#!/bin/sh
set -o errexit
set -o pipefail

print_usage_and_exit()
{
    echo "Usage: build_x86_64.sh <obj_dir> <r|d>"
    exit 1
}

KDIR_X86_64=$1
VER=$2
CPU='x86_64'
OSP_MAKE='make -j8'

if [ -z ${KDIR_X86_64} ]; then
    print_usage_and_exit
fi

if [ -z ${VER} ]; then
    print_usage_and_exit
fi

if [ ! -d ${KDIR_X86_64} ]; then
    mkdir -p ${KDIR_X86_64}
fi

if [ -f ${KDIR_X86_64}/.config ]; then
    $OSP_MAKE O=${KDIR_X86_64}
else
    $OSP_MAKE O=${KDIR_X86_64} distclean
    $OSP_MAKE O=${KDIR_X86_64} ${CPU}_${VER}_defconfig >/dev/null
    $OSP_MAKE O=${KDIR_X86_64}
fi

#!/bin/sh
set -o errexit
set -o pipefail

print_usage_and_exit()
{
    echo "Usage: build_powerpc.sh <obj_dir> <r|d>"
    exit 1
}

if [ -z $1 ]; then
    print_usage_and_exit
fi

KDIR_PPC=$1
cpu=$CPU
board=$BOARD

if [ ! -d $1 ]; then
    mkdir -p $1
fi

if [ ! -f Makefile ]; then
    touch Makefile
fi

if [ $2 == "r" ]; then
    msg=`comm -3 Makefile.r Makefile`
    if [ "$msg" != "" ]; then
        cp Makefile.r Makefile
    fi
    cp arch/powerpc/configs/${board}_defconfig.r arch/powerpc/configs/${board}_defconfig 
fi

if [ $2 == "d" ]; then
    msg=`comm -3 Makefile.d Makefile`
    if [ "$msg" != "" ]; then
        cp Makefile.d Makefile
    fi
    cp arch/powerpc/configs/${board}_defconfig.d arch/powerpc/configs/${board}_defconfig
fi

if [ -f $KDIR_PPC/.config ]; then
    cd $KDIR_PPC
    ${OSP_MAKE} O=$1 uImage
    ${OSP_MAKE} O=$1 ${board}_ctc.dtb
    rm arch/powerpc/configs/${board}_defconfig
else
    ${OSP_MAKE} O=$1 distclean
    ${OSP_MAKE} O=$1 ${board}_defconfig >/dev/null
    ${OSP_MAKE} O=$1 uImage
    ${OSP_MAKE} O=$1 ${board}_ctc.dtb
    rm arch/powerpc/configs/${board}_defconfig
fi

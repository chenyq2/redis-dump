"""
pyreverse.extensions
"""

__revision__ = "$Id $"

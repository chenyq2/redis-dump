/****************************************************************************
 * sram_model.c  :      sram operation interface
 *
 * Copyright (C) 2011 Centec Networks Inc.  All rights reserved.
 *
 * Modify History:
 * Revision     :       R0.02
 * Author       :       Fengger
 * Date         :       2005-6-4
 * Update     :         2010-02-24
 * Update Author    :   Zhouw
 * Reason       :       Compatible for Humber.
 ****************************************************************************/

/****************************************************************************
 *
* Header Files
*
****************************************************************************/
#if !defined(SDK_IN_KERNEL)
#include "sram_model.h"
#include "drv_tbl_reg.h"

/****************************************************************************
 *
* Global and Declarations
*
****************************************************************************/
uint8* sram_model_reg_wbit[MAX_LOCAL_CHIP_NUM][MAX_REG_NUM];
uint8* sram_model_tbl_wbit[MAX_LOCAL_CHIP_NUM][MAX_TBL_NUM];
bool sram_model_initialized_flag[MAX_LOCAL_CHIP_NUM];

/* Record Each Reg and Tbl's software address */
cmodel_reg_info_t cmodel_regs_info[MAX_LOCAL_CHIP_NUM][MAX_REG_NUM];
cmodel_tbl_info_t cmodel_tbls_info[MAX_LOCAL_CHIP_NUM][MAX_TBL_NUM];
/**************************************************************************
*
*Fuction Declarations
*
**************************************************************************/

/***************************************************************************
**  Functions
***************************************************************************/
/****************************************************************************
 * Name         : sram_humber_model_initialize
 * Purpose      : The function  initialize chip sram in bay or humber
 * Input         : chip_id-chip id
             chip_type - bay or humber
 * Output      : N/A
 * Return       : SUCCESS
 *                   Other   = ErrCode
 * Note         : N/A
****************************************************************************/

int32
sram_humber_model_initialize(uint8 chip_id)
{
    int32 ret = DRV_E_NONE;
    uint32 tbl_id = 0;
    uint32 reg_id = 0;
    uint32 idx;

    /* the following is some share mem table, so only malloc one time */
    uint32 share_tbl_num;
    bool nhp_maloc_flg = FALSE, l2edit_maloc_flg = FALSE, l3edit_maloc_flg = FALSE;
    bool oam_chan_flag = FALSE, oam_mep_flag = FALSE;
    bool acl_share_mem_flag = FALSE, qos_share_mem_flag = FALSE;
    bool  oam_hash_key0_flg = FALSE;
    bool  oam_hash_key1_flg = FALSE;

    uint32 nexthop_dyn_tbl_id[] = {DS_NEXTHOP, DS_NEXTHOP8W};
    uint32 l2edit_dyn_tbl_id[] = {DS_L2_EDIT_ETH4W, DS_L2_EDIT_ETH8W,
                                  DS_L2_EDIT_FLEX4W, DS_L2_EDIT_FLEX8W,
                                  DS_L2_EDIT_PBB4W, DS_L2_EDIT_PBB8W,
                                  DS_L2_EDIT_LOOPBACK};
    uint32 l3edit_dyn_tbl_id[] = {DS_L3EDIT_MPLS4W, DS_L3EDIT_MPLS8W,
                                  DS_L3EDIT_NAT4W,  DS_L3EDIT_NAT8W,
                                  DS_L3EDIT_TUNNEL_V4, DS_L3EDIT_TUNNEL_V6,
                                  DS_L3EDIT_FLEX, DS_L3EDIT_LOOP_BACK};
    uint32 oam_chan_tbl_id[] = {DS_ETH_OAM_CHAN, DS_MPLS_PBT_OAM_CHAN, DS_RMEP_CHAN, DS_MEP_CHAN_TABLE};
    uint32 oam_mep_tbl_id[] = {DS_ETH_MEP, DS_ETH_RMEP, DS_MPLS_MEP, DS_MPLS_RMEP};
    uint32 acl_mac_v4_mpls_tbl_id[] = {DS_MAC_ACL, DS_IPV4_ACL, DS_MPLS_ACL};
    uint32 qos_mac_v4_mpls_tbl_id[] = {DS_MAC_QOS, DS_IPV4_QOS, DS_MPLS_QOS};
    uint32 oam_hash_key0_tbl_id[] = {DS_ETH_OAM_HASH_KEY0, DS_PBT_OAM_HASH_KEY0, DS_MPLS_OAM_LABEL_HASH_KEY0, \
                                     DS_MPLS_OAM_IPV4_TTSI_HASH_KEY0, DS_ETH_OAM_RMEP_HASH_KEY0};
    uint32 oam_hash_key1_tbl_id[] = {DS_ETH_OAM_HASH_KEY1, DS_PBT_OAM_HASH_KEY1, DS_MPLS_OAM_LABEL_HASH_KEY1, \
                                     DS_MPLS_OAM_IPV4_TTSI_HASH_KEY1, DS_ETH_OAM_RMEP_HASH_KEY1};

    /* Cmodel only support up to 2 same chip */
    SRAM_CHIP_ID_VALID_CHECK(chip_id);

    /* check whether the chip's sram has been malloc or not */
    if (sram_model_initialized_flag[chip_id])
    {
        return DRV_E_NONE;
    }

    /* Malloc each register Memory */
    for (reg_id = 0; reg_id < MAX_REG_NUM; reg_id++)
    {
        uint32 reg_mem_size;

        /* malloc the reg's model memory according to the registed information */
        reg_mem_size = drv_regs_list[reg_id].entry_size
            * drv_regs_list[reg_id].max_index_num;

        cmodel_regs_info[chip_id][reg_id].sw_data_base = (uint32)malloc(reg_mem_size);
        if (!cmodel_regs_info[chip_id][reg_id].sw_data_base)
        {
            return DRV_E_NO_MEMORY;
        }

        sal_memset((uint32*)cmodel_regs_info[chip_id][reg_id].sw_data_base, 0, reg_mem_size);

        sram_model_reg_wbit[chip_id][reg_id] = malloc(drv_regs_list[reg_id].max_index_num);
        if (!sram_model_reg_wbit[chip_id][reg_id])
        {
            return DRV_E_NO_MEMORY;
        }

        sal_memset(sram_model_reg_wbit[chip_id][reg_id], 0, drv_regs_list[reg_id].max_index_num);
    }

    /* Malloc each table Memory */
    /* Do not include dynicTbl/TcamKeyTbl/HashKeyTbl.ect memory */
    for (tbl_id = 0; tbl_id < MAX_TBL_NUM; tbl_id++)
    {
        uint32 tbl_mem_size;
        uint32* tbl_arry_ptr = NULL;

        /* Check whether the table is dynic/TcamKey/HashKey.ect or not */
        /* TcamKey will malloc in tcam model */
        /* Dynic table and hashKey allocation happens after driver init , and use
           cli cmd method*/

        /* those no-allocated tables not malloc */
        if (!drv_tbls_list[tbl_id].max_index_num)
        {
            continue;
        }

        /* tcam each key not alloc mem in here */
        if (SRAM_MODEL_IS_TCAM_KEY(tbl_id))
        {
            continue;
        }

        /* share tables had been malloc one time */
        /* for those share tabels, need to do special resolve */
        if (SRAM_MODEL_IS_NEXTHOP_SHARE_TBL(tbl_id))
        {
            if (nhp_maloc_flg == FALSE)
            {
                share_tbl_num = sizeof(nexthop_dyn_tbl_id) / sizeof(uint32);
                nhp_maloc_flg = TRUE;
                tbl_arry_ptr = nexthop_dyn_tbl_id;
            }
            else
            {
                continue;
            }
        }
        else if (SRAM_MODEL_IS_L2EDIT_SHARE_TBL(tbl_id))
        {
            if (l2edit_maloc_flg == FALSE)
            {
                share_tbl_num = sizeof(l2edit_dyn_tbl_id) / sizeof(uint32);
                l2edit_maloc_flg = TRUE;
                tbl_arry_ptr = l2edit_dyn_tbl_id;
            }
            else
            {
                continue;
            }
        }
        else if (SRAM_MODEL_IS_L3EDIT_SHARE_TBL(tbl_id))
        {
            if (l3edit_maloc_flg == FALSE)
            {
                share_tbl_num = sizeof(l3edit_dyn_tbl_id) / sizeof(uint32);
                l3edit_maloc_flg = TRUE;
                tbl_arry_ptr = l3edit_dyn_tbl_id;
            }
            else
            {
                continue;
            }
        }
        else if (SRAM_MODEL_IS_OAM_CHAN_TBL(tbl_id))
        {
            if (oam_chan_flag == FALSE)
            {
                share_tbl_num = sizeof(oam_chan_tbl_id) / sizeof(uint32);
                oam_chan_flag = TRUE;
                tbl_arry_ptr = oam_chan_tbl_id;
            }
            else
            {
                continue;
            }
        }
        else if (SRAM_MODEL_IS_OAM_MEP_TBL(tbl_id))
        {
            if (oam_mep_flag == FALSE)
            {
                share_tbl_num = sizeof(oam_mep_tbl_id) / sizeof(uint32);
                oam_mep_flag = TRUE;
                tbl_arry_ptr = oam_mep_tbl_id;
            }
            else
            {
                continue;
            }
        }
        else if (SRAM_MODEL_IS_ACL_SHARE_TBL(tbl_id))
        {
            if (acl_share_mem_flag == FALSE)
            {
                share_tbl_num = sizeof(acl_mac_v4_mpls_tbl_id) / sizeof(uint32);
                acl_share_mem_flag = TRUE;
                tbl_arry_ptr = acl_mac_v4_mpls_tbl_id;
            }
            else
            {
                continue;
            }
        }
        else if (SRAM_MODEL_IS_QOS_SHARE_TBL(tbl_id))
        {
            if (qos_share_mem_flag == FALSE)
            {
                share_tbl_num = sizeof(qos_mac_v4_mpls_tbl_id) / sizeof(uint32);
                qos_share_mem_flag = TRUE;
                tbl_arry_ptr = qos_mac_v4_mpls_tbl_id;
            }
            else
            {
                continue;
            }
        }
        else if (SRAM_MODEL_IS_OAM_HASH_KEY0_SHARE_TBL(tbl_id))
        {
            if (FALSE == oam_hash_key0_flg)
            {
                share_tbl_num = sizeof(oam_hash_key0_tbl_id) / sizeof(uint32);
                oam_hash_key0_flg = TRUE;
                tbl_arry_ptr = oam_hash_key0_tbl_id;
            }
            else
            {
                continue;
            }
        }
        else if (SRAM_MODEL_IS_OAM_HASH_KEY1_SHARE_TBL(tbl_id))
        {
            if (FALSE == oam_hash_key1_flg)
            {
                share_tbl_num = sizeof(oam_hash_key1_tbl_id) / sizeof(uint32);
                oam_hash_key1_flg = TRUE;
                tbl_arry_ptr = oam_hash_key1_tbl_id;
            }
            else
            {
                continue;
            }
        }
        else
        {
            share_tbl_num = 0;
        }

        tbl_mem_size = drv_tbls_list[tbl_id].max_index_num
            * drv_tbls_list[tbl_id].entry_size;

        cmodel_tbls_info[chip_id][tbl_id].sw_data_base = (uint32)malloc(tbl_mem_size);
        if (!cmodel_tbls_info[chip_id][tbl_id].sw_data_base)
        {
            return DRV_E_NO_MEMORY;
        }

        if (SRAM_MODEL_IS_HASH_KEY_SHARE_TBL(tbl_id))  /* hash table init 1 */
        {
            sal_memset((uint32*)cmodel_tbls_info[chip_id][tbl_id].sw_data_base, 1, tbl_mem_size);
        }
        else
        {
            sal_memset((uint32*)cmodel_tbls_info[chip_id][tbl_id].sw_data_base, 0, tbl_mem_size);
        }

        sram_model_tbl_wbit[chip_id][tbl_id] = malloc(drv_tbls_list[tbl_id].max_index_num);
        if (!sram_model_tbl_wbit[chip_id][tbl_id])
        {
            return DRV_E_NO_MEMORY;
        }

        sal_memset(sram_model_tbl_wbit[chip_id][tbl_id], 0, drv_tbls_list[tbl_id].max_index_num);

        /* Record base of those tables which is share with the table */
        if (share_tbl_num != 0)
        {
            for (idx = 0; idx < share_tbl_num; idx++)
            {
                uint32 tbl_id_temp = tbl_arry_ptr[idx];
                if (tbl_id_temp != tbl_id)
                {
                    cmodel_tbls_info[chip_id][tbl_id_temp].sw_data_base = cmodel_tbls_info[chip_id][tbl_id].sw_data_base;
                    sram_model_tbl_wbit[chip_id][tbl_id_temp] = sram_model_tbl_wbit[chip_id][tbl_id];
                }
            }
        }
    }

    sram_model_initialized_flag[chip_id] = TRUE;
    /* printf("TotalUseMemory = %d M bytes!\n", total_mem/1024/1024);
     */
    return ret;
}

/****************************************************************************
 * Name         : sram_model_initialize
 * Purpose      : The function  initialize chip sram
 * Input         : chip_id-chip id
 * Output      : N/A
 * Return       : SUCCESS
 *                   Other   = ErrCode
 * Note         : N/A
****************************************************************************/
int32
sram_model_initialize(uint8 chip_id)
{
    int32 ret = DRV_E_NONE;

    ret = sram_humber_model_initialize(chip_id);

    return ret;
}

int32
sram_model_release(uint8 chip_id)
{
    uint32 tbl_id = 0;
    uint32 reg_id = 0;
    uint32* sw_mem_ptr = NULL;

    /* Cmodel only support up to 2 same chip */
    SRAM_CHIP_ID_VALID_CHECK(chip_id);

    /* release each reg's memory */
    for (reg_id = 0; reg_id < MAX_REG_NUM; reg_id++)
    {
        if (!cmodel_regs_info[chip_id][reg_id].sw_data_base)
        {
            sw_mem_ptr = (uint32*)cmodel_regs_info[chip_id][reg_id].sw_data_base;
            free(sw_mem_ptr);
            cmodel_regs_info[chip_id][reg_id].sw_data_base = 0;
        }

        if (!sram_model_reg_wbit[chip_id][reg_id])
        {
            free(sram_model_reg_wbit[chip_id][reg_id]);
            sram_model_reg_wbit[chip_id][reg_id] = NULL;
        }
    }

    /* release each tbl's memory */
    for (tbl_id = 0; tbl_id < MAX_TBL_NUM; tbl_id++)
    {
        if (!cmodel_tbls_info[chip_id][tbl_id].sw_data_base)
        {
            sw_mem_ptr = (uint32*)cmodel_tbls_info[chip_id][tbl_id].sw_data_base;
            free(sw_mem_ptr);
            cmodel_tbls_info[chip_id][tbl_id].sw_data_base = 0;
        }

        if (!sram_model_tbl_wbit[chip_id][tbl_id])
        {
            free(sram_model_tbl_wbit[chip_id][tbl_id]);
            sram_model_tbl_wbit[chip_id][tbl_id] = NULL;
        }
    }

    return DRV_E_NONE;
}

/****************************************************************************
 * Name         : ram_read
 * Purpose      : The function  read data from sram to controller.
 * Input         : offset - the offset address of the target
            ram_type - the ram type
                     data - the read data
                     len - the data length
 * Output       : N/A
 * Return        : SUCCESS
 *                    Other   = ErrCode
 * Note          : N/A
****************************************************************************/
int32
sram_model_read(uint8  chip_id,
                uint32 sw_model_addr,
                uint32* data,
                int32  len)
{
    SRAM_CHIP_ID_VALID_CHECK(chip_id);

    /* May be add code to check whether the address is valid or not */

    SRAM_MODEL_PTR_VALID_CHECK(data);

    sal_memcpy(data, (uint32*)sw_model_addr, len);

    return DRV_E_NONE;
}

/****************************************************************************
 * Name         : ram_write
 * Purpose      : The function  write data from controller to sram.
 * Input         : offset - the offset address of the target
            ram_type - the ram type
                     data - the read data
                     len - the data length
 * Output       : N/A
 * Return        : SUCCESS
 *                    Other   = ErrCode
 * Note          : N/A
****************************************************************************/
int32
sram_model_write(uint8  chip_id,
                 uint32 sw_model_addr,
                 uint32* data,
                 int32  len)
{
    SRAM_CHIP_ID_VALID_CHECK(chip_id);

    /* May be add code to check whether the address is valid or not */

    SRAM_MODEL_PTR_VALID_CHECK(data);

    sal_memcpy((uint32*)sw_model_addr, data,  len);

    /* set wbit for dump after write action(move to drv) */

    return DRV_E_NONE;
}

/****************************************************************************
 * Name         : sram_reset
 * Purpose      : reset the sram's value
 * Input        :

 * Output       : N/A
 * Return       : SUCCESS
 *              Other   = ErrCode
 * Note         : N/A
****************************************************************************/
int32
sram_model_reset(uint8 chip_id)
{
    uint32 tbl_id = 0;
    uint32 reg_id = 0;

    for (reg_id = 0; reg_id < MAX_REG_NUM; reg_id++)
    {
        uint32 reg_mem_size = drv_regs_list[reg_id].entry_size
            * drv_regs_list[reg_id].max_index_num;

        if (cmodel_regs_info[chip_id][reg_id].sw_data_base)
        {
            sal_memset((uint32*)cmodel_regs_info[chip_id][reg_id].sw_data_base, 0, reg_mem_size);
        }

        if (sram_model_reg_wbit[chip_id][reg_id])
        {
            sal_memset(sram_model_reg_wbit[chip_id][reg_id], 0, drv_regs_list[reg_id].max_index_num);
        }
    }

    for (tbl_id = 0; tbl_id < MAX_TBL_NUM; tbl_id++)
    {
        uint32 tbl_mem_size = drv_tbls_list[tbl_id].entry_size
            * drv_tbls_list[tbl_id].max_index_num;

        if (cmodel_tbls_info[chip_id][tbl_id].sw_data_base)
        {
            sal_memset((uint32*)cmodel_tbls_info[chip_id][tbl_id].sw_data_base, 0, tbl_mem_size);
        }

        if (sram_model_tbl_wbit[chip_id][tbl_id])
        {
            sal_memset(sram_model_tbl_wbit[chip_id][tbl_id], 0, drv_tbls_list[tbl_id].max_index_num);
        }
    }

    return DRV_E_NONE;
}

#endif


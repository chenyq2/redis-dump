#ifndef _SRAM_MODEL_H_
#define _SRAM_MODEL_H_
#ifdef __cplusplus
extern "C" {
#endif

#include "drv_error.h"
#include "drv_enum.h"
#include "drv_humber.h"
#include "drv_common.h"
#include "sal.h"

#define SRAM_MODEL_PTR_VALID_CHECK(ptr) \
    if (NULL == (ptr))                \
    {                                   \
        return DRV_E_INVALID_PTR;       \
    }

#define SRAM_MODEL_IS_TCAM_KEY(tbl_id)       \
    ((DS_MAC_KEY == (tbl_id))           \
     || (DS_ACL_MAC_KEY == (tbl_id))      \
     || (DS_ACL_IPV4_KEY == (tbl_id))     \
     || (DS_ACL_IPV6_KEY == (tbl_id))     \
     || (DS_QOS_MAC_KEY == (tbl_id))      \
     || (DS_QOS_IPV4_KEY == (tbl_id))     \
     || (DS_QOS_IPV6_KEY == (tbl_id))     \
     || (DS_IPV4_UCAST_ROUTE_KEY == (tbl_id))     \
     || (DS_IPV4_MCAST_ROUTE_KEY == (tbl_id))     \
     || (DS_IPV6_UCAST_ROUTE_KEY == (tbl_id))     \
     || (DS_IPV6_MCAST_ROUTE_KEY == (tbl_id))     \
     || (DS_IPV4_NAT_KEY == (tbl_id))             \
     || (DS_IPV4_PBR_DUALDA_KEY == (tbl_id))      \
     || (DS_USER_ID_IPV4_KEY == (tbl_id))         \
     || (DS_USER_ID_IPV6_KEY == (tbl_id))         \
     || (DS_USER_ID_MAC_KEY == (tbl_id))          \
     || (DS_USER_ID_VLAN_KEY == (tbl_id))         \
     || (DS_IPV6_NAT_KEY == (tbl_id))             \
     || (DS_IPV6_PBR_DUALDA_KEY == (tbl_id))      \
     || (DS_ETH_OAM_KEY == (tbl_id))              \
     || (DS_ETH_OAM_RMEP_KEY == (tbl_id))         \
     || (DS_MPLS_OAM_LABEL_KEY == (tbl_id))       \
     || (DS_MPLS_OAM_IPV4_TTSI_KEY == (tbl_id))   \
     || (DS_PBT_OAM_KEY == (tbl_id)))

#define SRAM_MODEL_IS_NEXTHOP_SHARE_TBL(tbl_id) \
    ((DS_NEXTHOP8W == (tbl_id))            \
     || (DS_NEXTHOP == (tbl_id)))

#define SRAM_MODEL_IS_L2EDIT_SHARE_TBL(tbl_id)  \
    ((DS_L2_EDIT_ETH4W == (tbl_id))          \
     || (DS_L2_EDIT_ETH8W == (tbl_id))        \
     || (DS_L2_EDIT_FLEX4W == (tbl_id))       \
     || (DS_L2_EDIT_FLEX8W == (tbl_id))       \
     || (DS_L2_EDIT_PBB4W == (tbl_id))        \
     || (DS_L2_EDIT_PBB8W == (tbl_id))        \
     || (DS_L2_EDIT_LOOPBACK == (tbl_id)))

#define SRAM_MODEL_IS_L3EDIT_SHARE_TBL(tbl_id)  \
    ((DS_L3EDIT_MPLS4W == (tbl_id))         \
     || (DS_L3EDIT_MPLS8W == (tbl_id))       \
     || (DS_L3EDIT_NAT4W == (tbl_id))        \
     || (DS_L3EDIT_NAT8W == (tbl_id))        \
     || (DS_L3EDIT_TUNNEL_V4 == (tbl_id))    \
     || (DS_L3EDIT_TUNNEL_V6 == (tbl_id))    \
     || (DS_L3EDIT_FLEX == (tbl_id))         \
     || (DS_L3EDIT_LOOP_BACK == (tbl_id)))

#define SRAM_MODEL_IS_OAM_CHAN_TBL(tbl_id)         \
    ((DS_ETH_OAM_CHAN == (tbl_id))            \
     || (DS_MPLS_PBT_OAM_CHAN == (tbl_id))      \
     || (DS_RMEP_CHAN == (tbl_id))              \
     || (DS_MEP_CHAN_TABLE == (tbl_id)))

#define SRAM_MODEL_IS_OAM_MEP_TBL(tbl_id)          \
    ((DS_ETH_MEP == (tbl_id))                 \
     || (DS_ETH_RMEP == (tbl_id))               \
     || (DS_MPLS_MEP == (tbl_id))               \
     || (DS_MPLS_RMEP == (tbl_id)))

#define SRAM_MODEL_IS_FOAM_OAM_CHAN_TBL(tbl_id)         \
    ((FOAM_DS_ETH_OAM_CHAN == (tbl_id))            \
     || (FOAM_DS_MPLS_PBT_BFD_OAM_CHAN == (tbl_id)))

#define SRAM_MODEL_IS_FOAM_MA_OR_MAC_NAME_TBL(tbl_id)         \
    ((FOAM_DS_MA_NAME == (tbl_id))            \
     || (FOAM_DS_MA == (tbl_id)))

#define SRAM_MODEL_IS_ACL_SHARE_TBL(tbl_id)        \
    ((DS_MAC_ACL == (tbl_id))                  \
     || (DS_IPV4_ACL == (tbl_id))                \
     || (DS_MPLS_ACL == (tbl_id)))

#define SRAM_MODEL_IS_QOS_SHARE_TBL(tbl_id)        \
    ((DS_MAC_QOS == (tbl_id))              \
     || (DS_IPV4_QOS == (tbl_id))            \
     || (DS_MPLS_QOS == (tbl_id)))

#define SRAM_MODEL_IS_OAM_HASH_KEY0_SHARE_TBL(tbl_id)       \
    ((DS_ETH_OAM_HASH_KEY0 == (tbl_id))             \
     || (DS_PBT_OAM_HASH_KEY0 == (tbl_id))            \
     || (DS_MPLS_OAM_LABEL_HASH_KEY0 == (tbl_id))      \
     || (DS_MPLS_OAM_IPV4_TTSI_HASH_KEY0 == (tbl_id)) \
     || (DS_ETH_OAM_RMEP_HASH_KEY0 == (tbl_id)))

#define SRAM_MODEL_IS_OAM_HASH_KEY1_SHARE_TBL(tbl_id)       \
    ((DS_ETH_OAM_HASH_KEY1 == (tbl_id))             \
     || (DS_PBT_OAM_HASH_KEY1 == (tbl_id))            \
     || (DS_MPLS_OAM_LABEL_HASH_KEY1 == (tbl_id))      \
     || (DS_MPLS_OAM_IPV4_TTSI_HASH_KEY1 == (tbl_id)) \
     || (DS_ETH_OAM_RMEP_HASH_KEY1 == (tbl_id)))

#define SRAM_MODEL_IS_HASH_KEY_SHARE_TBL(tbl_id)       \
    ((DS_MAC_HASH_KEY0 == (tbl_id))                    \
     || (DS_MAC_HASH_KEY1 == (tbl_id))                  \
     || (DS_IPV4_UCAST_HASH_KEY0 == (tbl_id))           \
     || (DS_IPV4_UCAST_HASH_KEY1 == (tbl_id))           \
     || (DS_IPV4_MCAST_HASH_KEY0 == (tbl_id))           \
     || (DS_IPV4_MCAST_HASH_KEY1 == (tbl_id))           \
     || (DS_IPV6_UCAST_HASH_KEY0 == (tbl_id))           \
     || (DS_IPV6_UCAST_HASH_KEY1 == (tbl_id))           \
     || (DS_IPV6_MCAST_HASH_KEY0 == (tbl_id))           \
     || (DS_IPV6_MCAST_HASH_KEY1 == (tbl_id))           \
     || (DS_ETH_OAM_HASH_KEY0 == (tbl_id))              \
     || (DS_ETH_OAM_HASH_KEY1 == (tbl_id))              \
     || (DS_PBT_OAM_HASH_KEY0 == (tbl_id))              \
     || (DS_PBT_OAM_HASH_KEY1 == (tbl_id))              \
     || (DS_MPLS_OAM_LABEL_HASH_KEY0 == (tbl_id))       \
     || (DS_MPLS_OAM_LABEL_HASH_KEY1 == (tbl_id))       \
     || (DS_MPLS_OAM_IPV4_TTSI_HASH_KEY0 == (tbl_id))   \
     || (DS_MPLS_OAM_IPV4_TTSI_HASH_KEY1 == (tbl_id))   \
     || (DS_ETH_OAM_RMEP_HASH_KEY0 == (tbl_id))         \
     || (DS_ETH_OAM_RMEP_HASH_KEY1 == (tbl_id)))

#define SRAM_CHIP_ID_VALID_CHECK(chip_id) \
    if ((chip_id) >= (MAX_LOCAL_CHIP_NUM))           \
    {                                         \
        DRV_DBG_INFO("Out of chip_id number\n"); \
        return DRV_E_INVALID_CHIP;            \
    }

/* Record each register sw base address in cmodel stucture */
struct cmodel_reg_info_s
{
    uint32  sw_data_base;
};
typedef struct cmodel_reg_info_s  cmodel_reg_info_t;

/* Record each table sw base address in cmodel stucture */
/* when the table is tcam key, we can get the key database and maskbase
   according to the whole tcam base and the key hw_offset,
   so to tcam key table we do not need the sw_data_base */
struct cmodel_tbl_info_s
{
    uint32  sw_data_base;
};
typedef struct cmodel_tbl_info_s cmodel_tbl_info_t;

extern int32 sram_model_initialize(uint8 chip_id);
extern int32 sram_model_release(uint8 chip_id);

extern int32 sram_model_read(uint8 chip_id,
                             uint32 sw_model_addr,
                             uint32* data,
                             int32 len);

extern int32 sram_model_write(uint8 chip_id,
                              uint32 sw_model_addr,
                              uint32* data,
                              int32 len);

extern int32 sram_model_reset(uint8 chip_id);

extern cmodel_reg_info_t cmodel_regs_info[MAX_LOCAL_CHIP_NUM][MAX_REG_NUM];
extern cmodel_tbl_info_t cmodel_tbls_info[MAX_LOCAL_CHIP_NUM][MAX_TBL_NUM];

#ifdef __cplusplus
}
#endif

#endif


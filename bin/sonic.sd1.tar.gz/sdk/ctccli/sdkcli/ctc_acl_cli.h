/**
 @file ctc_acl_cli.h

 @date 2009-12-22

 @version v2.0

*/

#ifndef _CTC_ACL_CLI_H_
#define _CTC_ACL_CLI_H_

#include "sal.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"

#define CHECK_FLAG(V, F)      ((V)&(F))
#define SET_FLAG(V, F)        (V) = (V) | (F)
#define UNSET_FLAG(V, F)      (V) = (V)&~(F)

#define ACL_IGMP_TYPE_HOST_QUERY                 0x11
#define ACL_IGMP_TYPE_HOST_REPORT                0x12
#define ACL_IGMP_TYPE_HOST_DVMRP                 0x13
#define ACL_IGMP_TYPE_PIM                        0x14
#define ACL_IGMP_TYPE_TRACE                      0x15
#define ACL_IGMP_TYPE_V2_REPORT                  0x16
#define ACL_IGMP_TYPE_V2_LEAVE                   0x17
#define ACL_IGMP_TYPE_MTRACE                     0x1f
#define ACL_IGMP_TYPE_MTRACE_RESPONSE            0x1e
#define ACL_IGMP_TYPE_PRECEDENCE                 0          /*temp, maybe change later*/
#define ACL_IGMP_TYPE_V3_REPORT                  0x22

#ifdef __cplusplus
extern "C" {
#endif

extern int32
ctc_acl_cli_init(void);

#ifdef __cplusplus
}
#endif

#endif


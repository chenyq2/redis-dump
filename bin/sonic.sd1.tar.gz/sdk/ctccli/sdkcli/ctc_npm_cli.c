/**
 @file Ctc_npm_cli.c

 @date 2016-04-26

 @version v1.0

 This file defines functions for npm cli module

*/

#include "ctc_api.h"
#include "ctcs_api.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"
#include "ctc_debug.h"
#include "ctc_npm.h"

#define CTC_CLI_NPM_M_STR "NPM Module"


CTC_CLI(ctc_cli_npm_set_session_transmit_en,
         ctc_cli_npm_set_session_transmit_en_cmd,
         "npm session SESSION transmit (enable | disable) (lchip LCHIP_ID | )",
         CTC_CLI_NPM_M_STR,
         "Session",
         "Session id",
         "Transmit Function",
         CTC_CLI_ENABLE,
         CTC_CLI_DISABLE,
         "Local chip",
         CTC_CLI_LCHIP_ID_VALUE)
{
    int32 ret = CLI_SUCCESS;
    uint8 enable = 0;
    uint8 session_id = 0;
    uint8 lchip = 0;
    uint8 index = 0;

    CTC_CLI_GET_UINT8_RANGE("session id", session_id, argv[0], 0, CTC_MAX_UINT8_VALUE);

    if (0 == sal_memcmp(argv[1],"e",1))
    {
        enable=1;
    }
    else
    {
        enable=0;
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (index != 0xFF)
    {
        if (index + 1 >= argc)
        {
            ctc_cli_out("%% Insufficient  param \n\r");
            return CLI_ERROR;
        }

        CTC_CLI_GET_UINT8_RANGE("lchip", lchip, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);

    }

    if(g_ctcs_api_en)
    {
        ret = ctcs_npm_set_transmit_en(g_api_lchip,  session_id, enable);
    }
    else
    {
        ret = ctc_npm_set_transmit_en(lchip, session_id, enable);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}



CTC_CLI(ctc_cli_npm_get_session_stats,
        ctc_cli_npm_get_session_stats_cmd,
        "show npm session SESSION stats (slm | dmm | lbm | 1sl | 1dm | tst | owamp | twamp | flex) (lchip LCHIP_ID | )",
        CTC_CLI_SHOW_STR,
        CTC_CLI_NPM_M_STR,
        "Session",
        "Session id",
        "Stats",
        "Get SLM Stats",
        "Get DMM Stats",
        "Get LBM Stats",
        "Get 1SL Stats",
        "Get 1DM Stats",
        "Get TST Stats",
        "Get OWAMP Stats",
        "Get TWAMP Stats",
        "Get FLEX Stats",
        "Local chip",
        CTC_CLI_LCHIP_ID_VALUE)
{
    int32 ret = CLI_SUCCESS;
    uint8 session_id = 0;
    uint8 index = 0;
    uint8 lchip = 0;
    ctc_npm_stats_t stats;

    sal_memset(&stats, 0, sizeof(ctc_npm_stats_t));

    CTC_CLI_GET_UINT8_RANGE("session id", session_id, argv[0], 0, CTC_MAX_UINT8_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (index != 0xFF)
    {
        if (index + 1 >= argc)
        {
            ctc_cli_out("%% Insufficient  param \n\r");
            return CLI_ERROR;
        }

        CTC_CLI_GET_UINT8_RANGE("lchip", lchip, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);

    }

    if (g_ctcs_api_en)
    {
        ret = ctcs_npm_get_stats(g_api_lchip,  session_id, &stats);
    }
    else
    {
        ret = ctc_npm_get_stats(lchip, session_id, &stats);
    }
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    index = CTC_CLI_GET_ARGC_INDEX("slm");
    if (0xFF != index)
    {
        ctc_cli_out("-------------------------Session %d stats for SLM-------------------------\n", session_id);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Total delay", stats.total_delay);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Total far delay", stats.total_far_delay);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Total near delay", stats.total_near_delay);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "First timestamp", stats.first_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Last timestamp", stats.last_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Tx Fcf", stats.tx_fcf);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Tx Fcb", stats.tx_fcb);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Rx Fcl", stats.rx_fcl);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dmm");
    if (0xFF != index)
    {
        ctc_cli_out("-------------------------Session %d stats for DMM-------------------------\n", session_id);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Total delay", stats.total_delay);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Total far delay", stats.total_far_delay);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Total near delay", stats.total_near_delay);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "First timestamp", stats.first_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Last timestamp", stats.last_ts);
    }

    index = CTC_CLI_GET_ARGC_INDEX("lbm");
    if (0xFF != index)
    {
        ctc_cli_out("-------------------------Session %d stats for LBM-------------------------\n", session_id);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "First timestamp", stats.first_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Last timestamp", stats.last_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Tx packets", stats.tx_pkts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Rx packets", stats.rx_pkts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Tx bytes", stats.tx_bytes);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Rx bytes", stats.rx_bytes);
    }

    index = CTC_CLI_GET_ARGC_INDEX("1sl");
    if (0xFF != index)
    {
        ctc_cli_out("-------------------------Session %d stats for 1SL-------------------------\n", session_id);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "First timestamp", stats.first_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Last timestamp", stats.last_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Tx Fcf", stats.tx_fcf);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Rx Fcl", stats.rx_fcl);
    }

    index = CTC_CLI_GET_ARGC_INDEX("1dm");
    if (0xFF != index)
    {
        ctc_cli_out("-------------------------Session %d stats for 1DM-------------------------\n", session_id);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Total delay", stats.total_delay);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "First timestamp", stats.first_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Last timestamp", stats.last_ts);
    }

    index = CTC_CLI_GET_ARGC_INDEX("tst");
    if (0xFF != index)
    {
        ctc_cli_out("-------------------------Session %d stats for TST-------------------------\n", session_id);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "First timestamp", stats.first_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Last timestamp", stats.last_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Tx packets", stats.tx_pkts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Rx packets", stats.rx_pkts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Tx bytes", stats.tx_bytes);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Rx bytes", stats.rx_bytes);
    }

    index = CTC_CLI_GET_ARGC_INDEX("owamp");
    if (0xFF != index)
    {
        ctc_cli_out("-------------------------Session %d stats for OWAMP-------------------------\n", session_id);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Total delay", stats.total_delay);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "First timestamp", stats.first_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Last timestamp", stats.last_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Tx packets", stats.tx_pkts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Rx packets", stats.rx_pkts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Tx bytes", stats.tx_bytes);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Rx bytes", stats.rx_bytes);
    }

    index = CTC_CLI_GET_ARGC_INDEX("twamp");
    if (0xFF != index)
    {
        ctc_cli_out("-------------------------Session %d stats for TWAMP-------------------------\n", session_id);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Total delay", stats.total_delay);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Total far delay", stats.total_far_delay);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Total near delay", stats.total_near_delay);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "First timestamp", stats.first_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Last timestamp", stats.last_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Tx packets", stats.tx_pkts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Rx packets", stats.rx_pkts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Tx bytes", stats.tx_bytes);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Rx bytes", stats.rx_bytes);
    }


    index = CTC_CLI_GET_ARGC_INDEX("flex");
    if (0xFF != index)
    {
        ctc_cli_out("-------------------------Session %d stats for FLEX-------------------------\n", session_id);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Total delay", stats.total_delay);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "First timestamp", stats.first_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Last timestamp", stats.last_ts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Tx packets", stats.tx_pkts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Rx packets", stats.rx_pkts);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Tx bytes", stats.tx_bytes);
        ctc_cli_out("%-30s: 0x%"PRIx64"\n", "Rx bytes", stats.rx_bytes);
    }

    return CLI_SUCCESS;
}


CTC_CLI(ctc_cli_npm_set_global_cfg,
        ctc_cli_npm_set_global_cfg_cmd,
        "npm global-cfg {session-mode MODE | frame-size-array SIZE1 (SIZE2 (SIZE3 (SIZE4 (SIZE5 (SIZE6 (SIZE7 \
        (SIZE8 (SIZE9 (SIZE10 (SIZE11 (SIZE12 (SIZE13 (SIZE14 (SIZE15 (SIZE16 | ) | ) | ) | ) | ) | ) | ) | ) | ) \
        | ) | ) | ) | ) | ) | )} (lchip LCHIP_ID | )",
        CTC_CLI_NPM_M_STR,
        "Global Configure",
        "Session Mode",
        "Mode:0-Max Session Number 8, 1-Max Session Number 6, 2-Max Session Number 4",
        "Frame-Size-Array",
        "Frame Size:<64-16128>",
        "Frame Size:<64-16128>",
        "Frame Size:<64-16128>",
        "Frame Size:<64-16128>",
        "Frame Size:<64-16128>",
        "Frame Size:<64-16128>",
        "Frame Size:<64-16128>",
        "Frame Size:<64-16128>",
        "Frame Size:<64-16128>",
        "Frame Size:<64-16128>",
        "Frame Size:<64-16128>",
        "Frame Size:<64-16128>",
        "Frame Size:<64-16128>",
        "Frame Size:<64-16128>",
        "Frame Size:<64-16128>",
        "Frame Size:<64-16128>",
        "Local chip",
        CTC_CLI_LCHIP_ID_VALUE)
{
    int32 ret = 0;
    uint8 index = 0;
    uint8 n = 0;
    uint8 i = 0;
    uint8 flag = 0;
    uint8 lchip = 0;

    ctc_npm_global_cfg_t npm;

    sal_memset(&npm, 0, sizeof(ctc_npm_global_cfg_t));

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (index != 0xFF)
    {
        if (index + 1 >= argc)
        {
            ctc_cli_out("%% Insufficient  param \n\r");
            return CLI_ERROR;
        }

        CTC_CLI_GET_UINT8_RANGE("lchip", lchip, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);

    }
    if(g_ctcs_api_en)
    {
        ret = ctcs_npm_get_global_config(g_api_lchip, &npm);
    }
    else
    {
        ret = ctc_npm_get_global_config(lchip, &npm);
    }



    index = CTC_CLI_GET_ARGC_INDEX("session-mode");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8_RANGE("session-mode value", npm.session_mode, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
        flag += 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("frame-size-array");
    if (0xFF != index)
    {


        if (flag == 0)
        {
            n = 1;
        }
        else
        {
            n = 3;
        }

        for (i = 0; i < argc - n; i++)
        {
            CTC_CLI_GET_UINT16_RANGE("frame size", npm.emix_size[i], argv[n + i], 0, CTC_MAX_UINT16_VALUE);
        }


    }

    if (g_ctcs_api_en)
    {
        ret = ctcs_npm_set_global_config(g_api_lchip, &npm);
    }
    else
    {
        ret = ctc_npm_set_global_config(lchip, &npm);
    }
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}

CTC_CLI(ctc_cli_npm_debug_on,
        ctc_cli_npm_debug_on_cmd,
        "debug npm (ctc|sys) (debug-level {func|param|info|error} |)",
        CTC_CLI_DEBUG_STR,
        "NPM module",
        "CTC layer",
        "Sys layer",
        CTC_CLI_DEBUG_LEVEL_STR,
        CTC_CLI_DEBUG_LEVEL_FUNC,
        CTC_CLI_DEBUG_LEVEL_PARAM,
        CTC_CLI_DEBUG_LEVEL_INFO,
        CTC_CLI_DEBUG_LEVEL_ERROR)
{

    uint32 typeenum = 0;
    uint8 level = CTC_DEBUG_LEVEL_INFO | CTC_DEBUG_LEVEL_FUNC | CTC_DEBUG_LEVEL_PARAM | CTC_DEBUG_LEVEL_ERROR;
    uint8 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("debug-level");
    if (index != 0xFF)
    {
        level = CTC_DEBUG_LEVEL_NONE;
        index = CTC_CLI_GET_ARGC_INDEX("func");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_FUNC;
        }

        index = CTC_CLI_GET_ARGC_INDEX("param");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_PARAM;
        }

        index = CTC_CLI_GET_ARGC_INDEX("info");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_INFO;
        }

        index = CTC_CLI_GET_ARGC_INDEX("error");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_ERROR;
        }
    }

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = NPM_CTC;

    }
    else
    {
        typeenum = NPM_SYS;

    }

    ctc_debug_set_flag("npm", "npm", typeenum, level, TRUE);
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_npm_debug_off,
        ctc_cli_npm_debug_off_cmd,
        "no debug npm (ctc | sys)",
        CTC_CLI_NO_STR,
        CTC_CLI_DEBUG_STR,
        "NPM Module",
        "Ctc layer",
        "Sys layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = NPM_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = NPM_SYS;
    }

    ctc_debug_set_flag("npm", "npm", typeenum, level, FALSE);

    return CLI_SUCCESS;
}



CTC_CLI(ctc_cli_npm_get_global_cfg,
        ctc_cli_npm_get_global_cfg_cmd,
        "show npm global-cfg (lchip LCHIP_ID | )",
        CTC_CLI_SHOW_STR,
        CTC_CLI_NPM_M_STR,
        "Global Configure",
        "Local chip",
        CTC_CLI_LCHIP_ID_VALUE)

{
    int32 ret = 0;
    uint8 index = 0;
    uint8 i = 0;
    uint8 lchip = 0;
    ctc_npm_global_cfg_t npm;

    sal_memset(&npm, 0, sizeof(ctc_npm_global_cfg_t));
    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (index != 0xFF)
    {
        if (index + 1 >= argc)
        {
            ctc_cli_out("%% Insufficient  param \n\r");
            return CLI_ERROR;
        }

        CTC_CLI_GET_UINT8_RANGE("lchip", lchip, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);

    }
    if (g_ctcs_api_en)
    {
        ret = ctcs_npm_get_global_config(g_api_lchip, &npm);
    }
    else
    {
        ret = ctc_npm_get_global_config(lchip, &npm);
    }
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    ctc_cli_out("The Session Mode is:\n");
    if (0 == npm.session_mode)
    {
        ctc_cli_out("Max Session Number 8\n");
    }
    if (1 == npm.session_mode)
    {
        ctc_cli_out("Max Session Number 6\n");
    }
    if (2 == npm.session_mode)
    {
        ctc_cli_out("Max Session Number 4\n");
    }
    ctc_cli_out("------------------------------\n");
    ctc_cli_out("The EMIX Size Array is:\n");
    for (i = 0; i < CTC_NPM_MAX_EMIX_NUM; i++)
    {
        if (npm.emix_size[i] != 0)
        {
            ctc_cli_out("%5d ", npm.emix_size[i]);
        }
        else
        {
            break;
        }
    }
    ctc_cli_out("\n");
    return CLI_SUCCESS;

}




#define CTC_NPM_MAX_PKTHDR_LEN 384


static int32
_npm_cli_pkthdr_get_from_file(char* file, uint8* buf, uint16* pkt_len)
{
    sal_file_t fp = NULL;
    int8  line[128];
    int32 lidx = 0, cidx = 0, tmp_val = 0;

    /* read packet from file */
    fp = sal_fopen(file, "r");
    if (NULL == fp)
    {
        ctc_cli_out("%% Failed to open the file <%s>\n", file);
        return CLI_ERROR;
    }

    sal_memset(line, 0, 128);
    while (sal_fgets((char*)line, 128, fp))
    {
        for (cidx = 0; cidx < 16; cidx++)
        {
            if (1 == sal_sscanf((char*)line + cidx * 2, "%02x", &tmp_val))
            {
                if((lidx * 16 + cidx) >= CTC_NPM_MAX_PKTHDR_LEN)
                {
                    ctc_cli_out("%% header_len larger than %d\n", CTC_NPM_MAX_PKTHDR_LEN);
                    sal_fclose(fp);
                    fp = NULL;
                    return CLI_ERROR;
                }
                buf[lidx * 16 + cidx] = tmp_val;
                (*pkt_len) += 1;
            }
            else
            {
                break;
            }
        }

        lidx++;
    }

    sal_fclose(fp);
    fp = NULL;

    return CLI_SUCCESS;
}







CTC_CLI(ctc_cli_npm_set_cfg,
        ctc_cli_npm_set_cfg_cmd,
        "npm cfg session SESSION dest-gport GPORT vlan-id VLAN tx-mode MODE (pkt-num NUM | tx-period PERIOD | )patter-type TYPE \
        (repeat VALUE | ) rate RATE frame-size-mode SIZEMODE {frame-size FRAMESIZE | min-frame-size MIN | \
        emix-size-num EMIXSIZENUM emix-size-idx IDX1 (IDX2 (IDX3 (IDX4 (IDX5 (IDX6 (IDX7 (IDX8 (IDX9 (IDX10 (IDX11 \
        (IDX12 (IDX13 (IDX14 (IDX15 (IDX16 | ) | ) | ) | ) | ) | ) | ) | ) | ) | ) | ) | ) | ) | ) | )} \
        (lbm | tst | slm | 1sl | dmm | 1dm | pkt-file FILE_NAME) {burst-en BURSTCNT ibg IBG | seq-en SEQOFFSET | ts-en \
        TSOFFSET | iloop | timeout TIME | } (lchip LCHIP_ID | )",
        CTC_CLI_NPM_M_STR,
        "Configure",
        "Session",
        "Session_id",
        "Destination Global Port",
        CTC_CLI_GPHYPORT_ID_DESC,
        CTC_CLI_VLAN_DESC,
        CTC_CLI_VLAN_RANGE_DESC,
        "Transmit Mode",
        "MODE:0-TX_MODE_PACKET_NUM, 1-TX_MODE_CONTINUOUS, 2-TX_MODE_PERIOD",
        "Packet Num",
        "NUM Value",
        "Transmit Period",
        "Period Value(unit:s)",
        "Patter Type",
        "TYPE:0-Repeat mode, 1-Random, 2-Increase by byte, 3-Decrease by byte, 4-Increase by word, 5-Decrease by word",
        "Repeat Mode",
        "Rapeat Value",
        "Transmit Rate",
        "Generate Traffic Speed(unit:Kbps)",
        "Frame Size Mode",
        "Packet Size Mode, 0: fix, 1: Increase, 2:Emix",
        "Fame Size",
        "Frame Size Value",
        "Min Frame size",
        "Min Value",
        "Emix Size Num",
        "NUM Value",
        "Emix Size Index",
        "Index Value",
        "Index Value",
        "Index Value",
        "Index Value",
        "Index Value",
        "Index Value",
        "Index Value",
        "Index Value",
        "Index Value",
        "Index Value",
        "Index Value",
        "Index Value",
        "Index Value",
        "Index Value",
        "Index Value",
        "Index Value",
        "LBM PDU",
        "TST PDU",
        "SLM PDU",
        "1SL PDU",
        "DMM PDU",
        "1DM PDU",
        "File store packet header",
        "File name",
        "Burst Enable",
        "Burst COUNT",
        "Inter Burst Gap",
        "Ibg Value",
        "Sequence Enable",
        "Sequence Offset",
        "Timestamp Enable",
        "Timestamp Offset",
        "ILOOP",
        "Timeout",
        "TIME(unit:s)",
        "Local chip",
        CTC_CLI_LCHIP_ID_VALUE)

{
    int32 ret = 0;
    uint8 index = 0;
    uint8 temp = 0;
    uint8 lchip = 0;
    ctc_npm_cfg_t cfg;
    uint8 i = 0;
    static char file[256] = {0};
    uint8 pkt_buf[CTC_NPM_MAX_PKTHDR_LEN] = {0};
    uint16 header_len = 0;
    static uint8 lbm_pkthd[64] =
    {
        0x01, 0x80, 0xC2, 0x00, 0x00, 0x33, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x81, 0x00, 0x00, 0x02,
        0x89, 0x02, 0x60, 0x03, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00, 0x03, 0x00, 0x1e, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    };
    static uint8 tst_pkthd[64] =
    {
        0x01, 0x80, 0xC2, 0x00, 0x00, 0x33, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x81, 0x00, 0x00, 0x02,
        0x89, 0x02, 0x60, 0x25, 0x00, 0x04, 0x00, 0x00, 0x00, 0x00, 0x20, 0x00, 0x1e, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    };

    static uint8 slm_pkthd[64] =
    {
        0x01, 0x80, 0xC2, 0x00, 0x00, 0x33, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x81, 0x00, 0x00, 0x02,
        0x89, 0x02, 0x60, 0x37, 0x00, 0x10, 0x00, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    };

    static uint8 onesl_pkthd[64] =
    {
        0x01, 0x80, 0xC2, 0x00, 0x00, 0x33, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x81, 0x00, 0x00, 0x02,
        0x89, 0x02, 0x60, 0x35, 0x00, 0x10, 0x00, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    };


    static uint8 dmm_pkthd[64] =
    {
        0x01, 0x80, 0xC2, 0x00, 0x00, 0x33, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x81, 0x00, 0x00, 0x02,
        0x89, 0x02, 0x61, 0x2d, 0x00, 0x10, 0x00, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    };


    static uint8 onedm_pkthd[64] =
    {
        0x01, 0x80, 0xC2, 0x00, 0x00, 0x33, 0x00, 0x00, 0x00, 0x00, 0x00, 0x03, 0x81, 0x00, 0x00, 0x02,
        0x89, 0x02, 0x61, 0x2f, 0x00, 0x20, 0x00, 0x11, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    };


    sal_memset(&cfg, 0, sizeof(ctc_npm_cfg_t));


    CTC_CLI_GET_UINT8_RANGE("session id", cfg.session_id, argv[0], 0, CTC_MAX_UINT8_VALUE);
    CTC_CLI_GET_UINT32_RANGE("dest gport", cfg.dest_gport, argv[1], 0, CTC_MAX_UINT32_VALUE);
    CTC_CLI_GET_UINT16_RANGE("VLAN id", cfg.vlan_id, argv[2], 0, CTC_MAX_UINT16_VALUE);
    CTC_CLI_GET_UINT8_RANGE("tx mode", cfg.tx_mode, argv[3], 0, CTC_MAX_UINT8_VALUE);
    temp = 3;



    index = CTC_CLI_GET_ARGC_INDEX("pkt-num");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT32_RANGE("packet number", cfg.packet_num, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
        temp = index + 1;
    }


    index = CTC_CLI_GET_ARGC_INDEX("tx-period");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT32_RANGE("transmit period", cfg.tx_period, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
        temp = index + 1;
    }

    CTC_CLI_GET_UINT8_RANGE("pattern type", cfg.pkt_format.pattern_type, argv[temp+1], 0, CTC_MAX_UINT8_VALUE);
    temp = temp + 1;



    index = CTC_CLI_GET_ARGC_INDEX("repeat");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT32_RANGE("repeat pattern value", cfg.pkt_format.repeat_pattern, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
        temp = index + 1;
    }


    CTC_CLI_GET_UINT32_RANGE("transmit rate", cfg.rate, argv[temp+1], 0, CTC_MAX_UINT32_VALUE);
    CTC_CLI_GET_UINT8_RANGE("frame size mode", cfg.pkt_format.frame_size_mode, argv[temp+2], 0, CTC_MAX_UINT8_VALUE);


    index = CTC_CLI_GET_ARGC_INDEX("frame-size");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT32_RANGE("frame size", cfg.pkt_format.frame_size, argv[index+1], 0, CTC_MAX_UINT32_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("min-frame-size");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT32_RANGE("min frame size", cfg.pkt_format.min_frame_size, argv[index+1], 0, CTC_MAX_UINT32_VALUE);
    }



    index = CTC_CLI_GET_ARGC_INDEX("emix-size-num");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8_RANGE("emix size number", cfg.pkt_format.emix_size_num, argv[index+1], 0, CTC_MAX_UINT8_VALUE);
        temp = index + 3;
        for (i = 0; i < cfg.pkt_format.emix_size_num; i++)
        {
//TBD-            CTC_CLI_GET_UINT16_RANGE("emix size index", cfg.pkt_format.emix_size_idx[i], argv[temp+i], 0, CTC_MAX_UINT16_VALUE);
        }

    }


    index = CTC_CLI_GET_ARGC_INDEX("lbm");
    if (0xFF != index)
    {
        cfg.pkt_format.pkt_header = (void*)lbm_pkthd;
        cfg.pkt_format.header_len = 29;
    }

    index = CTC_CLI_GET_ARGC_INDEX("tst");
    if (0xFF != index)
    {
        cfg.pkt_format.pkt_header = (void*)tst_pkthd;
        cfg.pkt_format.header_len = 30;
    }

    index = CTC_CLI_GET_ARGC_INDEX("slm");
    if (0xFF != index)
    {
        cfg.pkt_format.pkt_header = (void*)slm_pkthd;
        cfg.pkt_format.header_len = 39;
    }

    index = CTC_CLI_GET_ARGC_INDEX("1sl");
    if (0xFF != index)
    {
        cfg.pkt_format.pkt_header = (void*)onesl_pkthd;
        cfg.pkt_format.header_len = 39;
    }

    index = CTC_CLI_GET_ARGC_INDEX("dmm");
    if (0xFF != index)
    {
        cfg.pkt_format.pkt_header = (void*)dmm_pkthd;
        cfg.pkt_format.header_len = 39;
    }

    index = CTC_CLI_GET_ARGC_INDEX("1dm");
    if (0xFF != index)
    {
        cfg.pkt_format.pkt_header = (void*)onedm_pkthd;
        cfg.pkt_format.header_len = 31;
    }


    sal_memset(pkt_buf, 0, CTC_NPM_MAX_PKTHDR_LEN);

    index = CTC_CLI_GET_ARGC_INDEX("pkt-file");
    if (0xFF != index)
    {
        /* get packet from file */
        sal_strcpy((char*)file, argv[index + 1]);
        /* get packet from file */
        ret = _npm_cli_pkthdr_get_from_file(file, pkt_buf, &header_len);

        if (CLI_ERROR == ret)
        {
            return CLI_ERROR;
        }

        cfg.pkt_format.pkt_header = (void*)pkt_buf;
        cfg.pkt_format.header_len = header_len;
    }

    index = CTC_CLI_GET_ARGC_INDEX("burst-en");
    if (0xFF != index)
    {

        cfg.flag |= CTC_NPM_CFG_FLAG_BURST_EN;
        CTC_CLI_GET_UINT32_RANGE("burst count", cfg.burst_cnt, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
        CTC_CLI_GET_UINT32_RANGE("inter burst gap", cfg.ibg, argv[index + 3], 0, CTC_MAX_UINT32_VALUE);
    }


    index = CTC_CLI_GET_ARGC_INDEX("seq-en");
    if (0xFF != index)
    {
        cfg.flag |= CTC_NPM_CFG_FLAG_SEQ_EN;
        CTC_CLI_GET_UINT8_RANGE("sequence offset", cfg.pkt_format.seq_num_offset, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("ts-en");
    if (0xFF != index)
    {
        cfg.flag |= CTC_NPM_CFG_FLAG_TS_EN;
        CTC_CLI_GET_UINT16_RANGE("timestamp offset", cfg.pkt_format.ts_offset, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("iloop");
    if (0xFF != index)
    {
        cfg.flag |= CTC_NPM_CFG_FLAG_ILOOP;
    }

    index = CTC_CLI_GET_ARGC_INDEX("timeout");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8_RANGE("timeout", cfg.timeout, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
    }

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (index != 0xFF)
    {
        if (index + 1 >= argc)
        {
            ctc_cli_out("%% Insufficient  param \n\r");
            return CLI_ERROR;
        }

        CTC_CLI_GET_UINT8_RANGE("lchip", lchip, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);

    }

    if(g_ctcs_api_en)
    {
        ret = ctcs_npm_set_config(g_api_lchip, &cfg);
    }
    else
    {
        ret = ctc_npm_set_config(lchip, &cfg);
    }
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}





int32
ctc_npm_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_npm_set_session_transmit_en_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_npm_get_session_stats_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_npm_set_global_cfg_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_npm_get_global_cfg_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_npm_set_cfg_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_npm_debug_on_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_npm_debug_off_cmd);
    return CLI_SUCCESS;
}





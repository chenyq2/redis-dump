/**
 @file ctc_wlan_cli.c

 @author  Copyright (C) 2016 Centec Networks Inc.  All rights reserved.

 @date 2016-02-22

 @version v2.0

 The file apply clis of bpe module
*/

#include "sal.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"
#include "ctc_debug.h"
#include "ctc_error.h"
#include "ctc_api.h"
#include "ctcs_api.h"
#include "ctc_wlan.h"
#include "ctc_wlan_cli.h"

#define CTC_CLI_WLAN_DES      "wlan module"

#define CTC_CLI_WLAN_TUNNEL_PARAM_STR \
    "({split-mac|decrypt ID | reassemble-en | ttl-check | acl-use-outer | trust-dscp | tunnel-type (wtp2ac|ac2ac) | default-vlan-id VLAN | \
     logic-port LPORT |policer-id POLICER_ID | service-acl-en|acl-en lookup-type LKP_TYPE priority PRIORITY class-id CLASS_ID| use-flex} | )"

#define CTC_CLI_WLAN_TUNNEL_PARAM_DESC \
        "Add wlan tunnel terminate entry",\
        "Update wlan tunnel terminate entry",\
        "Tunnel mode, default network",\
        "Tunnel mode vlaue",\
        "Destination ip address",\
        "Destination ip address",\
        "Source ip address",\
        "Source ip address",\
        "L4 port",\
        "L4 port value",\
        "Bssid",\
        "Bssid mac value",\
        "Radio id",\
        "Radio id value",\
        "Split mac mode", \
        "Decrypt enable",\
        "Crypt id",\
        "Reassemble enable",\
        "Do ttl check for tunnel outer header",\
        "Use outer header info do acl lookup, default use the inner",\
        "Use outer dscp do qos classification",\
        "Tunnel type",\
        "wtp to ac",\
        "ac to ac",\
        "Default vlan id",\
        "Vlan value",\
        "Logic port",\
        "Logic port vlaue",\
        "Policer Id",\
        "<1-0xFFFF>",\
        "Enable service acl",\
        "Set ACL lookup property",\
        "Acl lookup type",\
        "Acl lookup type value",\
        "Acl priotity",\
        "Acl priority vlaue",\
        "Acl class ID",\
        "Acl class ID Value",\
        "Use flex key"

#define CTC_CLI_WLAN_CRYPT_DESC \
        "Aes key", \
        "Aes key value", \
        "Sha key", \
        "Sha key value", \
        "Seq num", \
        "Seq num value", \
        "Epoch", \
        "Epoch value", \
        "Valid", \
        "Enable", \
        "Disable"

#define CTC_CLI_WLAN_TUNNEL_PARAM_SET()  \
    index = CTC_CLI_GET_ARGC_INDEX("split-mac");                             \
    if (INDEX_VALID(index))                                                   \
    {                                                                           \
       tunnel_param.flag |= CTC_WLAN_TUNNEL_FLAG_SPLIT_MAC;                     \
    }                                                                           \
    index = CTC_CLI_GET_ARGC_INDEX("decrypt");                               \
    if (INDEX_VALID(index))                                                   \
    {                                                                           \
       CTC_CLI_GET_UINT8("decrypt", tunnel_param.decrypt_id, argv[index + 1]); \
       tunnel_param.flag |= CTC_WLAN_TUNNEL_FLAG_DECRYPT_ENABLE;                \
    }                                                                           \
    index = CTC_CLI_GET_ARGC_INDEX("reassemble-en");                         \
    if (INDEX_VALID(index))                                                   \
    {                                                                           \
       tunnel_param.flag |= CTC_WLAN_TUNNEL_FLAG_REASSEMBLE_ENABLE;             \
    }                                                                           \
    index = CTC_CLI_GET_ARGC_INDEX("ttl-check");                             \
    if (0xFF != index)                                                          \
    {                                                                           \
        tunnel_param.flag |= CTC_WLAN_TUNNEL_FLAG_TTL_CHECK;                    \
    }                                                                           \
    index = CTC_CLI_GET_ARGC_INDEX("acl-use-outer");                         \
    if (0xFF != index)                                                          \
    {                                                                           \
        tunnel_param.flag |= CTC_WLAN_TUNNEL_FLAG_ACL_LKUP_BY_OUTER_HEAD;       \
    }                                                                           \
    index = CTC_CLI_GET_ARGC_INDEX("trust-dscp");                            \
    if (0xFF != index)                                                          \
    {                                                                           \
        tunnel_param.flag |= CTC_WLAN_TUNNEL_FLAG_TRUST_DSCP;                   \
    }                                                                           \
    index = CTC_CLI_GET_ARGC_INDEX("tunnel-type");                           \
    if (0xFF != index)                                                          \
    {                                                                           \
        if (CLI_CLI_STR_EQUAL("wtp2ac", (index+1)))                           \
        {                                                                       \
            tunnel_param.type = CTC_WLAN_TUNNEL_TYPE_WTP_2_AC;                  \
        }                                                                       \
        else if (CLI_CLI_STR_EQUAL("ac2ac", (index+1)))                      \
        {                                                                       \
            tunnel_param.type = CTC_WLAN_TUNNEL_TYPE_AC_2_AC;                   \
        }                                                                       \
    }                                                                           \
    index = CTC_CLI_GET_ARGC_INDEX("default-vlan-id");                       \
    if (0xFF != index)                                                          \
    {                                                                           \
        CTC_CLI_GET_UINT16("default-vlan-id", tunnel_param.default_vlan_id, argv[index + 1]);  \
    }                                                                            \
    index = CTC_CLI_GET_ARGC_INDEX("logic-port");                             \
    if (0xFF != index)                                                           \
    {                                                                            \
        CTC_CLI_GET_UINT16("logic-port", tunnel_param.logic_port, argv[index + 1]);  \
    }                                                                             \
    index = CTC_CLI_GET_ARGC_INDEX("policer-id");                               \
    if (INDEX_VALID(index))                                                      \
    {                                                                              \
        CTC_CLI_GET_UINT32("policer-id", tunnel_param.policer_id, argv[index + 1]); \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("service-acl-en");                  \
    if (index != 0xFF)                                                             \
    {                                                                              \
        tunnel_param.flag |= CTC_WLAN_TUNNEL_FLAG_SERVICE_ACL_EN;                  \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("acl-en");                                   \
    if (index != 0xFF)                                                              \
    {                                                                               \
        tunnel_param.flag |= CTC_WLAN_TUNNEL_FLAG_ACL_EN;                           \
        index = CTC_CLI_GET_ARGC_INDEX("lookup-type");                           \
        if (0xFF != index)                                                          \
        {                                                                           \
            CTC_CLI_GET_UINT8("lookup-type", tunnel_param.acl_lookup_type, argv[index + 1]);\
        }                                                                                   \
        index = CTC_CLI_GET_ARGC_INDEX("priority");                                     \
        if (0xFF != index)                                                                  \
        {                                                                                   \
            CTC_CLI_GET_UINT8("priority", tunnel_param.acl_lookup_priority, argv[index + 1]);\
        }                                                                                 \
        index = CTC_CLI_GET_ARGC_INDEX("class-id");                                     \
        if (0xFF != index)                                                                  \
        {                                                                                   \
            CTC_CLI_GET_UINT8("class-id", tunnel_param.acl_class_id, argv[index + 1]);      \
        }                                                                                   \
    }                                                                                       \
    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("use-flex");                                 \
    if (index != 0xFF)                                                                      \
    {                                                                                       \
        tunnel_param.flag |= CTC_WLAN_TUNNEL_FLAG_RESOLVE_HASH_CONFLICT;                    \
    }

#define CTC_CLI_WLAN_CLIENT_PARAM_STR \
    "(sta STA|) (src-vlan-id VLANID|) (sta-roam-status STATUS|) (tunnel-type (wtp2ac|ac2ac)|) (sta-is-local|) (nexthop-id NHID|) \
    ({mulitcast-en | stats STATS_ID | policer-id POLICER_ID | vlan-id VLAN | cid CID | logic-port LPORT| acl-tcam-en lookup-type LKP_TYPE priority PRIORITY class-id CLASS_ID|use-flex} | )"

#define CTC_CLI_WLAN_CLIENT_PARAM_DESC \
        "Add wlan tunnel terminate entry",\
        "Update wlan tunnel terminate entry",\
        "Client type, default no-roam",\
        "Client type vlaue",\
        "Sta",\
        "Sta mac value",\
        "Src vlan id",\
        "Vlan id value",\
        "Sta roam status",\
        "0:no roam,1:roam in,2:roam out",\
        "tunnel type",\
        "wtp to ac",\
        "ac to ac",\
        "Sta is local, hub/spoke or full mesh roam",\
        "Nexthop id",\
        "Nexthop id",\
        "Mulitcast enable",\
        "Stats",\
        "Stats id",\
        "Policer enable",\
        "Policer id",\
        "Vlan, for sta classify",\
        "Vlan value",\
        "Cid",\
        "Cid value",\
        "Logic port",\
        "Logic port vlaue",\
        "Set ACL lookup property",\
        "Acl lookup type",\
        "Acl lookup type value",\
        "Acl priotity",\
        "Acl priority vlaue",\
        "Acl class ID",\
        "Acl class ID Value",\
        "Use flex key"

#define CTC_CLI_WLAN_CLIENT_PARAM_SET()                                     \
    index = CTC_CLI_GET_ARGC_INDEX("sta");                                   \
    if (INDEX_VALID(index))                                                   \
    {                                                                           \
        CTC_CLI_GET_MAC_ADDRESS("sta", client_param.sta, argv[index+1]);     \
    }                                                                           \
    index = CTC_CLI_GET_ARGC_INDEX("src-vlan-id");                           \
    if (INDEX_VALID(index))                                                   \
    {                                                                           \
        CTC_CLI_GET_UINT8("src vlan id", client_param.src_vlan_id, argv[index+1]); \
    }                                                                           \
    index = CTC_CLI_GET_ARGC_INDEX("sta-roam-status");                       \
    if (0xFF != index)                                                          \
    {                                                                           \
        CTC_CLI_GET_UINT8("sta roam status", client_param.roam_status, argv[index+1]); \
    }                                                                           \
    index = CTC_CLI_GET_ARGC_INDEX("tunnel-type");                           \
    if (0xFF != index)                                                          \
    {                                                                           \
        if (CLI_CLI_STR_EQUAL("wtp2ac", (index+1)))                           \
        {                                                                       \
            client_param.tunnel_type = CTC_WLAN_TUNNEL_TYPE_WTP_2_AC;           \
        }                                                                       \
        else if (CLI_CLI_STR_EQUAL("ac2ac", (index+1)))                      \
        {                                                                       \
            client_param.tunnel_type = CTC_WLAN_TUNNEL_TYPE_AC_2_AC;            \
        }                                                                       \
    }                                                                           \
    index = CTC_CLI_GET_ARGC_INDEX("sta-is-local");                          \
    if (0xFF != index)                                                          \
    {                                                                           \
        client_param.is_local = 1;                                              \
    }                                                                           \
    index = CTC_CLI_GET_ARGC_INDEX("nexthop-id");                            \
    if (0xFF != index)                                                          \
    {                                                                           \
        CTC_CLI_GET_UINT8("nexthop-id", client_param.nh_id, argv[index+1]);   \
        client_param.flag |= CTC_WLAN_CLIENT_FLAG_NH;                           \
    }                                                                           \
    index = CTC_CLI_GET_ARGC_INDEX("mulitcast-en");                          \
    if (0xFF != index)                                                          \
    {                                                                           \
        client_param.flag |= CTC_WLAN_CLIENT_FLAG_MC_EN;                        \
    }                                                                           \
    index = CTC_CLI_GET_ARGC_INDEX("stats");                                 \
    if (0xFF != index)                                                          \
    {                                                                           \
        CTC_CLI_GET_UINT16("stats", client_param.stats_id, argv[index + 1]);  \
        client_param.flag |= CTC_WLAN_CLIENT_FLAG_STATS_EN;                     \
    }                                                                           \
    index = CTC_CLI_GET_ARGC_INDEX("policer-id");                            \
    if (0xFF != index)                                                          \
    {                                                                           \
        CTC_CLI_GET_UINT16("policer-id", client_param.policer_id, argv[index + 1]); \
    }                                                                            \
    index = CTC_CLI_GET_ARGC_INDEX("vlan-id");                                \
    if (0xFF != index)                                                           \
    {                                                                            \
        CTC_CLI_GET_UINT16("vlan-id", client_param.vlan_id, argv[index + 1]);  \
        client_param.flag |= CTC_WLAN_CLIENT_FLAG_MAPPING_VLAN;                  \
    }                                                                            \
    index = CTC_CLI_GET_ARGC_INDEX("cid");                                    \
    if (0xFF != index)                                                           \
    {                                                                            \
        CTC_CLI_GET_UINT16("cid", client_param.cid, argv[index + 1]);          \
    }                                                                            \
    index = CTC_CLI_GET_ARGC_INDEX("logic-port");                             \
    if (0xFF != index)                                                           \
    {                                                                            \
        CTC_CLI_GET_UINT16("logic-port", client_param.logic_port, argv[index + 1]);  \
    }                                                                             \
    index = CTC_CLI_GET_ARGC_INDEX("acl-tcam-en");                                   \
    if (index != 0xFF)                                                              \
    {                                                                               \
        client_param.flag |= CTC_WLAN_CLIENT_FLAG_ACL_EN;                           \
        index = CTC_CLI_GET_ARGC_INDEX("lookup-type");                           \
        if (0xFF != index)                                                          \
        {                                                                           \
            CTC_CLI_GET_UINT8("lookup-type", client_param.acl.acl_tcam_lkup_type, argv[index + 1]);\
        }                                                                                   \
        index = CTC_CLI_GET_ARGC_INDEX("priority");                                     \
        if (0xFF != index)                                                                  \
        {                                                                                   \
            CTC_CLI_GET_UINT8("priority", client_param.acl.acl_tcam_lkup_priority, argv[index + 1]);\
        }                                                                                 \
        index = CTC_CLI_GET_ARGC_INDEX("class-id");                                     \
        if (0xFF != index)                                                                  \
        {                                                                                   \
            CTC_CLI_GET_UINT8("class-id", client_param.acl.acl_tcam_lkup_class_id, argv[index + 1]);      \
        }                                                                                   \
    }                                                                                       \
    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("use-flex");                       \
    if (index != 0xFF)                                                            \
    {                                                                             \
        client_param.flag |= CTC_WLAN_CLIENT_FLAG_RESOLVE_HASH_CONFLICT;          \
    }

CTC_CLI(ctc_cli_wlan_tunnel_add,
        ctc_cli_wlan_tunnel_add_cmd,
        "wlan tunnel (add|update) (mode MODE|) ipsa A.B.C.D ipda A.B.C.D l4-port L4PORT (bssid BSSID|) (radio-id RID|) \
        "CTC_CLI_WLAN_TUNNEL_PARAM_STR,
        CTC_CLI_WLAN_DES,
        "Tunnel",
        CTC_CLI_WLAN_TUNNEL_PARAM_DESC)
{
    ctc_wlan_tunnel_t tunnel_param;
    uint32 index = 0xFF;
    int32 ret = CLI_ERROR;
    uint8 is_update = 0;

    sal_memset(&tunnel_param, 0 ,sizeof(tunnel_param));

    tunnel_param.mode = CTC_WLAN_TUNNEL_MODE_NETWORK;
    tunnel_param.type = CTC_WLAN_TUNNEL_TYPE_WTP_2_AC;

    index = CTC_CLI_GET_ARGC_INDEX("update");
    if (0xFF != index)
    {
        is_update = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("mode");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("mode", tunnel_param.mode, argv[index + 1]);
        index = 3;
    }
    else
    {
        index = 1;
    }

    CTC_CLI_GET_IPV4_ADDRESS("ipsa", tunnel_param.ipsa.ipv4, argv[index]);
    CTC_CLI_GET_IPV4_ADDRESS("ipda", tunnel_param.ipda.ipv4, argv[index+1]);
    CTC_CLI_GET_UINT16("l4-port", tunnel_param.l4_port, argv[index + 2]);

    index = CTC_CLI_GET_ARGC_INDEX("bssid");
    if (index != 0xFF)
    {
        CTC_CLI_GET_MAC_ADDRESS("bssid", tunnel_param.bssid, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("radio-id");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("radio-id", tunnel_param.radio_id, argv[index + 1]);
    }
    CTC_CLI_WLAN_TUNNEL_PARAM_SET()

    if (is_update)
    {
        if(g_ctcs_api_en)
        {
             ret = ctcs_wlan_update_tunnel(g_api_lchip, &tunnel_param);
        }
        else
        {
            ret = ctc_wlan_update_tunnel(&tunnel_param);
        }
    }
    else
    {
        if(g_ctcs_api_en)
        {
             ret = ctcs_wlan_add_tunnel(g_api_lchip, &tunnel_param);
        }
        else
        {
            ret = ctc_wlan_add_tunnel(&tunnel_param);
        }
    }

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_wlan_tunnel_add_v6,
        ctc_cli_wlan_tunnel_add_v6_cmd,
        "wlan tunnel ipv6 (add|update) (mode MODE|) ipsa X:X::X:X ipda X:X::X:X  l4-port L4PORT (bssid BSSID|) (radio-id RID|) \
        "CTC_CLI_WLAN_TUNNEL_PARAM_STR,
        CTC_CLI_WLAN_DES,
        "Tunnel",
        "Ipv6",
        CTC_CLI_WLAN_TUNNEL_PARAM_DESC)
{
    ctc_wlan_tunnel_t tunnel_param;
    ipv6_addr_t ipv6_address;
    uint32 index = 0xFF;
    int32 ret = CLI_ERROR;
    uint8 is_update = 0;

    sal_memset(&tunnel_param, 0 ,sizeof(tunnel_param));

    tunnel_param.mode = CTC_WLAN_TUNNEL_MODE_NETWORK;
    tunnel_param.type = CTC_WLAN_TUNNEL_TYPE_WTP_2_AC;
    tunnel_param.flag |= CTC_WLAN_TUNNEL_FLAG_IPV6;

    index = CTC_CLI_GET_ARGC_INDEX("update");
    if (0xFF != index)
    {
        is_update = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("mode");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("mode", tunnel_param.mode, argv[index + 1]);
        index = 3;
    }
    else
    {
        index = 1;
    }

    CTC_CLI_GET_IPV6_ADDRESS("ipsa", ipv6_address, argv[index]);
    /* adjust endian */
    tunnel_param.ipsa.ipv6[0] = sal_htonl(ipv6_address[0]);
    tunnel_param.ipsa.ipv6[1] = sal_htonl(ipv6_address[1]);
    tunnel_param.ipsa.ipv6[2] = sal_htonl(ipv6_address[2]);
    tunnel_param.ipsa.ipv6[3] = sal_htonl(ipv6_address[3]);
    CTC_CLI_GET_IPV6_ADDRESS("ipda", ipv6_address, argv[index + 1]);
    /* adjust endian */
    tunnel_param.ipda.ipv6[0] = sal_htonl(ipv6_address[0]);
    tunnel_param.ipda.ipv6[1] = sal_htonl(ipv6_address[1]);
    tunnel_param.ipda.ipv6[2] = sal_htonl(ipv6_address[2]);
    tunnel_param.ipda.ipv6[3] = sal_htonl(ipv6_address[3]);
    CTC_CLI_GET_UINT16("l4-port", tunnel_param.l4_port, argv[index + 2]);

    index = CTC_CLI_GET_ARGC_INDEX("bssid");
    if (index != 0xFF)
    {
        CTC_CLI_GET_MAC_ADDRESS("bssid", tunnel_param.bssid, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("radio-id");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("radio-id", tunnel_param.radio_id, argv[index + 1]);
    }
    CTC_CLI_WLAN_TUNNEL_PARAM_SET()

    if (is_update)
    {
        if(g_ctcs_api_en)
        {
             ret = ctcs_wlan_update_tunnel(g_api_lchip, &tunnel_param);
        }
        else
        {
            ret = ctc_wlan_update_tunnel(&tunnel_param);
        }
    }
    else
    {
        if(g_ctcs_api_en)
        {
             ret = ctcs_wlan_add_tunnel(g_api_lchip, &tunnel_param);
        }
        else
        {
            ret = ctc_wlan_add_tunnel(&tunnel_param);
        }
    }

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_wlan_tunnel_remove,
        ctc_cli_wlan_tunnel_remove_cmd,
        "wlan tunnel remove (mode MODE|) ipsa A.B.C.D ipda A.B.C.D l4-port L4PORT (bssid BSSID|) (radio-id RID|) (use-flex |)",
        CTC_CLI_WLAN_DES,
        "Tunnel"
        "Remove wlan tunnel terminate entry",
        "Tunnel mode, default network",
        "Tunnel mode vlaue",
        "Destination ip address",
        CTC_CLI_IPV4_FORMAT,
        "Source ip address",
        CTC_CLI_IPV4_FORMAT,
        "L4 port",
        "L4 port value",
        "Bssid",
        "Bssid mac value",
        "Radio id",
        "Radio id value",
        "Use flex key")
{
    ctc_wlan_tunnel_t tunnel_param;
    uint32 index = 0xFF;
    int32 ret = CLI_ERROR;

    sal_memset(&tunnel_param, 0 ,sizeof(tunnel_param));

    tunnel_param.mode = CTC_WLAN_TUNNEL_MODE_NETWORK;

    index = CTC_CLI_GET_ARGC_INDEX("mode");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("mode", tunnel_param.mode, argv[index + 1]);
        index = 2;
    }
    else
    {
        index = 0;
    }

    CTC_CLI_GET_IPV4_ADDRESS("ipsa", tunnel_param.ipsa.ipv4, argv[index]);
    CTC_CLI_GET_IPV4_ADDRESS("ipda", tunnel_param.ipda.ipv4, argv[index + 1]);
    CTC_CLI_GET_UINT16("l4-port", tunnel_param.l4_port, argv[index + 2]);

    index = CTC_CLI_GET_ARGC_INDEX("bssid");
    if (index != 0xFF)
    {
        CTC_CLI_GET_MAC_ADDRESS("bssid", tunnel_param.bssid, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("radio-id");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("radio-id", tunnel_param.radio_id, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("use-flex");
    if (index != 0xFF)
    {
        tunnel_param.flag |= CTC_WLAN_TUNNEL_FLAG_RESOLVE_HASH_CONFLICT;
    }

    if(g_ctcs_api_en)
    {
        ret = ctcs_wlan_remove_tunnel(g_api_lchip, &tunnel_param);
    }
    else
    {
        ret = ctc_wlan_remove_tunnel(&tunnel_param);
    }

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_wlan_tunnel_remove_v6,
        ctc_cli_wlan_tunnel_remove_v6_cmd,
        "wlan tunnel ipv6 remove (mode MODE|) ipsa X:X::X:X ipda X:X::X:X  l4-port L4PORT (bssid BSSID|) (radio-id RID|) (use-flex |)",
        CTC_CLI_WLAN_DES,
        "Tunnel"
        CTC_CLI_IPV6_STR,
        "Remove wlan tunnel terminate entry",
        "Tunnel mode, default network",
        "Tunnel mode vlaue",
        "Destination ip address",
        CTC_CLI_IPV6_FORMAT,
        "Source ip address",
        CTC_CLI_IPV6_FORMAT,
        "L4 port",
        "L4 port value",
        "Bssid",
        "Bssid mac value",
        "Radio id",
        "Radio id value",
        "Use flex key")
{
    ctc_wlan_tunnel_t tunnel_param;
    ipv6_addr_t ipv6_address;
    uint32 index = 0xFF;
    int32 ret = CLI_ERROR;

    sal_memset(&tunnel_param, 0 ,sizeof(tunnel_param));

    tunnel_param.mode = CTC_WLAN_TUNNEL_MODE_NETWORK;
    tunnel_param.flag |= CTC_WLAN_TUNNEL_FLAG_IPV6;

    index = CTC_CLI_GET_ARGC_INDEX("mode");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("mode", tunnel_param.mode, argv[index + 1]);
        index = 3;
    }
    else
    {
        index = 0;
    }

    CTC_CLI_GET_IPV6_ADDRESS("ipsa", ipv6_address, argv[index]);
    /* adjust endian */
    tunnel_param.ipsa.ipv6[0] = sal_htonl(ipv6_address[0]);
    tunnel_param.ipsa.ipv6[1] = sal_htonl(ipv6_address[1]);
    tunnel_param.ipsa.ipv6[2] = sal_htonl(ipv6_address[2]);
    tunnel_param.ipsa.ipv6[3] = sal_htonl(ipv6_address[3]);
    CTC_CLI_GET_IPV6_ADDRESS("ipda", ipv6_address, argv[index + 1]);
    /* adjust endian */
    tunnel_param.ipda.ipv6[0] = sal_htonl(ipv6_address[0]);
    tunnel_param.ipda.ipv6[1] = sal_htonl(ipv6_address[1]);
    tunnel_param.ipda.ipv6[2] = sal_htonl(ipv6_address[2]);
    tunnel_param.ipda.ipv6[3] = sal_htonl(ipv6_address[3]);
    CTC_CLI_GET_UINT16("l4-port", tunnel_param.l4_port, argv[index + 2]);

    index = CTC_CLI_GET_ARGC_INDEX("bssid");
    if (index != 0xFF)
    {
        CTC_CLI_GET_MAC_ADDRESS("bssid", tunnel_param.bssid, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("radio-id");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("radio-id", tunnel_param.radio_id, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("use-flex");
    if (index != 0xFF)
    {
        tunnel_param.flag |= CTC_WLAN_TUNNEL_FLAG_RESOLVE_HASH_CONFLICT;
    }

    if(g_ctcs_api_en)
    {
        ret = ctcs_wlan_remove_tunnel(g_api_lchip, &tunnel_param);
    }
    else
    {
        ret = ctc_wlan_remove_tunnel(&tunnel_param);
    }

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_wlan_client_add,
        ctc_cli_wlan_client_add_cmd,
        "wlan client (add|update) (type TYPE|) \
        "CTC_CLI_WLAN_CLIENT_PARAM_STR,
        CTC_CLI_WLAN_DES,
        "Client",
        CTC_CLI_WLAN_CLIENT_PARAM_DESC)
{
    ctc_wlan_client_t client_param;
    uint32 index = 0xFF;
    int32 ret = CLI_ERROR;
    uint8 is_update = 0;

    sal_memset(&client_param, 0 ,sizeof(client_param));

    client_param.type = CTC_WLAN_CLIENT_TYPE_NO_ROAM;

    index = CTC_CLI_GET_ARGC_INDEX("update");
    if (0xFF != index)
    {
        is_update = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("type");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("type", client_param.type, argv[index + 1]);
    }
    CTC_CLI_WLAN_CLIENT_PARAM_SET()

    if (is_update)
    {
        if(g_ctcs_api_en)
        {
             ret = ctcs_wlan_update_client(g_api_lchip, &client_param);
        }
        else
        {
            ret = ctc_wlan_update_client(&client_param);
        }
    }
    else
    {
        if(g_ctcs_api_en)
        {
             ret = ctcs_wlan_add_client(g_api_lchip, &client_param);
        }
        else
        {
            ret = ctc_wlan_add_client(&client_param);
        }
    }

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_wlan_client_remove,
        ctc_cli_wlan_client_remove_cmd,
        "wlan client remove (type TYPE|) (sta STA|) (src-vlan-id VLANID|) (sta-roam-status STATUS|) (tunnel-type (wtp2ac|ac2ac)|) ({mulitcast-en|use-flex} |)",
        CTC_CLI_WLAN_DES,
        "Client"
        "Remove wlan tunnel terminate entry",
        "Client type, default no-roam",
        "Client type vlaue",
        "Sta",
        "Sta mac value",
        "Src vlan id",
        "Vlan id value",
        "Sta roam status",
        "0:no roam,1:roam in,2:roam out",
        "tunnel type",
        "wtp to ac",
        "ac to ac",
        "Mulitcast enable",
        "Use flex key")
{
    ctc_wlan_client_t client_param;
    uint32 index = 0xFF;
    int32 ret = CLI_ERROR;

    sal_memset(&client_param, 0 ,sizeof(client_param));

    client_param.type = CTC_WLAN_CLIENT_TYPE_NO_ROAM;

    index = CTC_CLI_GET_ARGC_INDEX("type");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("type", client_param.type, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("sta");
    if (INDEX_VALID(index))
    {
        CTC_CLI_GET_MAC_ADDRESS("sta", client_param.sta, argv[index+1]);
    }
    index = CTC_CLI_GET_ARGC_INDEX("src-vlan-id");
    if (INDEX_VALID(index))
    {
        CTC_CLI_GET_UINT8("src vlan id", client_param.src_vlan_id, argv[index+1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("sta-roam-status");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("sta roam status", client_param.roam_status, argv[index+1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("tunnel-type");
    if (0xFF != index)
    {
        if (CLI_CLI_STR_EQUAL("wtp2ac", (index+1)))
        {
            client_param.tunnel_type = CTC_WLAN_TUNNEL_TYPE_WTP_2_AC;
        }
        else if (CLI_CLI_STR_EQUAL("ac2ac", (index+1)))
        {
            client_param.tunnel_type = CTC_WLAN_TUNNEL_TYPE_AC_2_AC;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("mulitcast-en");
    if (0xFF != index)
    {
        client_param.flag |= CTC_WLAN_CLIENT_FLAG_MC_EN;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("use-flex");
    if (index != 0xFF)
    {
        client_param.flag |= CTC_WLAN_CLIENT_FLAG_RESOLVE_HASH_CONFLICT;
    }

    if(g_ctcs_api_en)
    {
        ret = ctcs_wlan_remove_client(g_api_lchip, &client_param);
    }
    else
    {
        ret = ctc_wlan_remove_client(&client_param);
    }

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_wlan_crypt_set,
        ctc_cli_wlan_crypt_set_cmd,
        "wlan crypt ID (type (encrypt|decrypt)|) (aes-key0 AES_KEY0 sha-key0 SHA_KEY0 seq-num0 SEQ_NUM0 epoch0 EPOCH0 (valid0 (enable|disable)|)|)\
        ((aes-key1 AES_KEY1 sha-key1 SHA_KEY1 seq_num1 SEQ_NUM1 epoch1 EPOCH1 (valid1 (enable|disable)|) |) |)",
        CTC_CLI_WLAN_DES,
        "Crypt",
        "Crypt id",
        "Crypt type",
        "Encrypt",
        "Decrypt",
        CTC_CLI_WLAN_CRYPT_DESC,
        CTC_CLI_WLAN_CRYPT_DESC)
{
    ctc_wlan_crypt_t crypt_param;
    uint32 index = 0xFF;
    int32 ret = CLI_ERROR;

    sal_memset(&crypt_param, 0, sizeof(crypt_param));

    crypt_param.type = CTC_WLAN_CRYPT_TYPE_ENCRYPT;

    CTC_CLI_GET_UINT8("crypt", crypt_param.crypt_id, argv[0]);

    index = CTC_CLI_GET_ARGC_INDEX("type");
    if (0xFF != index)
    {
        if (CLI_CLI_STR_EQUAL("encrypt", (index+1)))
        {
            crypt_param.type = 0;
        }
        else if (CLI_CLI_STR_EQUAL("decrypt", (index+1)))
        {
            crypt_param.type = 1;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("aes-key0");
    if (0xFF != index)
    {
        if ( sal_strlen(argv[index+1]) <= WLAN_AES_KEY_LENGTH)
        {
            sal_memcpy((uint8*)&crypt_param.key[0].aes_key, argv[index+1], sal_strlen(argv[index+1]));
        }
        else
        {
            ctc_cli_out("%% %s \n\r", ctc_get_error_desc(CTC_E_INVALID_PARAM));
            return CLI_ERROR;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("sha-key0");
    if (0xFF != index)
    {
        if ( sal_strlen(argv[index+1]) <= WLAN_SHA_KEY_LENGTH)
        {
            sal_memcpy((uint8*)&crypt_param.key[0].sha_key, argv[index+1],  sal_strlen(argv[index+1]));
        }
        else
        {
            ctc_cli_out("%% %s \n\r", ctc_get_error_desc(CTC_E_INVALID_PARAM));
            return CLI_ERROR;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("seq-num0");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT64("seq-num0", crypt_param.key[0].seq_num, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("epoch0");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16("epoch0", crypt_param.key[0].epoch, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("valid0");
    if (0xFF != index)
    {
        if (CLI_CLI_STR_EQUAL("enable", (index+1)))
        {
            crypt_param.key[0].valid = 1;
        }
        else if (CLI_CLI_STR_EQUAL("disable", (index+1)))
        {
            crypt_param.key[0].valid = 0;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("aes-key1");
    if (0xFF != index)
    {
        if ( sal_strlen(argv[index+1]) <= WLAN_AES_KEY_LENGTH)
        {
            sal_memcpy((uint8*)&crypt_param.key[1].aes_key, argv[index+1],  sal_strlen(argv[index+1]));
        }
        else
        {
            ctc_cli_out("%% %s \n\r", ctc_get_error_desc(CTC_E_INVALID_PARAM));
            return CLI_ERROR;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("sha-key1");
    if (0xFF != index)
    {
        if ( sal_strlen(argv[index+1]) <= WLAN_SHA_KEY_LENGTH)
        {
            sal_memcpy((uint8*)&crypt_param.key[1].sha_key, argv[index+1],  sal_strlen(argv[index+1]));
        }
        else
        {
            ctc_cli_out("%% %s \n\r", ctc_get_error_desc(CTC_E_INVALID_PARAM));
            return CLI_ERROR;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("seq-num1");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT64("seq-num1", crypt_param.key[1].seq_num, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("epoch1");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT16("epoch1", crypt_param.key[1].epoch, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("valid1");
    if (0xFF != index)
    {
        if (CLI_CLI_STR_EQUAL("enable", (index+1)))
        {
            crypt_param.key[1].valid = 1;
        }
        else if (CLI_CLI_STR_EQUAL("disable", (index+1)))
        {
            crypt_param.key[1].valid = 0;
        }
    }

    if(g_ctcs_api_en)
    {
         ret = ctcs_wlan_set_crypt(g_api_lchip, &crypt_param);
    }
    else
    {
        ret = ctc_wlan_set_crypt(&crypt_param);
    }

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_wlan_crypt_show,
        ctc_cli_wlan_crypt_show_cmd,
        "show wlan crypt ID (type (encrypt|decrypt)|)",
        "Show",
        CTC_CLI_WLAN_DES,
        "Crypt",
        "Crypt id",
        "Crypt type",
        "Encrypt",
        "Decrypt")
{
    ctc_wlan_crypt_t crypt_param;
    uint32 index = 0xFF;
    int32 ret = CLI_ERROR;
    uint8 temp_aes_key[WLAN_AES_KEY_LENGTH+1];
    uint8 temp_sha_key[WLAN_SHA_KEY_LENGTH+1];

    sal_memset(&crypt_param, 0, sizeof(crypt_param));
    sal_memset(temp_aes_key, 0, WLAN_AES_KEY_LENGTH+1);
    sal_memset(temp_sha_key, 0, WLAN_SHA_KEY_LENGTH+1);

    crypt_param.type = CTC_WLAN_CRYPT_TYPE_ENCRYPT;

    CTC_CLI_GET_UINT8("crypt", crypt_param.crypt_id, argv[0]);

    index = CTC_CLI_GET_ARGC_INDEX("type");
    if (0xFF != index)
    {
        if (CLI_CLI_STR_EQUAL("encrypt", (index+1)))
        {
            crypt_param.type = 0;
        }
        else if (CLI_CLI_STR_EQUAL("decrypt", (index+1)))
        {
            crypt_param.type = 1;
        }
    }

    if(g_ctcs_api_en)
    {
         ret = ctcs_wlan_get_crypt(g_api_lchip, &crypt_param);
    }
    else
    {
        ret = ctc_wlan_get_crypt(&crypt_param);
    }

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    else
    {
        ctc_cli_out("wlan crypt %d type %s:\n\r", crypt_param.crypt_id, crypt_param.type?"decrypt":"encrypt");
        if (CTC_WLAN_CRYPT_TYPE_ENCRYPT == crypt_param.type)
        {
            sal_memcpy(temp_aes_key, crypt_param.key[0].aes_key, WLAN_AES_KEY_LENGTH);
            ctc_cli_out("%-45s:  %s\n", "aes-key", temp_aes_key);
            sal_memcpy(temp_sha_key, crypt_param.key[0].sha_key, WLAN_SHA_KEY_LENGTH);
            ctc_cli_out("%-45s:  %s\n", "sha-key", temp_sha_key);
            ctc_cli_out("%-45s:  %llu\n", "seq-num", crypt_param.key[0].seq_num);
            ctc_cli_out("%-45s:  %d\n", "epoch", crypt_param.key[0].epoch);
        }
        else
        {
            sal_memcpy(temp_aes_key, crypt_param.key[0].aes_key, WLAN_AES_KEY_LENGTH);
            ctc_cli_out("%-45s:  %s\n", "aes-key0", temp_aes_key);
            sal_memcpy(temp_sha_key, crypt_param.key[0].sha_key, WLAN_SHA_KEY_LENGTH);
            ctc_cli_out("%-45s:  %s\n", "sha-key0", temp_sha_key);
            ctc_cli_out("%-45s:  %llu\n", "seq-num0", crypt_param.key[0].seq_num);
            ctc_cli_out("%-45s:  %d\n", "epoch0", crypt_param.key[0].epoch);
            ctc_cli_out("%-45s:  %u\n", "valid0", crypt_param.key[0].valid);
            sal_memcpy(temp_aes_key, crypt_param.key[1].aes_key, WLAN_AES_KEY_LENGTH);
            ctc_cli_out("%-45s:  %s\n", "aes-key1", temp_aes_key);
            sal_memcpy(temp_sha_key, crypt_param.key[1].sha_key, WLAN_SHA_KEY_LENGTH);
            ctc_cli_out("%-45s:  %s\n", "sha-key1", temp_sha_key);
            ctc_cli_out("%-45s:  %llu\n", "seq-num1", crypt_param.key[1].seq_num);
            ctc_cli_out("%-45s:  %d\n", "epoch1", crypt_param.key[1].epoch);
            ctc_cli_out("%-45s:  %u\n", "valid1", crypt_param.key[1].valid);
        }
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_wlan_global_config_set,
        ctc_cli_wlan_global_config_set_cmd,
        "wlan global ({ctl-pkt-decrypt-en VALUE|roam-en VALUE (roam-type VALUE|) | wds-en VALUE |dtls-version VALUE|fc-swap-en VALUE|l4-port0 VALUE0|l4-port1 VALUE1|default-client-action VALUE (mapping-vlan VLANID|)}|)",
        CTC_CLI_WLAN_DES,
        "Global",
        "Control packet decrypt",
        "0:disable,1:enable",
        "Roam enable",
        "0:disable, 1:enbale",
        "Roam type",
        "0:pop/poa,1:hub/spoke",
        "Wds enable",
        "0:disable, 1:enable",
        "Dtls version",
        "Version value",
        "Frame control swap enable",
        "0:disable, 1:enable",
        "L4 dest port 0",
        "Port 0 value",
        "L4 dest port 1",
        "Port 1 value",
        "Default client action",
        "0:discard, 1:mapping vlan",
        "Mapping Vlan",
        "Vlan ID")
{
    ctc_wlan_global_cfg_t glb_param;
    uint32 index = 0xFF;
    int32 ret = CLI_ERROR;

    sal_memset(&glb_param, 0, sizeof(ctc_wlan_global_cfg_t));

    if(g_ctcs_api_en)
    {
        ret = ctcs_wlan_get_global_cfg(g_api_lchip, &glb_param);
    }
    else
    {
        ret = ctc_wlan_get_global_cfg(&glb_param);
    }

    index = CTC_CLI_GET_ARGC_INDEX("ctl-pkt-decrypt-en");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("ctl pkt decrypt en", glb_param.control_pkt_decrypt_en, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("roam-en");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("roam en", glb_param.roam_enable, argv[index + 1]);
        index = CTC_CLI_GET_ARGC_INDEX("roam-type");
        if (0xFF != index)
        {
            CTC_CLI_GET_UINT8("roam type", glb_param.roam_type, argv[index + 1]);
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("wds-en");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("wds en", glb_param.wds_enable, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dtls-version");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16("dtls version", glb_param.dtls_version, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("fc-swap-en");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("fc swap en", glb_param.fc_swap_enable, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-port0");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16("l4 port0", glb_param.udp_dest_port0, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("l4-port1");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT16("l4 port1", glb_param.udp_dest_port1, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("default-client-action");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("default client action", glb_param.default_client_action, argv[index + 1]);
       index = CTC_CLI_GET_ARGC_INDEX("mapping-vlan");
        if (0xFF != index)
        {
            CTC_CLI_GET_UINT16("mapping vlan", glb_param.default_client_vlan_id, argv[index + 1]);
        }
    }

    if(g_ctcs_api_en)
    {
         ret = ctcs_wlan_set_global_cfg(g_api_lchip, &glb_param);
    }
    else
    {
        ret = ctc_wlan_set_global_cfg(&glb_param);
    }

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_wlan_show_global_config,
        ctc_cli_wlan_show_global_config_cmd,
        "show wlan global",
        CTC_CLI_SHOW_STR,
        CTC_CLI_WLAN_DES,
        "Global")
{
    int32 ret = CLI_SUCCESS;
    ctc_wlan_global_cfg_t glb_param;

    sal_memset(&glb_param, 0, sizeof(ctc_wlan_global_cfg_t));

    if(g_ctcs_api_en)
    {
        ret = ctcs_wlan_get_global_cfg(g_api_lchip, &glb_param);
    }
    else
    {
        ret = ctc_wlan_get_global_cfg(&glb_param);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    ctc_cli_out("%-30s%s\n", "wlan global config", "Value");
    ctc_cli_out("----------------------\n");

    ctc_cli_out("%-30s%s\n", "control decrypt", glb_param.control_pkt_decrypt_en?"enable":"disable");
    ctc_cli_out("%-30s%s\n", "roam", glb_param.roam_enable?"enable":"disable");
    if(glb_param.roam_enable)
    {
        ctc_cli_out("%-30s%s\n", "roam type", glb_param.roam_type?"hub/spoke or full/mesh":"pop/poa");
    }
    ctc_cli_out("%-30s%s\n", "wds", glb_param.wds_enable?"enable":"disable");
    ctc_cli_out("%-30s0x%x\n", "dtls version", glb_param.dtls_version);
    ctc_cli_out("%-30s%s\n", "fc swap", glb_param.fc_swap_enable?"enable":"disable");
    ctc_cli_out("%-30s%d\n", "l4 port 0", glb_param.udp_dest_port0);
    ctc_cli_out("%-30s%d\n", "l4 port 1", glb_param.udp_dest_port1);
    if (CTC_WLAN_DEFAULT_CLIENT_ACTION_DISCARD == glb_param.default_client_action)
    {
        ctc_cli_out("%-30s%d\n", "default client discard", 0);
    }
    else if(CTC_WLAN_DEFAULT_CLIENT_ACTION_MAPPING_VLAN == glb_param.default_client_action)
    {
        ctc_cli_out("%-30s%d\n", "default client mapping vlan", glb_param.default_client_vlan_id);
    }
    ctc_cli_out("\n");

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_wlan_debug_on,
        ctc_cli_wlan_debug_on_cmd,
        "debug wlan (ctc | sys) (debug-level {func|param|info|error} |)",
        CTC_CLI_DEBUG_STR,
        CTC_CLI_WLAN_DES,
        "Ctc layer",
        "Sys layer",
        CTC_CLI_DEBUG_LEVEL_STR,
        CTC_CLI_DEBUG_LEVEL_FUNC,
        CTC_CLI_DEBUG_LEVEL_PARAM,
        CTC_CLI_DEBUG_LEVEL_INFO,
        CTC_CLI_DEBUG_LEVEL_ERROR)
{
    uint32 typeenum = 0;
    uint8 level = CTC_DEBUG_LEVEL_INFO;
    uint8 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("debug-level");
    if (index != 0xFF)
    {
        level = CTC_DEBUG_LEVEL_NONE;
        index = CTC_CLI_GET_ARGC_INDEX("func");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_FUNC;
        }

        index = CTC_CLI_GET_ARGC_INDEX("param");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_PARAM;
        }

        index = CTC_CLI_GET_ARGC_INDEX("info");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_INFO;
        }

        index = CTC_CLI_GET_ARGC_INDEX("error");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_ERROR;
        }
    }
    else
    {
        level = CTC_DEBUG_LEVEL_FUNC | CTC_DEBUG_LEVEL_INFO | CTC_DEBUG_LEVEL_PARAM | CTC_DEBUG_LEVEL_ERROR;
    }

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = WLAN_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = WLAN_SYS;
    }

    ctc_debug_set_flag("wlan", "wlan", typeenum, level, TRUE);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_wlan_debug_off,
        ctc_cli_wlan_debug_off_cmd,
        "no debug wlan (ctc | sys)",
        CTC_CLI_NO_STR,
        CTC_CLI_DEBUG_STR,
        CTC_CLI_WLAN_DES,
        "Ctc layer",
        "Sys layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = WLAN_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = WLAN_SYS;
    }

    ctc_debug_set_flag("wlan", "wlan", typeenum, level, FALSE);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_wlan_debug_show,
        ctc_cli_wlan_debug_show_cmd,
        "show wlan (ctc | sys)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_WLAN_DES,
        "Ctc layer",
        "Sys layer")
{
    uint32 typeenum = 0;
    uint8 level = 0;

    if (0 == sal_memcmp(argv[0], "ctc", 3))
    {
        typeenum = WLAN_CTC;
    }
    else if (0 == sal_memcmp(argv[0], "sys", 3))
    {
        typeenum = WLAN_SYS;
    }

    ctc_cli_out("wlan:%s debug %s level %s\n\r", argv[0],
                ctc_debug_get_flag("wlan", "wlan", typeenum, &level) ? "on" : "off", ctc_cli_get_debug_desc(level));

    return CLI_SUCCESS;
}

int32
ctc_wlan_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_wlan_tunnel_add_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_wlan_tunnel_add_v6_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_wlan_tunnel_remove_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_wlan_tunnel_remove_v6_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_wlan_client_add_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_wlan_client_remove_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_wlan_crypt_set_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_wlan_crypt_show_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_wlan_global_config_set_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_wlan_show_global_config_cmd);

    install_element(CTC_SDK_MODE, &ctc_cli_wlan_debug_on_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_wlan_debug_off_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_wlan_debug_show_cmd);

    return CLI_SUCCESS;
}


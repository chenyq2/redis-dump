#ifndef _CTC_IPMC_CLI_H
#define _CTC_IPMC_CLI_H
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"

#ifdef __cplusplus
extern "C" {
#endif

int32
ctc_ipmc_cli_init(void);

#ifdef __cplusplus
}
#endif

#endif  /* _CTC_IPMC_CLI_H */


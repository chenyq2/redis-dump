/**
 @file ctc_nexthop_cli.c

 @date 2009-11-30

 @version v2.0

 The file apply clis of port module
*/

#include "ctc_api.h"
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_l2.h"
#include "ctc_error.h"
#include "ctc_debug.h"

#include "ctc_nexthop_cli.h"
#include "ctc_cli_common.h"

#include "sys_greatbelt_nexthop_api.h"
#include "sys_greatbelt_nexthop.h"

enum cli_humber_nh_type_e
{
    CLI_HUMBER_NH_TYPE_NULL,
    CLI_HUMBER_NH_TYPE_MCAST,
    CLI_HUMBER_NH_TYPE_BRGUC,
    CLI_HUMBER_NH_TYPE_IPUC,
    CLI_HUMBER_NH_TYPE_MPLS,
    CLI_HUMBER_NH_TYPE_ECMP, /*For IPUC, MPLS, etc*/
    CLI_HUMBER_NH_TYPE_DROP,
    CLI_HUMBER_NH_TYPE_TOCPU,
    CLI_HUMBER_NH_TYPE_UNROV,
    CLI_HUMBER_NH_TYPE_ILOOP,
    CLI_HUMBER_NH_TYPE_ELOOP,
    CLI_HUMBER_NH_TYPE_RSPAN,
    CLI_HUMBER_NH_TYPE_MISC,
    CLI_HUMBER_NH_TYPE_IP_TUNNEL,
    CLI_HUMBER_NH_TYPE_MAX
};
typedef enum cli_humber_nh_type_e cli_humber_nh_type_t;

extern int32
sys_greatbelt_nh_dump_all(cli_humber_nh_type_t nh_type, bool detail);
extern bool
sys_greatbelt_chip_is_local(uint8 gchip_id, uint8* lchip_id);

extern int32
sys_greatbelt_nh_display_current_global_sram_info();
int32
sys_greatbelt_nh_dump_mpls_tunnel(uint16 tunnel_id, bool detail);
extern int32
sys_greatbelt_nh_dump(uint32 nhid, bool detail);
extern int32
sys_greatbelt_nh_set_ecmp_mode(uint8 enable);
extern int32
sys_greatbelt_nh_set_dsfwd_mode(uint8 have_dsfwd);

CTC_CLI(ctc_cli_gb_nh_show_nexthop_by_nhid_type,
        ctc_cli_gb_nh_show_nexthop_by_nhid_type_cmd,
        "show nexthop NHID (detail |)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_NH_M_STR,
        CTC_CLI_NH_ID_STR,
        "Display detail information")
{
    uint32 nhid;
    int32 ret = CLI_ERROR;
    bool detail = FALSE;

    if (argc == 2)
    {
        detail = TRUE;
    }

    CTC_CLI_GET_UINT32("NexthopID", nhid, argv[0]);
    ret = sys_greatbelt_nh_dump(nhid, detail);
    if (ret)
    {
        ctc_cli_out("%% Dump nexthop fail\n");
    }

    return ret;
}

CTC_CLI(ctc_cli_gb_nh_show_nexthop_all_by_type,
        ctc_cli_gb_nh_show_nexthop_all_by_type_cmd,
        "show nexthop all ((mcast|brguc|ipuc|ecmp|mpls|iloop|rspan|ip-tunnel|misc)|) (detail |)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_NH_M_STR,
        "All nexthop",
        "Multicast nexthop",
        "Bridge unicast nexthop",
        "Ipuc nexthop",
        "ECMP nexthop",
        "MPLS nexthop",
        "ILoop nexthop",
        "RSPAN nexthop",
        "Ip tunnel nexthop",
        "Misc nexthop",
        "Display detail information")
{
    int32 ret = 0;

    if (0 == argc)
    {
        ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_MAX, FALSE);
    }
    else if (1 == argc)
    {
        if (CLI_CLI_STR_EQUAL("mcast", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_MCAST, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("brguc", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_BRGUC, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("ipuc", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_IPUC, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("mpls", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_MPLS, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("ecmp", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_ECMP, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("iloop", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_ILOOP, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("rspan", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_RSPAN, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("ip-tunnel", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_IP_TUNNEL, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("misc", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_MISC, FALSE);
        }
        else if (CLI_CLI_STR_EQUAL("detail", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_MAX, TRUE);
        }
        else
        {
            ctc_cli_out("Invalid Nexthop Type Input\n");
        }
    }
    else if (2 == argc)
    {
        if (CLI_CLI_STR_EQUAL("mcast", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_MCAST, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("brguc", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_BRGUC, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("ipuc", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_IPUC, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("mpls", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_MPLS, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("ecmp", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_ECMP, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("rspan", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_RSPAN, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("ip-tunnel", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_IP_TUNNEL, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("misc", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_MISC, TRUE);
        }
        else if (CLI_CLI_STR_EQUAL("iloop", 0))
        {
            ret = sys_greatbelt_nh_dump_all(CLI_HUMBER_NH_TYPE_ILOOP, TRUE);
        }
        else
        {
            ctc_cli_out("Invalid Nexthop Type Input\n");
        }
    }
    else
    {
        ctc_cli_out("%% Invalid input parameters\n");
    }

    if (ret)
    {
        ctc_cli_out("%% Dump nexthop fail\n");
    }

    return ret;

}



extern int32
sys_greatbelt_nh_set_ipmc_logic_replication(uint8 enable);
extern int32
sys_greatbelt_nh_set_pkt_nh_edit_mode(uint8 edit_mode);

CTC_CLI(ctc_cli_gb_nh_cfg_global_param,
        ctc_cli_gb_nh_cfg_global_param_cmd,
        "nexthop (ipmc-logic-replication) value VALUE",
        CTC_CLI_NH_M_STR,
        "IPMC-logic_replication",
        "Value",
        "The Value of paramer configuration")
{
    int32 ret  = CLI_SUCCESS;
    uint8 value;

    if (0 == sal_memcmp(argv[0], "ipmc-logic-replication", 4))
    {
        CTC_CLI_GET_UINT8("Value", value, argv[1]);
        ret = sys_greatbelt_nh_set_ipmc_logic_replication(value);
        if (ret < 0)
        {
            ctc_cli_out("%% %s \n",  ctc_get_error_desc(ret));
            return CLI_ERROR;
        }
    }

    return ret;
}

CTC_CLI(ctc_cli_gb_nh_dump_mpls_tunnel,
        ctc_cli_gb_nh_dump_mpls_tunnel_cmd,
        "show nexthop mpls-tunnel TUNNEL_ID (detail|)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_NH_M_STR,
        CTC_CLI_NH_MPLS_TUNNEL,
        CTC_CLI_NH_MPLS_TUNNEL_ID,
        "Display detail information")
{
    int32 ret  = CLI_SUCCESS;
    uint16 tunnel_id = 0;
    bool detail = FALSE;

    CTC_CLI_GET_UINT16("Value", tunnel_id, argv[0]);
    if (argc > 1)
    {
        detail = TRUE;
    }

    ret = sys_greatbelt_nh_dump_mpls_tunnel(tunnel_id, detail);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n",  ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_gb_nh_set_ecmp_mode,
        ctc_cli_gb_nh_set_ecmp_mode_cmd,
        "nexthop ecmp-mode (enable|disable)",
        CTC_CLI_NH_M_STR,
        "Ecmp mode",
        "Enable means use exact member",
        "Disable means use max member count")
{
    int32 ret = 0;
    uint8 enable = FALSE;

    if (0 == sal_strncmp("enable", argv[0], sizeof("enable")))
    {
        enable = TRUE;
    }

    ret = sys_greatbelt_nh_set_ecmp_mode(enable);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n",  ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

extern int32
sys_greatbelt_nh_set_reflective_brg_en(uint8 enable);

CTC_CLI(ctc_cli_gb_nh_set_reflective_bridge,
        ctc_cli_gb_nh_set_reflective_bridge_cmd,
        "nexthop mcast-reflective-bridge (enable|disable)",
        CTC_CLI_NH_M_STR,
        "Mcast packet will support reflective bridge",
        "Enable",
        "Disable")
{
    int32 ret = 0;
    uint8 enable = FALSE;

    if (0 == sal_strncmp("enable", argv[0], sizeof("enable")))
    {
        enable = TRUE;
    }

    ret = sys_greatbelt_nh_set_reflective_brg_en(enable);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n",  ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

extern int32
sys_greatbelt_nh_dump_resource_usage();

CTC_CLI(ctc_cli_gb_nh_show_resource_usage,
        ctc_cli_gb_nh_show_resource_usage_cmd,
        "show nexthop status",
        CTC_CLI_SHOW_STR,
        CTC_CLI_NH_M_STR,
        "Nexthop's resource used status")
{
    int32 ret = 0;

    ret = sys_greatbelt_nh_dump_resource_usage();
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n",  ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

extern int32
sys_greatbelt_nh_dump_arp(uint16 arp_id, bool detail);
CTC_CLI(ctc_cli_gb_nh_dump_arp_id,
        ctc_cli_gb_nh_dump_arp_id_cmd,
        "show nexthop arp-id ARP_ID (detail|)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_NH_M_STR,
        "ARP ID",
        "ARP ID Value",
        "Display detail information")
{
    int32 ret  = CLI_SUCCESS;
    uint16 arp_id = 0;
    uint8  index = 0 ;
    bool detail = FALSE;

    CTC_CLI_GET_UINT16("Value", arp_id, argv[0]);

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("detail");
    if (0xFF != index)
    {
         detail = TRUE;
    }

    ret = sys_greatbelt_nh_dump_arp(arp_id, detail);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

extern int32
sys_greatbelt_nh_set_service_queue_en(uint32 nhid, uint8 service_queue_en);

CTC_CLI(ctc_cli_gb_nh_set_service_queue,
        ctc_cli_gb_nh_set_service_queue_cmd,
        "nexthop service-queue NHID (enable|disable)",
        CTC_CLI_NH_M_STR,
        "Service queue",
        CTC_CLI_NH_ID_STR,
        "Enable",
        "Disable")
{
    uint8 service_queue_en = FALSE;

    uint32 nhid = 0;
    int32 ret = CLI_ERROR;

    CTC_CLI_GET_UINT32("NexthopID", nhid, argv[0]);

    if (0 == sal_strncmp("enable", argv[1], sizeof("enable")))
    {
        service_queue_en = TRUE;
    }

    ret = sys_greatbelt_nh_set_service_queue_en(nhid, service_queue_en);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n",  ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

extern int32
sys_greatbelt_nh_update_mcast_service_queue(uint16 mc_grp_id, uint32 member_nhid);

CTC_CLI(ctc_cli_gb_nh_update_mcast_service_queue,
        ctc_cli_gb_nh_update_mcast_service_queue_cmd,
        "nexthop mcast-group GROUP_ID service-queue update nexthop NHID",
        CTC_CLI_NH_M_STR,
        "Multicast Group",
        CTC_CLI_GLOBAL_MCASTGRP_ID_DESC,
        "Service queue",
        "Update service queue",
        "Member nexthop",
        CTC_CLI_NH_ID_STR)
{
    int32 ret = CLI_ERROR;
    uint16 mc_grp_id = 0;
    uint32 member_nhid = 0;

    CTC_CLI_GET_UINT16("Mcast group id", mc_grp_id, argv[0]);
    CTC_CLI_GET_UINT32("NexthopID", member_nhid, argv[1]);

    ret = sys_greatbelt_nh_update_mcast_service_queue(mc_grp_id, member_nhid);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n",  ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_nh_merge_dsfwd_mode,
        ctc_cli_gb_nh_merge_dsfwd_mode_cmd,
        "nexthop merge-dsfwd-mode (enable|disable)",
        CTC_CLI_NH_M_STR,
        "set nexthop merge dsfwd mode",
        CTC_CLI_ENABLE,
        CTC_CLI_DISABLE)
{
    uint8 have_dsfwd = 0;
    int32 ret  = CLI_SUCCESS;

    if (CLI_CLI_STR_EQUAL("en", 0))
    {
        have_dsfwd = 0;
    }
    else
    {
        have_dsfwd = 1;
    }

    ret = sys_greatbelt_nh_set_dsfwd_mode(have_dsfwd);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_gb_nh_set_nh_drop,
        ctc_cli_gb_nh_set_nh_drop_cmd,
        "nexthop NHID drop (protection-path|) (enable | disable)",
        CTC_CLI_NH_M_STR,
        CTC_CLI_NH_ID_STR,
        "Set nexthop drop",
        "Protection Path",
        "Drop Enable",
        "Drop Disable")
{
    int32 ret       = CLI_SUCCESS;
    uint32 nhid     = 0;
    uint16 index    = 0;
    ctc_nh_drop_info_t nh_drop;

    sal_memset(&nh_drop, 0, sizeof(ctc_nh_drop_info_t));


    CTC_CLI_GET_UINT32("Nexthop ID", nhid, argv[0]);

    index = CTC_CLI_GET_ARGC_INDEX("protection-path");
    if (0xFF != index)
    {
        nh_drop.is_protection_path = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX("enable");
    if (0xFF != index)
    {
        nh_drop.drop_en = 1;
    }
    else
    {
        nh_drop.drop_en = 0;
    }
    ret = ctc_nh_set_nh_drop(nhid, &nh_drop);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

int32
ctc_greatbelt_nexthop_cli_init(void)
{

    install_element(CTC_SDK_MODE, &ctc_cli_gb_nh_show_nexthop_by_nhid_type_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_nh_show_nexthop_all_by_type_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_nh_dump_mpls_tunnel_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_nh_show_resource_usage_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_nh_dump_arp_id_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_nh_set_nh_drop_cmd);

    /*GB CLIs*/
    install_element(CTC_INTERNAL_MODE, &ctc_cli_gb_nh_cfg_global_param_cmd);
    install_element(CTC_INTERNAL_MODE, &ctc_cli_gb_nh_set_ecmp_mode_cmd);
    install_element(CTC_INTERNAL_MODE, &ctc_cli_gb_nh_set_reflective_bridge_cmd);

    install_element(CTC_INTERNAL_MODE, &ctc_cli_gb_nh_set_service_queue_cmd);
    install_element(CTC_INTERNAL_MODE, &ctc_cli_gb_nh_update_mcast_service_queue_cmd);
    install_element(CTC_INTERNAL_MODE, &ctc_cli_gb_nh_merge_dsfwd_mode_cmd);

    return CLI_SUCCESS;
}


/**
 @file ctc_greatbelt_stacking_cli.c

 @date 2010-7-9

 @version v2.0

---file comments----
*/

#include "ctc_cli.h"
#include "ctc_error.h"
#include "ctc_api.h"
#include "ctc_debug.h"

#include "ctc_greatbelt_stacking_cli.h"
#include "sys_greatbelt_stacking.h"

extern int32 sys_greatbelt_stacking_show_trunk_info(uint8 trunk_id);
extern int32 sys_greatbelt_stacking_mcast_mode(uint8 mcast_mode);

CTC_CLI(ctc_cli_gb_stacking_show_trunk_info,
        ctc_cli_gb_stacking_show_trunk_info_cmd,
        "show stacking trunk trunk-id TRUNID info",
        "Show",
        "Stacking",
        "Trunk",
        "Trunk id",
        "Value <1-63>",
        "Information")
{
    uint8 trunk_id = 0;
    int32 ret = CLI_SUCCESS;

    CTC_CLI_GET_UINT8_RANGE("Trunkid", trunk_id, argv[0], 0, CTC_MAX_UINT8_VALUE);

    ret = sys_greatbelt_stacking_show_trunk_info(trunk_id);

    if (ret < 0)
    {
        ctc_cli_out("%% ret=%d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_stacking_mcast_mode,
        ctc_cli_gb_stacking_mcast_mode_cmd,
        "stacking mcast-mode MODE",
        "Stacking",
        "Mcast mode",
        "0: add trunk to mcast group auto; 1: add trunk to mcast group by user")
{
    int32 ret = CLI_SUCCESS;
    uint8 mode = 0;

    CTC_CLI_GET_UINT8("mode", mode, argv[0]);
    ret = sys_greatbelt_stacking_mcast_mode(mode);
    if (ret < 0)
    {
        ctc_cli_out("%% ret=%d, %s\n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


int32
ctc_greatbelt_stacking_cli_init(void)
{
    install_element(CTC_SDK_MODE,  &ctc_cli_gb_stacking_show_trunk_info_cmd);
    install_element(CTC_INTERNAL_MODE,  &ctc_cli_gb_stacking_mcast_mode_cmd);

    return CLI_SUCCESS;

}


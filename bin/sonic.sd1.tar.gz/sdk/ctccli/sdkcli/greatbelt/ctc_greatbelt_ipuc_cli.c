/**
 @file ctc_ipuc_cli.c

 @date 2009-12-30

 @version v2.0

 The file apply clis of ipuc module
*/

#include "sal.h"
#include "ctc_debug.h"
#include "ctc_error.h"
#include "ctc_ipuc_cli.h"
#include "ctc_api.h"
#include "ctc_ipuc.h"

extern int32
sys_greatbelt_ipuc_db_show(ctc_ip_ver_t ip_ver, uint32 detail);
extern int32
sys_greatbelt_ipuc_nat_sa_db_show(ctc_ip_ver_t ip_ver, uint32 detail);
extern int32
sys_greatbelt_ipuc_offset_show(uint8 flag, uint8 blockid);
extern int32
sys_greatbelt_ipuc_state_show(void);
extern int32
sys_greatbelt_ipuc_db_show_count(void);

extern int32
sys_greatbelt_ipuc_reinit(bool use_hash8);

extern int32
sys_greatbelt_l3_hash_state_show(void);
extern int32
sys_greatbelt_lpm_enable_dma(uint8 enable);
extern int32
sys_greatbelt_ipuc_show_debug_info(ctc_ipuc_param_t* p_ipuc_param, uint8 detail);

CTC_CLI(ctc_cli_gb_ipuc_show_ipv4,
        ctc_cli_gb_ipuc_show_ipv4_cmd,
        "show ipuc",
        CTC_CLI_SHOW_STR,
        CTC_CLI_IPUC_M_STR)
{
    int32 ret = CLI_ERROR;

    ret = sys_greatbelt_ipuc_db_show(CTC_IP_VER_4, FALSE);

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_ipuc_show_ipv4_nat_sa,
        ctc_cli_gb_ipuc_show_ipv4_nat_sa_cmd,
        "show ipuc nat-sa",
        CTC_CLI_SHOW_STR,
        CTC_CLI_IPUC_M_STR,
        "Nat sa")
{
    int32 ret = CLI_ERROR;

    ret = sys_greatbelt_ipuc_nat_sa_db_show(CTC_IP_VER_4, FALSE);

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_ipuc_show_ipv6,
        ctc_cli_gb_ipuc_show_ipv6_cmd,
        "show ipuc ipv6",
        CTC_CLI_SHOW_STR,
        CTC_CLI_IPUC_M_STR,
        CTC_CLI_IPV6_STR)
{
    int32 ret = CLI_ERROR;

    ret = sys_greatbelt_ipuc_db_show(CTC_IP_VER_6, FALSE);

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_ipuc_show_count,
        ctc_cli_gb_ipuc_show_count_cmd,
        "show ipuc count",
        CTC_CLI_SHOW_STR,
        CTC_CLI_IPUC_M_STR,
        "Show ipuc route number")
{
    int32 ret = CLI_ERROR;

    ret = sys_greatbelt_ipuc_db_show_count();

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_ipuc_show_state,
        ctc_cli_gb_ipuc_show_state_cmd,
        "show ipuc status",
        CTC_CLI_SHOW_STR,
        CTC_CLI_IPUC_M_STR,
        "IPUC configure and state")
{
    int32 ret = CLI_ERROR;

    ret = sys_greatbelt_ipuc_state_show();

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_ipuc_offset_show,
        ctc_cli_gb_ipuc_offset_show_cmd,
        "show ipuc offset (ipv6 | ) INDEX",
        CTC_CLI_SHOW_STR,
        CTC_CLI_IPUC_M_STR,
        "IPUC offset",
        CTC_CLI_IPV6_STR,
        "Block index")
{
    int32  ret = CLI_ERROR;
    uint32 index = 0;
    uint32 ip_ver = MAX_CTC_IP_VER;

    CTC_CLI_GET_UINT32("block id", index, argv[argc - 1]);

    if (0 == sal_memcmp("ipv6", argv[0], 4))
    {
        ip_ver = CTC_IP_VER_6;
    }
    else
    {
        ip_ver = CTC_IP_VER_4;
    }

    ret = sys_greatbelt_ipuc_offset_show(ip_ver, index);

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_ipuc_arrange_fragment,
        ctc_cli_gb_ipuc_arrange_fragment_cmd,
        "ipuc arrange fragment",
        CTC_CLI_IPUC_M_STR,
        "Arrange lpm fragment",
        "Arrange lpm fragment")
{
    int32 ret = CLI_ERROR;

    ret = ctc_ipuc_arrange_fragment(NULL);

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_ipuc_reinit,
        ctc_cli_gb_ipuc_reinit_cmd,
        "ipuc reinit pipline3 (enable | disable )",
        CTC_CLI_IPUC_M_STR,
        "Reinit ipv4 module with pipline mode (test usage only)",
        "Pipline3 enable means do lpm with hash8 and 3 level pipline else means do lpm with hash16 with 2 level pipline",
        "Enable : do hash8 and 3 level pipline lookup",
        "Disable : do hash16 and 2 level pipline lookup")
{
    int32 ret = CLI_ERROR;
    uint32 index;
    bool pipline3_enable;

    index = CTC_CLI_GET_ARGC_INDEX("enable");
    if (index != 0xFF)
    {
        pipline3_enable = TRUE;
    }
    else
    {
        pipline3_enable = FALSE;
    }

    ret = sys_greatbelt_ipuc_reinit(pipline3_enable);

    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gb_ipuc_show_l3_hash_state,
        ctc_cli_gb_ipuc_show_l3_hash_state_cmd,
        "show ipuc hash",
        CTC_CLI_SHOW_STR,
        "Show ipuc hash state",
        "Show ipuc hash state")
{
    int32 ret = 0;

    ret = sys_greatbelt_l3_hash_state_show();
    if (ret)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_show_ipv4_info,
        ctc_cli_ipuc_show_ipv4_info_cmd,
        "show ipuc VRFID A.B.C.D MASK_LEN (detail |)",
        CTC_CLI_IPUC_M_STR,
        "Show ipuc ipv4 route",
        CTC_CLI_VRFID_ID_DESC,
        CTC_CLI_IPV4_FORMAT,
        CTC_CLI_IPV4_MASK_LEN_FORMAT,
        "show the detail of this entry")
{
    int32 ret = CLI_SUCCESS;
    uint32 vrfid = 0;
    uint32 masklen = 0;
    ctc_ipuc_param_t ipuc_info = {0};
    uint8 detail = 0;
    uint8 index = 0;

    CTC_CLI_GET_UINT16_RANGE("vrfid", vrfid, argv[0], 0, CTC_MAX_UINT16_VALUE);
    ipuc_info.vrf_id = vrfid;

    CTC_CLI_GET_IPV4_ADDRESS("ip", ipuc_info.ip.ipv4, argv[1]);

    CTC_CLI_GET_UINT8_RANGE("mask", masklen, argv[2], 0, CTC_MAX_UINT8_VALUE);
    ipuc_info.masklen = masklen;

    index = CTC_CLI_GET_ARGC_INDEX("detail");
    if (index != 0xFF)
    {
        detail = 1;
    }

    ret = sys_greatbelt_ipuc_show_debug_info(&ipuc_info,detail);


    if (ret < 0)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_show_ipv6_info,
        ctc_cli_ipuc_show_ipv6_info_cmd,
        "show ipuc ipv6 VRFID X:X::X:X MASK_LEN (detail |)",
        CTC_CLI_IPUC_M_STR,
        CTC_CLI_IPV6_STR,
        "show ipuc ipv6 route",
        CTC_CLI_VRFID_ID_DESC,
        CTC_CLI_IPV6_FORMAT,
        CTC_CLI_IPV6_MASK_LEN_FORMAT,
        "show the detail of this entry")
{
    int32 ret = CLI_SUCCESS;
    uint32 vrfid = 0;
    uint32 masklen = 0;
    ipv6_addr_t ipv6_address;
    ctc_ipuc_param_t ipuc_info = {0};
    uint8 detail = 0;
    uint8 index = 0;

    ipuc_info.ip_ver = CTC_IP_VER_6;

    CTC_CLI_GET_UINT16_RANGE("vrfid", vrfid, argv[0], 0, CTC_MAX_UINT16_VALUE);
    ipuc_info.vrf_id = vrfid;

    CTC_CLI_GET_IPV6_ADDRESS("ipv6", ipv6_address, argv[1]);

    /* adjust endian */
    ipuc_info.ip.ipv6[0] = sal_htonl(ipv6_address[0]);
    ipuc_info.ip.ipv6[1] = sal_htonl(ipv6_address[1]);
    ipuc_info.ip.ipv6[2] = sal_htonl(ipv6_address[2]);
    ipuc_info.ip.ipv6[3] = sal_htonl(ipv6_address[3]);

    CTC_CLI_GET_UINT8_RANGE("mask", masklen, argv[2], 0, CTC_MAX_UINT8_VALUE);
    ipuc_info.masklen = masklen;

    index = CTC_CLI_GET_ARGC_INDEX("detail");
    if (index != 0xFF)
    {
        detail = 1;
    }

    ret = sys_greatbelt_ipuc_show_debug_info(&ipuc_info,detail);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_ipuc_write_lpm_by_dma,
        ctc_cli_ipuc_write_lpm_by_dma_cmd,
        "ipuc dma (enable|disable)",
        CTC_CLI_IPUC_M_STR,
        "Use",
        "DMA")
{
    int32 ret = 0;
    uint32 index;
    bool dma_enable;

    index = CTC_CLI_GET_ARGC_INDEX("enable");
    if (index != 0xFF)
    {
        dma_enable = TRUE;
    }
    else
    {
        dma_enable = FALSE;
    }

    ret = sys_greatbelt_lpm_enable_dma(dma_enable);
    if (ret < 0)
    {
        ctc_cli_out("%% %s \n\r", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}



CTC_CLI(ctc_cli_gb_ipuc_test,
        ctc_cli_gb_ipuc_test_cmd,
        "ipuc test A.B.C.D (mask MASK) (number NUMBER |)",
        "IPUC",
        "Test",
        "IP",
        "Mask",
        "Mask",
        "Number",
        "Number")
{
    uint8 index = 0;
    int32 ret = CLI_SUCCESS;
    ctc_ipuc_param_t ipuc_info =   {0};
    uint32 i = 0;
    uint32 number = 10000;
    ip_addr_t ipv4 = 0;

    sal_time_t tv;
    char* p_time_str = NULL;

    CTC_CLI_GET_IPV4_ADDRESS("ip", ipv4, argv[0]);

    index = CTC_CLI_GET_ARGC_INDEX("mask");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT8("mask", ipuc_info.masklen, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("number");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("number", number, argv[index + 1]);
    }
    ipuc_info.nh_id = 2;

    sal_time(&tv);
    p_time_str = sal_ctime(&tv);
    ctc_cli_out("START! Mask :%d, Entry :%d, TIME:%s", ipuc_info.masklen, number, p_time_str);
    for (i = 0; i < number; i++)
    {
        ipuc_info.ip.ipv4 = ipv4  + (i << (32 - ipuc_info.masklen));
        ret = ctc_ipuc_add(&ipuc_info);
    }
    sal_time(&tv);
    p_time_str = sal_ctime(&tv);
    ctc_cli_out("END! TIME:%s", p_time_str);

    return ret;
}


int32
ctc_greatbelt_ipuc_cli_init(void)
{

#ifdef SDK_INTERNAL_CLI_SHOW
    install_element(CTC_INTERNAL_MODE,  &ctc_cli_gb_ipuc_show_l3_hash_state_cmd);
    install_element(CTC_INTERNAL_MODE, &ctc_cli_gb_ipuc_offset_show_cmd);
    install_element(CTC_INTERNAL_MODE, &ctc_cli_ipuc_write_lpm_by_dma_cmd);
#endif

    install_element(CTC_SDK_MODE, &ctc_cli_gb_ipuc_arrange_fragment_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_ipuc_show_ipv6_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_ipuc_show_count_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_ipuc_show_state_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_ipuc_show_ipv4_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_ipuc_show_ipv4_nat_sa_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gb_ipuc_reinit_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipuc_show_ipv4_info_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_ipuc_show_ipv6_info_cmd);
    install_element(CTC_INTERNAL_MODE,  &ctc_cli_gb_ipuc_test_cmd);

    return CLI_SUCCESS;
}


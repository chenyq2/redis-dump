/**
 @file ctc_greatbelt_aps_cli.c

 @date 2012-12-6

 @version v2.0

 The file apply clis of ipuc module
*/

#include "sal.h"
#include "ctc_debug.h"
#include "ctc_error.h"
#include "ctc_aps_cli.h"
#include "ctc_api.h"
#include "ctc_aps.h"

extern int32
sys_greatbelt_aps_show_bridge(uint16 group_id);

CTC_CLI(ctc_cli_gb_aps_show_bridge,
        ctc_cli_gb_aps_show_bridge_cmd,
        "show aps bridge group GROUP_ID",
        CTC_CLI_SHOW_STR,
        CTC_CLI_APS_M_STR,
        "APS Bridge",
        "APS bridge group",
        CTC_CLI_APS_GROUP_ID_DESC)
{
    int32 ret = 0;
    uint16 group_id = 0;

    CTC_CLI_GET_UINT16_RANGE("aps bridge group id", group_id, argv[0], 0, CTC_MAX_UINT16_VALUE);

    ret = sys_greatbelt_aps_show_bridge(group_id);
    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

int32
ctc_greatbelt_aps_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_gb_aps_show_bridge_cmd);
    return CLI_SUCCESS;
}


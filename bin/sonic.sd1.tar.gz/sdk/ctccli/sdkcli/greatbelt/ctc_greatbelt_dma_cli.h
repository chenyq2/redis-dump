/**
 @file ctc_dma_cli.h

 @date 2012-3-20

 @version v2.0

---file comments----
*/

#ifndef _CTC_GREATBELT_DMA_CLI_H
#define _CTC_GREATBELT_DMA_CLI_H
#ifdef __cplusplus
extern "C" {
#endif
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"

/**
 @brief  Initialize sdk DMA module CLIs

 @param[in/out]   cli_tree     CLI tree

 @return CTC_E_XXX

*/
int32
ctc_greatbelt_dma_cli_init(void);

#ifdef __cplusplus
}
#endif

#endif  /* _CTC_GREATBELT_DMA_CLI_H */


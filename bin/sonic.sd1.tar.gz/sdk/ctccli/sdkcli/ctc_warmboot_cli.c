#include "sal.h"

#include "ctc_cli.h"
#include "ctc_api.h"
#include "ctc_cmd.h"
#include "ctc_cli_common.h"
#include "ctc_warmboot_cli.h"

extern int32 ctc_wb_sync();
extern int32 ctc_wb_sync_done();

CTC_CLI(ctc_cli_common_wb_sync,
        ctc_cli_common_wb_sync_cmd,
        "warmboot sync",
        "Warmboot module",
        "Sync up all data")
{
    ctc_wb_sync();

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_common_wb_sync_done,
        ctc_cli_common_wb_sync_done_cmd,
        "warmboot sync done",
        "Warmboot module",
        "Sync up all data",
        "Store memory DB to file")
{
    ctc_wb_sync_done();

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_common_wb_debug_on,
        ctc_cli_common_wb_debug_on_cmd,
        "debug warmboot (debug-level {func|param|info|error} |)",
        CTC_CLI_DEBUG_STR,
        "Warmboot module",
        CTC_CLI_DEBUG_LEVEL_STR,
        CTC_CLI_DEBUG_LEVEL_FUNC,
        CTC_CLI_DEBUG_LEVEL_PARAM,
        CTC_CLI_DEBUG_LEVEL_INFO,
        CTC_CLI_DEBUG_LEVEL_ERROR)
{

    uint8 level = CTC_DEBUG_LEVEL_INFO;
    uint8 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("debug-level");
    if (index != 0xFF)
    {
        level = CTC_DEBUG_LEVEL_NONE;
        index = CTC_CLI_GET_ARGC_INDEX("func");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_FUNC;
        }

        index = CTC_CLI_GET_ARGC_INDEX("param");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_PARAM;
        }

        index = CTC_CLI_GET_ARGC_INDEX("info");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_INFO;
        }

        index = CTC_CLI_GET_ARGC_INDEX("error");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_ERROR;
        }
    }

    ctc_debug_set_flag("wb", "wb", WB_CTC, level, TRUE);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_common_wb_debug_off,
        ctc_cli_common_wb_debug_off_cmd,
        "no debug warmboot",
        CTC_CLI_NO_STR,
        CTC_CLI_DEBUG_STR,
        "Warmboot moudle")
{
    uint8 level = 0;

    ctc_debug_set_flag("wb", "wb", WB_CTC, level, FALSE);

    return CLI_SUCCESS;
}

int32
ctc_warmboot_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_common_wb_sync_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_common_wb_sync_done_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_common_wb_debug_on_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_common_wb_debug_off_cmd);

    return CTC_E_NONE;
}


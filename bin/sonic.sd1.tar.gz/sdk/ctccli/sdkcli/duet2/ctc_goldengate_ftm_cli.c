/**
 @file ctc_goldengate_ftm_cli.c

 @date 2009-11-23

 @version v2.0

---file comments----
*/

#include "sal.h"
#include "ctc_cli.h"
#include "ctc_cli_common.h"
#include "ctc_ftm_cli.h"
#include "ctc_api.h"
#include "ctcs_api.h"
#include "ctc_alloc.h"
#include "ctc_error.h"
#include "ctc_debug.h"

extern int32 sys_goldengate_opf_print_alloc_info(uint8 lchip, uint8 pool_type, uint8 pool_index);
extern int32 sys_goldentgate_opf_print_type(uint8 lchip, uint8 opf_type, uint8 is_all);
extern int32 sys_goldengate_ftm_show_alloc_info_detail(uint8 lchip);
extern int32 sys_goldengate_ftm_show_alloc_info(uint8 lchip);
extern int32 drv_ftm_get_tcam_tbl_info_detail(uint8 lchip, char* P_tbl_name);

CTC_CLI(ctc_cli_gg_ftm_show_opf_type_info,
        ctc_cli_gg_ftm_show_opf_type_info_cmd,
        "show opf type (TYPE|all)",
        CTC_CLI_SHOW_STR,
        "Offset pool freelist",
        "OPF type",
        "OPF type value",
        "All types")
{
    uint8 opf_type;
    uint8 lchip = 0;
    int32 ret = CLI_SUCCESS;

    lchip = g_ctcs_api_en?g_api_lchip:lchip;
    if (0 == sal_memcmp("all", argv[0], 3))
    {
        ret = sys_goldentgate_opf_print_type(lchip,0,1);
    }
    else
    {
        CTC_CLI_GET_UINT8_RANGE("opf type", opf_type, argv[0], 0, CTC_MAX_UINT8_VALUE);
        ret = sys_goldentgate_opf_print_type(lchip, opf_type, 0);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% ret = %d, %s \n", ret, ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_gg_ftm_show_opf_alloc_info,
        ctc_cli_gg_ftm_show_opf_alloc_info_cmd,
        "show opf alloc type TYPE index INDEX",
        CTC_CLI_SHOW_STR,
        "Offset pool freelist",
        "OPF alloc info",
        "OPF type",
        "OPF type value",
        "Index of opf pool",
        "<0-0xFF>")
{
    int32 ret = CLI_SUCCESS;
    uint8 lchip = 0;
    uint8 pool_type = 0;
    uint8 pool_index = 0;

    CTC_CLI_GET_UINT8_RANGE("opf type", pool_type, argv[0], 0, CTC_MAX_UINT8_VALUE);
    CTC_CLI_GET_UINT8_RANGE("opf index", pool_index, argv[1], 0, CTC_MAX_UINT8_VALUE);

    lchip = g_ctcs_api_en?g_api_lchip:lchip;
    ret = sys_goldengate_opf_print_alloc_info(lchip, pool_type, pool_index);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

CTC_CLI(ctc_cli_gg_ftm_show_ftm_info,
        ctc_cli_gg_ftm_show_ftm_info_cmd,
        "show ftm info (detail|) (lchip LCHIP|)",
        CTC_CLI_SHOW_STR,
        CTC_CLI_MEM_ALLOCM_STR,
        "Information of TCAM and Sram",
        "show detail ftm info",
        CTC_CLI_LCHIP_ID_STR,
        CTC_CLI_LCHIP_ID_VALUE)
{
    int32 ret = CLI_SUCCESS;
    uint8 index = 0;
    uint8 lchip = 0;

    index = CTC_CLI_GET_ARGC_INDEX("lchip");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT8("lchip", lchip, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("detail");
    if (0xFF != index)
    {
        ret = sys_goldengate_ftm_show_alloc_info_detail(lchip);
    }
    else
    {
        ret = sys_goldengate_ftm_show_alloc_info(lchip);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}


CTC_CLI(ctc_cli_gg_ftm_show_tcam_detail_info,
        ctc_cli_gg_ftm_show_tcam_detail_info_cmd,
        "show ftm tcam alloc tbl STRING:TBL_NAME_ID",
        CTC_CLI_SHOW_STR,
        "Tcam",
        "Alloc")
{
    char buf[256] = {0};
    int32 ret = CLI_SUCCESS;

    sal_strncpy((char*)buf, argv[0], 256);

    ret = drv_ftm_get_tcam_tbl_info_detail(0, buf);

    if (ret < 0)
    {
        ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return ret;
}

int32
ctc_goldengate_ftm_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_gg_ftm_show_opf_type_info_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_ftm_show_opf_alloc_info_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_ftm_show_ftm_info_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_gg_ftm_show_tcam_detail_info_cmd);

    return CTC_E_NONE;
}


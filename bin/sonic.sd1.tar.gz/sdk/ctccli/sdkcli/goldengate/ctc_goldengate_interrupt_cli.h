/**
 @file ctc_goldengate_interrupt_cli.h

 @author  Copyright (C) 2012 Centec Networks Inc.  All rights reserved.

 @date 2012-10-23

 @version v2.0

 This file define interrupt CLI functions

*/

#ifndef _CTC_GOLDENGATE_INTERRUPT_CLI_H
#define _CTC_GOLDENGATE_INTERRUPT_CLI_H
#ifdef __cplusplus
extern "C" {
#endif

#include "sal.h"
#include "ctc_cli.h"

int32
ctc_goldengate_interrupt_cli_init(void);

#ifdef __cplusplus
}
#endif

#endif /* _CTC_GOLDENGATE_INTERRUPT_CLI_H */


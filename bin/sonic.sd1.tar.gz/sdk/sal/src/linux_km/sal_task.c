#include "sal.h"
#include <linux/sched.h>
#include <linux/delay.h>

struct sal_task
{
    struct task_struct* ktask;
    const char* name;
    void (* start)(void*);
    void* arg;
    struct completion started;
    struct completion done;
};

void ctc_sal_udelay(uint32 usec)
{
    udelay(usec);
}

static int
kthread_start(void* arg)
{
    sal_task_t* task = (sal_task_t*)arg;

    daemonize(task->name);
    complete(&task->started);
    schedule();

//    current->security = task;
    (*task->start)(task->arg);
//    current->security = NULL;

    complete(&task->done);

    SAL_FREE(task);
    return 0;
}

sal_err_t
ctc_sal_task_create(sal_task_t** ptask,
                char* name,
                size_t stack_size,
                int prio,
                void (* start)(void*),
                void* arg)
{
    sal_task_t* task;
    int pid;

    SAL_MALLOC(task, sal_task_t*, sizeof(sal_task_t));
    if (!task)
    {
        return ENOMEM;
    }

    task->name = name;
    task->start = start;
    task->arg = arg;
    init_completion(&task->started);
    init_completion(&task->done);

    pid = kernel_thread(kthread_start, task, CLONE_KERNEL);
    if (pid < 0)
    {
        SAL_FREE(task);

        return -pid;
    }

    wait_for_completion(&task->started);
    task->ktask = pid_task(find_pid_ns(pid, &init_pid_ns), PIDTYPE_PID);
    *ptask = task;

    return 0;
}

void
ctc_sal_task_destroy(sal_task_t* task)
{
#if 0
    wait_for_completion(&task->done);
    SAL_FREE(task);
#endif    
}

void
ctc_sal_task_exit(sal_task_t *task)
{
//    sal_task_t* task = (sal_task_t*)current->security;

//    current->security = NULL;
    complete_and_exit(&task->done, 0);
}

void
ctc_sal_task_sleep(uint32_t msec)
{
    __set_current_state(TASK_UNINTERRUPTIBLE);
    schedule_timeout(msecs_to_jiffies(msec));
}

void
ctc_sal_task_yield()
{
    yield();
}

void ctc_sal_delay(uint32 sec)
{
    ctc_sal_task_sleep(sec * 1000);
}

void
ctc_sal_gettime(sal_systime_t* tv)
{
    struct timeval temp_tv;

    sal_memset(&temp_tv, 0, sizeof(temp_tv));

    do_gettimeofday(&temp_tv);

    tv->tv_sec = temp_tv.tv_sec;
    tv->tv_usec = temp_tv.tv_usec;
}

void
ctc_sal_getuptime(struct timespec* ts)
{
    ktime_get_ts(ts);
}

sal_err_t
ctc_sal_task_set_priority(int32 priority)
{
    return 0;
}


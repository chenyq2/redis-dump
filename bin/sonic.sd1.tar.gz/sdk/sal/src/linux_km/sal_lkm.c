#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include "sal.h"

static int
ctc_sal_lkm_init()
{
    return 0;
}

static void
ctc_sal_lkm_exit()
{
}

//module_init(sal_lkm_init);
//module_exit(sal_lkm_exit);


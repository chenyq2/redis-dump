/**
 @file ctc_app_packet_cli.c

 @author  Copyright (C) 2012 Centec Networks Inc.  All rights reserved.

 @date 2012-11-25

 @version v2.0

 This file define packet sample CLI functions

*/

#include "sal.h"
#include "ctc_api.h"
#include "ctc_cli.h"
#include "ctc_error.h"
#include "ctc_debug.h"
#include "ctc_packet.h"
#include "ctc_opf.h"
#include "ctc_app_packet.h"
#include "ctc_cli_common.h"
#include "ctc_app_index.h"
#include "ctc_app_vlan_port.h"


CTC_CLI(ctc_cli_app_packet_show,
        ctc_cli_app_packet_show_cmd,
        "show app packet stats",
        CTC_CLI_SHOW_STR,
        CTC_CLI_APP_M_STR,
        "Packet",
        "Stats")
{
    ctc_app_packet_sample_show();
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_app_packet_print_rx,
        ctc_cli_app_packet_print_rx_cmd,
        "app packet cpu-rx-print (on|off)",
        CTC_CLI_APP_M_STR,
        "Packet",
        "Print CPU RX packet",
        "On",
        "Off")
{
    uint32 enable = FALSE;
    int32 ret = 0;

    if (0 == sal_strcmp(argv[0], "on"))
    {
        enable = TRUE;
    }
    else
    {
        enable = FALSE;
    }

    ret = ctc_app_packet_sample_set_rx_print_en(enable);
    if (ret < 0)
    {
        ctc_cli_out("%% %s\n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_app_packet_create_socket,
        ctc_cli_app_packet_create_socket_cmd,
        "app packet create eth-socket ifid IFID",
        CTC_CLI_APP_M_STR,
        "Packet",
        "Create",
        "Socket",
        "Eth interface",
        "Interface Id")
{
    uint16 if_id = 0;
    int32 ret = 0;

    CTC_CLI_GET_UINT16_RANGE("if-id", if_id, argv[0], 0, CTC_MAX_UINT16_VALUE);

    ret = ctc_app_packet_sample_eth_open_raw_socket(if_id);
    if (ret < 0)
    {
        ctc_cli_out("%% %s\n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_app_packet_destroy_socket,
        ctc_cli_app_packet_destroy_socket_cmd,
        "app packet destroy eth-socket",
        CTC_CLI_APP_M_STR,
        "Packet",
        "Destroy",
        "Socket")
{
    int32 ret = 0;
    ret = ctc_app_packet_sample_eth_close_raw_socket();
     if (ret < 0)
    {
        ctc_cli_out("%% %s\n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_app_debug_on,
        ctc_cli_app_debug_on_cmd,
        "debug app (debug-level {func|param|info|error} |)",
        CTC_CLI_DEBUG_STR,
        CTC_CLI_APP_M_STR,
        CTC_CLI_DEBUG_LEVEL_STR,
        CTC_CLI_DEBUG_LEVEL_FUNC,
        CTC_CLI_DEBUG_LEVEL_PARAM,
        CTC_CLI_DEBUG_LEVEL_INFO,
        CTC_CLI_DEBUG_LEVEL_ERROR)
{

    uint32 typeenum = 0;
    uint8 level = CTC_DEBUG_LEVEL_INFO | CTC_DEBUG_LEVEL_FUNC | CTC_DEBUG_LEVEL_PARAM | CTC_DEBUG_LEVEL_ERROR;
    uint8 index = 0;

    index = CTC_CLI_GET_ARGC_INDEX("debug-level");
    if (index != 0xFF)
    {
        level = CTC_DEBUG_LEVEL_NONE;
        index = CTC_CLI_GET_ARGC_INDEX("func");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_FUNC;
        }

        index = CTC_CLI_GET_ARGC_INDEX("param");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_PARAM;
        }

        index = CTC_CLI_GET_ARGC_INDEX("info");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_INFO;
        }

        index = CTC_CLI_GET_ARGC_INDEX("error");
        if (index != 0xFF)
        {
            level |= CTC_DEBUG_LEVEL_ERROR;
        }
    }

    typeenum = APP_SMP;

    ctc_debug_set_flag("app", "app", typeenum, level, TRUE);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_app_debug_off,
        ctc_cli_app_debug_off_cmd,
        "no debug app",
        CTC_CLI_NO_STR,
        CTC_CLI_DEBUG_STR,
        CTC_CLI_APP_M_STR)
{
    uint32 typeenum = APP_SMP;
    uint8 level = 0;

    ctc_debug_set_flag("app", "app", typeenum, level, FALSE);

    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_app_index_alloc,
        ctc_cli_app_index_alloc_cmd,
        "app index alloc (tunnel-id|nh-id|l3if-id |mcast-group-id|\
        acl-entry-id | policer-id | stats-id ) (gchip GCHIP|)",
        CTC_CLI_APP_M_STR,
        "Index",
        "Alloc",
        "Tunnel-id" ,
        "Nh-id",
        "L3if-id",
        "Mcast-group-id",
        "Acl-entry-id",
        "Policer-id ",
        "Stats-id ",
        CTC_CLI_GCHIP_DESC,
        CTC_CLI_GCHIP_ID_DESC)
{
    int32 ret = 0;
    uint8 index = 0;
    ctc_app_index_t app_index = {0};


    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("tunnel-id");
    if (index != 0xFF)
    {
        app_index.index_type = CTC_APP_INDEX_TYPE_MPLS_TUNEL_ID;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("nh-id");
    if (index != 0xFF)
    {
        app_index.index_type = CTC_APP_INDEX_TYPE_NHID;
    }


    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l3if-id");
    if (index != 0xFF)
    {
        app_index.index_type = CTC_APP_INDEX_TYPE_L3IF_ID;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("mcast-group-id");
    if (index != 0xFF)
    {
        app_index.index_type = CTC_APP_INDEX_TYPE_MCAST_GROUP_ID;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("acl-entry-id");
    if (index != 0xFF)
    {
        app_index.index_type = CTC_APP_INDEX_TYPE_ACL_ENTRY_ID;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("policer-id");
    if (index != 0xFF)
    {
        app_index.index_type = CTC_APP_INDEX_TYPE_POLICER_ID;
    }
    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("stats-id");
    if (index != 0xFF)
    {
        app_index.index_type = CTC_APP_INDEX_TYPE_STATSID_ID;
    }
    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("gchip");
    if (index != 0xFF)
    {

	   CTC_CLI_GET_UINT8("gchip", app_index.gchip, argv[index + 1]);
    }

    ret = ctc_app_index_alloc(&app_index);
    if (ret < 0)
    {
        ctc_cli_out("%% %s\n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    ctc_cli_out("%%Alloc offset by APP-Index, index: %u entry_num: %d\n", app_index.index, app_index.entry_num);

    return CLI_SUCCESS;
}



CTC_CLI(ctc_cli_app_index_free,
        ctc_cli_app_index_free_cmd,
        "app index free (tunnel-id|nh-id|l3if-id|global-dsnh-offset (entry-num ENTRY-NUM|)|mcast-group-id|\
        acl-entry-id|policer-id|stats-id) (index INDEX)  (gchip GCHIP|)",
        CTC_CLI_APP_M_STR,
        "Index",
        "Free",
        "Tunnel-id" ,
        "Nh-id",
        "L3if-id",
        "Global-dsnh-offset",
        "Entry num",
        "The value of entry num",
        "Mcast-group-id",
        "Acl-entry-id" ,
        "Policer-id ",
        "Stats-id ",
        "Index",
        "Start index to free",
        CTC_CLI_GCHIP_DESC,
        CTC_CLI_GCHIP_ID_DESC)
{
    int32 ret = 0;
    uint8 index = 0;
    ctc_app_index_t app_index = {0};
    app_index.entry_num = 1;
	app_index.index_type = CTC_APP_INDEX_TYPE_MAX;

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("tunnel-id");
    if (index != 0xFF)
    {
        app_index.index_type = CTC_APP_INDEX_TYPE_MPLS_TUNEL_ID;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("nh-id");
    if (index != 0xFF)
    {
        app_index.index_type = CTC_APP_INDEX_TYPE_NHID;
    }


    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l3if-id");
    if (index != 0xFF)
    {
        app_index.index_type = CTC_APP_INDEX_TYPE_L3IF_ID;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("global-dsnh-offset");
    if (index != 0xFF)
    {
        app_index.index_type = CTC_APP_INDEX_TYPE_GLOBAL_DSNH_OFFSET;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("mcast-group-id");
    if (index != 0xFF)
    {
        app_index.index_type = CTC_APP_INDEX_TYPE_MCAST_GROUP_ID;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("acl-entry-id");
    if (index != 0xFF)
    {
        app_index.index_type = CTC_APP_INDEX_TYPE_ACL_ENTRY_ID;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("policer-id");
    if (index != 0xFF)
    {
        app_index.index_type = CTC_APP_INDEX_TYPE_POLICER_ID;
    }
    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("stats-id");
    if (index != 0xFF)
    {
        app_index.index_type = CTC_APP_INDEX_TYPE_STATSID_ID;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("index");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("index", app_index.index, argv[index + 1]);
    }
    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("entry-num");
    if (index != 0xFF)
    {

	   CTC_CLI_GET_UINT8("entry_num", app_index.entry_num, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("gchip");
    if (index != 0xFF)
    {

	   CTC_CLI_GET_UINT8("gchip", app_index.gchip, argv[index + 1]);
    }

    ret = ctc_app_index_free(&app_index);

    if (ret < 0)
    {
        ctc_cli_out("%% %s\n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


CTC_CLI(ctc_cli_app_set_rchip_dsnh_offset_range,
        ctc_cli_app_set_rchip_dsnh_offset_range_cmd,
        "app index dsnh-offset-range (gchip GCHIP min-index MIN-INDEX max-index MAX-INDEX)",
        CTC_CLI_APP_M_STR,
        "Index",
        "Configure remote chip's dsnh-offset-range",
        CTC_CLI_GCHIP_DESC,
        CTC_CLI_GCHIP_ID_DESC,
        "Min dsnh offset",
        "Default to 1",
        "Max dsnh offset",
        "Refer to [GLB_NH_TBL_SIZE] from mem_profile")
{
    int32 ret = 0;
	uint8 gchip = 0;
	uint8 index = 0;
	uint32 min_index = 0;
	uint32 max_index = 0;

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("gchip");
    if (index != 0xFF)
    {

	   CTC_CLI_GET_UINT8("gchip", gchip, argv[index + 1]);
    }
    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("min-index");
    if (index != 0xFF)
    {

	   CTC_CLI_GET_UINT32("min-index", min_index, argv[index + 1]);
    }
	index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("max-index");
    if (index != 0xFF)
    {

	   CTC_CLI_GET_UINT32("max-index", max_index, argv[index + 1]);
    }
    ret = ctc_app_index_set_rchip_dsnh_offset_range( gchip,min_index, max_index);;
    if (ret < 0)
    {
        ctc_cli_out("%% %s\n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }
    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_app_show_index_used_status,
        ctc_cli_app_show_index_used_status_cmd,
        "show app index used-status (tunnel-id|nh-id|l3if-id|global-dsnh-offset (gchip GCHIP)|mcast-group-id|\
        acl-entry-id|policer-id|stats-id)",
        CTC_CLI_SHOW_MEMORY_STR,
        CTC_CLI_APP_M_STR,
        "Index",
        "Used status",
        "Tunnel-id" ,
        "Nh-id",
        "L3if-id",
        "Global-dsnh-offset",
        CTC_CLI_GCHIP_DESC,
        CTC_CLI_GCHIP_ID_DESC,
        "Mcast-group-id",
        "Acl-entry-id" ,
        "Policer-id ",
        "Stats-id ")
{
    int32 ret = 0;
	uint8 index = 0;
    ctc_opf_t opf;
    opf.multiple = 0;
    opf.pool_index = 0;
    opf.reverse = 0;


    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("tunnel-id");
    if (index != 0xFF)
    {
        opf.pool_type = CTC_OPF_TUNNEL_ID;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("nh-id");
    if (index != 0xFF)
    {
     opf.pool_type = CTC_OPF_NHID;
    }


    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("l3if-id");
    if (index != 0xFF)
    {
        opf.pool_type = CTC_OPF_L3IF_ID;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("global-dsnh-offset");
    if (index != 0xFF)
    {
       opf.pool_type = CTC_OPF_GLOBAL_DSNH_OFFSET;
	   index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("gchip");
       if (index != 0xFF)
       {
           CTC_CLI_GET_UINT8("gchip", opf.pool_index, argv[index + 1]);
       }
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("mcast-group-id");
    if (index != 0xFF)
    {
        opf.pool_type = CTC_OPF_MCAST_GROUP_ID;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("acl-entry-id");
    if (index != 0xFF)
    {
       opf.pool_type = CTC_OPF_ACL_ENTRY_ID;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("policer-id");
    if (index != 0xFF)
    {
        opf.pool_type = CTC_OPF_POLICER_ID;
    }
    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("stats-id");
    if (index != 0xFF)
    {
       opf.pool_type = CTC_OPF_STATSID_ID;
    }
    ret = ctc_opf_print_alloc_info(&opf);
    if (ret < 0)
    {
        ctc_cli_out("%% %s\n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }


    return CLI_SUCCESS;
}

CTC_CLI(ctc_cli_app_vlan_port_init,
        ctc_cli_app_vlan_port_init_cmd,
        "app vlan-port module init",
         CTC_CLI_APP_M_STR,
        "Vlan port",
        "Module",
        "init")
{
    uint8 lchip = 0;
    int32 ret = 0;

    ret = ctc_app_vlan_port_init(lchip, NULL);


    if (ret < 0)
    {
        ctc_cli_out("%% %s\n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }


    return CLI_SUCCESS;

}


CTC_CLI(ctc_cli_app_vlan_port_create_nni_port,
        ctc_cli_app_vlan_port_create_nni_port_cmd,
        "app vlan-port (create|destroy) nni-port (port GPORT)",
        CTC_CLI_APP_M_STR,
        "Vlan port",
        "Create",
        "Destroy",
        "NNI port",
        "Port",
        "Value")
{
    int32 ret = 0;
    uint8 index = 0;
    ctc_app_nni_t nni_port;
    uint8 is_destroy = 0;
    uint8 lchip = 0;

   sal_memset(&nni_port, 0, sizeof(ctc_app_nni_t));

   index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("destroy");
   if (index != 0xFF)
   {
       is_destroy = 1;
   }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("port", nni_port.port, argv[index + 1]);
    }

    if (is_destroy)
    {
        ret = ctc_app_vlan_port_destory_nni(lchip, &nni_port);
    }
    else
    {
        ret = ctc_app_vlan_port_create_nni(lchip, &nni_port);
    }


    if (ret < 0)
    {
        ctc_cli_out("%% %s\n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;

}




CTC_CLI(ctc_cli_app_vlan_port_create_gem_port,
        ctc_cli_app_vlan_port_create_gem_port_cmd,
        "app vlan-port (create|destroy)  gem-port (port GPORT tunnel-value TUNNEL)",
        CTC_CLI_APP_M_STR,
        "Vlan port",
        "Create",
        "Destroy",
        "GEM port",
        "Port",
        "Value",
        "Tunnel value (tunnel vlan)",
        "Value")
{
    int32 ret = 0;
    uint8 index = 0;
    ctc_app_gem_port_t gem_port;
    uint8 is_destroy = 0;
    uint8 lchip = 0;

   sal_memset(&gem_port, 0, sizeof(ctc_app_gem_port_t));

   index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("destroy");
   if (index != 0xFF)
   {
       is_destroy = 1;
   }


    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("port", gem_port.port, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("tunnel-value");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("tunnel value", gem_port.tunnel_value, argv[index + 1]);
    }

    if (is_destroy)
    {
        ret = ctc_app_vlan_port_destory_gem_port(lchip, &gem_port);
    }
    else
    {
        ret = ctc_app_vlan_port_create_gem_port(lchip, &gem_port);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% %s\n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    if (!is_destroy)
    {
        ctc_cli_out("gem logic port         : %d\n",   gem_port.logic_port);
        ctc_cli_out("gem associate port     : 0x%x\n", gem_port.ga_gport);
    }

    return CLI_SUCCESS;

}



#define CTC_CLI_APP_VLAN_ACTION_OP "(none|add|del|replace)"

#define CTC_CLI_APP_VLAN_ACTION " (svlan " CTC_CLI_APP_VLAN_ACTION_OP " (new-svid SVID|) |) " \
                                " (scos  " CTC_CLI_APP_VLAN_ACTION_OP " (new-scos SCOS|) |) " \
                                " (cvlan " CTC_CLI_APP_VLAN_ACTION_OP " (new-cvid CVID|) |) " \
                                " (ccos  " CTC_CLI_APP_VLAN_ACTION_OP " (new-ccos CCOS|) |) "


#define CTC_CLI_APP_VLAN_ACTION_OP_DSCP \
    "None",       \
    "Add",        \
    "Del",        \
    "Replace"     \


#define CTC_CLI_APP_VLAN_ACTION_DSCP \
    "Svlan",                              \
    CTC_CLI_APP_VLAN_ACTION_OP_DSCP,      \
    "New svid",                            \
    "Svlan value",                        \
    "Scos",                               \
    CTC_CLI_APP_VLAN_ACTION_OP_DSCP,      \
    "New scos",                            \
    "Scos value",                         \
    "Cvlan",                              \
    CTC_CLI_APP_VLAN_ACTION_OP_DSCP,      \
    "New cvid",                            \
    "Cvlan value",                        \
    "Ccos",                               \
    CTC_CLI_APP_VLAN_ACTION_OP_DSCP,      \
    "New cos",                            \
    "Cos value"                           \



 static int32
_ctc_app_cli_parser_vlan_action(unsigned char argc,
                                    char** argv,
                                    uint8 start,
                                    char *field,
                                    uint32* p_vlan_action,
                                    uint16* p_new_value)
{
    uint8 index = 0;
    uint8 start_index = 0;
    uint16 value = 0;

    start_index = CTC_CLI_GET_SPECIFIC_INDEX(field, start);
    if (start_index == 0xFF)
    {
        return 0;
    }

    index = start + start_index + 1;

    if (CLI_CLI_STR_EQUAL("none", index))
    {
        *p_vlan_action = CTC_APP_VLAN_ACTION_NONE;
    }
    else if(CLI_CLI_STR_EQUAL("add", index))
    {
        *p_vlan_action = CTC_APP_VLAN_ACTION_ADD;
    }
    else if(CLI_CLI_STR_EQUAL("del", index))
    {
        *p_vlan_action = CTC_APP_VLAN_ACTION_DEL;
    }
    else if(CLI_CLI_STR_EQUAL("replace", index))
    {
        *p_vlan_action = CTC_APP_VLAN_ACTION_REPLACE;
    }

    index = start + start_index + 2;

    if (argv[(index)])
    {
        if (CLI_CLI_STR_EQUAL("new-svid", index))
        {
            CTC_CLI_GET_UINT16("new svid", value, argv[index + 1]);
        }
        else if(CLI_CLI_STR_EQUAL("new-scos", index))
        {
            CTC_CLI_GET_UINT16("new scos", value, argv[index + 1]);
        }
        else if(CLI_CLI_STR_EQUAL("new-cvid", index))
        {
            CTC_CLI_GET_UINT16("new cvid", value, argv[index + 1]);
        }
        else if(CLI_CLI_STR_EQUAL("new-ccos", index))
        {
            CTC_CLI_GET_UINT16("new ccos", value, argv[index + 1]);
        }
        *p_new_value = value;
    }


    return 0;

}

CTC_CLI(ctc_cli_app_vlan_port_create,
        ctc_cli_app_vlan_port_create_cmd,
        "app vlan-port (create|destroy)  vlan-port (port GPORT match-tunnel-value TUNNEL match-svlan SVLAN {match-cvlan CVLAN| match-svlan-end SVLAN| }) \
        (igs-vlan-action" CTC_CLI_APP_VLAN_ACTION "|) \
        (egs-vlan-action" CTC_CLI_APP_VLAN_ACTION "|) (priority PRIORITY|)",
        CTC_CLI_APP_M_STR,
        "Vlan port",
        "Create",
        "Destroy",
        "Vlan port",
        "Port",
        "Value",
        "Tunnel value (tunnel vlan)",
        "Value",
        "Svlan",
        "Value",
        "Cvlan",
        "Value",
        "Svlan end",
        "Value",
        "Ingress vlan action",
        CTC_CLI_APP_VLAN_ACTION_DSCP,
        "Egress vlan action",
        CTC_CLI_APP_VLAN_ACTION_DSCP,
        "Priority",
        "Value")
{
    int32 ret = 0;
    uint8 index = 0;
    uint8 start_index = 0;
    ctc_app_vlan_port_t vlan_port;
    uint8 is_destroy = 0;
    uint8 lchip = 0;

   sal_memset(&vlan_port, 0, sizeof(ctc_app_vlan_port_t));


   index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("destroy");
   if (index != 0xFF)
   {
       is_destroy = 1;
   }

    /*match key*/
    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("port");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("port", vlan_port.port, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("match-tunnel-value");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("tunnel value", vlan_port.match_tunnel_value, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("match-svlan");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("macth svlan value", vlan_port.match_svlan, argv[index + 1]);
        vlan_port.criteria = CTC_APP_VLAN_PORT_MATCH_PORT_TUNNEL_SVLAN;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("match-cvlan");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("macth cvlan value", vlan_port.match_cvlan, argv[index + 1]);
        vlan_port.criteria = CTC_APP_VLAN_PORT_MATCH_PORT_TUNNEL_SVLAN_CVLAN;
    }


    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("match-svlan-end");
    if (index != 0xFF)
    {
        CTC_CLI_GET_UINT32("macth svlan end value", vlan_port.match_svlan_end, argv[index + 1]);
    }


    /*igress action*/
    start_index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("igs-vlan-action");

    if (start_index != 0xFF)
    {
        _ctc_app_cli_parser_vlan_action(argc,
                                        &argv[0],
                                        start_index,
                                        "svlan",
                                        &vlan_port.ingress_vlan_action_set.svid,
                                        &vlan_port.ingress_vlan_action_set.new_svid);



        _ctc_app_cli_parser_vlan_action(argc,
                                        &argv[0],
                                        start_index,
                                        "scos",
                                        &vlan_port.ingress_vlan_action_set.scos,
                                        &vlan_port.ingress_vlan_action_set.new_scos);



        _ctc_app_cli_parser_vlan_action(argc,
                                        &argv[0],
                                        start_index,
                                        "cvlan",
                                        &vlan_port.ingress_vlan_action_set.cvid,
                                        &vlan_port.ingress_vlan_action_set.new_cvid);


        _ctc_app_cli_parser_vlan_action(argc,
                                        &argv[0],
                                        start_index,
                                        "ccos",
                                        &vlan_port.ingress_vlan_action_set.ccos,
                                        &vlan_port.ingress_vlan_action_set.new_ccos);


    }


    /*egress action*/
    start_index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("egs-vlan-action");

    if (start_index != 0xFF)
    {
        _ctc_app_cli_parser_vlan_action(argc,
                                        &argv[0],
                                        start_index,
                                        "svlan",
                                        &vlan_port.egress_vlan_action_set.svid,
                                        &vlan_port.egress_vlan_action_set.new_svid);



        _ctc_app_cli_parser_vlan_action(argc,
                                        &argv[0],
                                        start_index,
                                        "scos",
                                        &vlan_port.egress_vlan_action_set.scos,
                                        &vlan_port.egress_vlan_action_set.new_scos);



        _ctc_app_cli_parser_vlan_action(argc,
                                        &argv[0],
                                        start_index,
                                        "cvlan",
                                        &vlan_port.egress_vlan_action_set.cvid,
                                        &vlan_port.egress_vlan_action_set.new_cvid);


        _ctc_app_cli_parser_vlan_action(argc,
                                        &argv[0],
                                        start_index,
                                        "ccos",
                                        &vlan_port.egress_vlan_action_set.ccos,
                                        &vlan_port.egress_vlan_action_set.new_ccos);

    }



    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("priority");
    if (index != 0xFF)
    {
        CTC_SET_FLAG(vlan_port.flags, CTC_APP_VLAN_PORT_FLAG_PRIORITY);
        CTC_CLI_GET_UINT32("priority", vlan_port.priority, argv[index + 1]);
    }

    if (is_destroy)
    {
        ret = ctc_app_vlan_port_destory(lchip, &vlan_port);
    }
    else
    {
        ret = ctc_app_vlan_port_create(lchip, &vlan_port);
    }

    if (ret < 0)
    {
        ctc_cli_out("%% %s\n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    if (!is_destroy)
    {
        ctc_cli_out("vlan port id         : %d\n",   vlan_port.vlan_port_id);
    }

    return CLI_SUCCESS;

}


CTC_CLI(ctc_cli_app_vlan_port_destory,
        ctc_cli_app_vlan_port_destory_cmd,
        "app vlan-port destroy vlan-port vlan-port-id ID",
        CTC_CLI_APP_M_STR,
        "Vlan port",
        "Destroy",
        "Vlan port",
        "Vlan port id",
        "Value")
{
    int32 ret = 0;
    uint8 lchip = 0;
    ctc_app_vlan_port_t vlan_port;

    sal_memset(&vlan_port, 0, sizeof(ctc_app_vlan_port_t));

    CTC_CLI_GET_UINT32("vlan port id", vlan_port.vlan_port_id, argv[0]);

    ret = ctc_app_vlan_port_destory(lchip, &vlan_port);

    if (ret < 0)
    {
        ctc_cli_out("%% %s\n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }


    return CLI_SUCCESS;
}

extern int32 ctc_app_vlan_port_show(uint8 lchip, uint8 type);

CTC_CLI(ctc_cli_app_vlan_port_show,
        ctc_cli_app_vlan_port_show_cmd,
        "show app vlan-port (status | gem-port | vlan-port)",
        "Show"
        CTC_CLI_APP_M_STR,
        "Status",
        "Gem port",
        "Vlan port")
{
    int32 ret = 0;
    uint8 index = 0;
    uint8 type = 0;
    uint8 lchip = 0;

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("gem-port");
    if (index != 0xFF)
    {
        type = 1;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("vlan-port");
    if (index != 0xFF)
    {
        type = 2;
    }

    index = CTC_CLI_GET_ARGC_INDEX_ENHANCE("status");
    if (index != 0xFF)
    {
        type = 0;
    }


    ret = ctc_app_vlan_port_show(lchip, type);

    if (ret < 0)
    {
        ctc_cli_out("%% %s\n", ctc_get_error_desc(ret));
        return CLI_ERROR;
    }

    return CLI_SUCCESS;
}


int32
ctc_app_cli_init(void)
{
    install_element(CTC_SDK_MODE, &ctc_cli_app_packet_show_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_app_packet_print_rx_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_app_packet_create_socket_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_app_packet_destroy_socket_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_app_debug_on_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_app_debug_off_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_app_index_alloc_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_app_index_free_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_app_set_rchip_dsnh_offset_range_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_app_show_index_used_status_cmd);

    install_element(CTC_SDK_MODE, &ctc_cli_app_vlan_port_init_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_app_vlan_port_create_gem_port_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_app_vlan_port_create_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_app_vlan_port_destory_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_app_vlan_port_create_nni_port_cmd);
    install_element(CTC_SDK_MODE, &ctc_cli_app_vlan_port_show_cmd);

    return CLI_SUCCESS;
}


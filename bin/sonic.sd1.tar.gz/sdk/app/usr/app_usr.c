/**
 @file app_usr.c

 @date 2010-06-09

 @version v2.0

 User define code
*/

/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "app_usr.h"


/**************************************************/
/*    Following pseudocode is used for system adapter reference   */
/**************************************************/
/*
void
ctc_app_link_monitor_thread(void* para)
{
    uint16 lport = 0;
    uint16 gport = 0;
    uint8 gchip = 0;
    uint32 mac_en = 0;
    bool is_up = 0;
    uint32 is_detect = 0;
    uint8 lchip = 0;
    uint8 lchip_num = 0;
    int32 ret = 0;

    ctc_get_local_chip_num(&lchip_num);

    while(1)
    {
        for (lchip = 0; lchip < lchip_num; lchip++)
        {
            ctc_get_gchip_id(lchip, &gchip);

            for (lport = 0; lport < CTC_MAX_PHY_PORT; lport++)
            {
                mac_en = 0;
                is_up = 0;

                gport = CTC_MAP_LPORT_TO_GPORT(gchip, lport);

                //Step1: get signal detect
                ret = ctc_port_get_property(gport, CTC_PORT_PROP_SIGNAL_DETECT, &is_detect);
                if (ret < 0)
                {
                    continue;
                }

                //Step2: If signal detect, need enable mac
                if (is_detect)
                {
                    ret = ctc_port_set_mac_en(gport, TRUE);
                    if (ret < 0)
                    {
                        continue;
                    }
                }
                else
                {
                    continue;
                }

                //Step3: Get mac linkup
                //If using ext phy, should get phy link status, else f using Mac Pcs directly get link from mac pcs
                ret = ctc_port_get_mac_link_up(gport, &is_up);
                if (ret < 0)
                {
                    continue;
                }

                Step4: If using link down interrupt, do interrupt enable
                ctc_port_set_property(gport,CTC_PORT_PROP_LINK_INTRRUPT_EN,TRUE);

                Step5: If mac link up, do port enable
                if (is_detect)
                {
                    ret = ctc_port_set_property(gport,CTC_PORT_PROP_PORT_EN,TRUE);
                    if (ret < 0)
                    {
                        continue;
                    }

                    //Do other thing
                }
            }
        }

        sal_task_sleep(100);
    }

    return;
}
*/
extern int32 ctc_register_cli_exec_cb(void* cb);
extern int cli_com_source_file(ctc_cmd_element_t *, ctc_vti_t *, int, char **);
extern ctc_cmd_element_t cli_com_source_file_cmd;
extern ctc_vti_t *g_ctc_vti;

int32 ctc_cli_exec()
{
    char *argv[1];
    argv[0] = (char*)START_UP_CONFIG;

    if (0 == SDK_WORK_PLATFORM)
    {
        if (NULL == sal_fopen((char*)START_UP_CONFIG, "r"))
        {
            CTC_APP_DBG_OUT(CTC_DEBUG_LEVEL_DUMP, "Use default FFE config\n");
        }
        else
        {
            cli_com_source_file(&cli_com_source_file_cmd, g_ctc_vti, 1, argv);
        }
    }

    return CTC_E_NONE;
}



int32
ctc_app_usr_init(void)
{

    ctc_register_cli_exec_cb(ctc_cli_exec);



    return CTC_E_NONE;
}



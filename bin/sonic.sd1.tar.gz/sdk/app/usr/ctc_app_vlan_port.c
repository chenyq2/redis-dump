
#if 1

#include "ctc_app.h"
#include "ctc_app_vlan_port.h"

#include "ctc_api.h"
#include "ctcs_api.h"
#include "ctc_hash.h"
#include "ctc_opf.h"


enum ctc_app_vlan_port_nhid_e
{
   CTC_APP_VLAN_PORT_NHID_RSV_ILOOP = CTC_NH_RESERVED_NHID_MAX, /*3*/
   CTC_APP_VLAN_PORT_NHID_RSV_E2ILOOP, /*4*/
   CTC_APP_VLAN_PORT_NHID_ALLOC,       /*5*/
   CTC_APP_VLAN_PORT_NHID_MAX
};
typedef enum ctc_app_vlan_port_nhid_e ctc_app_vlan_port_nhid_t;


enum ctc_app_vlan_port_opf_e
{
   CTC_APP_VLAN_PORT_OPF_GEM_PORT,  /*logic port for gem port*/
   CTC_APP_VLAN_PORT_OPF_VLAN_PORT,  /*logic port for vlan port*/
   CTC_APP_VLAN_PORT_OPF_NNI_PORT,  /*logic port for uplink nni port*/
   CTC_APP_VLAN_PORT_OPF_MAX
};
typedef enum ctc_app_vlan_port_opf_e ctc_app_vlan_port_opf_t;

struct ctc_app_vlan_port_master_s
{
    uint16 gem_port_iloop_port;
    uint16 gem_port_eloop_port;
    uint16 gem_port_illop_nhid;
    uint16 gem_port_xlate_e2iloop_nhid;
    ctc_hash_t *gem_port_hash;
    ctc_hash_t *vlan_port_hash;

    uint16 gem_port_cnt;
    uint16 vlan_port_cnt;
    uint16 nni_port_cnt;
};
typedef struct ctc_app_vlan_port_master_s ctc_app_vlan_port_master_t;

struct ctc_app_vlan_port_gem_port_db_s
{
  uint32 port;
  uint32 tunnel_value;

  uint32 logic_port;
  uint32 ref_cnt;
};
typedef struct ctc_app_vlan_port_gem_port_db_s ctc_app_vlan_port_gem_port_db_t;

struct ctc_app_vlan_port_db_s
{
  uint32 criteria;
  uint32 port;
  uint32 tunnel_value;
  uint16 match_svlan;
  uint16 match_cvlan;
  uint16 match_svlan_end;
  uint16 match_cvlan_end;
  uint32 logic_port;

  uint8 egs_vlan_mapping_en;
  ctc_app_vlan_port_gem_port_db_t *p_gem_port_db;

};
typedef struct ctc_app_vlan_port_db_s ctc_app_vlan_port_db_t;


struct ctc_app_vlan_port_find_s
{
  uint32 logic_port;
  ctc_app_vlan_port_db_t *p_vlan_port_db;
};
typedef struct ctc_app_vlan_port_find_s ctc_app_vlan_port_find_t;


#define CTC_APP_VLAN_PORT_GEM_PORT_NUM 2*1024
#define CTC_APP_VLAN_PORT_VLAN_PORT_NUM 13*1024
#define CTC_APP_VLAN_PORT_NNI_PORT_NUM 1*1024

#define CTC_APP_MAP_VLAN_PORT_NHID(port) (port+CTC_APP_VLAN_PORT_NHID_ALLOC)
#define CTC_APP_VLAN_PORT_DEFULAT_FID 1

#define CTC_APP_VLAN_PORT_INIT_CHECK() \
    do {\
        if(NULL == p_g_app_vlan_port_master) return CTC_E_NOT_INIT;\
     }while(0);


#define CTC_APP_DBG_FUNC()          CTC_APP_DBG_OUT(CTC_DEBUG_LEVEL_FUNC, "%s()\n", __FUNCTION__)
#define CTC_APP_DBG_INFO(FMT, ...)  CTC_APP_DBG_OUT(CTC_DEBUG_LEVEL_INFO, FMT, ##__VA_ARGS__)
#define CTC_APP_DBG_ERROR(FMT, ...) CTC_APP_DBG_OUT(CTC_DEBUG_LEVEL_ERROR, FMT, ##__VA_ARGS__)
#define CTC_APP_DBG_PARAM(FMT, ...) CTC_APP_DBG_OUT(CTC_DEBUG_LEVEL_PARAM, FMT, ##__VA_ARGS__)
#define CTC_APP_DBG_DUMP(FMT, ...)  CTC_APP_DBG_OUT(CTC_DEBUG_LEVEL_DUMP, FMT, ##__VA_ARGS__)

#define CTC_APP_DBG_PARAM_ST(param) CTC_APP_DBG_PARAM("%-40s :%10d\n", #param, p_vlan_port->param)


ctc_app_vlan_port_master_t *p_g_app_vlan_port_master = NULL;



int32
_ctc_app_vlan_port_match_vlan_port(ctc_app_vlan_port_db_t *p_vlan_port_db,
                                   ctc_app_vlan_port_find_t *p_vlan_port_match)
{
    CTC_PTR_VALID_CHECK(p_vlan_port_match);
    CTC_PTR_VALID_CHECK(p_vlan_port_db);

    if (p_vlan_port_db->logic_port == p_vlan_port_match->logic_port)
    {
        p_vlan_port_match->p_vlan_port_db = p_vlan_port_db;
        return -1;
    }

    return 0;
}

ctc_app_vlan_port_db_t*
_ctc_app_vlan_port_find_vlan_port_db(uint8 lchip, uint32 logic_port)
{
    ctc_app_vlan_port_find_t vlan_port_find;

    sal_memset(&vlan_port_find, 0, sizeof(vlan_port_find));

    vlan_port_find.logic_port = logic_port;
    ctc_hash_traverse(p_g_app_vlan_port_master->vlan_port_hash,
                      (hash_traversal_fn)_ctc_app_vlan_port_match_vlan_port, &vlan_port_find);

    return vlan_port_find.p_vlan_port_db;
}



static uint32
_ctc_app_vlan_port_hash_gem_port_make(ctc_app_vlan_port_gem_port_db_t *p_gem_port_db)
{
    uint32 data[2] = {0};
    uint32 length = 0;

    data[0] = p_gem_port_db->port;
    data[1] = p_gem_port_db->tunnel_value;
    length = sizeof(uint32)*2;

    return ctc_hash_caculate(length, (uint8*)data);
}

static bool
_ctc_app_vlan_port_hash_gem_port_cmp(ctc_app_vlan_port_gem_port_db_t *p_data0,
                                     ctc_app_vlan_port_gem_port_db_t *p_data1)
{
    if (p_data0->port == p_data1->port &&
        p_data0->tunnel_value == p_data1->tunnel_value)
    {
        return TRUE;
    }

    return FALSE;
}


static uint32
_ctc_app_vlan_port_hash_make(ctc_app_vlan_port_db_t *p_vlan_port_db)
{
    uint32 data[4] = {0};
    uint32 length = 0;

    data[0] = p_vlan_port_db->port;
    data[1] = p_vlan_port_db->tunnel_value;
    data[2] = ((p_vlan_port_db->match_svlan << 16) | p_vlan_port_db->match_cvlan);
    data[3] = ((p_vlan_port_db->match_svlan_end << 16) | p_vlan_port_db->match_cvlan_end);
    length = sizeof(uint32)*4;

    return ctc_hash_caculate(length, (uint8*)data);
}

static bool
_ctc_app_vlan_port_hash_cmp(ctc_app_vlan_port_db_t *p_data0,
                            ctc_app_vlan_port_db_t *p_data1)
{
    if (p_data0->port == p_data1->port &&
        p_data0->tunnel_value == p_data1->tunnel_value &&
        p_data0->match_svlan == p_data1->match_svlan &&
        p_data0->match_cvlan == p_data1->match_cvlan &&
        p_data0->match_svlan_end == p_data1->match_svlan_end &&
        p_data0->match_cvlan_end == p_data1->match_cvlan_end)
    {
        return TRUE;
    }

    return FALSE;
}


int32
ctc_app_vlan_port_create_gem_port(uint8 lchip, ctc_app_gem_port_t *p_gem_port)
{
    int32 ret = 0;
    uint32 logic_port = 0;
    uint8 gchip = 0;
    ctc_opf_t opf;
    ctc_vlan_mapping_t vlan_mapping;
    ctc_port_scl_property_t scl_prop;
    ctc_vlan_edit_nh_param_t gem_xlate_nh;
    ctc_app_vlan_port_gem_port_db_t gem_port_db;
    ctc_app_vlan_port_gem_port_db_t *p_gem_port_db = NULL;

    /* CHECK */
    CTC_PTR_VALID_CHECK(p_gem_port);
    CTC_APP_VLAN_PORT_INIT_CHECK();


    /* Debug */
    CTC_APP_DBG_PARAM("-------------------------------------------------\n");
    CTC_APP_DBG_PARAM("%-40s :%10d\n", "port", p_gem_port->port);
    CTC_APP_DBG_PARAM("%-40s :%10d\n", "port", p_gem_port->tunnel_value);


    /* DB */
    sal_memset(&gem_port_db, 0, sizeof(gem_port_db));
    gem_port_db.port = p_gem_port->port;
    gem_port_db.tunnel_value = p_gem_port->tunnel_value;
    p_gem_port_db = ctc_hash_lookup(p_g_app_vlan_port_master->gem_port_hash, &gem_port_db);
    if (NULL != p_gem_port_db)
    {
        return CTC_E_EXIST;
    }

    MALLOC_POINTER(ctc_app_vlan_port_gem_port_db_t, p_gem_port_db);
    if (NULL == p_gem_port_db)
    {
        return CTC_E_NO_MEMORY;
    }

    sal_memset(p_gem_port_db, 0, sizeof(ctc_app_vlan_port_gem_port_db_t));
    p_gem_port_db->port = p_gem_port->port;
    p_gem_port_db->tunnel_value = p_gem_port->tunnel_value;

    /* OPF */
    sal_memset(&opf, 0, sizeof(opf));
    opf.pool_type = CTC_OPF_VLAN_PORT;
    opf.pool_index = CTC_APP_VLAN_PORT_OPF_GEM_PORT;
    CTC_ERROR_GOTO(ctc_opf_alloc_offset(&opf, 1, &logic_port), ret, free_meomory);
    p_gem_port_db->logic_port = logic_port;
    p_gem_port->logic_port = logic_port;

    ctc_get_gchip_id(lchip, &gchip);
    p_gem_port->ga_gport = CTC_MAP_LPORT_TO_GPORT(gchip, p_g_app_vlan_port_master->gem_port_iloop_port);


    CTC_APP_DBG_INFO("OPF gem logic port: %d\n", logic_port);

    /* Add vlan mapping */
    sal_memset(&vlan_mapping, 0, sizeof(vlan_mapping));
    CTC_SET_FLAG(vlan_mapping.key, CTC_VLAN_MAPPING_KEY_SVID);
    vlan_mapping.old_svid = p_gem_port->tunnel_value;
    CTC_SET_FLAG(vlan_mapping.action, CTC_VLAN_MAPPING_OUTPUT_LOGIC_SRC_PORT);
    CTC_SET_FLAG(vlan_mapping.action, CTC_VLAN_MAPPING_OUTPUT_NHID);
    CTC_SET_FLAG(vlan_mapping.action, CTC_VLAN_MAPPING_OUTPUT_SVID);
    vlan_mapping.stag_op = CTC_VLAN_TAG_OP_DEL;
    vlan_mapping.logic_src_port = logic_port;
    vlan_mapping.u3.nh_id = p_g_app_vlan_port_master->gem_port_xlate_e2iloop_nhid;
    CTC_ERROR_GOTO(ctc_vlan_add_vlan_mapping(p_gem_port->port, &vlan_mapping), ret, roll_back_0);


    /* Enable scl lookup for svlan */
    sal_memset(&scl_prop, 0, sizeof(scl_prop));
    scl_prop.scl_id = 0;
    scl_prop.direction = CTC_INGRESS;
    scl_prop.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_PORT_SVLAN;
    scl_prop.action_type = CTC_PORT_SCL_ACTION_TYPE_SCL;
    CTC_ERROR_GOTO(ctc_port_set_scl_property(p_gem_port->port, &scl_prop), ret, roll_back_1);


    /* Create xlate nh */
    sal_memset(&gem_xlate_nh, 0, sizeof(gem_xlate_nh));
    gem_xlate_nh.gport_or_aps_bridge_id = p_gem_port->port;
    gem_xlate_nh.vlan_edit_info.svlan_edit_type = CTC_VLAN_EGRESS_EDIT_INSERT_VLAN;
    gem_xlate_nh.vlan_edit_info.cvlan_edit_type = CTC_VLAN_EGRESS_EDIT_KEEP_VLAN_UNCHANGE;
    gem_xlate_nh.vlan_edit_info.output_svid = p_gem_port->tunnel_value;
    gem_xlate_nh.vlan_edit_info.edit_flag = CTC_VLAN_EGRESS_EDIT_OUPUT_SVID_VALID;
    CTC_APP_DBG_INFO("nh xlate nhid: %d\n", CTC_APP_MAP_VLAN_PORT_NHID(logic_port));
    CTC_ERROR_GOTO(ctc_nh_add_xlate(CTC_APP_MAP_VLAN_PORT_NHID(logic_port), &gem_xlate_nh), ret, roll_back_2);

    /* DB & STATS */
    ctc_hash_insert(p_g_app_vlan_port_master->gem_port_hash, p_gem_port_db);
    p_g_app_vlan_port_master->gem_port_cnt++;

    return CTC_E_NONE;



   /*-----------------------------------------------------------
   *** rool back
   -----------------------------------------------------------*/

    roll_back_2:
    scl_prop.scl_id = 0;
    scl_prop.direction = CTC_INGRESS;
    scl_prop.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_DISABLE;
    ctc_port_set_scl_property(p_gem_port->port, &scl_prop);

    roll_back_1:
    ctc_vlan_remove_vlan_mapping(p_gem_port->port, &vlan_mapping);

    roll_back_0:
    ctc_opf_free_offset(&opf, 1, logic_port);

    free_meomory:
    mem_free(p_gem_port_db);
    p_gem_port_db = NULL;

    return ret;
}


int32
ctc_app_vlan_port_destory_gem_port(uint8 lchip, ctc_app_gem_port_t *p_gem_port)
{
    uint32 logic_port = 0;
    ctc_opf_t opf;
    ctc_vlan_mapping_t vlan_mapping;
    ctc_port_scl_property_t scl_prop;
    ctc_app_vlan_port_gem_port_db_t gem_port_db;
    ctc_app_vlan_port_gem_port_db_t *p_gem_port_db = NULL;

    /* CHECK */
    CTC_PTR_VALID_CHECK(p_gem_port);
    CTC_APP_VLAN_PORT_INIT_CHECK();

    /* Debug */
    CTC_APP_DBG_PARAM("-------------------------------------------------\n");
    CTC_APP_DBG_PARAM("%-40s :%10d\n", "port", p_gem_port->port);
    CTC_APP_DBG_PARAM("%-40s :%10d\n", "port", p_gem_port->tunnel_value);

    /* DB */
    sal_memset(&gem_port_db, 0, sizeof(gem_port_db));
    gem_port_db.port = p_gem_port->port;
    gem_port_db.tunnel_value = p_gem_port->tunnel_value;
    p_gem_port_db = ctc_hash_lookup(p_g_app_vlan_port_master->gem_port_hash, &gem_port_db);
    if (NULL == p_gem_port_db)
    {
        return CTC_E_NOT_EXIST;
    }

    if (p_gem_port_db->ref_cnt)
    {
        return  CTC_E_IN_USE;
    }

    logic_port = p_gem_port_db->logic_port;
    CTC_APP_DBG_INFO("Gem logic port: %d\n", logic_port);

    /* Remove xlate nexthop */
    CTC_APP_DBG_INFO("Gem xlate nhid: %d\n", CTC_APP_MAP_VLAN_PORT_NHID(logic_port));
    CTC_ERROR_RETURN(ctc_nh_remove_xlate(CTC_APP_MAP_VLAN_PORT_NHID(logic_port)));

    /* Disable port scl en */
    sal_memset(&scl_prop, 0, sizeof(scl_prop));
    scl_prop.scl_id = 0;
    scl_prop.direction = CTC_INGRESS;
    scl_prop.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_DISABLE;
    CTC_ERROR_RETURN(ctc_port_set_scl_property(p_gem_port->port, &scl_prop));

    /* Remove vlan mapping */
    sal_memset(&vlan_mapping, 0, sizeof(vlan_mapping));
    CTC_SET_FLAG(vlan_mapping.key, CTC_VLAN_MAPPING_KEY_SVID);
    vlan_mapping.old_svid = p_gem_port->tunnel_value;
    CTC_ERROR_RETURN(ctc_vlan_remove_vlan_mapping(p_gem_port->port, &vlan_mapping));

    /* Free OPF */
    sal_memset(&opf, 0, sizeof(opf));
    opf.pool_type = CTC_OPF_VLAN_PORT;
    opf.pool_index = CTC_APP_VLAN_PORT_OPF_GEM_PORT;
    CTC_ERROR_RETURN(ctc_opf_free_offset(&opf, 1, logic_port));


    ctc_hash_remove(p_g_app_vlan_port_master->gem_port_hash, p_gem_port_db);
    p_g_app_vlan_port_master->gem_port_cnt--;

    mem_free(p_gem_port_db);
    p_gem_port_db = NULL;


    return CTC_E_NONE;
}


static int32
_ctc_app_vlan_port_vlan_mapping(uint8 lchip, ctc_app_vlan_port_t *p_vlan_port,
                               ctc_vlan_mapping_t *p_vlan_mapping)
{
    CTC_APP_VLAN_PORT_INIT_CHECK();

/*SVLAN op*/
    switch(p_vlan_port->ingress_vlan_action_set.svid)
    {
    case CTC_APP_VLAN_ACTION_ADD:
        CTC_SET_FLAG(p_vlan_mapping->action, CTC_VLAN_MAPPING_OUTPUT_SVID);
        p_vlan_mapping->stag_op = CTC_VLAN_TAG_OP_ADD;
        p_vlan_mapping->svid_sl = CTC_VLAN_TAG_SL_NEW;
        p_vlan_mapping->new_svid = p_vlan_port->ingress_vlan_action_set.new_svid;
        break;

    case CTC_APP_VLAN_ACTION_REPLACE:
        CTC_SET_FLAG(p_vlan_mapping->action, CTC_VLAN_MAPPING_OUTPUT_SVID);
        p_vlan_mapping->stag_op = CTC_VLAN_TAG_OP_REP;
        p_vlan_mapping->svid_sl = CTC_VLAN_TAG_SL_NEW;
        p_vlan_mapping->new_svid = p_vlan_port->ingress_vlan_action_set.new_svid;
        break;

     case CTC_APP_VLAN_ACTION_NONE:
        CTC_SET_FLAG(p_vlan_mapping->action, CTC_VLAN_MAPPING_OUTPUT_SVID);
        p_vlan_mapping->stag_op = CTC_VLAN_TAG_OP_NONE;

        break;

    default:
        return CTC_E_INTR_INVALID_PARAM;
    }


    switch(p_vlan_port->ingress_vlan_action_set.cvid)
    {
    case CTC_APP_VLAN_ACTION_ADD:
        CTC_SET_FLAG(p_vlan_mapping->action, CTC_VLAN_MAPPING_OUTPUT_CVID);
        p_vlan_mapping->ctag_op = CTC_VLAN_TAG_OP_ADD;
        p_vlan_mapping->cvid_sl = CTC_VLAN_TAG_SL_NEW;
        p_vlan_mapping->new_cvid = p_vlan_port->ingress_vlan_action_set.new_cvid;
        break;

    case CTC_APP_VLAN_ACTION_REPLACE:
        CTC_SET_FLAG(p_vlan_mapping->action, CTC_VLAN_MAPPING_OUTPUT_CVID);
        p_vlan_mapping->ctag_op = CTC_VLAN_TAG_OP_REP;
        p_vlan_mapping->cvid_sl = CTC_VLAN_TAG_SL_NEW;
        p_vlan_mapping->new_cvid = p_vlan_port->ingress_vlan_action_set.new_cvid;
        break;

     case CTC_APP_VLAN_ACTION_NONE:
        CTC_SET_FLAG(p_vlan_mapping->action, CTC_VLAN_MAPPING_OUTPUT_CVID);
        p_vlan_mapping->ctag_op = CTC_VLAN_TAG_OP_NONE;

        break;

    default:
        return CTC_E_INTR_INVALID_PARAM;
    }



    switch(p_vlan_port->ingress_vlan_action_set.scos)
    {
    case CTC_APP_VLAN_ACTION_ADD:
    case CTC_APP_VLAN_ACTION_REPLACE:
        p_vlan_mapping->scos_sl = CTC_VLAN_TAG_SL_NEW;
        p_vlan_mapping->new_scos = p_vlan_port->ingress_vlan_action_set.new_scos;
        break;

    case  CTC_APP_VLAN_ACTION_NONE:
        p_vlan_mapping->scos_sl = CTC_VLAN_TAG_SL_AS_PARSE;
        break;

    default:
        return CTC_E_INTR_INVALID_PARAM;
    }


    switch(p_vlan_port->ingress_vlan_action_set.ccos)
    {
    case CTC_APP_VLAN_ACTION_ADD:
    case CTC_APP_VLAN_ACTION_REPLACE:
        p_vlan_mapping->ccos_sl = CTC_VLAN_TAG_SL_NEW;
        p_vlan_mapping->new_ccos = p_vlan_port->ingress_vlan_action_set.new_ccos;
        break;

     case CTC_APP_VLAN_ACTION_NONE:
        p_vlan_mapping->ccos_sl = CTC_VLAN_TAG_SL_AS_PARSE;
        break;

    default:
        return CTC_E_INTR_INVALID_PARAM;
    }


    return CTC_E_NONE;
}


static int32
_ctc_app_vlan_port_xlate_mapping(uint8 lchip, ctc_app_vlan_port_t *p_vlan_port,
                               ctc_vlan_egress_edit_info_t *p_xlate)
{
    CTC_APP_VLAN_PORT_INIT_CHECK();

/* SVLAN op */
    switch(p_vlan_port->egress_vlan_action_set.svid)
    {
    case CTC_APP_VLAN_ACTION_DEL:
        p_xlate->svlan_edit_type = CTC_VLAN_EGRESS_EDIT_STRIP_VLAN;
        break;

    case CTC_APP_VLAN_ACTION_REPLACE:
        p_xlate->svlan_edit_type = CTC_VLAN_EGRESS_EDIT_REPLACE_VLAN;
        p_xlate->output_svid = p_vlan_port->egress_vlan_action_set.new_svid;
        CTC_SET_FLAG(p_xlate->edit_flag, CTC_VLAN_EGRESS_EDIT_OUPUT_SVID_VALID);
        break;

     case CTC_APP_VLAN_ACTION_NONE:
        break;

    case CTC_APP_VLAN_ACTION_ADD:
    default:
        return CTC_E_INTR_INVALID_PARAM;
    }

/* CVLAN op */
    switch(p_vlan_port->egress_vlan_action_set.cvid)
    {
    case CTC_APP_VLAN_ACTION_DEL:
        p_xlate->cvlan_edit_type = CTC_VLAN_EGRESS_EDIT_STRIP_VLAN;
        break;

    case CTC_APP_VLAN_ACTION_REPLACE:
        p_xlate->cvlan_edit_type = CTC_VLAN_EGRESS_EDIT_REPLACE_VLAN;
        p_xlate->output_cvid = p_vlan_port->egress_vlan_action_set.new_cvid;
        CTC_SET_FLAG(p_xlate->edit_flag, CTC_VLAN_EGRESS_EDIT_OUPUT_CVID_VALID);
        break;

    case CTC_APP_VLAN_ACTION_NONE:
        break;

    case CTC_APP_VLAN_ACTION_ADD:
    default:
        return CTC_E_INTR_INVALID_PARAM;
    }


/* SCOS op */
    switch(p_vlan_port->egress_vlan_action_set.scos)
    {
    case CTC_APP_VLAN_ACTION_NONE:
        break;

    case CTC_APP_VLAN_ACTION_ADD:
    case CTC_APP_VLAN_ACTION_DEL:
    case CTC_APP_VLAN_ACTION_REPLACE:
    default:
        return CTC_E_INTR_INVALID_PARAM;
    }


/* CCOS op */
    switch(p_vlan_port->egress_vlan_action_set.ccos)
    {
    case CTC_APP_VLAN_ACTION_NONE:
        break;

    case CTC_APP_VLAN_ACTION_ADD:
    case CTC_APP_VLAN_ACTION_DEL:
    case CTC_APP_VLAN_ACTION_REPLACE:
    default:
        return CTC_E_INTR_INVALID_PARAM;
    }

    return CTC_E_NONE;
}




int32
ctc_app_vlan_port_create(uint8 lchip, ctc_app_vlan_port_t *p_vlan_port)
{
    int32 ret = 0;
    uint8 gchip = 0;
    ctc_vlan_mapping_t vlan_mapping;
    ctc_vlan_edit_nh_param_t vlan_xlate_nh;
    ctc_app_vlan_port_gem_port_db_t gem_port_db;
    ctc_app_vlan_port_gem_port_db_t *p_gem_port_db = NULL;
    ctc_app_vlan_port_db_t vlan_port_db;
    ctc_app_vlan_port_db_t *p_vlan_port_db = NULL;
    ctc_opf_t opf;
    uint32 logic_port = 0;

    /* CHECK */
    CTC_APP_VLAN_PORT_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_vlan_port);

    /* Debug */
    CTC_APP_DBG_PARAM("-------------------------------------------------\n");
    CTC_APP_DBG_PARAM_ST(criteria);
    CTC_APP_DBG_PARAM_ST(port);
    CTC_APP_DBG_PARAM_ST(match_tunnel_value);
    CTC_APP_DBG_PARAM_ST(match_svlan);
    CTC_APP_DBG_PARAM_ST(match_cvlan);
    CTC_APP_DBG_PARAM_ST(match_svlan_end);
    CTC_APP_DBG_PARAM_ST(match_cvlan_end);
    CTC_APP_DBG_PARAM_ST(qos_domain);
    CTC_APP_DBG_PARAM_ST(ingress_policer_id);
    CTC_APP_DBG_PARAM_ST(egress_policer_id);

    CTC_APP_DBG_PARAM_ST(ingress_vlan_action_set.svid);
    CTC_APP_DBG_PARAM_ST(ingress_vlan_action_set.new_svid);
    CTC_APP_DBG_PARAM_ST(ingress_vlan_action_set.cvid);
    CTC_APP_DBG_PARAM_ST(ingress_vlan_action_set.new_cvid);
    CTC_APP_DBG_PARAM_ST(ingress_vlan_action_set.scos);
    CTC_APP_DBG_PARAM_ST(ingress_vlan_action_set.new_scos);
    CTC_APP_DBG_PARAM_ST(ingress_vlan_action_set.ccos);
    CTC_APP_DBG_PARAM_ST(ingress_vlan_action_set.new_ccos);

    CTC_APP_DBG_PARAM_ST(egress_vlan_action_set.svid);
    CTC_APP_DBG_PARAM_ST(egress_vlan_action_set.new_svid);
    CTC_APP_DBG_PARAM_ST(egress_vlan_action_set.cvid);
    CTC_APP_DBG_PARAM_ST(egress_vlan_action_set.new_cvid);
    CTC_APP_DBG_PARAM_ST(egress_vlan_action_set.scos);
    CTC_APP_DBG_PARAM_ST(egress_vlan_action_set.new_scos);
    CTC_APP_DBG_PARAM_ST(egress_vlan_action_set.ccos);
    CTC_APP_DBG_PARAM_ST(egress_vlan_action_set.new_ccos);

    if (p_vlan_port->ingress_policer_id)
    {
       return CTC_E_NOT_SUPPORT;
    }

    ctc_get_gchip_id(lchip, &gchip);

    /* DB */
    sal_memset(&gem_port_db, 0, sizeof(gem_port_db));
    gem_port_db.port = p_vlan_port->port;
    gem_port_db.tunnel_value = p_vlan_port->match_tunnel_value;
    p_gem_port_db = ctc_hash_lookup(p_g_app_vlan_port_master->gem_port_hash, &gem_port_db);

    if (NULL == p_gem_port_db)
    {
        return CTC_E_NOT_EXIST;
    }

    sal_memset(&vlan_port_db, 0, sizeof(vlan_port_db));
    vlan_port_db.port = p_vlan_port->port;
    vlan_port_db.tunnel_value = p_vlan_port->match_tunnel_value;
    vlan_port_db.match_svlan  = p_vlan_port->match_svlan;
    vlan_port_db.match_cvlan  = p_vlan_port->match_cvlan;
    vlan_port_db.match_svlan_end = p_vlan_port->match_svlan_end;
    vlan_port_db.match_cvlan_end = p_vlan_port->match_cvlan_end;

    p_vlan_port_db = ctc_hash_lookup(p_g_app_vlan_port_master->vlan_port_hash, &vlan_port_db);

    if (NULL != p_vlan_port_db)
    {
        return CTC_E_EXIST;
    }

    MALLOC_POINTER(ctc_app_vlan_port_db_t, p_vlan_port_db);
    if (NULL == p_vlan_port_db)
    {
        return CTC_E_NO_MEMORY;
    }

    sal_memset(p_vlan_port_db, 0, sizeof(ctc_app_vlan_port_db_t));
    p_vlan_port_db->criteria = p_vlan_port->criteria;
    p_vlan_port_db->port = p_vlan_port->port;
    p_vlan_port_db->tunnel_value = p_vlan_port->match_tunnel_value;
    p_vlan_port_db->match_svlan = p_vlan_port->match_svlan;
    p_vlan_port_db->match_svlan_end = p_vlan_port->match_svlan_end;
    p_vlan_port_db->match_cvlan = p_vlan_port->match_cvlan;
    p_vlan_port_db->match_cvlan_end = p_vlan_port->match_cvlan_end;
    p_vlan_port_db->p_gem_port_db = p_gem_port_db;

    /* OPF */
    sal_memset(&opf, 0, sizeof(opf));
    opf.pool_type = CTC_OPF_VLAN_PORT;
    opf.pool_index = CTC_APP_VLAN_PORT_OPF_VLAN_PORT;
    CTC_ERROR_GOTO(ctc_opf_alloc_offset(&opf, 1, &logic_port), ret, free_meomory);
    p_vlan_port_db->logic_port = logic_port;
    CTC_APP_DBG_INFO("OPF vlan logic port: %d\n", logic_port);


    /* Add vlan mapping */
    sal_memset(&vlan_mapping, 0, sizeof(vlan_mapping));
    vlan_mapping.flag = CTC_VLAN_MAPPING_FLAG_USE_LOGIC_PORT;

    if (p_vlan_port->criteria == CTC_APP_VLAN_PORT_MATCH_PORT_TUNNEL_SVLAN_CVLAN)
    {
        CTC_SET_FLAG(vlan_mapping.key, CTC_VLAN_MAPPING_KEY_SVID);
        CTC_SET_FLAG(vlan_mapping.key, CTC_VLAN_MAPPING_KEY_CVID);
        vlan_mapping.old_svid = p_vlan_port->match_svlan;
        vlan_mapping.old_cvid = p_vlan_port->match_cvlan;
        vlan_mapping.scl_id = 0;

    }
    else if(p_vlan_port->criteria == CTC_APP_VLAN_PORT_MATCH_PORT_TUNNEL_SVLAN)
    {
        CTC_SET_FLAG(vlan_mapping.key, CTC_VLAN_MAPPING_KEY_SVID);
        CTC_SET_FLAG(vlan_mapping.key, CTC_VLAN_MAPPING_KEY_CVID);
        vlan_mapping.old_svid = p_vlan_port->match_svlan;
        vlan_mapping.old_cvid = 0;
        vlan_mapping.scl_id = 0;
    }

    /* Add vlan range */
    if (p_vlan_port->match_svlan_end)
    {
        ctc_vlan_range_info_t range_info;
        ctc_vlan_range_t vlan_range;

        sal_memset(&range_info, 0, sizeof(range_info));
        sal_memset(&vlan_range, 0, sizeof(vlan_range));

        range_info.direction = CTC_INGRESS;
        range_info.vrange_grpid = 0;
        vlan_range.vlan_start = p_vlan_port->match_svlan;
        vlan_range.vlan_end   = p_vlan_port->match_svlan_end;

        CTC_ERROR_GOTO(ctc_vlan_add_vlan_range(&range_info, &vlan_range), ret, roll_back_0);

        vlan_mapping.svlan_end = p_vlan_port->match_svlan_end;
        vlan_mapping.vrange_grpid = 0;
    }


    CTC_SET_FLAG(vlan_mapping.action, CTC_VLAN_MAPPING_OUTPUT_LOGIC_SRC_PORT);
    vlan_mapping.logic_src_port = logic_port;
    CTC_ERROR_GOTO(_ctc_app_vlan_port_vlan_mapping(lchip, p_vlan_port, &vlan_mapping), ret, roll_back_1);
    CTC_ERROR_GOTO(ctc_vlan_add_vlan_mapping(p_gem_port_db->logic_port, &vlan_mapping), ret, roll_back_1);

    /* Create xlate nh */
    sal_memset(&vlan_xlate_nh, 0, sizeof(vlan_xlate_nh));
    vlan_xlate_nh.gport_or_aps_bridge_id = CTC_MAP_LPORT_TO_GPORT(gchip, p_g_app_vlan_port_master->gem_port_eloop_port);
    vlan_xlate_nh.vlan_edit_info.loop_nhid = CTC_APP_MAP_VLAN_PORT_NHID(p_gem_port_db->logic_port);
    vlan_xlate_nh.logic_port = p_gem_port_db->logic_port;
    CTC_ERROR_GOTO(_ctc_app_vlan_port_xlate_mapping(lchip, p_vlan_port, &vlan_xlate_nh.vlan_edit_info), ret, roll_back_2);
    CTC_APP_DBG_INFO("nh xlate nhid: %d\n", CTC_APP_MAP_VLAN_PORT_NHID(logic_port));
    CTC_ERROR_GOTO(ctc_nh_add_xlate(CTC_APP_MAP_VLAN_PORT_NHID(logic_port), &vlan_xlate_nh), ret, roll_back_2);

    /* Bind logic port and nhid which for hw learning */
    CTC_ERROR_GOTO(ctc_l2_set_nhid_by_logic_port(logic_port, CTC_APP_MAP_VLAN_PORT_NHID(logic_port)), ret, roll_back_3);

    /* Bind priority for qos policer */
    if (CTC_FLAG_ISSET(p_vlan_port->flags, CTC_APP_VLAN_PORT_FLAG_PRIORITY))
    {
        ctc_egress_vlan_mapping_t egs_vlan_mapping;
        sal_memset(&egs_vlan_mapping, 0, sizeof(egs_vlan_mapping));

        egs_vlan_mapping.flag = CTC_VLAN_MAPPING_FLAG_USE_LOGIC_PORT;

        if (p_vlan_port->criteria == CTC_APP_VLAN_PORT_MATCH_PORT_TUNNEL_SVLAN_CVLAN)
        {
            CTC_SET_FLAG(egs_vlan_mapping.key, CTC_VLAN_MAPPING_KEY_SVID);
            CTC_SET_FLAG(egs_vlan_mapping.key, CTC_VLAN_MAPPING_KEY_CVID);
            egs_vlan_mapping.old_svid = p_vlan_port->match_svlan;
            egs_vlan_mapping.old_cvid = p_vlan_port->match_cvlan;
        }
        else if(p_vlan_port->criteria == CTC_APP_VLAN_PORT_MATCH_PORT_TUNNEL_SVLAN)
        {
            CTC_SET_FLAG(egs_vlan_mapping.key, CTC_VLAN_MAPPING_KEY_SVID);
            CTC_SET_FLAG(egs_vlan_mapping.key, CTC_VLAN_MAPPING_KEY_CVID);
            egs_vlan_mapping.old_svid = p_vlan_port->match_svlan;
            egs_vlan_mapping.old_cvid = 0;
        }

        egs_vlan_mapping.color = CTC_QOS_COLOR_GREEN;
        egs_vlan_mapping.priority =  p_vlan_port->priority;
        CTC_ERROR_GOTO(ctc_vlan_add_egress_vlan_mapping(p_gem_port_db->logic_port, &egs_vlan_mapping), ret, roll_back_3);

        p_vlan_port_db->egs_vlan_mapping_en = 1;
    }

    ctc_hash_insert(p_g_app_vlan_port_master->vlan_port_hash, p_vlan_port_db);
    p_g_app_vlan_port_master->vlan_port_cnt++;
    p_gem_port_db->ref_cnt++;

    p_vlan_port->vlan_port_id = logic_port;

    return CTC_E_NONE;


   /*-----------------------------------------------------------
   *** rool back
   -----------------------------------------------------------*/

    roll_back_3:
    ctc_nh_remove_xlate(CTC_APP_MAP_VLAN_PORT_NHID(logic_port));

    roll_back_2:
    ctc_vlan_remove_vlan_mapping(p_gem_port_db->logic_port, &vlan_mapping);

    roll_back_1:
    if (p_vlan_port->match_svlan_end)
    {
        ctc_vlan_range_info_t range_info;
        ctc_vlan_range_t vlan_range;

        sal_memset(&range_info, 0, sizeof(range_info));
        sal_memset(&vlan_range, 0, sizeof(vlan_range));

        range_info.direction = CTC_INGRESS;
        range_info.vrange_grpid = 0;
        vlan_range.vlan_start = p_vlan_port->match_svlan;
        vlan_range.vlan_end   = p_vlan_port->match_svlan_end;
        ctc_vlan_remove_vlan_range(&range_info, &vlan_range);
    }

    roll_back_0:
    ctc_opf_free_offset(&opf, 1, logic_port);

    free_meomory:
    mem_free(p_vlan_port_db);
    p_vlan_port_db = NULL;


    return ret;

}


int32
ctc_app_vlan_port_destory(uint8 lchip, ctc_app_vlan_port_t *p_vlan_port)
{
    ctc_vlan_mapping_t vlan_mapping;
    ctc_app_vlan_port_gem_port_db_t *p_gem_port_db = NULL;
    ctc_app_vlan_port_db_t *p_vlan_port_db = NULL;
    ctc_opf_t opf;
    uint32 logic_port = 0;

    /* CHECK */
    CTC_APP_VLAN_PORT_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_vlan_port);

    /* Debug */
    CTC_APP_DBG_PARAM("-------------------------------------------------\n");
    CTC_APP_DBG_PARAM_ST(vlan_port_id);
    CTC_APP_DBG_PARAM_ST(criteria);
    CTC_APP_DBG_PARAM_ST(port);
    CTC_APP_DBG_PARAM_ST(match_tunnel_value);
    CTC_APP_DBG_PARAM_ST(match_svlan);
    CTC_APP_DBG_PARAM_ST(match_cvlan);
    CTC_APP_DBG_PARAM_ST(match_svlan_end);
    CTC_APP_DBG_PARAM_ST(match_cvlan_end);


    /* DB */

    if (p_vlan_port->vlan_port_id)
    {
        p_vlan_port_db = _ctc_app_vlan_port_find_vlan_port_db(lchip, p_vlan_port->vlan_port_id);
        if (NULL == p_vlan_port_db)
        {
            return CTC_E_NOT_EXIST;
        }

        p_gem_port_db = p_vlan_port_db->p_gem_port_db;
    }
    else
    {
        ctc_app_vlan_port_db_t vlan_port_db;
        ctc_app_vlan_port_gem_port_db_t gem_port_db;

        sal_memset(&gem_port_db, 0, sizeof(gem_port_db));
        gem_port_db.port = p_vlan_port->port;
        gem_port_db.tunnel_value = p_vlan_port->match_tunnel_value;
        p_gem_port_db = ctc_hash_lookup(p_g_app_vlan_port_master->gem_port_hash, &gem_port_db);

        if (NULL == p_gem_port_db)
        {
            return CTC_E_NOT_EXIST;
        }

        sal_memset(&vlan_port_db, 0, sizeof(vlan_port_db));
        vlan_port_db.port = p_vlan_port->port;
        vlan_port_db.tunnel_value = p_vlan_port->match_tunnel_value;
        vlan_port_db.match_svlan  = p_vlan_port->match_svlan;
        vlan_port_db.match_cvlan  = p_vlan_port->match_cvlan;
        vlan_port_db.match_svlan_end = p_vlan_port->match_svlan_end;
        vlan_port_db.match_cvlan_end = p_vlan_port->match_cvlan_end;

        p_vlan_port_db = ctc_hash_lookup(p_g_app_vlan_port_master->vlan_port_hash, &vlan_port_db);

        if (NULL == p_vlan_port_db)
        {
            return CTC_E_NOT_EXIST;
        }

    }


    logic_port =  p_vlan_port_db->logic_port;

    /* Remvoe vlan xlate nexthop */
    CTC_ERROR_RETURN(ctc_nh_remove_xlate(CTC_APP_MAP_VLAN_PORT_NHID(logic_port)));

    /* Remvoe vlan mapping */
    sal_memset(&vlan_mapping, 0, sizeof(vlan_mapping));
    vlan_mapping.flag = CTC_VLAN_MAPPING_FLAG_USE_LOGIC_PORT;

    if (p_vlan_port_db->criteria == CTC_APP_VLAN_PORT_MATCH_PORT_TUNNEL_SVLAN_CVLAN)
    {
        CTC_SET_FLAG(vlan_mapping.key, CTC_VLAN_MAPPING_KEY_SVID);
        CTC_SET_FLAG(vlan_mapping.key, CTC_VLAN_MAPPING_KEY_CVID);
        vlan_mapping.old_svid = p_vlan_port_db->match_svlan;
        vlan_mapping.old_cvid = p_vlan_port_db->match_cvlan;
        vlan_mapping.scl_id = 0;

    }
    else if(p_vlan_port_db->criteria == CTC_APP_VLAN_PORT_MATCH_PORT_TUNNEL_SVLAN)
    {
        CTC_SET_FLAG(vlan_mapping.key, CTC_VLAN_MAPPING_KEY_SVID);
        CTC_SET_FLAG(vlan_mapping.key, CTC_VLAN_MAPPING_KEY_CVID);
        vlan_mapping.old_svid = p_vlan_port_db->match_svlan;
        vlan_mapping.old_cvid = 0;
        vlan_mapping.scl_id = 0;
    }


    if (p_vlan_port_db->match_svlan_end)
    {
        vlan_mapping.svlan_end = p_vlan_port_db->match_svlan_end;
        vlan_mapping.vrange_grpid = 0;
    }

    CTC_ERROR_RETURN(ctc_vlan_remove_vlan_mapping(p_gem_port_db->logic_port, &vlan_mapping));

    /* Remvoe egress vlan mapping */
    if (p_vlan_port_db->egs_vlan_mapping_en)
    {
        ctc_egress_vlan_mapping_t egs_vlan_mapping;
        sal_memset(&egs_vlan_mapping, 0, sizeof(egs_vlan_mapping));

        egs_vlan_mapping.flag = CTC_VLAN_MAPPING_FLAG_USE_LOGIC_PORT;

        if (p_vlan_port_db->criteria == CTC_APP_VLAN_PORT_MATCH_PORT_TUNNEL_SVLAN_CVLAN)
        {
            CTC_SET_FLAG(egs_vlan_mapping.key, CTC_VLAN_MAPPING_KEY_SVID);
            CTC_SET_FLAG(egs_vlan_mapping.key, CTC_VLAN_MAPPING_KEY_CVID);
            egs_vlan_mapping.old_svid = p_vlan_port_db->match_svlan;
            egs_vlan_mapping.old_cvid = p_vlan_port_db->match_cvlan;
        }
        else if(p_vlan_port_db->criteria == CTC_APP_VLAN_PORT_MATCH_PORT_TUNNEL_SVLAN)
        {
            CTC_SET_FLAG(egs_vlan_mapping.key, CTC_VLAN_MAPPING_KEY_SVID);
            CTC_SET_FLAG(egs_vlan_mapping.key, CTC_VLAN_MAPPING_KEY_CVID);
            egs_vlan_mapping.old_svid = p_vlan_port_db->match_svlan;
            egs_vlan_mapping.old_cvid = 0;
        }

        CTC_ERROR_RETURN(ctc_vlan_remove_egress_vlan_mapping(p_gem_port_db->logic_port, &egs_vlan_mapping));
    }


    /* Remove vlan range*/
    if (p_vlan_port_db->match_svlan_end)
    {
        ctc_vlan_range_info_t range_info;
        ctc_vlan_range_t vlan_range;

        sal_memset(&range_info, 0, sizeof(range_info));
        sal_memset(&vlan_range, 0, sizeof(vlan_range));

        range_info.direction = CTC_INGRESS;
        range_info.vrange_grpid = 0;
        vlan_range.vlan_start = p_vlan_port_db->match_svlan;
        vlan_range.vlan_end   = p_vlan_port_db->match_svlan_end;
        CTC_ERROR_RETURN(ctc_vlan_remove_vlan_range(&range_info, &vlan_range));
    }

    /* free opf */
    sal_memset(&opf, 0, sizeof(opf));
    opf.pool_type = CTC_OPF_VLAN_PORT;
    opf.pool_index = CTC_APP_VLAN_PORT_OPF_VLAN_PORT;
    CTC_ERROR_RETURN(ctc_opf_free_offset(&opf, 1, logic_port));

    ctc_hash_remove(p_g_app_vlan_port_master->vlan_port_hash, p_vlan_port_db);
    p_g_app_vlan_port_master->vlan_port_cnt--;
    p_gem_port_db->ref_cnt--;

    /* free memory */
    mem_free(p_vlan_port_db);
    p_vlan_port_db = NULL;

    return CTC_E_NONE;
}


int32
ctc_app_vlan_port_create_nni(uint8 lchip, ctc_app_nni_t *p_nni)
{
    int32 ret = 0;
    uint32 logic_port = 0;
    ctc_opf_t opf;
    ctc_vlan_edit_nh_param_t vlan_xlate_nh;
    ctc_l2dflt_addr_t l2dflt_addr;
    uint32 fid = 0;

    /* CHECK */
    CTC_APP_VLAN_PORT_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_nni);

    /* Debug */
    CTC_APP_DBG_PARAM("-------------------------------------------------\n");
    CTC_APP_DBG_PARAM("%-40s :%10d\n", "port", p_nni->port);


    CTC_ERROR_RETURN(ctc_port_get_property(p_nni->port, CTC_PORT_PROP_LOGIC_PORT, &logic_port));
    if (0 != logic_port)
    {
        return CTC_E_EXIST;
    }

    /* OPF */
    sal_memset(&opf, 0, sizeof(opf));
    opf.pool_type = CTC_OPF_VLAN_PORT;
    opf.pool_index= CTC_APP_VLAN_PORT_OPF_NNI_PORT;
    CTC_ERROR_RETURN(ctc_opf_alloc_offset(&opf, 1, &logic_port));
    CTC_APP_DBG_INFO("OPF nni logic port: %d\n", logic_port);

   /* Set port logic_port */
    CTC_ERROR_GOTO(ctc_port_set_property(p_nni->port, CTC_PORT_PROP_LOGIC_PORT, logic_port), ret, roll_back_0);

    /* Create xlate nh */
    sal_memset(&vlan_xlate_nh, 0, sizeof(vlan_xlate_nh));
    vlan_xlate_nh.gport_or_aps_bridge_id = p_nni->port;
    vlan_xlate_nh.vlan_edit_info.svlan_edit_type = CTC_VLAN_EGRESS_EDIT_NONE;
    vlan_xlate_nh.vlan_edit_info.cvlan_edit_type = CTC_VLAN_EGRESS_EDIT_NONE;
    CTC_APP_DBG_INFO("nh xlate nhid: %d\n", CTC_APP_MAP_VLAN_PORT_NHID(logic_port));
    CTC_ERROR_GOTO(ctc_nh_add_xlate(CTC_APP_MAP_VLAN_PORT_NHID(logic_port), &vlan_xlate_nh), ret, roll_back_0);

    /* Bind logic port and nhid which for hw learning */
    CTC_ERROR_GOTO(ctc_l2_set_nhid_by_logic_port(logic_port, CTC_APP_MAP_VLAN_PORT_NHID(logic_port)), ret, roll_back_1);

    sal_memset(&l2dflt_addr, 0, sizeof(ctc_l2dflt_addr_t));
    l2dflt_addr.with_nh = 1;
    l2dflt_addr.member.nh_id = CTC_APP_MAP_VLAN_PORT_NHID(logic_port);

    for (fid = 1; fid <= CTC_MAX_VLAN_ID; fid++)
    {
        l2dflt_addr.fid = fid;
        CTC_ERROR_GOTO(ctc_l2_add_port_to_default_entry(&l2dflt_addr), ret, roll_back_1);
    }

    p_g_app_vlan_port_master->nni_port_cnt++;

    return CTC_E_NONE;

    roll_back_1:
    ctc_nh_remove_xlate(CTC_APP_MAP_VLAN_PORT_NHID(logic_port));

    roll_back_0:
    ctc_opf_free_offset(&opf, 1, logic_port);

    return CTC_E_NONE;
}



int32
ctc_app_vlan_port_destory_nni(uint8 lchip, ctc_app_nni_t *p_nni)
{
    uint32 logic_port = 0;
    ctc_opf_t opf;
    ctc_l2dflt_addr_t l2dflt_addr;
    uint32 fid = 0;

    /* CHECK */
    CTC_APP_VLAN_PORT_INIT_CHECK();
    CTC_PTR_VALID_CHECK(p_nni);

    /* Debug */
    CTC_APP_DBG_PARAM("-------------------------------------------------\n");
    CTC_APP_DBG_PARAM("%-40s :%10d\n", "port", p_nni->port);

    CTC_ERROR_RETURN(ctc_port_get_property(p_nni->port, CTC_PORT_PROP_LOGIC_PORT, &logic_port));
    if (0 == logic_port)
    {
        return CTC_E_NOT_EXIST;
    }

    CTC_APP_DBG_INFO("NNI logic port: %d\n", logic_port);

    /* Remove from default Entry */
    sal_memset(&l2dflt_addr, 0, sizeof(ctc_l2dflt_addr_t));
    l2dflt_addr.with_nh = 1;
    l2dflt_addr.member.nh_id = CTC_APP_MAP_VLAN_PORT_NHID(logic_port);

    for (fid = 1; fid <= CTC_MAX_VLAN_ID; fid++)
    {
        CTC_ERROR_RETURN(ctc_l2_remove_port_from_default_entry(&l2dflt_addr));
    }

    /* Remove xlate nexthop */
    CTC_ERROR_RETURN(ctc_nh_remove_xlate(CTC_APP_MAP_VLAN_PORT_NHID(logic_port)));

    /* Free opf offset */
    sal_memset(&opf, 0, sizeof(opf));
    opf.pool_type = CTC_OPF_VLAN_PORT;
    opf.pool_index= CTC_APP_VLAN_PORT_OPF_NNI_PORT;
    CTC_ERROR_RETURN(ctc_opf_free_offset(&opf, 1, logic_port));

    /* Clear port logic_port*/
    CTC_ERROR_RETURN(ctc_port_set_property(p_nni->port, CTC_PORT_PROP_LOGIC_PORT, 0));

   p_g_app_vlan_port_master->nni_port_cnt--;

    return CTC_E_NONE;
}


static int32
_ctc_app_vlan_port_init_db(uint8 lchip)
{
    CTC_PTR_VALID_CHECK(p_g_app_vlan_port_master);

    p_g_app_vlan_port_master->gem_port_hash = ctc_hash_create(10,
                                                              100,
                                                              (hash_key_fn) _ctc_app_vlan_port_hash_gem_port_make,
                                                              (hash_cmp_fn) _ctc_app_vlan_port_hash_gem_port_cmp);


    if (NULL == p_g_app_vlan_port_master->gem_port_hash)
    {
        return CTC_E_NO_MEMORY;
    }


    p_g_app_vlan_port_master->vlan_port_hash = ctc_hash_create(10,
                                                               100,
                                                               (hash_key_fn) _ctc_app_vlan_port_hash_make,
                                                               (hash_cmp_fn) _ctc_app_vlan_port_hash_cmp);


    if (NULL == p_g_app_vlan_port_master->vlan_port_hash)
    {
        return CTC_E_NO_MEMORY;
    }



    return CTC_E_NONE;
}


static int32
_ctc_app_vlan_port_init_flooding(uint8 lchip)
{
    ctc_l2dflt_addr_t l2dflt_addr;
    uint32 fid  = 0;

    sal_memset(&l2dflt_addr, 0, sizeof(ctc_l2dflt_addr_t));

    l2dflt_addr.flag = CTC_L2_DFT_VLAN_FLAG_USE_LOGIC_PORT;

    for (fid = 1; fid <= CTC_MAX_VLAN_ID; fid++)
    {
        l2dflt_addr.fid = fid;
        l2dflt_addr.l2mc_grp_id = fid;
        ctc_l2_add_default_entry(&l2dflt_addr);
    }

    return CTC_E_NONE;
}



static int32
_ctc_app_vlan_port_init_opf(uint8 lchip)
{
    ctc_opf_t opf;

    ctc_opf_init(CTC_OPF_VLAN_PORT, CTC_APP_VLAN_PORT_OPF_MAX);

    sal_memset(&opf, 0, sizeof(opf));
    opf.pool_type = CTC_OPF_VLAN_PORT;
    opf.pool_index = CTC_APP_VLAN_PORT_OPF_GEM_PORT;
    ctc_opf_init_offset(&opf, 1, CTC_APP_VLAN_PORT_GEM_PORT_NUM);

    opf.pool_index = CTC_APP_VLAN_PORT_OPF_VLAN_PORT;
    ctc_opf_init_offset(&opf, CTC_APP_VLAN_PORT_GEM_PORT_NUM + 1, CTC_APP_VLAN_PORT_VLAN_PORT_NUM);

    opf.pool_index = CTC_APP_VLAN_PORT_OPF_NNI_PORT;
    ctc_opf_init_offset(&opf, (CTC_APP_VLAN_PORT_GEM_PORT_NUM + CTC_APP_VLAN_PORT_VLAN_PORT_NUM + 1), CTC_APP_VLAN_PORT_NNI_PORT_NUM);

    return CTC_E_NONE;
}


static int32
_ctc_app_vlan_port_init_gem_port(uint8 lchip)
{
    uint8 gchip = 0;
    uint32 gem_iloop_gport = 0;
    ctc_internal_port_assign_para_t alloc_port;
    ctc_loopback_nexthop_param_t gem_port_iloop;
    ctc_vlan_edit_nh_param_t gem_xlate_nh;
    ctc_port_scl_property_t scl_prop;
    ctc_vlan_miss_t vlan_miss;
    ctc_vlan_range_info_t vlan_range;

    ctc_get_gchip_id(lchip, &gchip);

    p_g_app_vlan_port_master->gem_port_illop_nhid = CTC_APP_VLAN_PORT_NHID_RSV_ILOOP;
    p_g_app_vlan_port_master->gem_port_xlate_e2iloop_nhid = CTC_APP_VLAN_PORT_NHID_RSV_E2ILOOP;

    /* Alloc gem port iloop port */
    sal_memset(&alloc_port, 0, sizeof(alloc_port));
    alloc_port.type = CTC_INTERNAL_PORT_TYPE_ILOOP;
    alloc_port.gchip = gchip;
    CTC_ERROR_RETURN(ctc_alloc_internal_port(&alloc_port));
    p_g_app_vlan_port_master->gem_port_iloop_port = alloc_port.inter_port;

    /* Create gem port iloop nh */
    sal_memset(&gem_port_iloop, 0, sizeof(gem_port_iloop));
    gem_port_iloop.lpbk_lport = p_g_app_vlan_port_master->gem_port_iloop_port;
    ctc_nh_add_iloop(p_g_app_vlan_port_master->gem_port_illop_nhid, &gem_port_iloop);

    /* Alloc gem port eloop port */
    sal_memset(&alloc_port, 0, sizeof(alloc_port));
    alloc_port.type = CTC_INTERNAL_PORT_TYPE_ELOOP;
    alloc_port.gchip = gchip;
    alloc_port.nhid = p_g_app_vlan_port_master->gem_port_illop_nhid;
    CTC_ERROR_RETURN(ctc_alloc_internal_port(&alloc_port));
    p_g_app_vlan_port_master->gem_port_eloop_port = alloc_port.inter_port;

    /* Create gem port xlate nh */
    sal_memset(&gem_xlate_nh, 0, sizeof(gem_xlate_nh));
    gem_xlate_nh.gport_or_aps_bridge_id = CTC_MAP_LPORT_TO_GPORT(gchip, p_g_app_vlan_port_master->gem_port_eloop_port);
    gem_xlate_nh.vlan_edit_info.svlan_edit_type = CTC_VLAN_EGRESS_EDIT_NONE;
    gem_xlate_nh.vlan_edit_info.cvlan_edit_type = CTC_VLAN_EGRESS_EDIT_NONE;
    gem_xlate_nh.vlan_edit_info.loop_nhid = p_g_app_vlan_port_master->gem_port_illop_nhid;
    CTC_ERROR_RETURN(ctc_nh_add_xlate(p_g_app_vlan_port_master->gem_port_xlate_e2iloop_nhid, &gem_xlate_nh));

    /* Enable learning */
    gem_iloop_gport = CTC_MAP_LPORT_TO_GPORT(gchip, p_g_app_vlan_port_master->gem_port_iloop_port);
    CTC_ERROR_RETURN(ctc_port_set_property(gem_iloop_gport, CTC_PORT_PROP_LEARNING_EN, 1));

    /* Enable port en */
    CTC_ERROR_RETURN(ctc_port_set_property(gem_iloop_gport, CTC_PORT_PROP_PORT_EN, 1));


    /* Vlan range enalbe*/
    sal_memset(&vlan_range, 0, sizeof(vlan_range));
    vlan_range.direction = CTC_INGRESS;
    vlan_range.vrange_grpid = 0;
    CTC_ERROR_RETURN(ctc_vlan_create_vlan_range_group(&vlan_range, TRUE));
    CTC_ERROR_RETURN(ctc_port_set_vlan_range(gem_iloop_gport, &vlan_range, TRUE));

#if 1
    /*Enable port service policer*/
#if defined (GREATBELT)
    extern int32 sys_greatbelt_port_set_service_policer_en(uint8 lchip, uint32 gport, bool enable);
    CTC_ERROR_RETURN(sys_greatbelt_port_set_service_policer_en(lchip,
                                                               CTC_MAP_LPORT_TO_GPORT(gchip, p_g_app_vlan_port_master->gem_port_eloop_port),
                                                               TRUE));
#endif
#endif

    /* Enable scl lookup for double */
    sal_memset(&scl_prop, 0, sizeof(scl_prop));
    scl_prop.scl_id = 0;
    scl_prop.direction = CTC_INGRESS;
    scl_prop.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_PORT_2VLAN;
    scl_prop.use_logic_port_en = 1;
    scl_prop.action_type = CTC_PORT_SCL_ACTION_TYPE_SCL;
    CTC_ERROR_RETURN(ctc_port_set_scl_property(gem_iloop_gport, &scl_prop));

    scl_prop.scl_id = 0;
    scl_prop.direction = CTC_EGRESS;
    scl_prop.hash_type = CTC_PORT_IGS_SCL_HASH_TYPE_PORT_2VLAN;
    scl_prop.use_logic_port_en = 1;
    scl_prop.action_type = CTC_PORT_SCL_ACTION_TYPE_SCL;
    CTC_ERROR_RETURN(ctc_port_set_scl_property(gem_iloop_gport, &scl_prop));


    /* Default vlan mapping for do-nothing */
    sal_memset(&vlan_miss, 0, sizeof(vlan_miss));
    vlan_miss.flag = CTC_VLAN_MISS_ACTION_DO_NOTHING;
    CTC_ERROR_RETURN(ctc_vlan_add_default_vlan_mapping(gem_iloop_gport, &vlan_miss));


    return CTC_E_NONE;
}


int32
ctc_app_vlan_port_init(uint8 lchip, void *p_param)
{

    if (NULL != p_g_app_vlan_port_master)
    {
         return CTC_E_INIT_FAIL;
    }

    MALLOC_POINTER(ctc_app_vlan_port_master_t, p_g_app_vlan_port_master);
    if (NULL == p_g_app_vlan_port_master)
    {
        return CTC_E_NO_MEMORY;
    }

    sal_memset(p_g_app_vlan_port_master, 0, sizeof(ctc_app_vlan_port_master_t));

    /*------------DB------------*/
    CTC_ERROR_RETURN(_ctc_app_vlan_port_init_db(lchip));

    CTC_ERROR_RETURN(_ctc_app_vlan_port_init_opf(lchip));

    CTC_ERROR_RETURN(_ctc_app_vlan_port_init_flooding(lchip));

    CTC_ERROR_RETURN(_ctc_app_vlan_port_init_gem_port(lchip));


    return CTC_E_NONE;
}


int32
_ctc_app_vlan_port_show_gem_port(ctc_app_vlan_port_gem_port_db_t *p_gem_port_db,
                                 uint32* i)
{
    CTC_PTR_VALID_CHECK(i);
    CTC_PTR_VALID_CHECK(p_gem_port_db);

    CTC_APP_DBG_DUMP("%-5d %5d %15d %15d %15d\n",
               *i,
               p_gem_port_db->port,
               p_gem_port_db->tunnel_value,
               p_gem_port_db->logic_port,
               p_gem_port_db->ref_cnt);
    (*i)++;

    return CTC_E_NONE;
}

int32
_ctc_app_vlan_port_show_vlan_port(ctc_app_vlan_port_db_t *p_vlan_port_db,
                                  uint32* i)
{
   CTC_PTR_VALID_CHECK(i);
   CTC_PTR_VALID_CHECK(p_vlan_port_db);


   CTC_APP_DBG_DUMP("%-5d %5d %15d %10d %10d %10d %15d\n",
              *i,
              p_vlan_port_db->port,
              p_vlan_port_db->tunnel_value,
              p_vlan_port_db->match_svlan,
              p_vlan_port_db->match_cvlan,
              p_vlan_port_db->match_svlan_end,
              p_vlan_port_db->logic_port);
    (*i)++;

    return CTC_E_NONE;
}

int32
ctc_app_vlan_port_show_gem_port(uint8 lchip)
{
    uint32 i = 1;
    CTC_APP_DBG_DUMP("%-5s %5s %15s %15s %15s\n", "No.", "port", "tunnel-value", "logic port", "ref cnt");
    CTC_APP_DBG_DUMP("-----------------------------------------------------------------\n");

    ctc_hash_traverse(p_g_app_vlan_port_master->gem_port_hash,
                      (hash_traversal_fn)_ctc_app_vlan_port_show_gem_port, &i);
    return CTC_E_NONE;
}

int32
ctc_app_vlan_port_show_vlan_port(uint8 lchip)
{
    uint32 i = 1;
    CTC_APP_DBG_DUMP("%-5s %5s %15s %10s %10s %10s %15s\n", "No.", "port", "tunnel-value", "svid", "cvid", "svid-end", "logic port");
    CTC_APP_DBG_DUMP("-------------------------------------------------------------------------------------------\n");

    ctc_hash_traverse(p_g_app_vlan_port_master->vlan_port_hash,
                      (hash_traversal_fn)_ctc_app_vlan_port_show_vlan_port, &i);
    return CTC_E_NONE;
}

int32
ctc_app_vlan_port_show_status(uint8 lchip)
{

    CTC_APP_DBG_DUMP("Count:\n");
    CTC_APP_DBG_DUMP("-----------------------------\n");
    CTC_APP_DBG_DUMP("%-20s : %d\n", "gem port",    p_g_app_vlan_port_master->gem_port_cnt);
    CTC_APP_DBG_DUMP("%-20s : %d\n", "vlan port",   p_g_app_vlan_port_master->vlan_port_cnt);
    CTC_APP_DBG_DUMP("%-20s : %d\n", "nni port",    p_g_app_vlan_port_master->nni_port_cnt);

    CTC_APP_DBG_DUMP("\n");
    CTC_APP_DBG_DUMP("GEM port resource:\n");
    CTC_APP_DBG_DUMP("-----------------------------\n");
    CTC_APP_DBG_DUMP("%-20s : %d\n", "iloop port",    p_g_app_vlan_port_master->gem_port_iloop_port);
    CTC_APP_DBG_DUMP("%-20s : %d\n", "eloop port",    p_g_app_vlan_port_master->gem_port_eloop_port);
    CTC_APP_DBG_DUMP("%-20s : %d\n", "iloop nhid",    p_g_app_vlan_port_master->gem_port_illop_nhid);
    CTC_APP_DBG_DUMP("%-20s : %d\n", "e2iloop nhid",  p_g_app_vlan_port_master->gem_port_xlate_e2iloop_nhid);



    return CTC_E_NONE;
}


int32
ctc_app_vlan_port_show(uint8 lchip, uint8 type)
{
    CTC_APP_VLAN_PORT_INIT_CHECK();

    switch(type)
    {
    case 0:
        ctc_app_vlan_port_show_status(lchip);
        break;
    case 1:
        ctc_app_vlan_port_show_gem_port(lchip);
        break;
    case 2:
        ctc_app_vlan_port_show_vlan_port(lchip);
        break;
    default:
       break;
    }

    return CTC_E_NONE;
}


#endif





/**
 @file ctc_app_vlan_port.h

 @date 2016-04-13

 @version v5.0

 The file defines vlan port api
*/
#ifndef _CTC_APP_VLAN_PORT_H_
#define _CTC_APP_VLAN_PORT_H_
#ifdef __cplusplus
extern "C" {
#endif
/****************************************************************
 *
 * Header Files
 *
 ***************************************************************/
#include "sal.h"
#include "ctc_const.h"
#include "ctc_mix.h"
#include "ctc_error.h"

/****************************************************************
*
* Defines and Macros
*
****************************************************************/


enum ctc_app_vlan_port_match_s {
    CTC_APP_VLAN_PORT_MATCH_PORT_TUNNEL,               /*[GB.GG] Match port + tunnel */
    CTC_APP_VLAN_PORT_MATCH_PORT_TUNNEL_SVLAN,         /*[GB.GG] Match port + tunnel + svlan*/
    CTC_APP_VLAN_PORT_MATCH_PORT_TUNNEL_SVLAN_CVLAN,   /*[GB.GG] Match port + tunnel + svlan + cvlan*/
    CTC_APP_VLAN_PORT_MATCH_MAX
};
typedef enum ctc_app_vlan_port_match_s ctc_app_vlan_port_match_t;


enum ctc_app_vlan_action_s {
    CTC_APP_VLAN_ACTION_NONE,        /*[GB.GG] Vlan action none */
    CTC_APP_VLAN_ACTION_ADD,         /*[GB.GG] Add new */
    CTC_APP_VLAN_ACTION_DEL,         /*[GB.GG] Del */
    CTC_APP_VLAN_ACTION_REPLACE,     /*[GB.GG] Replace */
    CTC_APP_VLAN_ACTION_MAX
};
typedef enum ctc_app_vlan_action_s ctc_app_vlan_action_t;


enum ctc_app_vlan_port_flag_s {
    CTC_APP_VLAN_PORT_FLAG_PRIORITY = 0x00000001,         /*[GB.GG] Vlan action priority */
    CTC_APP_VLAN_PORT_FLAG_MAX
};
typedef enum ctc_app_vlan_port_flag_s ctc_app_vlan_port_flag_t;


struct ctc_app_vlan_action_set_s {

    ctc_app_vlan_action_t svid;   /*[GB.GG] Svlan vlan id action*/
    ctc_app_vlan_action_t scos;   /*[GB.GG] svlan cos  action*/
    ctc_app_vlan_action_t scfi;   /*[GB.GG] Svlan cfi action*/

    ctc_app_vlan_action_t cvid;   /*[GB.GG] Cvlan vlan id action */
    ctc_app_vlan_action_t ccos;   /*[GB.GG] Cvlan cos action */
    ctc_app_vlan_action_t ccfi;   /*[GB.GG] Cvlan cfi action */

    uint16 new_svid;    /*[GB.GG] New svlan vlan id*/
    uint16 new_scos;    /*[GB.GG] New svlan cos*/
    uint16 new_scfi;    /*[GB.GG] New svlan cfi*/

    uint16 new_cvid;   /*[GB.GG] New cvlan vlan id*/
    uint16 new_ccos;   /*[GB.GG] New cvlan vlan id*/
    uint16 new_ccfi;   /*[GB.GG] New cvlan vlan id*/

};
typedef struct ctc_app_vlan_action_set_s ctc_app_vlan_action_set_t;


struct ctc_app_vlan_port_s {

    uint32 vlan_port_id; /*[GB.GG] [out] Entry identification */

    uint32 flags;        /*[GB.GG]  Flags refer to  ctc_app_vlan_port_flag_t */

    ctc_app_vlan_port_match_t criteria;   /*[GB.GG]  [in] Match criteria*/

    uint32 port;                        /*[GB.GG]  [in] Incoming port */

    uint32 match_tunnel_value;          /*[GB.GG]  [in] Tunnel LLID Value */

    uint16 match_svlan;                 /*[GB.GG]  [in] Svlan to match */
    uint16 match_cvlan;                 /*[GB.GG]  [in] Cvlan to match */
    uint16 match_svlan_end;             /*[GB.GG]  [in] Svlan range to match */
    uint16 match_cvlan_end;             /*[GB.GG]  [in] Cvlan range to match */

    ctc_app_vlan_action_set_t ingress_vlan_action_set;  /*[GB.GG]  [in] Ingress vlan action */
    ctc_app_vlan_action_set_t egress_vlan_action_set;   /*[GB.GG]  [in] Egress vlan action */

    uint16    qos_domain;            /*[GB.GG]  [in] QoS Map domain id*/
    uint16    priority;              /*[GB.GG]  [in] QoS priority*/

    uint32    ingress_policer_id;         /*[GB.GG] [in] Igr Policer ID, Not support now */
    uint32    egress_policer_id;          /*[GB.GG] [in] Egr Policer ID */

};
typedef struct ctc_app_vlan_port_s ctc_app_vlan_port_t;


struct ctc_app_gem_port_s {

    uint32 port;               /*[GB.GG] [in]  Incomming port*/
    uint32 tunnel_value;       /*[GB.GG] [in]  GEM port vlan*/
    uint32 logic_port;         /*[GB.GG] [out] Logic port which used for acl key and policer id*/

    uint32 ga_gport;           /*[GB.GG] [out] Gem port associate gport, used for enable acl*/
};
typedef struct ctc_app_gem_port_s ctc_app_gem_port_t;


struct ctc_app_nni_s {

    uint32 port;               /*[GB.GG] [in] nni port which is uplink port*/
};
typedef struct ctc_app_nni_s ctc_app_nni_t;



/**********************************************************************************
                      Define API function interfaces
 ***********************************************************************************/

/**
 @brief Create gem port which mapping tunnel value to logic port and gem_gport

 @param[in] lchip    local chip id

 @param[in/out] p_gem_port  point to ctc_app_gem_port_t

 @remark  Mapping tunnel value to logic port and gem_gport

 @return CTC_E_XXX

*/
int32
ctc_app_vlan_port_create_gem_port(uint8 lchip, ctc_app_gem_port_t *p_gem_port);

/**
 @brief Destroy gem port which cancel mapping tunnel value to logic port and gem_gport

 @param[in] lchip    local chip id

 @param[in] p_gem_port  point to ctc_app_gem_port_t

 @remark  Cancel mapping tunnel value to logic port and gem_gport

 @return CTC_E_XXX

*/
int32
ctc_app_vlan_port_destory_gem_port(uint8 lchip, ctc_app_gem_port_t *p_gem_port);


/**
 @brief Create vlan port which mapping vlan and service

 @param[in] lchip    local chip id

 @param[in/out] p_vlan_port point to ctc_app_vlan_port_t

 @remark  Mapping vlan and service

 @return CTC_E_XXX

*/
int32
ctc_app_vlan_port_create(uint8 lchip, ctc_app_vlan_port_t *p_vlan_port);

/**
 @brief Destroy vlan port which cancel mapping vlan and service

 @param[in] lchip    local chip id

 @param[in] p_vlan_port point to ctc_app_vlan_port_t

 @remark  Cancel mapping vlan and service

 @return CTC_E_XXX

*/
int32
ctc_app_vlan_port_destory(uint8 lchip, ctc_app_vlan_port_t *p_vlan_port);

/**
 @brief Create nni uplink port

 @param[in] lchip    local chip id

 @param[in] p_nni    point to ctc_app_nni_t

 @remark  Create nni uplink port

 @return CTC_E_XXX

*/
int32
ctc_app_vlan_port_create_nni(uint8 lchip, ctc_app_nni_t *p_nni);

/**
 @brief Destroy nni uplink port

 @param[in] lchip    local chip id

 @param[in] p_nni    point to ctc_app_nni_t

 @remark  Create nni uplink port

 @return CTC_E_XXX

*/
int32
ctc_app_vlan_port_destory_nni(uint8 lchip, ctc_app_nni_t *p_nni);


/**
 @brief vlan port ini

 @param[in] lchip    local chip id

 @param[in] p_param    void

 @remark  init vlan port

 @return CTC_E_XXX

*/
int32
ctc_app_vlan_port_init(uint8 lchip, void *p_param);


#ifdef __cplusplus
}
#endif

#endif  /* _CTC_APP_VLAN_PORT_H_*/




/**
 @file drv_ftm.h

 @date 2011-11-16

 @version v2.0

 alloc memory and offset
*/

#ifndef _SYS_GOLDENGATE_FTM_H
#define _SYS_GOLDENGATE_FTM_H
#ifdef __cplusplus
extern "C" {
#endif

#define DRV_FTM_MEM_MAX (32)

/**
 @brief Define key size
*/
enum drv_ftm_key_size_e
{
    DRV_FTM_KEY_SIZE_INVALID = 0,   /**< [HB.GB]Invalid key size*/
    DRV_FTM_KEY_SIZE_80_BIT  = 1,   /**< [HB.GB]80 bits key size*/
    DRV_FTM_KEY_SIZE_160_BIT = 2,   /**< [HB.GB]160 bits key size*/
    DRV_FTM_KEY_SIZE_320_BIT = 4,   /**< [HB.GB]320 bits key size*/
    DRV_FTM_KEY_SIZE_640_BIT = 8,   /**< [HB.GB]640 bits key size*/
    DRV_FTM_KEY_SIZE_MAX
};
typedef enum drv_ftm_key_size_e drv_ftm_key_size_t;


enum drv_ftm_key_type_e
{
    DRV_FTM_KEY_TYPE_IPV6_ACL0,         /**< [GB]Ipv6 ACL key */
    DRV_FTM_KEY_TYPE_IPV6_ACL1,         /**< [GB]Ipv6 ACL key */

    DRV_FTM_KEY_TYPE_SCL0,              /**< [GG]SCL key */
    DRV_FTM_KEY_TYPE_SCL1,              /**< [GG]SCL key */

    DRV_FTM_KEY_TYPE_ACL0,              /**< [GB.GG]ACL key include MAC , IPV4, MPLS */
    DRV_FTM_KEY_TYPE_ACL1,              /**< [GB.GG]ACL key include MAC , IPV4, MPLS */
    DRV_FTM_KEY_TYPE_ACL2,              /**< [GB.GG]ACL key include MAC , IPV4, MPLS */
    DRV_FTM_KEY_TYPE_ACL3,              /**< [GB.GG]ACL key include MAC , IPV4, MPLS */


    DRV_FTM_KEY_TYPE_ACL0_EGRESS,       /**< [GG]Egress ACL key include MAC , IPV4, IPV6, MPLS */


    DRV_FTM_KEY_TYPE_IPV4_MCAST,        /**< [GB]IPV4 mcast key*/
    DRV_FTM_KEY_TYPE_IPV6_MCAST,        /**< [GB]IPV6 mcast key*/

    DRV_FTM_KEY_TYPE_VLAN_SCL,          /**< [GB]SCL VLAN key*/
    DRV_FTM_KEY_TYPE_MAC_SCL,           /**< [GB]SCL MAC key*/
    DRV_FTM_KEY_TYPE_IPV4_SCL,          /**< [GB]SCL IPv4 key*/

    DRV_FTM_KEY_TYPE_IPV6_SCL,          /**< [GB]SCL IPv6 key*/

    DRV_FTM_KEY_TYPE_FDB,               /**< [GB]FDB key*/
    DRV_FTM_KEY_TYPE_IPV4_UCAST,        /**< [GB.GG]IPv4 Ucast key*/
    DRV_FTM_KEY_TYPE_IPV6_UCAST,        /**< [GB.GG]IPv6 Ucast key*/

    DRV_FTM_KEY_TYPE_IPV4_NAT,          /**< [GB.GG]IPv4 Nat key*/
    DRV_FTM_KEY_TYPE_IPV6_NAT,          /**< [GB.GG]IPv6 Nat key*/
    DRV_FTM_KEY_TYPE_IPV4_PBR,          /**< [GB.GG]IPv4 PBR key*/
    DRV_FTM_KEY_TYPE_IPV6_PBR,          /**< [GB.GG]IPv6 PBR key*/

    DRV_FTM_KEY_TYPE_IPV4_TUNNEL,       /**< [GB]IPv4 Tunnel key*/
    DRV_FTM_KEY_TYPE_IPV6_TUNNEL,       /**< [GB]IPv6 Tunnel key*/

    DRV_FTM_KEY_TYPE_ACL4,              /**< [GB.GG]ACL key include MAC , IPV4, MPLS */
    DRV_FTM_KEY_TYPE_ACL5,              /**< [GB.GG]ACL key include MAC , IPV4, MPLS */
    DRV_FTM_KEY_TYPE_ACL6,              /**< [GB.GG]ACL key include MAC , IPV4, MPLS */
    DRV_FTM_KEY_TYPE_ACL7,              /**< [GB.GG]ACL key include MAC , IPV4, MPLS */

    DRV_FTM_KEY_TYPE_ACL1_EGRESS,       /**< [GG]Egress ACL key include MAC , IPV4, IPV6, MPLS */
    DRV_FTM_KEY_TYPE_ACL2_EGRESS,       /**< [GG]Egress ACL key include MAC , IPV4, IPV6, MPLS */

    DRV_FTM_KEY_TYPE_MAX
};
typedef enum drv_ftm_key_type_e drv_ftm_key_type_t;


enum drv_ftm_tbl_type_e
{

    DRV_FTM_TBL_TYPE_LPM_PIPE0,     /**< [GB.GG] LPM PIPE0 table*/

    DRV_FTM_TBL_TYPE_NEXTHOP,       /**< [GB.GG] Nexthop table*/
    DRV_FTM_TBL_TYPE_FWD,           /**< [GB.GG] Fwd table*/
    DRV_FTM_TBL_TYPE_MET,           /**< [GB.GG] Met table*/
    DRV_FTM_TBL_TYPE_EDIT,          /**< [GB.GG] l2 and l3 edit table*/

    DRV_FTM_TBL_TYPE_OAM_MEP,       /**< [GB.GG] All OAM table*/

    DRV_FTM_TBL_TYPE_STATS,         /**< [GB.GG] statistics table*/
    DRV_FTM_TBL_TYPE_LM,            /**< [GB.GG] OAM LM statistics table*/
    DRV_FTM_TBL_TYPE_SCL_HASH_KEY,  /**< [GB.GG] SCL hash key table*/
    DRV_FTM_TBL_TYPE_SCL_HASH_AD,   /**< [GB.GG] SCL AD table*/

    DRV_FTM_TBL_TYPE_FIB_HASH_KEY,  /**< [GB] MAC, IP key table*/
    DRV_FTM_TBL_TYPE_LPM_HASH_KEY,  /**< [GB] LPM hash key table*/
    DRV_FTM_TBL_TYPE_FIB_HASH_AD,   /**< [GB] MAC, IP AD table*/
    DRV_FTM_TBL_TYPE_LPM_PIPE1,     /**< [GB] LPM PIPE1 table*/
    DRV_FTM_TBL_TYPE_LPM_PIPE2,     /**< [GB] LPM PIPE2 table*/
    DRV_FTM_TBL_TYPE_LPM_PIPE3,     /**< [GB] LPM PIPE3 table*/
    DRV_FTM_TBL_TYPE_MPLS,          /**< [GB] MPLS table*/

    DRV_FTM_TBL_FIB0_HASH_KEY,      /**< [GG] MAC, IPDA key table*/
    DRV_FTM_TBL_DSMAC_AD,           /**< [GG] MAC AD table*/
    DRV_FTM_TBL_FIB1_HASH_KEY,      /**< [GG] NAT, IPSA key table*/
    DRV_FTM_TBL_DSIP_AD,            /**< [GG] IP AD table*/

    DRV_FTM_TBL_XCOAM_HASH_KEY,     /**< [GG] OAM and Egress Vlan Xlate table*/
    DRV_FTM_TBL_FLOW_HASH_KEY,      /**< [GG] Flow hash key*/
    DRV_FTM_TBL_FLOW_AD,            /**< [GG] Flow Ad table*/
    DRV_FTM_TBL_IPFIX_HASH_KEY,     /**< [GG] IPFix hash key*/
    DRV_FTM_TBL_IPFIX_AD,           /**< [GG] IPFix AD table*/
    DRV_FTM_TBL_OAM_APS,            /**< [GG] APS table*/

    DRV_FTM_TBL_TYPE_MAX
};
typedef enum drv_ftm_tbl_type_e drv_ftm_tbl_type_t;


enum drv_ftm_cam_type_e
{
    DRV_FTM_CAM_TYPE_INVALID        = 0,
    DRV_FTM_CAM_TYPE_FIB_HOST0_FDB  = 1,
    DRV_FTM_CAM_TYPE_FIB_HOST0_MC   = 2,
    DRV_FTM_CAM_TYPE_FIB_HOST1_NAT  = 3,
    DRV_FTM_CAM_TYPE_FIB_HOST1_MC   = 4,
    DRV_FTM_CAM_TYPE_SCL            = 5,
    DRV_FTM_CAM_TYPE_DCN            = 6,
    DRV_FTM_CAM_TYPE_MPLS           = 7,
    DRV_FTM_CAM_TYPE_OAM            = 8,
    DRV_FTM_CAM_TYPE_XC             = 9,
    DRV_FTM_CAM_TYPE_MAX
};
typedef enum drv_ftm_cam_type_e drv_ftm_cam_type_t;

enum drv_ftm_mem_id_e
{
    DRV_FTM_SRAM0,                                      /*  CM_SHARE_RAM0           ShareRam0             */
    DRV_FTM_SRAM1,                                      /*  CM_SHARE_RAM1           ShareRam1             */
    DRV_FTM_SRAM2,                                      /*  CM_SHARE_RAM2           ShareRam2             */
    DRV_FTM_SRAM3,                                      /*  CM_SHARE_RAM3           ShareRam3             */
    DRV_FTM_SRAM4,                                      /*  CM_SHARE_RAM4           ShareRam4             */
    DRV_FTM_SRAM5,                                      /*  CM_SHARE_RAM5           ShareRam5             */

    DRV_FTM_SRAM6,                                      /*  CM_SHARE_RAM6           ShareRam6             */
    DRV_FTM_SRAM7,                                      /*  CM_DS_IPMAC_RAM0        IpMacRam0             */
    DRV_FTM_SRAM8,                                      /*  CM_DS_IPMAC_RAM1        IpMacRam1             */
    DRV_FTM_SRAM9,                                      /*  CM_DS_IPMAC_RAM2        IpMacRam2             */
    DRV_FTM_SRAM10,                                     /*  CM_DS_IPMAC_RAM3        IpMacRam3             */

    DRV_FTM_SRAM11,                                     /*  CM_USERIDHASHKEY_RAM0   UseridHashKeyRam0     */
    DRV_FTM_SRAM12,                                     /*  CM_USERIDHASHKEY_RAM1   UseridHashKeyRam1     */
    DRV_FTM_SRAM13,                                     /*  CM_USERIDHASHAD_RAM     UseridHashAdRam       */

    DRV_FTM_SRAM14,                                     /*  CM_L23EDITRAM0          L23EditRam0           */
    DRV_FTM_SRAM15,                                     /*  CM_L23EDITRAM1          L23EditRam1           */
    DRV_FTM_SRAM16,                                     /*  CM_NEXTHOPMET_RAM0      NexthopMetRam0        */
    DRV_FTM_SRAM17,                                     /*  CM_NEXTHOPMET_RAM1      NexthopMetRam1        */
    DRV_FTM_SRAM18,                                     /*  CM_DSFWD_RAM            DsFwdRam              */
    DRV_FTM_SRAM19,                                     /*  CM_STATS_RAM            StatsRam              */

    DRV_FTM_SRAM20,                                     /*  CM_POLICERCOUNTERRAM0   PolicerCounterRam0    */
    DRV_FTM_SRAM21,                                     /*  CM_POLICERCOUNTERRAM1   PolicerCounterRam1    */
    DRV_FTM_SRAM22,
    DRV_FTM_SRAM23,

    DRV_FTM_SRAM_MAX,                                   /*                                                */

    DRV_FTM_TCAM_KEY0,                                  /*  CM_Tcam key0  */
    DRV_FTM_TCAM_KEY1,                                  /*  CM_Tcam key1  */
    DRV_FTM_TCAM_KEY2,                                  /*  CM_Tcam key2  */
    DRV_FTM_TCAM_KEY3,                                  /*  CM_Tcam key3  */
    DRV_FTM_TCAM_KEY4,                                  /*  CM_Tcam key4  */
    DRV_FTM_TCAM_KEY5,                                  /*  CM_Tcam key5  */
    DRV_FTM_TCAM_KEY6,                                  /*  CM_Tcam key6  */
    DRV_FTM_TCAM_KEY7,                                  /*  CM_Tcam key7  */
    DRV_FTM_TCAM_KEY8,                                  /*  CM_Tcam key8  */
    DRV_FTM_TCAM_KEY9,                                  /*  CM_Tcam key9  */
    DRV_FTM_TCAM_KEY10,                                 /*  CM_Tcam key10 */
    DRV_FTM_TCAM_KEY11,                                 /*  CM_Tcam key11 */
    DRV_FTM_TCAM_KEY12,                                 /*  CM_Tcam key12 */
    DRV_FTM_TCAM_KEY13,                                 /*  CM_Tcam key13 */
    DRV_FTM_TCAM_KEY14,                                 /*  CM_Tcam key14 */
    DRV_FTM_TCAM_KEY15,                                 /*  CM_Tcam key15 */
    DRV_FTM_TCAM_KEYM,                                  /*                */

    DRV_FTM_TCAM_AD0,                                   /*  CM_Tcam AD0  */
    DRV_FTM_TCAM_AD1,                                   /*  CM_Tcam AD1  */
    DRV_FTM_TCAM_AD2,                                   /*  CM_Tcam AD2  */
    DRV_FTM_TCAM_AD3,                                   /*  CM_Tcam AD3  */
    DRV_FTM_TCAM_AD4,                                   /*  CM_Tcam AD4  */
    DRV_FTM_TCAM_AD5,                                   /*  CM_Tcam AD5  */
    DRV_FTM_TCAM_AD6,                                   /*  CM_Tcam AD6  */
    DRV_FTM_TCAM_AD7,                                   /*  CM_Tcam AD7  */
    DRV_FTM_TCAM_AD8,                                   /*  CM_Tcam AD8  */
    DRV_FTM_TCAM_AD9,                                   /*  CM_Tcam AD9  */
    DRV_FTM_TCAM_AD10,                                  /*  CM_Tcam AD10 */
    DRV_FTM_TCAM_AD11,                                  /*  CM_Tcam AD11 */
    DRV_FTM_TCAM_AD12,                                  /*  CM_Tcam AD12 */
    DRV_FTM_TCAM_AD13,                                  /*  CM_Tcam AD13 */
    DRV_FTM_TCAM_AD14,                                  /*  CM_Tcam AD14 */
    DRV_FTM_TCAM_AD15,                                  /*  CM_Tcam AD15 */
    DRV_FTM_TCAM_ADM,                                   /*               */

    DRV_FTM_LPM_TCAM_KEY0,                              /* CM_LPM_Tcam key0         */
    DRV_FTM_LPM_TCAM_KEY1,                              /* CM_LPM_Tcam key1         */
    DRV_FTM_LPM_TCAM_KEY2,                              /* CM_LPM_Tcam key2         */
    DRV_FTM_LPM_TCAM_KEY3,                              /* CM_LPM_Tcam key3         */
    DRV_FTM_LPM_TCAM_KEY4,                              /* CM_LPM_Tcam key4         */
    DRV_FTM_LPM_TCAM_KEY5,                              /* CM_LPM_Tcam key5         */
    DRV_FTM_LPM_TCAM_KEY6,                              /* CM_LPM_Tcam key6         */
    DRV_FTM_LPM_TCAM_KEY7,                              /* CM_LPM_Tcam key7         */
    DRV_FTM_LPM_TCAM_KEY8,                              /* CM_LPM_Tcam key8         */
    DRV_FTM_LPM_TCAM_KEY9,                              /* CM_LPM_Tcam key9         */
    DRV_FTM_LPM_TCAM_KEY10,                             /* CM_LPM_Tcam key10        */
    DRV_FTM_LPM_TCAM_KEY11,                             /* CM_LPM_Tcam key11        */
    DRV_FTM_LPM_TCAM_KEYM,                              /*                          */

    DRV_FTM_LPM_TCAM_AD0,                               /* CM_LPM_Tcam AD0          */
    DRV_FTM_LPM_TCAM_AD1,                               /* CM_LPM_Tcam AD1          */
    DRV_FTM_LPM_TCAM_AD2,                               /* CM_LPM_Tcam AD2          */
    DRV_FTM_LPM_TCAM_AD3,                               /* CM_LPM_Tcam AD3          */
    DRV_FTM_LPM_TCAM_AD4,                               /* CM_LPM_Tcam AD4          */
    DRV_FTM_LPM_TCAM_AD5,                               /* CM_LPM_Tcam AD5          */
    DRV_FTM_LPM_TCAM_AD6,                               /* CM_LPM_Tcam AD6          */
    DRV_FTM_LPM_TCAM_AD7,                               /* CM_LPM_Tcam AD7          */
    DRV_FTM_LPM_TCAM_AD8,                               /* CM_LPM_Tcam AD8          */
    DRV_FTM_LPM_TCAM_AD9,                               /* CM_LPM_Tcam AD9          */
    DRV_FTM_LPM_TCAM_AD10,                              /* CM_LPM_Tcam AD10         */
    DRV_FTM_LPM_TCAM_AD11,                              /* CM_LPM_Tcam AD11         */
    DRV_FTM_LPM_TCAM_ADM,

    DRV_FTM_MAX_ID
};;
typedef enum drv_ftm_mem_id_e drv_ftm_mem_id_t;

struct drv_ftm_tbl_info_s
{
    uint32  tbl_id;                             /**[GB]ctc_ftm_tbl_type_t*/
    uint32 mem_bitmap;                          /**[GB]Table allocation in which SRAM*/
    uint32 mem_start_offset[DRV_FTM_MEM_MAX];  /**[GB]Start Offset of SRAM*/
    uint32 mem_entry_num[DRV_FTM_MEM_MAX];     /**[GB]Entry number in SRAM*/
};
typedef struct drv_ftm_tbl_info_s drv_ftm_tbl_info_t;

/**
 @brief Profile key information
*/
struct drv_ftm_key_info_s
{
    uint8  key_size;                    /**< [HB.GB.GG]Value = {1,2,4,8}, indicates {80b,160b,320b,640b}. */
    uint32 max_key_index;               /**< [HB.GB]Key total number. key_max_index * key_size = consumed 80b tcam entry. */
    uint8  key_media;                   /**< [HB.GB]ctc_ftm_key_location_t*/
    uint8  key_id;                      /**< [HB.GB.GG]Key type*/

    uint32 tcam_bitmap;                         /**< [GG]Tcam Key tcam bitmap*/
    uint32 tcam_start_offset[DRV_FTM_MEM_MAX]; /**< [GG]Start Offset of TCAM*/
    uint32 tcam_entry_num[DRV_FTM_MEM_MAX];    /**< [GG]Entry number in TCAM*/
};
typedef struct drv_ftm_key_info_s drv_ftm_key_info_t;


struct drv_ftm_cam_s
{
    uint8 conflict_cam_num[DRV_FTM_CAM_TYPE_MAX];
};
typedef struct drv_ftm_cam_s drv_ftm_cam_t;


struct drv_ftm_profile_info_s
{
    drv_ftm_key_info_t* key_info;   /**< [HB.GB]Profile key information*/
    uint16 key_info_size;           /**< [HB.GB]Size of key_info, multiple of sizeof(ctc_ftm_key_info_t) */
    uint8 profile_type;             /**< [GB]Profile type, refer to ctc_ftm_profile_type_t*/
    uint8  lpm_mode;

    drv_ftm_tbl_info_t* tbl_info;               /**< [GB]table information  */
    uint16 tbl_info_size;                       /**< [GB]Size of tbl_info, multiple of sizeof(ctc_ftm_tbl_info_t) */

    drv_ftm_cam_t cam_info;
};
typedef struct drv_ftm_profile_info_s drv_ftm_profile_info_t;

enum drv_ftm_info_type_e
{
    DRV_FTM_INFO_TYPE_CAM,
    DRV_FTM_INFO_TYPE_TCAM,
    DRV_FTM_INFO_TYPE_EDRAM,
    DRV_FTM_INFO_TYPE_LPM_MODEL,        /* ftm lpm model */
    DRV_FTM_INFO_TYPE_NAT_PBR_EN,       /* ftm nat/pbr enable */
    DRV_FTM_INFO_TYPE_MAX,
};
typedef enum drv_ftm_info_type_e drv_ftm_info_type_t;

#define DRV_FTM_FTM_MAX_EDRAM_MEM_NUM       5
#define DRV_FTM_FTM_MAX_TCAM_TBL_NUM        15

struct drv_ftm_info_detail_s
{
    uint8 info_type;                /*< [GG]drv_ftm_info_type_t */
    uint8 tbl_type;                 /*< [GG]drv_ftm_key_type_t or drv_ftm_tbl_type_t or drv_ftm_cam_type_t*/
    uint8 tbl_entry_num;

    /*for edram*/
    uint8 mem_id[DRV_FTM_FTM_MAX_EDRAM_MEM_NUM];
    uint32 entry_num[DRV_FTM_FTM_MAX_EDRAM_MEM_NUM];
    uint32 offset[DRV_FTM_FTM_MAX_EDRAM_MEM_NUM];

    /*for tcam*/
    uint32 tbl_id[DRV_FTM_FTM_MAX_TCAM_TBL_NUM];
    uint32 key_size[DRV_FTM_FTM_MAX_TCAM_TBL_NUM];
    uint32 max_idx[DRV_FTM_FTM_MAX_TCAM_TBL_NUM];

    /* for cam */
    uint8 max_size;
    uint8 used_size;

    union {
        uint32 lpm_model;
        uint32 nat_pbr_en;
    }l3;

    char str[64];
};
typedef struct drv_ftm_info_detail_s drv_ftm_info_detail_t;

extern int32
drv_ftm_map_tcam_index(uint8 lchip,
                       uint32 tbl_id,
                       uint32 old_index,
                       uint32* new_index);

extern int32
drv_ftm_lookup_ctl_init(uint8 lchip);

extern int32
drv_ftm_mem_alloc(void* profile_info);

extern int32
drv_ftm_get_lpm_tcam_info(uint32 tblid, uint32* p_entry_offset, uint32* p_entry_num, uint32* p_entry_size);

extern int32
drv_ftm_alloc_cam_offset(uint32 tbl_id, uint32 *offset);
extern int32
drv_ftm_free_cam_offset(uint32 tbl_id, uint32 offset);

extern int32
drv_ftm_get_info_detail(drv_ftm_info_detail_t* p_ftm_info);

extern int32
drv_goldengate_ftm_check_tbl_recover(uint8 mem_id, uint32 ram_offset, uint8* p_recover, uint32* p_tblid);

extern int32
drv_ftm_map_compress_idx_real(uint8 lchip, uint32 tbl_id, uint32 old_index,uint32* new_index);

extern int32
drv_ftm_get_host1_poly_type(uint32* poly, uint32* poly_len, uint32* type);


extern int32
drv_ftm_get_sram_type(uint32 mem_id, uint8* p_sram_type);

extern int32
drv_ftm_get_hash_poly(uint8 lchip, uint32 mem_id, uint8 sram_type, uint32* drv_poly);

extern int32
drv_ftm_set_hash_poly(uint8 lchip, uint32 mem_id, uint8 sram_type, uint32 drv_poly);

#ifdef __cplusplus
}
#endif

#endif


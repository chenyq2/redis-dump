/**
  @file drv_io.h

  @date 2010-02-26

  @version v5.1

  The file implement driver IOCTL defines and macros
*/

#ifndef _DRV_IO_H_
#define _DRV_IO_H_

#include "drv_enum.h"
#include "drv_common.h"
#include "drv_api.h"


/**********************************************************************************
              Define Typedef, define and Data Structure
***********************************************************************************/

#define HASH_KEY_LENGTH_MODE_SINGLE      0
#define HASH_KEY_LENGTH_MODE_DOUBLE      1
#define HASH_KEY_LENGTH_MODE_QUAD        2

#define FIB_HOST0_CAM_NUM          ( 32 )
#define FIB_HOST1_CAM_NUM          ( 32 )
#define FLOW_HASH_CAM_NUM          ( 32 )
#define USER_ID_HASH_CAM_NUM       ( 32 )
#define XC_OAM_HASH_CAM_NUM        ( 128 )

#define _DRV_FIB_ACC_M_1

struct addr_array_s
{
    uint8 valid;
    uint32 start_addr;
    uint32 end_addr;
};
typedef struct addr_array_s addr_array_t;

/**********************************************************************************
                      Define API function interfaces
***********************************************************************************/
/**
 @brief remove tcam entry interface according to key id and index
*/
extern int32
drv_chip_sram_tbl_read(uint8 chip_id, tbls_id_t tbl_id, uint32 index, uint32* data);

extern int32
drv_chip_sram_tbl_write(uint8 chip_id, tbls_id_t tbl_id, uint32 index, uint32* data);

extern int32
drv_chip_tcam_tbl_read(uint8 chip_id_offset, tbls_id_t tbl_id, uint32 index, tbl_entry_t *entry);

extern int32
drv_chip_tcam_tbl_write(uint8 chip_id_offset, tbls_id_t tbl_id, uint32 index, tbl_entry_t* entry);

extern int32
drv_chip_tcam_tbl_remove(uint8 chip_id_offset, tbls_id_t tbl_id, uint32 index);

#endif /*end of _DRV_IO_H*/


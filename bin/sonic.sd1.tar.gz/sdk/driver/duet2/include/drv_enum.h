#ifndef __DRV_ENUM_H__
#define __DRV_ENUM_H__

#include "sal_types.h"

enum FLOWPORTTYPE {
    DRV_FLOWPORTTYPE_BITMAP                      = 0x0,
    DRV_FLOWPORTTYPE_GPORT                       = 0x1,
    DRV_FLOWPORTTYPE_LPORT                       = 0x2,
    DRV_FLOWPORTTYPE_METADATA                    = 0x3,
};

enum TCAMKEYTYPE {
    DRV_TCAMKEYTYPE_MACKEY_160                   = 0x0,
    DRV_TCAMKEYTYPE_L3KEY_160                    = 0x1,
    DRV_TCAMKEYTYPE_L3KEY_320                    = 0x2,
    DRV_TCAMKEYTYPE_IPV6KEY_320                  = 0x3,
    DRV_TCAMKEYTYPE_IPV6KEY_640                  = 0x4,
    DRV_TCAMKEYTYPE_MACL3KEY_320                 = 0x5,
    DRV_TCAMKEYTYPE_MACL3KEY_640                 = 0x6,
    DRV_TCAMKEYTYPE_MACIPV6KEY_640               = 0x7,
    DRV_TCAMKEYTYPE_CIDKEY_160                   = 0x8,
    DRV_TCAMKEYTYPE_SHORTKEY_80                  = 0x9,
    DRV_TCAMKEYTYPE_FORWARDKEY_320               = 0xa,
    DRV_TCAMKEYTYPE_FORWARDKEY_640               = 0xb,
};

enum FIBNATPBRTCAMKEYTYPE {
    DRV_FIBNATPBRTCAMKEYTYPE_IPV4PBR             = 0x0,
    DRV_FIBNATPBRTCAMKEYTYPE_IPV6PBR             = 0x1,
    DRV_FIBNATPBRTCAMKEYTYPE_IPV4NAT             = 0x2,
    DRV_FIBNATPBRTCAMKEYTYPE_IPV6NAT             = 0x3,
};

enum UDFTYPE {
    DRV_UDFTYPE_L2UDF                            = 0x0,
    DRV_UDFTYPE_L3UDF                            = 0x1,
    DRV_UDFTYPE_L4UDF                            = 0x2,
    DRV_UDFTYPE_METADATA                         = 0x3,
};
enum VLANIDACTIONTYPE {
    DRV_VLANIDACTIONTYPE_NONE                    = 0x0,
    DRV_VLANIDACTIONTYPE_SWAP                    = 0x1,
    DRV_VLANIDACTIONTYPE_USER                    = 0x2,
};
enum VTAGACTIONTYPE {
    DRV_VTAGACTIONTYPE_NONE                      = 0x0,
    DRV_VTAGACTIONTYPE_MODIFY                    = 0x1,
    DRV_VTAGACTIONTYPE_ADD                       = 0x2,
    DRV_VTAGACTIONTYPE_DELETE                    = 0x3,
};
enum EGRESSXCOAMHASHTYPE {
    EGRESSXCOAMHASHTYPE_DISABLE              = 0x0,
    EGRESSXCOAMHASHTYPE_DOUBLEVLANPORT       = 0x1,
    EGRESSXCOAMHASHTYPE_SVLANPORT            = 0x2,
    EGRESSXCOAMHASHTYPE_CVLANPORT            = 0x3,
    EGRESSXCOAMHASHTYPE_SVLANCOSPORT         = 0x4,
    EGRESSXCOAMHASHTYPE_CVLANCOSPORT         = 0x5,
    EGRESSXCOAMHASHTYPE_PORTVLANCROSS        = 0x6,
    EGRESSXCOAMHASHTYPE_PORTCROSS            = 0x7,
    EGRESSXCOAMHASHTYPE_PORT                 = 0x8,
    EGRESSXCOAMHASHTYPE_SVLANPORTMAC         = 0x9,
    EGRESSXCOAMHASHTYPE_TUNNELPBB            = 0xa,
    EGRESSXCOAMHASHTYPE_ETH                  = 0x10,
    EGRESSXCOAMHASHTYPE_BFD                  = 0x11,
    EGRESSXCOAMHASHTYPE_MPLSLABEL            = 0x12,
    EGRESSXCOAMHASHTYPE_MPLSSECTION          = 0x13,
    EGRESSXCOAMHASHTYPE_RMEP                 = 0x14,
};

enum FIBHOST0PRIMARYHASHTYPE {
    FIBHOST0PRIMARYHASHTYPE_FCOE             = 0x0,
    FIBHOST0PRIMARYHASHTYPE_IPV4             = 0x1,
    FIBHOST0PRIMARYHASHTYPE_IPV6MCAST        = 0x2,
    FIBHOST0PRIMARYHASHTYPE_IPV6UCAST        = 0x3,
    FIBHOST0PRIMARYHASHTYPE_MAC              = 0x4,
    FIBHOST0PRIMARYHASHTYPE_MACIPV6MCAST     = 0x5,
    FIBHOST0PRIMARYHASHTYPE_TRILL            = 0x6,
};

enum FIBHOST1PRIMARYHASHTYPE {
    FIBHOST1PRIMARYHASHTYPE_IPV4             = 0x0,
    FIBHOST1PRIMARYHASHTYPE_IPV6NATDA        = 0x1,
    FIBHOST1PRIMARYHASHTYPE_IPV6NATSA        = 0x2,
    FIBHOST1PRIMARYHASHTYPE_OTHER            = 0x3,
};

enum FLOWHASHTYPE {
    FLOWHASHTYPE_INVALID                     = 0x0,
    FLOWHASHTYPE_L2                          = 0x1,
    FLOWHASHTYPE_L2L3                        = 0x2,
    FLOWHASHTYPE_L3IPV4                      = 0x3,
    FLOWHASHTYPE_L3IPV6                      = 0x4,
    FLOWHASHTYPE_L3MPLS                      = 0x5,
};

enum IPFIXHASHTYPE {
    IPFIXHASHTYPE_INVALID                    = 0x0,
    IPFIXHASHTYPE_L2                         = 0x1,
    IPFIXHASHTYPE_L2L3                       = 0x2,
    IPFIXHASHTYPE_L3IPV4                     = 0x3,
    IPFIXHASHTYPE_L3IPV6                     = 0x4,
    IPFIXHASHTYPE_L3MPLS                     = 0x5,
};

enum OAMHASHTYPE {
    OAMHASHTYPE_ETH                          = 0x0,
    OAMHASHTYPE_BFD                          = 0x1,
    OAMHASHTYPE_MPLSLABEL                    = 0x2,
    OAMHASHTYPE_MPLSSECTION                  = 0x3,
    OAMHASHTYPE_RMEP                         = 0x4,
};

enum USERIDHASHTYPE {
    USERIDHASHTYPE_DISABLE                   = 0x0,
    USERIDHASHTYPE_DOUBLEVLANPORT            = 0x1,
    USERIDHASHTYPE_SVLANPORT                 = 0x2,
    USERIDHASHTYPE_CVLANPORT                 = 0x3,
    USERIDHASHTYPE_SVLANCOSPORT              = 0x4,
    USERIDHASHTYPE_CVLANCOSPORT              = 0x5,
    USERIDHASHTYPE_MACPORT                   = 0x6,
    USERIDHASHTYPE_IPV4PORT                  = 0x7,
    USERIDHASHTYPE_MAC                       = 0x8,
    USERIDHASHTYPE_IPV4SA                    = 0x9,
    USERIDHASHTYPE_PORT                      = 0xa,
    USERIDHASHTYPE_SVLANMACSA                = 0xb,
    USERIDHASHTYPE_SVLAN                     = 0xc,
    USERIDHASHTYPE_ECIDNAMESPACE             = 0xd,
    USERIDHASHTYPE_INGECIDNAMESPACE          = 0xe,
    USERIDHASHTYPE_IPV6SA                    = 0xf,
    USERIDHASHTYPE_IPV6PORT                  = 0x10,
    USERIDHASHTYPE_CAPWAPSTASTATUS           = 0x11,
    USERIDHASHTYPE_CAPWAPSTASTATUSMC         = 0x12,
    USERIDHASHTYPE_CAPWAPMACDAFORWARD        = 0x13,
    USERIDHASHTYPE_CAPWAPVLANFORWARD         = 0x14,
    USERIDHASHTYPE_TUNNELIPV4                = 0x15,
    USERIDHASHTYPE_TUNNELIPV4GREKEY          = 0x16,
    USERIDHASHTYPE_TUNNELIPV4UDP             = 0x17,
    USERIDHASHTYPE_TUNNELPBB                 = 0x18,
    USERIDHASHTYPE_TUNNELTRILLUCRPF          = 0x19,
    USERIDHASHTYPE_TUNNELTRILLUCDECAP        = 0x1a,
    USERIDHASHTYPE_TUNNELTRILLMCRPF          = 0x1b,
    USERIDHASHTYPE_TUNNELTRILLMCDECAP        = 0x1c,
    USERIDHASHTYPE_TUNNELTRILLMCADJ          = 0x1d,
    USERIDHASHTYPE_TUNNELIPV4RPF             = 0x1e,
    USERIDHASHTYPE_TUNNELIPV4UCVXLANMODE0    = 0x1f,
    USERIDHASHTYPE_TUNNELIPV4UCVXLANMODE1    = 0x20,
    USERIDHASHTYPE_TUNNELIPV6UCVXLANMODE0    = 0x21,
    USERIDHASHTYPE_TUNNELIPV6UCVXLANMODE1    = 0x22,
    USERIDHASHTYPE_TUNNELIPV4UCNVGREMODE0    = 0x23,
    USERIDHASHTYPE_TUNNELIPV4UCNVGREMODE1    = 0x24,
    USERIDHASHTYPE_TUNNELIPV6UCNVGREMODE0    = 0x25,
    USERIDHASHTYPE_TUNNELIPV6UCNVGREMODE1    = 0x26,
    USERIDHASHTYPE_TUNNELIPV4MCVXLANMODE0    = 0x27,
    USERIDHASHTYPE_TUNNELIPV4VXLANMODE1      = 0x28,
    USERIDHASHTYPE_TUNNELIPV6MCVXLANMODE0    = 0x29,
    USERIDHASHTYPE_TUNNELIPV6MCVXLANMODE1    = 0x2a,
    USERIDHASHTYPE_TUNNELIPV4MCNVGREMODE0    = 0x2b,
    USERIDHASHTYPE_TUNNELIPV4NVGREMODE1      = 0x2c,
    USERIDHASHTYPE_TUNNELIPV6MCNVGREMODE0    = 0x2d,
    USERIDHASHTYPE_TUNNELIPV6MCNVGREMODE1    = 0x2e,
    USERIDHASHTYPE_TUNNELIPV4CAPWAP          = 0x2f,
    USERIDHASHTYPE_TUNNELIPV6CAPWAP          = 0x30,
    USERIDHASHTYPE_TUNNELCAPWAPRMAC          = 0x31,
    USERIDHASHTYPE_TUNNELCAPWAPRMACRID       = 0x32,
    USERIDHASHTYPE_TUNNELIPV4DA              = 0x33,
    USERIDHASHTYPE_TUNNELMPLS                = 0x34,
    USERIDHASHTYPE_SCLFLOWL2                 = 0x35,
};

enum USERIDPORTHASHTYPE {
    USERIDPORTHASHTYPE_DISABLE               = 0x0,
    USERIDPORTHASHTYPE_DOUBLEVLANPORT        = 0x1,
    USERIDPORTHASHTYPE_SVLANPORT             = 0x2,
    USERIDPORTHASHTYPE_CVLANPORT             = 0x3,
    USERIDPORTHASHTYPE_SVLANCOSPORT          = 0x4,
    USERIDPORTHASHTYPE_CVLANCOSPORT          = 0x5,
    USERIDPORTHASHTYPE_MACPORT               = 0x6,
    USERIDPORTHASHTYPE_IPSAPORT              = 0x7,
    USERIDPORTHASHTYPE_MAC                   = 0x8,
    USERIDPORTHASHTYPE_IPSA                  = 0x9,
    USERIDPORTHASHTYPE_PORT                  = 0xa,
    USERIDPORTHASHTYPE_SVLANMACSA            = 0xb,
    USERIDPORTHASHTYPE_SVLAN                 = 0xc,
    USERIDPORTHASHTYPE_ECIDNAMESPACE         = 0xd,
    USERIDPORTHASHTYPE_INGECIDNAMESPACE      = 0xe,
    USERIDPORTHASHTYPE_TUNNEL                = 0x1d,
    USERIDPORTHASHTYPE_SCLFLOW               = 0x1e,
    USERIDPORTHASHTYPE_TRILL                 = 0x1f,
};

enum FIBHOST0HASHTYPE {
    FIBHOST0HASHTYPE_FCOE                    = 0x0,
    FIBHOST0HASHTYPE_IPV4                    = 0x1,
    FIBHOST0HASHTYPE_IPV6MCAST               = 0x2,
    FIBHOST0HASHTYPE_IPV6UCAST               = 0x3,
    FIBHOST0HASHTYPE_MAC                     = 0x4,
    FIBHOST0HASHTYPE_MACIPV6MCAST            = 0x5,
    FIBHOST0HASHTYPE_TRILL                   = 0x6,
};

enum FIBHOST1HASHTYPE {
    FIBHOST1HASHTYPE_FCOERPF                 = 0x0,
    FIBHOST1HASHTYPE_IPV4MCAST               = 0x1,
    FIBHOST1HASHTYPE_IPV4NATDAPORT           = 0x2,
    FIBHOST1HASHTYPE_IPV4NATSAPORT           = 0x3,
    FIBHOST1HASHTYPE_IPV6MCAST               = 0x4,
    FIBHOST1HASHTYPE_IPV6NATDAPORT           = 0x5,
    FIBHOST1HASHTYPE_IPV6NATSAPORT           = 0x6,
    FIBHOST1HASHTYPE_MACIPV4MCAST            = 0x7,
    FIBHOST1HASHTYPE_MACIPV6MCAST            = 0x8,
    FIBHOST1HASHTYPE_TRILLMCASTVLAN          = 0x9,
};

//Field Enum
#define CTC_FIELD_ENUM(ModuleName, RegName, FieldName, Bits, ...) \
  RegName##_##FieldName##_f,

//Field Addr
#define CTC_FIELD_ADDR(ModuleName, RegName, FieldName, Bits, ...) \
  static segs_t RegName##_##FieldName##_tbl_segs[] = {__VA_ARGS__};

//Field Info
#define CTC_FIELD_INFO(ModuleName, RegName, FieldName, Bits, ...) \
   { \
      #FieldName, \
      Bits, \
      sizeof(RegName##_##FieldName##_tbl_segs) / sizeof(segs_t), \
      RegName##_##FieldName##_tbl_segs, \
   },

//DS Field List Seperator
#define CTC_DS_SEPERATOR_INFO(ModuleName, RegName, SliceType, OpType, Entry, Word, ...) \
 }; \
 static fields_t RegName##_tbl_fields[] = {


//DS Field Sepertor
#define CTC_DS_SEPERATOR_ENUM(ModuleName, RegName, SliceType, OpType, Entry, Word, ...) \
  RegName##__f = -1,

//DS ENUM
#define CTC_DS_ENUM(ModuleName, RegName, SliceType, OpType, Entry, Word, ...) \
   RegName##_t,

//DS TYPE
#define CTC_DS_TYPE(ModuleName, RegName, SliceType, OpType, Entry, Word, ...) \
  typedef struct {uint32 m[Word];} RegName##_m;

//DS ADDR
#define CTC_DS_ADDR(ModuleName, RegName, SliceType, OpType, Entry, Word, ...) \
   static addrs_t RegName##_tbl_addrs[] = {__VA_ARGS__};

//DS LIST
#define CTC_DS_INFO(ModuleName, RegName, SliceType, OpType, Entry, Word, ...) \
   { \
      #RegName, \
      SliceType, \
      OpType, \
      Entry, \
      Word*4, \
      sizeof(RegName##_tbl_addrs)/sizeof(addrs_t), \
      RegName##_tbl_addrs, \
      sizeof(RegName##_tbl_fields)/sizeof(fields_t), \
      RegName##_tbl_fields, \
      NULL, \
   },
#define CTC_MODULE_DS(ModuleName, RegName, SliceType, OpType, Entry, Word, ...) \
   RegName##_t,

#define CTC_MODULE_ENUM(ModuleName, InstNum) \
     ModuleName##_m,

#define CTC_MODULE_INFO(ModuleName, InstNum) \
     {#ModuleName, \
     	InstNum, \
     	dbg_##ModuleName##_tbl_id_list, \
     	sizeof(dbg_##ModuleName##_tbl_id_list)/sizeof(tbls_id_t), \
     },
#define CTC_MODULE_SEPERATOR(ModuleName, InstNum) \
   }; \
   static tbls_id_t dbg_##ModuleName##_tbl_id_list[]  = {

#undef DRV_DEF_C
#undef DRV_DEF_M
#undef DRV_DEF_D
#undef DRV_DEF_F

//drv_type.h:
#ifdef DRV_DEF_C
	#error DRV_DEF_C has been defined
#endif

#ifdef DRV_DEF_M
	#error DRV_DEF_M has been defined
#endif

#ifdef DRV_DEF_D
	#error DRV_DEF_D has been defined
#endif

#ifdef DRV_DEF_F
	#error DRV_DEF_F has been defined
#endif
#define DRV_DEF_C(MaxInstNum, MaxEntry, MaxWord, MaxBits,MaxStartPos,MaxSegSize)

// Field Enum
#define DRV_DEF_M(ModuleName, InstNum)
#define DRV_DEF_D(ModuleName, InstNum, RegName, SliceType, OpType, Entry, Word, ...) \
        CTC_DS_SEPERATOR_ENUM(ModuleName, RegName, SliceType, OpType, Entry, Word, __VA_ARGS__)
#define DRV_DEF_F(ModuleName, InstNum, RegName, FieldName, Bits, ...) \
        CTC_FIELD_ENUM(ModuleName, RegName, FieldName, Bits, __VA_ARGS__)
typedef enum fld_id_e {
#include "drv_ds.h"
} fld_id_t;
#undef DRV_DEF_M
#undef DRV_DEF_D
#undef DRV_DEF_F

// DS Enum
#define DRV_DEF_M(ModuleName, InstNum)
#define DRV_DEF_D(ModuleName, InstNum, RegName, SliceType, OpType, Entry, Word, ...) \
        CTC_DS_ENUM(ModuleName, RegName, SliceType, OpType, Entry, Word, __VA_ARGS__)
#define DRV_DEF_F(ModuleName, InstNum, RegName, FieldName, Bits, ...)
typedef enum tbls_id_e {
#include "drv_ds.h"
   MaxTblId_t
} tbls_id_t;
#undef DRV_DEF_M
#undef DRV_DEF_D
#undef DRV_DEF_F

// DS Type
#define DRV_DEF_M(ModuleName, InstNum)
#define DRV_DEF_D(ModuleName, InstNum, RegName, SliceType, OpType, Entry, Word, ...) \
        CTC_DS_TYPE(ModuleName, RegName, SliceType, OpType, Entry, Word, __VA_ARGS__)
#define DRV_DEF_F(ModuleName, InstNum, RegName, FieldName, Bits, ...)
#include "drv_ds.h"
#undef DRV_DEF_M
#undef DRV_DEF_D
#undef DRV_DEF_F


#undef DRV_DEF_C

#endif // __DRV_TYPE_H__

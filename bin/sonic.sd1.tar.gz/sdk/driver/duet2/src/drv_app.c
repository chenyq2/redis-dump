/**
  @file drv_acc.c

  @date 2010-02-26

  @version v5.1

  The file implement driver acc IOCTL defines and macros
*/

#include "sal.h"
#include "drv_api.h"
#include "drv_ftm.h"
#include "drv_common.h"
#include "drv_error.h"
#include "drv_enum.h"
#include "drv_chip_agent.h"  /*delete later, TBD*/

/**********************************************************************************
              Define Gloabal var, Typedef, define and Data Structure
***********************************************************************************/

enum drv_acc_hash_module_e
{
    DRV_ACC_HASH_MODULE_FDB,
    DRV_ACC_HASH_MODULE_FIB_HOST0,
    DRV_ACC_HASH_MODULE_FIB_HOST1,
    DRV_ACC_HASH_MODULE_EGRESS_XC,
    DRV_ACC_HASH_MODULE_FLOW,
    DRV_ACC_HASH_MODULE_USERID,
    DRV_ACC_HASH_MODULE_MAC_LIMIT,
    DRV_ACC_HASH_MODULE_IPFIX,
    DRV_ACC_HASH_MODULE_CID,
    DRV_ACC_HASH_MODULE_NUM,
};
typedef enum drv_acc_hash_module_e drv_acc_hash_module_t;

enum hash_module_e
{
    HASH_MODULE_EGRESS_XC,
    HASH_MODULE_FIB_HOST0,
    HASH_MODULE_FIB_HOST1,
    HASH_MODULE_FLOW,
    HASH_MODULE_IPFIX,
    HASH_MODULE_USERID,
    HASH_MODULE_NUM,
};
typedef enum hash_module_e hash_module_t;

enum drv_acc_chip_type_e
{
    DRV_ACC_CHIP_MAC_WRITE_BY_INDEX,       /*0*/
    DRV_ACC_CHIP_MAC_WRITE_BY_KEY,         /*1*/
    DRV_ACC_CHIP_MAC_DEL_BY_INDEX,         /*2*/
    DRV_ACC_CHIP_MAC_DEL_BY_KEY,           /*3*/
    DRV_ACC_CHIP_MAC_FLUSH_BY_PORT_VLAN,   /*4*/
    DRV_ACC_CHIP_MAC_FLUSH_DUMP_BY_ALL,    /*5*/
    DRV_ACC_CHIP_MAC_LOOKUP_BY_KEY,        /*6*/
    DRV_ACC_CHIP_HOST0_lOOKUP_BY_KEY,      /*7*/
    DRV_ACC_CHIP_HOST0_lOOKUP_BY_INDEX,    /*8*/
    DRV_ACC_CHIP_HOST0_WRITE_BY_INDEX,     /*9*/
    DRV_ACC_CHIP_HOST0_WRITE_BY_KEY,       /*10*/
    DRV_ACC_CHIP_LIMIT_UPDATE,             /*11*/
    DRV_ACC_CHIP_LIMIT_READ,               /*12*/
    DRV_ACC_CHIP_LIMIT_WRITE,              /*13*/
    DRV_ACC_CHIP_MAC_FLUSH_BY_MAC_PORT,    /*14*/
    DRV_ACC_CHIP_MAC_DUMP_BY_PORT_VLAN,    /*15*/
    DRV_ACC_CHIP_MAX_TYPE
};
typedef enum drv_acc_chip_type_e drv_acc_chip_type_t;

enum drv_ipfix_acc_req_type_e
{
    DRV_IPFIX_REQ_WRITE_BY_IDX,
    DRV_IPFIX_REQ_WRITE_BY_KEY,
    DRV_IPFIX_REQ_LKP_BY_KEY,
    DRV_IPFIX_REQ_LKP_BY_IDX
};
typedef enum drv_ipfix_acc_req_type_e drv_ipfix_acc_req_type_t;

extern drv_master_t** p_drv_master;

#define DRV_FIB_ACC_SLEEP_TIME    1

#define FIB_ACC_LOCK(chip_id)    \
  if(p_drv_master[chip_id]->fib_acc_mutex) {sal_mutex_lock(p_drv_master[chip_id]->fib_acc_mutex);}
#define FIB_ACC_UNLOCK(chip_id)  \
  if(p_drv_master[chip_id]->fib_acc_mutex) {sal_mutex_unlock(p_drv_master[chip_id]->fib_acc_mutex);}
#define CPU_ACC_LOCK(chip_id)    \
  if(p_drv_master[chip_id]->cpu_acc_mutex) {sal_mutex_lock(p_drv_master[chip_id]->cpu_acc_mutex);}
#define CPU_ACC_UNLOCK(chip_id)  \
  if(p_drv_master[chip_id]->cpu_acc_mutex) {sal_mutex_unlock(p_drv_master[chip_id]->cpu_acc_mutex);}
#define IPFIX_ACC_LOCK(chip_id)  \
  if(p_drv_master[chip_id]->ipfix_acc_mutex) {sal_mutex_lock(p_drv_master[chip_id]->ipfix_acc_mutex);}
#define IPFIX_ACC_UNLOCK(chip_id)\
  if(p_drv_master[chip_id]->ipfix_acc_mutex) {sal_mutex_unlock(p_drv_master[chip_id]->ipfix_acc_mutex);}
#define CID_ACC_UNLOCK(chip_id)\
  if(p_drv_master[chip_id]->cid_acc_mutex) {sal_mutex_unlock(p_drv_master[chip_id]->cid_acc_mutex);}
#define CID_ACC_LOCK(chip_id)  \
  if(p_drv_master[chip_id]->cid_acc_mutex) {sal_mutex_lock(p_drv_master[chip_id]->cid_acc_mutex);}

#define SINGLE_KEY_BYTE           sizeof(DsFibHost0MacHashKey_m)
#define DOUBLE_KEY_BYTE           sizeof(DsFibHost0Ipv6UcastHashKey_m)
#define QUAD_KEY_BYTE             sizeof(DsFibHost0HashCam_m)
#define DS_USER_ID_HASH_CAM_BYTES sizeof(DsUserIdHashCam_m)

extern int32
drv_model_hash_combined_key( uint8* dest_key, uint8* src_key, uint32 len, uint32 tbl_id);
extern int32
drv_model_hash_mask_key( uint8* dest_key, uint8* src_key, hash_module_t hash_module, uint32 key_type);
extern int32
drv_model_hash_un_combined_key( uint8* dest_key, uint8* src_key, uint32 len, uint32 tbl_id);

int32
drv_acc_host0_prepare(uint8 lchip, drv_acc_in_t* acc_in, uint32* req);
int32
drv_acc_host0_process(uint8 chip_id, uint32* i_cpu_req, uint32* o_cpu_rlt);
int32
drv_acc_host0(uint8 chip_id, drv_acc_in_t* acc_in, drv_acc_out_t* acc_out);

int32
drv_acc_host0_result(uint8 lchip, drv_acc_in_t* acc_in, uint32* fib_acc_cpu_rlt, drv_acc_out_t* out);


uint32 g_drv_io_is_asic;         /*delete later, TBD*/


typedef struct
{
    uint32 key_index;
    uint32 tbl_id;
    uint8 is_read;
    uint8 cam_num;
    uint8 is_left;     /*for cid acc*/
    uint8 is_high;     /*for cid acc*/
    void* data;
    uint8  is_cam;
    uint8  cam_step;
    uint8  conflict;  /*for asic lookup result*/
    uint8  valid;     /*for asic lookup result*/
}drv_cpu_acc_prepare_info_t;


static int32
drv_get_cam_info(uint8 hash_module, uint32* tbl_id, uint8* num)
{
    if (hash_module == DRV_ACC_HASH_MODULE_FIB_HOST1)
    {
        *tbl_id = DsFibHost1HashCam_t;
        *num = FIB_HOST1_CAM_NUM;
    }
    else if (hash_module == DRV_ACC_HASH_MODULE_EGRESS_XC)
    {
        *tbl_id = DsEgressXcOamHashCam_t;
        *num = XC_OAM_HASH_CAM_NUM;
    }
    else if (hash_module == DRV_ACC_HASH_MODULE_FLOW)
    {
        *tbl_id = DsFlowHashCam_t;
        *num = FLOW_HASH_CAM_NUM;
    }
    else if (hash_module == DRV_ACC_HASH_MODULE_USERID)
    {
        *tbl_id = DsUserIdHashCam_t;
        *num = USER_ID_HASH_CAM_NUM;
    }
    else
    {
        return DRV_E_INVAILD_TYPE;
    }

    return DRV_E_NONE;
}

static int32
_drv_acc_hash_get_valid(uint8 lchip, uint8 hash_module, uint32* p_valid)
{
    uint32 valid = 0;
    uint32 cmd = 0;
    uint32 data[MAX_ENTRY_BYTE / 4] = { 0 };

    if (DRV_ACC_HASH_MODULE_FIB_HOST1 == hash_module)
    {
        cmd = DRV_IOR(FibHost1FlowHashCpuLookupReq_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, data));
        valid = GetFibHost1FlowHashCpuLookupReq(V, cpuLookupReqValid_f, data);
    }
    else if (DRV_ACC_HASH_MODULE_USERID == hash_module)
    {
        cmd = DRV_IOR(UserIdCpuLookupReq_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, data));
        valid = GetUserIdCpuLookupReq(V, cpuLookupReqValid_f, data);
    }
    else if (DRV_ACC_HASH_MODULE_EGRESS_XC == hash_module)
    {
        cmd = DRV_IOR(EgressXcOamCpuLookupReq_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, data));
        valid = GetEgressXcOamCpuLookupReq(V, cpuLookupReqValid_f, data);
    }
    else if (DRV_ACC_HASH_MODULE_FLOW == hash_module)
    {
        cmd = DRV_IOR(FibHost1FlowHashCpuLookupReq_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, data));
        valid = GetFibHost1FlowHashCpuLookupReq(V, cpuLookupReqValid_f, data);
    }
    else if (DRV_ACC_HASH_MODULE_CID == hash_module)
    {
        cmd = DRV_IOR(CidPairHashCpuLookupReq_t, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, data));
        valid = GetCidPairHashCpuLookupReq(V, cpuLookupReqValid_f, data);
    }
    *p_valid = valid;

    return  DRV_E_NONE;
}

static int32
_drv_acc_get_hash_module_from_tblid(uint32 tbl_id, uint8* p_module)
{
    if (tbl_id == DsFibHost0MacHashKey_t)
    {
        *p_module = DRV_ACC_HASH_MODULE_FDB;
    }
    else if ((tbl_id == DsFibHost0FcoeHashKey_t) || (tbl_id == DsFibHost0Ipv4HashKey_t) ||
       (tbl_id == DsFibHost0Ipv6McastHashKey_t) || (tbl_id == DsFibHost0Ipv6UcastHashKey_t) ||
       (tbl_id == DsFibHost0MacIpv6McastHashKey_t) || (tbl_id == DsFibHost0TrillHashKey_t))
    {
        *p_module = DRV_ACC_HASH_MODULE_FIB_HOST0;
    }
    else if ((tbl_id >= DsFibHost1FcoeRpfHashKey_t) && (tbl_id <= DsFibHost1TrillMcastVlanHashKey_t))
    {
        *p_module = DRV_ACC_HASH_MODULE_FIB_HOST1;
    }
    else if (((tbl_id >= DsEgressXcOamBfdHashKey_t) && (tbl_id <= DsEgressXcOamRmepHashKey_t)) ||
            ((tbl_id >= DsEgressXcOamCvlanCosPortHashKey_t) && (tbl_id <= DsEgressXcOamTunnelPbbHashKey_t)))
    {
        *p_module = DRV_ACC_HASH_MODULE_EGRESS_XC;
    }
    else if ((tbl_id == DsFlowL2HashKey_t) || (tbl_id == DsFlowL2L3HashKey_t) ||
       (tbl_id == DsFlowL3Ipv4HashKey_t) || (tbl_id == DsFlowL3Ipv6HashKey_t) ||
       (tbl_id == DsFlowL3MplsHashKey_t))
    {
        *p_module = DRV_ACC_HASH_MODULE_FLOW;
    }
    else if ((tbl_id >= DsUserIdCapwapMacDaForwardHashKey_t) && (tbl_id <= DsUserIdTunnelTrillUcRpfHashKey_t))
    {
        *p_module = DRV_ACC_HASH_MODULE_USERID;
    }
    else if ((tbl_id == DsIpfixL2HashKey_t) || (tbl_id == DsIpfixL2L3HashKey_t) ||
       (tbl_id == DsIpfixL3Ipv4HashKey_t) || (tbl_id == DsIpfixL3Ipv6HashKey_t) ||
       (tbl_id == DsIpfixL3MplsHashKey_t) || (tbl_id == DsIpfixSessionRecord_t))
    {
        *p_module = DRV_ACC_HASH_MODULE_IPFIX;
    }
    else if ((tbl_id == DsMacLimitCount_t) || (tbl_id == DsMacSecurity_t))
    {
        *p_module = DRV_ACC_HASH_MODULE_MAC_LIMIT;
    }
    else if ((tbl_id == DsCategoryIdPairHashLeftKey_t) || (tbl_id == DsCategoryIdPairHashRightKey_t))
    {
        *p_module = DRV_ACC_HASH_MODULE_CID;
    }
    else
    {
        return DRV_E_INVAILD_TYPE;
    }

    return DRV_E_NONE;
}

#define __ACC_FDB__
static int32
_drv_acc_prepare_write_mac_by_idx(uint32 req_type, drv_acc_in_t* in, uint32* cpu_req)
{
    hw_mac_addr_t   mac = {0};
    uint16 fid = 0;
    uint32 ad_idx = 0;
    DsFibHost0MacHashKey_m* p_mac_key = NULL;

    DRV_PTR_VALID_CHECK(in->data);

    if (req_type == DRV_ACC_CHIP_MAX_TYPE)
    {
        return DRV_E_INVAILD_TYPE;
    }

    p_mac_key = (DsFibHost0MacHashKey_m*)in->data;

    GetDsFibHost0MacHashKey(A, mappedMac_f, p_mac_key, mac);
    fid = GetDsFibHost0MacHashKey(V, vsiId_f, p_mac_key);
    ad_idx = GetDsFibHost0MacHashKey(V, dsAdIndex_f, p_mac_key);

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, cpu_req, 1);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, cpu_req, req_type);
    SetFibHashKeyCpuReq(A, cpuKeyMac_f, cpu_req, mac);
    SetFibHashKeyCpuReq(V, cpuKeyVrfId_f, cpu_req, fid);
    SetFibHashKeyCpuReq(V, cpuKeyDsAdIndex_f, cpu_req, ad_idx);
    SetFibHashKeyCpuReq(V, cpuKeyIndex_f, cpu_req, in->index);
    return DRV_E_NONE;
}


static int32
_drv_acc_prepare_write_mac_by_key(uint32 req_type, drv_acc_in_t* in, uint32* cpu_req)
{
    uint32 key_index       = 0;
    uint32 static_count_en = 0;
    uint32 hw_aging_en = 0;
    hw_mac_addr_t   mac = {0};
    uint16 fid = 0;
    uint32 ad_idx = 0;
    DsFibHost0MacHashKey_m* p_mac_key = NULL;

    DRV_PTR_VALID_CHECK(in->data);

    p_mac_key = (DsFibHost0MacHashKey_m*)in->data;

    GetDsFibHost0MacHashKey(A, mappedMac_f, p_mac_key, mac);
    fid = GetDsFibHost0MacHashKey(V, vsiId_f, p_mac_key);
    ad_idx = GetDsFibHost0MacHashKey(V, dsAdIndex_f, p_mac_key);

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_UPDATE_MAC_LIMIT_CNT))
    {
        key_index |= 1 << 14;    /* port mac limit */
        key_index |= 1 << 15;    /* vlan mac limit */

        if (!DRV_IS_BIT_SET(in->flag, DRV_ACC_STATIC_MAC_LIMIT_CNT))
        {
            key_index |= 1 << 16;    /* dynamic mac limit */
        }
    }

    if (((mac[1] >> 8) & 0x01) == 0)
    {
        key_index |= 1 << 17;    /* profile mac limit */
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_USE_LOGIC_PORT))
    {
        /*logic port do not update port mac limit*/
        key_index &= ~(1<<14);
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_STATIC_MAC_LIMIT_CNT))
    {
        static_count_en = 1;
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_AGING_EN))
    {
        hw_aging_en = 1;
    }

    if (req_type == DRV_ACC_CHIP_MAX_TYPE)
    {
        return DRV_E_INVAILD_TYPE;
    }

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, cpu_req, 1);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, cpu_req, req_type);
    SetFibHashKeyCpuReq(A, cpuKeyMac_f, cpu_req, mac);
    SetFibHashKeyCpuReq(V, staticCountEn_f, cpu_req, static_count_en);
    SetFibHashKeyCpuReq(V, cpuKeyVrfId_f, cpu_req, fid);
    SetFibHashKeyCpuReq(V, cpuKeyDsAdIndex_f, cpu_req, ad_idx);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqPort_f, cpu_req, in->gport);
    SetFibHashKeyCpuReq(V, cpuKeyIndex_f, cpu_req, key_index);
    SetFibHashKeyCpuReq(V, cpuKeyDelType_f, cpu_req, in->timer_index);
    SetFibHashKeyCpuReq(V, cpuKeyPortDelMode_f, cpu_req, hw_aging_en);

    return DRV_E_NONE;
}

static int32
_drv_acc_prepare_del_mac_by_idx(uint32 req_type, drv_acc_in_t* in, uint32* cpu_req)
{
    if (req_type == DRV_ACC_CHIP_MAX_TYPE)
    {
        return DRV_E_INVAILD_TYPE;
    }

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, cpu_req, 1);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, cpu_req, req_type);
    SetFibHashKeyCpuReq(V, cpuKeyIndex_f, cpu_req, in->index);
    return DRV_E_NONE;
}

static int32
_drv_acc_prepare_del_mac_by_key(uint32 req_type, drv_acc_in_t* in, uint32* cpu_req)
{
    uint32 key_index = 0;
    hw_mac_addr_t   mac = {0};
    uint16 fid = 0;
    DsFibHost0MacHashKey_m* p_mac_key = NULL;

    DRV_PTR_VALID_CHECK(in->data);

    p_mac_key = (DsFibHost0MacHashKey_m*)in->data;

    GetDsFibHost0MacHashKey(A, mappedMac_f, p_mac_key, mac);
    fid = GetDsFibHost0MacHashKey(V, vsiId_f, p_mac_key);

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_UPDATE_MAC_LIMIT_CNT))
    {
        key_index |= 1 << 14;    /* port mac limit */
        key_index |= 1 << 15;    /* vlan mac limit */
        if (!DRV_IS_BIT_SET(in->flag, DRV_ACC_STATIC_MAC_LIMIT_CNT))
        {
            key_index |= 1 << 16;    /* dynamic mac limit */
        }
    }

    if (((mac[1] >> 8) & 0x01) == 0)
    {
        key_index |= 1 << 17;    /* profile mac limit */
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_USE_LOGIC_PORT))
    {
        /*logic port do not update port mac limit*/
        key_index &= ~(1<<14);
    }

    if (req_type == DRV_ACC_CHIP_MAX_TYPE)
    {
        return DRV_E_INVAILD_TYPE;
    }

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, cpu_req, 1);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, cpu_req, req_type);
    SetFibHashKeyCpuReq(A, cpuKeyMac_f, cpu_req, mac);
    SetFibHashKeyCpuReq(V, cpuKeyVrfId_f, cpu_req, fid);
    SetFibHashKeyCpuReq(V, cpuKeyIndex_f, cpu_req, key_index);

    return DRV_E_NONE;
}



static int32
_drv_acc_prepare_lkp_mac_by_key(uint32 req_type, drv_acc_in_t* in, uint32* cpu_req)
{
    uint16 fid = 0;
    DsFibHost0MacHashKey_m* p_mac_key = NULL;
    hw_mac_addr_t   mac = {0};

    DRV_PTR_VALID_CHECK(in->data);

    p_mac_key = (DsFibHost0MacHashKey_m*)in->data;

    GetDsFibHost0MacHashKey(A, mappedMac_f, p_mac_key, mac);
    fid = GetDsFibHost0MacHashKey(V, vsiId_f, p_mac_key);

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, cpu_req, 1);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, cpu_req, req_type);
    SetFibHashKeyCpuReq(V, cpuKeyVrfId_f, cpu_req, fid);
    SetFibHashKeyCpuReq(A, cpuKeyMac_f, cpu_req, mac);

    return DRV_E_NONE;
}

static int32
_drv_acc_prepare_dump_mac_by_port_vlan(uint32 req_type, drv_acc_in_t* in, uint32* cpu_req)
{
    uint32        del_type  = 0;
    uint32        del_mode  = 0;
    uint32        key_index = 0;
    hw_mac_addr_t hw_mac    = { 0 };
    uint16 fid = 0;
    DsFibHost0MacHashKey_m* p_mac_key = NULL;

    DRV_PTR_VALID_CHECK(in->data);

    hw_mac[0] = (in->index & 0x7FFFF) |
                ((in->query_end_index & 0x1f) << 19) |
                (((in->query_end_index >> 5) & 0xff) << 24);

    hw_mac[1] = (in->query_end_index >> 13) & 0x3F;

    key_index |= 1<<4;
    if (in->op_type == DRV_ACC_OP_BY_PORT_VLAN)
    {   //dump by port+vsi
        del_type = 0;
    }
    else if (in->op_type == DRV_ACC_OP_BY_PORT)
    {   //dump by port
        del_type = 1;
    }
    else if (in->op_type == DRV_ACC_OP_BY_VLAN)
    {   //dump by vsi
        del_type = 2;
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_ENTRY_STATIC))
    {
        key_index |= 1;
    }
    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_ENTRY_DYNAMIC))
    {
        key_index |= 1 << 1;
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_USE_LOGIC_PORT))
    {
        del_mode = 1;
    }

    p_mac_key = (DsFibHost0MacHashKey_m*)in->data;
    fid = GetDsFibHost0MacHashKey(V, vsiId_f, p_mac_key);

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, cpu_req, 1);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, cpu_req, req_type);
    SetFibHashKeyCpuReq(V, cpuKeyVrfId_f, cpu_req, fid);
    SetFibHashKeyCpuReq(V, cpuKeyDelType_f, cpu_req, del_type);
    SetFibHashKeyCpuReq(V, cpuKeyIndex_f, cpu_req, key_index);
    SetFibHashKeyCpuReq(V, cpuKeyPortDelMode_f, cpu_req, del_mode);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqPort_f, cpu_req, in->gport);
    SetFibHashKeyCpuReq(A, cpuKeyMac_f, cpu_req, hw_mac);
    SetFibHashKeyCpuReq(V, cpuKeyDsAdIndex_f, cpu_req, in->query_cnt);
    return DRV_E_NONE;
}

static int32
_drv_acc_prepare_dump_mac_all(uint32 req_type, drv_acc_in_t* in, uint32* cpu_req)
{
    hw_mac_addr_t hw_mac    = { 0 };
    uint32        key_index = 0;

    hw_mac[0] = (in->index & 0x7FFFF) |
                ((in->query_end_index & 0x1f) << 19) |
                (((in->query_end_index >> 5) & 0xff) << 24);

    hw_mac[1] = (in->query_end_index >> 13) & 0x3F;

    key_index |= 1<<4;

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_ENTRY_STATIC))
    {
        key_index |= 1;
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_ENTRY_DYNAMIC))
    {
        key_index |= 1 << 1;
    }

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, cpu_req, 1);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, cpu_req, req_type);
    SetFibHashKeyCpuReq(V, cpuKeyPortDelMode_f, cpu_req, 1); //means dump all
    SetFibHashKeyCpuReq(V, cpuKeyIndex_f, cpu_req, key_index);
    SetFibHashKeyCpuReq(A, cpuKeyMac_f, cpu_req, hw_mac);
    SetFibHashKeyCpuReq(V, cpuKeyDsAdIndex_f, cpu_req, in->query_cnt);

    return DRV_E_NONE;
}

static int32
_drv_acc_prepare_flush_mac_by_port_vlan(uint32 req_type, drv_acc_in_t* in, uint32* cpu_req)
{
    uint32 key_index = 0;
    uint32 del_type  = 0;
    uint32 del_mode  = 0;
    uint16 fid = 0;
    DsFibHost0MacHashKey_m* p_mac_key = NULL;

    DRV_PTR_VALID_CHECK(in->data);

    if (in->op_type == DRV_ACC_OP_BY_PORT_VLAN)
    {   //delete by port+vsi
        del_type = 0;
    }
    else if (in->op_type == DRV_ACC_OP_BY_PORT)
    {   //delete by port
        del_type = 1;
    }
    else if (in->op_type == DRV_ACC_OP_BY_VLAN)
    {   //delete by vsi
        del_type = 2;
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_ENTRY_STATIC))
    {
        key_index |= 1;
    }
    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_ENTRY_DYNAMIC))
    {
        key_index |= 1 << 1;
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_UPDATE_MAC_LIMIT_CNT))
    {
        key_index |= 1 << 5;
        key_index |= 1 << 7;
        key_index |= 1 << 8;
    }

    /*profile*/
    key_index |= 1 << 9;

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_USE_LOGIC_PORT))
    {
        /*logic port do not update port mac limit*/
        key_index &= ~(1<<5);
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_STATIC_MAC_LIMIT_CNT))
    {
        key_index |= 1 << 4;
        key_index |= 1 << 6;
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_USE_LOGIC_PORT))
    {
        del_mode = 1;
    }

    p_mac_key = (DsFibHost0MacHashKey_m*)in->data;
    fid = GetDsFibHost0MacHashKey(V, vsiId_f, p_mac_key);

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, cpu_req, 1);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, cpu_req, req_type);
    SetFibHashKeyCpuReq(V, cpuKeyVrfId_f, cpu_req, fid);
    SetFibHashKeyCpuReq(V, cpuKeyDelType_f, cpu_req, del_type);
    SetFibHashKeyCpuReq(V, cpuKeyIndex_f, cpu_req, key_index);
    SetFibHashKeyCpuReq(V, cpuKeyPortDelMode_f, cpu_req, del_mode);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqPort_f, cpu_req, in->gport);

    return DRV_E_NONE;
}

static int32
_drv_acc_prepare_flush_mac_by_mac_port(uint32 req_type, drv_acc_in_t* in, uint32* cpu_req)
{
    uint32 key_index = 0;
    uint32 del_type  = 0;
    uint32 del_mode  = 0;
    uint16 fid = 0;
    DsFibHost0MacHashKey_m* p_mac_key = NULL;
    hw_mac_addr_t   mac = {0};

    DRV_PTR_VALID_CHECK(in->data);

    if (in->op_type == DRV_ACC_OP_BY_PORT_MAC)
    {   //delete by mac+port
        del_type = 2;
    }
    else
    {   //delete by mac
        del_type = 1;
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_ENTRY_STATIC))
    {
        key_index |= 1 << 0;
    }
    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_ENTRY_DYNAMIC))
    {
        key_index |= 1 << 1;
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_UPDATE_MAC_LIMIT_CNT))
    {
        key_index |= 1 << 5;
        key_index |= 1 << 7;
        key_index |= 1 << 8;
    }

    /*profile*/
    key_index |= 1 << 9;

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_USE_LOGIC_PORT))
    {
        /*logic port do not update port mac limit*/
        key_index &= ~(1<<5);
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_STATIC_MAC_LIMIT_CNT))
    {
        key_index |= 1 << 4;
        key_index |= 1 << 6;
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_USE_LOGIC_PORT))
    {
        del_mode = 1;
    }

    p_mac_key = (DsFibHost0MacHashKey_m*)in->data;

    GetDsFibHost0MacHashKey(A, mappedMac_f, p_mac_key, mac);
    fid = GetDsFibHost0MacHashKey(V, vsiId_f, p_mac_key);

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, cpu_req, 1);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, cpu_req, req_type);
    SetFibHashKeyCpuReq(A, cpuKeyMac_f, cpu_req, mac);
    SetFibHashKeyCpuReq(V, cpuKeyVrfId_f, cpu_req, fid);
    SetFibHashKeyCpuReq(V, cpuKeyDelType_f, cpu_req, del_type);
    SetFibHashKeyCpuReq(V, cpuKeyIndex_f, cpu_req, key_index);
    SetFibHashKeyCpuReq(V, cpuKeyPortDelMode_f, cpu_req, del_mode);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqPort_f, cpu_req, in->gport);

    return DRV_E_NONE;
}

static int32
_drv_acc_prepare_flush_mac_all(uint32 req_type, drv_acc_in_t* in, uint32* cpu_req)
{
    uint32 key_index = 0;

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_ENTRY_STATIC))
    {
        key_index |= 1 << 0;
    }
    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_ENTRY_DYNAMIC))
    {
        key_index |= 1 << 1;
    }

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_UPDATE_MAC_LIMIT_CNT))
    {
        key_index |= 1 << 5;
        key_index |= 1 << 7;
        key_index |= 1 << 8;
    }

    /*profile*/
    key_index |= 1 << 9;

    if (DRV_IS_BIT_SET(in->flag, DRV_ACC_STATIC_MAC_LIMIT_CNT))
    {
        key_index |= 1 << 4;
        key_index |= 1 << 6;
    }

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, cpu_req, 1);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, cpu_req, req_type);
    SetFibHashKeyCpuReq(V, cpuKeyIndex_f, cpu_req, key_index);
    return DRV_E_NONE;
}

static int32
_drv_acc_result_write_mac_by_key(uint32* fib_acc_cpu_rlt, drv_acc_out_t* out)
{
    out->key_index = GetFibHashKeyCpuResult(V, hashCpuLuIndex_f, fib_acc_cpu_rlt);
    out->is_full   = GetFibHashKeyCpuResult(V, pending_f, fib_acc_cpu_rlt);
    out->is_conflict  = GetFibHashKeyCpuResult(V, conflict_f, fib_acc_cpu_rlt);

    return DRV_E_NONE;
}

static int32
_drv_acc_result_del_mac_by_key(uint32* fib_acc_cpu_rlt, drv_acc_out_t* out)
{
    out->key_index = GetFibHashKeyCpuResult(V, hashCpuLuIndex_f, fib_acc_cpu_rlt);
    out->is_hit       = GetFibHashKeyCpuResult(V, hashCpuKeyHit_f, fib_acc_cpu_rlt);
    out->is_conflict  = GetFibHashKeyCpuResult(V, conflict_f, fib_acc_cpu_rlt);

    return DRV_E_NONE;
}


static int32
_drv_acc_result_lkp_mac_by_key(uint32* fib_acc_cpu_rlt, drv_acc_out_t* out)
{
    out->is_hit       = GetFibHashKeyCpuResult(V, hashCpuKeyHit_f, fib_acc_cpu_rlt);
    out->key_index = GetFibHashKeyCpuResult(V, hashCpuLuIndex_f, fib_acc_cpu_rlt);
    out->is_conflict  = GetFibHashKeyCpuResult(V, conflict_f, fib_acc_cpu_rlt);
    out->is_pending   = GetFibHashKeyCpuResult(V, pending_f, fib_acc_cpu_rlt);
    out->ad_index  = GetFibHashKeyCpuResult(V, hashCpuDsIndex_f, fib_acc_cpu_rlt);

    return DRV_E_NONE;
}

static int32
_drv_acc_result_dump_mac(uint32* fib_acc_cpu_rlt, drv_acc_out_t* out)
{

    uint32 confict = 0;
    uint32 pending = 0;

    confict = GetFibHashKeyCpuResult(V, conflict_f, fib_acc_cpu_rlt);
    pending = GetFibHashKeyCpuResult(V, pending_f, fib_acc_cpu_rlt);

    out->key_index = GetFibHashKeyCpuResult(V, hashCpuLuIndex_f, fib_acc_cpu_rlt);
    out->is_full   = (confict && (!pending));
    out->is_end = !(!confict && (pending));
    out->query_cnt      = GetFibHashKeyCpuResult(V, hashCpuDsIndex_f, fib_acc_cpu_rlt);
    return DRV_E_NONE;
}

int32
drv_acc_fdb_prepare(uint8 lchip, drv_acc_in_t* acc_in, uint32* req)
{
    uint32 type = DRV_ACC_CHIP_MAX_TYPE;

    switch(acc_in->type)
    {
        case DRV_ACC_TYPE_ADD:
            if (acc_in->op_type == DRV_ACC_OP_BY_INDEX)
            {
                type = DRV_ACC_CHIP_MAC_WRITE_BY_INDEX;
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_write_mac_by_idx(type, acc_in, req));
            }
            else
            {
                type = DRV_ACC_CHIP_MAC_WRITE_BY_KEY;
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_write_mac_by_key(type, acc_in, req));
            }
            break;

        case DRV_ACC_TYPE_DEL:
            if (acc_in->op_type == DRV_ACC_OP_BY_INDEX)
            {
                type = DRV_ACC_CHIP_MAC_DEL_BY_INDEX;
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_del_mac_by_idx(type, acc_in, req));
            }
            else
            {
                type = DRV_ACC_CHIP_MAC_DEL_BY_KEY;
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_del_mac_by_key(type, acc_in, req));
            }
            break;

         case DRV_ACC_TYPE_LOOKUP:
            if (acc_in->op_type == DRV_ACC_OP_BY_INDEX)
            {
                return DRV_E_INVAILD_TYPE;
            }
            else
            {
                type = DRV_ACC_CHIP_MAC_LOOKUP_BY_KEY;
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_lkp_mac_by_key(type, acc_in, req));
            }
            break;

         case DRV_ACC_TYPE_DUMP:
            if ((acc_in->op_type == DRV_ACC_OP_BY_PORT) ||
                (acc_in->op_type == DRV_ACC_OP_BY_VLAN) ||
                (acc_in->op_type == DRV_ACC_OP_BY_PORT_VLAN))
            {
                type = DRV_ACC_CHIP_MAC_DUMP_BY_PORT_VLAN;
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_dump_mac_by_port_vlan(type, acc_in, req));
            }
            else if (acc_in->op_type == DRV_ACC_OP_BY_ALL)
            {
                type = DRV_ACC_CHIP_MAC_FLUSH_DUMP_BY_ALL;
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_dump_mac_all(type, acc_in, req));
            }
            break;

         case DRV_ACC_TYPE_FLUSH:
            if ((acc_in->op_type == DRV_ACC_OP_BY_PORT) ||
                (acc_in->op_type == DRV_ACC_OP_BY_VLAN) ||
                (acc_in->op_type == DRV_ACC_OP_BY_PORT_VLAN))
            {
                type = DRV_ACC_CHIP_MAC_FLUSH_BY_PORT_VLAN;
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_flush_mac_by_port_vlan(type, acc_in, req));
            }
            else if ((acc_in->op_type == DRV_ACC_OP_BY_MAC)||
                     (acc_in->op_type == DRV_ACC_OP_BY_PORT_MAC))
            {
                type = DRV_ACC_CHIP_MAC_FLUSH_BY_MAC_PORT;
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_flush_mac_by_mac_port(type, acc_in, req));
            }
            else if ((acc_in->op_type == DRV_ACC_OP_BY_ALL))
            {
                type = DRV_ACC_CHIP_MAC_FLUSH_DUMP_BY_ALL;
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_flush_mac_all(type, acc_in, req));
            }
            break;

        default:
            return DRV_E_INVAILD_TYPE;

    }

    return 0;
}

int32
drv_acc_fdb_result(uint8 lchip, drv_acc_in_t* acc_in, uint32* fib_acc_cpu_rlt, drv_acc_out_t* out)
{
    switch(acc_in->type)
    {
        case DRV_ACC_TYPE_ADD:

            if ((acc_in->op_type != DRV_ACC_OP_BY_INDEX))
            {
                DRV_IF_ERROR_RETURN(_drv_acc_result_write_mac_by_key(fib_acc_cpu_rlt, out));
            }

            break;

        case DRV_ACC_TYPE_DEL:

            if ((acc_in->op_type != DRV_ACC_OP_BY_INDEX))
            {
                DRV_IF_ERROR_RETURN(_drv_acc_result_del_mac_by_key(fib_acc_cpu_rlt, out));
            }

            break;

         case DRV_ACC_TYPE_LOOKUP:

            if (acc_in->op_type != DRV_ACC_OP_BY_INDEX)
            {
                DRV_IF_ERROR_RETURN(_drv_acc_result_lkp_mac_by_key(fib_acc_cpu_rlt, out));
            }
            break;

         case DRV_ACC_TYPE_DUMP:
                DRV_IF_ERROR_RETURN(_drv_acc_result_dump_mac(fib_acc_cpu_rlt, out));

            break;

         case DRV_ACC_TYPE_FLUSH:
            break;

        default:
            return DRV_E_INVAILD_TYPE;

    }

    return 0;
}

#define __ACC_HOST0__

static int32
_drv_acc_prepare_write_fib0_by_key(uint8 lchip, uint32 req_type, drv_acc_in_t* in, uint32* cpu_req)
{

    drv_fib_acc_fib_data_t fib_data;
    hw_mac_addr_t          hw_mac     = { 0 };
    uint32                 key_length = 0;
    uint32                 tbl_id     = 0;
    uint32                 length = 0;
    uint32                 overwrite_en = 0;
    uint8                  hash_type = 0;
    DsFibHost0FcoeHashKey_m* p_host0_key = NULL;

    DRV_PTR_VALID_CHECK(in->data);
    sal_memset(&fib_data, 0, sizeof(drv_fib_acc_fib_data_t));

    p_host0_key = (DsFibHost0FcoeHashKey_m*)in->data;
    hash_type = GetDsFibHost0FcoeHashKey(V, hashType_f, p_host0_key);

    hw_mac[0] = hash_type;

    if ((in->tbl_id == DsFibHost0FcoeHashKey_t) || (in->tbl_id == DsFibHost0Ipv4HashKey_t)
        || (in->tbl_id == DsFibHost0MacHashKey_t) || (in->tbl_id == DsFibHost0TrillHashKey_t))
    {
        hw_mac[0] |= HASH_KEY_LENGTH_MODE_SINGLE << 3;
        key_length = DRV_HASH_85BIT_KEY_LENGTH;
        tbl_id     = DsFibHost0MacHashKey_t;
        length     = SINGLE_KEY_BYTE;
    }
    else
    {
        hw_mac[0] |= HASH_KEY_LENGTH_MODE_DOUBLE << 3;
        key_length = DRV_HASH_170BIT_KEY_LENGTH;
        tbl_id     = DsFibHost0MacIpv6McastHashKey_t;
        length     = DOUBLE_KEY_BYTE;
    }

#if (SDK_WORK_PLATFORM == 1)
    drv_model_hash_combined_key((uint8 *) fib_data, (uint8 *) in->data, key_length, tbl_id);
#else
    sal_memcpy((uint8*)fib_data, (uint8 *) in->data, length);
#endif

    overwrite_en = DRV_IS_BIT_SET(in->flag, DRV_ACC_OVERWRITE_EN);

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, cpu_req, 1);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, cpu_req, req_type);
    SetFibHashKeyCpuReq(V, cpuKeyPortDelMode_f, cpu_req, overwrite_en);
    SetFibHashKeyCpuReq(A, cpuKeyMac_f, cpu_req, hw_mac);
    SetFibHashKeyCpuReq(A, writeData_f, cpu_req, fib_data);
    return DRV_E_NONE;
}

static int32
_drv_acc_prepare_lkp_fib0_by_idx(uint8 lchip, uint32 req_type, drv_acc_in_t* in, uint32* cpu_req)
{
    uint32        length_mode= 0;
    uint32        length = 0;
    uint32        count      = 0;
    hw_mac_addr_t hw_mac     = { 0 };

    hw_mac[0] = in->index;
    count     = (in->index % 4)/2;

    if ((in->tbl_id == DsFibHost0FcoeHashKey_t) || (in->tbl_id == DsFibHost0Ipv4HashKey_t)
        || (in->tbl_id == DsFibHost0MacHashKey_t) || (in->tbl_id == DsFibHost0TrillHashKey_t))
    {
        length_mode = HASH_KEY_LENGTH_MODE_SINGLE;
    }
    else
    {
        length_mode = HASH_KEY_LENGTH_MODE_DOUBLE;
    }

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, cpu_req, 1);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, cpu_req, req_type);
    SetFibHashKeyCpuReq(A, cpuKeyMac_f, cpu_req, hw_mac);

    /* only cmodel need spec and rtl do not need */
    if (1 == count)
    {
        SetFibHashKeyCpuReq(V, staticCountEn_f, cpu_req, length_mode);
    }
    else
    {
        SetFibHashKeyCpuReq(V, cpuKeyPortDelMode_f, cpu_req, length_mode);
    }

    return DRV_E_NONE;
}

static int32
_drv_acc_prepare_write_fib0_by_idx(uint8 lchip, uint32 req_type, drv_acc_in_t* in, uint32* cpu_req)
{
    drv_fib_acc_rw_data_t rw_data;
    drv_fib_acc_rw_data_t tmp_rw_data;
    drv_acc_in_t      acc_read_in;
    drv_acc_out_t     acc_read_out;
    uint32                key_length_mode[2] = { 0 };
    uint32                del_mode   = 0;
    uint32                count      = 0;
    uint32                key_length = 0;
    uint32                tbl_id     = 0;
    uint32                key_index  = 0;
    uint8                 shift      = 0;
    hw_mac_addr_t         hw_mac = { 0 };
    FibHashKeyCpuReq_m fib_req;
    FibHashKeyCpuResult_m fib_result;

    DRV_PTR_VALID_CHECK(in->data);

    sal_memset(&rw_data, 0, sizeof(drv_fib_acc_rw_data_t));
    sal_memset(&tmp_rw_data, 0, sizeof(drv_fib_acc_rw_data_t));
    sal_memset(&acc_read_in, 0, sizeof(drv_acc_in_t));
    sal_memset(&acc_read_out, 0, sizeof(drv_acc_out_t));

    hw_mac[0] = in->index;
    count     = (in->index % 4) / 2;

    if ((in->tbl_id == DsFibHost0FcoeHashKey_t) || (in->tbl_id == DsFibHost0Ipv4HashKey_t)
        || (in->tbl_id == DsFibHost0MacHashKey_t) || (in->tbl_id == DsFibHost0TrillHashKey_t))
    {
        key_length_mode[count] = HASH_KEY_LENGTH_MODE_SINGLE;
        key_length             = SINGLE_KEY_BYTE;
    }
    else
    {
        key_length_mode[count] = HASH_KEY_LENGTH_MODE_DOUBLE;
        key_length             = SINGLE_KEY_BYTE*2;
    }

    del_mode  = key_length_mode[count];
    key_index = in->index - (in->index % 4);

    /* read by index, for 340bits */
    acc_read_in.type = DRV_ACC_TYPE_LOOKUP;
    acc_read_in.op_type = DRV_ACC_OP_BY_INDEX;
    acc_read_in.index = key_index;

    /*Note: can not using drv_acc_host0 directly, because of lock, using internal interface*/
    DRV_IF_ERROR_RETURN(drv_acc_host0_prepare(lchip, &acc_read_in, (uint32*)&fib_req));
    DRV_IF_ERROR_RETURN(drv_acc_host0_process(lchip, (uint32*)&fib_req, (uint32*)&fib_result));
    DRV_IF_ERROR_RETURN(drv_acc_host0_result(lchip, &acc_read_in, (uint32*)&fib_result, &acc_read_out));

    /* move request data to read data */
    shift = (in->index % 4);
    sal_memcpy(tmp_rw_data, acc_read_out.data, sizeof(drv_fib_acc_rw_data_t));
    sal_memcpy(((uint32 *) tmp_rw_data + shift * 3), in->data, key_length);

    tbl_id     = DsFibHost0HashCam_t;
    key_length = DRV_HASH_170BIT_KEY_LENGTH * 2;

#if (SDK_WORK_PLATFORM == 1)
    drv_model_hash_combined_key((uint8 *)rw_data, (uint8 *) tmp_rw_data, key_length, tbl_id);
#else
    sal_memcpy((uint8*)rw_data, (uint8 *)tmp_rw_data, QUAD_KEY_BYTE);
#endif

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, cpu_req, 1);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, cpu_req, req_type);
    SetFibHashKeyCpuReq(A, cpuKeyMac_f, cpu_req, hw_mac);
    SetFibHashKeyCpuReq(A, writeData_f, cpu_req, rw_data);

#if (SDK_WORK_PLATFORM == 1)
    /* only cmodel need spec and rtl do not need */
    SetFibHashKeyCpuReq(V, cpuKeyPortDelMode_f, cpu_req, key_length_mode[0]);
    SetFibHashKeyCpuReq(V, staticCountEn_f, cpu_req, key_length_mode[1]);
#endif
    return DRV_E_NONE;
}

static int32
_drv_acc_prepare_lkp_fib0_by_key(uint8 lchip, uint32 req_type, drv_acc_in_t* in, uint32* cpu_req)
{
    drv_fib_acc_fib_data_t fib_data;
    hw_mac_addr_t          hw_mac     = { 0 };
    uint32                 key_length = 0;
    uint32                 tbl_id     = 0;
    uint32                 length     = 0;
    uint8                  hash_type = 0;
    DsFibHost0FcoeHashKey_m* p_host0_key = NULL;

    DRV_PTR_VALID_CHECK(in->data);
    sal_memset(&fib_data, 0, sizeof(drv_fib_acc_fib_data_t));

    p_host0_key = (DsFibHost0FcoeHashKey_m*)in->data;
    hash_type = GetDsFibHost0FcoeHashKey(V, hashType_f, p_host0_key);

    hw_mac[0] = hash_type;
    if ((in->tbl_id == DsFibHost0FcoeHashKey_t) || (in->tbl_id == DsFibHost0Ipv4HashKey_t)
        || (in->tbl_id == DsFibHost0MacHashKey_t) || (in->tbl_id == DsFibHost0TrillHashKey_t))
    {
        hw_mac[0] |= HASH_KEY_LENGTH_MODE_SINGLE << 3;
        key_length = DRV_HASH_85BIT_KEY_LENGTH;
        tbl_id     = DsFibHost0MacHashKey_t;
        length     = SINGLE_KEY_BYTE;
    }
    else
    {
        hw_mac[0] |= HASH_KEY_LENGTH_MODE_DOUBLE << 3;
        key_length = DRV_HASH_170BIT_KEY_LENGTH;
        tbl_id     = DsFibHost0MacIpv6McastHashKey_t;
        length     = DOUBLE_KEY_BYTE;
    }

#if (SDK_WORK_PLATFORM == 1)
    drv_model_hash_combined_key((uint8 *) fib_data, (uint8 *)in->data, key_length, tbl_id);
   //- drv_model_hash_mask_key((uint8 *) fib_data, (uint8 *) fib_data, HASH_MODULE_FIB_HOST0, FIBHOST0PRIMARYHASHTYPE_IPV4);
#else
    sal_memcpy((uint8*)fib_data, (uint8 *)in->data, DOUBLE_KEY_BYTE);
#endif

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, cpu_req, 1);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, cpu_req, req_type);
    SetFibHashKeyCpuReq(A, cpuKeyMac_f, cpu_req, hw_mac);
    SetFibHashKeyCpuReq(A, writeData_f, cpu_req, fib_data);

    return DRV_E_NONE;
}

static int32
_drv_acc_result_write_fib0_by_key(uint32* cpu_rlt, drv_acc_out_t* out)
{
    out->key_index = GetFibHashKeyCpuResult(V, hashCpuLuIndex_f, cpu_rlt);
    out->is_conflict  = GetFibHashKeyCpuResult(V, conflict_f, cpu_rlt);
    out->ad_index = GetFibHashKeyCpuResult(V, hashCpuDsIndex_f, cpu_rlt);
    out->is_hit       = GetFibHashKeyCpuResult(V, hashCpuKeyHit_f, cpu_rlt);

    return DRV_E_NONE;
}

static int32
_drv_acc_result_lkp_fib0_by_idx(drv_acc_in_t* acc_in, uint32* cpu_rlt, drv_acc_out_t* out)
{
    uint8         shift = 0;
    uint32        length_mode= 0;
    uint32        length = 0;
    uint32        c_length = 0;
    drv_fib_acc_rw_data_t rw_data;
    drv_fib_acc_rw_data_t tmp_rw_data;

    sal_memset(&rw_data, 0, sizeof(rw_data));
    sal_memset(&tmp_rw_data, 0, sizeof(tmp_rw_data));

    GetFibHashKeyCpuResult(A, readData_f, cpu_rlt, rw_data);

    if ((acc_in->tbl_id == DsFibHost0FcoeHashKey_t) || (acc_in->tbl_id == DsFibHost0Ipv4HashKey_t)
        || (acc_in->tbl_id == DsFibHost0MacHashKey_t) || (acc_in->tbl_id == DsFibHost0TrillHashKey_t))
    {
        length     = SINGLE_KEY_BYTE;
    }
    else
    {
        length     = DOUBLE_KEY_BYTE;
    }

#if (SDK_WORK_PLATFORM == 1)
    drv_model_hash_un_combined_key((uint8 *) tmp_rw_data, (uint8 *) rw_data, DRV_HASH_340BIT_KEY_LENGTH, DsFibHost0HashCam_t);
#else
    sal_memcpy((uint8*)tmp_rw_data, (uint8 *)rw_data, length);
#endif

    /* asic only read 340 key drv need to adjust the key */
    if (acc_in->index < FIB_HOST0_CAM_NUM)
    {
        shift = (acc_in->index % 4);
    }
    else
    {
        shift = ((acc_in->index-FIB_HOST0_CAM_NUM) % 4);
    }
    sal_memcpy(out->data, ((uint32 *) tmp_rw_data + shift * 3), length);

    return DRV_E_NONE;
}

static int32
_drv_acc_result_lkp_fib0_by_key(drv_acc_in_t* acc_in, uint32* cpu_rlt, drv_acc_out_t* out)
{
    out->is_hit       = GetFibHashKeyCpuResult(V, hashCpuKeyHit_f, cpu_rlt);
    out->key_index = GetFibHashKeyCpuResult(V, hashCpuLuIndex_f, cpu_rlt);
    out->is_conflict  = GetFibHashKeyCpuResult(V, conflict_f, cpu_rlt);
    out->ad_index  = GetFibHashKeyCpuResult(V, hashCpuDsIndex_f, cpu_rlt);
    return DRV_E_NONE;
}

int32
drv_acc_host0_prepare(uint8 lchip, drv_acc_in_t* acc_in, uint32* req)
{
    uint32 type = DRV_ACC_CHIP_MAX_TYPE;

    switch(acc_in->type)
    {
        case DRV_ACC_TYPE_ADD:
            if (acc_in->op_type == DRV_ACC_OP_BY_INDEX)
            {
                type = DRV_ACC_CHIP_HOST0_WRITE_BY_INDEX;
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_write_fib0_by_idx(lchip, type, acc_in, req));
            }
            else
            {
                type = DRV_ACC_CHIP_HOST0_WRITE_BY_KEY;
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_write_fib0_by_key(lchip, type, acc_in, req));
            }

            break;

         case DRV_ACC_TYPE_LOOKUP:
            if (acc_in->op_type == DRV_ACC_OP_BY_INDEX)
            {
                type = DRV_ACC_CHIP_HOST0_lOOKUP_BY_INDEX;
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_lkp_fib0_by_idx(lchip, type, acc_in, req));            }
            else
            {
                type = DRV_ACC_CHIP_HOST0_lOOKUP_BY_KEY;
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_lkp_fib0_by_key(lchip, type, acc_in, req));
            }
            break;

        default:
            return DRV_E_INVAILD_TYPE;

    }

    return 0;
}

int32
drv_acc_host0_process(uint8 chip_id, uint32* i_cpu_req, uint32* o_cpu_rlt)
{
    uint32        cmd   = 0;
    uint16         loop  = 0;
    uint8         count = 0;
    uint8         done  = 0;

    cmd = DRV_IOW(FibHashKeyCpuReq_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(chip_id, 0, cmd, i_cpu_req));

    cmd = DRV_IOR(FibHashKeyCpuReq_t, DRV_ENTRY_FLAG);

    for (loop = 0; (loop < 200) && !done; loop++)
    {
        for (count = 0; (count < 150) && !done; count++)
        {
            DRV_IF_ERROR_RETURN(DRV_IOCTL(chip_id, 0, cmd, i_cpu_req));
            done = !GetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, i_cpu_req);
        }

        if (done)
        {
            break;
        }
        sal_task_sleep(DRV_FIB_ACC_SLEEP_TIME);
    }

    if (!done)
    {
        DRV_IF_ERROR_RETURN(DRV_E_TIME_OUT);
    }

    cmd = DRV_IOR(FibHashKeyCpuResult_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(chip_id, 0, cmd, o_cpu_rlt));

#if NEVER
    ecc_en = drv_ecc_recover_get_enable();

    if (is_store && ecc_en)
    {
        _drv_chip_fib_acc_store(chip_id, i_fib_acc_cpu_req, o_fib_acc_cpu_rlt);
    }
#endif
    return DRV_E_NONE;
}

int32
drv_acc_host0_result(uint8 lchip, drv_acc_in_t* acc_in, uint32* fib_acc_cpu_rlt, drv_acc_out_t* out)
{
    switch(acc_in->type)
    {
        case DRV_ACC_TYPE_ADD:

            if (acc_in->op_type != DRV_ACC_OP_BY_INDEX)
            {
                DRV_IF_ERROR_RETURN(_drv_acc_result_write_fib0_by_key(fib_acc_cpu_rlt, out));
            }

            break;

        case DRV_ACC_TYPE_DEL:

            break;

         case DRV_ACC_TYPE_LOOKUP:

            if (acc_in->op_type == DRV_ACC_OP_BY_INDEX)
            {
                DRV_IF_ERROR_RETURN(_drv_acc_result_lkp_fib0_by_idx(acc_in, fib_acc_cpu_rlt, out));
            }
            else if (acc_in->op_type == DRV_ACC_OP_BY_KEY)
            {
                DRV_IF_ERROR_RETURN(_drv_acc_result_lkp_fib0_by_key(acc_in, fib_acc_cpu_rlt, out));
            }
            break;

        default:
            return DRV_E_INVAILD_TYPE;

    }

    return 0;
}

#define __ACC_HOST1__

static int32
_drv_acc_prepare_host1_by_key(uint8 lchip, drv_acc_in_t* in, drv_cpu_acc_prepare_info_t* pre_info)
{
    FibHost1FlowHashCpuLookupReq_m host1_req;
    FibHost1FlowHashCpuLookupResult_m host1_result;
    uint32 cmd = 0;
    uint8 type = 0;
    uint32 tbl_id = 0;
    uint32 entry_size = 0;
    uint8 c_length = 0;
    uint8 length = 0;
    uint32 mode = 0;
    uint32 loop = 0;
    uint32 count = 0;
    uint32 done = 0;
    uint32 data[12] = { 0 };
    uint32 req_valid = 0;
    DsFibHost1Ipv4McastHashKey_m* p_hash = NULL;

    /* check valid bit clear */
    _drv_acc_hash_get_valid(lchip, DRV_ACC_HASH_MODULE_FIB_HOST1, &req_valid);
    if (req_valid)
    {
        return DRV_E_OCCPANCY;
    }

    sal_memset(&host1_req, 0, sizeof(FibHost1FlowHashCpuLookupReq_m));
    sal_memset(&host1_result, 0, sizeof(FibHost1FlowHashCpuLookupResult_m));

    cmd = DRV_IOW(FibHost1FlowHashCpuLookupResult_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &host1_result));

    /*for action by key, need do lookup first*/
    pre_info->tbl_id = in->tbl_id;
    tbl_id = in->tbl_id;

    entry_size  = TABLE_ENTRY_SIZE(tbl_id) / 12;

    switch (entry_size)
    {
        case 1:
            c_length = DRV_HASH_85BIT_KEY_LENGTH;
            mode = HASH_KEY_LENGTH_MODE_SINGLE;
            length     = SINGLE_KEY_BYTE;
            break;

        case 2:
            c_length = DRV_HASH_170BIT_KEY_LENGTH;
            mode = HASH_KEY_LENGTH_MODE_DOUBLE;
            length     = DOUBLE_KEY_BYTE;
            break;

        case 4:
            c_length = DRV_HASH_340BIT_KEY_LENGTH;
            mode = HASH_KEY_LENGTH_MODE_QUAD;
            length     = QUAD_KEY_BYTE;
            break;
        default:
            return DRV_E_INVALID_TBL;
    }

#if (SDK_WORK_PLATFORM == 1)
    drv_model_hash_combined_key((uint8 *)data, (uint8 *)in->data, c_length, tbl_id);
    drv_model_hash_mask_key((uint8 *)data, (uint8 *)data, HASH_MODULE_FIB_HOST1, tbl_id);
#else
    sal_memcpy((uint8*)data, (uint8 *)in->data, length);
    p_hash = (DsFibHost1Ipv4McastHashKey_m*)data;
    SetDsFibHost1Ipv4McastHashKey(V, dsAdIndex_f, p_hash, 0);
#endif

    SetFibHost1FlowHashCpuLookupReq(V, cpuLookupReqValid_f, &host1_req, 1);
    SetFibHost1FlowHashCpuLookupReq(A, data_f, &host1_req, data);
    SetFibHost1FlowHashCpuLookupReq(V, lengthMode_f, &host1_req, mode);
    SetFibHost1FlowHashCpuLookupReq(V, fibHost1Req_f, &host1_req, 1);

    cmd = DRV_IOW(FibHost1FlowHashCpuLookupReq_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &host1_req));

    cmd = DRV_IOR(FibHost1FlowHashCpuLookupResult_t, DRV_ENTRY_FLAG);

    for (loop = 0; (loop < 200) && !done; loop++)
    {
        for (count = 0; (count < 50) && !done; count++)
        {
            DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &host1_result));
            done = GetFibHost1FlowHashCpuLookupResult(V, cpuLookupReqDone_f, &host1_result);
        }

        if (done)
        {
            break;
        }
        sal_task_sleep(1);
    }

    if (!done)
    {
        DRV_IF_ERROR_RETURN(DRV_E_CMD_NOT_DONE);
    }

    pre_info->conflict = GetFibHost1FlowHashCpuLookupResult(V, conflict_f, &host1_result);
    pre_info->valid = GetFibHost1FlowHashCpuLookupResult(V, lookupResultValid_f, &host1_result);

    /*acording lookup result build prepare information*/
    if (!GetFibHost1FlowHashCpuLookupResult(V, conflict_f, &host1_result))
    {
        pre_info->tbl_id = tbl_id;
        pre_info->key_index = GetFibHost1FlowHashCpuLookupResult(V, resultIndex_f, &host1_result);
    }
    else
    {
        return DRV_E_HASH_CONFLICT;
    }

    return DRV_E_NONE;
}

#define __ACC_USERID__

static int32
_drv_acc_prepare_userid_by_key(uint8 lchip, drv_acc_in_t* in, drv_cpu_acc_prepare_info_t* pre_info)
{
    UserIdCpuLookupReq_m userid_req;
    UserIdCpuLookupResult_m userid_result;
    uint32 cmd = 0;
    uint8 type = 0;
    uint32 tbl_id = 0;
    uint32 entry_size = 0;
    uint8 c_length = 0;
    uint8 length = 0;
    uint32 mode = 0;
    uint32 loop = 0;
    uint32 count = 0;
    uint32 done = 0;
    uint32 data[12] = { 0 };
    uint32 req_valid = 0;
    DsUserIdCvlanPortHashKey_m* p_hash = NULL;

    /* check valid bit clear */
    _drv_acc_hash_get_valid(lchip, DRV_ACC_HASH_MODULE_USERID, &req_valid);
    if (req_valid)
    {
        return DRV_E_OCCPANCY;
    }

    sal_memset(&userid_req, 0, sizeof(UserIdCpuLookupReq_m));
    sal_memset(&userid_result, 0, sizeof(UserIdCpuLookupResult_m));

    cmd = DRV_IOW(UserIdCpuLookupResult_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &userid_result));

    /*for action by key, need do lookup first*/
    pre_info->tbl_id = in->tbl_id;
    tbl_id = in->tbl_id;

    entry_size  = TABLE_ENTRY_SIZE(tbl_id) / 12;

    switch (entry_size)
    {
        case 1:
            c_length = DRV_HASH_85BIT_KEY_LENGTH;
            mode = HASH_KEY_LENGTH_MODE_SINGLE;
            length     = SINGLE_KEY_BYTE;
            break;

        case 2:
            c_length = DRV_HASH_170BIT_KEY_LENGTH;
            mode = HASH_KEY_LENGTH_MODE_DOUBLE;
            length     = DOUBLE_KEY_BYTE;
            break;

        case 4:
            c_length = DRV_HASH_340BIT_KEY_LENGTH;
            mode = HASH_KEY_LENGTH_MODE_QUAD;
            length     = QUAD_KEY_BYTE;
            break;
        default:
            return DRV_E_INVALID_TBL;
    }

#if (SDK_WORK_PLATFORM == 1)
    drv_model_hash_combined_key((uint8 *)data, (uint8 *)in->data, c_length, tbl_id);
    drv_model_hash_mask_key((uint8 *)data, (uint8 *)data, HASH_MODULE_USERID, tbl_id);
#else
    sal_memcpy((uint8*)data, (uint8 *)in->data, length);
    p_hash = (DsUserIdCvlanPortHashKey_m*)data;
    SetDsUserIdCvlanPortHashKey(V, dsAdIndex_f, p_hash, 0);
#endif

    SetUserIdCpuLookupReq(V, cpuLookupReqValid_f, &userid_req, 1);
    SetUserIdCpuLookupReq(A, data_f, &userid_req, data);
    SetUserIdCpuLookupReq(V, lengthMode_f, &userid_req, mode);

    cmd = DRV_IOW(UserIdCpuLookupReq_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &userid_req));

    cmd = DRV_IOR(UserIdCpuLookupResult_t, DRV_ENTRY_FLAG);

    for (loop = 0; (loop < 200) && !done; loop++)
    {
        for (count = 0; (count < 150) && !done; count++)
        {
            DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &userid_result));
            done = GetUserIdCpuLookupResult(V, cpuLookupReqDone_f, &userid_result);
        }

        if (done)
        {
            break;
        }
        sal_task_sleep(1);
    }

    if (!done)
    {
        DRV_IF_ERROR_RETURN(DRV_E_CMD_NOT_DONE);
    }

    pre_info->conflict = GetUserIdCpuLookupResult(V, conflict_f, &userid_result);
    pre_info->valid = GetUserIdCpuLookupResult(V, lookupResultValid_f, &userid_result);

    /*acording lookup result build prepare information*/
    if (!GetUserIdCpuLookupResult(V, conflict_f, &userid_result))
    {
        pre_info->tbl_id = tbl_id;
        pre_info->key_index = GetUserIdCpuLookupResult(V, resultIndex_f, &userid_result);
    }
    else
    {
        return DRV_E_HASH_CONFLICT;
    }

    return DRV_E_NONE;
}

#define __ACC_XCOAM__

static int32
_drv_acc_prepare_xcoam_by_key(uint8 lchip, drv_acc_in_t* in, drv_cpu_acc_prepare_info_t* pre_info)
{
    EgressXcOamCpuLookupReq_m xcoam_req;
    EgressXcOamCpuLookupResult_m xcoam_result;
    uint32 cmd = 0;
    uint8 type = 0;
    uint32 tbl_id = 0;
    uint32 entry_size = 0;
    uint8 c_length = 0;
    uint8 length = 0;
    uint32 mode = 0;
    uint32 loop = 0;
    uint32 count = 0;
    uint32 done = 0;
    uint32 data[12] = { 0 };
    uint32 req_valid = 0;

    /* check valid bit clear */
    _drv_acc_hash_get_valid(lchip, DRV_ACC_HASH_MODULE_EGRESS_XC, &req_valid);
    if (req_valid)
    {
        return DRV_E_OCCPANCY;
    }

    sal_memset(&xcoam_req, 0, sizeof(EgressXcOamCpuLookupReq_m));
    sal_memset(&xcoam_result, 0, sizeof(EgressXcOamCpuLookupResult_m));

    /*clear request result*/
    cmd = DRV_IOW(EgressXcOamCpuLookupResult_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &xcoam_result));

    /*for action by key, need do lookup first*/
    pre_info->tbl_id = in->tbl_id;
    tbl_id = in->tbl_id;

    entry_size  = TABLE_ENTRY_SIZE(tbl_id) / 12;

    switch (entry_size)
    {
        case 1:
            c_length = DRV_HASH_85BIT_KEY_LENGTH;
            mode = HASH_KEY_LENGTH_MODE_SINGLE;
            length     = SINGLE_KEY_BYTE;
            break;

        case 2:
            c_length = DRV_HASH_170BIT_KEY_LENGTH;
            mode = HASH_KEY_LENGTH_MODE_DOUBLE;
            length     = DOUBLE_KEY_BYTE;
            break;

        case 4:
            c_length = DRV_HASH_340BIT_KEY_LENGTH;
            mode = HASH_KEY_LENGTH_MODE_QUAD;
            length     = QUAD_KEY_BYTE;
            break;
        default:
            return DRV_E_INVALID_TBL;
    }

#if (SDK_WORK_PLATFORM == 1)
    drv_model_hash_combined_key((uint8 *)data, (uint8 *)in->data, c_length, tbl_id);
    drv_model_hash_mask_key((uint8 *)data, (uint8 *)data, HASH_MODULE_EGRESS_XC, tbl_id);
#else
    sal_memcpy((uint8*)data, (uint8 *)in->data, length);
#endif

    SetEgressXcOamCpuLookupReq(V, cpuLookupReqValid_f, &xcoam_req, 1);
    SetEgressXcOamCpuLookupReq(A, data_f, &xcoam_req, data);

    cmd = DRV_IOW(EgressXcOamCpuLookupReq_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &xcoam_req));

    cmd = DRV_IOR(EgressXcOamCpuLookupResult_t, DRV_ENTRY_FLAG);

    for (loop = 0; (loop < 200) && !done; loop++)
    {
        for (count = 0; (count < 150) && !done; count++)
        {
            DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &xcoam_result));
            done = GetEgressXcOamCpuLookupResult(V, cpuLookupReqDone_f, &xcoam_result);
        }

        if (done)
        {
            break;
        }
        sal_task_sleep(1);
    }

    if (!done)
    {
        DRV_IF_ERROR_RETURN(DRV_E_CMD_NOT_DONE);
    }

    pre_info->conflict = GetEgressXcOamCpuLookupResult(V, conflict_f, &xcoam_result);
    pre_info->valid = GetEgressXcOamCpuLookupResult(V, lookupResultValid_f, &xcoam_result);

    /*acording lookup result build prepare information*/
    if (!GetEgressXcOamCpuLookupResult(V, conflict_f, &xcoam_result))
    {
        pre_info->tbl_id = tbl_id;
        pre_info->key_index = GetEgressXcOamCpuLookupResult(V, resultIndex_f, &xcoam_result);
    }
    else
    {
        return DRV_E_HASH_CONFLICT;
    }

    return DRV_E_NONE;
}

#define __ACC_FLOW__

static int32
_drv_acc_prepare_flow_by_key(uint8 lchip, drv_acc_in_t* in, drv_cpu_acc_prepare_info_t* pre_info)
{
    FibHost1FlowHashCpuLookupReq_m flow_req;
   //- FlowHashCpuLookupReq1_m flow_req1;
    FibHost1FlowHashCpuLookupResult_m flow_result;
    uint32 cmd = 0;
    uint8 type = 0;
    uint32 tbl_id = 0;
    uint32 entry_size = 0;
    uint8 c_length = 0;
    uint8 length = 0;
    uint32 mode = 0;
    uint32 loop = 0;
    uint32 count = 0;
    uint32 done = 0;
    uint32 data[12] = { 0 };
    uint32 req_valid = 0;
    DsFlowL2HashKey_m* p_l2hash = NULL;

    /* check valid bit clear */
    _drv_acc_hash_get_valid(lchip, DRV_ACC_HASH_MODULE_FLOW, &req_valid);
    if (req_valid)
    {
        return DRV_E_OCCPANCY;
    }

    sal_memset(&flow_req, 0, sizeof(FibHost1FlowHashCpuLookupReq_m));
    //-sal_memset(&flow_req1, 0, sizeof(FlowHashCpuLookupReq1_m));
    sal_memset(&flow_result, 0, sizeof(FibHost1FlowHashCpuLookupResult_m));

    cmd = DRV_IOW(FibHost1FlowHashCpuLookupResult_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &flow_result));

    /*for action by key, need do lookup first*/
    pre_info->tbl_id = in->tbl_id;
    tbl_id = in->tbl_id;

    entry_size  = TABLE_ENTRY_SIZE(tbl_id) / 12;

    switch (entry_size)
    {
        case 1:
            c_length = DRV_HASH_85BIT_KEY_LENGTH;
            mode = HASH_KEY_LENGTH_MODE_SINGLE;
            length     = SINGLE_KEY_BYTE;
            break;

        case 2:
            c_length = DRV_HASH_170BIT_KEY_LENGTH;
            mode = HASH_KEY_LENGTH_MODE_DOUBLE;
            length     = DOUBLE_KEY_BYTE;
            break;

        case 4:
            c_length = DRV_HASH_340BIT_KEY_LENGTH;
            mode = HASH_KEY_LENGTH_MODE_QUAD;
            length     = QUAD_KEY_BYTE;
            break;
        default:
            return DRV_E_INVALID_TBL;
    }

#if (SDK_WORK_PLATFORM == 1)
    drv_model_hash_combined_key((uint8 *)data, (uint8 *)in->data, c_length, tbl_id);
    drv_model_hash_mask_key((uint8 *)data, (uint8 *)data, HASH_MODULE_FLOW, tbl_id);
#else
    sal_memcpy((uint8*)data, (uint8 *)in->data, length);
    p_l2hash = (DsFlowL2HashKey_m*)data;
    SetDsFlowL2HashKey(V, dsAdIndex_f, p_l2hash, 0);
#endif

    SetFibHost1FlowHashCpuLookupReq(V, cpuLookupReqValid_f, &flow_req, 1);
    SetFibHost1FlowHashCpuLookupReq(A, data_f, &flow_req, data);
    SetFibHost1FlowHashCpuLookupReq(V, lengthMode_f, &flow_req, mode);
    SetFibHost1FlowHashCpuLookupReq(V, fibHost1Req_f, &flow_req, 0);

    cmd = DRV_IOW(FibHost1FlowHashCpuLookupReq_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &flow_req));

    cmd = DRV_IOR(FibHost1FlowHashCpuLookupResult_t, DRV_ENTRY_FLAG);

    for (loop = 0; (loop < 200) && !done; loop++)
    {
        for (count = 0; (count < 150) && !done; count++)
        {
            DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &flow_result));
            done = GetFibHost1FlowHashCpuLookupResult(V, cpuLookupReqDone_f, &flow_result);
        }

        if (done)
        {
            break;
        }
        sal_task_sleep(1);
    }

    if (!done)
    {
        DRV_IF_ERROR_RETURN(DRV_E_CMD_NOT_DONE);
    }

    pre_info->conflict = GetFibHost1FlowHashCpuLookupResult(V, conflict_f, &flow_result);
    pre_info->valid = GetFibHost1FlowHashCpuLookupResult(V, lookupResultValid_f, &flow_result);

    /*acording lookup result build prepare information*/
    if (!GetFibHost1FlowHashCpuLookupResult(V, conflict_f, &flow_result))
    {
        pre_info->tbl_id = tbl_id;
        pre_info->key_index = GetFibHost1FlowHashCpuLookupResult(V, resultIndex_f, &flow_result);
    }
    else
    {
        return DRV_E_HASH_CONFLICT;
    }

    return DRV_E_NONE;
}

int32
drv_acc_hash_prepare(uint8 lchip, uint8 hash_type, drv_acc_in_t* acc_in, drv_cpu_acc_prepare_info_t* pre_info)
{
    uint32 tbl_id = 0;
    uint8 cam_num = 0;

    DRV_IF_ERROR_RETURN(drv_get_cam_info(hash_type, &tbl_id, &cam_num));

    pre_info->cam_step = (TABLE_ENTRY_SIZE(tbl_id))/SINGLE_KEY_BYTE;
    pre_info->tbl_id = acc_in->tbl_id;
    pre_info->key_index = acc_in->index;
    pre_info->cam_num = cam_num;

    if (acc_in->op_type != DRV_ACC_OP_BY_INDEX)
    {
        if (hash_type == DRV_ACC_HASH_MODULE_FIB_HOST1)
        {
            DRV_IF_ERROR_RETURN(_drv_acc_prepare_host1_by_key(lchip, acc_in, pre_info));
        }
        else if (hash_type == DRV_ACC_HASH_MODULE_EGRESS_XC)
        {
            DRV_IF_ERROR_RETURN(_drv_acc_prepare_xcoam_by_key(lchip, acc_in, pre_info));
        }
        else if (hash_type == DRV_ACC_HASH_MODULE_FLOW)
        {
            DRV_IF_ERROR_RETURN(_drv_acc_prepare_flow_by_key(lchip, acc_in, pre_info));
        }
        else if (hash_type == DRV_ACC_HASH_MODULE_USERID)
        {
            DRV_IF_ERROR_RETURN(_drv_acc_prepare_userid_by_key(lchip, acc_in, pre_info));
        }
    }

    switch(acc_in->type)
    {
        case DRV_ACC_TYPE_ADD:
            pre_info->data = acc_in->data;
            pre_info->is_read = 0;
            break;

         case DRV_ACC_TYPE_LOOKUP:
            pre_info->is_read = 1;
            break;

         case DRV_ACC_TYPE_DEL:
            sal_memset((uint8*)pre_info->data, 0, 48);
            pre_info->is_read = 0;
            break;

         case DRV_ACC_TYPE_ALLOC:
            if (pre_info->valid)
            {
                return DRV_E_INVALID_ALLOC_INFO;
            }

            sal_memset((uint8*)pre_info->data, 0xFF, 48);
            pre_info->is_read = 0;
            break;
        default:
            return DRV_E_INVAILD_TYPE;

    }

    if (pre_info->key_index < cam_num)
    {
        pre_info->is_cam = 1;
    }
    else
    {
        pre_info->is_cam = 0;
    }

    return 0;
}

int32
drv_acc_hash_process(uint8 chip_id, drv_cpu_acc_prepare_info_t* p_info)
{
    uint32 cmdr                        = 0;
    uint32 cmdw                        = 0;
    uint32 index                       = 0;
    uint32 step                        = 0;
    uint32 cam_key[12] = { 0 };

    /*check whether using cam*/
    if (p_info->is_cam)
    {
        /*TBD*/
        /*If software alloc cam using, alloc cam index do not using acc return index*/

        /*If cam not shared, using acc return index, SDK should using this mode, check spec*/
    }

    if (p_info->is_cam)
    {
        index = p_info->key_index / p_info->cam_step;
        step  = p_info->key_index % p_info->cam_step;

        cmdr = DRV_IOR(p_info->tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(DRV_IOCTL(chip_id, index, cmdr, cam_key));
        if (!p_info->is_read)
        {
            sal_memcpy(&(cam_key[(SINGLE_KEY_BYTE / 4) * step]), p_info->data, TABLE_ENTRY_SIZE(p_info->tbl_id));
            cmdw = DRV_IOW(p_info->tbl_id, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(DRV_IOCTL(chip_id, index, cmdw, cam_key));
        }
        else
        {
            sal_memcpy(p_info->data, &(cam_key[(SINGLE_KEY_BYTE / 4) * step]), TABLE_ENTRY_SIZE(p_info->tbl_id));
        }
    }
    else
    {
        if (!p_info->is_read)
        {
            cmdw = DRV_IOW(p_info->tbl_id, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(DRV_IOCTL(chip_id, (p_info->key_index-p_info->cam_num), cmdw, p_info->data));
        }
        else
        {
            cmdr = DRV_IOR(p_info->tbl_id, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(DRV_IOCTL(chip_id, (p_info->key_index-p_info->cam_num), cmdr, p_info->data));
        }
    }

    return DRV_E_NONE;
}

int32
drv_acc_hash_result(uint8 lchip, drv_acc_in_t* acc_in, drv_cpu_acc_prepare_info_t* pre_info, drv_acc_out_t* out)
{
    out->is_conflict = pre_info->conflict;
    out->is_hit = pre_info->valid;
    out->key_index = pre_info->key_index;

    if (acc_in->op_type == DRV_ACC_OP_BY_INDEX)
    {
        sal_memcpy((uint8*)out->data, (uint8*)pre_info->data, TABLE_ENTRY_SIZE(pre_info->tbl_id));
    }

    return 0;
}

#define __MAC_LIMIT__
static int32
_drv_acc_prepare_read_mac_limit(uint8 lchip, drv_acc_in_t* acc_in, uint32* req)
{
    uint32 mac_limit_type = 0;
    uint32 cpu_req_port = 0;
    uint32 index = 0;
    uint16 fid = 0;
    DsFibHost0MacHashKey_m* p_mac_key = NULL;

    if (acc_in->op_type == DRV_ACC_OP_BY_PORT)
    {
        /*Get port base mac limit state*/
        if (DRV_GPORT_TO_GCHIP(acc_in->gport) == 0x1f)
        {
            index =  (acc_in->gport) & 0x3F;
        }
        else
        {
            index = DRV_GPORT_TO_LPORT(acc_in->gport) + 64;
        }
        mac_limit_type = 1;
    }
    else if (acc_in->op_type == DRV_ACC_OP_BY_VLAN)
    {
        DRV_PTR_VALID_CHECK(acc_in->data);
        p_mac_key = (DsFibHost0MacHashKey_m*)acc_in->data;
        fid = GetDsFibHost0MacHashKey(V, vsiId_f, p_mac_key);

        /*Get vlan base mac limit state*/
        index = 64 + 256 + fid;
        mac_limit_type = 1;
    }
    else if (acc_in->op_type == DRV_ACC_OP_BY_ALL)
    {
        if (DRV_IS_BIT_SET(acc_in->flag, DRV_ACC_STATIC_MAC_LIMIT_CNT))
        {
            /*Get profile base mac limit state*/
            mac_limit_type = 3;
        }
        else
        {
            /*Get dynamic base mac limit state*/
            mac_limit_type = 2;
        }
    }

    if (mac_limit_type == 1)
    {
        cpu_req_port = (((index & 0x1f) << 8) | (index >> 5));
        SetFibHashKeyCpuReq(V, cpuKeyVrfId_f, req, index);
        SetFibHashKeyCpuReq(V, hashKeyCpuReqPort_f, req, cpu_req_port);
    }

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, req, 1);
    SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, req, DRV_ACC_CHIP_LIMIT_READ);
    SetFibHashKeyCpuReq(V, cpuKeyDelType_f, req, mac_limit_type);

    return DRV_E_NONE;
}

static int32
_drv_acc_result_read_mac_limit(uint8 lchip, uint32* fib_acc_cpu_rlt, drv_acc_out_t* out)
{
    out->query_cnt         = GetFibHashKeyCpuResult(V, hashCpuLuIndex_f, fib_acc_cpu_rlt);
    out->is_full = GetFibHashKeyCpuResult(V, hashCpuKeyHit_f, fib_acc_cpu_rlt);
    return DRV_E_NONE;
}

static int32
_drv_acc_prepare_write_mac_limit(uint8 lchip, drv_acc_in_t* acc_in, uint32* req)
{
    uint32 index = 0;
    uint16 fid = 0;
    DsFibHost0MacHashKey_m* p_mac_key = NULL;
    uint32 del_type = 0;
    hw_mac_addr_t hw_mac       = { 0 };
    uint32   cpu_req_port = 0;

    if (acc_in->op_type == DRV_ACC_OP_BY_PORT)
    {
        /*port base mac limit state*/
        if (DRV_GPORT_TO_GCHIP(acc_in->gport) == 0x1f)
        {
            index =  (acc_in->gport) & 0x3F;
        }
        else
        {
            index = DRV_GPORT_TO_LPORT(acc_in->gport) + 64;
        }
        del_type = 1;
        SetFibHashKeyCpuReq(V, cpuKeyVrfId_f, req, index);
    }
    else if (acc_in->op_type == DRV_ACC_OP_BY_VLAN)
    {
        DRV_PTR_VALID_CHECK(acc_in->data);
        p_mac_key = (DsFibHost0MacHashKey_m*)acc_in->data;
        fid = GetDsFibHost0MacHashKey(V, vsiId_f, p_mac_key);

        /*vlan base mac limit state*/
        index = 64 + 256 + fid;
        del_type = 1;
        SetFibHashKeyCpuReq(V, cpuKeyVrfId_f, req, index);
    }
    else if (acc_in->op_type == DRV_ACC_OP_BY_ALL)
    {
        if (DRV_IS_BIT_SET(acc_in->flag, DRV_ACC_STATIC_MAC_LIMIT_CNT))
        {
            /*profile base mac limit state*/
            del_type = 3;
        }
        else
        {
            /*dynamic base mac limit state*/
            del_type = 2;
        }
    }

    if (!DRV_IS_BIT_SET(acc_in->flag, DRV_ACC_OVERWRITE_EN))
    {
        cpu_req_port = (((index & 0x1f) << 8) | (index >> 5));
        if (DRV_IS_BIT_SET(acc_in->flag, DRV_ACC_MAC_LIMIT_NEGATIVE))
        {
            cpu_req_port |= 1 <<13;
        }

        SetFibHashKeyCpuReq(V, hashKeyCpuReqPort_f, req, cpu_req_port);

        if (DRV_IS_BIT_SET(acc_in->flag, DRV_ACC_MAC_LIMIT_STATUS))
        {
            SetFibHashKeyCpuReq(V, cpuKeyPortDelMode_f, req, acc_in->limit_cnt);
            hw_mac[0] = 1<<1;
        }
        else
        {
            SetFibHashKeyCpuReq(V, cpuKeyIndex_f, req, acc_in->limit_cnt);
            hw_mac[0] = 1;
        }

        SetFibHashKeyCpuReq(A, cpuKeyMac_f, req, hw_mac);
        SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, req, DRV_ACC_CHIP_LIMIT_UPDATE);
    }
    else
    {
        SetFibHashKeyCpuReq(V, hashKeyCpuReqType_f, req, DRV_ACC_CHIP_LIMIT_WRITE);
        SetFibHashKeyCpuReq(V, cpuKeyIndex_f, req, acc_in->limit_cnt);
    }

    SetFibHashKeyCpuReq(V, hashKeyCpuReqValid_f, req, 1);
    SetFibHashKeyCpuReq(V, cpuKeyDelType_f, req, del_type);

    return DRV_E_NONE;
}

int32
drv_acc_mac_limit_prepare(uint8 lchip, drv_acc_in_t* acc_in, uint32* req)
{
    uint32 type = DRV_ACC_CHIP_MAX_TYPE;

    switch(acc_in->type)
    {
        case DRV_ACC_TYPE_ADD:
            /*write mac limit*/
            DRV_IF_ERROR_RETURN(_drv_acc_prepare_write_mac_limit(lchip, acc_in, req));
            break;

         case DRV_ACC_TYPE_LOOKUP:
            DRV_IF_ERROR_RETURN(_drv_acc_prepare_read_mac_limit(lchip, acc_in, req));
            /*read mac limit*/

            break;

        default:
            return DRV_E_INVAILD_TYPE;

    }

    return 0;
}

int32
drv_acc_mac_limit_result(uint8 lchip, drv_acc_in_t* acc_in, uint32* fib_acc_cpu_rlt, drv_acc_out_t* out)
{
    switch(acc_in->type)
    {
        case DRV_ACC_TYPE_ADD:
            break;

         case DRV_ACC_TYPE_LOOKUP:
            _drv_acc_result_read_mac_limit(lchip, fib_acc_cpu_rlt, out);
            break;

        default:
            return DRV_E_INVAILD_TYPE;

    }

    return 0;
}

#define __ACC_IPFIX__

static int32
_drv_acc_prepare_write_ipfix(uint8 lchip, uint8 by_index, drv_acc_in_t* acc_in, uint32* req)
{
    uint32 data[12] = { 0 };
    uint32 key_length = 0;
    uint8 is_340bits = 0;
    uint8 len = 0;

    if ((acc_in->tbl_id == DsIpfixL2L3HashKey_t) || (acc_in->tbl_id == DsIpfixL3Ipv6HashKey_t))
    {
        key_length = DRV_HASH_340BIT_KEY_LENGTH;
        len = QUAD_KEY_BYTE;
        is_340bits = 1;
    }
    else
    {
        key_length = DRV_HASH_170BIT_KEY_LENGTH;
        len = DOUBLE_KEY_BYTE;
        is_340bits = 0;
    }

#if (SDK_WORK_PLATFORM == 1)
    drv_model_hash_combined_key((uint8 *) data, (uint8 *)acc_in->data, key_length, acc_in->tbl_id);
#else
    sal_memcpy((uint8*)data, (uint8 *)acc_in->data, len);
#endif

    SetIpfixHashAdCpuReq(V, cpuReqType_f, req, (by_index?DRV_IPFIX_REQ_WRITE_BY_IDX:DRV_IPFIX_REQ_WRITE_BY_KEY));
    SetIpfixHashAdCpuReq(V, cpuReqValid_f, req, 1);
    if(by_index)
    {
        SetIpfixHashAdCpuReq(V, u1_gWriteByIndex_cpuIndex_f, req, acc_in->index);
        SetIpfixHashAdCpuReq(V, u1_gWriteByIndex_dataType_f, req, is_340bits);
        SetIpfixHashAdCpuReq(A, u1_gWriteByIndex_data_f, req, (uint32 *)data);
    }
    else
    {
        SetIpfixHashAdCpuReq(V, u1_gWriteByKey_dataType_f, req, is_340bits);
        SetIpfixHashAdCpuReq(A, u1_gWriteByKey_data_f, req, (uint32 *)data);
    }

    if (acc_in->tbl_id == DsIpfixSessionRecord_t)
    {
        /*write ad*/
        SetIpfixHashAdCpuReq(V, isAdMemOperation_f, req, 1);
    }
    else
    {
        SetIpfixHashAdCpuReq(V, isAdMemOperation_f, req, 0);
    }

    return DRV_E_NONE;
}

static int32
_drv_acc_prepare_del_ipfix(uint8 lchip, drv_acc_in_t* acc_in, uint32* req)
{
    uint32 data[12] = { 0 };
    uint8  is_340bits = 0;

    if ((acc_in->tbl_id == DsIpfixL2L3HashKey_t) || (acc_in->tbl_id == DsIpfixL3Ipv6HashKey_t))
    {
        is_340bits = 1;
    }
    else
    {
        is_340bits = 0;
    }

    SetIpfixHashAdCpuReq(V, cpuReqType_f, req, DRV_IPFIX_REQ_WRITE_BY_IDX);
    SetIpfixHashAdCpuReq(V, cpuReqValid_f, req, 1);
    SetIpfixHashAdCpuReq(V, u1_gWriteByIndex_cpuIndex_f, req, acc_in->index);
    SetIpfixHashAdCpuReq(V, u1_gWriteByIndex_dataType_f, req, is_340bits);
    SetIpfixHashAdCpuReq(A, u1_gWriteByIndex_data_f, req, (uint32 *)data);

    if (acc_in->tbl_id == DsIpfixSessionRecord_t)
    {
        /*write ad*/
        SetIpfixHashAdCpuReq(V, isAdMemOperation_f, req, 1);
    }
    else
    {
        SetIpfixHashAdCpuReq(V, isAdMemOperation_f, req, 0);
    }

    return DRV_E_NONE;
}

static int32
_drv_acc_prepare_lkp_ipfix(uint8 lchip, uint8 by_idx, drv_acc_in_t* acc_in, uint32* req)
{
    uint32 data[12] = { 0 };
    uint8  is_340bits = 0;
    uint8 key_length = 0;
    uint8 len = 0;

    if ((acc_in->tbl_id == DsIpfixL2L3HashKey_t) || (acc_in->tbl_id == DsIpfixL3Ipv6HashKey_t))
    {
        key_length = DRV_HASH_340BIT_KEY_LENGTH;
        len = QUAD_KEY_BYTE;
        is_340bits = 1;
    }
    else
    {
        key_length = DRV_HASH_170BIT_KEY_LENGTH;
        len = DOUBLE_KEY_BYTE;
        is_340bits = 0;
    }

    SetIpfixHashAdCpuReq(V, cpuReqValid_f, req, 1);
    if (!by_idx)
    {
#if (SDK_WORK_PLATFORM == 1)
        drv_model_hash_combined_key((uint8 *) data, (uint8 *)acc_in->data, key_length, acc_in->tbl_id);
#else
        sal_memcpy((uint8*)data, (uint8 *)acc_in->data, len);
#endif
        SetIpfixHashAdCpuReq(V, cpuReqType_f, req, DRV_IPFIX_REQ_LKP_BY_KEY);
        SetIpfixHashAdCpuReq(A, u1_gLookupByKey_data_f, req, (uint32 *)data);
        SetIpfixHashAdCpuReq(V, u1_gLookupByKey_dataType_f, req, is_340bits);
    }
    else
    {
        SetIpfixHashAdCpuReq(V, cpuReqType_f, req, DRV_IPFIX_REQ_LKP_BY_IDX);
        SetIpfixHashAdCpuReq(V, u1_gReadByIndex_dataType_f, req, is_340bits);
        SetIpfixHashAdCpuReq(V, u1_gReadByIndex_cpuIndex_f, req, acc_in->index);
    }

    if (acc_in->tbl_id == DsIpfixSessionRecord_t)
    {
        /*write ad*/
        SetIpfixHashAdCpuReq(V, isAdMemOperation_f, req, 1);
    }
    else
    {
        SetIpfixHashAdCpuReq(V, isAdMemOperation_f, req, 0);
    }

    return DRV_E_NONE;
}

int32
drv_acc_ipfix_prepare(uint8 lchip, drv_acc_in_t* acc_in, uint32* req)
{
    switch(acc_in->type)
    {
        case DRV_ACC_TYPE_ADD:
            if (acc_in->op_type == DRV_ACC_OP_BY_INDEX)
            {
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_write_ipfix(lchip, 1, acc_in, req));
            }
            else
            {
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_write_ipfix(lchip, 0, acc_in, req));
            }
            break;

         case DRV_ACC_TYPE_LOOKUP:
            if (acc_in->op_type == DRV_ACC_OP_BY_INDEX)
            {
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_lkp_ipfix(lchip, 1, acc_in, req));
            }
            else
            {
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_lkp_ipfix(lchip, 0, acc_in, req));
            }
            break;

         case DRV_ACC_TYPE_DEL:
            if (acc_in->op_type == DRV_ACC_OP_BY_INDEX)
            {
                DRV_IF_ERROR_RETURN(_drv_acc_prepare_del_ipfix(lchip, acc_in, req));
            }
            else
            {
                return DRV_E_INVAILD_TYPE;
            }
            break;
        default:
            return DRV_E_INVAILD_TYPE;

    }

    return 0;
}

int32
drv_acc_ipfix_process(uint8 chip_id, void* i_ipfix_req, void* o_ipfix_result)
{

    uint8                      loop  = 0;
    uint8                      count = 0;
    uint32                     done  = 0;
    uint32 cmdw = DRV_IOW(IpfixHashAdCpuReq_t, DRV_ENTRY_FLAG);
    uint32 cmdw_result = DRV_IOW(IpfixHashAdCpuResult_t,DRV_ENTRY_FLAG);
    uint32 cmdr = DRV_IOR(IpfixHashAdCpuResult_t, DRV_ENTRY_FLAG);
    IpfixHashAdCpuResult_m result;

    /*clear IpfixHashAdCpuResult*/
    sal_memset(&result,0,sizeof(result));
    DRV_IF_ERROR_RETURN(DRV_IOCTL(chip_id, 0, cmdw_result, &result));

    DRV_IF_ERROR_RETURN(DRV_IOCTL(chip_id, 0, cmdw, i_ipfix_req));
    for (loop = 0; (loop < 200) && !done; loop++)
    {
        for (count = 0; (count < 50) && !done; count++)
        {
            DRV_IF_ERROR_RETURN(DRV_IOCTL(chip_id, 0, cmdr, o_ipfix_result));
            done = GetIpfixHashAdCpuResult(V, operationDone_f, o_ipfix_result);
        }
        sal_task_sleep(1);
    }

    if (!done)
    {
        DRV_IF_ERROR_RETURN(DRV_E_CMD_NOT_DONE);
    }

    /*for ipfix acc sometime cannot return data following done is set, do one more io*/
    DRV_IF_ERROR_RETURN(DRV_IOCTL(chip_id, 0, cmdr, o_ipfix_result));
    return DRV_E_NONE;
}

int32
drv_acc_ipfix_result(uint8 acc_type, drv_acc_in_t* in, void* req_result, drv_acc_out_t* out)
{
    uint32                     ret_idx     = 0;
    uint32                     is_conflict = 0;
    uint32                     idx_invalid = 0;

    is_conflict = GetIpfixHashAdCpuResult(V, conflictValid_f, req_result);
    idx_invalid = GetIpfixHashAdCpuResult(V, invalidIndex_f, req_result);
    ret_idx     = GetIpfixHashAdCpuResult(V, lookupReturnIndex_f, req_result);

    out->is_conflict = is_conflict;
    out->is_hit       = !idx_invalid;

    if (in->op_type == DRV_ACC_OP_BY_KEY)
    {
        out->key_index = ret_idx;
    }

    if (in->type == DRV_ACC_TYPE_LOOKUP && in->op_type == DRV_ACC_OP_BY_INDEX)
    {
        DRV_IOR_FIELD(IpfixHashAdCpuResult_t, IpfixHashAdCpuResult_readData_f, (uint32 *)out->data, req_result);
    }

    return DRV_E_NONE;
}

#define __ACC_CID__
int32
drv_acc_cid_lookup(uint8 lchip, drv_acc_in_t* acc_in, drv_cpu_acc_prepare_info_t* pre_info)
{
    CidPairHashCpuLookupReq_m cid_req;
    CidPairHashCpuLookupResult_m cid_result;
    uint32 cmd = 0;
    uint32 tbl_id = 0;
    uint32 loop = 0;
    uint32 count = 0;
    uint32 done = 0;
    uint32 data = 0;
    DsCategoryIdPairHashLeftKey_m cid_data;
    uint32 src_cid = 0;
    uint32 dst_cid = 0;
    uint32 src_valid = 0;
    uint32 dst_valid = 0;
    uint32 entry_valid = 0;

    sal_memset(&cid_req, 0, sizeof(CidPairHashCpuLookupReq_m));
    sal_memset(&cid_result, 0, sizeof(CidPairHashCpuLookupResult_m));

    /*clear request result*/
    cmd = DRV_IOW(CidPairHashCpuLookupResult_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cid_result));

    /*for action by key, need do lookup first*/
    pre_info->tbl_id = acc_in->tbl_id;
    tbl_id = acc_in->tbl_id;

    /*Data must using 1st array for acc interface, decode data using DsCategoryIdPairHashLeftKey*/
    /*Format is: SrcCid(8)+DstCid(8)+SrcValid(1)+DstValid(1)+EntryValid(1)*/
    src_cid = (GetDsCategoryIdPairHashLeftKey(V, array_0_srcCategoryId_f, (uint32*)acc_in->data)) & 0xff;
    dst_cid = (GetDsCategoryIdPairHashLeftKey(V, array_0_destCategoryId_f, (uint32*)acc_in->data)) & 0xff;
    src_valid = (GetDsCategoryIdPairHashLeftKey(V, array_0_srcCategoryIdClassfied_f, (uint32*)acc_in->data));
    dst_valid = (GetDsCategoryIdPairHashLeftKey(V, array_0_destCategoryIdClassfied_f, (uint32*)acc_in->data));
    entry_valid = (GetDsCategoryIdPairHashLeftKey(V, array_0_valid_f, (uint32*)acc_in->data));
    data = ((src_cid << 11) | (dst_cid << 3) | (src_valid << 2) | (dst_valid << 1) | entry_valid);

    SetCidPairHashCpuLookupReq(V, data_f, &cid_req, data);
    SetCidPairHashCpuLookupReq(V, cpuLookupReqValid_f, &cid_req, 1);

    cmd = DRV_IOW(CidPairHashCpuLookupReq_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cid_req));

    cmd = DRV_IOR(CidPairHashCpuLookupResult_t, DRV_ENTRY_FLAG);

    for (loop = 0; (loop < 200) && !done; loop++)
    {
        for (count = 0; (count < 150) && !done; count++)
        {
            DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &cid_result));
            done = GetCidPairHashCpuLookupResult(V, cpuLookupReqDone_f, &cid_result);
        }

        if (done)
        {
            break;
        }
        sal_task_sleep(1);
    }

    if (!done)
    {
        DRV_IF_ERROR_RETURN(DRV_E_CMD_NOT_DONE);
    }

    pre_info->conflict = !GetCidPairHashCpuLookupResult(V, hit_f, &cid_result) && !GetCidPairHashCpuLookupResult(V, freeValid_f, &cid_result);
    pre_info->valid = GetCidPairHashCpuLookupResult(V, hit_f, &cid_result);

    /*acording lookup result build prepare information*/
    if (!pre_info->conflict)
    {
        pre_info->is_left = GetCidPairHashCpuLookupResult(V, isLeft_f, &cid_result);
        pre_info->is_high = GetCidPairHashCpuLookupResult(V, entryOffset_f, &cid_result);
        pre_info->key_index = GetCidPairHashCpuLookupResult(V, hashKeyIndex_f, &cid_result);
        pre_info->tbl_id = pre_info->is_left?DsCategoryIdPairHashLeftKey_t:DsCategoryIdPairHashRightKey_t;

        /*re-coding hash data*/
        if (acc_in->type == DRV_ACC_TYPE_DEL)
        {
            src_cid = 0;
            dst_cid = 0;
            src_valid = 0;
            dst_valid = 0;
            entry_valid = 0;
        }

        cmd = DRV_IOR(pre_info->tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, pre_info->key_index, cmd, &cid_data));
        if (!pre_info->is_high)
        {
            SetDsCategoryIdPairHashLeftKey(V, array_0_srcCategoryId_f, &cid_data, src_cid);
            SetDsCategoryIdPairHashLeftKey(V, array_0_destCategoryId_f, &cid_data, dst_cid);
            SetDsCategoryIdPairHashLeftKey(V, array_0_srcCategoryIdClassfied_f, &cid_data, src_valid);
            SetDsCategoryIdPairHashLeftKey(V, array_0_destCategoryIdClassfied_f, &cid_data, dst_valid);
            SetDsCategoryIdPairHashLeftKey(V, array_0_valid_f, &cid_data, entry_valid);
        }
        else
        {
            SetDsCategoryIdPairHashLeftKey(V, array_1_srcCategoryId_f, &cid_data, src_cid);
            SetDsCategoryIdPairHashLeftKey(V, array_1_destCategoryId_f, &cid_data, dst_cid);
            SetDsCategoryIdPairHashLeftKey(V, array_1_srcCategoryIdClassfied_f, &cid_data, src_valid);
            SetDsCategoryIdPairHashLeftKey(V, array_1_destCategoryIdClassfied_f, &cid_data, dst_valid);
            SetDsCategoryIdPairHashLeftKey(V, array_1_valid_f, &cid_data, entry_valid);
        }

        sal_memcpy(pre_info->data, &cid_data, sizeof(DsCategoryIdPairHashLeftKey_m));
    }
    else
    {
        return DRV_E_NONE;
    }

    return DRV_E_NONE;
}

int32
drv_acc_cid_prepare(uint8 lchip, drv_acc_in_t* acc_in, drv_cpu_acc_prepare_info_t* pre_info)
{
    uint32 tbl_id = 0;
    uint32 req_valid = 0;
    uint32 cmd = 0;
    DsCategoryIdPairHashLeftKey_m cid_data;

    pre_info->tbl_id = acc_in->tbl_id;
    pre_info->key_index = acc_in->index;

    /* check valid bit clear */
    DRV_IF_ERROR_RETURN(_drv_acc_hash_get_valid(lchip, DRV_ACC_HASH_MODULE_CID, &req_valid));
    if (req_valid)
    {
        return DRV_E_OCCPANCY;
    }

    /*only support add by index, del/lookup should by key*/
    if ((acc_in->op_type == DRV_ACC_OP_BY_INDEX) && (acc_in->type != DRV_ACC_TYPE_ADD))
    {
        return DRV_E_INVAILD_TYPE;
    }

    if (acc_in->op_type != DRV_ACC_OP_BY_INDEX)
    {
        DRV_IF_ERROR_RETURN(drv_acc_cid_lookup(lchip, acc_in, pre_info));
    }

    switch(acc_in->type)
    {
        case DRV_ACC_TYPE_ADD:
            if (acc_in->op_type == DRV_ACC_OP_BY_INDEX)
            {
                /*re-coding hash data*/
                cmd = DRV_IOR(acc_in->tbl_id, DRV_ENTRY_FLAG);
                DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, pre_info->key_index, cmd, &cid_data));

                if (!acc_in->offset)
                {
                    sal_memcpy(&cid_data, (uint32*)acc_in->data, sizeof(uint32)*2);
                }
                else
                {
                    sal_memcpy(((uint32*)&cid_data+2), (uint32*)acc_in->data, sizeof(uint32)*2);
                }

                sal_memcpy(pre_info->data, &cid_data, sizeof(DsCategoryIdPairHashLeftKey_m));
            }


            pre_info->is_read = 0;
            break;

         case DRV_ACC_TYPE_LOOKUP:
            pre_info->is_read = 1;
            break;

         case DRV_ACC_TYPE_DEL:
            pre_info->is_read = 0;
            break;

        default:
            return DRV_E_INVAILD_TYPE;

    }

    return 0;
}


int32
drv_acc_cid_process(uint8 chip_id, drv_cpu_acc_prepare_info_t* p_info)
{
    uint32 cmdr                        = 0;
    uint32 cmdw                        = 0;

    if (!p_info->is_read)
    {
        cmdw = DRV_IOW(p_info->tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(DRV_IOCTL(chip_id, (p_info->key_index), cmdw, p_info->data));
    }
    else
    {
        cmdr = DRV_IOR(p_info->tbl_id, DRV_ENTRY_FLAG);
        DRV_IF_ERROR_RETURN(DRV_IOCTL(chip_id, (p_info->key_index), cmdr, p_info->data));
    }

    return DRV_E_NONE;
}

int32
drv_acc_cid_result(uint8 lchip, drv_acc_in_t* acc_in, drv_cpu_acc_prepare_info_t* pre_info, drv_acc_out_t* out)
{
    out->is_conflict = pre_info->conflict;
    out->is_hit = pre_info->valid;
    out->key_index = pre_info->key_index;
    out->is_left = pre_info->is_left;
    out->offset = pre_info->is_high;

    if (acc_in->type == DRV_ACC_TYPE_LOOKUP)
    {
        if (!pre_info->is_high)
        {
            out->ad_index = (GetDsCategoryIdPairHashLeftKey(V, array_0_adIndex_f, (uint32*)pre_info->data));
        }
        else
        {
            out->ad_index = (GetDsCategoryIdPairHashLeftKey(V, array_1_adIndex_f, (uint32*)pre_info->data));
        }
    }

    return 0;
}

#define __ACC_START__
/*only for fdb acc*/
int32
drv_acc_fdb(uint8 chip_id, drv_acc_in_t* acc_in, drv_acc_out_t* acc_out)
{
    uint32 cmd = 0;
    FibHashKeyCpuReq_m fib_req;
    FibHashKeyCpuResult_m fib_result;

    sal_memset(&fib_result, 0, sizeof(FibHashKeyCpuResult_m));

    FIB_ACC_LOCK(chip_id);
    /* check valid bit clear */
    cmd = DRV_IOR(FibHashKeyCpuReq_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN_WITH_UNLOCK(DRV_IOCTL(chip_id, 0, cmd, &fib_req), p_drv_master[chip_id]->fib_acc_mutex);
    if (GetFibHashKeyCpuReq(V,hashKeyCpuReqValid_f,&fib_req))
    {
        FIB_ACC_UNLOCK(chip_id);
        return DRV_E_OCCPANCY;
    }

    sal_memset(&fib_req, 0, sizeof(FibHashKeyCpuReq_m));

    DRV_IF_ERROR_RETURN_WITH_UNLOCK(drv_acc_fdb_prepare(chip_id, acc_in, (uint32*)&fib_req),
        p_drv_master[chip_id]->fib_acc_mutex);
    DRV_IF_ERROR_RETURN_WITH_UNLOCK(drv_acc_host0_process(chip_id, (uint32*)&fib_req, (uint32*)&fib_result),
        p_drv_master[chip_id]->fib_acc_mutex);
    FIB_ACC_UNLOCK(chip_id);
    DRV_IF_ERROR_RETURN(drv_acc_fdb_result(chip_id, acc_in, (uint32*)&fib_result, acc_out));

    return DRV_E_NONE;
}

/* for host0 acc*/
int32
drv_acc_host0(uint8 chip_id, drv_acc_in_t* acc_in, drv_acc_out_t* acc_out)
{
    uint32 cmd = 0;
    FibHashKeyCpuReq_m fib_req;
    FibHashKeyCpuResult_m fib_result;

    sal_memset(&fib_result, 0, sizeof(FibHashKeyCpuResult_m));

    FIB_ACC_LOCK(chip_id);
    /* check valid bit clear */
    cmd = DRV_IOR(FibHashKeyCpuReq_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN_WITH_UNLOCK(DRV_IOCTL(chip_id, 0, cmd, &fib_req), p_drv_master[chip_id]->fib_acc_mutex);
    if (GetFibHashKeyCpuReq(V,hashKeyCpuReqValid_f,&fib_req))
    {
        FIB_ACC_UNLOCK(chip_id);
        return DRV_E_OCCPANCY;
    }

    sal_memset(&fib_req, 0, sizeof(FibHashKeyCpuReq_m));

    DRV_IF_ERROR_RETURN_WITH_UNLOCK(drv_acc_host0_prepare(chip_id, acc_in, (uint32*)&fib_req),
        p_drv_master[chip_id]->fib_acc_mutex);
    DRV_IF_ERROR_RETURN_WITH_UNLOCK(drv_acc_host0_process(chip_id, (uint32*)&fib_req, (uint32*)&fib_result),
        p_drv_master[chip_id]->fib_acc_mutex);
    FIB_ACC_UNLOCK(chip_id);
    DRV_IF_ERROR_RETURN(drv_acc_host0_result(chip_id, acc_in, (uint32*)&fib_result, acc_out));

    return DRV_E_NONE;
}

/* for host1/xcoam/flow/userid acc*/
int32
drv_acc_hash(uint8 chip_id, uint8 hash_module, drv_acc_in_t* acc_in, drv_acc_out_t* acc_out)
{
    drv_cpu_acc_prepare_info_t pre_info;
    uint32 write_data[12] = { 0 };

    sal_memset(&pre_info, 0, sizeof(drv_cpu_acc_prepare_info_t));
    pre_info.data = write_data;

    CPU_ACC_LOCK(chip_id);
    DRV_IF_ERROR_RETURN_WITH_UNLOCK(drv_acc_hash_prepare(chip_id, hash_module, acc_in, &pre_info),
        p_drv_master[chip_id]->cpu_acc_mutex);
    DRV_IF_ERROR_RETURN_WITH_UNLOCK(drv_acc_hash_process(chip_id, &pre_info),
        p_drv_master[chip_id]->cpu_acc_mutex);
    CPU_ACC_UNLOCK(chip_id);
    DRV_IF_ERROR_RETURN(drv_acc_hash_result(chip_id, acc_in, &pre_info, acc_out));

    return DRV_E_NONE;
}

/*for mac limit process*/
int32
drv_acc_mac_limit(uint8 chip_id, drv_acc_in_t* acc_in, drv_acc_out_t* acc_out)
{
    uint32 cmd = 0;
    FibHashKeyCpuReq_m fib_req;
    FibHashKeyCpuResult_m fib_result;

    sal_memset(&fib_result, 0, sizeof(FibHashKeyCpuResult_m));

    FIB_ACC_LOCK(chip_id);
    /* check valid bit clear */
    cmd = DRV_IOR(FibHashKeyCpuReq_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN_WITH_UNLOCK(DRV_IOCTL(chip_id, 0, cmd, &fib_req),p_drv_master[chip_id]->fib_acc_mutex);
    if (GetFibHashKeyCpuReq(V,hashKeyCpuReqValid_f,&fib_req))
    {
        FIB_ACC_UNLOCK(chip_id);
        return DRV_E_OCCPANCY;
    }

    sal_memset(&fib_req, 0, sizeof(FibHashKeyCpuReq_m));

    DRV_IF_ERROR_RETURN_WITH_UNLOCK(drv_acc_mac_limit_prepare(chip_id, acc_in, (uint32*)&fib_req),
        p_drv_master[chip_id]->fib_acc_mutex);
    DRV_IF_ERROR_RETURN_WITH_UNLOCK(drv_acc_host0_process(chip_id, (uint32*)&fib_req, (uint32*)&fib_result),
        p_drv_master[chip_id]->fib_acc_mutex);
    FIB_ACC_UNLOCK(chip_id);
    DRV_IF_ERROR_RETURN(drv_acc_mac_limit_result(chip_id, acc_in, (uint32*)&fib_result, acc_out));

    return DRV_E_NONE;
}

/*only for ipfix acc*/
int32
drv_acc_ipfix(uint8 chip_id, drv_acc_in_t* acc_in, drv_acc_out_t* acc_out)
{
    uint32 cmd = 0;
    IpfixHashAdCpuReq_m ipfix_req;
    IpfixHashAdCpuResult_m ipfix_result;

    sal_memset(&ipfix_result, 0, sizeof(IpfixHashAdCpuResult_m));

    IPFIX_ACC_LOCK(chip_id);
    /* check valid bit clear */
    cmd = DRV_IOR(IpfixHashAdCpuReq_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN_WITH_UNLOCK(DRV_IOCTL(0, 0, cmd, &ipfix_req), p_drv_master[chip_id]->ipfix_acc_mutex);
    if (GetIpfixHashAdCpuReq(V, cpuReqValid_f, &ipfix_req))
    {
        IPFIX_ACC_UNLOCK(chip_id);
        return DRV_E_OCCPANCY;
    }

    sal_memset(&ipfix_req, 0, sizeof(IpfixHashAdCpuReq_m));

    DRV_IF_ERROR_RETURN_WITH_UNLOCK(drv_acc_ipfix_prepare(chip_id, acc_in, (uint32*)&ipfix_req),
        p_drv_master[chip_id]->ipfix_acc_mutex);
    DRV_IF_ERROR_RETURN_WITH_UNLOCK(drv_acc_ipfix_process(chip_id, (uint32*)&ipfix_req, (uint32*)&ipfix_result),
        p_drv_master[chip_id]->ipfix_acc_mutex);
    IPFIX_ACC_UNLOCK(chip_id);
    DRV_IF_ERROR_RETURN(drv_acc_ipfix_result(chip_id, acc_in, (uint32*)&ipfix_result, acc_out));

    return DRV_E_NONE;
}


/* for cid acc*/
int32
drv_acc_cid(uint8 chip_id, drv_acc_in_t* acc_in, drv_acc_out_t* acc_out)
{
    drv_cpu_acc_prepare_info_t pre_info;
    uint32 write_data[12] = { 0 };

    sal_memset(&pre_info, 0, sizeof(drv_cpu_acc_prepare_info_t));
    pre_info.data = write_data;

    CID_ACC_LOCK(chip_id);
    DRV_IF_ERROR_RETURN_WITH_UNLOCK(drv_acc_cid_prepare(chip_id, acc_in, &pre_info),
        p_drv_master[chip_id]->cid_acc_mutex);
    DRV_IF_ERROR_RETURN_WITH_UNLOCK(drv_acc_cid_process(chip_id, &pre_info),
        p_drv_master[chip_id]->cid_acc_mutex);
    CID_ACC_UNLOCK(chip_id);
    DRV_IF_ERROR_RETURN(drv_acc_cid_result(chip_id, acc_in, &pre_info, acc_out));

    return DRV_E_NONE;
}

/*drv layer acc interface*/
int32
drv_acc(uint8 chip_id, void* in, void* out)
{
    drv_acc_in_t* p_acc = NULL;
    uint8 hash_module = 0;

    DRV_PTR_VALID_CHECK(in);
    DRV_PTR_VALID_CHECK(out);

    p_acc = (drv_acc_in_t*)in;

    DRV_IF_ERROR_RETURN(_drv_acc_get_hash_module_from_tblid(p_acc->tbl_id, &hash_module));

    if (hash_module == DRV_ACC_HASH_MODULE_FDB)
    {
        if ((p_acc->type == DRV_ACC_TYPE_LOOKUP) && (p_acc->op_type == DRV_ACC_OP_BY_INDEX))
        {
            DRV_IF_ERROR_RETURN(drv_acc_host0(chip_id, in, out));
        }
        else
        {
            DRV_IF_ERROR_RETURN(drv_acc_fdb(chip_id, in, out));
        }
    }
    else if (hash_module == DRV_ACC_HASH_MODULE_FIB_HOST0)
    {
        DRV_IF_ERROR_RETURN(drv_acc_host0(chip_id, in, out));
    }
    else if ((hash_module == DRV_ACC_HASH_MODULE_FIB_HOST1) || (hash_module <= DRV_ACC_HASH_MODULE_EGRESS_XC) ||
            (hash_module == DRV_ACC_HASH_MODULE_FLOW) || (hash_module == DRV_ACC_HASH_MODULE_USERID))
    {
        DRV_IF_ERROR_RETURN(drv_acc_hash(chip_id, hash_module, in, out));
    }
    else if (hash_module == DRV_ACC_HASH_MODULE_MAC_LIMIT)
    {
        DRV_IF_ERROR_RETURN(drv_acc_mac_limit(chip_id, in, out));
    }
    else if (hash_module == DRV_ACC_HASH_MODULE_IPFIX)
    {
        DRV_IF_ERROR_RETURN(drv_acc_ipfix(chip_id, in, out));
    }
    else if (hash_module == DRV_ACC_HASH_MODULE_CID)
    {
        DRV_IF_ERROR_RETURN(drv_acc_cid(chip_id, in, out));
    }
    else
    {
        return DRV_E_INVAILD_TYPE;
    }

    return DRV_E_NONE;
}


int32
drv_ftm_get_entry_size(uint8 lchip, uint32 table_id, uint32* entry_size)
{
    *entry_size = TABLE_ENTRY_SIZE(table_id);

    return DRV_E_NONE;
}

int32
drv_get_dynamic_ram_couple_mode(uint32 *couple_mode)
{

    return DRV_E_NONE;
}

int32
drv_set_dynamic_ram_couple_mode(uint32 couple_mode)
{

    return DRV_E_NONE;
}



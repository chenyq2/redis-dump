/**
  @file drv_tbl_reg.c

  @date 2010-07-22

  @version v5.1

  The file implement driver IOCTL defines and macros
*/

#include "sal.h"
#include "drv_common.h"
#include "drv_error.h"
/**********************************************************************************
              Define Global declarations, Typedef, define and Data Structure
***********************************************************************************/
extern int32 drv_get_dynamic_ram_couple_mode(uint32 *couple_mode);

/* global store driver all mem info */
tables_info_t drv_tbls_list[MaxTblId_t];

dup_address_offset_type_t duplicate_addr_type = SLICE_Addr_All;

uint32 parser_tbl_id_list[] =
{
   ParserUdfCam_t                              ,
   ParserUdfCamResult_t                     ,
   ParserDebugStats_t                       ,
   ParserEthernetCtl_t                      ,
   ParserIpChecksumCtl_t                    ,
   ParserIpCtl_t                            ,
   ParserL3Ctl_t                            ,
   ParserLayer2ProtocolCam_t                ,
   ParserLayer2ProtocolCamValid_t           ,
   ParserLayer3FlexCtl_t                    ,
   ParserLayer3HashCtl_t                    ,
   ParserLayer3ProtocolCam_t                ,
   ParserLayer3ProtocolCamValid_t           ,
   ParserLayer3ProtocolCtl_t                ,
   ParserLayer4AchCtl_t                     ,
   ParserLayer4AppCtl_t                     ,
   ParserLayer4FlexCtl_t                    ,
   ParserMplsCtl_t                          ,
   ParserPacketTypeMap_t                    ,
   ParserPbbCtl_t                           ,
   ParserTrillCtl_t                         ,
};
/**
 @brief
*/
int32
drv_get_tbl_index_base(tbls_id_t tbl_id, uint32 index, uint8 *addr_offset)
{
    DRV_TBL_ID_VALID_CHECK(tbl_id);

    if (TABLE_ENTRY_TYPE(tbl_id) == SLICE_Cascade)
    {
        if (index >= (TABLE_MAX_INDEX(tbl_id)/2))
        {
            *addr_offset = 1;
        }
        else
        {
            *addr_offset = 0;
        }
    }
#if (SDK_WORK_PLATFORM == 0)
    else if (TABLE_ENTRY_TYPE(tbl_id) == SLICE_Duplicated)
    {
        if (duplicate_addr_type == SLICE_Addr_0)
        {
            *addr_offset = 1;
        }
        else if (duplicate_addr_type == SLICE_Addr_1)
        {
            *addr_offset = 2;
        }
    }
#endif
    else
    {
        *addr_offset = 0;
    }

    return DRV_E_NONE;
}

fields_t *
drv_find_field(tbls_id_t tbl_id, fld_id_t field_id)
{
    if (!(CHK_TABLE_ID_VALID(tbl_id) | CHK_FIELD_ID_VALID(tbl_id, field_id)))
    {
        DRV_DBG_INFO("ERROR! INVALID TblID or fieldID! TblID: %d, fieldID: %d\n", tbl_id, field_id);
        if (TABLE_NAME(tbl_id))
        {
            DRV_DBG_INFO("ERROR! INVALID TblName:%s\n", TABLE_NAME(tbl_id));
        }
        return NULL;
    }

    return (TABLE_FIELD_INFO_PTR(tbl_id) + field_id);
}

/**
 @brief Get a field of  word & bit offset
*/
int32
drv_get_field_offset(tbls_id_t tbl_id, fld_id_t field_id, uint32* w_offset, uint32 *b_offset)
{
#ifdef SHANZ_NOTE

    fields_t* field = NULL;

    DRV_TBL_ID_VALID_CHECK(tbl_id);

    field = drv_find_field(tbl_id, field_id);
    if (field == NULL)
    {
        DRV_DBG_INFO("ERROR! (drv_mem_get_field): memID-%d, field-%d is not supported\n", tbl_id, field_id);
        return DRV_E_INVALID_FLD;
    }

    if(NULL != w_offset)
    {
        *w_offset = field->word_offset;
    }

    if(NULL != b_offset)
    {
        *b_offset = field->bit_offset;
    }
#endif
    return DRV_E_NONE;
}

/**
 @brief
*/
int32
drv_get_tbl_string_by_id(tbls_id_t tbl_id, char* name)
{
    if (!name)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    if ((tbl_id >= 0) && (tbl_id < MaxTblId_t))
    {
         sal_strcpy(name, TABLE_NAME(tbl_id));
         return DRV_E_NONE;
    }

    return DRV_E_INVALID_TBL;
}

/**
 @brief
*/
int32
drv_get_field_string_by_id(tbls_id_t tbl_id, fld_id_t field_id, char* name)
{
    fields_t* ptr_field_info = NULL;

    if (!name)
    {
        return DRV_E_INVALID_PARAMETER;
    }

    if ((tbl_id >= 0) && (tbl_id < MaxTblId_t))
    {
        if (field_id < TABLE_FIELD_NUM(tbl_id))
        {
            ptr_field_info = TABLE_FIELD_INFO_PTR(tbl_id);
            sal_strcpy(name, ptr_field_info[field_id].ptr_field_name);
            return DRV_E_NONE;
        }
        else
        {
            return DRV_E_INVALID_FLD;
        }
    }

    return DRV_E_INVALID_TBL;
}

/**
 @brief
*/
int32
drv_get_tbl_id_by_string(tbls_id_t* tbl_id, char* name)
{
    tbls_id_t tmp_tableid = 0;

    /* This is so inefficient Code, need to consider to optimize it, add by zhouw??? */
    for (tmp_tableid = 0; tmp_tableid < MaxTblId_t; tmp_tableid++)
    {
        if (0 == sal_strcasecmp(name, TABLE_NAME(tmp_tableid)))
        {
            *tbl_id = tmp_tableid;
            return DRV_E_NONE;
        }
    }

    DRV_DBG_INFO("%% Not Find the TableID!! tableName: %s\n", name);

    return DRV_E_INVALID_TBL;
}

/**
 @brief
*/
int32
drv_get_field_id_by_string(tbls_id_t tbl_id, fld_id_t* field_id, char* name)
{
    fields_t* ptr_field_info = TABLE_FIELD_INFO_PTR(tbl_id);
    uint32 field_num = TABLE_FIELD_NUM(tbl_id);
    uint32 tmp_index = 0;

    for (tmp_index = 0; tmp_index < field_num; tmp_index++)
    {
        if (0 == sal_strcasecmp(name, ptr_field_info[tmp_index].ptr_field_name))
        {
            *field_id = tmp_index;
            return DRV_E_NONE;
        }
    }

    DRV_DBG_INFO("%% Not Find the FieldID!! tableId: %d; Fieldname: %s\n", tbl_id, name);

    return DRV_E_INVALID_FLD;
}

int32
drv_table_consum_hw_addr_size_per_index(tbls_id_t tbl_id, uint32 *hw_addr_size)
{
    uint32 entry_size = TABLE_ENTRY_SIZE(tbl_id);
    uint32 word_num = 0;

    if ((!entry_size)
        || (entry_size%DRV_BYTES_PER_WORD))
    {
        DRV_DBG_INFO("%% ERROR! tbl_id = %d 's entrySize(%d Bytes) is unreasonable in driver dataBase!!\n", tbl_id, entry_size);
        return DRV_E_INVALID_PARAMETER;
    }

    *hw_addr_size = 0;
    word_num = entry_size/DRV_BYTES_PER_WORD;

    switch(word_num) /* wordNum */
    {
        case 1:     /* 1 word */
            *hw_addr_size = 1;
            break;
        case 2:     /* 2 words */
            *hw_addr_size = 2;
            break;
        case 3:
        case 4:
            *hw_addr_size = 4;
            break;
        case 5:
        case 6:
        case 7:
        case 8:
            *hw_addr_size = 8;
            break;
        default:           /* addr_unit(=2^n) >= wordNum > 2^(n-1) */
            if ((word_num <= 16) && (word_num >= 9))
            {
                *hw_addr_size = 16;
            }
            else if ((word_num >= 17) && (word_num <= 32))
            {
                *hw_addr_size = 32;
            }
            else if ((word_num >= 33) && (word_num <= 64))
            {
                *hw_addr_size = 64;
            }
            /* hold on by zhouw???? Pay attention !! */
          //  *addr_unit = 2^(ceil(M_LOG2E *(entry_size/DRV_BYTES_PER_WORD)));
            break;
    }

    return DRV_E_NONE;
}

static int32
_drv_table_get_sram_hw_addr(tbls_id_t tbl_id, uint32 index, uint32 *hw_addr, uint32 is_dump_cfg)
{
    uint8 blk_id = 0;
    uint8 addr_offset = 0;
    uint32 hw_data_base = 0;
    uint32 hw_addr_size_per_idx = 0; /* unit: word, per-index consume hw address size */
    uint32 map_index = 0;

    DRV_TBL_INDEX_VALID_CHECK(tbl_id, index);

    DRV_IF_ERROR_RETURN(drv_table_consum_hw_addr_size_per_index(tbl_id, &hw_addr_size_per_idx));

    if (drv_get_table_type(tbl_id) == DRV_TABLE_TYPE_DYNAMIC)
    {
        for (blk_id = 0; blk_id < MAX_DRV_BLOCK_NUM; blk_id++)
        {
            DRV_IF_ERROR_RETURN(drv_get_tbl_index_base(tbl_id, index, &addr_offset));

            if (!IS_BIT_SET(DYNAMIC_BITMAP(tbl_id), blk_id))
            {
                continue;
            }

            if ((index >= DYNAMIC_START_INDEX(tbl_id, blk_id)) && (index <= DYNAMIC_END_INDEX(tbl_id, blk_id)))
            {
                hw_data_base = DYNAMIC_DATA_BASE(tbl_id, blk_id, addr_offset);
                break;
            }
        }

        if (DYNAMIC_ACCESS_MODE(tbl_id) == DYNAMIC_8W_MODE)
        {
            if ((index%2) && (!is_dump_cfg))
            {
                DRV_DBG_INFO("ERROR!! get tbl_id %d index must be even! now index = %d\n", tbl_id, index);
                return DRV_E_INVALID_INDEX;
            }

            *hw_addr = hw_data_base + (index - DYNAMIC_START_INDEX(tbl_id, blk_id)) * DRV_ADDR_BYTES_PER_ENTRY;
        }
        else if (DYNAMIC_ACCESS_MODE(tbl_id) == DYNAMIC_16W_MODE)
        {
            if ((index%4) && (!is_dump_cfg))
            {
                DRV_DBG_INFO("ERROR!! get tbl_id %d index must be times of 4! now index = %d\n", tbl_id, index);
                return DRV_E_INVALID_INDEX;
            }

            *hw_addr = hw_data_base + (index - DYNAMIC_START_INDEX(tbl_id, blk_id)) * DRV_ADDR_BYTES_PER_ENTRY;
        }
        else
        {
            *hw_addr = hw_data_base + (index - DYNAMIC_START_INDEX(tbl_id, blk_id)) * hw_addr_size_per_idx * DRV_BYTES_PER_WORD;
        }
        //sal_printf("tbl_id:%d, hw_data_base:%08x, real hw addr:%08x\n",tbl_id,hw_data_base,*hw_addr);
    }
    else if (drv_get_table_type(tbl_id) == DRV_TABLE_TYPE_TCAM_AD)
    {
        for (blk_id = 0; blk_id < MAX_NOR_TCAM_NUM; blk_id++)
        {
            DRV_IF_ERROR_RETURN(drv_get_tbl_index_base(tbl_id, index, &addr_offset));

            if (!IS_BIT_SET(TCAM_BITMAP(tbl_id), blk_id))
            {
                continue;
            }

            if ((index >= TCAM_START_INDEX(tbl_id, blk_id)) && (index <= TCAM_END_INDEX(tbl_id, blk_id)))
            {
                hw_data_base = TCAM_DATA_BASE(tbl_id, blk_id, addr_offset);
                map_index = index - TCAM_START_INDEX(tbl_id, blk_id);

                break;
            }
        }
        *hw_addr = hw_data_base + map_index * hw_addr_size_per_idx * DRV_BYTES_PER_WORD;
    }
    else if (drv_get_table_type(tbl_id) == DRV_TABLE_TYPE_TCAM_LPM_AD || drv_get_table_type(tbl_id) == DRV_TABLE_TYPE_TCAM_NAT_AD)
    {
        for (blk_id = 0; blk_id < MAX_LPM_TCAM_NUM; blk_id++)
        {
            DRV_IF_ERROR_RETURN(drv_get_tbl_index_base(tbl_id, index, &addr_offset));

            if (!IS_BIT_SET(TCAM_BITMAP(tbl_id), blk_id))
            {
                continue;
            }

            if ((index >= TCAM_START_INDEX(tbl_id, blk_id)) && (index <= TCAM_END_INDEX(tbl_id, blk_id)))
            {
                hw_data_base = TCAM_DATA_BASE(tbl_id, blk_id, addr_offset);
                map_index = index - TCAM_START_INDEX(tbl_id, blk_id);

                break;
            }
        }
        *hw_addr = hw_data_base + map_index * hw_addr_size_per_idx * DRV_BYTES_PER_WORD;
    }
    else
    {
        DRV_IF_ERROR_RETURN(drv_get_tbl_index_base(tbl_id, index, &addr_offset));
        hw_data_base = TABLE_DATA_BASE(tbl_id, addr_offset);

        if (TABLE_ENTRY_TYPE(tbl_id) == SLICE_Cascade)
        {
            if (index >= (TABLE_MAX_INDEX(tbl_id)/2))
            {
                map_index = index - (TABLE_MAX_INDEX(tbl_id)/2);
            }
            else
            {
                map_index = index;
            }
        }
        else
        {
            map_index = index;
        }

        *hw_addr = hw_data_base + map_index *hw_addr_size_per_idx*DRV_BYTES_PER_WORD;
    }

    return DRV_E_NONE;
}

/* Get hardware address according to tablid + index + data/mask flag (only tcam key) */
static int32
_drv_table_get_tcam_hw_addr(tbls_id_t tbl_id, uint32 index, uint32 *hw_addr, uint32 is_data)
{
    uint8 addr_offset = 0;
    uint32 blk_id = 0;
    uint32 addr_base = 0;
    uint32 map_index = 0;

    if (drv_get_table_type(tbl_id) == DRV_TABLE_TYPE_TCAM)
    {
        for (blk_id = 0; blk_id < MAX_NOR_TCAM_NUM; blk_id++)
        {
            DRV_IF_ERROR_RETURN(drv_get_tbl_index_base(tbl_id, index, &addr_offset));

            if (!IS_BIT_SET(TCAM_BITMAP(tbl_id), blk_id))
            {
                continue;
            }

            if ((index >= TCAM_START_INDEX(tbl_id, blk_id)) && (index <= TCAM_END_INDEX(tbl_id, blk_id)))
            {
                addr_base = is_data ? TCAM_DATA_BASE(tbl_id, blk_id, addr_offset) : TCAM_MASK_BASE(tbl_id, blk_id, addr_offset);
                map_index = index - TCAM_START_INDEX(tbl_id, blk_id);

                *hw_addr = addr_base + TCAM_KEY_SIZE(tbl_id)/DRV_BYTES_PER_ENTRY*DRV_ADDR_BYTES_PER_ENTRY* map_index;
                break;
            }
        }
    }
    else if ((drv_get_table_type(tbl_id) == DRV_TABLE_TYPE_LPM_TCAM_IP) || (drv_get_table_type(tbl_id) == DRV_TABLE_TYPE_LPM_TCAM_NAT))
    {
        for (blk_id = 0; blk_id < MAX_LPM_TCAM_NUM; blk_id++)
        {
            DRV_IF_ERROR_RETURN(drv_get_tbl_index_base(tbl_id, index, &addr_offset));

            if (!IS_BIT_SET(TCAM_BITMAP(tbl_id), blk_id))
            {
                continue;
            }

            if ((index >= TCAM_START_INDEX(tbl_id, blk_id)) && (index <= TCAM_END_INDEX(tbl_id, blk_id)))
            {
                addr_base = is_data ? TCAM_DATA_BASE(tbl_id, blk_id, addr_offset) : TCAM_MASK_BASE(tbl_id, blk_id, addr_offset);
                map_index = index - TCAM_START_INDEX(tbl_id, blk_id);

                *hw_addr = addr_base + TCAM_KEY_SIZE(tbl_id) * map_index;
                break;
            }
        }
    }
    else if(drv_get_table_type(tbl_id) == DRV_TABLE_TYPE_STATIC_TCAM_KEY)
    {
        if ((index >= TCAM_START_INDEX(tbl_id, 0)) && (index <= TCAM_END_INDEX(tbl_id, 0)))
        {
            addr_base = is_data ? TCAM_DATA_BASE(tbl_id, 0, 0) : TCAM_MASK_BASE(tbl_id, 0, 0);
            map_index = index;

            *hw_addr = addr_base + TCAM_KEY_SIZE(tbl_id) * map_index;
        }
    }
    else
    {
        DRV_DBG_INFO("ERROR!! tbl_id %d is not tcam key!\n", tbl_id);
        return DRV_E_INVALID_INDEX;
    }

    return DRV_E_NONE;
}

/* Get hardware address according to tablid + index
    flag: for tcam, 0-mask, 1-data
          for sram, 0-not dump, 1-dump
 */
int32
drv_table_get_hw_addr(tbls_id_t tbl_id, uint32 index, uint32 *hw_addr, uint32 flag)
{
    DRV_TBL_ID_VALID_CHECK(tbl_id);

    if ((drv_get_table_type(tbl_id) == DRV_TABLE_TYPE_TCAM) ||
        (drv_get_table_type(tbl_id) == DRV_TABLE_TYPE_LPM_TCAM_IP) ||
        (drv_get_table_type(tbl_id) == DRV_TABLE_TYPE_LPM_TCAM_NAT) ||
        (drv_get_table_type(tbl_id) == DRV_TABLE_TYPE_STATIC_TCAM_KEY))
    {
        DRV_IF_ERROR_RETURN(_drv_table_get_tcam_hw_addr(tbl_id, index, hw_addr, flag));
    }
    else
    {
        DRV_IF_ERROR_RETURN(_drv_table_get_sram_hw_addr(tbl_id, index, hw_addr, flag));
    }

    return DRV_E_NONE;
}

/**
  @driver get table type interface
*/
uint32
drv_get_table_type (tbls_id_t tb_id)
{
    uint32 type = 0;

    if (TABLE_EXT_INFO_PTR(tb_id))
    {
        type = TABLE_EXT_INFO_TYPE(tb_id);
    }
    else
    {
        type = DRV_TABLE_TYPE_NORMAL;
    }
    return type;
}

int8 drv_table_is_slice1(tbls_id_t tbl_id)
{
    return FALSE;
}

int8 drv_table_is_parser_tbl(tbls_id_t tbl_id)
{
    uint32 i =0 ;

    for(i =0; i < sizeof(parser_tbl_id_list)/sizeof(parser_tbl_id_list[0]); i++)
    {
        if(tbl_id == parser_tbl_id_list[i])
        {
            return TRUE;
        }
    }

    return FALSE;
}


/*
 @file drv_ftm.c

 @date 2011-11-16

 @version v2.0

 This file provides all sys alloc function
*/

#include "sal.h"
#include "drv_enum.h"
#include "drv_ftm.h"
#include "drv_common.h"
#include "drv_api.h"

#define DRV_FTM_REALLOC_TCAM 1


#if (SDK_WORK_PLATFORM == 1)
#include "cm_com_sdk.h"
#endif

#define DYNAMIC_SLICE0_ADDR_BASE_OFFSET_TO_DUP 0x60000000
#define DYNAMIC_SLICE1_ADDR_BASE_OFFSET_TO_DUP 0x40000000

int32 drv_set_tcam_lookup_bitmap(uint32 mem_id, uint32 bitmap);

#define DRV_FTM_DBG_OUT(fmt, args...)       sal_printf(fmt, ##args)
#define DRV_FTM_DBG_DUMP(fmt, args...)

#define   DRV_FTM_TBL_INFO(tbl_id)   g_ftm_master->p_sram_tbl_info[tbl_id]
#define   DRV_FTM_KEY_INFO(tbl_id)   g_ftm_master->p_tcam_key_info[tbl_id]
#define   DRV_FTM_MEM_INFO(mem_id)   drv_ftm_mem_info[mem_id]

#define DRV_FTM_TBL_ACCESS_FLAG(tbl_id)               DRV_FTM_TBL_INFO(tbl_id).access_flag
#define DRV_FTM_TBL_MAX_ENTRY_NUM(tbl_id)             DRV_FTM_TBL_INFO(tbl_id).max_entry_num
#define DRV_FTM_TBL_MEM_BITMAP(tbl_id)                DRV_FTM_TBL_INFO(tbl_id).mem_bitmap
#define DRV_FTM_TBL_MEM_START_OFFSET(tbl_id, mem_id)  DRV_FTM_TBL_INFO(tbl_id).mem_start_offset[mem_id]
#define DRV_FTM_TBL_MEM_ENTRY_NUM(tbl_id, mem_id)     DRV_FTM_TBL_INFO(tbl_id).mem_entry_num[mem_id]

#define DRV_FTM_TBL_BASE_BITMAP(tbl_id)      DRV_FTM_TBL_INFO(tbl_id).dyn_ds_base.bitmap
#define DRV_FTM_TBL_BASE_VAL(tbl_id, i)   DRV_FTM_TBL_INFO(tbl_id).dyn_ds_base.ds_dynamic_base[i]
#define DRV_FTM_TBL_BASE_MIN(tbl_id, i)   DRV_FTM_TBL_INFO(tbl_id).dyn_ds_base.ds_dynamic_min_index[i]
#define DRV_FTM_TBL_BASE_MAX(tbl_id, i)   DRV_FTM_TBL_INFO(tbl_id).dyn_ds_base.ds_dynamic_max_index[i]

#define DRV_FTM_MEM_ALLOCED_ENTRY_NUM(mem_id) DRV_FTM_MEM_INFO(mem_id) .allocated_entry_num
#define DRV_FTM_MEM_MAX_ENTRY_NUM(mem_id)     DRV_FTM_MEM_INFO(mem_id).max_mem_entry_num
#define DRV_FTM_MEM_HW_DATA_BASE(mem_id)      DRV_FTM_MEM_INFO(mem_id).hw_data_base_addr_4w
#define DRV_FTM_MEM_HW_DATA_BASE6W(mem_id)      DRV_FTM_MEM_INFO(mem_id).hw_data_base_addr_mask
#define DRV_FTM_MEM_HW_DATA_BASE12W(mem_id)      DRV_FTM_MEM_INFO(mem_id).hw_data_base_addr_12w
#define DRV_FTM_MEM_HW_MASK_BASE(mem_id)      DRV_FTM_MEM_INFO(mem_id).hw_data_base_addr_mask

#define DRV_FTM_KEY_MAX_INDEX(tbl_id)                  DRV_FTM_KEY_INFO(tbl_id).max_key_index
#define DRV_FTM_KEY_MEM_BITMAP(tbl_id)                 DRV_FTM_KEY_INFO(tbl_id).mem_bitmap
#define DRV_FTM_KEY_ENTRY_NUM(tbl_id, type, mem_id)                 DRV_FTM_KEY_INFO(tbl_id).entry_num[type][mem_id]
#define DRV_FTM_KEY_START_OFFSET(tbl_id, type, mem_id)                 DRV_FTM_KEY_INFO(tbl_id).start_offset[type][mem_id]

#define DRV_FTM_ADD_TABLE(mem_id, table, start, size) \
    do { \
        if (size) \
        { \
            DRV_FTM_TBL_MEM_BITMAP(table)               |= (1 << mem_id); \
            DRV_FTM_TBL_MAX_ENTRY_NUM(table)            += size; \
            DRV_FTM_TBL_MEM_START_OFFSET(table, mem_id) = start; \
            DRV_FTM_TBL_MEM_ENTRY_NUM(table, mem_id)    = size; \
        } \
    } while (0)


#define DRV_FTM_ADD_KEY(mem_id, table, start, size) \
    do { \
        if (size) \
        { \
            DRV_FTM_KEY_MEM_BITMAP(table)               |=  (1 << (mem_id-DRV_FTM_TCAM_KEY0)); \
            DRV_FTM_KEY_MAX_INDEX(table)                += size; \
        } \
    } while (0)

#define DRV_FTM_ADD_LPM_KEY(mem_id, table, start, size) \
    do { \
        if (size) \
        { \
            DRV_FTM_KEY_MEM_BITMAP(table)               |=  (1 << (mem_id-DRV_FTM_LPM_TCAM_KEY0)); \
            DRV_FTM_KEY_MAX_INDEX(table)                += size; \
        } \
    } while (0)

#define DRV_FTM_ADD_KEY_BYTYPE(mem_id, table, type, start, size) \
    do { \
        if (size) \
        { \
           DRV_FTM_KEY_START_OFFSET(table, type, mem_id - DRV_FTM_TCAM_KEY0)       = start; \
           DRV_FTM_KEY_ENTRY_NUM(table, type, mem_id - DRV_FTM_TCAM_KEY0)          = size; \
        } \
    } while (0)

#define DRV_FTM_ADD_LPM_KEY_BYTYPE(mem_id, table, type, start, size) \
    do { \
        if (size) \
        { \
           DRV_FTM_KEY_START_OFFSET(table, type, mem_id - DRV_FTM_LPM_TCAM_KEY0)       = start; \
           DRV_FTM_KEY_ENTRY_NUM(table, type, mem_id - DRV_FTM_LPM_TCAM_KEY0)          = size; \
        } \
    } while (0)


#define DRV_FTM_ADD_FULL_TABLE(mem_id, table) \
        do {\
            uint32 couple = 0;\
            drv_get_dynamic_ram_couple_mode(&couple);\
            if (couple) \
            {\
                DRV_FTM_ADD_TABLE(mem_id, table, 0, (DRV_FTM_MEM_MAX_ENTRY_NUM(mem_id)*2));\
            } else {\
                DRV_FTM_ADD_TABLE(mem_id, table, 0, DRV_FTM_MEM_MAX_ENTRY_NUM(mem_id));    \
            }\
        } while (0)


#define ENTRY_NUM entry_num

#define DRV_FTM_ADD_FULL_KEY(mem_id, table) \
        do { \
            uint32 couple = 0;\
            uint32 entry_num = DRV_FTM_MEM_MAX_ENTRY_NUM(mem_id);\
            drv_get_dynamic_ram_couple_mode(&couple);\
            if (couple) \
            {\
                entry_num = (ENTRY_NUM*2);\
            } else {\
                entry_num = ENTRY_NUM;\
            }\
            DRV_FTM_ADD_KEY(mem_id, table, 0, entry_num);\
            DRV_FTM_ADD_KEY_BYTYPE(mem_id, table, DRV_FTM_TCAM_SIZE_80,  0,                 1 * (entry_num/4)); \
            DRV_FTM_ADD_KEY_BYTYPE(mem_id, table, DRV_FTM_TCAM_SIZE_160, 1 * (entry_num/4), 1 * (entry_num/4)); \
            DRV_FTM_ADD_KEY_BYTYPE(mem_id, table, DRV_FTM_TCAM_SIZE_320, 2 * (entry_num/4), 1 * (entry_num/4)); \
            DRV_FTM_ADD_KEY_BYTYPE(mem_id, table, DRV_FTM_TCAM_SIZE_640, 3 * (entry_num/4), 1 * (entry_num/4)); \
       } while (0)

/* single/double 2 chose 1 */
#define DRV_FTM_ADD_LPM0_KEY(mem_id, table)                                                             \
    do {                                                                                                \
        uint32 couple = 0;                                                                              \
        uint32 entry_num = DRV_FTM_MEM_MAX_ENTRY_NUM(mem_id);                                           \
        drv_get_dynamic_ram_couple_mode(&couple);                                                       \
        if (couple)                                                                                     \
        {                                                                                               \
            entry_num = (ENTRY_NUM*2);                                                                  \
        } else {                                                                                        \
            entry_num = ENTRY_NUM;                                                                      \
        }                                                                                               \
        DRV_FTM_ADD_LPM_KEY(mem_id, table, 0, entry_num);                                               \
        DRV_FTM_ADD_LPM_KEY_BYTYPE(mem_id, table, DRV_FTM_TCAM_SIZE_halfkey,   0,                 1 * (entry_num/2)); \
        DRV_FTM_ADD_LPM_KEY_BYTYPE(mem_id, table, DRV_FTM_TCAM_SIZE_doublekey, 1 * (entry_num/2), 1 * (entry_num/2)); \
        DRV_FTM_ADD_LPM_KEY_BYTYPE(mem_id, table, DRV_FTM_TCAM_SIZE_singlekey, 1 * (entry_num/2), 1 * (entry_num/2)); \
     } while (0)


#define DRV_FTM_ADD_LPM1_KEY(mem_id, table) \
        do { \
            uint32 couple = 0;\
            uint32 entry_num = DRV_FTM_MEM_MAX_ENTRY_NUM(mem_id);\
            drv_get_dynamic_ram_couple_mode(&couple);\
            if (couple) \
            {\
                entry_num = (ENTRY_NUM*2);\
            } else {\
                entry_num = ENTRY_NUM;\
            }\
            DRV_FTM_ADD_LPM_KEY(mem_id, table, 0, entry_num);\
            DRV_FTM_ADD_LPM_KEY_BYTYPE(mem_id, table, DRV_FTM_TCAM_SIZE_ipv4_nat, entry_num*0/4, entry_num/4); \
            DRV_FTM_ADD_LPM_KEY_BYTYPE(mem_id, table, DRV_FTM_TCAM_SIZE_ipv4_pbr, entry_num*1/4, entry_num/4); \
            DRV_FTM_ADD_LPM_KEY_BYTYPE(mem_id, table, DRV_FTM_TCAM_SIZE_ipv6_nat, entry_num*2/4, entry_num/4); \
            DRV_FTM_ADD_LPM_KEY_BYTYPE(mem_id, table, DRV_FTM_TCAM_SIZE_ipv6_pbr, entry_num*3/4, entry_num/4); \
     } while (0)


enum drv_ftm_module_s
{
    TCAM_MODULE_NONE = 0,
    TCAM_MODULE_ACL = 1,
    TCAM_MODULE_SCL = 2,
    TCAM_MODULE_LPM = 3,
};

enum drv_ftm_tcam_key_type_e
{
    DRV_FTM_TCAM_TYPE_IGS_ACL0,
    DRV_FTM_TCAM_TYPE_IGS_ACL1,
    DRV_FTM_TCAM_TYPE_IGS_ACL2,
    DRV_FTM_TCAM_TYPE_IGS_ACL3,
    DRV_FTM_TCAM_TYPE_IGS_ACL4,
    DRV_FTM_TCAM_TYPE_IGS_ACL5,
    DRV_FTM_TCAM_TYPE_IGS_ACL6,
    DRV_FTM_TCAM_TYPE_IGS_ACL7,

    DRV_FTM_TCAM_TYPE_EGS_ACL0,
    DRV_FTM_TCAM_TYPE_EGS_ACL1,
    DRV_FTM_TCAM_TYPE_EGS_ACL2,
    DRV_FTM_TCAM_TYPE_IGS_USERID0,
    DRV_FTM_TCAM_TYPE_IGS_USERID1,

    DRV_FTM_TCAM_TYPE_IGS_LPM0_ALL,
    DRV_FTM_TCAM_TYPE_IGS_LPM0_PUB_ALL,

    DRV_FTM_TCAM_TYPE_IGS_LPM0,             /* private ipda && private ipda/ipsa */
    DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI,        /* private ipsa */
    DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB,        /* public ipda && public ipda/ipsa */
    DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB,        /* public ipsa */

    DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2,         /* private ipda && private ipda/ipsa */
    DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI_LK2,    /* private ipsa */
    DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2,    /* public ipda && public ipda/ipsa */
    DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB_LK2,    /* public ipsa */

    DRV_FTM_TCAM_TYPE_IGS_LPM1,

    DRV_FTM_TCAM_TYPE_STATIC_TCAM,
    DRV_FTM_TCAM_TYPE_MAX
};
typedef enum drv_ftm_tcam_key_type_e drv_ftm_tcam_key_type_t;

enum drv_ftm_sram_tbl_type_e
{
    DRV_FTM_SRAM_TBL_FIB0_HASH_KEY,
    DRV_FTM_SRAM_TBL_FIB1_HASH_KEY,
    DRV_FTM_SRAM_TBL_FLOW_HASH_KEY,
    DRV_FTM_SRAM_TBL_IPFIX_HASH_KEY,
    DRV_FTM_SRAM_TBL_USERID_HASH_KEY,
    DRV_FTM_SRAM_TBL_XCOAM_HASH_KEY,

    DRV_FTM_SRAM_TBL_LPM_LKP_KEY,

    DRV_FTM_SRAM_TBL_DSMAC_AD,
    DRV_FTM_SRAM_TBL_DSIP_AD,
    DRV_FTM_SRAM_TBL_FLOW_AD,
    DRV_FTM_SRAM_TBL_IPFIX_AD,
    DRV_FTM_SRAM_TBL_USERID_AD,

    DRV_FTM_SRAM_TBL_NEXTHOP,
    DRV_FTM_SRAM_TBL_FWD,
    DRV_FTM_SRAM_TBL_MET,
    DRV_FTM_SRAM_TBL_EDIT,

    DRV_FTM_SRAM_TBL_OAM_APS,
    DRV_FTM_SRAM_TBL_OAM_LM,
    DRV_FTM_SRAM_TBL_OAM_MEP,
    DRV_FTM_SRAM_TBL_OAM_MA,
    DRV_FTM_SRAM_TBL_OAM_MA_NAME,

    DRV_FTM_SRAM_TBL_MAX
};
typedef enum drv_ftm_sram_tbl_type_e drv_ftm_sram_tbl_type_t;

enum drv_ftm_dyn_cam_type_e
{
    DRV_FTM_DYN_CAM_TYPE_LPM_KEY,
    DRV_FTM_DYN_CAM_TYPE_FIB_MACHOST0_KEY,
    DRV_FTM_DYN_CAM_TYPE_FIB_MACHOST1_KEY,
    DRV_FTM_DYN_CAM_TYPE_FIB_FLOW_KEY,
    DRV_FTM_DYN_CAM_TYPE_FIB_FLOW_AD,
    DRV_FTM_DYN_CAM_TYPE_USERID_HASH_KEY,
    DRV_FTM_DYN_CAM_TYPE_USERID_HASH_AD,

    DRV_FTM_DYN_CAM_TYPE_EGRESS_OAM_HASH_KEY,

    DRV_FTM_DYN_CAM_TYPE_IP_FIX_HASH_KEY,
    DRV_FTM_DYN_CAM_TYPE_IP_FIX_HASH_AD,
    DRV_FTM_DYN_CAM_TYPE_FIB_L2_AD,
    DRV_FTM_DYN_CAM_TYPE_FIB_L3_AD,
    DRV_FTM_DYN_CAM_TYPE_DS_LM,
    DRV_FTM_DYN_CAM_TYPE_DS_APS,
    DRV_FTM_DYN_CAM_TYPE_DS_MEP,
    DRV_FTM_DYN_CAM_TYPE_DS_MA,
    DRV_FTM_DYN_CAM_TYPE_DS_MANAME,
    DRV_FTM_DYN_CAM_TYPE_DS_EDIT,
    DRV_FTM_DYN_CAM_TYPE_DS_NEXTHOP,
    DRV_FTM_DYN_CAM_TYPE_DS_MET,
    DRV_FTM_DYN_CAM_TYPE_DS_FWD,
    DRV_FTM_DYN_CAM_TYPE_MAX
};
typedef enum drv_ftm_dyn_cam_type_e drv_ftm_dyn_cam_type_t;

#define DRV_FTM_UNIT_1K 10
#define DRV_FTM_UNIT_8K 13
#define DRV_FTM_FLD_INVALID 0xFFFFFFFF

#define DRV_FTM_MAX_MEM_NUM 5

struct drv_ftm_dyn_ds_base_s
{
    uint32 bitmap;
    uint32 ds_dynamic_base[DRV_FTM_MAX_MEM_NUM];
    uint32 ds_dynamic_max_index[DRV_FTM_MAX_MEM_NUM];
    uint32 ds_dynamic_min_index[DRV_FTM_MAX_MEM_NUM];
};
typedef struct drv_ftm_dyn_ds_base_s drv_ftm_dyn_ds_base_t;

struct drv_ftm_sram_tbl_info_s
{
    uint32 access_flag; /*judge weather tbl share alloc*/
    uint32 mem_bitmap;
    uint32 max_entry_num;
    uint32 mem_start_offset[DRV_FTM_SRAM_MAX];
    uint32 mem_entry_num[DRV_FTM_SRAM_MAX];
    drv_ftm_dyn_ds_base_t dyn_ds_base;
};
typedef struct drv_ftm_sram_tbl_info_s drv_ftm_sram_tbl_info_t;

#define BYTE_TO_4W  12

#define DRV_FTM_TCAM_SIZE_80  0
#define DRV_FTM_TCAM_SIZE_160 1
#define DRV_FTM_TCAM_SIZE_320 2
#define DRV_FTM_TCAM_SIZE_640 3

#define DRV_FTM_TCAM_SIZE_ipv4_pbr 0
#define DRV_FTM_TCAM_SIZE_ipv6_pbr 1
#define DRV_FTM_TCAM_SIZE_ipv4_nat 2
#define DRV_FTM_TCAM_SIZE_ipv6_nat 3

#define DRV_FTM_TCAM_SIZE_halfkey   0
#define DRV_FTM_TCAM_SIZE_singlekey 1
#define DRV_FTM_TCAM_SIZE_doublekey 2

#define DRV_FTM_TCAM_SIZE_LPMhalf   0
#define DRV_FTM_TCAM_SIZE_LPMSingle 1
#define DRV_FTM_TCAM_SIZE_LPMDouble 2

#define DRV_FTM_TCAM_SIZE_MAX 4



#define DRV_FTM_CAM_CHECK_TBL_VALID(cam_type, tbl_id)\
    if ((DRV_FTM_CAM_TYPE_FIB_HOST1_NAT == cam_type)\
        && (DsFibHost1Ipv4NatDaPortHashKey_t != tbl_id))\
    {\
        return DRV_E_HASH_CONFLICT;\
    }

struct drv_ftm_tcam_key_info_s
{
    uint32 mem_bitmap;
    uint32  max_key_index;
    uint32 entry_num[DRV_FTM_TCAM_SIZE_MAX][DRV_FTM_MAX_ID];
    uint32 start_offset[DRV_FTM_TCAM_SIZE_MAX][DRV_FTM_MAX_ID];
};
typedef struct drv_ftm_tcam_key_info_s drv_ftm_tcam_key_info_t;


struct g_ftm_master_s
{
    drv_ftm_sram_tbl_info_t* p_sram_tbl_info;
    drv_ftm_tcam_key_info_t* p_tcam_key_info;

    uint16  int_tcam_used_entry;
    uint8   lpm_model;
    uint8   nat_pbr_enable;
    uint8   lookup_div;

    uint16 tcam_specs[DRV_FTM_TCAM_TYPE_MAX][4];
    uint16 tcam_offset[DRV_FTM_TCAM_TYPE_MAX][4];


    /*cam*/
    uint8 cfg_max_cam_num[DRV_FTM_CAM_TYPE_MAX];
    uint8 conflict_cam_num[DRV_FTM_CAM_TYPE_MAX];

    /*cam bitmap*/
    uint32 fib1_cam_bitmap0[1];     /*single*/
    uint32 fib1_cam_bitmap1[1];     /*dual*/
    uint32 fib1_cam_bitmap2[1];     /*quad*/

    uint32 userid_cam_bitmap0[1];   /*single*/
    uint32 userid_cam_bitmap1[1];   /*dual*/
    uint32 userid_cam_bitmap2[1];   /*quad*/

    uint32 xcoam_cam_bitmap0[4];    /*single*/
    uint32 xcoam_cam_bitmap1[4];    /*dual*/
    uint32 xcoam_cam_bitmap2[4];    /*quad*/

    uint32 cam_bitmap;
    uint32 host1_poly_type;
};
typedef struct g_ftm_master_s g_ftm_master_t;

g_ftm_master_t* g_ftm_master = NULL;


struct drv_ftm_mem_allo_info_s
{
    char   mem_name[128];
    uint32 allocated_entry_num;            /* entry size is always 72/80 */
    uint32 max_mem_entry_num;
    uint32 hw_data_base_addr_4w;     /* to dynic memory and TcamAd memory, is 4word mode base address */
    uint32 hw_data_base_addr_mask; /*union of 6w*/
    uint32 hw_data_base_addr_12w;
};
typedef struct drv_ftm_mem_allo_info_s drv_ftm_mem_allo_info_t;

#define DRV_BIT_SET(flag, bit)      ((flag) = (flag) | (1 << (bit)))

static drv_ftm_mem_allo_info_t drv_ftm_mem_info[DRV_FTM_MAX_ID] =
{
{"KeyRam0",0, DRV_KEY_RAM0_MAX_ENTRY_NUM, DRV_KEY_RAM0_BASE_4W, DRV_KEY_RAM0_BASE_6W, DRV_KEY_RAM0_BASE_12W},/*CM_MEMORY0*/
{"KeyRam1",0, DRV_KEY_RAM1_MAX_ENTRY_NUM, DRV_KEY_RAM1_BASE_4W, DRV_KEY_RAM1_BASE_6W, DRV_KEY_RAM1_BASE_12W},/*CM_MEMORY1*/
{"KeyRam2",0, DRV_KEY_RAM2_MAX_ENTRY_NUM, DRV_KEY_RAM2_BASE_4W, DRV_KEY_RAM2_BASE_6W, DRV_KEY_RAM2_BASE_12W},/*CM_MEMORY2*/
{"KeyRam3",0, DRV_KEY_RAM3_MAX_ENTRY_NUM, DRV_KEY_RAM3_BASE_4W, DRV_KEY_RAM3_BASE_6W, DRV_KEY_RAM3_BASE_12W},/*CM_MEMORY3*/
{"KeyRam4",0, DRV_KEY_RAM4_MAX_ENTRY_NUM, DRV_KEY_RAM4_BASE_4W, DRV_KEY_RAM4_BASE_6W, DRV_KEY_RAM4_BASE_12W},/*CM_MEMORY4*/
{"KeyRam5",0, DRV_KEY_RAM5_MAX_ENTRY_NUM, DRV_KEY_RAM5_BASE_4W, DRV_KEY_RAM5_BASE_6W, DRV_KEY_RAM5_BASE_12W},/*CM_MEMORY5*/

{"KeyRam6",0, DRV_KEY_RAM6_MAX_ENTRY_NUM, DRV_KEY_RAM6_BASE_4W, DRV_KEY_RAM6_BASE_6W, DRV_KEY_RAM6_BASE_12W},/*CM_MEMORY6*/
{"KeyRam7",0, DRV_KEY_RAM7_MAX_ENTRY_NUM, DRV_KEY_RAM7_BASE_4W, DRV_KEY_RAM7_BASE_6W, DRV_KEY_RAM7_BASE_12W},/*CM_MEMORY7*/
{"KeyRam8",0, DRV_KEY_RAM8_MAX_ENTRY_NUM, DRV_KEY_RAM8_BASE_4W, DRV_KEY_RAM8_BASE_6W, DRV_KEY_RAM8_BASE_12W},/*CM_MEMORY8*/
{"KeyRam9",0, DRV_KEY_RAM9_MAX_ENTRY_NUM, DRV_KEY_RAM9_BASE_4W, DRV_KEY_RAM9_BASE_6W, DRV_KEY_RAM9_BASE_12W},/*CM_MEMORY8*/
{"KeyRam10",0, DRV_KEY_RAM10_MAX_ENTRY_NUM, DRV_KEY_RAM10_BASE_4W, DRV_KEY_RAM10_BASE_6W, DRV_KEY_RAM10_BASE_12W},/*CM_MEMORY8*/

{"AdRam0",0, DRV_AD_RAM0_MAX_ENTRY_NUM, DRV_AD_RAM0_BASE_4W, DRV_AD_RAM0_BASE_6W, DRV_AD_RAM0_BASE_12W},/*CM_MEMORY0*/
{"AdRam1",0, DRV_AD_RAM1_MAX_ENTRY_NUM, DRV_AD_RAM1_BASE_4W, DRV_AD_RAM1_BASE_6W, DRV_AD_RAM1_BASE_12W},/*CM_MEMORY1*/
{"AdRam2",0, DRV_AD_RAM2_MAX_ENTRY_NUM, DRV_AD_RAM2_BASE_4W, DRV_AD_RAM2_BASE_6W, DRV_AD_RAM2_BASE_12W},/*CM_MEMORY2*/
{"AdRam3",0, DRV_AD_RAM3_MAX_ENTRY_NUM, DRV_AD_RAM3_BASE_4W, DRV_AD_RAM3_BASE_6W, DRV_AD_RAM3_BASE_12W},/*CM_MEMORY3*/
{"AdRam4",0, DRV_AD_RAM4_MAX_ENTRY_NUM, DRV_AD_RAM4_BASE_4W, DRV_AD_RAM4_BASE_6W, DRV_AD_RAM4_BASE_12W},/*CM_MEMORY4*/

{"EditRam0",0, DRV_EDIT_RAM0_MAX_ENTRY_NUM, DRV_EDIT_RAM0_BASE_4W, DRV_EDIT_RAM0_BASE_6W, DRV_EDIT_RAM0_BASE_12W},/*CM_MEMORY0*/
{"EditRam1",0, DRV_EDIT_RAM1_MAX_ENTRY_NUM, DRV_EDIT_RAM1_BASE_4W, DRV_EDIT_RAM1_BASE_6W, DRV_EDIT_RAM1_BASE_12W},/*CM_MEMORY1*/
{"EditRam2",0, DRV_EDIT_RAM2_MAX_ENTRY_NUM, DRV_EDIT_RAM2_BASE_4W, DRV_EDIT_RAM2_BASE_6W, DRV_EDIT_RAM2_BASE_12W},/*CM_MEMORY2*/
{"EditRam3",0, DRV_EDIT_RAM3_MAX_ENTRY_NUM, DRV_EDIT_RAM3_BASE_4W, DRV_EDIT_RAM3_BASE_6W, DRV_EDIT_RAM3_BASE_12W},/*CM_MEMORY3*/
{"EditRam4",0, DRV_EDIT_RAM4_MAX_ENTRY_NUM, DRV_EDIT_RAM4_BASE_4W, DRV_EDIT_RAM4_BASE_6W, DRV_EDIT_RAM4_BASE_12W},/*CM_MEMORY4*/
{"EditRam5",0, DRV_EDIT_RAM5_MAX_ENTRY_NUM, DRV_EDIT_RAM5_BASE_4W, DRV_EDIT_RAM5_BASE_6W, DRV_EDIT_RAM5_BASE_12W},/*CM_MEMORY4*/

{"PolicerCounterRam0",0, DRV_POLICERCOUNTERRAM0_MAX_ENTRY_NUM, DRV_POLICERCOUNTERRAM0_BASE_4W, DRV_POLICERCOUNTERRAM0_BASE_6W, DRV_POLICERCOUNTERRAM0_BASE_12W},/*CM_MEMORY8*/
{"PolicerCounterRam1",0, DRV_POLICERCOUNTERRAM1_MAX_ENTRY_NUM, DRV_POLICERCOUNTERRAM1_BASE_4W, DRV_POLICERCOUNTERRAM1_BASE_6W, DRV_POLICERCOUNTERRAM1_BASE_12W},/*CM_MEMORY8*/
{"",0,0,0,0,0},

{"Tcam key0", 0, DRV_TCAM_KEY0_MAX_ENTRY_NUM, DRV_TCAM_KEY0_BASE_4W, DRV_TCAM_MASK0_BASE_4W, 0},/*CM_TCAM_KEY*/
{"Tcam key1", 0, DRV_TCAM_KEY1_MAX_ENTRY_NUM, DRV_TCAM_KEY1_BASE_4W, DRV_TCAM_MASK1_BASE_4W, 0},/*CM_TCAM_KEY*/
{"Tcam key2", 0, DRV_TCAM_KEY2_MAX_ENTRY_NUM, DRV_TCAM_KEY2_BASE_4W, DRV_TCAM_MASK2_BASE_4W, 0},/*CM_TCAM_KEY*/
{"Tcam key3", 0, DRV_TCAM_KEY3_MAX_ENTRY_NUM, DRV_TCAM_KEY3_BASE_4W, DRV_TCAM_MASK3_BASE_4W, 0},/*CM_TCAM_KEY*/
{"Tcam key4", 0, DRV_TCAM_KEY4_MAX_ENTRY_NUM, DRV_TCAM_KEY4_BASE_4W, DRV_TCAM_MASK4_BASE_4W, 0},/*CM_TCAM_KEY*/
{"Tcam key5", 0, DRV_TCAM_KEY5_MAX_ENTRY_NUM, DRV_TCAM_KEY5_BASE_4W, DRV_TCAM_MASK5_BASE_4W, 0},/*CM_TCAM_KEY*/
{"Tcam key6", 0, DRV_TCAM_KEY6_MAX_ENTRY_NUM, DRV_TCAM_KEY6_BASE_4W, DRV_TCAM_MASK6_BASE_4W, 0},/*CM_TCAM_KEY*/
{"Tcam key7", 0, DRV_TCAM_KEY7_MAX_ENTRY_NUM, DRV_TCAM_KEY7_BASE_4W, DRV_TCAM_MASK7_BASE_4W, 0},/*CM_TCAM_KEY*/
{"Tcam key8", 0, DRV_TCAM_KEY8_MAX_ENTRY_NUM, DRV_TCAM_KEY8_BASE_4W, DRV_TCAM_MASK8_BASE_4W, 0},/*CM_TCAM_KEY*/
{"Tcam key9", 0, DRV_TCAM_KEY9_MAX_ENTRY_NUM, DRV_TCAM_KEY9_BASE_4W, DRV_TCAM_MASK9_BASE_4W, 0},/*CM_TCAM_KEY*/
{"Tcam key10", 0, DRV_TCAM_KEY10_MAX_ENTRY_NUM, DRV_TCAM_KEY10_BASE_4W, DRV_TCAM_MASK10_BASE_4W, 0},/*CM_TCAM_KEY*/
{"Tcam key11", 0, DRV_TCAM_KEY11_MAX_ENTRY_NUM, DRV_TCAM_KEY11_BASE_4W, DRV_TCAM_MASK11_BASE_4W, 0},/*CM_TCAM_KEY*/
{"Tcam key12", 0, DRV_TCAM_KEY12_MAX_ENTRY_NUM, DRV_TCAM_KEY12_BASE_4W, DRV_TCAM_MASK12_BASE_4W, 0},/*CM_TCAM_KEY*/
{"Tcam key13", 0, DRV_TCAM_KEY13_MAX_ENTRY_NUM, DRV_TCAM_KEY13_BASE_4W, DRV_TCAM_MASK13_BASE_4W, 0},/*CM_TCAM_KEY*/
{"Tcam key14", 0, DRV_TCAM_KEY14_MAX_ENTRY_NUM, DRV_TCAM_KEY14_BASE_4W, DRV_TCAM_MASK14_BASE_4W, 0},/*CM_TCAM_KEY*/
{"Tcam key15", 0, DRV_TCAM_KEY15_MAX_ENTRY_NUM, DRV_TCAM_KEY15_BASE_4W, DRV_TCAM_MASK15_BASE_4W, 0},/*CM_TCAM_KEY*/
//-{"Tcam key16", 0, DRV_TCAM_KEY16_MAX_ENTRY_NUM, DRV_TCAM_KEY16_BASE_4W, DRV_TCAM_MASK16_BASE_4W, 0},/*CM_TCAM_KEY*/
{"",0,0,0,0,0},

{"Tcam AD0",  0, DRV_TCAM_AD0_MAX_ENTRY_NUM, DRV_TCAM_AD0_BASE_4W, DRV_TCAM_AD0_BASE_4W, DRV_TCAM_AD0_BASE_4W},/*CM_TCAM_AD*/
{"Tcam AD1",  0, DRV_TCAM_AD1_MAX_ENTRY_NUM, DRV_TCAM_AD1_BASE_4W, DRV_TCAM_AD1_BASE_4W, DRV_TCAM_AD1_BASE_4W},/*CM_TCAM_AD*/
{"Tcam AD2",  0, DRV_TCAM_AD2_MAX_ENTRY_NUM, DRV_TCAM_AD2_BASE_4W, DRV_TCAM_AD2_BASE_4W, DRV_TCAM_AD2_BASE_4W},/*CM_TCAM_AD*/
{"Tcam AD3",  0, DRV_TCAM_AD3_MAX_ENTRY_NUM, DRV_TCAM_AD3_BASE_4W, DRV_TCAM_AD3_BASE_4W, DRV_TCAM_AD3_BASE_4W},/*CM_TCAM_AD*/
{"Tcam AD4",  0, DRV_TCAM_AD4_MAX_ENTRY_NUM, DRV_TCAM_AD4_BASE_4W, DRV_TCAM_AD4_BASE_4W, DRV_TCAM_AD4_BASE_4W},/*CM_TCAM_AD*/
{"Tcam AD5",  0, DRV_TCAM_AD5_MAX_ENTRY_NUM, DRV_TCAM_AD5_BASE_4W, DRV_TCAM_AD5_BASE_4W, DRV_TCAM_AD5_BASE_4W},/*CM_TCAM_AD*/
{"Tcam AD6",  0, DRV_TCAM_AD6_MAX_ENTRY_NUM, DRV_TCAM_AD6_BASE_4W, DRV_TCAM_AD6_BASE_4W, DRV_TCAM_AD6_BASE_4W},/*CM_TCAM_AD*/
{"Tcam AD7",  0, DRV_TCAM_AD7_MAX_ENTRY_NUM, DRV_TCAM_AD7_BASE_4W, DRV_TCAM_AD7_BASE_4W, DRV_TCAM_AD7_BASE_4W},/*CM_TCAM_AD*/
{"Tcam AD8",  0, DRV_TCAM_AD8_MAX_ENTRY_NUM, DRV_TCAM_AD8_BASE_4W, DRV_TCAM_AD8_BASE_4W, DRV_TCAM_AD8_BASE_4W},/*CM_TCAM_AD*/
{"Tcam AD9",  0, DRV_TCAM_AD9_MAX_ENTRY_NUM, DRV_TCAM_AD9_BASE_4W, DRV_TCAM_AD9_BASE_4W, DRV_TCAM_AD9_BASE_4W},/*CM_TCAM_AD*/
{"Tcam AD10",  0, DRV_TCAM_AD10_MAX_ENTRY_NUM, DRV_TCAM_AD10_BASE_4W, DRV_TCAM_AD10_BASE_4W, DRV_TCAM_AD10_BASE_4W},/*CM_TCAM_AD*/
{"Tcam AD11",  0, DRV_TCAM_AD11_MAX_ENTRY_NUM, DRV_TCAM_AD11_BASE_4W, DRV_TCAM_AD11_BASE_4W, DRV_TCAM_AD11_BASE_4W},/*CM_TCAM_AD*/
{"Tcam AD12",  0, DRV_TCAM_AD12_MAX_ENTRY_NUM, DRV_TCAM_AD12_BASE_4W, DRV_TCAM_AD12_BASE_4W, DRV_TCAM_AD12_BASE_4W},/*CM_TCAM_AD*/
{"Tcam AD13",  0, DRV_TCAM_AD13_MAX_ENTRY_NUM, DRV_TCAM_AD13_BASE_4W, DRV_TCAM_AD13_BASE_4W, DRV_TCAM_AD13_BASE_4W},/*CM_TCAM_AD*/
{"Tcam AD14",  0, DRV_TCAM_AD14_MAX_ENTRY_NUM, DRV_TCAM_AD14_BASE_4W, DRV_TCAM_AD14_BASE_4W, DRV_TCAM_AD14_BASE_4W},/*CM_TCAM_AD*/
{"Tcam AD15",  0, DRV_TCAM_AD15_MAX_ENTRY_NUM, DRV_TCAM_AD15_BASE_4W, DRV_TCAM_AD15_BASE_4W, DRV_TCAM_AD15_BASE_4W},/*CM_TCAM_AD*/
//-{"Tcam AD16",  0, DRV_TCAM_AD16_MAX_ENTRY_NUM, DRV_TCAM_AD16_BASE_4W, DRV_TCAM_AD16_BASE_4W, DRV_TCAM_AD16_BASE_4W},/*CM_TCAM_AD*/
{"",0,0,0,0,0},

#if (0 == SDK_WORK_PLATFORM)
{"LPM Tcam key0", 0, 64, DRV_LPM_TCAM_KEY0_BASE_4W, DRV_LPM_TCAM_MASK0_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key1", 0, 64, DRV_LPM_TCAM_KEY1_BASE_4W, DRV_LPM_TCAM_MASK1_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key2", 0, 64, DRV_LPM_TCAM_KEY2_BASE_4W, DRV_LPM_TCAM_MASK2_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key3", 0, 64, DRV_LPM_TCAM_KEY3_BASE_4W, DRV_LPM_TCAM_MASK3_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key4", 0, 64, DRV_LPM_TCAM_KEY4_BASE_4W, DRV_LPM_TCAM_MASK4_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key5", 0, 64, DRV_LPM_TCAM_KEY5_BASE_4W, DRV_LPM_TCAM_MASK5_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key6", 0, 64, DRV_LPM_TCAM_KEY6_BASE_4W, DRV_LPM_TCAM_MASK6_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key7", 0, 64, DRV_LPM_TCAM_KEY7_BASE_4W, DRV_LPM_TCAM_MASK7_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key8", 0, 64, DRV_LPM_TCAM_KEY8_BASE_4W, DRV_LPM_TCAM_MASK8_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key9", 0, 64, DRV_LPM_TCAM_KEY9_BASE_4W, DRV_LPM_TCAM_MASK9_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key10", 0, 64, DRV_LPM_TCAM_KEY10_BASE_4W, DRV_LPM_TCAM_MASK10_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key11", 0, 64, DRV_LPM_TCAM_KEY11_BASE_4W, DRV_LPM_TCAM_MASK11_BASE_4W, 0},/* LPM TCAM KEY */
{"",0,0,0,0,0},

{"LPM Tcam Ad0", 0, 64, DRV_LPM_TCAM_AD0_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad1", 0, 64, DRV_LPM_TCAM_AD1_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad2", 0, 64, DRV_LPM_TCAM_AD2_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad3", 0, 64, DRV_LPM_TCAM_AD3_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad4", 0, 64, DRV_LPM_TCAM_AD4_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad5", 0, 64, DRV_LPM_TCAM_AD5_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad6", 0, 64, DRV_LPM_TCAM_AD6_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad7", 0, 64, DRV_LPM_TCAM_AD7_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad8", 0, 64, DRV_LPM_TCAM_AD8_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad9", 0, 64, DRV_LPM_TCAM_AD9_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad10", 0, 64, DRV_LPM_TCAM_AD10_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad11", 0, 64, DRV_LPM_TCAM_AD11_BASE_4W, 0, 0},/* LPM TCAM AD */
{"",0,0,0,0,0},
};
#else
{"LPM Tcam key0", 0, DRV_LPM_TCAM_KEY0_MAX_ENTRY_NUM, DRV_LPM_TCAM_KEY0_BASE_4W, DRV_LPM_TCAM_MASK0_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key1", 0, DRV_LPM_TCAM_KEY1_MAX_ENTRY_NUM, DRV_LPM_TCAM_KEY1_BASE_4W, DRV_LPM_TCAM_MASK1_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key2", 0, DRV_LPM_TCAM_KEY2_MAX_ENTRY_NUM, DRV_LPM_TCAM_KEY2_BASE_4W, DRV_LPM_TCAM_MASK2_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key3", 0, DRV_LPM_TCAM_KEY3_MAX_ENTRY_NUM, DRV_LPM_TCAM_KEY3_BASE_4W, DRV_LPM_TCAM_MASK3_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key4", 0, DRV_LPM_TCAM_KEY4_MAX_ENTRY_NUM, DRV_LPM_TCAM_KEY4_BASE_4W, DRV_LPM_TCAM_MASK4_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key5", 0, DRV_LPM_TCAM_KEY5_MAX_ENTRY_NUM, DRV_LPM_TCAM_KEY5_BASE_4W, DRV_LPM_TCAM_MASK5_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key6", 0, DRV_LPM_TCAM_KEY6_MAX_ENTRY_NUM, DRV_LPM_TCAM_KEY6_BASE_4W, DRV_LPM_TCAM_MASK6_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key7", 0, DRV_LPM_TCAM_KEY7_MAX_ENTRY_NUM, DRV_LPM_TCAM_KEY7_BASE_4W, DRV_LPM_TCAM_MASK7_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key8", 0, DRV_LPM_TCAM_KEY8_MAX_ENTRY_NUM, DRV_LPM_TCAM_KEY8_BASE_4W, DRV_LPM_TCAM_MASK8_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key9", 0, DRV_LPM_TCAM_KEY9_MAX_ENTRY_NUM, DRV_LPM_TCAM_KEY9_BASE_4W, DRV_LPM_TCAM_MASK9_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key10", 0, DRV_LPM_TCAM_KEY10_MAX_ENTRY_NUM, DRV_LPM_TCAM_KEY10_BASE_4W, DRV_LPM_TCAM_MASK10_BASE_4W, 0},/* LPM TCAM KEY */
{"LPM Tcam key11", 0, DRV_LPM_TCAM_KEY11_MAX_ENTRY_NUM, DRV_LPM_TCAM_KEY11_BASE_4W, DRV_LPM_TCAM_MASK11_BASE_4W, 0},/* LPM TCAM KEY */
{"",0,0,0,0,0},

{"LPM Tcam Ad0", 0, DRV_LPM_TCAM_AD0_MAX_ENTRY_NUM, DRV_LPM_TCAM_AD0_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad1", 0, DRV_LPM_TCAM_AD1_MAX_ENTRY_NUM, DRV_LPM_TCAM_AD1_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad2", 0, DRV_LPM_TCAM_AD2_MAX_ENTRY_NUM, DRV_LPM_TCAM_AD2_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad3", 0, DRV_LPM_TCAM_AD3_MAX_ENTRY_NUM, DRV_LPM_TCAM_AD3_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad4", 0, DRV_LPM_TCAM_AD4_MAX_ENTRY_NUM, DRV_LPM_TCAM_AD4_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad5", 0, DRV_LPM_TCAM_AD5_MAX_ENTRY_NUM, DRV_LPM_TCAM_AD5_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad6", 0, DRV_LPM_TCAM_AD6_MAX_ENTRY_NUM, DRV_LPM_TCAM_AD6_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad7", 0, DRV_LPM_TCAM_AD7_MAX_ENTRY_NUM, DRV_LPM_TCAM_AD7_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad8", 0, DRV_LPM_TCAM_AD8_MAX_ENTRY_NUM, DRV_LPM_TCAM_AD8_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad9", 0, DRV_LPM_TCAM_AD9_MAX_ENTRY_NUM, DRV_LPM_TCAM_AD9_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad10", 0, DRV_LPM_TCAM_AD10_MAX_ENTRY_NUM, DRV_LPM_TCAM_AD10_BASE_4W, 0, 0},/* LPM TCAM AD */
{"LPM Tcam Ad11", 0, DRV_LPM_TCAM_AD11_MAX_ENTRY_NUM, DRV_LPM_TCAM_AD11_BASE_4W, 0, 0},/* LPM TCAM AD */
{"",0,0,0,0,0},
};
#endif
typedef enum drv_ftm_lpm_model_type_e{
    LPM_MODEL_PUBLIC_IPDA                             = 0, /* only public Ipda */
    LPM_MODEL_PRIVATE_IPDA                            = 1, /* only private ipda */
    LPM_MODEL_PUBLIC_IPDA_IPSA_HALF                   = 2, /* public ipda+ipsa, half size, performance */
    LPM_MODEL_PUBLIC_IPDA_IPSA_FULL                   = 3, /* public ipda+ipsa, full size, no performance */
    LPM_MODEL_PUBLIC_IPDA_PRIVATE_IPDA_HALF           = 4, /* public and private ipda, half size, performance */
    LPM_MODEL_PRIVATE_IPDA_IPSA_HALF                  = 5, /* private ipda+ipsa, half size, performance */
    LPM_MODEL_PRIVATE_IPDA_IPSA_FULL                  = 6, /* private ipda+ipsa, full size, no performance, default Mode */
    LPM_MODEL_PUBLIC_IPDA_IPSA_PRIVATE_IPDA_IPSA_HALF = 7, /* public ipda+ipsa, private ipda+ipsa, half size, no performance */
}drv_ftm_lpm_model_type_t;

static int32
_drv_ftm_config_lpm_model(uint32 model)
{
    uint8 table         = 0;
    switch(model)
    {
    case LPM_MODEL_PUBLIC_IPDA:                                 /* only public Ipda */
        if(g_ftm_master->nat_pbr_enable)
        {
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;

                case 1:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                case 2:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                default:
                    break;
            }
        }
        else
        {
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 1:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 2:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                default:
                    break;
            }
        }
        break;
    case LPM_MODEL_PRIVATE_IPDA:                                /* only private ipda */
        if(g_ftm_master->nat_pbr_enable)
        {
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;

                case 1:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                case 2:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                default:
                    break;
            }
        }
        else
        {
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 1:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 2:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                default:
                    break;
            }
        }
        break;
    case LPM_MODEL_PUBLIC_IPDA_IPSA_HALF:                       /* public ipda+ipsa, half size, performance */
        if(g_ftm_master->nat_pbr_enable)
        {
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                case 1:
                case 2:
                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                default:
                    break;
            }
        }else{
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 1:
                case 2:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;

                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                default:
                    break;
            }
        }
        break;
    case LPM_MODEL_PUBLIC_IPDA_IPSA_FULL:                       /* public ipda+ipsa, full size, no performance */
        if(g_ftm_master->nat_pbr_enable)
        {
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;

                case 1:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                case 2:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                default:
                    break;
            }
        }else{
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;

                case 1:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 2:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                default:
                    break;
            }
        }
        break;
    case LPM_MODEL_PUBLIC_IPDA_PRIVATE_IPDA_HALF:               /* public and private ipda, half size, performance */
        if(g_ftm_master->nat_pbr_enable)
        {
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

                case 1:
                case 2:
                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                default:
                    break;
            }
        }else{
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 1:
                case 2:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                default:
                    break;
            }
        }
        break;
    case LPM_MODEL_PRIVATE_IPDA_IPSA_HALF:                      /* private ipda+ipsa, half size, performance */
        if(g_ftm_master->nat_pbr_enable)
        {
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                case 1:
                case 2:
                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                default:
                    break;
            }
        }else{
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 1:
                case 2:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;

                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                default:
                    break;
            }
        }
        break;
    case LPM_MODEL_PRIVATE_IPDA_IPSA_FULL:                      /* private ipda+ipsa, full size, no performance */
        if(g_ftm_master->nat_pbr_enable)
        {
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                case 1:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                case 2:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    break;
                default:
                    break;
            }
        }else{
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 1:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 2:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                default:
                    break;
            }
        }
        break;
    case LPM_MODEL_PUBLIC_IPDA_IPSA_PRIVATE_IPDA_IPSA_HALF:     /* public ipda+ipsa, private ipda+ipsa, half size, no performance */
        if(g_ftm_master->nat_pbr_enable)
        {
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    /*private */
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

                    break;
                case 1:
                case 2:
                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);


                    /*private */
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

                    break;
                default:
                    break;
            }
        }else{
            switch(g_ftm_master->lookup_div)
            {
                case 0:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 1:
                case 2:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                case 3:
                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY8, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY9, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);

                    table = DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2;
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                    DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
                    break;
                default:
                    break;
            }
        }
        break;
    default:
        break;
    }

    /*all */
    switch(model)
    {
        case LPM_MODEL_PUBLIC_IPDA:
        case LPM_MODEL_PUBLIC_IPDA_IPSA_HALF:
        case LPM_MODEL_PUBLIC_IPDA_IPSA_FULL:
            table = DRV_FTM_TCAM_TYPE_IGS_LPM0_PUB_ALL;
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

            if (g_ftm_master->nat_pbr_enable)
            {
                table = DRV_FTM_TCAM_TYPE_IGS_LPM1;
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY8,  table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY9,  table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY11, table);

            }
            else
            {
                table = DRV_FTM_TCAM_TYPE_IGS_LPM0_PUB_ALL;
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY8,  table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY9,  table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
            }
            break;

        case LPM_MODEL_PRIVATE_IPDA:
        case LPM_MODEL_PRIVATE_IPDA_IPSA_HALF:
        case LPM_MODEL_PRIVATE_IPDA_IPSA_FULL:
            table = DRV_FTM_TCAM_TYPE_IGS_LPM0_ALL;
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

            if (g_ftm_master->nat_pbr_enable)
            {
                table = DRV_FTM_TCAM_TYPE_IGS_LPM1;
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY8,  table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY9,  table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY11, table);

            }
            else
            {
                table = DRV_FTM_TCAM_TYPE_IGS_LPM0_ALL;
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY8,  table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY9,  table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
            }

            break;
        case LPM_MODEL_PUBLIC_IPDA_PRIVATE_IPDA_HALF:
        case LPM_MODEL_PUBLIC_IPDA_IPSA_PRIVATE_IPDA_IPSA_HALF:
            table = DRV_FTM_TCAM_TYPE_IGS_LPM0_PUB_ALL;
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY0, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY1, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY2, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY3, table);

            table = DRV_FTM_TCAM_TYPE_IGS_LPM0_ALL;
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY4, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY5, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY6, table);
            DRV_FTM_ADD_LPM0_KEY(DRV_FTM_LPM_TCAM_KEY7, table);

            if (g_ftm_master->nat_pbr_enable)
            {
                table = DRV_FTM_TCAM_TYPE_IGS_LPM1;
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY8,  table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY9,  table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY11, table);

            }
            else
            {
                table = DRV_FTM_TCAM_TYPE_IGS_LPM0_PUB_ALL;
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY8,  table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY9,  table);

                table = DRV_FTM_TCAM_TYPE_IGS_LPM0_ALL;
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY10, table);
                DRV_FTM_ADD_LPM1_KEY(DRV_FTM_LPM_TCAM_KEY11, table);
            }

            break;
       default:
            break;
    }

    return DRV_E_NONE;
}


static int32
_drv_ftm_set_profile_default()
{

    uint8 table         = 0;
    uint32 couple_mode  = 0;

    DRV_IF_ERROR_RETURN(drv_get_dynamic_ram_couple_mode(&couple_mode));
    /********************************************
    dynamic edram table
    *********************************************/

    /*FIB Host0 Hash Key*/
    /* table ��ʾRAM�ļ���,����FibHost0Hash ����ѡ��5��RAM */
    table = DRV_FTM_SRAM_TBL_FIB0_HASH_KEY;
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM0, table);   /*Moidfy to 16K*/  /* ��RAM1 �����С���ӵ�table�� */
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM3, table);   /*Moidfy to 8K*/
#if (SDK_WORK_PLATFORM == 1)
    drv_set_hash_lookup_bitmap(HASH_MODULE_FIB_HOST0, 0x9, 0); /* level 1,2,4 */
#endif
    /*FIB Host1 Hash Key*/
    table = DRV_FTM_SRAM_TBL_FIB1_HASH_KEY;
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM9, table);   /*Moidfy to 4K*/
#if (SDK_WORK_PLATFORM == 1)
    drv_set_hash_lookup_bitmap(HASH_MODULE_FIB_HOST1, 0x8, 0); /* level 1 */
#endif
    /*FLOW Hash Key*/
    table = DRV_FTM_SRAM_TBL_FLOW_HASH_KEY;
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM4, table);   /*Moidfy to 8K*/
#if (SDK_WORK_PLATFORM == 1)
    drv_set_hash_lookup_bitmap(HASH_MODULE_FLOW, 0x10, 0); /* level 0 */
#endif
    /*FLOW Hash AD*/
    table = DRV_FTM_SRAM_TBL_FLOW_AD;
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM14, table);   /*Moidfy to 8K*/

    /*Lpm lookup Key*/
    table = DRV_FTM_SRAM_TBL_LPM_LKP_KEY;
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM6, table);   /*Moidfy to 8K*/

    /*DsIpDa*/
    table = DRV_FTM_SRAM_TBL_DSIP_AD;
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM13, table);   /*Moidfy to 8K*/

    /*DsIpMac*/
    table = DRV_FTM_SRAM_TBL_DSMAC_AD;
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM11, table);  /*Moidfy to 16K*/

    /*UserIdTunnelMpls Hash Key*/
    table = DRV_FTM_SRAM_TBL_USERID_HASH_KEY;
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM7, table);  /*Moidfy to 8K*/
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM8, table);  /*Moidfy to 4K*/
#if (SDK_WORK_PLATFORM == 1)
    drv_set_hash_lookup_bitmap(HASH_MODULE_USERID, 0x6, 0); /* level 0, 1 */
#endif
    /*UserIdTunnelMpls AD*/
    table = DRV_FTM_SRAM_TBL_USERID_AD;
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM15, table);  /*Moidfy to 8K*/

    /*Oam Mep*/
    table = DRV_FTM_SRAM_TBL_OAM_MEP;
    DRV_FTM_ADD_TABLE(DRV_FTM_SRAM1, table, 0, 8 * 1024);          /*Moidfy to 8K*/ /* ��SRAM14��ǰ8K�ŵ�TABLE OAM_MEP �� */

    /*Oam Ma*/
    table = DRV_FTM_SRAM_TBL_OAM_MA;
    DRV_FTM_ADD_TABLE(DRV_FTM_SRAM1, table, 8 * 1024, 2 * 1024);   /*Moidfy to 2K*//* ��SRAM14��8K ~ 10K�ŵ�TABLE OAM_MA �� */
    /*Oam MaName*/
    table = DRV_FTM_SRAM_TBL_OAM_MA_NAME;
    DRV_FTM_ADD_TABLE(DRV_FTM_SRAM1, table, 10 * 1024, 4 * 1024);  /*Moidfy to 4K*/
    /*Oam Lm*/
    table = DRV_FTM_SRAM_TBL_OAM_LM;
    DRV_FTM_ADD_TABLE(DRV_FTM_SRAM1, table, 14 * 1024, 2 * 1024);  /*Moidfy to 2K*/

    /*Oam APS*/
    table = DRV_FTM_SRAM_TBL_OAM_APS;
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM10, table);  /*Moidfy to 4K*/

    /*DsEdit*/
    table = DRV_FTM_SRAM_TBL_EDIT;
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM20, table);  /*Moidfy to 8K*/


    /*DsNexthop*/
    table = DRV_FTM_SRAM_TBL_NEXTHOP;
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM16, table);  /*Moidfy to 8K*/
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM19, table);  /*Moidfy to 8K*/
    /*DsMet*/
    table = DRV_FTM_SRAM_TBL_MET;
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM18, table);  /*Moidfy to 8K*/
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM21, table);  /*Moidfy to 4K*/


    /*XcOamHash */
    table = DRV_FTM_SRAM_TBL_XCOAM_HASH_KEY;
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM2, table);   /*Moidfy to 32K*/
#if (SDK_WORK_PLATFORM == 1)
    drv_set_hash_lookup_bitmap(HASH_MODULE_EGRESS_XC, 0x1, 0); /* level 0 */
#endif
    /*IpFix */
    table = DRV_FTM_SRAM_TBL_IPFIX_HASH_KEY;
    //DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM3, table);
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM5, table);   /*Moidfy to 8K*/
#if (SDK_WORK_PLATFORM == 1)
    drv_set_hash_lookup_bitmap(HASH_MODULE_IPFIX, 0xc, 0); /* level 0, 1*/
#endif
    /*IpFixAd */
    table = DRV_FTM_SRAM_TBL_IPFIX_AD;
    //DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM7, table);
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM12, table);   /*Moidfy to 8K*/

    /*DsFwd */
    table = DRV_FTM_SRAM_TBL_FWD;
    DRV_FTM_ADD_FULL_TABLE(DRV_FTM_SRAM17, table);   /*Moidfy to 8K*/

    /********************************************
    tcam table
    *********************************************/

    table = DRV_FTM_TCAM_TYPE_IGS_ACL0;
    DRV_FTM_ADD_FULL_KEY(DRV_FTM_TCAM_KEY2, table); /* OK */

    table = DRV_FTM_TCAM_TYPE_IGS_ACL1;
    DRV_FTM_ADD_FULL_KEY(DRV_FTM_TCAM_KEY3, table); /* OK */

    table = DRV_FTM_TCAM_TYPE_IGS_ACL2;
    DRV_FTM_ADD_FULL_KEY(DRV_FTM_TCAM_KEY4, table); /* OK */

    table = DRV_FTM_TCAM_TYPE_IGS_ACL3;
    DRV_FTM_ADD_FULL_KEY(DRV_FTM_TCAM_KEY5, table); /* OK */

    table = DRV_FTM_TCAM_TYPE_IGS_ACL4;
    DRV_FTM_ADD_FULL_KEY(DRV_FTM_TCAM_KEY6, table); /* OK */

    table = DRV_FTM_TCAM_TYPE_IGS_ACL5;
    DRV_FTM_ADD_FULL_KEY(DRV_FTM_TCAM_KEY7, table); /* OK */

    table = DRV_FTM_TCAM_TYPE_IGS_ACL6;
    DRV_FTM_ADD_FULL_KEY(DRV_FTM_TCAM_KEY8, table); /* OK */

    table = DRV_FTM_TCAM_TYPE_IGS_ACL7;
    DRV_FTM_ADD_FULL_KEY(DRV_FTM_TCAM_KEY9, table); /* OK */

    table = DRV_FTM_TCAM_TYPE_EGS_ACL0;
    DRV_FTM_ADD_FULL_KEY(DRV_FTM_TCAM_KEY10, table);/* OK */

    table = DRV_FTM_TCAM_TYPE_EGS_ACL1;
    DRV_FTM_ADD_FULL_KEY(DRV_FTM_TCAM_KEY11, table);/* OK */

    table = DRV_FTM_TCAM_TYPE_EGS_ACL2;
    DRV_FTM_ADD_FULL_KEY(DRV_FTM_TCAM_KEY12, table);/* OK */

    table = DRV_FTM_TCAM_TYPE_IGS_USERID0;
    DRV_FTM_ADD_FULL_KEY(DRV_FTM_TCAM_KEY0, table); /* OK */

    table = DRV_FTM_TCAM_TYPE_IGS_USERID1;
    DRV_FTM_ADD_FULL_KEY(DRV_FTM_TCAM_KEY1, table); /* OK */

    /*default tcam mode is private ipda+ipsa, full size, no performance*/
    g_ftm_master->lpm_model = 6;
    _drv_ftm_config_lpm_model(g_ftm_master->lpm_model);

    return DRV_E_NONE;
}


/*
   ���������Ҫ���������û��Զ���memprofile��ʱ��ת���õ�
 */
static int32
_drv_ftm_get_key_id_info(uint8 key_id,uint8 key_size, uint8* drv_key_id, uint8* key_type)
{

    /* convert ctc size to drv size*/
    switch(key_size)
    {
        case DRV_FTM_KEY_SIZE_160_BIT:
            *key_type = DRV_FTM_TCAM_SIZE_160;
            break;
        case DRV_FTM_KEY_SIZE_320_BIT:
            *key_type = DRV_FTM_TCAM_SIZE_320;
            break;
        case DRV_FTM_KEY_SIZE_640_BIT:
            *key_type = DRV_FTM_TCAM_SIZE_640;
            break;
        default:
            break;
    }
    /*convert ctc id to drv id*/
    switch(key_id)
    {
        case DRV_FTM_KEY_TYPE_SCL0:
            *drv_key_id = DRV_FTM_TCAM_TYPE_IGS_USERID0;
            break;
        case DRV_FTM_KEY_TYPE_SCL1:
            *drv_key_id = DRV_FTM_TCAM_TYPE_IGS_USERID1;
            break;

        case DRV_FTM_KEY_TYPE_ACL0:
            *drv_key_id = DRV_FTM_TCAM_TYPE_IGS_ACL0;
            break;

        case DRV_FTM_KEY_TYPE_ACL1:
            *drv_key_id = DRV_FTM_TCAM_TYPE_IGS_ACL1;
            break;

        case DRV_FTM_KEY_TYPE_ACL2:
            *drv_key_id = DRV_FTM_TCAM_TYPE_IGS_ACL2;
            break;

        case DRV_FTM_KEY_TYPE_ACL3:
            *drv_key_id = DRV_FTM_TCAM_TYPE_IGS_ACL3;
            break;

        case DRV_FTM_KEY_TYPE_ACL4:
            *drv_key_id = DRV_FTM_TCAM_TYPE_IGS_ACL4;
            break;

        case DRV_FTM_KEY_TYPE_ACL5:
            *drv_key_id = DRV_FTM_TCAM_TYPE_IGS_ACL5;
            break;

        case DRV_FTM_KEY_TYPE_ACL6:
            *drv_key_id = DRV_FTM_TCAM_TYPE_IGS_ACL6;
            break;

        case DRV_FTM_KEY_TYPE_ACL7:
            *drv_key_id = DRV_FTM_TCAM_TYPE_IGS_ACL7;
            break;


        case DRV_FTM_KEY_TYPE_ACL0_EGRESS:
            *drv_key_id = DRV_FTM_TCAM_TYPE_EGS_ACL0;
            break;

        case DRV_FTM_KEY_TYPE_ACL1_EGRESS:
            *drv_key_id = DRV_FTM_TCAM_TYPE_EGS_ACL1;
            break;

        case DRV_FTM_KEY_TYPE_ACL2_EGRESS:
            *drv_key_id = DRV_FTM_TCAM_TYPE_EGS_ACL2;
            break;

        case DRV_FTM_KEY_TYPE_IPV4_NAT:
            *drv_key_id = DRV_FTM_TCAM_TYPE_IGS_LPM1;
            *key_type   = DRV_FTM_TCAM_SIZE_ipv4_nat;
            break;

        default:
            return DRV_E_INVAILD_TYPE;
    }

    return DRV_E_NONE;
}


static int32
_drv_ftm_get_tbl_id(uint8 tbl_id,uint8* drv_tbl_id)
{
    switch(tbl_id)
    {
        case DRV_FTM_TBL_TYPE_LPM_PIPE0:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_LPM_LKP_KEY;
            break;
        case DRV_FTM_TBL_TYPE_NEXTHOP:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_NEXTHOP;
            break;

        case DRV_FTM_TBL_TYPE_FWD:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_FWD;
            break;

        case DRV_FTM_TBL_TYPE_MET:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_MET;
            break;

        case DRV_FTM_TBL_TYPE_EDIT:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_EDIT;
            break;

        case DRV_FTM_TBL_TYPE_OAM_MEP:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_OAM_MEP;
            break;

        case DRV_FTM_TBL_TYPE_STATS:
            break;

        case DRV_FTM_TBL_TYPE_LM:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_OAM_LM;
            break;

        case DRV_FTM_TBL_TYPE_SCL_HASH_KEY:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_USERID_HASH_KEY;
            break;

        case DRV_FTM_TBL_TYPE_SCL_HASH_AD:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_USERID_AD;
            break;

        case DRV_FTM_TBL_FIB0_HASH_KEY:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_FIB0_HASH_KEY;
            break;
        case DRV_FTM_TBL_DSMAC_AD:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_DSMAC_AD;
            break;

        case DRV_FTM_TBL_FIB1_HASH_KEY:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_FIB1_HASH_KEY;
            break;

        case DRV_FTM_TBL_DSIP_AD:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_DSIP_AD;
            break;


        case DRV_FTM_TBL_XCOAM_HASH_KEY:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_XCOAM_HASH_KEY;
            break;
        case DRV_FTM_TBL_FLOW_HASH_KEY:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_FLOW_HASH_KEY;
            break;
        case DRV_FTM_TBL_FLOW_AD:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_FLOW_AD;
            break;
        case DRV_FTM_TBL_IPFIX_HASH_KEY:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_IPFIX_HASH_KEY;
            break;

        case DRV_FTM_TBL_IPFIX_AD:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_IPFIX_AD;
            break;
        case DRV_FTM_TBL_OAM_APS:
            *drv_tbl_id = DRV_FTM_SRAM_TBL_OAM_APS;
            break;

        default:
            break;
    }
    return DRV_E_NONE;
}

static int32
_drv_ftm_process_oam_tbl(drv_ftm_tbl_info_t *p_oam_tbl_info)
{

    uint32 bitmap = 0;
    uint8 bit_offset = 0;
    uint32 total_size = 0;

    uint32 tbl_ids[] = {DRV_FTM_SRAM_TBL_OAM_MEP, DRV_FTM_SRAM_TBL_OAM_MA, DRV_FTM_SRAM_TBL_OAM_MA_NAME, DRV_FTM_SRAM_TBL_OAM_LM};
    uint32 tbl_size[] = {0, 0, 0, 0};
    uint8  idx  = 0;

    uint32 couple_mode      = 0;
    uint32 mem_entry_num    = 0;
    uint32 mem_start_offset = 0;

    DRV_IF_ERROR_RETURN(drv_get_dynamic_ram_couple_mode(&couple_mode));

    bitmap = p_oam_tbl_info->mem_bitmap;
    for (bit_offset = 0 ; bit_offset < 32; bit_offset++)
    {
        if(IS_BIT_SET(bitmap, bit_offset))
        {
            if(couple_mode)
            {
                total_size += (p_oam_tbl_info->mem_entry_num[bit_offset]*2);
            }
            else
            {
                total_size += p_oam_tbl_info->mem_entry_num[bit_offset];
            }
        }
    }
    tbl_size[0] = total_size/8*4;   /*MEP*/
    tbl_size[1] = total_size/8*1;   /*MA*/
    tbl_size[2] = total_size/8*2;   /*MANAME*/
    tbl_size[3] = total_size/8*1;   /*LM*/

    bit_offset = 0;
    while (bit_offset < DRV_FTM_MEM_MAX)
    {
        if(IS_BIT_SET(bitmap, bit_offset))
        {
            mem_entry_num       = p_oam_tbl_info->mem_entry_num[bit_offset];
            mem_start_offset    = p_oam_tbl_info->mem_start_offset[bit_offset];
            if (couple_mode)
            {
                mem_entry_num       *= 2;
            }

            if (tbl_size[idx] == mem_entry_num)
            {
                DRV_FTM_ADD_TABLE(bit_offset, tbl_ids[idx], mem_start_offset, mem_entry_num);
                idx++;
                bit_offset ++;
            }
            else if (tbl_size[idx] > mem_entry_num)
            {
                DRV_FTM_ADD_TABLE(bit_offset, tbl_ids[idx], mem_start_offset, mem_entry_num);
                tbl_size[idx] -= mem_entry_num;
                bit_offset ++;
            }
            else
            {
                DRV_FTM_ADD_TABLE(bit_offset, tbl_ids[idx], mem_start_offset, tbl_size[idx]);

                p_oam_tbl_info->mem_start_offset[bit_offset] += tbl_size[idx];
                p_oam_tbl_info->mem_entry_num[bit_offset]    -= tbl_size[idx];
                idx++;
            }

            if(idx >= 4)
            {
                break;
            }
        }
        else
        {
            bit_offset ++;
        }
    }

    return DRV_E_NONE;
}

static int32
_drv_ftm_set_profile_user_define_edram(drv_ftm_profile_info_t *profile_info)
{
    uint8 tbl_index     = 0;
    uint8 tbl_info_num  = 0;
    uint8 tbl_id        = 0;

    uint32 bitmap       = 0;
    uint8 mem_id        = 0;
    uint32 offset       = 0;
    uint32 entry_size   = 0;
    uint32 couple_mode  = 0;

    DRV_IF_ERROR_RETURN(drv_get_dynamic_ram_couple_mode(&couple_mode));

    /********************************************
    dynamic edram table
    *********************************************/
    tbl_info_num = profile_info->tbl_info_size;
    for(tbl_index = 0; tbl_index < tbl_info_num; tbl_index++)
    {
        bitmap = profile_info->tbl_info[tbl_index].mem_bitmap;
        if (DRV_FTM_TBL_TYPE_OAM_MEP == profile_info->tbl_info[tbl_index].tbl_id)
        {/*oam mep*/
            _drv_ftm_process_oam_tbl(&profile_info->tbl_info[tbl_index]);
        }
        else
        {
            _drv_ftm_get_tbl_id(profile_info->tbl_info[tbl_index].tbl_id,&tbl_id);

            for (mem_id = 0; mem_id < DRV_FTM_SRAM_MAX; mem_id++)
            {
                if(IS_BIT_SET(bitmap, mem_id))
                {
                    offset       = profile_info->tbl_info[tbl_index].mem_start_offset[mem_id];
                    entry_size   = profile_info->tbl_info[tbl_index].mem_entry_num[mem_id];
#if 0
                    if ((DRV_FTM_TBL_IPFIX_HASH_KEY == profile_info->tbl_info[tbl_index].tbl_id)
                        || (DRV_FTM_TBL_IPFIX_AD == profile_info->tbl_info[tbl_index].tbl_id))
                    {
                        {
                            entry_size * = 2;
                            offset     * = 2;
                        }
                    }
                    else if(couple_mode)
                    {
                        entry_size * = 2;
                        offset     * = 2;
                    }

#endif
                    DRV_FTM_ADD_TABLE(mem_id, tbl_id, offset, entry_size);
                }
            }
        }

    }

    return DRV_E_NONE;
}

static int32
_drv_ftm_set_profile_user_define_tcam(drv_ftm_profile_info_t *profile_info)
{
    uint8 key_idx       = 0;
    uint8 key_info_num  = 0;
    uint32 bitmap       = 0;
    uint8 mem_id        = 0;

    uint8  key_id       = 0;
    uint8 key_type      = 0;

    uint32 offset       = 0;
    uint32 entry_size   = 0;
    uint32 couple_mode  = 0;

    DRV_IF_ERROR_RETURN(drv_get_dynamic_ram_couple_mode(&couple_mode));
    /********************************************
    tcam table
    *********************************************/
    key_info_num = profile_info->key_info_size;
    for(key_idx = 0; key_idx < key_info_num; key_idx++)
    {
        bitmap = profile_info->key_info[key_idx].tcam_bitmap;
        _drv_ftm_get_key_id_info(profile_info->key_info[key_idx].key_id,
                                profile_info->key_info[key_idx].key_size,
                                &key_id, &key_type);
        for(mem_id = DRV_FTM_TCAM_KEY0; mem_id < DRV_FTM_TCAM_KEYM; mem_id++)
        {
            if(IS_BIT_SET(bitmap, (mem_id - DRV_FTM_TCAM_KEY0)))
            {
                offset       = profile_info->key_info[key_idx].tcam_start_offset[mem_id - DRV_FTM_TCAM_KEY0];
                entry_size   = profile_info->key_info[key_idx].tcam_entry_num[mem_id - DRV_FTM_TCAM_KEY0];
                if (couple_mode && (DRV_FTM_TCAM_KEY8 != mem_id))
                {
                    entry_size *= 2;
                    offset     *= 2;
                }
                DRV_FTM_ADD_KEY(mem_id, key_id, 0, entry_size);

                DRV_FTM_ADD_KEY_BYTYPE(mem_id, key_id, key_type, offset, entry_size);
            }
        }
        //SYS_FTM_DBG_DUMP("key_id = %d, max_index = %d\n", key_id, SYS_FTM_KEY_MAX_INDEX(key_id));
    }

    return DRV_E_NONE;

}

static int32
_drv_ftm_set_profile_user_define(drv_ftm_profile_info_t *profile_info)
{

    _drv_ftm_set_profile_user_define_edram(profile_info);

    _drv_ftm_set_profile_user_define_tcam(profile_info);
    _drv_ftm_config_lpm_model(g_ftm_master->lpm_model);

    return DRV_E_NONE;
}

static int32
_drv_ftm_get_sram_tbl_name(uint32 sram_type, char* sram_tbl_id_str)
{
    char* str[]={
        "FibHost0HashKey",
        "FibHost1HashKey",
        "FlowHashKey",
        "IpfixHashKey",
        "SclHashKey",
        "XoamHashKey",
        "LpmLookupKey",
        "DsMacAd",
        "DsIpAd",
        "DsFlowAd",
        "DsIpfixAd",
        "DsSclAd",
        "DsNexthop",
        "DsFwd",
        "DsMet",
        "DsEdit",
        "DsAps",
        "DsOamLm",
        "DsOamMep",
        "DsOamMa",
        "DsOamMaName"
    };

    DRV_PTR_VALID_CHECK(sram_tbl_id_str);
    if (DRV_FTM_SRAM_TBL_MAX < sram_type)
    {
        return DRV_E_EXCEED_MAX_SIZE;
    }

    sal_strcpy(sram_tbl_id_str, str[sram_type]);

    return DRV_E_NONE;
}

static int32
_drv_ftm_get_sram_tbl_id(uint32 sram_type,
                                   uint32* p_sram_tbl_id,
                                   uint8* p_share_num)
{
    uint8 idx = 0;

    DRV_PTR_VALID_CHECK(p_sram_tbl_id);
    DRV_PTR_VALID_CHECK(p_share_num);

    switch (sram_type)
    {
    case DRV_FTM_SRAM_TBL_FIB0_HASH_KEY:
        p_sram_tbl_id[idx++] = DsFibHost0Ipv4HashKey_t,
        p_sram_tbl_id[idx++] = DsFibHost0Ipv6UcastHashKey_t,
        p_sram_tbl_id[idx++] = DsFibHost0Ipv6McastHashKey_t,
        p_sram_tbl_id[idx++] = DsFibHost0MacIpv6McastHashKey_t,
        p_sram_tbl_id[idx++] = DsFibHost0MacHashKey_t,
        p_sram_tbl_id[idx++] = DsFibHost0TrillHashKey_t,
        p_sram_tbl_id[idx++] = DsFibHost0FcoeHashKey_t,
        DRV_FTM_TBL_ACCESS_FLAG(sram_type) = 1;
        break;

    case DRV_FTM_SRAM_TBL_FIB1_HASH_KEY:
        p_sram_tbl_id[idx++] = DsFibHost1Ipv4McastHashKey_t,
        p_sram_tbl_id[idx++] = DsFibHost1Ipv4NatDaPortHashKey_t,
        p_sram_tbl_id[idx++] = DsFibHost1Ipv4NatSaPortHashKey_t,
        p_sram_tbl_id[idx++] = DsFibHost1Ipv6McastHashKey_t,
        p_sram_tbl_id[idx++] = DsFibHost1MacIpv4McastHashKey_t,
        p_sram_tbl_id[idx++] = DsFibHost1Ipv6NatDaPortHashKey_t,
        p_sram_tbl_id[idx++] = DsFibHost1Ipv6NatSaPortHashKey_t,
        p_sram_tbl_id[idx++] = DsFibHost1FcoeRpfHashKey_t,
        p_sram_tbl_id[idx++] = DsFibHost1TrillMcastVlanHashKey_t,
        p_sram_tbl_id[idx++] = DsFibHost1MacIpv6McastHashKey_t,
        DRV_FTM_TBL_ACCESS_FLAG(sram_type) = 1;
        break;

    case DRV_FTM_SRAM_TBL_FLOW_HASH_KEY:
        p_sram_tbl_id[idx++] = DsFlowL2HashKey_t,
        p_sram_tbl_id[idx++] = DsFlowL2L3HashKey_t,
        p_sram_tbl_id[idx++] = DsFlowL3Ipv4HashKey_t,
        p_sram_tbl_id[idx++] = DsFlowL3Ipv6HashKey_t,
        p_sram_tbl_id[idx++] = DsFlowL3MplsHashKey_t,
        DRV_FTM_TBL_ACCESS_FLAG(sram_type) = 1;
        break;

    case DRV_FTM_SRAM_TBL_IPFIX_HASH_KEY:
        p_sram_tbl_id[idx++] = DsIpfixL2HashKey_t,
        p_sram_tbl_id[idx++] = DsIpfixL2L3HashKey_t,
        p_sram_tbl_id[idx++] = DsIpfixL3Ipv4HashKey_t,
        p_sram_tbl_id[idx++] = DsIpfixL3Ipv6HashKey_t,
        p_sram_tbl_id[idx++] = DsIpfixL3MplsHashKey_t,
        DRV_FTM_TBL_ACCESS_FLAG(sram_type) = 1;
        break;

    case DRV_FTM_SRAM_TBL_USERID_HASH_KEY:
        p_sram_tbl_id[idx++] = DsUserIdCvlanCosPortHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdCvlanPortHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdDoubleVlanPortHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdIpv4PortHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdIpv4SaHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdIpv6PortHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdIpv6SaHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdMacHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdMacPortHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdPortHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdSvlanCosPortHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdSvlanHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdSvlanMacSaHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdSvlanPortHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdSclFlowL2HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv4DaHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv4GreKeyHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv4HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv4RpfHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv4UdpHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv4McNvgreMode0HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv4NvgreMode1HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv4McVxlanMode0HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv4VxlanMode1HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv4UcNvgreMode0HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv4UcNvgreMode1HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv4UcVxlanMode0HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv4UcVxlanMode1HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv6McNvgreMode0HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv6McNvgreMode1HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv6McVxlanMode0HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv6McVxlanMode1HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv6UcNvgreMode0HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv6UcNvgreMode1HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv6UcVxlanMode0HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv6UcVxlanMode1HashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelMplsHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelPbbHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelTrillMcAdjHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelTrillMcDecapHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelTrillMcRpfHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelTrillUcDecapHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelTrillUcRpfHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdCapwapMacDaForwardHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdCapwapStaStatusHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdCapwapStaStatusMcHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdCapwapVlanForwardHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv4CapwapHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelIpv6CapwapHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelCapwapRmacHashKey_t,
        p_sram_tbl_id[idx++] = DsUserIdTunnelCapwapRmacRidHashKey_t,
        DRV_FTM_TBL_ACCESS_FLAG(sram_type) = 1;
        break;

    case DRV_FTM_SRAM_TBL_XCOAM_HASH_KEY:
        p_sram_tbl_id[idx++] = DsEgressXcOamPortCrossHashKey_t,
        p_sram_tbl_id[idx++] = DsEgressXcOamPortHashKey_t,
        p_sram_tbl_id[idx++] = DsEgressXcOamPortVlanCrossHashKey_t,
        p_sram_tbl_id[idx++] = DsEgressXcOamCvlanCosPortHashKey_t,
        p_sram_tbl_id[idx++] = DsEgressXcOamCvlanPortHashKey_t,
        p_sram_tbl_id[idx++] = DsEgressXcOamDoubleVlanPortHashKey_t,
        p_sram_tbl_id[idx++] = DsEgressXcOamSvlanCosPortHashKey_t,
        p_sram_tbl_id[idx++] = DsEgressXcOamSvlanPortHashKey_t,
        p_sram_tbl_id[idx++] = DsEgressXcOamSvlanPortMacHashKey_t,
        p_sram_tbl_id[idx++] = DsEgressXcOamTunnelPbbHashKey_t,
        p_sram_tbl_id[idx++] = DsEgressXcOamBfdHashKey_t,
        p_sram_tbl_id[idx++] = DsEgressXcOamEthHashKey_t,
        p_sram_tbl_id[idx++] = DsEgressXcOamMplsLabelHashKey_t,
        p_sram_tbl_id[idx++] = DsEgressXcOamMplsSectionHashKey_t,
        p_sram_tbl_id[idx++] = DsEgressXcOamRmepHashKey_t,

        DRV_FTM_TBL_ACCESS_FLAG(sram_type) = 1;
        break;

    case DRV_FTM_SRAM_TBL_LPM_LKP_KEY:
        p_sram_tbl_id[idx++] = DsLpmLookupKey_t;
        break;

    case DRV_FTM_SRAM_TBL_DSMAC_AD:
        p_sram_tbl_id[idx++] = DsMac_t;
        break;

    case DRV_FTM_SRAM_TBL_DSIP_AD:
        p_sram_tbl_id[idx++] = DsIpDa_t;
        p_sram_tbl_id[idx++] = DsIpSaNat_t;
        p_sram_tbl_id[idx++] = DsFcoeDa_t;
        p_sram_tbl_id[idx++] = DsFcoeSa_t;
        p_sram_tbl_id[idx++] = DsTrillDa_t;
        break;

    case DRV_FTM_SRAM_TBL_FLOW_AD:
        p_sram_tbl_id[idx++] = DsFlow_t;
        break;

    case DRV_FTM_SRAM_TBL_IPFIX_AD:
        p_sram_tbl_id[idx++] = DsIpfixSessionRecord_t;
        break;

    case DRV_FTM_SRAM_TBL_USERID_AD:
        p_sram_tbl_id[idx++] = DsTunnelId_t;
        p_sram_tbl_id[idx++] = DsTunnelIdHalf_t;
        p_sram_tbl_id[idx++] = DsUserId_t;
        p_sram_tbl_id[idx++] = DsUserIdHalf_t;
        p_sram_tbl_id[idx++] = DsSclFlow_t;
        p_sram_tbl_id[idx++] = DsMpls_t;
        p_sram_tbl_id[idx++] = DsMplsHalf_t;
        p_sram_tbl_id[idx++] = DsTunnelIdRpf_t;

        DRV_FTM_TBL_ACCESS_FLAG(sram_type) = 1;
        break;

    case DRV_FTM_SRAM_TBL_NEXTHOP:
        p_sram_tbl_id[idx++] = DsNextHop4W_t;
        p_sram_tbl_id[idx++] = DsNextHop8W_t;
        DRV_FTM_TBL_ACCESS_FLAG(sram_type) = 1;
        break;

    case DRV_FTM_SRAM_TBL_FWD:
        p_sram_tbl_id[idx++] = DsFwd_t;
        p_sram_tbl_id[idx++] = DsFwdDualHalf_t;
        p_sram_tbl_id[idx++] = DsFwdHalf_t;
        DRV_FTM_TBL_ACCESS_FLAG(sram_type) = 1;
        break;

    case DRV_FTM_SRAM_TBL_MET:
        p_sram_tbl_id[idx++] = DsMetEntry3W_t;
        p_sram_tbl_id[idx++] = DsMetEntry6W_t;
        DRV_FTM_TBL_ACCESS_FLAG(sram_type) = 1;
        break;

    case DRV_FTM_SRAM_TBL_EDIT:
        p_sram_tbl_id[idx++] = DsL23Edit3W_t;
        p_sram_tbl_id[idx++] = DsL23Edit12W_t;
        p_sram_tbl_id[idx++] = DsL23Edit6W_t;
        p_sram_tbl_id[idx++] = DsL2EditEth3W_t;
        p_sram_tbl_id[idx++] = DsL2EditEth6W_t;
        p_sram_tbl_id[idx++] = DsL2EditInnerSwap_t;
        p_sram_tbl_id[idx++] = DsL2EditFlex_t;
        p_sram_tbl_id[idx++] = DsL2EditLoopback_t;
        p_sram_tbl_id[idx++] = DsL2EditPbb4W_t;
        p_sram_tbl_id[idx++] = DsL2EditPbb8W_t;
        p_sram_tbl_id[idx++] = DsL2EditSwap_t;
        p_sram_tbl_id[idx++] = DsL2EditOf_t;
        p_sram_tbl_id[idx++] = DsL3EditFlex_t;
        p_sram_tbl_id[idx++] = DsL3EditLoopback_t;
        p_sram_tbl_id[idx++] = DsL3EditMpls3W_t;
        p_sram_tbl_id[idx++] = DsL3EditNat3W_t;
        p_sram_tbl_id[idx++] = DsL3EditNat6W_t;
        p_sram_tbl_id[idx++] = DsL3EditOf6W_t;
        p_sram_tbl_id[idx++] = DsL3EditOf12W_t;
        p_sram_tbl_id[idx++] = DsL3EditOf12WIpv6Only_t;
        p_sram_tbl_id[idx++] = DsL3EditOf12WArpData_t;
        p_sram_tbl_id[idx++] = DsL3EditOf12WIpv6L4_t;
        p_sram_tbl_id[idx++] = DsL3EditTrill_t;
        p_sram_tbl_id[idx++] = DsL3EditTunnelV4_t;
        p_sram_tbl_id[idx++] = DsL3EditTunnelV6_t;
        p_sram_tbl_id[idx++] = DsL3Edit12W1st_t;
        p_sram_tbl_id[idx++] = DsL3Edit12W2nd_t;
        p_sram_tbl_id[idx++] = DsL2Edit12WInner_t;
        p_sram_tbl_id[idx++] = DsL2Edit12WShare_t;
        p_sram_tbl_id[idx++] = DsL2Edit6WShare_t;
        p_sram_tbl_id[idx++] = DsL2EditDsLite_t;
        p_sram_tbl_id[idx++] = TempInnerEdit12W_t;
        p_sram_tbl_id[idx++] = TempOuterEdit12W_t;
        DRV_FTM_TBL_ACCESS_FLAG(sram_type) = 1;
    break;

    case DRV_FTM_SRAM_TBL_OAM_APS:
        p_sram_tbl_id[idx++] = DsApsBridge_t;
        break;

    case DRV_FTM_SRAM_TBL_OAM_LM:
        p_sram_tbl_id[idx++] = DsOamLmStats_t;
        break;

    case DRV_FTM_SRAM_TBL_OAM_MEP:
        p_sram_tbl_id[idx++] = DsBfdMep_t;
        p_sram_tbl_id[idx++] = DsBfdRmep_t;
        p_sram_tbl_id[idx++] = DsEthMep_t;
        p_sram_tbl_id[idx++] = DsEthRmep_t;
        break;

    case DRV_FTM_SRAM_TBL_OAM_MA:
        p_sram_tbl_id[idx++] = DsMa_t;
        break;

    case DRV_FTM_SRAM_TBL_OAM_MA_NAME:
        p_sram_tbl_id[idx++] = DsMaName_t;
        break;


    default:
        return DRV_E_INVAILD_TYPE;

    }

    *p_share_num = idx;

    return DRV_E_NONE;

}

static int32
_sys_goldengate_ftm_get_edram_bitmap(uint8 sram_type,
                                     uint32* bitmap,
                                     uint32* sram_array)
{
    uint32 bit_map_temp = 0;
    uint32 mem_bit_map  = 0;
    uint8 mem_id        = 0;
    uint8 idx           = 0;
    uint8 bit[DRV_FTM_MAX_ID]     = {0};

    switch (sram_type)
    {
        /* SelEdram  {edram0, edram3, edram7, edram7} Done */
        case DRV_FTM_SRAM_TBL_LPM_LKP_KEY:
        bit[DRV_FTM_SRAM0] = 0;
        bit[DRV_FTM_SRAM3] = 1;
        bit[DRV_FTM_SRAM6] = 2;
        bit[DRV_FTM_SRAM7] = 3;
        break;

        /* SelEdram  {edram0, edram1, edram2, edram3, edram4, edram5 } Done*/
        case DRV_FTM_SRAM_TBL_FIB0_HASH_KEY:
        bit[DRV_FTM_SRAM0] = 0;
        bit[DRV_FTM_SRAM1] = 1;
        bit[DRV_FTM_SRAM2] = 2;
        bit[DRV_FTM_SRAM3] = 3;
        bit[DRV_FTM_SRAM4] = 4;
        bit[DRV_FTM_SRAM5] = 5;
        break;

        /* SelEdram  {edram11, edram12, edram13, edram14, edram15} Done*/
    case DRV_FTM_SRAM_TBL_FLOW_AD:
        bit[DRV_FTM_SRAM11]   = 0;
        bit[DRV_FTM_SRAM12]   = 1;
        bit[DRV_FTM_SRAM13]   = 2;
        bit[DRV_FTM_SRAM14]   = 3;
        bit[DRV_FTM_SRAM15]   = 4;
        break;

        /* SelEdram  {edram0, edram5} Done*/
        case DRV_FTM_SRAM_TBL_IPFIX_HASH_KEY:
        bit[DRV_FTM_SRAM0] = 0;
        bit[DRV_FTM_SRAM5] = 1;
        break;

        /* SelEdram  {edram11, edram12} Done*/
    case DRV_FTM_SRAM_TBL_IPFIX_AD:
        bit[DRV_FTM_SRAM11] = 0;
        bit[DRV_FTM_SRAM12] = 1;
        break;

        /* SelEdram  {edram11, edram12, edram13, edram14, edram15} Done*/
        case DRV_FTM_SRAM_TBL_DSMAC_AD:
        bit[DRV_FTM_SRAM11]   = 0;
        bit[DRV_FTM_SRAM12]   = 1;
        bit[DRV_FTM_SRAM13]   = 2;
        bit[DRV_FTM_SRAM14]   = 3;
        bit[DRV_FTM_SRAM15]   = 4;
        break;

        /* SelEdram  {edram11, edram12, edram13, edram14, edram15} Done*/
        case DRV_FTM_SRAM_TBL_DSIP_AD:
        bit[DRV_FTM_SRAM11]   = 0;
        bit[DRV_FTM_SRAM12]   = 1;
        bit[DRV_FTM_SRAM13]   = 2;
        bit[DRV_FTM_SRAM14]   = 3;
        bit[DRV_FTM_SRAM15]   = 4;
        break;

        /* SelEdram  {edram18, edram19, edram20, edram21 } Done*/
    case DRV_FTM_SRAM_TBL_EDIT:
        bit[DRV_FTM_SRAM18] = 0;
        bit[DRV_FTM_SRAM19] = 1;
        bit[DRV_FTM_SRAM20] = 2;
        bit[DRV_FTM_SRAM21] = 3;
        break;

        /* SelEdram  {edram16, edram18, edram19, edram20, edram21 } Done*/
        case DRV_FTM_SRAM_TBL_NEXTHOP:
        bit[DRV_FTM_SRAM16] = 0;
        bit[DRV_FTM_SRAM18] = 1;
        bit[DRV_FTM_SRAM19] = 2;
        bit[DRV_FTM_SRAM20] = 3;
        bit[DRV_FTM_SRAM21] = 4;
        break;

        /* SelEdram  {edram16, edram18, edram19, edram20, edram21 } Done*/
        case DRV_FTM_SRAM_TBL_MET:
        bit[DRV_FTM_SRAM16] = 0;
        bit[DRV_FTM_SRAM18] = 1;
        bit[DRV_FTM_SRAM19] = 2;
        bit[DRV_FTM_SRAM20] = 3;
        bit[DRV_FTM_SRAM21] = 4;
        break;

        /* SelEdram  {edram17, edram18, edram19, edram20, edram21 } Done*/
        case DRV_FTM_SRAM_TBL_FWD:
        bit[DRV_FTM_SRAM17] = 0;
        bit[DRV_FTM_SRAM18] = 1;
        bit[DRV_FTM_SRAM19] = 2;
        bit[DRV_FTM_SRAM20] = 3;
        bit[DRV_FTM_SRAM21] = 4;
        break;


        /* SelEdram  {edram11, edram12, edram13, edram14, edram15} Done*/
        case DRV_FTM_SRAM_TBL_USERID_AD:
        bit[DRV_FTM_SRAM11]   = 0;
        bit[DRV_FTM_SRAM12]   = 1;
        bit[DRV_FTM_SRAM13]   = 2;
        bit[DRV_FTM_SRAM14]   = 3;
        bit[DRV_FTM_SRAM15]   = 4;
        break;

         /* SelEdram  {edram1, edram4} Done*/
        case DRV_FTM_SRAM_TBL_OAM_LM:
        bit[DRV_FTM_SRAM1] = 0;
        bit[DRV_FTM_SRAM4] = 1;
        break;

         /* SelEdram  {edram1, edram4} Done*/
        case DRV_FTM_SRAM_TBL_OAM_MEP:
        bit[DRV_FTM_SRAM1] = 0;
        bit[DRV_FTM_SRAM4] = 1;
        break;

         /* SelEdram  {edram1, edram4} Done*/
        case DRV_FTM_SRAM_TBL_OAM_MA:
        bit[DRV_FTM_SRAM1] = 0;
        bit[DRV_FTM_SRAM4] = 1;
        break;

         /* SelEdram  {edram1, edram4} Done*/
        case DRV_FTM_SRAM_TBL_OAM_MA_NAME:
        bit[DRV_FTM_SRAM1] = 0;
        bit[DRV_FTM_SRAM4] = 1;
        break;


        /* NONE */
        case DRV_FTM_SRAM_TBL_FIB1_HASH_KEY:
        bit[DRV_FTM_SRAM6] = 0;
        bit[DRV_FTM_SRAM7] = 1;
        bit[DRV_FTM_SRAM8] = 2;
        bit[DRV_FTM_SRAM9] = 3;
        bit[DRV_FTM_SRAM10] = 4;
        break;

        /* NONE */
    case DRV_FTM_SRAM_TBL_FLOW_HASH_KEY:
        bit[DRV_FTM_SRAM0] = 0;
        bit[DRV_FTM_SRAM1] = 1;
        bit[DRV_FTM_SRAM2] = 2;
        bit[DRV_FTM_SRAM3] = 3;
        bit[DRV_FTM_SRAM4] = 4;
        break;

         /* NONE */
        case DRV_FTM_SRAM_TBL_OAM_APS:
        bit[DRV_FTM_SRAM10] = 0;
        break;

        /* NONE */
        case DRV_FTM_SRAM_TBL_XCOAM_HASH_KEY:
        bit[DRV_FTM_SRAM2] = 0;
        bit[DRV_FTM_SRAM5] = 0;
        break;

        /* NONE */
        case DRV_FTM_SRAM_TBL_USERID_HASH_KEY:
        bit[DRV_FTM_SRAM6] = 0;
        bit[DRV_FTM_SRAM7] = 1;
        bit[DRV_FTM_SRAM8] = 2;
        bit[DRV_FTM_SRAM9] = 3;
        bit[DRV_FTM_SRAM10] = 4;
        break;

        default:
           break;
    }

    mem_bit_map = DRV_FTM_TBL_MEM_BITMAP(sram_type);

    for (mem_id = DRV_FTM_SRAM0; mem_id < DRV_FTM_SRAM_MAX; mem_id++)
    {
        if (IS_BIT_SET(mem_bit_map, mem_id))
        {
            idx = bit[mem_id];
            SET_BIT(bit_map_temp, idx);
            sram_array[idx] = mem_id;
        }
    }

    *bitmap = bit_map_temp;

    return DRV_E_NONE;;
}

static int32
_sys_goldengate_ftm_get_hash_type(uint8 sram_type, uint32 mem_id,
                                              uint8 couple, uint32 *poly)
{
    uint8 base = 0;
    uint8 extra = 0;

    *poly = 0;

    switch (sram_type)
    {
        case DRV_FTM_SRAM_TBL_FIB0_HASH_KEY:
        /*Host0lkup ctl
         {HASH_CRC, 0x00000005, 11},
         {HASH_CRC, 0x00000017, 11},
         {HASH_CRC, 0x0000002b, 11},
         {HASH_CRC, 0x00000053, 12},
         {HASH_CRC, 0x00000099, 12},
         {HASH_CRC, 0x00000107, 12},
         {HASH_CRC, 0x0000001b, 13},
         {HASH_CRC, 0x00000027, 13},
         {HASH_CRC, 0x000000c3, 13},
         {HASH_XOR, 16        , 0},

         mem   {RAM0,RAM1,RAM2,RAM3,RAM4}
         size  :32k  32k  32k  32k  8k
         couple:64k  64k  64k  64k  16k
         DRV_FTM_SRAM0  32K/4=8K  2, 6
         DRV_FTM_SRAM1  32K/4=8K  3, 7
         DRV_FTM_SRAM2  32K/4=8K  4, 8
         DRV_FTM_SRAM3  32K/4=8K  5, 9
         DRV_FTM_SRAM4  08K/4=2K  0, 1
        */
            switch(mem_id)
            {
            case DRV_FTM_SRAM0:
                *poly = couple ? 6: 3;
                break;
            case DRV_FTM_SRAM1:
                *poly = couple ? 6: 3;
                break;
            case DRV_FTM_SRAM2:
                *poly = couple ? 6: 3;
                break;
            case DRV_FTM_SRAM3:
                *poly = couple ? 3: 0;
                break;
            case DRV_FTM_SRAM4:
                *poly = couple ? 3: 0;
                break;
            case DRV_FTM_SRAM5:
                *poly = couple ? 3: 0;
                break;

            }

            break;

        case DRV_FTM_SRAM_TBL_FIB1_HASH_KEY:
        /*Host1lkup ctl
         {HASH_CRC, 0x00000011, 9},
         {HASH_CRC, 0x0000001b, 10},
         {HASH_CRC, 0x00000027, 10},
         {HASH_CRC, 0x00000005, 11},
         {HASH_CRC, 0x00000017, 11},
         {HASH_CRC, 0x0000002b, 11},
         {HASH_CRC, 0x00000053, 12},
         {HASH_CRC, 0x00000099, 12},
         {HASH_CRC, 0x00000107, 12},
         {HASH_XOR, 16        , 0},

         mem   {RAM0,RAM5,RAM6}
         size  :32k  16k  16k
         couple:64k  32k  32k
         DRV_FTM_SRAM0  32K/4=8K  2, 4
         DRV_FTM_SRAM5  16K/4=4K  0, 2
         DRV_FTM_SRAM6  16K/4=4K  1, 3
         */
            switch(mem_id)
            {
            case DRV_FTM_SRAM6:
                *poly = couple ? 6: 3;
                break;
            case DRV_FTM_SRAM7:
                *poly = couple ? 6: 3;
                break;
            case DRV_FTM_SRAM8:
                *poly = couple ? 3: 1;
                break;
            case DRV_FTM_SRAM9:
                *poly = couple ? 3: 1;
                break;
            case DRV_FTM_SRAM10:
                *poly = couple ? 1: 0;
                break;
            }
            break;

        case DRV_FTM_SRAM_TBL_FLOW_HASH_KEY:
        /*Flow lkup ctl
         {HASH_CRC, 0x00000005, 11},
         {HASH_CRC, 0x00000017, 11},
         {HASH_CRC, 0x0000002b, 11},
         {HASH_CRC, 0x00000053, 12},
         {HASH_CRC, 0x00000099, 12},
         {HASH_CRC, 0x00000107, 12},
         {HASH_CRC, 0x0000001b, 13},
         {HASH_CRC, 0x00000027, 13},
         {HASH_CRC, 0x000000c3, 13},
         {HASH_XOR, 16        , 0},

         mem   {RAM0,RAM1,RAM2,RAM3,RAM4}
         size  :32k  32k  32k  32k  8k
         couple:64k  64k  64k  64k  16k

         DRV_FTM_SRAM0  32K/4=8K  2, 6
         DRV_FTM_SRAM1  32K/4=8K  3, 7
         DRV_FTM_SRAM2  32K/4=8K  4, 8
         DRV_FTM_SRAM3  32K/4=8K  5, 9
         DRV_FTM_SRAM4  08K/4=2K  0, 1
        */
            switch(mem_id)
            {
            case DRV_FTM_SRAM0:
                *poly = couple ? 6: 3;
                break;
            case DRV_FTM_SRAM1:
                *poly = couple ? 6: 3;
                break;
            case DRV_FTM_SRAM2:
                *poly = couple ? 6: 3;
                break;
            case DRV_FTM_SRAM3:
                *poly = couple ? 3: 0;
                break;
            case DRV_FTM_SRAM4:
                *poly = couple ? 3: 0;
                break;
            case DRV_FTM_SRAM5:
                *poly = couple ? 3: 0;
                break;
            }
            break;

        case DRV_FTM_SRAM_TBL_IPFIX_HASH_KEY:
        /*
         {HASH_CRC, 0x0000001b, 10},
         {HASH_CRC, 0x00000027, 10},
         {HASH_CRC, 0x00000005, 11},
         {HASH_CRC, 0x00000017, 11},
         {HASH_CRC, 0x00000053, 12},
         {HASH_CRC, 0x00000107, 12},
     */
            switch(mem_id)
            {
            case DRV_FTM_SRAM0:
                *poly = couple ? 4: 2;
                break;
            case DRV_FTM_SRAM5:
                *poly = couple ? 2: 0;
                break;

            }
            break;

        case DRV_FTM_SRAM_TBL_USERID_HASH_KEY:
        /*userid  lkup ctl
         {HASH_CRC, 0x00000011, 9},
         {HASH_CRC, 0x0000001b, 10},
         {HASH_CRC, 0x00000027, 10},
         {HASH_CRC, 0x00000005, 11},
         {HASH_CRC, 0x00000017, 11},
         {HASH_CRC, 0x0000002b, 11},
         {HASH_CRC, 0x00000053, 12},
         {HASH_CRC, 0x00000099, 12},
         {HASH_CRC, 0x00000107, 12},
         {HASH_XOR, 16        , 0},

         mem   {RAM2,RAM11,RAM3,RAM12}
         size  :32k  8k    32k  8k
         couple:64k  16k   64k  16k

         DRV_FTM_SRAM2   32K/4=8K  4, 6
         DRV_FTM_SRAM3   32K/4=8K  5, 7
         DRV_FTM_SRAM11  08K/4=2K  0, 2
         DRV_FTM_SRAM12  08K/4=2K  1, 3
        */
            switch(mem_id)
            {
            case DRV_FTM_SRAM6:
                *poly = couple ? 6: 3;
                break;
            case DRV_FTM_SRAM7:
                *poly = couple ? 6: 3;
                break;
            case DRV_FTM_SRAM8:
                *poly = couple ? 3: 1;
                break;
            case DRV_FTM_SRAM9:
                *poly = couple ? 3: 1;
                break;
            case DRV_FTM_SRAM10:
                *poly = couple ? 1: 0;
                break;
            }
            break;

        case DRV_FTM_SRAM_TBL_XCOAM_HASH_KEY:
        /*XcOamUserid  lkup ctl
         {HASH_CRC, 0x00000005, 11},
         {HASH_CRC, 0x00000053, 12},
         {HASH_CRC, 0x0000001b, 13},
         {HASH_XOR, 16        , 0},

         mem   {RAM17,RAM7,RAM8, RAM2}
         size  :32k  8k    16k   16K
         couple:64k  16k   32k   32k

         DRV_FTM_SRAM17   32K/4=8K  1, 3
         DRV_FTM_SRAM7    32K/4=8K  2, 4
         DRV_FTM_SRAM8    16K/4=4K  0, 1
        */

            switch(mem_id)
            {
            case DRV_FTM_SRAM2:
                *poly = couple ?(extra?3:2): (extra?1:1);
                break;
            case DRV_FTM_SRAM5:
                *poly = couple ? (extra?4:1): (extra?2:0);
                break;
            }
            break;

    }
    return DRV_E_NONE;
}


tbls_ext_info_t*
drv_ftm_build_dynamic_tbl_info()
{
    tbls_ext_info_t* p_tbl_ext_info = NULL;
    dynamic_mem_ext_content_t* p_dyn_mem_ext_info = NULL;

    p_tbl_ext_info = mem_malloc(MEM_FTM_MODULE, sizeof(tbls_ext_info_t));
    if (NULL == p_tbl_ext_info)
    {
        return NULL;
    }

    sal_memset(p_tbl_ext_info, 0, sizeof(tbls_ext_info_t));

    p_dyn_mem_ext_info = mem_malloc(MEM_FTM_MODULE, sizeof(dynamic_mem_ext_content_t));
    if (NULL == p_dyn_mem_ext_info)
    {
        mem_free(p_tbl_ext_info);
        return NULL;
    }

    sal_memset(p_dyn_mem_ext_info, 0, sizeof(dynamic_mem_ext_content_t));

    p_tbl_ext_info->ptr_ext_content = p_dyn_mem_ext_info;

    return p_tbl_ext_info;

}

static int32
drv_ftm_alloc_dyn_share_tbl(uint8 sram_type,
                                       uint32 tbl_id)
{
    uint32 bitmap = 0;
    uint32 sram_array[5] = {0};
    uint8   bit_idx = 0;

    uint32 mem_entry_num = 0;
    uint32 max_index_num = 0;
    uint32 start_index = 0;
    uint32 end_index = 0;

    uint32 start_base = 0;
    uint32 end_base = 0;
    uint32 entry_num = 0;

    uint32 hw_base = 0;
    uint32 tbl_offset = 0;
    int8 mem_id = 0;
    uint8 is_mep = 0;
    uint32 hw_addr_base_offset_slice0 = 0, hw_addr_base_offset_slice1 = 0;

    dynamic_mem_ext_content_t* p_dyn_mem_ext_info = NULL;
    tbls_ext_info_t* p_tbl_ext_info = NULL;

    is_mep      = (DRV_FTM_SRAM_TBL_OAM_MEP == sram_type);

    p_tbl_ext_info = drv_ftm_build_dynamic_tbl_info();
    if (NULL == p_tbl_ext_info)
    {
        return DRV_E_NO_MEMORY;
    }

    if (0 == DRV_FTM_TBL_MAX_ENTRY_NUM(sram_type))
    {
        return DRV_E_NONE;
    }

    p_dyn_mem_ext_info = p_tbl_ext_info->ptr_ext_content;


    TABLE_EXT_INFO_PTR(tbl_id) = p_tbl_ext_info;
    TABLE_EXT_INFO_TYPE(tbl_id) = EXT_INFO_TYPE_DYNAMIC;

    p_dyn_mem_ext_info->dynamic_access_mode = DYNAMIC_DEFAULT;

    if (DRV_FTM_TBL_ACCESS_FLAG(sram_type))
    {
        if (TABLE_ENTRY_SIZE(tbl_id) == (4 * DRV_BYTES_PER_ENTRY))
        {
            p_dyn_mem_ext_info->dynamic_access_mode = DYNAMIC_16W_MODE;
        }
        else if (TABLE_ENTRY_SIZE(tbl_id) == (2 * DRV_BYTES_PER_ENTRY))
        {
            p_dyn_mem_ext_info->dynamic_access_mode = DYNAMIC_8W_MODE;
        }
        else if (TABLE_ENTRY_SIZE(tbl_id) == DRV_BYTES_PER_ENTRY)
        {
            p_dyn_mem_ext_info->dynamic_access_mode = DYNAMIC_4W_MODE;
        }
    }

    DYNAMIC_BITMAP(tbl_id) = DRV_FTM_TBL_MEM_BITMAP(sram_type);
    /* SDK��memid��оƬ�Ĳ�һ��˳��,���е���; */
    _sys_goldengate_ftm_get_edram_bitmap(sram_type,   &bitmap,   sram_array);
    //-bitmap = DYNAMIC_BITMAP(tbl_id);

    for (bit_idx = 0; bit_idx < 6; bit_idx++)
    {
        if (!IS_BIT_SET(bitmap, bit_idx))
        {
            continue;
        }

        mem_id = sram_array[bit_idx];
        mem_entry_num = DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, mem_id);

        if (TABLE_ENTRY_SIZE(tbl_id) == (4 * DRV_BYTES_PER_ENTRY))
        {
            hw_base = DRV_FTM_MEM_HW_DATA_BASE12W(mem_id);
        }
        else if (TABLE_ENTRY_SIZE(tbl_id) == (2 * DRV_BYTES_PER_ENTRY))
        {
            hw_base = DRV_FTM_MEM_HW_DATA_BASE6W(mem_id);
        }
        else if (TABLE_ENTRY_SIZE(tbl_id) == DRV_BYTES_PER_ENTRY)
        {
            hw_base = DRV_FTM_MEM_HW_DATA_BASE(mem_id);
        }

/* begin cmode defult 3W base --by xuwj */
if(!hw_base)
{
    hw_base = DRV_FTM_MEM_HW_DATA_BASE(mem_id);
}
/* end   cmode defult 3W base --by xuwj */

        hw_addr_base_offset_slice0 = hw_base - DYNAMIC_SLICE0_ADDR_BASE_OFFSET_TO_DUP;
        hw_addr_base_offset_slice1 = hw_base - DYNAMIC_SLICE1_ADDR_BASE_OFFSET_TO_DUP;


#if (SDK_WORK_PLATFORM == 1)
        hw_base = DRV_FTM_MEM_HW_DATA_BASE(mem_id);
#else

        if (TABLE_ENTRY_SIZE(tbl_id) == (4 * DRV_BYTES_PER_ENTRY))
        {
            hw_base = DRV_FTM_MEM_HW_DATA_BASE12W(mem_id);
        }
        else if (TABLE_ENTRY_SIZE(tbl_id) == (2 * DRV_BYTES_PER_ENTRY))
        {
            hw_base = DRV_FTM_MEM_HW_DATA_BASE6W(mem_id);
        }
        else if (TABLE_ENTRY_SIZE(tbl_id) == DRV_BYTES_PER_ENTRY)
        {
            hw_base = DRV_FTM_MEM_HW_DATA_BASE(mem_id);
        }
#endif

        DYNAMIC_ENTRY_NUM(tbl_id, mem_id) = mem_entry_num;
        tbl_offset = DRV_FTM_TBL_MEM_START_OFFSET(sram_type, mem_id);


#if (0 == SDK_WORK_PLATFORM)
        /*
CPU indirect access to mep tables */
        if (is_mep)
        {
            DYNAMIC_DATA_BASE(tbl_id, mem_id, 0) = OAM_DS_MP_DATA_ADDR + tbl_offset * DRV_ADDR_BYTES_PER_ENTRY;
        }
        else
#endif
       {
            is_mep = is_mep;
            DYNAMIC_DATA_BASE(tbl_id, mem_id, 0) = hw_base + tbl_offset* DRV_ADDR_BYTES_PER_ENTRY;
            DYNAMIC_DATA_BASE(tbl_id, mem_id, 1) = hw_addr_base_offset_slice0 + tbl_offset* DRV_ADDR_BYTES_PER_ENTRY;
            DYNAMIC_DATA_BASE(tbl_id, mem_id, 2) = hw_addr_base_offset_slice1 + tbl_offset* DRV_ADDR_BYTES_PER_ENTRY;
        }

        start_index = max_index_num; /*per key index*/
        start_base = entry_num; /*per 80bit base*/
        entry_num += mem_entry_num;

        if (DRV_FTM_TBL_ACCESS_FLAG(sram_type))
        {
            max_index_num += mem_entry_num;
        }
        else
        {
            max_index_num += mem_entry_num * DRV_BYTES_PER_ENTRY / TABLE_ENTRY_SIZE(tbl_id);
        }

        end_index = (max_index_num - 1);
        end_base = entry_num - 1;

        DYNAMIC_START_INDEX(tbl_id, mem_id) = start_index;
        DYNAMIC_END_INDEX(tbl_id, mem_id) = end_index;

        DRV_FTM_TBL_BASE_VAL(sram_type, bit_idx) = tbl_offset;
        DRV_FTM_TBL_BASE_MIN(sram_type, bit_idx) = start_base;
        DRV_FTM_TBL_BASE_MAX(sram_type, bit_idx) = end_base;


    }

    TABLE_MAX_INDEX(tbl_id) = max_index_num;
    DRV_FTM_TBL_BASE_BITMAP(sram_type) = bitmap;


    for (bit_idx = 0; bit_idx < 5; bit_idx++)
    {
        if (IS_BIT_SET(bitmap, bit_idx))
        {
            mem_id = sram_array[bit_idx];
            TABLE_DATA_BASE(tbl_id, 0) = DYNAMIC_DATA_BASE(tbl_id, mem_id, 0);
            break;
        }
    }


    return DRV_E_NONE;
}



static int32
drv_ftm_alloc_sram()
{
    uint8 index = 0;
    uint32 sram_type = 0;
    uint32 sram_tbl_id = MaxTblId_t;
    uint32 sram_tbl_a[60] = {0};
    uint8 share_tbl_num  = 0;
    uint32 max_entry_num = 0;

    for (sram_type = 0; sram_type < DRV_FTM_SRAM_TBL_MAX; sram_type++)
    {
        max_entry_num = DRV_FTM_TBL_MAX_ENTRY_NUM(sram_type);
        if (0 == max_entry_num)
        {
            continue;
        }

        _drv_ftm_get_sram_tbl_id(sram_type,
                                           sram_tbl_a,
                                           &share_tbl_num);

        for (index = 0; index < share_tbl_num; index++)
        {
            sram_tbl_id = sram_tbl_a[index];

            if (sram_tbl_id >= MaxTblId_t)
            {
                DRV_FTM_DBG_DUMP("unexpect tbl id:%d\r\n", sram_tbl_id);
                return DRV_E_INVAILD_TYPE;
            }

            DRV_IF_ERROR_RETURN(drv_ftm_alloc_dyn_share_tbl(sram_type, sram_tbl_id));
        }

        index = 0;

    }

    return DRV_E_NONE;
}

#define ____change_table_config
static int32
drv_ftm_get_tcam_info(uint32 tcam_key_type,
                                 uint32* p_tcam_key_id,
                                 uint32* p_tcam_ad_tbl,
                                 uint8* p_key_share_num,
                                 uint8* p_ad_share_num)
{
    uint8 idx0 = 0;
    uint8 idx1 = 0;

    DRV_PTR_VALID_CHECK(p_tcam_key_id);
    DRV_PTR_VALID_CHECK(p_tcam_ad_tbl);
    DRV_PTR_VALID_CHECK(p_key_share_num);
    DRV_PTR_VALID_CHECK(p_ad_share_num);

    switch (tcam_key_type)
    {
    case DRV_FTM_TCAM_TYPE_IGS_ACL0:
        p_tcam_key_id[idx0++] = DsAclQosForwardKey320Ing0_t;
        p_tcam_key_id[idx0++] = DsAclQosForwardKey640Ing0_t;
        p_tcam_key_id[idx0++] = DsAclQosKey80Ing0_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key320Ing0_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key640Ing0_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key160Ing0_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key320Ing0_t;
        p_tcam_key_id[idx0++] = DsAclQosMacIpv6Key640Ing0_t;
        p_tcam_key_id[idx0++] = DsAclQosMacKey160Ing0_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key320Ing0_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key640Ing0_t;
        p_tcam_key_id[idx0++] = DsAclQosCidKey160Ing0_t;

        p_tcam_ad_tbl[idx1++] = DsAcl0Ingress_t;
        p_tcam_ad_tbl[idx1++] = DsAcl0HalfIngress_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl0ForwardBasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl0ForwardExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl0IpfixEnableTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl0Ipv6BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl0Ipv6ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl0L3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl0L3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl0MacIpv6TcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl0MacL3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl0MacL3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl0MacTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl0SgtTcamAd_t;

       //- p_tcam_ad_tbl[idx1++] = DsTcam0_t;
        break;

    case DRV_FTM_TCAM_TYPE_IGS_ACL1:
        p_tcam_key_id[idx0++] = DsAclQosForwardKey320Ing1_t;
        p_tcam_key_id[idx0++] = DsAclQosForwardKey640Ing1_t;
        p_tcam_key_id[idx0++] = DsAclQosKey80Ing1_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key320Ing1_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key640Ing1_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key160Ing1_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key320Ing1_t;
        p_tcam_key_id[idx0++] = DsAclQosMacIpv6Key640Ing1_t;
        p_tcam_key_id[idx0++] = DsAclQosMacKey160Ing1_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key320Ing1_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key640Ing1_t;
        p_tcam_key_id[idx0++] = DsAclQosCidKey160Ing1_t;

        p_tcam_ad_tbl[idx1++] = DsAcl1Ingress_t;
        p_tcam_ad_tbl[idx1++] = DsAcl1HalfIngress_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl1ForwardBasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl1ForwardExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl1IpfixEnableTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl1Ipv6BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl1Ipv6ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl1L3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl1L3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl1MacIpv6TcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl1MacL3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl1MacL3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl1MacTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl1SgtTcamAd_t;
        break;

    case DRV_FTM_TCAM_TYPE_IGS_ACL2:
        p_tcam_key_id[idx0++] = DsAclQosForwardKey320Ing2_t;
        p_tcam_key_id[idx0++] = DsAclQosForwardKey640Ing2_t;
        p_tcam_key_id[idx0++] = DsAclQosKey80Ing2_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key320Ing2_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key640Ing2_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key160Ing2_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key320Ing2_t;
        p_tcam_key_id[idx0++] = DsAclQosMacIpv6Key640Ing2_t;
        p_tcam_key_id[idx0++] = DsAclQosMacKey160Ing2_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key320Ing2_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key640Ing2_t;
        p_tcam_key_id[idx0++] = DsAclQosCidKey160Ing2_t;

        p_tcam_ad_tbl[idx1++] = DsAcl2Ingress_t;
        p_tcam_ad_tbl[idx1++] = DsAcl2HalfIngress_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl2ForwardBasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl2ForwardExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl2IpfixEnableTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl2Ipv6BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl2Ipv6ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl2L3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl2L3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl2MacIpv6TcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl2MacL3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl2MacL3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl2MacTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl2SgtTcamAd_t;
        break;

    case DRV_FTM_TCAM_TYPE_IGS_ACL3:
        p_tcam_key_id[idx0++] = DsAclQosForwardKey320Ing3_t;
        p_tcam_key_id[idx0++] = DsAclQosForwardKey640Ing3_t;
        p_tcam_key_id[idx0++] = DsAclQosKey80Ing3_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key320Ing3_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key640Ing3_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key160Ing3_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key320Ing3_t;
        p_tcam_key_id[idx0++] = DsAclQosMacIpv6Key640Ing3_t;
        p_tcam_key_id[idx0++] = DsAclQosMacKey160Ing3_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key320Ing3_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key640Ing3_t;
        p_tcam_key_id[idx0++] = DsAclQosCidKey160Ing3_t;

        p_tcam_ad_tbl[idx1++] = DsAcl3Ingress_t;
        p_tcam_ad_tbl[idx1++] = DsAcl3HalfIngress_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl3ForwardBasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl3ForwardExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl3IpfixEnableTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl3Ipv6BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl3Ipv6ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl3L3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl3L3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl3MacIpv6TcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl3MacL3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl3MacL3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl3MacTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl3SgtTcamAd_t;
        break;

    case DRV_FTM_TCAM_TYPE_IGS_ACL4:
        p_tcam_key_id[idx0++] = DsAclQosForwardKey320Ing4_t;
        p_tcam_key_id[idx0++] = DsAclQosForwardKey640Ing4_t;
        p_tcam_key_id[idx0++] = DsAclQosKey80Ing4_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key320Ing4_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key640Ing4_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key160Ing4_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key320Ing4_t;
        p_tcam_key_id[idx0++] = DsAclQosMacIpv6Key640Ing4_t;
        p_tcam_key_id[idx0++] = DsAclQosMacKey160Ing4_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key320Ing4_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key640Ing4_t;
        p_tcam_key_id[idx0++] = DsAclQosCidKey160Ing4_t;

        p_tcam_ad_tbl[idx1++] = DsAcl4Ingress_t;
        p_tcam_ad_tbl[idx1++] = DsAcl4HalfIngress_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl4ForwardBasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl4ForwardExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl4IpfixEnableTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl4Ipv6BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl4Ipv6ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl4L3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl4L3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl4MacIpv6TcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl4MacL3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl4MacL3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl4MacTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl4SgtTcamAd_t;
        break;

    case DRV_FTM_TCAM_TYPE_IGS_ACL5:
        p_tcam_key_id[idx0++] = DsAclQosForwardKey320Ing5_t;
        p_tcam_key_id[idx0++] = DsAclQosForwardKey640Ing5_t;
        p_tcam_key_id[idx0++] = DsAclQosKey80Ing5_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key320Ing5_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key640Ing5_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key160Ing5_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key320Ing5_t;
        p_tcam_key_id[idx0++] = DsAclQosMacIpv6Key640Ing5_t;
        p_tcam_key_id[idx0++] = DsAclQosMacKey160Ing5_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key320Ing5_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key640Ing5_t;
        p_tcam_key_id[idx0++] = DsAclQosCidKey160Ing5_t;

        p_tcam_ad_tbl[idx1++] = DsAcl5Ingress_t;
        p_tcam_ad_tbl[idx1++] = DsAcl5HalfIngress_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl5ForwardBasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl5ForwardExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl5IpfixEnableTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl5Ipv6BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl5Ipv6ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl5L3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl5L3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl5MacIpv6TcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl5MacL3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl5MacL3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl5MacTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl5SgtTcamAd_t;
        break;
    case DRV_FTM_TCAM_TYPE_IGS_ACL6:
        p_tcam_key_id[idx0++] = DsAclQosForwardKey320Ing6_t;
        p_tcam_key_id[idx0++] = DsAclQosForwardKey640Ing6_t;
        p_tcam_key_id[idx0++] = DsAclQosKey80Ing6_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key320Ing6_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key640Ing6_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key160Ing6_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key320Ing6_t;
        p_tcam_key_id[idx0++] = DsAclQosMacIpv6Key640Ing6_t;
        p_tcam_key_id[idx0++] = DsAclQosMacKey160Ing6_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key320Ing6_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key640Ing6_t;
        p_tcam_key_id[idx0++] = DsAclQosCidKey160Ing6_t;

        p_tcam_ad_tbl[idx1++] = DsAcl6Ingress_t;
        p_tcam_ad_tbl[idx1++] = DsAcl6HalfIngress_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl6ForwardBasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl6ForwardExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl6IpfixEnableTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl6Ipv6BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl6Ipv6ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl6L3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl6L3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl6MacIpv6TcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl6MacL3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl6MacL3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl6MacTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl6SgtTcamAd_t;
        break;
    case DRV_FTM_TCAM_TYPE_IGS_ACL7:
        p_tcam_key_id[idx0++] = DsAclQosForwardKey320Ing7_t;
        p_tcam_key_id[idx0++] = DsAclQosForwardKey640Ing7_t;
        p_tcam_key_id[idx0++] = DsAclQosKey80Ing7_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key320Ing7_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key640Ing7_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key160Ing7_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key320Ing7_t;
        p_tcam_key_id[idx0++] = DsAclQosMacIpv6Key640Ing7_t;
        p_tcam_key_id[idx0++] = DsAclQosMacKey160Ing7_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key320Ing7_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key640Ing7_t;
        p_tcam_key_id[idx0++] = DsAclQosCidKey160Ing7_t;

        p_tcam_ad_tbl[idx1++] = DsAcl7Ingress_t;
        p_tcam_ad_tbl[idx1++] = DsAcl7HalfIngress_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl7ForwardBasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl7ForwardExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl7IpfixEnableTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl7Ipv6BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl7Ipv6ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl7L3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl7L3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl7MacIpv6TcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl7MacL3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl7MacL3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl7MacTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsIngAcl7SgtTcamAd_t;
        break;

    case DRV_FTM_TCAM_TYPE_EGS_ACL0:
        p_tcam_key_id[idx0++] = DsAclQosKey80Egr0_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key320Egr0_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key640Egr0_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key160Egr0_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key320Egr0_t;
        p_tcam_key_id[idx0++] = DsAclQosMacIpv6Key640Egr0_t;
        p_tcam_key_id[idx0++] = DsAclQosMacKey160Egr0_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key320Egr0_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key640Egr0_t;


        p_tcam_ad_tbl[idx1++] = DsAcl0Egress_t;
        p_tcam_ad_tbl[idx1++] = DsAcl0HalfEgress_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl0IpfixEnableTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl0Ipv6BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl0Ipv6ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl0L3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl0L3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl0MacIpv6TcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl0MacTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl0MacL3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl0MacL3ExtTcamAd_t;
        break;
    case DRV_FTM_TCAM_TYPE_EGS_ACL1:
        p_tcam_key_id[idx0++] = DsAclQosKey80Egr1_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key320Egr1_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key640Egr1_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key160Egr1_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key320Egr1_t;
        p_tcam_key_id[idx0++] = DsAclQosMacIpv6Key640Egr1_t;
        p_tcam_key_id[idx0++] = DsAclQosMacKey160Egr1_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key320Egr1_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key640Egr1_t;

        p_tcam_ad_tbl[idx1++] = DsAcl1Egress_t;
        p_tcam_ad_tbl[idx1++] = DsAcl1HalfEgress_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl1IpfixEnableTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl1Ipv6BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl1Ipv6ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl1L3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl1L3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl1MacIpv6TcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl1MacTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl1MacL3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl1MacL3ExtTcamAd_t;
        break;
    case DRV_FTM_TCAM_TYPE_EGS_ACL2:
        p_tcam_key_id[idx0++] = DsAclQosKey80Egr2_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key320Egr2_t;
        p_tcam_key_id[idx0++] = DsAclQosIpv6Key640Egr2_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key160Egr2_t;
        p_tcam_key_id[idx0++] = DsAclQosL3Key320Egr2_t;
        p_tcam_key_id[idx0++] = DsAclQosMacIpv6Key640Egr2_t;
        p_tcam_key_id[idx0++] = DsAclQosMacKey160Egr2_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key320Egr2_t;
        p_tcam_key_id[idx0++] = DsAclQosMacL3Key640Egr2_t;

        p_tcam_ad_tbl[idx1++] = DsAcl2Egress_t;
        p_tcam_ad_tbl[idx1++] = DsAcl2HalfEgress_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl2IpfixEnableTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl2Ipv6BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl2Ipv6ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl2L3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl2L3ExtTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl2MacIpv6TcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl2MacTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl2MacL3BasicTcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsEgrAcl2MacL3ExtTcamAd_t;
        break;


    case DRV_FTM_TCAM_TYPE_IGS_USERID0:
        p_tcam_key_id[idx0++] = DsUserId0TcamKey80_t;
        p_tcam_key_id[idx0++] = DsScl0MacKey160_t;
        p_tcam_key_id[idx0++] = DsScl0L3Key160_t;
        p_tcam_key_id[idx0++] = DsScl0Ipv6Key320_t;
        p_tcam_key_id[idx0++] = DsScl0MacL3Key320_t;
        p_tcam_key_id[idx0++] = DsScl0MacIpv6Key640_t;
        p_tcam_key_id[idx0++] = DsUserId0TcamKey160_t;
        p_tcam_key_id[idx0++] = DsUserId0TcamKey320_t;

        p_tcam_ad_tbl[idx1++] = DsUserId0Tcam_t;
        p_tcam_ad_tbl[idx1++] = DsTunnelId0Tcam_t;
        p_tcam_ad_tbl[idx1++] = DsSclFlow0Tcam_t;
        p_tcam_ad_tbl[idx1++] = DsUserIdTcam160Ad0_t;
        //-p_tcam_ad_tbl[idx1++] = DsUserId0Mac160TcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsUserIdTcam320Ad0_t;
        //-p_tcam_ad_tbl[idx1++] = DsUserIdTcam640Ad0_t;
        break;

    case DRV_FTM_TCAM_TYPE_IGS_USERID1:
        p_tcam_key_id[idx0++] = DsUserId1TcamKey80_t;
        p_tcam_key_id[idx0++] = DsScl1MacKey160_t;
        p_tcam_key_id[idx0++] = DsScl1L3Key160_t;
        p_tcam_key_id[idx0++] = DsScl1Ipv6Key320_t;
        p_tcam_key_id[idx0++] = DsScl1MacL3Key320_t;
        p_tcam_key_id[idx0++] = DsScl1MacIpv6Key640_t;
        p_tcam_key_id[idx0++] = DsUserId1TcamKey160_t;
        p_tcam_key_id[idx0++] = DsUserId1TcamKey320_t;

        p_tcam_ad_tbl[idx1++] = DsUserId1Tcam_t;
        p_tcam_ad_tbl[idx1++] = DsTunnelId1Tcam_t;
        p_tcam_ad_tbl[idx1++] = DsSclFlow1Tcam_t;
        p_tcam_ad_tbl[idx1++] = DsUserIdTcam160Ad1_t;
        //-p_tcam_ad_tbl[idx1++] = DsUserId1Mac160TcamAd_t;
        p_tcam_ad_tbl[idx1++] = DsUserIdTcam320Ad1_t;
        //-p_tcam_ad_tbl[idx1++] = DsUserIdTcam640Ad1_t;
        break;

    /*Private all (lookup 0 and 1)*/
    case DRV_FTM_TCAM_TYPE_IGS_LPM0_ALL:
        p_tcam_key_id[idx0++] = DsLpmTcamIpv4HalfKey_t;
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6DoubleKey0_t;

        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6DoubleKey0Ad_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv4HalfKeyAd_t;
        break;

    /*Public all (lookup 0 and 1)*/
    case DRV_FTM_TCAM_TYPE_IGS_LPM0_PUB_ALL:
        p_tcam_key_id[idx0++] = DsLpmTcamIpv4DaPubHalfKey_t;
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6DaPubDoubleKey0_t;

        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv4DaPubRouteKeyAd_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6DaPubDoubleKey0Ad_t;
        break;

    /*Pirvate 0 Da*/
    case DRV_FTM_TCAM_TYPE_IGS_LPM0:
        p_tcam_key_id[idx0++] = DsLpmTcamIpv4HalfKeyLookup1_t;
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6SingleKey_t;
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6DoubleKey0Lookup1_t;

        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6DoubleKey0AdLookup1_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv4HalfKeyAdLookup1_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6SingleKeyAd_t;
        break;

    /*Pirvate 0 Sa*/
    case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI:
        p_tcam_key_id[idx0++] = DsLpmTcamIpv4SaHalfKeyLookup1_t;
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6SaSingleKey_t;
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6SaDoubleKey0Lookup1_t;

        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6SaDoubleKey0AdLookup1_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv4SaHalfKeyAdLookup1_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6SaSingleKeyAd_t;
        break;

    /*Public 0 Da*/
    case DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB:
        p_tcam_key_id[idx0++] = DsLpmTcamIpv4DaPubHalfKeyLookup1_t;
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6DaPubSingleKey_t;
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6DaPubDoubleKey0Lookup1_t;

        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6DaPubDoubleKey0AdLookup1_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv4DaPubHalfKeyAdLookup1_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6DaPubSingleKeyAd_t;
        break;
    case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB:
        p_tcam_key_id[idx0++] = DsLpmTcamIpv4SaPubHalfKeyLookup1_t;
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6SaPubSingleKey_t;
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6SaPubDoubleKey0Lookup1_t;

        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6SaPubDoubleKey0AdLookup1_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv4SaPubHalfKeyAdLookup1_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6SaPubSingleKeyAd_t;
        break;

    case DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2:
        p_tcam_key_id[idx0++] = DsLpmTcamIpv4HalfKeyLookup2_t;
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6DoubleKey0Lookup2_t;

        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6DoubleKey0AdLookup2_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv4HalfKeyAdLookup2_t;
        break;
    case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI_LK2:
        p_tcam_key_id[idx0++] = DsLpmTcamIpv4SaHalfKeyLookup2_t;
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6SaDoubleKey0Lookup2_t;

        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6SaDoubleKey0AdLookup2_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv4SaHalfKeyAdLookup2_t;
        break;
    case DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2:
        p_tcam_key_id[idx0++] = DsLpmTcamIpv4DaPubHalfKeyLookup2_t;
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6DaPubDoubleKey0Lookup2_t;

        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6DaPubDoubleKey0AdLookup2_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv4DaPubHalfKeyAdLookup2_t;
        break;
    case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB_LK2:
        p_tcam_key_id[idx0++] = DsLpmTcamIpv4SaPubHalfKeyLookup2_t;
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6SaPubDoubleKey0Lookup2_t;

        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6SaPubDoubleKey0AdLookup2_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv4SaPubHalfKeyAdLookup2_t;
        break;

    case DRV_FTM_TCAM_TYPE_IGS_LPM1:
        p_tcam_key_id[idx0++] = DsLpmTcamIpv4DoubleKey_t;       /* for v4 PBR/PBR */
        p_tcam_key_id[idx0++] = DsLpmTcamIpv4PbrDoubleKey_t;    /* for v4 PBR */
        p_tcam_key_id[idx0++] = DsLpmTcamIpv4NatDoubleKey_t;    /* for v4 NAT --xuwj */
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6QuadKey_t;         /* for v6 PBR --xuwj */
        p_tcam_key_id[idx0++] = DsLpmTcamIpv6DoubleKey1_t;      /* for v6 NAT */

//        p_tcam_key_id[idx0++] = DsLpmTcamIpv4PbrDoubleKey_t;

        p_tcam_ad_tbl[idx1++] = DsLpmTcamAd_t;   /*special for DsLpmTcamIpv4DoubleKey_t */
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv4NatDoubleKeyAd_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv4PbrDoubleKeyAd_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6NatDoubleKeyAd_t;
        p_tcam_ad_tbl[idx1++] = DsLpmTcamIpv6PbrQuadKeyAd_t;
        break;

    case DRV_FTM_TCAM_TYPE_STATIC_TCAM:
        p_tcam_key_id[idx0++] = DsCategoryIdPairTcamKey_t;
        p_tcam_key_id[idx0++] = DsQueueMapTcamKey_t;
        break;

    default:
        return DRV_E_INVAILD_TYPE;
    }

    *p_key_share_num = idx0;
    *p_ad_share_num  = idx1;
    return DRV_E_NONE;
}


uint32
drv_ftm_alloc_tcam_key_map_szietype(uint32 tbl_id)
{
    /* Lpm NAT ����Ǵ�TCAM���и������,�������TABLEID�õ��и����������� */
    uint8 new_type = 0;
    switch (tbl_id)
    {
        case DsLpmTcamIpv4DoubleKey_t:
            new_type = DRV_FTM_TCAM_SIZE_ipv4_nat;
            break;
        case DsLpmTcamIpv4PbrDoubleKey_t:
            new_type = DRV_FTM_TCAM_SIZE_ipv4_pbr;
            break;
        case DsLpmTcamIpv4NatDoubleKey_t:
            new_type = DRV_FTM_TCAM_SIZE_ipv4_nat;
            break;
        case DsLpmTcamIpv6QuadKey_t:
            new_type = DRV_FTM_TCAM_SIZE_ipv6_pbr;
            break;
        case DsLpmTcamIpv6DoubleKey1_t:
            new_type = DRV_FTM_TCAM_SIZE_ipv6_nat;
            break;

        case DsLpmTcamIpv4HalfKeyLookup2_t:
        case DsLpmTcamIpv4HalfKeyLookup1_t:                /* for v4 lpm + tcam + prefix */
        case DsLpmTcamIpv4SaHalfKeyLookup2_t:
        case DsLpmTcamIpv4SaHalfKeyLookup1_t:
        case DsLpmTcamIpv4DaPubHalfKeyLookup2_t:
        case DsLpmTcamIpv4DaPubHalfKeyLookup1_t:
        case DsLpmTcamIpv4SaPubHalfKeyLookup2_t:
        case DsLpmTcamIpv4SaPubHalfKeyLookup1_t:
            new_type = DRV_FTM_TCAM_SIZE_halfkey;
            break;

        case DsLpmTcamIpv6DoubleKey0Lookup2_t:             /* for ipv6 tcam + chip bug */
        case DsLpmTcamIpv6DoubleKey0Lookup1_t:
        case DsLpmTcamIpv6SaDoubleKey0Lookup2_t:
        case DsLpmTcamIpv6SaDoubleKey0Lookup1_t:
        case DsLpmTcamIpv6DaPubDoubleKey0Lookup2_t:
        case DsLpmTcamIpv6DaPubDoubleKey0Lookup1_t:
        case DsLpmTcamIpv6SaPubDoubleKey0Lookup2_t:
        case DsLpmTcamIpv6SaPubDoubleKey0Lookup1_t:
            new_type = DRV_FTM_TCAM_SIZE_doublekey;
            break;

        case DsLpmTcamIpv6SingleKey_t:              /* for ipv6 prefix only */
        case DsLpmTcamIpv6SaSingleKey_t:
        case DsLpmTcamIpv6DaPubSingleKey_t:
        case DsLpmTcamIpv6SaPubSingleKey_t:
            new_type = DRV_FTM_TCAM_SIZE_singlekey;
            break;
        default:
            break;
    }
    return new_type;
}

/*
 * ����TCAM_AD�Ĵ�С�̶���,����KEY�ǲ�ͬ��,��Ҫ������AD�Ĵ�С,������ƫ������
 */
static void
drv_ftm_alloc_tcam_ad_map_to_new_word(uint32 tbl_id)
{
#define CASE_ACL_ING_AD_FIXSIZE_2_KEYSIZE_BREAK(ad,key)         \
    case DsIngAcl0##ad##TcamAd_t:                               \
    case DsIngAcl1##ad##TcamAd_t:                               \
    case DsIngAcl2##ad##TcamAd_t:                               \
    case DsIngAcl3##ad##TcamAd_t:                               \
    case DsIngAcl4##ad##TcamAd_t:                               \
    case DsIngAcl5##ad##TcamAd_t:                               \
    case DsIngAcl6##ad##TcamAd_t:                               \
    case DsIngAcl7##ad##TcamAd_t:                               \
        TCAM_KEY_SIZE(tbl_id) =                              \
            TABLE_ENTRY_SIZE(DsAclQos##key##Ing0_t);            \
        break;

#define CASE_ACL_EGR_AD_FIXSIZE_2_KEYSIZE_BREAK(ad,key)         \
    case DsEgrAcl0##ad##TcamAd_t:                               \
    case DsEgrAcl1##ad##TcamAd_t:                               \
    case DsEgrAcl2##ad##TcamAd_t:                               \
        TCAM_KEY_SIZE(tbl_id) =                              \
            TABLE_ENTRY_SIZE(DsAclQos##key##Egr0_t);            \
        break;

    switch (tbl_id)
    {

        case DsLpmTcamIpv4HalfKeyAd_t:
        case DsLpmTcamIpv4HalfKeyAdLookup1_t:
        case DsLpmTcamIpv4SaHalfKeyAdLookup1_t:
        case DsLpmTcamIpv4DaPubHalfKeyAdLookup1_t:
        case DsLpmTcamIpv4SaPubHalfKeyAdLookup1_t:
        case DsLpmTcamIpv4HalfKeyAdLookup2_t:
        case DsLpmTcamIpv4SaHalfKeyAdLookup2_t:
        case DsLpmTcamIpv4DaPubHalfKeyAdLookup2_t:
            TCAM_KEY_SIZE(tbl_id) =
                TABLE_ENTRY_SIZE(DsLpmTcamIpv4HalfKeyLookup1_t);
           break;

        case DsLpmTcamIpv6SaPubDoubleKey0Ad_t:
        case DsLpmTcamIpv6SaPubDoubleKey0AdLookup1_t:
        case DsLpmTcamIpv6DaPubDoubleKey0Ad_t:
        case DsLpmTcamIpv6DaPubDoubleKey0AdLookup1_t:
        case DsLpmTcamIpv6SaDoubleKey0Ad_t:
        case DsLpmTcamIpv6SaDoubleKey0AdLookup1_t:
        case DsLpmTcamIpv6DoubleKey0Ad_t:
        case DsLpmTcamIpv6DoubleKey0AdLookup1_t:
        case DsLpmTcamIpv6SaPubDoubleKey0AdLookup2_t:
        case DsLpmTcamIpv6DaPubDoubleKey0AdLookup2_t:
        case DsLpmTcamIpv6SaDoubleKey0AdLookup2_t:
        case DsLpmTcamIpv6DoubleKey0AdLookup2_t:
            TCAM_KEY_SIZE(tbl_id) =
                TABLE_ENTRY_SIZE(DsLpmTcamIpv6DoubleKey0Lookup1_t);
            break;

        case DsLpmTcamIpv6SingleKeyAd_t:
        case DsLpmTcamIpv6SaSingleKeyAd_t:
        case DsLpmTcamIpv6DaPubSingleKeyAd_t:
        case DsLpmTcamIpv6SaPubSingleKeyAd_t:
        case DsLpmTcamIpv4SaPubHalfKeyAdLookup2_t:
            TCAM_KEY_SIZE(tbl_id) =
                TABLE_ENTRY_SIZE(DsLpmTcamIpv6SingleKey_t);
            break;
#if 0
        case DsLpmTcamAd_t:
            TABLE_ENTRY_SIZE(tbl_id) =
                TABLE_ENTRY_SIZE(DsLpmTcamIpv4NatDoubleKey_t);
            break;
        case DsLpmTcamIpv4NatDoubleKeyAd_t:
            TABLE_ENTRY_SIZE(tbl_id) =
                TABLE_ENTRY_SIZE(DsLpmTcamIpv4NatDoubleKey_t);
            break;
#endif

        case DsLpmTcamIpv4PbrDoubleKeyAd_t:
            TCAM_KEY_SIZE(tbl_id) =
                TABLE_ENTRY_SIZE(DsLpmTcamIpv4PbrDoubleKey_t);
            break;

        case DsLpmTcamIpv6NatDoubleKeyAd_t:
            TCAM_KEY_SIZE(tbl_id) =
                TABLE_ENTRY_SIZE(DsLpmTcamIpv6DoubleKey1_t);
            break;

        case DsLpmTcamIpv6PbrQuadKeyAd_t:
            TCAM_KEY_SIZE(tbl_id) =
                TABLE_ENTRY_SIZE(DsLpmTcamIpv6QuadKey_t);
            break;

        CASE_ACL_ING_AD_FIXSIZE_2_KEYSIZE_BREAK(ForwardExt,ForwardKey640)
        CASE_ACL_ING_AD_FIXSIZE_2_KEYSIZE_BREAK(ForwardBasic,ForwardKey320)
        CASE_ACL_ING_AD_FIXSIZE_2_KEYSIZE_BREAK(IpfixEnable,Key80)
        CASE_ACL_ING_AD_FIXSIZE_2_KEYSIZE_BREAK(Ipv6Basic,Ipv6Key320)
        CASE_ACL_ING_AD_FIXSIZE_2_KEYSIZE_BREAK(Ipv6Ext,Ipv6Key640)
        CASE_ACL_ING_AD_FIXSIZE_2_KEYSIZE_BREAK(L3Basic,L3Key160)
        CASE_ACL_ING_AD_FIXSIZE_2_KEYSIZE_BREAK(L3Ext,L3Key320)
        CASE_ACL_ING_AD_FIXSIZE_2_KEYSIZE_BREAK(MacIpv6,MacIpv6Key640)
        CASE_ACL_ING_AD_FIXSIZE_2_KEYSIZE_BREAK(MacL3Basic,MacL3Key320)
        CASE_ACL_ING_AD_FIXSIZE_2_KEYSIZE_BREAK(MacL3Ext,MacL3Key640)
        CASE_ACL_ING_AD_FIXSIZE_2_KEYSIZE_BREAK(Mac,MacKey160)
        CASE_ACL_ING_AD_FIXSIZE_2_KEYSIZE_BREAK(Sgt,CidKey160)

        CASE_ACL_EGR_AD_FIXSIZE_2_KEYSIZE_BREAK(IpfixEnable,Key80)
        CASE_ACL_EGR_AD_FIXSIZE_2_KEYSIZE_BREAK(Ipv6Basic,Ipv6Key320)
        CASE_ACL_EGR_AD_FIXSIZE_2_KEYSIZE_BREAK(Ipv6Ext,Ipv6Key640)
        CASE_ACL_EGR_AD_FIXSIZE_2_KEYSIZE_BREAK(L3Basic,L3Key160)
        CASE_ACL_EGR_AD_FIXSIZE_2_KEYSIZE_BREAK(L3Ext,L3Key320)
        CASE_ACL_EGR_AD_FIXSIZE_2_KEYSIZE_BREAK(MacIpv6,MacIpv6Key640)
        CASE_ACL_EGR_AD_FIXSIZE_2_KEYSIZE_BREAK(Mac,MacKey160)
        CASE_ACL_EGR_AD_FIXSIZE_2_KEYSIZE_BREAK(MacL3Basic,MacL3Key320)
        CASE_ACL_EGR_AD_FIXSIZE_2_KEYSIZE_BREAK(MacL3Ext,MacL3Key640)
        default:
            break;
    }
#undef CASE_ACL_ING_AD_FIXSIZE_2_KEYSIZE_BREAK
#undef CASE_ACL_EGR_AD_FIXSIZE_2_KEYSIZE_BREAK
}

static int32
drv_ftm_get_tcam_ad_by_size_type(uint8 tcam_key_type,
                                        uint8 size_type,
                                        uint32 *p_ad_share_tbl,
                                        uint8* p_ad_share_num)
{
#define DRV_FTM_TCAM_ACL_ING_AD_MAP(acl_id)                 \
        {                                                   \
            if (DRV_FTM_TCAM_SIZE_80 == size_type)          \
            {                                               \
                p_ad_share_tbl[idx0++] =                    \
                    DsIngAcl##acl_id##SgtTcamAd_t;          \
                p_ad_share_tbl[idx0++] =                    \
                    DsIngAcl##acl_id##IpfixEnableTcamAd_t;  \
            }                                               \
            else if (DRV_FTM_TCAM_SIZE_160 == size_type)    \
            {                                               \
                p_ad_share_tbl[idx0++] =                    \
                    DsIngAcl##acl_id##L3BasicTcamAd_t;      \
                p_ad_share_tbl[idx0++] =                    \
                    DsIngAcl##acl_id##MacTcamAd_t;          \
            }                                               \
            else if(DRV_FTM_TCAM_SIZE_320 == size_type)     \
            {                                               \
                p_ad_share_tbl[idx0++] =                    \
                    DsIngAcl##acl_id##Ipv6BasicTcamAd_t;    \
                p_ad_share_tbl[idx0++] =                    \
                    DsIngAcl##acl_id##L3ExtTcamAd_t;        \
                p_ad_share_tbl[idx0++] =                    \
                    DsIngAcl##acl_id##MacL3BasicTcamAd_t;   \
                p_ad_share_tbl[idx0++] =                    \
                    DsIngAcl##acl_id##ForwardBasicTcamAd_t;    \
            }                                               \
            else if(DRV_FTM_TCAM_SIZE_640 == size_type)     \
            {                                               \
                p_ad_share_tbl[idx0++] =                    \
                    DsIngAcl##acl_id##ForwardExtTcamAd_t;  \
                p_ad_share_tbl[idx0++] =                    \
                    DsIngAcl##acl_id##Ipv6ExtTcamAd_t;      \
                p_ad_share_tbl[idx0++] =                    \
                    DsIngAcl##acl_id##MacIpv6TcamAd_t;      \
                p_ad_share_tbl[idx0++] =                    \
                    DsIngAcl##acl_id##MacL3ExtTcamAd_t;     \
            }                                               \
       }

#define DRV_FTM_TCAM_ACL_EGR_AD_MAP(acl_id)                 \
        {                                                   \
            if (DRV_FTM_TCAM_SIZE_80 == size_type)          \
            {                                               \
                p_ad_share_tbl[idx0++] =                    \
                    DsEgrAcl##acl_id##IpfixEnableTcamAd_t;  \
            }                                               \
            else if (DRV_FTM_TCAM_SIZE_160 == size_type)    \
            {                                               \
                p_ad_share_tbl[idx0++] =                    \
                    DsEgrAcl##acl_id##L3BasicTcamAd_t;      \
                p_ad_share_tbl[idx0++] =                    \
                    DsEgrAcl##acl_id##MacTcamAd_t;          \
            }                                               \
            else if(DRV_FTM_TCAM_SIZE_320 == size_type)     \
            {                                               \
                p_ad_share_tbl[idx0++] =                    \
                    DsEgrAcl##acl_id##Ipv6BasicTcamAd_t;    \
                p_ad_share_tbl[idx0++] =                    \
                    DsEgrAcl##acl_id##L3ExtTcamAd_t;        \
                p_ad_share_tbl[idx0++] =                    \
                    DsEgrAcl##acl_id##MacL3BasicTcamAd_t;   \
            }                                               \
            else if(DRV_FTM_TCAM_SIZE_640 == size_type)     \
            {                                               \
                p_ad_share_tbl[idx0++] =                    \
                    DsEgrAcl##acl_id##Ipv6ExtTcamAd_t;      \
                p_ad_share_tbl[idx0++] =                    \
                    DsEgrAcl##acl_id##MacIpv6TcamAd_t;      \
                p_ad_share_tbl[idx0++] =                    \
                    DsEgrAcl##acl_id##MacL3ExtTcamAd_t;     \
            }                                               \
       }

    uint8 idx0 = 0;

    DRV_PTR_VALID_CHECK(p_ad_share_tbl);
    DRV_PTR_VALID_CHECK(p_ad_share_num);

    switch (tcam_key_type)
    {

    case DRV_FTM_TCAM_TYPE_IGS_ACL0:
        DRV_FTM_TCAM_ACL_ING_AD_MAP(0);
        break;

    case DRV_FTM_TCAM_TYPE_IGS_ACL1:
        DRV_FTM_TCAM_ACL_ING_AD_MAP(1);
        break;

    case DRV_FTM_TCAM_TYPE_IGS_ACL2:
        DRV_FTM_TCAM_ACL_ING_AD_MAP(2);
        break;

    case DRV_FTM_TCAM_TYPE_IGS_ACL3:
        DRV_FTM_TCAM_ACL_ING_AD_MAP(3);
        break;

    case DRV_FTM_TCAM_TYPE_IGS_ACL4:
        DRV_FTM_TCAM_ACL_ING_AD_MAP(4);
        break;

    case DRV_FTM_TCAM_TYPE_IGS_ACL5:
        DRV_FTM_TCAM_ACL_ING_AD_MAP(5);
        break;

    case DRV_FTM_TCAM_TYPE_IGS_ACL6:
        DRV_FTM_TCAM_ACL_ING_AD_MAP(6);
        break;

    case DRV_FTM_TCAM_TYPE_IGS_ACL7:
        DRV_FTM_TCAM_ACL_ING_AD_MAP(7);
        break;

    case DRV_FTM_TCAM_TYPE_EGS_ACL0:
        DRV_FTM_TCAM_ACL_EGR_AD_MAP(0);
        break;

    case DRV_FTM_TCAM_TYPE_EGS_ACL1:
        DRV_FTM_TCAM_ACL_EGR_AD_MAP(1);
        break;

    case DRV_FTM_TCAM_TYPE_EGS_ACL2:
        DRV_FTM_TCAM_ACL_EGR_AD_MAP(2);
        break;

    case DRV_FTM_TCAM_TYPE_IGS_USERID0:
        if (DRV_FTM_TCAM_SIZE_160 == size_type)
        {
            p_ad_share_tbl[idx0++] = DsUserIdTcam160Ad0_t;
           //- p_ad_share_tbl[idx0++] = DsUserId0Mac160TcamAd_t;
        }
        else if(DRV_FTM_TCAM_SIZE_320 == size_type)
        {
            p_ad_share_tbl[idx0++] = DsUserIdTcam320Ad0_t;
        }
        else if(DRV_FTM_TCAM_SIZE_640 == size_type)
        {
            p_ad_share_tbl[idx0++] = DsUserIdTcam320Ad0_t;
        }
        break;

    case DRV_FTM_TCAM_TYPE_IGS_USERID1:
        if (DRV_FTM_TCAM_SIZE_160 == size_type)
        {
            p_ad_share_tbl[idx0++] = DsUserIdTcam160Ad1_t;
            //-p_ad_share_tbl[idx0++] = DsUserId1Mac160TcamAd_t;
        }
        else if(DRV_FTM_TCAM_SIZE_320 == size_type)
        {
            p_ad_share_tbl[idx0++] = DsUserIdTcam320Ad1_t;
        }
        else if(DRV_FTM_TCAM_SIZE_640 == size_type)
        {
            p_ad_share_tbl[idx0++] = DsUserIdTcam320Ad1_t;
        }
        break;
    case DRV_FTM_TCAM_TYPE_IGS_LPM0:
        if (DRV_FTM_TCAM_SIZE_halfkey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv4HalfKeyAdLookup1_t;
        }
        else if(DRV_FTM_TCAM_SIZE_doublekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6DoubleKey0AdLookup1_t;
        }
        else if(DRV_FTM_TCAM_SIZE_singlekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6SingleKeyAd_t;
        }
        break;
    case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI:
        if (DRV_FTM_TCAM_SIZE_halfkey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv4SaHalfKeyAdLookup1_t;
        }
        else if(DRV_FTM_TCAM_SIZE_doublekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6SaDoubleKey0AdLookup1_t;
        }
        else if(DRV_FTM_TCAM_SIZE_singlekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6SaSingleKeyAd_t;
        }
        break;
    case DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB:
        if (DRV_FTM_TCAM_SIZE_halfkey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv4DaPubHalfKeyAdLookup1_t;
        }
        else if(DRV_FTM_TCAM_SIZE_doublekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6DaPubDoubleKey0AdLookup1_t;
        }
        else if(DRV_FTM_TCAM_SIZE_singlekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6DaPubSingleKeyAd_t;
        }
        break;
    case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB:
        if (DRV_FTM_TCAM_SIZE_halfkey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv4SaPubHalfKeyAdLookup1_t;
        }
        else if(DRV_FTM_TCAM_SIZE_doublekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6SaPubDoubleKey0AdLookup1_t;
        }
        else if(DRV_FTM_TCAM_SIZE_singlekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6SaPubSingleKeyAd_t;
        }
        break;
    case DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2:
        if (DRV_FTM_TCAM_SIZE_halfkey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv4HalfKeyAdLookup2_t;
        }
        else if(DRV_FTM_TCAM_SIZE_doublekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6DoubleKey0AdLookup2_t;
        }
        break;
    case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI_LK2:
        if (DRV_FTM_TCAM_SIZE_halfkey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv4SaHalfKeyAdLookup2_t;
        }
        else if(DRV_FTM_TCAM_SIZE_doublekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6SaDoubleKey0AdLookup2_t;
        }
        break;
    case DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2:
        if (DRV_FTM_TCAM_SIZE_halfkey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv4DaPubHalfKeyAdLookup2_t;
        }
        else if(DRV_FTM_TCAM_SIZE_doublekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6DaPubDoubleKey0AdLookup2_t;
        }
        break;
    case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB_LK2:
        if (DRV_FTM_TCAM_SIZE_halfkey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv4SaPubHalfKeyAdLookup2_t;
        }
        else if(DRV_FTM_TCAM_SIZE_doublekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6SaPubDoubleKey0AdLookup2_t;
        }
        break;

    case DRV_FTM_TCAM_TYPE_IGS_LPM0_ALL:
        if (DRV_FTM_TCAM_SIZE_halfkey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv4HalfKeyAd_t;
        }
        else if(DRV_FTM_TCAM_SIZE_doublekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6DoubleKey0Ad_t;
        }
        else if(DRV_FTM_TCAM_SIZE_singlekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6SingleKeyAd_t;
        }
        break;

    case DRV_FTM_TCAM_TYPE_IGS_LPM0_PUB_ALL:
        if (DRV_FTM_TCAM_SIZE_halfkey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv4HalfKeyAd_t;
        }
        else if(DRV_FTM_TCAM_SIZE_doublekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6DoubleKey0Ad_t;
        }
        else if(DRV_FTM_TCAM_SIZE_singlekey == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6SingleKeyAd_t;
        }
        break;


    case DRV_FTM_TCAM_TYPE_IGS_LPM1:
        if(DRV_FTM_TCAM_SIZE_ipv4_nat == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv4NatDoubleKeyAd_t;
            p_ad_share_tbl[idx0++] = DsLpmTcamAd_t;
        }else if(DRV_FTM_TCAM_SIZE_ipv4_pbr == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6PbrQuadKeyAd_t;
        }
        else if(DRV_FTM_TCAM_SIZE_ipv6_nat == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6NatDoubleKeyAd_t;
        }else if(DRV_FTM_TCAM_SIZE_ipv6_pbr == size_type)
        {
            p_ad_share_tbl[idx0++] = DsLpmTcamIpv6PbrQuadKeyAd_t;
        }

        break;

    default:
        return DRV_E_INVAILD_TYPE;
    }

    *p_ad_share_num  = idx0;

    return DRV_E_NONE;

#undef DRV_FTM_TCAM_ACL_ING_AD_MAP
#undef DRV_FTM_TCAM_ACL_EGR_AD_MAP
}

tbls_ext_info_t*
drv_ftm_build_tcam_tbl_info()
{
    tbls_ext_info_t* p_tbl_ext_info = NULL;
    tcam_mem_ext_content_t* p_tcam_mem_ext_info = NULL;

    p_tbl_ext_info = mem_malloc(MEM_FTM_MODULE, sizeof(tbls_ext_info_t));
    if (NULL == p_tbl_ext_info)
    {
        return NULL;
    }

    sal_memset(p_tbl_ext_info, 0, sizeof(tbls_ext_info_t));

    p_tcam_mem_ext_info = mem_malloc(MEM_FTM_MODULE, sizeof(tcam_mem_ext_content_t));
    if (NULL == p_tcam_mem_ext_info)
    {
        mem_free(p_tbl_ext_info);
        return NULL;
    }

    sal_memset(p_tcam_mem_ext_info, 0, sizeof(tcam_mem_ext_content_t));
    p_tcam_mem_ext_info->hw_mask_base =  mem_malloc(MEM_FTM_MODULE, sizeof(addrs_t)*3);
    if (NULL == p_tcam_mem_ext_info->hw_mask_base )
    {
        mem_free(p_tcam_mem_ext_info);
        mem_free(p_tbl_ext_info);
        return NULL;
    }
    p_tbl_ext_info->ptr_ext_content = p_tcam_mem_ext_info;

    return p_tbl_ext_info;

}


static int32
drv_ftm_alloc_tcam_key_share_tbl(uint8 tcam_key_type,
                                 uint32 tbl_id)
{
    uint32 max_index_num = 0;
    uint32 mem_id = 0;
    uint32 mem_idx = 0;
    tbls_ext_info_t* p_tbl_ext_info = NULL;
    uint32  is_lpm0 = 0;
    uint32  is_lpm1 = 0;
    uint32  is_lpm = 0;
    int32   per_entry_bytes = 0;
    uint32  mem_entry      = 0;
    uint8   tcam_module = 0;
    is_lpm = 0;

    p_tbl_ext_info = drv_ftm_build_tcam_tbl_info();
    if (NULL == p_tbl_ext_info)
    {
        return DRV_E_NO_MEMORY;
    }

    per_entry_bytes            = DRV_BYTES_PER_ENTRY;

    TABLE_EXT_INFO_PTR(tbl_id) = p_tbl_ext_info;

    switch(tcam_key_type)
    {
        case DRV_FTM_TCAM_TYPE_IGS_LPM0_ALL:
        case DRV_FTM_TCAM_TYPE_IGS_LPM0_PUB_ALL:

        case DRV_FTM_TCAM_TYPE_IGS_LPM0:
        case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI:
        case DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB:
        case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB:
        case DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2:
        case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI_LK2:
        case DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2:
        case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB_LK2:
            TABLE_EXT_INFO_TYPE(tbl_id) = EXT_INFO_TYPE_LPM_TCAM_IP;
            TCAM_KEY_MODULE(tbl_id) = TCAM_MODULE_LPM;
            per_entry_bytes             = DRV_LPM_KEY_BYTES_PER_ENTRY;
            is_lpm                      = 1;
            break;
        case DRV_FTM_TCAM_TYPE_IGS_LPM1:
        TABLE_EXT_INFO_TYPE(tbl_id) = EXT_INFO_TYPE_LPM_TCAM_NAT;
        TCAM_KEY_MODULE(tbl_id) = TCAM_MODULE_LPM;
            per_entry_bytes             = DRV_LPM_KEY_BYTES_PER_ENTRY;
            is_lpm                      = 1;
            break;

        case DRV_FTM_TCAM_TYPE_IGS_USERID0:
        case DRV_FTM_TCAM_TYPE_IGS_USERID1:
            TABLE_EXT_INFO_TYPE(tbl_id) = EXT_INFO_TYPE_TCAM;
            TCAM_KEY_MODULE(tbl_id) = TCAM_MODULE_SCL;
            break;

        default:
            TABLE_EXT_INFO_TYPE(tbl_id) = EXT_INFO_TYPE_TCAM;
            TCAM_KEY_MODULE(tbl_id) = TCAM_MODULE_ACL;
            break;
    }

    if (TABLE_ENTRY_SIZE(tbl_id) == 0)
    {
        DRV_FTM_DBG_DUMP("tbl_id:%d size is zero!!!\n", tbl_id);
        return DRV_E_NONE;
    }

    TCAM_KEY_TYPE(tbl_id) = tcam_key_type;

    TCAM_KEY_SIZE(tbl_id) = TABLE_ENTRY_SIZE(tbl_id);

    TCAM_BITMAP(tbl_id) = DRV_FTM_KEY_MEM_BITMAP(tcam_key_type);
    if(tcam_key_type < DRV_FTM_TCAM_TYPE_IGS_LPM0_ALL)
    {
    #if (SDK_WORK_PLATFORM == 1)
        drv_set_tcam_lookup_bitmap(tcam_key_type, TCAM_BITMAP(tbl_id));
    #endif
    }

    if(is_lpm)
    {
        for (mem_idx = DRV_FTM_LPM_TCAM_KEY0; mem_idx < DRV_FTM_LPM_TCAM_KEYM; mem_idx++)
        {
            mem_id = mem_idx - DRV_FTM_LPM_TCAM_KEY0;

            /* if share list is no info in the block ,continue */
            if (!IS_BIT_SET(TCAM_BITMAP((tbl_id)), mem_id))
            {
                continue;
            }

            mem_entry = DRV_FTM_MEM_MAX_ENTRY_NUM(mem_idx);

            TCAM_DATA_BASE(tbl_id, mem_id, 0) =
                DRV_FTM_MEM_HW_DATA_BASE(mem_idx);
            TCAM_MASK_BASE(tbl_id, mem_id, 0) =
                DRV_FTM_MEM_HW_MASK_BASE(mem_idx);

            TCAM_ENTRY_NUM(tbl_id, mem_id)      = mem_entry;
            TCAM_START_INDEX(tbl_id, mem_id)    = max_index_num;

            /* lpm per 46bit ��, ��� ���ֵ / (һ����Ҫ����46bit) == �����ٸ�index */
            /* NAT /PBR 96bit ��, ��� ���ֵ / (һ����Ҫ����46bit) == �����ٸ�index */
            max_index_num +=
                (mem_entry / (TABLE_ENTRY_SIZE(tbl_id) / per_entry_bytes));
            TCAM_END_INDEX(tbl_id, mem_id) = (max_index_num - 1);
        }
    }
    else
    {
        for (mem_idx = DRV_FTM_TCAM_KEY0; mem_idx < DRV_FTM_TCAM_KEYM; mem_idx++)
        {
            mem_id = mem_idx - DRV_FTM_TCAM_KEY0;

            /* if share list is no info in the block ,continue */
            if (!IS_BIT_SET(TCAM_BITMAP((tbl_id)), mem_id))
            {
                continue;
            }

            mem_entry = DRV_FTM_MEM_MAX_ENTRY_NUM(mem_idx);

            TCAM_DATA_BASE(tbl_id, mem_id, 0) =
                DRV_FTM_MEM_HW_DATA_BASE(mem_idx);
            TCAM_MASK_BASE(tbl_id, mem_id, 0) =
                DRV_FTM_MEM_HW_MASK_BASE(mem_idx);

            TCAM_ENTRY_NUM(tbl_id, mem_id)      =  mem_entry;
            TCAM_START_INDEX(tbl_id, mem_id)    = max_index_num;

            /* flowhash per 96bit ��,��� ���ֵ / (һ����Ҫ����80bit) */
            max_index_num +=
                (mem_entry / (TABLE_ENTRY_SIZE(tbl_id) / per_entry_bytes));
            TCAM_END_INDEX(tbl_id, mem_id) = (max_index_num - 1);
        }
    }

    TABLE_MAX_INDEX(tbl_id) = max_index_num;
    DRV_FTM_DBG_DUMP("Key TABLE_MAX_INDEX(%20s) = %d\n", TABLE_NAME(tbl_id), max_index_num);

    return DRV_E_NONE;

}

#if 0
int32
drv_ftm_get_emulation_tcam_resource(uint32* emu_size, uint32 tbl_id)
{
    uint8 mem_idx = 0;
    uint8 mem_id = 0;

    *emu_size = 0;

    for (mem_idx = DRV_FTM_LPM_TCAM_KEY0; mem_idx < DRV_FTM_LPM_TCAM_KEYM; mem_idx++)
    {
        mem_id = mem_idx - DRV_FTM_LPM_TCAM_KEY0;

        /* if share list is no info in the block ,continue */
        if (!IS_BIT_SET(TCAM_BITMAP((tbl_id)), mem_id))
        {
            continue;
        }

        *emu_size += 64/(TCAM_KEY_SIZE(tbl_id)/(DRV_LPM_KEY_BYTES_PER_ENTRY));
    }

    *emu_size = *emu_size/2;

    return DRV_E_NONE;
}
#endif
int32
drv_ftm_get_tcam_tbl_info_detail(uint8 lchip, char* P_tbl_name)
{
    uint8 index = 0;
    uint32 tcam_key_type = 0;
    uint32 tcam_key_id = MaxTblId_t;
    uint32 tcam_ad_tbl = MaxTblId_t;
    uint32 tcam_key_a[20] = {0};
    uint32 tcam_ad_a[20] = {0};
    uint8 key_share_num  = 0;
    uint8 ad_share_num  = 0;
    uint8 mem_idx = 0;
    uint8 mem_id = 0;
    uint32 mem_entry = 0;
    uint32 tbl_id = 0;
    uint8 size_type = 0;

    if (DRV_E_NONE != drv_get_tbl_id_by_string(&tbl_id, (char*)P_tbl_name))
    {
        sal_printf("%% Not found %s\n", P_tbl_name);
        return DRV_E_INVALID_TBL;
    }

    for (tcam_key_type = DRV_FTM_TCAM_TYPE_IGS_ACL0; tcam_key_type < DRV_FTM_TCAM_TYPE_MAX; tcam_key_type++)
    {

        DRV_IF_ERROR_RETURN(drv_ftm_get_tcam_info(tcam_key_type,
                                                          tcam_key_a,
                                                          tcam_ad_a,
                                                          &key_share_num,
                                                          &ad_share_num));

        if (0 == key_share_num || 0 == ad_share_num)
        {
            continue;
        }

        /*tcam key alloc*/
        for (index = 0; index < key_share_num; index++)
        {
            tcam_key_id = tcam_key_a[index];

            if (tcam_key_id >= MaxTblId_t)
            {
                return DRV_E_NONE;
            }

            if (tcam_key_id != tbl_id)
            {
                continue;
            }

            size_type = TCAM_KEY_SIZE(tbl_id) / (DRV_LPM_KEY_BYTES_PER_ENTRY);
            if (size_type == 2)
            {
                size_type = DRV_FTM_TCAM_SIZE_LPMSingle;
            }
            else if(size_type == 4)
            {
                size_type = DRV_FTM_TCAM_SIZE_LPMDouble;
            }
            else
            {
                size_type = DRV_FTM_TCAM_SIZE_LPMhalf;
            }

            for (mem_idx = DRV_FTM_LPM_TCAM_KEY0; mem_idx < DRV_FTM_LPM_TCAM_KEYM; mem_idx++)
            {
                mem_id = mem_idx - DRV_FTM_LPM_TCAM_KEY0;

                /* if share list is no info in the block ,continue */
                if (!IS_BIT_SET(TCAM_BITMAP((tcam_key_id)), mem_id))
                {
                    continue;
                }

                mem_entry = DRV_FTM_MEM_MAX_ENTRY_NUM(mem_idx);

                DRV_FTM_DBG_OUT("%-30s :%s\n", "Tcam Table ID", TABLE_NAME(tcam_key_id));
                DRV_FTM_DBG_OUT("%-30s :%d\n", "Tcam Memory ID", mem_id);
                DRV_FTM_DBG_OUT("%-30s :0x%x\n", "Memory max entry", TCAM_ENTRY_NUM(tcam_key_id, mem_id));
                DRV_FTM_DBG_OUT("%-30s :0x%x\n", "Table Start Idx In Mem", TCAM_START_INDEX(tcam_key_id, mem_id));
                DRV_FTM_DBG_OUT("%-30s :0x%x\n", "Table End Idx In Mem", TCAM_END_INDEX(tcam_key_id, mem_id));

                DRV_FTM_DBG_OUT("%-30s :0x%x\n", "Spec max entry num", g_ftm_master->tcam_specs[tcam_key_type][size_type]);
                DRV_FTM_DBG_OUT("%-30s :0x%x\n", "Table Start Idx In Spec", g_ftm_master->tcam_offset[tcam_key_type][size_type]);
                DRV_FTM_DBG_OUT("\n");
            }
        }

    }

    return DRV_E_NONE;
}

static int32
drv_ftm_alloc_tcam_ad_share_tbl(uint8 tcam_key_type,
                                 uint32 tbl_id)
{
    uint32 max_index_num = 0;
    int8 mem_id = 0;
    uint8 mem_idx = 0;
    tbls_ext_info_t* p_tbl_ext_info = NULL;
    bool is_lpm0 = 0;
    bool is_lpm1 = 0;
    bool is_lpm = 0;
    uint8 per_entry_bytes = 0;
    uint32 mem_entry      = 0;

    p_tbl_ext_info = drv_ftm_build_tcam_tbl_info();
    if (NULL == p_tbl_ext_info)
    {
      return DRV_E_NO_MEMORY;
    }

    TABLE_EXT_INFO_PTR(tbl_id) = p_tbl_ext_info;

    switch(tcam_key_type)
    {
    case DRV_FTM_TCAM_TYPE_IGS_LPM0_ALL:
    case DRV_FTM_TCAM_TYPE_IGS_LPM0_PUB_ALL:
    case DRV_FTM_TCAM_TYPE_IGS_LPM0:
    case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI:
    case DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB:
    case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB:
    case DRV_FTM_TCAM_TYPE_IGS_LPM0_LK2:
    case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPRI_LK2:
    case DRV_FTM_TCAM_TYPE_IGS_LPM0DAPUB_LK2:
    case DRV_FTM_TCAM_TYPE_IGS_LPM0SAPUB_LK2:
        TABLE_EXT_INFO_TYPE(tbl_id) = EXT_INFO_TYPE_TCAM_LPM_AD;
        per_entry_bytes             = DRV_LPM_AD0_BYTE_PER_ENTRY;
        is_lpm                      = 1;
        TCAM_KEY_MODULE(tbl_id) = TCAM_MODULE_LPM;
        break;
    case DRV_FTM_TCAM_TYPE_IGS_LPM1:
        TABLE_EXT_INFO_TYPE(tbl_id) = EXT_INFO_TYPE_TCAM_NAT_AD;
        per_entry_bytes             = DRV_LPM_AD1_BYTE_PER_ENTRY;
        is_lpm                      = 1;
        TCAM_KEY_MODULE(tbl_id) = TCAM_MODULE_LPM;
        break;

    case DRV_FTM_TCAM_TYPE_IGS_USERID0:
    case DRV_FTM_TCAM_TYPE_IGS_USERID1:
        TABLE_EXT_INFO_TYPE(tbl_id) = EXT_INFO_TYPE_TCAM_AD;
        TCAM_KEY_MODULE(tbl_id) = TCAM_MODULE_SCL;
        break;

    default:
        TABLE_EXT_INFO_TYPE(tbl_id) = EXT_INFO_TYPE_TCAM_AD;
        TCAM_KEY_MODULE(tbl_id) = TCAM_MODULE_ACL;
        break;
    }

    TCAM_KEY_TYPE(tbl_id) = tcam_key_type;

    //- if(DsTcam0_t == tbl_id)
    //- {
    //-     TCAM_BITMAP(DsTcam0_t) = 0x1FFFF;
    //-  }
    //-  else
    {
        TCAM_BITMAP(tbl_id) = DRV_FTM_KEY_MEM_BITMAP(tcam_key_type);
    }

    if(is_lpm)
    {
        for (mem_idx = DRV_FTM_LPM_TCAM_AD0; mem_idx < DRV_FTM_LPM_TCAM_ADM; mem_idx++)
        {
             mem_id = mem_idx - DRV_FTM_LPM_TCAM_AD0;

            /* if share list is no info in the block ,continue */
            if (!IS_BIT_SET(TCAM_BITMAP(tbl_id),mem_id))
            {
                continue;
            }

            mem_entry = DRV_FTM_MEM_MAX_ENTRY_NUM(mem_idx);

            TCAM_DATA_BASE(tbl_id, mem_id, 0)   =
                DRV_FTM_MEM_HW_DATA_BASE(mem_idx);

            //-sal_printf("Ad Tcam tbl-id: %d, memory id:%d, memory base:0x%x\n",tbl_id, mem_id,TCAM_DATA_BASE(tbl_id, mem_id, 0));
            TCAM_ENTRY_NUM(tbl_id, mem_id)      = mem_entry;
            TCAM_START_INDEX(tbl_id, mem_id)    = max_index_num;

            /*
                46Bit
             */

            max_index_num +=
                (mem_entry / (TABLE_ENTRY_SIZE(tbl_id) / per_entry_bytes));
            TCAM_END_INDEX(tbl_id, mem_id) = (max_index_num - 1);

            //-sal_printf("Ad TCAM_START_INDEX(%20s, %d) = %d\n", TABLE_NAME(tbl_id), mem_id, TCAM_START_INDEX(tbl_id, mem_id));
            //-sal_printf("Ad TCAM_END_INDEX(%20s, %d) = %d\n", TABLE_NAME(tbl_id), mem_id, TCAM_END_INDEX(tbl_id, mem_id));

        }
    }
    else
    {
        for (mem_idx = DRV_FTM_TCAM_AD0; mem_idx < DRV_FTM_TCAM_ADM; mem_idx++)
        {
             mem_id = mem_idx - DRV_FTM_TCAM_AD0;

            /* if share list is no info in the block ,continue */
            if (!IS_BIT_SET(TCAM_BITMAP(tbl_id),mem_id))
            {
                continue;
            }

            mem_entry = DRV_FTM_MEM_MAX_ENTRY_NUM(mem_idx);

            TCAM_DATA_BASE(tbl_id, mem_id, 0) =
                DRV_FTM_MEM_HW_DATA_BASE(mem_idx);

            TCAM_ENTRY_NUM(tbl_id, mem_id)      = mem_entry;
            TCAM_START_INDEX(tbl_id, mem_id)    = max_index_num;

            max_index_num +=
                (mem_entry / ( TABLE_ENTRY_SIZE(tbl_id) / DRV_BYTES_PER_ENTRY));
            TCAM_END_INDEX(tbl_id, mem_id) = (max_index_num - 1);

            DRV_FTM_DBG_DUMP("Ad TCAM_START_INDEX(%20s, %d) = %d\n", TABLE_NAME(tbl_id), mem_id, TCAM_START_INDEX(tbl_id, mem_id));
            DRV_FTM_DBG_DUMP("Ad TCAM_END_INDEX(%20s, %d) = %d\n", TABLE_NAME(tbl_id), mem_id, TCAM_END_INDEX(tbl_id, mem_id));
        }
    }

    TABLE_MAX_INDEX(tbl_id) = max_index_num;

    drv_ftm_alloc_tcam_ad_map_to_new_word(tbl_id);

    DRV_FTM_DBG_DUMP("Ad TCAM_BITMAP(%20s) = %d\n", TABLE_NAME(tbl_id), TCAM_BITMAP(tbl_id));
    DRV_FTM_DBG_DUMP("Ad TABLE_MAX_INDEX(%20s) = %d\n", TABLE_NAME(tbl_id), TABLE_MAX_INDEX(tbl_id));
    DRV_FTM_DBG_DUMP("----------------------------------------\n");

    return DRV_E_NONE;

}

static int32
drv_ftm_alloc_tcam()
{
    uint8 index = 0;
    uint32 tcam_key_type = 0;
    uint32 tcam_key_id = MaxTblId_t;
    uint32 tcam_ad_tbl = MaxTblId_t;
    uint32 tcam_key_a[20] = {0};
    uint32 tcam_ad_a[20] = {0};
    uint8 key_share_num  = 0;
    uint8 ad_share_num  = 0;

    for (tcam_key_type = DRV_FTM_TCAM_TYPE_IGS_ACL0; tcam_key_type < DRV_FTM_TCAM_TYPE_MAX; tcam_key_type++)
    {

        DRV_IF_ERROR_RETURN(drv_ftm_get_tcam_info(tcam_key_type,
                                                          tcam_key_a,
                                                          tcam_ad_a,
                                                          &key_share_num,
                                                          &ad_share_num));

        if (0 == key_share_num || 0 == ad_share_num)
        {
            continue;
        }

        /*tcam key alloc*/
        for (index = 0; index < key_share_num; index++)
        {
            tcam_key_id = tcam_key_a[index];

            if (tcam_key_id >= MaxTblId_t)
            {
                DRV_FTM_DBG_DUMP("unexpect tbl id:%d\r\n", tcam_key_id);
                return DRV_E_INVAILD_TYPE;
            }

            DRV_IF_ERROR_RETURN(drv_ftm_alloc_tcam_key_share_tbl(tcam_key_type, tcam_key_id));
        }

        /*tcam ad alloc*/
        for (index = 0; index < ad_share_num; index++)
        {
            tcam_ad_tbl = tcam_ad_a[index];

            if (tcam_ad_tbl >= MaxTblId_t)
            {
                DRV_FTM_DBG_DUMP("unexpect tbl id:%d\r\n", tcam_ad_tbl);
                return DRV_E_INVAILD_TYPE;
            }

            DRV_IF_ERROR_RETURN(drv_ftm_alloc_tcam_ad_share_tbl(tcam_key_type, tcam_ad_tbl));
        }

    }

    return DRV_E_NONE;

}

static int32
drv_ftm_alloc_static()
{
    uint8 index = 0;
    uint32 tcam_key_type = 0;
    uint32 tbl_id = MaxTblId_t;
    uint32 tcam_ad_tbl = MaxTblId_t;
    uint32 tcam_key_a[20] = {0};
    uint32 tcam_ad_a[20] = {0};
    uint8 key_share_num  = 0;
    uint8 ad_share_num  = 0;
    tbls_ext_info_t* p_tbl_ext_info = NULL;


    tcam_key_type = DRV_FTM_TCAM_TYPE_STATIC_TCAM;

    DRV_IF_ERROR_RETURN(drv_ftm_get_tcam_info(tcam_key_type,
                                              tcam_key_a,
                                              tcam_ad_a,
                                              &key_share_num,
                                              &ad_share_num));

    /*tcam key alloc*/
    for (index = 0; index < key_share_num; index++)
    {
        tbl_id = tcam_key_a[index];

        if (tbl_id >= MaxTblId_t)
        {
            DRV_FTM_DBG_DUMP("unexpect tbl id:%d\r\n", tbl_id);
            return DRV_E_INVAILD_TYPE;
        }


        p_tbl_ext_info = drv_ftm_build_tcam_tbl_info();
        if (NULL == p_tbl_ext_info)
        {
            return DRV_E_NO_MEMORY;
        }

        TABLE_EXT_INFO_PTR(tbl_id) = p_tbl_ext_info;


        TABLE_EXT_INFO_TYPE(tbl_id) = EXT_INFO_TYPE_STATIC_TCAM_KEY;
        TCAM_KEY_MODULE(tbl_id) = TCAM_MODULE_NONE;
        TCAM_KEY_TYPE(tbl_id) = tcam_key_type;

        TCAM_KEY_SIZE(tbl_id) = TABLE_ENTRY_SIZE(tbl_id);/* table key size are in bytes */
        TCAM_BITMAP(tbl_id) = 0;

        if (tbl_id == DsCategoryIdPairTcamKey_t)
        {
            TCAM_DATA_BASE(tbl_id, 0, 0) = DRV_CID_TCAM_KEY_BASE_ADDR;
            TCAM_MASK_BASE(tbl_id, 0, 0) = DRV_CID_TCAM_MASK_BASE_ADDR;
        }
        else
        {

            TCAM_DATA_BASE(tbl_id, 0, 0) = DRV_QUEUE_TCAM_KEY_BASE_ADDR;
            TCAM_MASK_BASE(tbl_id, 0, 0) = DRV_QUEUE_TCAM_MASK_BASE_ADDR;
        }

        TCAM_ENTRY_NUM(tbl_id, 0) = TABLE_MAX_INDEX(tbl_id);
        TCAM_TABLE_SW_BASE(tbl_id, 0) = 0;
        TCAM_START_INDEX(tbl_id, 0) = 0;
        TCAM_END_INDEX(tbl_id, 0) = TABLE_MAX_INDEX(tbl_id) - 1;

    }


  return DRV_E_NONE;
}


int32
drv_ftm_alloc_cam(drv_ftm_cam_t *p_cam_profile)
{
    uint32 bitmap = 0;

    /*fib acc cam*/
    /*bit
    bit[0]: mac
    bit[1]: ipv4 uc host
    bit[2]: ipv4 l2 mc
    bit[3]: ipv4 mc
    bit[4]: ipv6 uc hot
    bit[5]: ipv6 l2 mc
    bit[6]: ipv6 mc
    bit[7]: fcoe
    bit[8]: trill
    */
    SET_BIT(bitmap, 1);
    SET_BIT(bitmap, 4);
    SET_BIT(bitmap, 7);
    SET_BIT(bitmap, 8);
    if((0 == p_cam_profile->conflict_cam_num[DRV_FTM_CAM_TYPE_FIB_HOST0_FDB])
       && (0 == p_cam_profile->conflict_cam_num[DRV_FTM_CAM_TYPE_FIB_HOST0_MC]))
    {/*share*/

    }
    else if(FIB_HOST0_CAM_NUM == p_cam_profile->conflict_cam_num[DRV_FTM_CAM_TYPE_FIB_HOST0_FDB])
    {
        SET_BIT(bitmap, 2);
        SET_BIT(bitmap, 3);
        SET_BIT(bitmap, 5);
        SET_BIT(bitmap, 6);
    }
    else if(FIB_HOST0_CAM_NUM == p_cam_profile->conflict_cam_num[DRV_FTM_CAM_TYPE_FIB_HOST0_MC])
    {
        SET_BIT(bitmap, 0);
    }
    /*
    else if(FIB_HOST0_CAM_NUM == (p_cam_profile->fdb_conflict_num + p_cam_profile->ipmc_g_conflict_num))
    {
        //write valid bit
        drv_fib_acc_in_t* fib_acc_in;
        drv_fib_acc_out_t* fib_acc_out;
        uint8 index = 0;
        ds_fib_host0_ipv4_hash_key_m ds_fib_host0_ipv4_hash_key;

        sal_memset(&fib_acc_in, 0, sizeof(fib_acc_in));
        sal_memset(&fib_acc_out, 0, sizeof(drv_fib_acc_out_t));
        sal_memset(&ds_fib_host0_ipv4_hash_key, 0, sizeof(ds_fib_host0_ipv4_hash_key));

        SetDsFibHost0Ipv4HashKey(V, valid_f, &ds_fib_host0_ipv4_hash_key, 1);
        for (index = 0; index < p_cam_profile->ipmc_g_conflict_num; index ++)
        {
            fib_acc_in.rw.tbl_id = DsFibHost0Ipv4HashKey_t;
            fib_acc_in.rw.key_index = index;
            fib_acc_in.rw.data = (void*)&ds_fib_host0_ipv4_hash_key;
            drv_fib_acc(0, DRV_FIB_ACC_WRITE_FIB0_BY_IDX, &fib_acc_in, &fib_acc_out);
        }

        SET_BIT(bitmap, 2);
        SET_BIT(bitmap, 3);
        SET_BIT(bitmap, 5);
        SET_BIT(bitmap, 6);
    }
    */
    /* fib host0 acc bitmap */
    g_ftm_master->cam_bitmap = bitmap;

    sal_memcpy(&g_ftm_master->conflict_cam_num[0], &p_cam_profile->conflict_cam_num[0],
                sizeof(p_cam_profile->conflict_cam_num[0])*DRV_FTM_CAM_TYPE_MAX);
    sal_memcpy(&g_ftm_master->cfg_max_cam_num[0], &p_cam_profile->conflict_cam_num[0],
                sizeof(p_cam_profile->conflict_cam_num[0])*DRV_FTM_CAM_TYPE_MAX);


    //if (p_cam_profile->conflict_cam_num[DRV_FTM_CAM_TYPE_OAM])
    {
        SET_BIT(g_ftm_master->xcoam_cam_bitmap0[3], 31); /*single*/
        SET_BIT(g_ftm_master->xcoam_cam_bitmap1[1], 31); /*dual*/
        SET_BIT(g_ftm_master->xcoam_cam_bitmap2[0], 31); /*quad*/

        if(g_ftm_master->conflict_cam_num[DRV_FTM_CAM_TYPE_OAM])
        {
            g_ftm_master->conflict_cam_num[DRV_FTM_CAM_TYPE_OAM] -= 1;
        }
        else
        {
            g_ftm_master->conflict_cam_num[DRV_FTM_CAM_TYPE_XC] -= 1;
        }
    }

    return DRV_E_NONE;
}



static int32
_drv_ftm_get_cam_by_tbl_id(uint32 tbl_id, uint8* cam_type)
{
    uint8 type = DRV_FTM_CAM_TYPE_INVALID;

    switch(tbl_id)
    {
        case DsFibHost1Ipv6NatDaPortHashKey_t:
        case DsFibHost1Ipv6NatSaPortHashKey_t:
        case DsFibHost1Ipv4NatDaPortHashKey_t:
        case DsFibHost1Ipv4NatSaPortHashKey_t:
            type = DRV_FTM_CAM_TYPE_FIB_HOST1_NAT;
            break;

        case DsFibHost1Ipv4McastHashKey_t:
        case DsFibHost1Ipv6McastHashKey_t:
        case DsFibHost1MacIpv4McastHashKey_t:
        case DsFibHost1MacIpv6McastHashKey_t:
            type =DRV_FTM_CAM_TYPE_FIB_HOST1_MC ;
            break;


        case DsEgressXcOamPortVlanCrossHashKey_t:
        case DsEgressXcOamCvlanCosPortHashKey_t:
        case DsEgressXcOamPortCrossHashKey_t:
        case DsEgressXcOamCvlanPortHashKey_t:
        case DsEgressXcOamDoubleVlanPortHashKey_t:
        case DsEgressXcOamSvlanCosPortHashKey_t:
        case DsEgressXcOamSvlanPortHashKey_t:
        case DsEgressXcOamPortHashKey_t:
        case DsEgressXcOamSvlanPortMacHashKey_t:
        case DsEgressXcOamTunnelPbbHashKey_t:
            type = DRV_FTM_CAM_TYPE_XC;
            break;

        case DsEgressXcOamBfdHashKey_t:
        case DsEgressXcOamEthHashKey_t:
        case DsEgressXcOamMplsLabelHashKey_t:
        case DsEgressXcOamMplsSectionHashKey_t:
        case DsEgressXcOamRmepHashKey_t:
            type = DRV_FTM_CAM_TYPE_OAM;
            break;

        case DsUserIdTunnelMplsHashKey_t:
            type = DRV_FTM_CAM_TYPE_MPLS;
            break;

        case DsUserIdCvlanCosPortHashKey_t:
        case DsUserIdCvlanPortHashKey_t:
        case DsUserIdDoubleVlanPortHashKey_t:

        case DsUserIdIpv4PortHashKey_t:
        case DsUserIdIpv4SaHashKey_t:
        case DsUserIdIpv6PortHashKey_t:
        case DsUserIdIpv6SaHashKey_t:

        case DsUserIdMacHashKey_t:
        case DsUserIdMacPortHashKey_t:
        case DsUserIdPortHashKey_t:
        case DsUserIdSvlanCosPortHashKey_t:
        case DsUserIdSvlanHashKey_t:
        case DsUserIdSvlanMacSaHashKey_t:
        case DsUserIdSvlanPortHashKey_t:
        case DsUserIdSclFlowL2HashKey_t:

        case DsUserIdTunnelIpv4DaHashKey_t:
        case DsUserIdTunnelIpv4GreKeyHashKey_t:
        case DsUserIdTunnelIpv4HashKey_t:
        case DsUserIdTunnelIpv4RpfHashKey_t:
        case DsUserIdTunnelIpv4UdpHashKey_t:
            type = DRV_FTM_CAM_TYPE_SCL;
            break;

        case DsUserIdTunnelIpv4McNvgreMode0HashKey_t:
        case DsUserIdTunnelIpv4McVxlanMode0HashKey_t:
        case DsUserIdTunnelIpv4NvgreMode1HashKey_t:
        case DsUserIdTunnelIpv4VxlanMode1HashKey_t:
        case DsUserIdTunnelIpv4UcNvgreMode0HashKey_t:
        case DsUserIdTunnelIpv4UcNvgreMode1HashKey_t:
        case DsUserIdTunnelIpv4UcVxlanMode0HashKey_t:
        case DsUserIdTunnelIpv4UcVxlanMode1HashKey_t:
        case DsUserIdTunnelIpv6McNvgreMode0HashKey_t:
        case DsUserIdTunnelIpv6McNvgreMode1HashKey_t:
        case DsUserIdTunnelIpv6McVxlanMode0HashKey_t:
        case DsUserIdTunnelIpv6McVxlanMode1HashKey_t:
        case DsUserIdTunnelIpv6UcNvgreMode0HashKey_t:
        case DsUserIdTunnelIpv6UcNvgreMode1HashKey_t:
        case DsUserIdTunnelIpv6UcVxlanMode0HashKey_t:
        case DsUserIdTunnelIpv6UcVxlanMode1HashKey_t:
            type = DRV_FTM_CAM_TYPE_DCN;
            break;

        default:
            type = DRV_FTM_CAM_TYPE_INVALID;
            break;

    }

    *cam_type = type;

    return DRV_E_NONE;
}



static int32
drv_ftm_set_profile(drv_ftm_profile_info_t *profile_info)
{
    uint8 profile_index    = 0;

    profile_index = profile_info->profile_type;
    switch (profile_index)
    {
    case 0:
        _drv_ftm_set_profile_default();
        break;

    case 12:
        _drv_ftm_set_profile_user_define(profile_info);
        break;

    default:
        return DRV_E_NONE;
    }

    return DRV_E_NONE;

}



static int32
drv_ftm_init(drv_ftm_profile_info_t *profile_info)
{
    if (NULL != g_ftm_master)
    {
        return DRV_E_NONE;
    }

    g_ftm_master = mem_malloc(MEM_FTM_MODULE, sizeof(g_ftm_master_t));

    if (NULL == g_ftm_master)
    {
        return DRV_E_NO_MEMORY;
    }

    sal_memset(g_ftm_master, 0, sizeof(g_ftm_master_t));

    g_ftm_master->p_sram_tbl_info =
        mem_malloc(MEM_FTM_MODULE, sizeof(drv_ftm_sram_tbl_info_t) * DRV_FTM_SRAM_TBL_MAX);
    if (NULL == g_ftm_master->p_sram_tbl_info)
    {
        mem_free(g_ftm_master);
        return DRV_E_NO_MEMORY;
    }

    sal_memset(g_ftm_master->p_sram_tbl_info, 0, sizeof(drv_ftm_sram_tbl_info_t) * DRV_FTM_SRAM_TBL_MAX);

    g_ftm_master->p_tcam_key_info =
        mem_malloc(MEM_FTM_MODULE, sizeof(drv_ftm_tcam_key_info_t) * DRV_FTM_TCAM_TYPE_MAX);
    if (NULL == g_ftm_master->p_sram_tbl_info)
    {
        mem_free(g_ftm_master->p_sram_tbl_info);
        mem_free(g_ftm_master);
        return DRV_E_NO_MEMORY;
    }

    sal_memset(g_ftm_master->p_tcam_key_info, 0, sizeof(drv_ftm_tcam_key_info_t) * DRV_FTM_TCAM_TYPE_MAX);

    g_ftm_master->lookup_div = 1;
    g_ftm_master->lpm_model = profile_info->lpm_mode;
    g_ftm_master->nat_pbr_enable = 1;

    return DRV_E_NONE;
}




static int32
drv_tcam_ctl_init(uint8 lchip)
{
    uint32 cmd = 0;
    uint32 alloc_bitmap = 0;
    uint32 tcam_bitmap = 0;
    uint32 couple_mode = 0;
    uint32 sel = 0;
    uint8 mem_id = 0;
    FlowTcamLookupCtl_m FlowTcamLookupCtl;
    LpmTcamCtl_m lpmtcam;

    sal_memset(&FlowTcamLookupCtl, 0, sizeof(FlowTcamLookupCtl));

    DRV_IF_ERROR_RETURN(drv_get_dynamic_ram_couple_mode(&couple_mode));

    cmd = DRV_IOR(LpmTcamCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &lpmtcam));
    SetLpmTcamCtl(V,privatePublicLookupMode_f, &lpmtcam, g_ftm_master->lpm_model);
    SetLpmTcamCtl(V,natPbrTcamLookupEn_f, &lpmtcam, g_ftm_master->nat_pbr_enable);
    SetLpmTcamCtl(V,lpmTcamLookup2Division_f, &lpmtcam, g_ftm_master->lookup_div);
    cmd = DRV_IOW(LpmTcamCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &lpmtcam));

    cmd = DRV_IOR(FlowTcamLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &FlowTcamLookupCtl));


    /*User1/ACL1/ACl4/ACl7 sel*/
    mem_id = DRV_FTM_TCAM_KEY13 - DRV_FTM_TCAM_KEY0;
    if (IS_BIT_SET(DRV_FTM_KEY_MEM_BITMAP(DRV_FTM_TCAM_TYPE_IGS_USERID1), mem_id))
    {
        sel = 0;
    }
    else if(IS_BIT_SET(DRV_FTM_KEY_MEM_BITMAP(DRV_FTM_TCAM_TYPE_IGS_ACL1), mem_id))
    {
        sel = 1;
    }
    else if(IS_BIT_SET(DRV_FTM_KEY_MEM_BITMAP(DRV_FTM_TCAM_TYPE_IGS_ACL4), mem_id))
    {
        sel = 2;
    }
    else if(IS_BIT_SET(DRV_FTM_KEY_MEM_BITMAP(DRV_FTM_TCAM_TYPE_IGS_ACL7), mem_id))
    {
        sel = 3;
    }
    SetFlowTcamLookupCtl(V, share0IntfSel_f, &FlowTcamLookupCtl, sel);


    /*User0/ACL0/ACL2/ACl5 sel*/
    mem_id = DRV_FTM_TCAM_KEY14 - DRV_FTM_TCAM_KEY0;
    if (IS_BIT_SET(DRV_FTM_KEY_MEM_BITMAP(DRV_FTM_TCAM_TYPE_IGS_USERID0), mem_id))
    {
        sel = 0;
    }
    else if(IS_BIT_SET(DRV_FTM_KEY_MEM_BITMAP(DRV_FTM_TCAM_TYPE_IGS_ACL0), mem_id))
    {
        sel = 1;
    }
    else if(IS_BIT_SET(DRV_FTM_KEY_MEM_BITMAP(DRV_FTM_TCAM_TYPE_IGS_ACL2), mem_id))
    {
        sel = 2;
    }
    else if(IS_BIT_SET(DRV_FTM_KEY_MEM_BITMAP(DRV_FTM_TCAM_TYPE_IGS_ACL5), mem_id))
    {
        sel = 3;
    }
    SetFlowTcamLookupCtl(V, share1IntfSel_f, &FlowTcamLookupCtl, sel);


    /*User0/ACL3/ACl6 sel*/
    mem_id = DRV_FTM_TCAM_KEY15 - DRV_FTM_TCAM_KEY0;
    if (IS_BIT_SET(DRV_FTM_KEY_MEM_BITMAP(DRV_FTM_TCAM_TYPE_IGS_USERID0), mem_id))
    {
        sel = 0;
    }
    else if(IS_BIT_SET(DRV_FTM_KEY_MEM_BITMAP(DRV_FTM_TCAM_TYPE_IGS_ACL3), mem_id))
    {
        sel = 1;
    }
    else if(IS_BIT_SET(DRV_FTM_KEY_MEM_BITMAP(DRV_FTM_TCAM_TYPE_IGS_ACL6), mem_id))
    {
        sel = 2;
    }
    SetFlowTcamLookupCtl(V, share2IntfSel_f, &FlowTcamLookupCtl, sel);

    cmd = DRV_IOW(FlowTcamLookupCtl_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &FlowTcamLookupCtl));


    return DRV_E_NONE;
}


int32
drv_dynamic_cam_init(uint32 lchip)
{
#if 1
    uint32 cmd                = 0;
    uint32 field_id        = 0;
    uint32 field_id_en      = 0;
    uint32 field_id_base      = 0;
    uint32 field_id_max_index = 0;
    uint32 field_id_min_index = 0;
    uint32 user_id_max_base = 0;

    uint32 ds[32] = {0};
    uint8 i = 0;
    uint8 idx = 0;
    uint32 field_val          = 0;
    uint32 tbl_id             = 0;
    uint32 tbl_id_array[5]   = {0};

    uint32 sum               = 0;
    uint8 step                  = 1;
    uint32 bitmap            = 0;
    uint8 cam_type            = 0;
    uint8 sram_type           = 0;
    uint8 unit                    = DRV_FTM_UNIT_8K;

    for (cam_type = 0; cam_type < DRV_FTM_DYN_CAM_TYPE_MAX; cam_type++)
    {
        idx = 0;

        switch (cam_type)
        {
        case DRV_FTM_DYN_CAM_TYPE_LPM_KEY:
            sram_type                    =  DRV_FTM_SRAM_TBL_LPM_LKP_KEY;
            tbl_id_array[idx++]      = DynamicKeyLpmPipe0IndexCam_t;
            //-tbl_id_array[idx++]      = DynamicKeyLpmPipe1IndexCam_t;
            field_id_en                   = DynamicKeyLpmPipe0IndexCam_lpmPipe0CamEnable0_f;
            field_id_base               = DynamicKeyLpmPipe0IndexCam_lpmPipe0BaseAddr0_f;
            field_id_min_index      = DynamicKeyLpmPipe0IndexCam_lpmPipe0MinIndex0_f;
            field_id_max_index     = DynamicKeyLpmPipe0IndexCam_lpmPipe0MaxIndex0_f;
            unit                               = DRV_FTM_UNIT_1K;
            break;

        case DRV_FTM_DYN_CAM_TYPE_FIB_MACHOST0_KEY:
            sram_type                    =  DRV_FTM_SRAM_TBL_FIB0_HASH_KEY;
            tbl_id_array[idx++]      =  DynamicKeyHost0KeyIndexCam_t;
            field_id_en                   = DynamicKeyHost0KeyIndexCam_host0KeyCamEnable0_f;
            field_id_base               = DynamicKeyHost0KeyIndexCam_host0KeyBaseAddr0_f;
            field_id_min_index      = DynamicKeyHost0KeyIndexCam_host0KeyMinIndex0_f;
            field_id_max_index     = DynamicKeyHost0KeyIndexCam_host0KeyMaxIndex0_f;
            unit                               = DRV_FTM_UNIT_1K;
            break;

        case DRV_FTM_DYN_CAM_TYPE_FIB_FLOW_AD:
            sram_type                    =  DRV_FTM_SRAM_TBL_FLOW_AD;
            tbl_id_array[idx++]      = DynamicAdDsFlowIndexCam_t;
            field_id_en                   = DynamicAdDsFlowIndexCam_dsFlowCamEnable0_f;
            field_id_base               = DynamicAdDsFlowIndexCam_dsFlowBaseAddr0_f;
            field_id_min_index      = DynamicAdDsFlowIndexCam_dsFlowMinIndex0_f;
            field_id_max_index     = DynamicAdDsFlowIndexCam_dsFlowMaxIndex0_f;
            unit                               = DRV_FTM_UNIT_1K;
            break;


        case DRV_FTM_DYN_CAM_TYPE_IP_FIX_HASH_KEY:
            sram_type                    =  DRV_FTM_SRAM_TBL_IPFIX_HASH_KEY;
            tbl_id_array[idx++]      = DynamicKeyIpfixKeyIndexCam_t;
            field_id_en                   = DynamicKeyIpfixKeyIndexCam_ipfixKeyCamEnable0_f;
            field_id_base               = DynamicKeyIpfixKeyIndexCam_ipfixKeyBaseAddr0_f;
            field_id_min_index      = DynamicKeyIpfixKeyIndexCam_ipfixKeyMinIndex0_f;
            field_id_max_index     = DynamicKeyIpfixKeyIndexCam_ipfixKeyMaxIndex0_f;
            unit                               = DRV_FTM_UNIT_1K;
            break;

        case DRV_FTM_DYN_CAM_TYPE_IP_FIX_HASH_AD:
            sram_type                    =  DRV_FTM_SRAM_TBL_IPFIX_AD;
            tbl_id_array[idx++]      = DynamicAdDsIpfixIndexCam_t;
            field_id_en                   = DynamicAdDsIpfixIndexCam_dsIpfixCamEnable0_f;
            field_id_base               = DynamicAdDsIpfixIndexCam_dsIpfixBaseAddr0_f;
            field_id_min_index      = DynamicAdDsIpfixIndexCam_dsIpfixMinIndex0_f;
            field_id_max_index     = DynamicAdDsIpfixIndexCam_dsIpfixMaxIndex0_f;
            unit                               = DRV_FTM_UNIT_1K;
            break;

        case DRV_FTM_DYN_CAM_TYPE_FIB_L2_AD:
            sram_type                    =  DRV_FTM_SRAM_TBL_DSMAC_AD;
            tbl_id_array[idx++]      = DynamicAdDsMacIndexCam_t;
            field_id_en                   = DynamicAdDsMacIndexCam_dsMacCamEnable0_f;
            field_id_base               = DynamicAdDsMacIndexCam_dsMacBaseAddr0_f;
            field_id_min_index      = DynamicAdDsMacIndexCam_dsMacMinIndex0_f;
            field_id_max_index     = DynamicAdDsMacIndexCam_dsMacMaxIndex0_f;
            unit                               = DRV_FTM_UNIT_1K;
            break;

        case DRV_FTM_DYN_CAM_TYPE_FIB_L3_AD:
            sram_type                    =  DRV_FTM_SRAM_TBL_DSIP_AD;
            tbl_id_array[idx++]      = DynamicAdDsIpIndexCam_t;
            field_id_en                   = DynamicAdDsIpIndexCam_dsIpCamEnable0_f;
            field_id_base               = DynamicAdDsIpIndexCam_dsIpBaseAddr0_f;
            field_id_min_index      = DynamicAdDsIpIndexCam_dsIpMinIndex0_f;
            field_id_max_index     = DynamicAdDsIpIndexCam_dsIpMaxIndex0_f;
            unit                               = DRV_FTM_UNIT_1K;
            break;

        case DRV_FTM_DYN_CAM_TYPE_DS_EDIT:
            sram_type                    =  DRV_FTM_SRAM_TBL_EDIT;
            tbl_id_array[idx++]      = DynamicEditDsEditIndexCam_t;
            field_id_en                   = DynamicEditDsEditIndexCam_dsEditCamEnable0_f;
            field_id_base               = DynamicEditDsEditIndexCam_dsEditBaseAddr0_f;
            field_id_min_index      = DynamicEditDsEditIndexCam_dsEditMinIndex0_f;
            field_id_max_index     = DynamicEditDsEditIndexCam_dsEditMaxIndex0_f;
            unit                               = DRV_FTM_UNIT_1K;
            break;


        case DRV_FTM_DYN_CAM_TYPE_DS_NEXTHOP:
            sram_type                    =  DRV_FTM_SRAM_TBL_NEXTHOP;
            tbl_id_array[idx++]      = DynamicEditDsNextHopIndexCam_t;
            field_id_en                   = DynamicEditDsNextHopIndexCam_dsNextHopCamEnable0_f;
            field_id_base               = DynamicEditDsNextHopIndexCam_dsNextHopBaseAddr0_f;
            field_id_min_index      = DynamicEditDsNextHopIndexCam_dsNextHopMinIndex0_f;
            field_id_max_index     = DynamicEditDsNextHopIndexCam_dsNextHopMaxIndex0_f;
            unit                               = DRV_FTM_UNIT_1K;
            break;

        case DRV_FTM_DYN_CAM_TYPE_DS_MET:
            sram_type                    =  DRV_FTM_SRAM_TBL_MET;
            tbl_id_array[idx++]      = DynamicEditDsMetIndexCam_t;
            field_id_en                   = DynamicEditDsMetIndexCam_dsMetCamEnable0_f;
            field_id_base               = DynamicEditDsMetIndexCam_dsMetBaseAddr0_f;
            field_id_min_index      = DynamicEditDsMetIndexCam_dsMetMinIndex0_f;
            field_id_max_index     = DynamicEditDsMetIndexCam_dsMetMaxIndex0_f;
            unit                               = DRV_FTM_UNIT_1K;
            break;

        case DRV_FTM_DYN_CAM_TYPE_DS_FWD:
            sram_type                    =  DRV_FTM_SRAM_TBL_FWD;
            tbl_id_array[idx++]      = DynamicEditDsFwdIndexCam_t;
            field_id_en                   = DynamicEditDsFwdIndexCam_dsFwdCamEnable0_f;
            field_id_base               = DynamicEditDsFwdIndexCam_dsFwdBaseAddr0_f;
            field_id_min_index      = DynamicEditDsFwdIndexCam_dsFwdMinIndex0_f;
            field_id_max_index     = DynamicEditDsFwdIndexCam_dsFwdMaxIndex0_f;
            unit                               = DRV_FTM_UNIT_1K;
            break;


        case DRV_FTM_DYN_CAM_TYPE_USERID_HASH_AD:
            sram_type                    =  DRV_FTM_SRAM_TBL_USERID_AD;
            tbl_id_array[idx++]      = DynamicAdUserIdAdIndexCam_t;
            field_id_en                   = DynamicAdUserIdAdIndexCam_userIdAdCamEnable0_f;
            field_id_base               = DynamicAdUserIdAdIndexCam_userIdAdBaseAddr0_f;
            field_id_min_index      = DynamicAdUserIdAdIndexCam_userIdAdMinIndex0_f;
            field_id_max_index     = DynamicAdUserIdAdIndexCam_userIdAdMaxIndex0_f;
            unit                               = DRV_FTM_UNIT_1K;
            break;

        case DRV_FTM_DYN_CAM_TYPE_DS_MEP:
            sram_type                    =  DRV_FTM_SRAM_TBL_OAM_MEP;
            tbl_id_array[idx++]      = DynamicKeyDsMepIndexCam_t;
            field_id_en                   = DynamicKeyDsMepIndexCam_dsMepCamEnable0_f;
            field_id_base               = DynamicKeyDsMepIndexCam_dsMepBaseAddr0_f;
            field_id_min_index      = DynamicKeyDsMepIndexCam_dsMepMinIndex0_f;
            field_id_max_index     = DynamicKeyDsMepIndexCam_dsMepMaxIndex0_f;
            unit                               = DRV_FTM_UNIT_1K;
            break;

        case DRV_FTM_DYN_CAM_TYPE_DS_LM:
            sram_type                    =  DRV_FTM_SRAM_TBL_OAM_LM;
            tbl_id_array[idx++]      = DynamicKeyDsLmIndexCam_t;
            field_id_en                   = DynamicKeyDsLmIndexCam_dsLmCamEnable0_f;
            field_id_base               = DynamicKeyDsLmIndexCam_dsLmBaseAddr0_f;
            field_id_min_index      = DynamicKeyDsLmIndexCam_dsLmMinIndex0_f;
            field_id_max_index     = DynamicKeyDsLmIndexCam_dsLmMaxIndex0_f;
            unit                               = DRV_FTM_UNIT_1K;
            break;

        case DRV_FTM_DYN_CAM_TYPE_DS_APS:
        case DRV_FTM_DYN_CAM_TYPE_EGRESS_OAM_HASH_KEY:
        case DRV_FTM_DYN_CAM_TYPE_USERID_HASH_KEY:
        default:
           continue;
        }

        bitmap = DRV_FTM_TBL_BASE_BITMAP(sram_type);
        tbl_id = tbl_id_array[0];

        sal_memset(ds, 0, sizeof(ds));

        for (i = 0; i < 5; i++)
        {
            if (!IS_BIT_SET(bitmap, i))
            {
                continue;
            }


            step = i;


            if (field_id_en != DRV_FTM_FLD_INVALID)
            {
                /*write ds cam enable value*/
                field_id = field_id_en + step;
                field_val = 1;
                DRV_SET_FIELD_V(tbl_id, field_id,   ds,   field_val );
            }

            if (field_id_base != DRV_FTM_FLD_INVALID)
            {
                /*write ds cam base value*/
                field_id = field_id_base + step;
                field_val = DRV_FTM_TBL_BASE_VAL(sram_type, i);
                field_val = (field_val >> unit);
                DRV_SET_FIELD_V(tbl_id, field_id,   ds,   field_val );
            }

            if (field_id_min_index != DRV_FTM_FLD_INVALID)
            {
                /*write ds cam min value*/
                field_id = field_id_min_index + step;
                field_val = DRV_FTM_TBL_BASE_MIN(sram_type, i);
                field_val = (field_val >> unit);

                if  (DRV_FTM_SRAM_TBL_USERID_HASH_KEY == sram_type)
                {
                    field_val = 0;
                }


                DRV_SET_FIELD_V(tbl_id, field_id,   ds,   field_val );

            }

            if (field_id_max_index != DRV_FTM_FLD_INVALID)
            {
                /*write ds cam max value*/
                field_id = field_id_max_index + step;

                /*write ds cam base max index*/
                if (DRV_FTM_SRAM_TBL_OAM_MEP == sram_type)
                {
                    field_val = DRV_FTM_TBL_BASE_MAX(DRV_FTM_SRAM_TBL_OAM_MEP,    i) +
                    DRV_FTM_TBL_BASE_MAX(DRV_FTM_SRAM_TBL_OAM_MA,      i) +
                    DRV_FTM_TBL_BASE_MAX(DRV_FTM_SRAM_TBL_OAM_MA_NAME, i);
                }
                else
                {
                    field_val = DRV_FTM_TBL_BASE_MAX(sram_type, i);
                }

                field_val = (field_val >> unit);
                DRV_SET_FIELD_V(tbl_id, field_id,   ds,   field_val );
            }

        }

        for (i = 0; i < idx; i++)
        {
            tbl_id = tbl_id_array[i];
            cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
            DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));
        }

    }


    /*init oam base*/
    field_val = 0;
    field_id_base = OamTblAddrCtl_mpBaseAddr_f;
    cmd = DRV_IOW(OamTblAddrCtl_t, field_id_base);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));

    sum += DRV_FTM_TBL_MAX_ENTRY_NUM(DRV_FTM_SRAM_TBL_OAM_MEP);
    field_val = (sum >> 6);
    field_id_base = OamTblAddrCtl_maBaseAddr_f;
    cmd = DRV_IOW(OamTblAddrCtl_t, field_id_base);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));

    sum  += (DRV_FTM_TBL_MAX_ENTRY_NUM(DRV_FTM_SRAM_TBL_OAM_MA));
    field_val = (sum >> 6);
    field_id_base = OamTblAddrCtl_maNameBaseAddr_f;
    cmd = DRV_IOW(OamTblAddrCtl_t, field_id_base);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &field_val));

    /*init fib host0 cam bitmap*/
    cmd = DRV_IOW(FibAccelerationCtl_t, FibAccelerationCtl_camDisableBitmap_f);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &g_ftm_master->cam_bitmap));
#endif
    return DRV_E_NONE;
}

int32
drv_dynamic_arb_init(uint32 lchip)
{
    tbls_id_t table_id = MaxTblId_t;
    uint32 cmd = 0;
    uint32 ds[MAX_ENTRY_WORD] = {0};
    uint32 bit_set = 0;
    uint32 couple_mode      = 0;
    uint32 ipfix_couple_en  = 1;

    DRV_IF_ERROR_RETURN(drv_get_dynamic_ram_couple_mode(&couple_mode));

#define ArbTable(i) DynamicKeyShareRam##i##Ctl_t
#define ArbTblFld(i, fld) DynamicKeyShareRam##i##Ctl_shareKeyRam##i##fld##_f
#define ArbTblFldCouple(i, fld) DynamicKeyShareRam##i##Ctl_shareKeyRam##i##Local##fld##_f

    /* Share RAM 0 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(0);
    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_IPFIX_HASH_KEY), DRV_FTM_SRAM0);
    DRV_IOW_FIELD(table_id, ArbTblFld(0, IpfixKeyEn),   &bit_set, ds);
    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FIB0_HASH_KEY), DRV_FTM_SRAM0);
    DRV_IOW_FIELD(table_id, ArbTblFld(0, Host0KeyEn),   &bit_set, ds);
    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FLOW_HASH_KEY), DRV_FTM_SRAM0);
    DRV_IOW_FIELD(table_id, ArbTblFld(0, FlowKeyEn),   &bit_set, ds);
    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_LPM_LKP_KEY), DRV_FTM_SRAM0);
    DRV_IOW_FIELD(table_id, ArbTblFld(0, LpmGrp0En),   &bit_set, ds);
    //TODO DRV_IOW_FIELD(table_id, ArbTblFld(0, LpmGrp1En),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(0, Couple),   &couple_mode, ds);

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 1 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(1);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FIB0_HASH_KEY), DRV_FTM_SRAM1);
    DRV_IOW_FIELD(table_id, ArbTblFld(1, Host0KeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FLOW_HASH_KEY), DRV_FTM_SRAM1);
    DRV_IOW_FIELD(table_id, ArbTblFld(1, FlowKeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_OAM_MEP), DRV_FTM_SRAM1);
    DRV_IOW_FIELD(table_id, ArbTblFld(1, DsOamEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(1, Couple),   &couple_mode, ds);

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 2 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(2);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FIB0_HASH_KEY), DRV_FTM_SRAM2);
    DRV_IOW_FIELD(table_id, ArbTblFld(2, Host0KeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FLOW_HASH_KEY), DRV_FTM_SRAM2);
    DRV_IOW_FIELD(table_id, ArbTblFld(2, FlowKeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_XCOAM_HASH_KEY), DRV_FTM_SRAM2);
    DRV_IOW_FIELD(table_id, ArbTblFld(2, EgrXcOamEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(2, Couple),   &couple_mode, ds);

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 3 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(3);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FIB0_HASH_KEY), DRV_FTM_SRAM3);
    DRV_IOW_FIELD(table_id, ArbTblFld(3, Host0KeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FLOW_HASH_KEY), DRV_FTM_SRAM3);
    DRV_IOW_FIELD(table_id, ArbTblFld(3, FlowKeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_LPM_LKP_KEY), DRV_FTM_SRAM3);
    DRV_IOW_FIELD(table_id, ArbTblFld(3, LpmGrp0En),   &bit_set, ds);
    //TODO DRV_IOW_FIELD(table_id, ArbTblFld(3, LpmGrp1En),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(3, Couple),   &couple_mode, ds);

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 4 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(4);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FIB0_HASH_KEY), DRV_FTM_SRAM4);
    DRV_IOW_FIELD(table_id, ArbTblFld(4, Host0KeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FLOW_HASH_KEY), DRV_FTM_SRAM4);
    DRV_IOW_FIELD(table_id, ArbTblFld(4, FlowKeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_OAM_MEP), DRV_FTM_SRAM4);
    DRV_IOW_FIELD(table_id, ArbTblFld(4, DsOamEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(4, Couple),   &couple_mode, ds);
    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 5 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(5);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_IPFIX_HASH_KEY), DRV_FTM_SRAM5);
    DRV_IOW_FIELD(table_id, ArbTblFld(5, IpfixKeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FIB0_HASH_KEY), DRV_FTM_SRAM5);
    DRV_IOW_FIELD(table_id, ArbTblFld(5, Host0KeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_XCOAM_HASH_KEY), DRV_FTM_SRAM5);
    DRV_IOW_FIELD(table_id, ArbTblFld(5, EgrXcOamEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(5, Couple),   &couple_mode, ds);
    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 6 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(6);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_LPM_LKP_KEY), DRV_FTM_SRAM6);
    DRV_IOW_FIELD(table_id, ArbTblFld(6, LpmGrp0En),   &bit_set, ds);
    //TODO DRV_IOW_FIELD(table_id, ArbTblFld(6, LpmGrp1En),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FIB1_HASH_KEY), DRV_FTM_SRAM6);
    DRV_IOW_FIELD(table_id, ArbTblFld(6, Host1KeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_USERID_HASH_KEY), DRV_FTM_SRAM6);
    DRV_IOW_FIELD(table_id, ArbTblFld(6, UserIdKeyEn),   &bit_set, ds);


    DRV_IOW_FIELD(table_id, ArbTblFldCouple(6, Couple),   &couple_mode, ds);
    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 7 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(7);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_LPM_LKP_KEY), DRV_FTM_SRAM7);
    DRV_IOW_FIELD(table_id, ArbTblFld(7, LpmGrp0En),   &bit_set, ds);
    //TODO DRV_IOW_FIELD(table_id, ArbTblFld(7, LpmGrp1En),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FIB1_HASH_KEY), DRV_FTM_SRAM7);
    DRV_IOW_FIELD(table_id, ArbTblFld(7, Host1KeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_USERID_HASH_KEY), DRV_FTM_SRAM7);
    DRV_IOW_FIELD(table_id, ArbTblFld(7, UserIdKeyEn),   &bit_set, ds);


    DRV_IOW_FIELD(table_id, ArbTblFldCouple(7, Couple),   &couple_mode, ds);
    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 8 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(8);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FIB1_HASH_KEY), DRV_FTM_SRAM8);
    DRV_IOW_FIELD(table_id, ArbTblFld(8, Host1KeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_USERID_HASH_KEY), DRV_FTM_SRAM8);
    DRV_IOW_FIELD(table_id, ArbTblFld(8, UserIdKeyEn),   &bit_set, ds);


    DRV_IOW_FIELD(table_id, ArbTblFldCouple(8, Couple),   &couple_mode, ds);
    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 9 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(9);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FIB1_HASH_KEY), DRV_FTM_SRAM9);
    DRV_IOW_FIELD(table_id, ArbTblFld(9, Host1KeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_USERID_HASH_KEY), DRV_FTM_SRAM9);
    DRV_IOW_FIELD(table_id, ArbTblFld(9, UserIdKeyEn),   &bit_set, ds);


    DRV_IOW_FIELD(table_id, ArbTblFldCouple(9, Couple),   &couple_mode, ds);
    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 10 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(10);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FIB1_HASH_KEY), DRV_FTM_SRAM10);
    DRV_IOW_FIELD(table_id, ArbTblFld(10, Host1KeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_USERID_HASH_KEY), DRV_FTM_SRAM10);
    DRV_IOW_FIELD(table_id, ArbTblFld(10, UserIdKeyEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_OAM_APS), DRV_FTM_SRAM10);
    DRV_IOW_FIELD(table_id, ArbTblFld(10, DsApsEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(10, Couple),   &couple_mode, ds);
    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


#undef ArbTable
#undef ArbTblFld
#undef ArbTblFldCouple
#define ArbTable(i) DynamicAdShareRam##i##Ctl_t
#define ArbTblFld(i, fld) DynamicAdShareRam##i##Ctl_shareAdRam##i##fld##_f
#define ArbTblFldCouple(i, fld) DynamicAdShareRam##i##Ctl_shareAdRam##i##Local##fld##_f

    /* Share RAM 11 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(0);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_IPFIX_AD), DRV_FTM_SRAM11);
    DRV_IOW_FIELD(table_id, ArbTblFld(0, DsIpfixEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_DSMAC_AD), DRV_FTM_SRAM11);
    DRV_IOW_FIELD(table_id, ArbTblFld(0, DsMacEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_DSIP_AD), DRV_FTM_SRAM11);
    DRV_IOW_FIELD(table_id, ArbTblFld(0, DsIpEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FLOW_AD), DRV_FTM_SRAM11);
    DRV_IOW_FIELD(table_id, ArbTblFld(0, DsFlowEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_USERID_AD), DRV_FTM_SRAM11);
    DRV_IOW_FIELD(table_id, ArbTblFld(0, UserIdAdEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(0, Couple),   &couple_mode, ds);

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 12 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(1);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_IPFIX_AD), DRV_FTM_SRAM12);
    DRV_IOW_FIELD(table_id, ArbTblFld(1, DsIpfixEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_DSMAC_AD), DRV_FTM_SRAM12);
    DRV_IOW_FIELD(table_id, ArbTblFld(1, DsMacEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_DSIP_AD), DRV_FTM_SRAM12);
    DRV_IOW_FIELD(table_id, ArbTblFld(1, DsIpEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FLOW_AD), DRV_FTM_SRAM12);
    DRV_IOW_FIELD(table_id, ArbTblFld(1, DsFlowEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_USERID_AD), DRV_FTM_SRAM12);
    DRV_IOW_FIELD(table_id, ArbTblFld(1, UserIdAdEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(1, Couple),   &couple_mode, ds);

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));



    /* Share RAM 13 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(2);
    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_DSMAC_AD), DRV_FTM_SRAM13);
    DRV_IOW_FIELD(table_id, ArbTblFld(2, DsMacEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_DSIP_AD), DRV_FTM_SRAM13);
    DRV_IOW_FIELD(table_id, ArbTblFld(2, DsIpEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FLOW_AD), DRV_FTM_SRAM13);
    DRV_IOW_FIELD(table_id, ArbTblFld(2, DsFlowEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_USERID_AD), DRV_FTM_SRAM13);
    DRV_IOW_FIELD(table_id, ArbTblFld(2, UserIdAdEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(2, Couple),   &couple_mode, ds);

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));



    /* Share RAM 14 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(3);
    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_DSMAC_AD), DRV_FTM_SRAM14);
    DRV_IOW_FIELD(table_id, ArbTblFld(3, DsMacEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_DSIP_AD), DRV_FTM_SRAM14);
    DRV_IOW_FIELD(table_id, ArbTblFld(3, DsIpEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FLOW_AD), DRV_FTM_SRAM14);
    DRV_IOW_FIELD(table_id, ArbTblFld(3, DsFlowEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_USERID_AD), DRV_FTM_SRAM14);
    DRV_IOW_FIELD(table_id, ArbTblFld(3, UserIdAdEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(3, Couple),   &couple_mode, ds);

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 15 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(4);
    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_DSMAC_AD), DRV_FTM_SRAM15);
    DRV_IOW_FIELD(table_id, ArbTblFld(4, DsMacEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_DSIP_AD), DRV_FTM_SRAM15);
    DRV_IOW_FIELD(table_id, ArbTblFld(4, DsIpEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FLOW_AD), DRV_FTM_SRAM15);
    DRV_IOW_FIELD(table_id, ArbTblFld(4, DsFlowEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_USERID_AD), DRV_FTM_SRAM15);
    DRV_IOW_FIELD(table_id, ArbTblFld(4, UserIdAdEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(4, Couple),   &couple_mode, ds);

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));



#undef ArbTable
#undef ArbTblFld
#undef ArbTblFldCouple
#define ArbTable(i) DynamicEditShareRam##i##Ctl_t
#define ArbTblFld(i, fld) DynamicEditShareRam##i##Ctl_shareEditRam##i##fld##_f
#define ArbTblFldCouple(i, fld) DynamicEditShareRam##i##Ctl_shareEditRam##i##Local##fld##_f


    /* Share RAM 16 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(0);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_NEXTHOP), DRV_FTM_SRAM16);
    DRV_IOW_FIELD(table_id, ArbTblFld(0, DsNextHopEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_MET), DRV_FTM_SRAM16);
    DRV_IOW_FIELD(table_id, ArbTblFld(0, DsMetEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(0, Couple),   &couple_mode, ds);

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 17 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(1);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FWD), DRV_FTM_SRAM17);
    DRV_IOW_FIELD(table_id, ArbTblFld(1, DsFwdEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(1, Couple),   &couple_mode, ds);

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 18 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(2);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_NEXTHOP), DRV_FTM_SRAM18);
    DRV_IOW_FIELD(table_id, ArbTblFld(2, DsNextHopEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_MET), DRV_FTM_SRAM18);
    DRV_IOW_FIELD(table_id, ArbTblFld(2, DsMetEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FWD), DRV_FTM_SRAM18);
    DRV_IOW_FIELD(table_id, ArbTblFld(2, DsFwdEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_EDIT), DRV_FTM_SRAM18);
    DRV_IOW_FIELD(table_id, ArbTblFld(2, DsEditEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(2, Couple),   &couple_mode, ds);

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 19 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(3);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_NEXTHOP), DRV_FTM_SRAM19);
    DRV_IOW_FIELD(table_id, ArbTblFld(3, DsNextHopEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_MET), DRV_FTM_SRAM19);
    DRV_IOW_FIELD(table_id, ArbTblFld(3, DsMetEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FWD), DRV_FTM_SRAM19);
    DRV_IOW_FIELD(table_id, ArbTblFld(3, DsFwdEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_EDIT), DRV_FTM_SRAM19);
    DRV_IOW_FIELD(table_id, ArbTblFld(3, DsEditEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(3, Couple),   &couple_mode, ds);

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /* Share RAM 20 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(4);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_NEXTHOP), DRV_FTM_SRAM20);
    DRV_IOW_FIELD(table_id, ArbTblFld(4, DsNextHopEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_MET), DRV_FTM_SRAM20);
    DRV_IOW_FIELD(table_id, ArbTblFld(4, DsMetEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FWD), DRV_FTM_SRAM20);
    DRV_IOW_FIELD(table_id, ArbTblFld(4, DsFwdEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_EDIT), DRV_FTM_SRAM20);
    DRV_IOW_FIELD(table_id, ArbTblFld(4, DsEditEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(4, Couple),   &couple_mode, ds);

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));



    /* Share RAM 21 */
    sal_memset(ds, 0, sizeof(ds));
    table_id = ArbTable(5);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_NEXTHOP), DRV_FTM_SRAM21);
    DRV_IOW_FIELD(table_id, ArbTblFld(5, DsNextHopEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_MET), DRV_FTM_SRAM21);
    DRV_IOW_FIELD(table_id, ArbTblFld(5, DsMetEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_FWD), DRV_FTM_SRAM21);
    DRV_IOW_FIELD(table_id, ArbTblFld(5, DsFwdEn),   &bit_set, ds);

    bit_set = IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(DRV_FTM_SRAM_TBL_EDIT), DRV_FTM_SRAM21);
    DRV_IOW_FIELD(table_id, ArbTblFld(5, DsEditEn),   &bit_set, ds);

    DRV_IOW_FIELD(table_id, ArbTblFldCouple(5, Couple),   &couple_mode, ds);

    cmd = DRV_IOW(table_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));

    return DRV_E_NONE;
}

static int32
drv_flow_lkup_ctl_init(uint8 lchip)
{
    uint32 cmd = 0;
    uint32 ds[MAX_ENTRY_WORD] = {0};
    uint32 tbl_id = 0;
    uint32 en = 0;
    uint32 mem_alloced = 0;

    uint8 i  = 0;
    uint32 bitmap = 0;
    uint32 sram_array[6] = {0};
    uint8 sram_type = 0;
    uint32 couple_mode = 0;
    uint32 poly = 0;

    DRV_IF_ERROR_RETURN(drv_get_dynamic_ram_couple_mode(&couple_mode));

    /*Flow lkup ctl*/
    sal_memset(ds, 0, sizeof(ds));
    mem_alloced = 0;
    tbl_id = FlowHashLookupCtl_t;
    sram_type = DRV_FTM_SRAM_TBL_FLOW_HASH_KEY;
    sal_memset(sram_array, 0, sizeof(sram_array));
    _sys_goldengate_ftm_get_edram_bitmap(sram_type,   &bitmap,   sram_array);

    i  = 0;
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel0HashEn_f,     ds, en);

    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel0HashType_f,   ds, poly);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel0Couple_f,     ds, couple_mode);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 1;
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel1HashEn_f,     ds, en);

    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel1HashType_f,   ds, poly);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel1IndexBase_f,   ds, mem_alloced);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel1Couple_f,     ds, couple_mode);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 2;
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel2HashEn_f,     ds, en);

    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel2HashType_f,   ds, poly);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel2IndexBase_f,   ds, mem_alloced);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel2Couple_f,     ds, couple_mode);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 3;
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel3HashEn_f,     ds, en);
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel3HashType_f,   ds, poly);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel3IndexBase_f,   ds, mem_alloced);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel3Couple_f,     ds, couple_mode);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 4;
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel4HashEn_f,     ds, en);
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel4HashType_f,   ds, poly);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel4IndexBase_f,   ds, mem_alloced);
    DRV_SET_FIELD_V(tbl_id,   FlowHashLookupCtl_flowLevel4Couple_f,     ds, couple_mode);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));

    /*userid  lkup ctl*/
    sal_memset(ds, 0, sizeof(ds));
    mem_alloced = 0;
    tbl_id = UserIdHashLookupCtl_t;
    sram_type = DRV_FTM_SRAM_TBL_USERID_HASH_KEY;
    sal_memset(sram_array, 0, sizeof(sram_array));
    _sys_goldengate_ftm_get_edram_bitmap(sram_type,   &bitmap,   sram_array);

    i  = 0;
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel0HashEn_f,     ds, en);

    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel0HashType_f,   ds, poly);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel0Couple_f,     ds, couple_mode);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 1;
    en = IS_BIT_SET(bitmap, i);
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel1Couple_f,     ds, couple_mode);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel1HashEn_f,     ds, en);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel1HashType_f,   ds, poly);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel1IndexBase_f,   ds, mem_alloced);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 2;
    en = IS_BIT_SET(bitmap, i);
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel2Couple_f,     ds, couple_mode);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel2HashEn_f,     ds, en);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel2HashType_f,   ds, poly);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel2IndexBase_f,   ds, mem_alloced);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 3;
    en = IS_BIT_SET(bitmap, i);
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel3Couple_f,     ds, couple_mode);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel3HashEn_f,     ds, en);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel3HashType_f,   ds, poly);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel3IndexBase_f,   ds, mem_alloced);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 4;
    en = IS_BIT_SET(bitmap, i);
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel4Couple_f,     ds, couple_mode);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel4HashEn_f,     ds, en);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel4HashType_f,   ds, poly);
    DRV_SET_FIELD_V(tbl_id,   UserIdHashLookupCtl_userIdLevel4IndexBase_f,   ds, mem_alloced);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));

    /*XcOamUserid  lkup ctl*/
    sal_memset(ds, 0, sizeof(ds));
    mem_alloced = 0;
    tbl_id = EgressXcOamHashLookupCtl_t;
    sram_type = DRV_FTM_SRAM_TBL_XCOAM_HASH_KEY;
    sal_memset(sram_array, 0, sizeof(sram_array));
    _sys_goldengate_ftm_get_edram_bitmap(sram_type,   &bitmap,   sram_array);

    i = 0;
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id, EgressXcOamHashLookupCtl_egressXcOamLevel0HashEn_f, ds, en);

    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id, EgressXcOamHashLookupCtl_egressXcOamLevel0HashType_f, ds, poly);
    DRV_SET_FIELD_V(tbl_id, EgressXcOamHashLookupCtl_egressXcOamLevel0Couple_f, ds, couple_mode);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i = 1;
    en = IS_BIT_SET(bitmap, 1);
    DRV_SET_FIELD_V(tbl_id, EgressXcOamHashLookupCtl_egressXcOamLevel1Couple_f, ds, couple_mode);
    DRV_SET_FIELD_V(tbl_id, EgressXcOamHashLookupCtl_egressXcOamLevel1HashEn_f, ds, en);
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id, EgressXcOamHashLookupCtl_egressXcOamLevel1HashType_f, ds, poly);
    DRV_SET_FIELD_V(tbl_id, EgressXcOamHashLookupCtl_egressXcOamLevel1IndexBase_f, ds, mem_alloced);

    cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));

    /*Host0lkup ctl*/
    sal_memset(ds, 0, sizeof(ds));
    mem_alloced = 0;
    tbl_id = FibHost0HashLookupCtl_t;
    sram_type = DRV_FTM_SRAM_TBL_FIB0_HASH_KEY;
    sal_memset(sram_array, 0, sizeof(sram_array));
    _sys_goldengate_ftm_get_edram_bitmap(sram_type,   &bitmap,   sram_array);

    i  = 0;
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level0HashEn_f, ds, en);
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level0HashType_f, ds, poly);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level0Couple_f, ds, couple_mode);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 1;
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level1HashEn_f, ds, en);
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level1HashType_f, ds, poly);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level1IndexBase_f, ds, mem_alloced);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level1Couple_f, ds, couple_mode);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 2;
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level2HashEn_f, ds, en);
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level2HashType_f, ds, poly);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level2IndexBase_f, ds, mem_alloced);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level2Couple_f, ds, couple_mode);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 3;
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level3HashEn_f, ds, en);
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level3HashType_f, ds, poly);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level3IndexBase_f, ds, mem_alloced);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level3Couple_f, ds, couple_mode);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 4;
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level4HashEn_f, ds, en);
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level4HashType_f, ds, poly);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level4IndexBase_f, ds, mem_alloced);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level4Couple_f, ds, couple_mode);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;


    i  = 5;
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level5HashEn_f, ds, en);
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level5HashType_f, ds, poly);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level5IndexBase_f, ds, mem_alloced);
    DRV_SET_FIELD_V(tbl_id, FibHost0HashLookupCtl_fibHost0Level5Couple_f, ds, couple_mode);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));

    /*Host1lkup ctl*/
    sal_memset(ds, 0, sizeof(ds));
    mem_alloced = 0;
    tbl_id = FibHost1HashLookupCtl_t;
    sram_type = DRV_FTM_SRAM_TBL_FIB1_HASH_KEY;
    sal_memset(sram_array, 0, sizeof(sram_array));
    _sys_goldengate_ftm_get_edram_bitmap(sram_type,   &bitmap,   sram_array);


    i  = 0;
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);

    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level0HashEn_f, ds, en);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level0HashType_f, ds, poly);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level0Couple_f, ds, couple_mode);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 1;
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level1HashEn_f, ds, en);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level1HashType_f, ds, poly);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level1Couple_f, ds, couple_mode);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level1IndexBase_f, ds, mem_alloced);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 2;
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level2HashEn_f, ds, en);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level2HashType_f, ds, poly);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level2Couple_f, ds, couple_mode);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level2IndexBase_f, ds, mem_alloced);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 3;
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level3HashEn_f, ds, en);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level3HashType_f, ds, poly);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level3Couple_f, ds, couple_mode);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level3IndexBase_f, ds, mem_alloced);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    i  = 4;
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level4HashEn_f, ds, en);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level4HashType_f, ds, poly);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level4Couple_f, ds, couple_mode);
    DRV_SET_FIELD_V(tbl_id, FibHost1HashLookupCtl_fibHost1Level4IndexBase_f, ds, mem_alloced);
    mem_alloced  += en?DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, sram_array[i]):0;

    cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));


    /*IPFix hash ctl*/
    sal_memset(ds, 0, sizeof(ds));
    tbl_id = IpfixHashLookupCtl_t;
    sram_type = DRV_FTM_SRAM_TBL_IPFIX_HASH_KEY;
    _sys_goldengate_ftm_get_edram_bitmap(sram_type,   &bitmap,   sram_array);

    DRV_SET_FIELD_V(tbl_id, IpfixHashLookupCtl_ipfixMemCouple_f,   ds,   couple_mode );

    i  = 0;
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id, IpfixHashLookupCtl_ipfixLevel0HashEn_f,   ds,   en );
    DRV_SET_FIELD_V(tbl_id, IpfixHashLookupCtl_ipfixLevel0HashType_f, ds, poly);
    DRV_SET_FIELD_V(tbl_id, IpfixHashLookupCtl_ipfixLevel1HashEn_f,   ds,   en );
    DRV_SET_FIELD_V(tbl_id, IpfixHashLookupCtl_ipfixLevel1HashType_f, ds, poly);

    i  = 1;
    _sys_goldengate_ftm_get_hash_type(sram_type, sram_array[i], couple_mode, &poly);
    en = IS_BIT_SET(bitmap, i);
    DRV_SET_FIELD_V(tbl_id, IpfixHashLookupCtl_ipfixLevel2HashEn_f,   ds,   en );
    DRV_SET_FIELD_V(tbl_id, IpfixHashLookupCtl_ipfixLevel2HashType_f, ds, poly);
    DRV_SET_FIELD_V(tbl_id, IpfixHashLookupCtl_ipfixLevel3HashEn_f,   ds,   en );
    DRV_SET_FIELD_V(tbl_id, IpfixHashLookupCtl_ipfixLevel3HashType_f, ds, poly);

    cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));

    /*lpm ctl*/
    sal_memset(ds, 0, sizeof(ds));
    tbl_id = FibEngineLookupCtl_t;
    sram_type = DRV_FTM_SRAM_TBL_LPM_LKP_KEY;
    _sys_goldengate_ftm_get_edram_bitmap(sram_type,   &bitmap,   sram_array);
    DRV_SET_FIELD_V(tbl_id, FibEngineLookupCtl_lpmPipelineEn_f,   ds,   1 );
    cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, ds));

    return DRV_E_NONE;
}


static int32
drv_fib_lkup_ctl_init(uint8 lchip)
{
    uint32 cmd = 0;
    FibAccelerationCtl_m ds;
    uint32 tbl_id = 0;
    uint8 i  = 0;
    uint32 bitmap = 0;
    uint32 sram_array[6];
    uint8 sram_type = 0;

    /*Host0lkup ctl*/
    sal_memset(&ds, 0, sizeof(ds));

    tbl_id = FibAccelerationCtl_t;
    sram_type = DRV_FTM_SRAM_TBL_FIB0_HASH_KEY;
    _sys_goldengate_ftm_get_edram_bitmap(sram_type,   &bitmap,   sram_array);
    //-bitmap = DRV_FTM_TBL_MEM_BITMAP(tbl_id);

    cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ds));

    /*Support 6 level fibhostAcc*/
    for (i = 0; i < 6; i++)
    {
        if (IS_BIT_SET(bitmap, i))
        {
            DRV_SET_FIELD_V(tbl_id, FibAccelerationCtl_host0Level0HashEn_f + i*2, &ds, 1);
        }
    }

    cmd = DRV_IOW(tbl_id, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(DRV_IOCTL(lchip, 0, cmd, &ds));

    return DRV_E_NONE;
}

static int32
_drv_ftm_get_cam_info(drv_ftm_info_detail_t* p_ftm_info)
{
    p_ftm_info->max_size = g_ftm_master->cfg_max_cam_num[p_ftm_info->tbl_type];
    p_ftm_info->used_size = g_ftm_master->cfg_max_cam_num[p_ftm_info->tbl_type] - g_ftm_master->conflict_cam_num[p_ftm_info->tbl_type];
    return DRV_E_NONE;
}

static int32
_drv_ftm_get_tcam_info_detail(drv_ftm_info_detail_t* p_ftm_info)
{
    uint8 tcam_key_type        = 0;
    uint32 tcam_key_id          = MaxTblId_t;
    uint32 tcam_ad_a[20]        = {0};
    uint32 old_key_size = 0;
    uint8 key_share_num         = 0;
    uint8 ad_share_num          = 0;
    uint32 key_size             = 0;
    uint8 index                 = 0;
    uint8 key_type = 0;
    char* arr_tcam_tbl[] = {
        "IpeAcl0",
        "IpeAcl1",
        "IpeAcl2",
        "IpeAcl3",
        "IpeAcl4",
        "IpeAcl5",
        "IpeAcl6",
        "IpeAcl7",
        "EpeAcl0",
        "EpeAcl1",
        "EpeAcl2",
        "SCL0",
        "SCL1",
        "LPM0All",
        "LPM0",
        "LPM0SaPrivate",
        "LPM0DaPublic",
        "LPM0SaPublic",
        "LPM0Lk2",
        "LPM0SaPrivateLk2",
        "LPM0DaPublicLk2",
        "LPM0SaPublicLk2",
        "LPM1",
        "Static"
    };


    DRV_IF_ERROR_RETURN(_drv_ftm_get_key_id_info(p_ftm_info->tbl_type, key_size, &tcam_key_type, &key_type));

    drv_ftm_get_tcam_info(tcam_key_type,
                             p_ftm_info->tbl_id,
                             tcam_ad_a,
                             &key_share_num,
                             &ad_share_num);
    if (0 == key_share_num || 0 == ad_share_num)
    {
        return DRV_E_NONE;
    }

    p_ftm_info->tbl_entry_num = key_share_num;

    /*tcam key alloc*/
    for (index = 0; index < key_share_num; index++)
    {
        tcam_key_id = p_ftm_info->tbl_id[index];

        if (tcam_key_id >= MaxTblId_t)
        {
            DRV_FTM_DBG_OUT("unexpect tbl id:%d\r\n", tcam_key_id);
            return DRV_E_INVAILD_TYPE;
        }

        p_ftm_info->max_idx[index]  = TABLE_MAX_INDEX(tcam_key_id);
        key_size            = TCAM_KEY_SIZE(tcam_key_id);
        if (tcam_key_type >= DRV_FTM_TCAM_TYPE_IGS_LPM0 && tcam_key_type <= DRV_FTM_TCAM_TYPE_IGS_LPM1)
        {
            key_size            = (key_size / DRV_LPM_KEY_BYTES_PER_ENTRY) * 40;
        }
        else
        {
            key_size            = (key_size / DRV_BYTES_PER_ENTRY) * 80;
        }

        if (tcam_key_type != DRV_FTM_TCAM_TYPE_IGS_LPM1)
        {
            if (old_key_size != key_size)
            {
                p_ftm_info->key_size[index] = key_size;
            }
            else
            {
                p_ftm_info->key_size[index] = 0;
            }
        }
        else
        {
            p_ftm_info->key_size[index] = key_size;
        }

        old_key_size = key_size;

    }

    sal_strcpy(p_ftm_info->str, arr_tcam_tbl[tcam_key_type]);

    return DRV_E_NONE;
}

static int32
_drv_ftm_get_edram_info_detail(drv_ftm_info_detail_t* p_ftm_info)
{
    uint8 drv_tbl_id = 0;
    uint8 mem_id = 0;
    uint8 mem_num = 0;
    uint32 sram_tbl_a[50]       = {0};
    uint8 share_tbl_num         = 0;

    _drv_ftm_get_tbl_id(p_ftm_info->tbl_type, &drv_tbl_id);

    _drv_ftm_get_sram_tbl_id(drv_tbl_id, sram_tbl_a, &share_tbl_num);
    _drv_ftm_get_sram_tbl_name(drv_tbl_id, p_ftm_info->str);

    for (mem_id = DRV_FTM_SRAM0; mem_id < DRV_FTM_SRAM_MAX; mem_id++)
    {
        if (IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(drv_tbl_id), mem_id) &&
            DRV_FTM_TBL_MEM_ENTRY_NUM(drv_tbl_id, mem_id))
        {
            p_ftm_info->mem_id[mem_num] = mem_id;
            p_ftm_info->entry_num[mem_num] = DRV_FTM_TBL_MEM_ENTRY_NUM(drv_tbl_id, mem_id);
            p_ftm_info->offset[mem_num] = DRV_FTM_TBL_MEM_START_OFFSET(drv_tbl_id, mem_id);

            ++ mem_num;
        }
    }

    p_ftm_info->tbl_entry_num = mem_num;

    return DRV_E_NONE;
}

int32
drv_ftm_set_tcam_spec(void* profile_info)
{
    uint8 lchip = 0;
    uint32 entry_num = 0;
    uint8 tcam_key_type = 0;

    for (tcam_key_type = DRV_FTM_TCAM_TYPE_IGS_ACL0; tcam_key_type <= DRV_FTM_TCAM_TYPE_IGS_USERID1; tcam_key_type++)
    {

        entry_num =  DRV_FTM_KEY_MAX_INDEX(tcam_key_type);

        g_ftm_master->tcam_specs[tcam_key_type][DRV_FTM_TCAM_SIZE_80] = (entry_num / 4) / 1;
        g_ftm_master->tcam_specs[tcam_key_type][DRV_FTM_TCAM_SIZE_160]  = (entry_num / 4) / 2;
        g_ftm_master->tcam_specs[tcam_key_type][DRV_FTM_TCAM_SIZE_320]  = (entry_num / 4) / 4;
        g_ftm_master->tcam_specs[tcam_key_type][DRV_FTM_TCAM_SIZE_640] = (entry_num / 4) / 8;


        g_ftm_master->tcam_offset[tcam_key_type][DRV_FTM_TCAM_SIZE_80] = 0;
        g_ftm_master->tcam_offset[tcam_key_type][DRV_FTM_TCAM_SIZE_160] = (g_ftm_master->tcam_specs[tcam_key_type][DRV_FTM_TCAM_SIZE_80])/2;

        g_ftm_master->tcam_offset[tcam_key_type][DRV_FTM_TCAM_SIZE_320] = (g_ftm_master->tcam_specs[tcam_key_type][DRV_FTM_TCAM_SIZE_80]
                                                                            + g_ftm_master->tcam_specs[tcam_key_type][DRV_FTM_TCAM_SIZE_160]*2)/4;

        g_ftm_master->tcam_offset[tcam_key_type][DRV_FTM_TCAM_SIZE_640] = (g_ftm_master->tcam_specs[tcam_key_type][DRV_FTM_TCAM_SIZE_80]
                                                                            +g_ftm_master->tcam_specs[tcam_key_type][DRV_FTM_TCAM_SIZE_160]*2
                                                                            +g_ftm_master->tcam_specs[tcam_key_type][DRV_FTM_TCAM_SIZE_320]*4)/8;
    }

    for (tcam_key_type = DRV_FTM_TCAM_TYPE_IGS_LPM0_ALL; tcam_key_type < DRV_FTM_TCAM_TYPE_IGS_LPM1; tcam_key_type++)
    {
        entry_num =  DRV_FTM_KEY_MAX_INDEX(tcam_key_type);

        g_ftm_master->tcam_specs[tcam_key_type][DRV_FTM_TCAM_SIZE_LPMhalf] = (entry_num  / 2) / 1;
        g_ftm_master->tcam_specs[tcam_key_type][DRV_FTM_TCAM_SIZE_LPMSingle]  = (entry_num / 2) / 2;
        g_ftm_master->tcam_specs[tcam_key_type][DRV_FTM_TCAM_SIZE_LPMDouble]  = (entry_num / 2) / 4;

        g_ftm_master->tcam_offset[tcam_key_type][DRV_FTM_TCAM_SIZE_LPMhalf] = 0;
        g_ftm_master->tcam_offset[tcam_key_type][DRV_FTM_TCAM_SIZE_LPMSingle] = (g_ftm_master->tcam_specs[tcam_key_type][DRV_FTM_TCAM_SIZE_LPMhalf]) / 2;
        g_ftm_master->tcam_offset[tcam_key_type][DRV_FTM_TCAM_SIZE_LPMDouble] = (g_ftm_master->tcam_specs[tcam_key_type][DRV_FTM_TCAM_SIZE_LPMhalf]) / 4;
    }

    return 0;
}


#define _____APIs_____
int32
drv_ftm_get_entry_num(uint8 lchip, uint32 tbl_id, uint32* entry_num)
{

    uint8 size = 0;
    uint8 tcam_key_type = 0;
    uint8 size_type = 0;


    if (NULL == TABLE_EXT_INFO_PTR(tbl_id))
    {
        goto label1;
    }

    if (TABLE_EXT_INFO_TYPE(tbl_id) == EXT_INFO_TYPE_TCAM_AD)
    {
        goto label1;
    }

    if (TCAM_KEY_MODULE(tbl_id) != TCAM_MODULE_LPM )
    {
        goto label1;
    }

    tcam_key_type = TCAM_KEY_TYPE(tbl_id);

    if(TCAM_KEY_MODULE(tbl_id) == TCAM_MODULE_LPM )
    {

        if (tcam_key_type == DRV_FTM_TCAM_TYPE_IGS_LPM1)
        {
            goto label1;
        }

        size_type = drv_ftm_alloc_tcam_key_map_szietype(tbl_id);
    }


    *entry_num = g_ftm_master->tcam_specs[tcam_key_type][size_type];
    return DRV_E_NONE;


    label1:
    *entry_num = TABLE_MAX_INDEX(tbl_id);

    return DRV_E_NONE;
}


int32
drv_ftm_map_tcam_index(uint8 lchip,
                       uint32 tbl_id,
                       uint32 old_index,
                       uint32* new_index)
{
    uint8 size = 0;
    uint8 tcam_key_type = 0;
    uint8 size_type = 0;

    if (NULL == TABLE_EXT_INFO_PTR(tbl_id))
    {
        return 0;
    }

    if (TCAM_KEY_MODULE(tbl_id) != TCAM_MODULE_ACL
        && TCAM_KEY_MODULE(tbl_id) != TCAM_MODULE_SCL
        && TCAM_KEY_MODULE(tbl_id) != TCAM_MODULE_LPM )
    {
        return 0;
    }

    tcam_key_type = TCAM_KEY_TYPE(tbl_id);

    if (TCAM_KEY_MODULE(tbl_id) == TCAM_MODULE_ACL)
    {

        /*
        80  bits / (2 * 80bits) = 0 ȡ type == 0
        160 bits / (2 * 80bits) = 1 ȡ type == 1
        320 bits / (2 * 80bits) = 2 ȡ type == 2
        640 bits / (2 * 80bits) = 4 ȡ type == 3
        */
        size_type = TCAM_KEY_SIZE(tbl_id) / (DRV_BYTES_PER_ENTRY * 2);
        size_type = (4 == size_type) ? 3 : size_type;

        *new_index = g_ftm_master->tcam_offset[tcam_key_type][size_type] + old_index;

        if (TABLE_EXT_INFO_TYPE(tbl_id) == EXT_INFO_TYPE_TCAM_AD)
        {
            if (size_type == 0)
            {
                *new_index = (*new_index) *(TCAM_KEY_SIZE(tbl_id) / (DRV_BYTES_PER_ENTRY*1));
            }
            else
            {
                *new_index = (*new_index) *(TCAM_KEY_SIZE(tbl_id) / (DRV_BYTES_PER_ENTRY*2));
            }
        }

    }
    else if (TCAM_KEY_MODULE(tbl_id) == TCAM_MODULE_SCL)
    {
        if (TABLE_EXT_INFO_TYPE(tbl_id) == EXT_INFO_TYPE_TCAM_AD)
        {
           return 0;
        }

        if (tcam_key_type == DRV_FTM_TCAM_TYPE_IGS_USERID1)
        {
            return 0;
        }

        size_type = TCAM_KEY_SIZE(tbl_id) / (DRV_BYTES_PER_ENTRY * 2);
        size_type = (4 == size_type) ? 3 : size_type;

        *new_index = g_ftm_master->tcam_offset[tcam_key_type][size_type] + old_index;
    }
    else if(TCAM_KEY_MODULE(tbl_id) == TCAM_MODULE_LPM )
    {

        if (tcam_key_type == DRV_FTM_TCAM_TYPE_IGS_LPM1)
        {
            return 0;
        }

        size_type = TCAM_KEY_SIZE(tbl_id) / (DRV_LPM_KEY_BYTES_PER_ENTRY);
        if (size_type == 2)
        {
            size_type = DRV_FTM_TCAM_SIZE_LPMSingle;
        }
        else if(size_type == 4)
        {
            size_type = DRV_FTM_TCAM_SIZE_LPMDouble;
        }
        else
        {
            size_type = DRV_FTM_TCAM_SIZE_LPMhalf;
        }

        *new_index = g_ftm_master->tcam_offset[tcam_key_type][size_type] + old_index;

        if (TABLE_EXT_INFO_TYPE(tbl_id) == EXT_INFO_TYPE_TCAM_LPM_AD)
        {
            *new_index = (*new_index) *(TCAM_KEY_SIZE(tbl_id) / DRV_LPM_KEY_BYTES_PER_ENTRY);
        }
    }


   /*sal_printf("%20s index:0x%x, new index:0x%x\n", TABLE_NAME(tbl_id), old_index, *new_index);*/

    return 0;

}


int32
drv_ftm_lookup_ctl_init(uint8 lchip)
{
    DRV_IF_ERROR_RETURN(drv_tcam_ctl_init(lchip));
    DRV_IF_ERROR_RETURN(drv_dynamic_cam_init(lchip));
    DRV_IF_ERROR_RETURN(drv_dynamic_arb_init(lchip));
    DRV_IF_ERROR_RETURN(drv_flow_lkup_ctl_init(lchip));
    DRV_IF_ERROR_RETURN(drv_fib_lkup_ctl_init(lchip));

    return DRV_E_NONE;
}

int32
drv_ftm_mem_alloc(void* p_profile_info)
{
    drv_ftm_profile_info_t *profile_info = (drv_ftm_profile_info_t *)p_profile_info;

    DRV_PTR_VALID_CHECK(profile_info);

    if ((profile_info->profile_type >= 1)
        && ((profile_info->profile_type != 12)))
    {
        return DRV_E_INVAILD_TYPE;
    }

    /*init global param*/
    DRV_IF_ERROR_RETURN(drv_ftm_init(profile_info));

    /*set profile*/
    DRV_IF_ERROR_RETURN(drv_ftm_set_profile(profile_info));

    /*alloc hash table*/
    DRV_IF_ERROR_RETURN(drv_ftm_alloc_sram());

    /* alloc tcam table*/
    DRV_IF_ERROR_RETURN(drv_ftm_alloc_tcam());

    /* alloc static table*/
    DRV_IF_ERROR_RETURN(drv_ftm_alloc_static());


    DRV_IF_ERROR_RETURN(drv_ftm_alloc_cam(&profile_info->cam_info));

    DRV_IF_ERROR_RETURN(drv_ftm_set_tcam_spec(profile_info));

    return DRV_E_NONE;


}

int32
drv_ftm_get_lpm_tcam_info(uint32 tblid, uint32* p_entry_offset, uint32* p_entry_num, uint32* p_entry_size)
{
    uint8 size_type = 0;
    uint8 tcam_type = 0;
    uint8 mem_id = 0;

    size_type = drv_ftm_alloc_tcam_key_map_szietype(tblid);
#if 0
    if ((DsLpmTcamIpv440Key_t == tblid) || (DsLpmTcamIpv6160Key0_t == tblid))
    {
        tcam_type = DRV_FTM_TCAM_TYPE_IGS_LPM0;
        mem_id = DRV_FTM_TCAM_KEY7 - DRV_FTM_TCAM_KEY0;
        *p_entry_size = TABLE_ENTRY_SIZE(tblid) / DRV_LPM_KEY_BYTES_PER_ENTRY;
    }
    else if ((DsLpmTcamIpv4Pbr160Key_t == tblid) || (DsLpmTcamIpv6320Key_t == tblid)
            || (DsLpmTcamIpv4NAT160Key_t == tblid) || (DsLpmTcamIpv6160Key1_t == tblid))
    {
        tcam_type = DRV_FTM_TCAM_TYPE_IGS_LPM1;
        mem_id = DRV_FTM_TCAM_KEY8 - DRV_FTM_TCAM_KEY0;
        *p_entry_size = TABLE_ENTRY_SIZE(tblid) / DRV_BYTES_PER_ENTRY;
    }
    else
    {
        return DRV_E_INVALID_TCAM_TYPE;
    }

    *p_entry_offset = DRV_FTM_KEY_START_OFFSET(tcam_type, size_type, mem_id);
    *p_entry_num = DRV_FTM_KEY_ENTRY_NUM(tcam_type, size_type, mem_id);
#endif
    return DRV_E_NONE;
}

int32
drv_ftm_alloc_cam_offset(uint32 tbl_id, uint32 *offset)
{
    uint8 bit_len = 0;
    uint32 *bitmap0  = 0;
    uint32 *bitmap1  = 0;
    uint32 *bitmap2  = 0;

    uint32 *bitmap    = 0;
    uint32 loop_cnt  = 0;
    uint32 bit_offset = 0;

    uint8 cam_type = 0;
    uint32 alloc_offset = 0;

    /*1. get clear bit*/
    bit_len  = TABLE_ENTRY_SIZE(tbl_id) / BYTE_TO_4W;

    _drv_ftm_get_cam_by_tbl_id(tbl_id, &cam_type);
    if (DRV_FTM_CAM_TYPE_INVALID == cam_type)
    {
        return DRV_E_INVAILD_TYPE;
    }

    DRV_FTM_CAM_CHECK_TBL_VALID(cam_type, tbl_id);

    if ((DRV_FTM_CAM_TYPE_FIB_HOST1_NAT == cam_type)
        || (DRV_FTM_CAM_TYPE_FIB_HOST1_MC == cam_type))
    {
        bitmap0 = &g_ftm_master->fib1_cam_bitmap0[0];
        bitmap1 = &g_ftm_master->fib1_cam_bitmap1[0];
        bitmap2 = &g_ftm_master->fib1_cam_bitmap2[0];

        loop_cnt = 32/bit_len;
    }
    else if ((DRV_FTM_CAM_TYPE_SCL == cam_type)
        || (DRV_FTM_CAM_TYPE_DCN == cam_type)
        || (DRV_FTM_CAM_TYPE_MPLS == cam_type))
    {
        bitmap0 = &g_ftm_master->userid_cam_bitmap0[0];
        bitmap1 = &g_ftm_master->userid_cam_bitmap1[0];
        bitmap2 = &g_ftm_master->userid_cam_bitmap2[0];

        loop_cnt = 32/bit_len;
    }
    else if ((DRV_FTM_CAM_TYPE_XC == cam_type)
            || (DRV_FTM_CAM_TYPE_OAM == cam_type))
    {
        bitmap0 = &g_ftm_master->xcoam_cam_bitmap0[0];
        bitmap1 = &g_ftm_master->xcoam_cam_bitmap1[0];
        bitmap2 = &g_ftm_master->xcoam_cam_bitmap2[0];

        loop_cnt = 128/bit_len;
    }

    /*judge allocate or not*/
    if(g_ftm_master->conflict_cam_num[cam_type] < bit_len)
    {
        return DRV_E_HASH_CONFLICT;
    }

    bitmap  = (1 == bit_len) ? bitmap0 : ((2 == bit_len) ? bitmap1 : bitmap2);

    for(bit_offset = 0; bit_offset < loop_cnt; bit_offset++)
    {
        if(!IS_BIT_SET(bitmap[(bit_offset/32)], (bit_offset%32)))
        {
            break;
        }
    }

    if(bit_offset == loop_cnt)
    {
        return DRV_E_HASH_CONFLICT;
    }

    /*alloc num*/
    g_ftm_master->conflict_cam_num[cam_type] -= bit_len;

    alloc_offset  = bit_offset*bit_len;

    /*set bitmap*/
    if (1 == bit_len)
    {
        SET_BIT(bitmap0[alloc_offset/32], (alloc_offset%32));
        SET_BIT(bitmap1[(alloc_offset/2)/32], ((alloc_offset/2)%32));
        SET_BIT(bitmap2[(alloc_offset/4)/32], ((alloc_offset/4)%32));
    }
    else if (2 == bit_len)
    {
        SET_BIT(bitmap0[alloc_offset/32], (alloc_offset%32));
        SET_BIT(bitmap0[(alloc_offset+1)/32], ((alloc_offset+1)%32));

        SET_BIT(bitmap1[(alloc_offset/2)/32], ((alloc_offset/2)%32));
        SET_BIT(bitmap2[(alloc_offset/4)/32], ((alloc_offset/4)%32));
    }
    else if (4 == bit_len)
    {
        SET_BIT(bitmap0[alloc_offset/32], (alloc_offset%32));
        SET_BIT(bitmap0[(alloc_offset+1)/32], ((alloc_offset+1)%32));
        SET_BIT(bitmap0[(alloc_offset+2)/32], ((alloc_offset+2)%32));
        SET_BIT(bitmap0[(alloc_offset+3)/32], ((alloc_offset+3)%32));

        SET_BIT(bitmap1[(alloc_offset/2)/32], ((alloc_offset/2)%32));
        SET_BIT(bitmap1[(alloc_offset/2+1)/32], ((alloc_offset/2+1)%32));

        SET_BIT(bitmap2[(alloc_offset/4)/32], ((alloc_offset/4)%32));
    }

    *offset = alloc_offset;

    return DRV_E_NONE;
}

int32
drv_ftm_free_cam_offset(uint32 tbl_id, uint32 offset)
{
    uint8 bit_len = 0;
    uint32 *bitmap0  = 0;
    uint32 *bitmap1  = 0;
    uint32 *bitmap2  = 0;

    uint8 bit_offset0 = 0;
    uint8 bit_offset1 = 0;
    uint8 bit_offset2 = 0;

    uint8 cam_type = 0;
    uint8 is_alloc = 0;

    /*1. get clear bit*/
    bit_len  = TABLE_ENTRY_SIZE(tbl_id) / 12;


    _drv_ftm_get_cam_by_tbl_id(tbl_id, &cam_type);
    if (DRV_FTM_CAM_TYPE_INVALID == cam_type)
    {
        return DRV_E_INVAILD_TYPE;
    }

    if ((DRV_FTM_CAM_TYPE_FIB_HOST1_NAT == cam_type)
        || (DRV_FTM_CAM_TYPE_FIB_HOST1_MC == cam_type))
    {
        bitmap0 = &g_ftm_master->fib1_cam_bitmap0[0];
        bitmap1 = &g_ftm_master->fib1_cam_bitmap1[0];
        bitmap2 = &g_ftm_master->fib1_cam_bitmap2[0];
        bit_offset0 = offset;
        bit_offset1 = offset/2;
        bit_offset2 = offset/4;
    }
    else if ((DRV_FTM_CAM_TYPE_SCL == cam_type)
        || (DRV_FTM_CAM_TYPE_DCN == cam_type)
        || (DRV_FTM_CAM_TYPE_MPLS == cam_type))
    {
        bitmap0 = &g_ftm_master->userid_cam_bitmap0[0];
        bitmap1 = &g_ftm_master->userid_cam_bitmap1[0];
        bitmap2 = &g_ftm_master->userid_cam_bitmap2[0];
        bit_offset0 = offset;
        bit_offset1 = offset/2;
        bit_offset2 = offset/4;
    }
    else if ((DRV_FTM_CAM_TYPE_XC == cam_type)
            || (DRV_FTM_CAM_TYPE_OAM == cam_type))
    {
        bitmap0 = &g_ftm_master->xcoam_cam_bitmap0[offset/32];
        bitmap1 = &g_ftm_master->xcoam_cam_bitmap1[offset/64];
        bitmap2 = &g_ftm_master->xcoam_cam_bitmap2[offset/128];

        bit_offset0 = offset%32;
        bit_offset1 = (offset/2)%32;
        bit_offset2 = (offset/4)%32;
    }

    /*judge allocate or not*/
    if (1 == bit_len)
    {
        is_alloc = IS_BIT_SET((*bitmap0), bit_offset0);
    }
    else if (2 == bit_len)
    {
        is_alloc = IS_BIT_SET((*bitmap1), bit_offset1);
    }
    else if (4 == bit_len)
    {
        is_alloc = IS_BIT_SET((*bitmap2), bit_offset2);
    }

    if(!is_alloc)
    {
        return DRV_E_INVALID_ALLOC_INFO;
    }

    /*free num*/
    g_ftm_master->conflict_cam_num[cam_type] += bit_len;

    /*free bitmap*/
    if (1 == bit_len)
    {
        CLEAR_BIT((*bitmap0), bit_offset0);


        if((!IS_BIT_SET((*bitmap0), (bit_offset0/2*2))
            &&(!IS_BIT_SET((*bitmap0), (bit_offset0/2*2 + 1)))))
        {
            CLEAR_BIT((*bitmap1), bit_offset1);
        }

        if(!IS_BIT_SET((*bitmap0), (bit_offset0/4*4))
            &&(!IS_BIT_SET((*bitmap0), (bit_offset0/4*4 + 1)))
            && (!IS_BIT_SET((*bitmap0), (bit_offset0/4*4 + 2)))
            && (!IS_BIT_SET((*bitmap0), (bit_offset0/4*4 + 3))))
        {
            CLEAR_BIT((*bitmap2), bit_offset2);
        }

    }
    else if (2 == bit_len)
    {
        CLEAR_BIT((*bitmap1), bit_offset1);

        CLEAR_BIT((*bitmap0), ((bit_offset0/2)*2));
        CLEAR_BIT((*bitmap0), ((bit_offset0/2)*2 + 1));

        if(!IS_BIT_SET((*bitmap1), (bit_offset1/2*2))
            &&(!IS_BIT_SET((*bitmap1), (bit_offset1/2*2 + 1))))
        {
            CLEAR_BIT((*bitmap2), bit_offset2);
        }

    }
    else if (4 == bit_len)
    {
        CLEAR_BIT((*bitmap2), bit_offset2);

        CLEAR_BIT((*bitmap1), ((bit_offset1/2)*2));
        CLEAR_BIT((*bitmap1), ((bit_offset1/2)*2 + 1));

        CLEAR_BIT((*bitmap0), ((bit_offset0/4)*4));
        CLEAR_BIT((*bitmap0), ((bit_offset0/4*4) + 1));
        CLEAR_BIT((*bitmap0), ((bit_offset0/4*4) + 2));
        CLEAR_BIT((*bitmap0), ((bit_offset0/4*4) + 3));
    }

    return DRV_E_NONE;
}

int32
drv_ftm_get_info_detail(drv_ftm_info_detail_t* p_ftm_info)
{

    switch (p_ftm_info->info_type)
    {
        case DRV_FTM_INFO_TYPE_CAM:
            DRV_IF_ERROR_RETURN(_drv_ftm_get_cam_info(p_ftm_info));
            break;
        case DRV_FTM_INFO_TYPE_TCAM:
            DRV_IF_ERROR_RETURN(_drv_ftm_get_tcam_info_detail(p_ftm_info));
            break;
        case DRV_FTM_INFO_TYPE_EDRAM:
            DRV_IF_ERROR_RETURN(_drv_ftm_get_edram_info_detail(p_ftm_info));
            break;
        case DRV_FTM_INFO_TYPE_LPM_MODEL:
            p_ftm_info->l3.lpm_model = g_ftm_master->lpm_model;
            break;
        case DRV_FTM_INFO_TYPE_NAT_PBR_EN:
            p_ftm_info->l3.nat_pbr_en = g_ftm_master->nat_pbr_enable;
            break;
        default:
            break;
    }

    return DRV_E_NONE;
}

int32
drv_goldengate_ftm_check_tbl_recover(uint8 mem_id, uint32 ram_offset, uint8* p_recover, uint32* p_tblid)
{
    uint32 sram_type       = 0, tbl_id = 0;
    uint32 mem_entry_num   = 0;
    uint32 start_offset    = 0, entry_num = 0;
    uint32 sram_tbl_a[50]  = {0};
    uint32 tcam_ad_a[20]   = {0};
    uint8  share_tbl_num   = 0, size_type = 0, ad_share_num = 0, tcam_key_type = 0;
    uint8  is_lpm = 0, ad_id = 0;

    if ((NULL == p_recover) || (NULL == p_tblid))
    {
        return DRV_E_INVALID_POINT;
    }
    *p_tblid = MaxTblId_t;

    if (mem_id < DRV_FTM_SRAM_MAX)
    {
        for (sram_type = 0; sram_type < DRV_FTM_SRAM_TBL_MAX; sram_type++)
        {
            mem_entry_num = DRV_FTM_TBL_MEM_ENTRY_NUM(sram_type, mem_id);
            if (!IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(sram_type), mem_id) || 0 == mem_entry_num)
            {
                continue;
            }
            else
            {
                start_offset = DRV_FTM_TBL_MEM_START_OFFSET(sram_type, mem_id);
                if ((ram_offset >= start_offset) && (ram_offset < (start_offset+ mem_entry_num)))
                {

                    break;
                }
                else
                {
                    continue;
                }
            }
        }

        if (sram_type == DRV_FTM_SRAM_TBL_MAX)
        {
            *p_recover = 0;
            return DRV_E_NONE;
        }
        else
        {
            /*
                DsOamLmStats DsBfdMep DsBfdRmep DsEthMep DsEthRmep can't recover
            */
            if ((DRV_FTM_SRAM_TBL_OAM_MEP == sram_type)
                || (DRV_FTM_SRAM_TBL_OAM_LM == sram_type)
                || (DRV_FTM_SRAM_TBL_IPFIX_HASH_KEY == sram_type)
                || (DRV_FTM_SRAM_TBL_IPFIX_AD == sram_type))
            {
                *p_recover = 0;
            }
            else
            {
                *p_recover = 1;
            }

            _drv_ftm_get_sram_tbl_id(sram_type, sram_tbl_a, &share_tbl_num);
            *p_tblid = sram_tbl_a[0];
        }
    }
    else if ((mem_id >= DRV_FTM_TCAM_AD0) && (mem_id < DRV_FTM_TCAM_ADM))
    {
        ad_id = mem_id - DRV_FTM_TCAM_AD0;

        for (tcam_key_type = DRV_FTM_TCAM_TYPE_IGS_ACL0; tcam_key_type < DRV_FTM_TCAM_TYPE_MAX; tcam_key_type++)
        {
            if(tcam_key_type >= DRV_FTM_TCAM_TYPE_IGS_LPM0 && tcam_key_type <= DRV_FTM_TCAM_TYPE_IGS_LPM1)
            {
                is_lpm = 1;
            }

            for (size_type = DRV_FTM_TCAM_SIZE_160; size_type < DRV_FTM_TCAM_SIZE_MAX; size_type++)
            {
                drv_ftm_get_tcam_ad_by_size_type(tcam_key_type, size_type, tcam_ad_a,  &ad_share_num);

                entry_num = 0;

                tbl_id = tcam_ad_a[0];
                entry_num =  DRV_FTM_KEY_ENTRY_NUM(tcam_key_type, size_type, ad_id);
                if (0 == entry_num)
                {
                    continue;
                }

                if (is_lpm)
                {
                    if (DRV_FTM_TCAM_AD7 == mem_id)
                    {
                        if ((ram_offset >= DRV_FTM_KEY_START_OFFSET(tcam_key_type, size_type, ad_id))
                           && (ram_offset < (DRV_FTM_KEY_START_OFFSET(tcam_key_type, size_type, ad_id) + entry_num)))
                        {
                            *p_tblid = tbl_id;
                            *p_recover = 1;
                            return DRV_E_NONE;
                        }
                    }
                    else
                    {
                        if ((ram_offset >= (DRV_FTM_KEY_START_OFFSET(tcam_key_type, size_type, ad_id) / 2))
                            && (ram_offset < (DRV_FTM_KEY_START_OFFSET(tcam_key_type, size_type, ad_id) / 2) + ((entry_num / 2))))
                        {
                            *p_tblid = tbl_id;
                            *p_recover = 1;
                            return DRV_E_NONE;
                        }
                    }
                }
                else
                {
                    if ((ram_offset >= DRV_FTM_KEY_START_OFFSET(tcam_key_type, size_type, ad_id))
                        && (ram_offset < (DRV_FTM_KEY_START_OFFSET(tcam_key_type, size_type, ad_id) + entry_num)))
                    {
                        *p_tblid = tbl_id;
                        *p_recover = 1;
                        return DRV_E_NONE;
                    }
                }
            }
        }
    }
    else
    {
        return DRV_E_INVALID_PARAMETER;
    }

    return DRV_E_NONE;
}

int32
drv_ftm_get_sram_type(uint32 mem_id, uint8* p_sram_type)
{
    uint8 sram_type = 0;
    for (sram_type = DRV_FTM_SRAM_TBL_FIB0_HASH_KEY; sram_type <= DRV_FTM_SRAM_TBL_XCOAM_HASH_KEY; sram_type++)
    {
        if (IS_BIT_SET(DRV_FTM_TBL_MEM_BITMAP(sram_type), mem_id))
        {
            break;
        }
    }

    switch (sram_type)
    {
        case DRV_FTM_SRAM_TBL_FIB0_HASH_KEY:
            *p_sram_type = DRV_FTM_TBL_FIB0_HASH_KEY;
            break;

        case DRV_FTM_SRAM_TBL_FIB1_HASH_KEY:
            *p_sram_type = DRV_FTM_TBL_FIB1_HASH_KEY;
            break;

        case DRV_FTM_SRAM_TBL_FLOW_HASH_KEY:
            *p_sram_type = DRV_FTM_TBL_FLOW_HASH_KEY;
            break;

        case DRV_FTM_SRAM_TBL_IPFIX_HASH_KEY:
            *p_sram_type = DRV_FTM_TBL_IPFIX_HASH_KEY;
            break;

        case DRV_FTM_SRAM_TBL_USERID_HASH_KEY:
            *p_sram_type = DRV_FTM_TBL_TYPE_SCL_HASH_KEY;
            break;

        case DRV_FTM_SRAM_TBL_XCOAM_HASH_KEY:
            *p_sram_type = DRV_FTM_TBL_XCOAM_HASH_KEY;
            break;

        default:
            *p_sram_type = DRV_FTM_TBL_TYPE_MAX;
            break;
    }

    return DRV_E_NONE;
}


int32
drv_ftm_get_hash_poly(uint8 lchip, uint32 mem_id, uint8 sram_type, uint32* drv_poly)
{
    uint32 cmd = 0;
    uint32 tbl_id = 0;
    uint32 fld_id = 0;

    switch (sram_type)
    {
        case DRV_FTM_TBL_FLOW_HASH_KEY:
            tbl_id = FlowHashLookupCtl_t;
            if (DRV_FTM_SRAM0 == mem_id)
            {
                fld_id = FlowHashLookupCtl_flowLevel0HashType_f;
            }
            else if (DRV_FTM_SRAM1 == mem_id)
            {
                fld_id = FlowHashLookupCtl_flowLevel1HashType_f;
            }
            else if (DRV_FTM_SRAM2 == mem_id)
            {
                fld_id = FlowHashLookupCtl_flowLevel2HashType_f;
            }
            else if (DRV_FTM_SRAM3 == mem_id)
            {
                fld_id = FlowHashLookupCtl_flowLevel3HashType_f;
            }
            else if (DRV_FTM_SRAM4 == mem_id)
            {
                fld_id = FlowHashLookupCtl_flowLevel4HashType_f;
            }
            cmd = DRV_IOR(tbl_id, fld_id);
            DRV_IOCTL(lchip, 0, cmd, drv_poly);
            break;

        case DRV_FTM_TBL_TYPE_SCL_HASH_KEY:
            tbl_id = UserIdHashLookupCtl_t;
            fld_id = ((DRV_FTM_SRAM2 == mem_id) || (DRV_FTM_SRAM11 == mem_id))?
            UserIdHashLookupCtl_userIdLevel0HashType_f : UserIdHashLookupCtl_userIdLevel1HashType_f;
            cmd = DRV_IOR(tbl_id, fld_id);
            DRV_IOCTL(lchip, 0, cmd, drv_poly);
            break;

        case DRV_FTM_TBL_XCOAM_HASH_KEY:
            tbl_id = EgressXcOamHashLookupCtl_t;
            fld_id = (DRV_FTM_SRAM17 == mem_id)? EgressXcOamHashLookupCtl_egressXcOamLevel0HashType_f : EgressXcOamHashLookupCtl_egressXcOamLevel1HashType_f;
            cmd = DRV_IOR(tbl_id, fld_id);
            DRV_IOCTL(lchip, 0, cmd, drv_poly);
            break;

        case DRV_FTM_TBL_FIB0_HASH_KEY:
            tbl_id = FibHost0HashLookupCtl_t;
            if (DRV_FTM_SRAM0 == mem_id)
            {
                fld_id = FibHost0HashLookupCtl_fibHost0Level0HashType_f;
            }
            else if (DRV_FTM_SRAM1 == mem_id)
            {
                fld_id = FibHost0HashLookupCtl_fibHost0Level1HashType_f;
            }
            else if (DRV_FTM_SRAM2 == mem_id)
            {
                fld_id = FibHost0HashLookupCtl_fibHost0Level2HashType_f;
            }
            else if (DRV_FTM_SRAM3 == mem_id)
            {
                fld_id = FibHost0HashLookupCtl_fibHost0Level3HashType_f;
            }
            else if (DRV_FTM_SRAM4 == mem_id)
            {
                fld_id = FibHost0HashLookupCtl_fibHost0Level4HashType_f;
            }
            cmd = DRV_IOR(tbl_id, fld_id);
            DRV_IOCTL(lchip, 0, cmd, drv_poly);
            break;

        case DRV_FTM_TBL_FIB1_HASH_KEY:
            tbl_id = FibHost1HashLookupCtl_t;
            if (DRV_FTM_SRAM5 == mem_id)
            {
                fld_id = FibHost1HashLookupCtl_fibHost1Level0HashType_f;
            }
            else if (DRV_FTM_SRAM6 == mem_id)
            {
                fld_id = FibHost1HashLookupCtl_fibHost1Level1HashType_f;
            }
            else if (DRV_FTM_SRAM0 == mem_id)
            {
                fld_id = FibHost1HashLookupCtl_fibHost1Level2HashType_f;
            }
            cmd = DRV_IOR(tbl_id, fld_id);
            DRV_IOCTL(lchip, 0, cmd, drv_poly);
            break;

        default :
            break;

    }
    return DRV_E_NONE;
}


int32
drv_ftm_set_hash_poly(uint8 lchip, uint32 mem_id, uint8 sram_type, uint32 drv_poly)
{
    uint32 cmd = 0;
    uint32 tbl_id = 0;
    uint32 fld_id = 0;

    switch (sram_type)
    {
        case DRV_FTM_TBL_FLOW_HASH_KEY:
            tbl_id = FlowHashLookupCtl_t;
            if (DRV_FTM_SRAM0 == mem_id)
            {
                fld_id = FlowHashLookupCtl_flowLevel0HashType_f;
            }
            else if (DRV_FTM_SRAM1 == mem_id)
            {
                fld_id = FlowHashLookupCtl_flowLevel1HashType_f;
            }
            else if (DRV_FTM_SRAM2 == mem_id)
            {
                fld_id = FlowHashLookupCtl_flowLevel2HashType_f;
            }
            else if (DRV_FTM_SRAM3 == mem_id)
            {
                fld_id = FlowHashLookupCtl_flowLevel3HashType_f;
            }
            else if (DRV_FTM_SRAM4 == mem_id)
            {
                fld_id = FlowHashLookupCtl_flowLevel4HashType_f;
            }
            cmd = DRV_IOW(tbl_id, fld_id);
            DRV_IOCTL(lchip, 0, cmd, &drv_poly);
            break;

        case DRV_FTM_TBL_TYPE_SCL_HASH_KEY:
            tbl_id = UserIdHashLookupCtl_t;
            fld_id = ((DRV_FTM_SRAM2 == mem_id) || (DRV_FTM_SRAM11 == mem_id))?
            UserIdHashLookupCtl_userIdLevel0HashType_f : UserIdHashLookupCtl_userIdLevel1HashType_f;
            cmd = DRV_IOW(tbl_id, fld_id);
            DRV_IOCTL(lchip, 0, cmd, &drv_poly);
            break;

        case DRV_FTM_TBL_XCOAM_HASH_KEY:
            tbl_id = EgressXcOamHashLookupCtl_t;
            fld_id = (DRV_FTM_SRAM17 == mem_id)? EgressXcOamHashLookupCtl_egressXcOamLevel0HashType_f : EgressXcOamHashLookupCtl_egressXcOamLevel1HashType_f;
            cmd = DRV_IOW(tbl_id, fld_id);
            DRV_IOCTL(lchip, 0, cmd, &drv_poly);
            break;

        case DRV_FTM_TBL_FIB0_HASH_KEY:
            tbl_id = FibHost0HashLookupCtl_t;
            if (DRV_FTM_SRAM0 == mem_id)
            {
                fld_id = FibHost0HashLookupCtl_fibHost0Level0HashType_f;
            }
            else if (DRV_FTM_SRAM1 == mem_id)
            {
                fld_id = FibHost0HashLookupCtl_fibHost0Level1HashType_f;
            }
            else if (DRV_FTM_SRAM2 == mem_id)
            {
                fld_id = FibHost0HashLookupCtl_fibHost0Level2HashType_f;
            }
            else if (DRV_FTM_SRAM3 == mem_id)
            {
                fld_id = FibHost0HashLookupCtl_fibHost0Level3HashType_f;
            }
            else if (DRV_FTM_SRAM4 == mem_id)
            {
                fld_id = FibHost0HashLookupCtl_fibHost0Level4HashType_f;
            }
            cmd = DRV_IOW(tbl_id, fld_id);
            DRV_IOCTL(lchip, 0, cmd, &drv_poly);
            break;

        case DRV_FTM_TBL_FIB1_HASH_KEY:
            tbl_id = FibHost1HashLookupCtl_t;
            if (DRV_FTM_SRAM5 == mem_id)
            {
                cmd = DRV_IOW(tbl_id, FibHost1HashLookupCtl_fibHost1Level0HashType_f);
                DRV_IOCTL(lchip, 0, cmd, &drv_poly);
            }
            else if (DRV_FTM_SRAM6 == mem_id)
            {
                cmd = DRV_IOW(tbl_id, FibHost1HashLookupCtl_fibHost1Level1HashType_f);
                DRV_IOCTL(lchip, 0, cmd, &drv_poly);
            }
            else if (DRV_FTM_SRAM0 == mem_id)
            {
                cmd = DRV_IOW(tbl_id, FibHost1HashLookupCtl_fibHost1Level2HashType_f);
                DRV_IOCTL(lchip, 0, cmd, &drv_poly);
            }
            g_ftm_master->host1_poly_type = drv_poly;
            break;

        default :
            break;

    }
    return DRV_E_NONE;
}

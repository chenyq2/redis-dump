/*
 @file drv_ftm.c

 @date 2011-11-16

 @version v2.0

 This file provides all sys alloc function
*/

#include "sal.h"
#include "drv_enum.h"
#include "drv_ftm.h"
#include "drv_common.h"
#include "drv_io.h"

int32
drv_ftm_mem_alloc(void* p_profile_info)
{

    return DRV_E_NONE;

}

int32
drv_ftm_init(void* p_profile_info)
{

    return DRV_E_NONE;


}

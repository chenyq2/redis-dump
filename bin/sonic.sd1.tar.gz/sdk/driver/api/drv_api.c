/**
 @file drv_api.c

 @author  Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2015-10-09

 @version v1.0

 The file contains all chip APIs of Driver layer
*/
#include "sal.h"
#include "drv_api.h"
#include "drv_common.h"
#include "drv_error.h"

extern int32 drv_chip_common_init(uint8 lchip);
extern int32 drv_model_common_init(uint8 lchip);
extern int32 dal_get_chip_number(uint8* p_num);

/* use for testing cpu endian */
struct endian_test_e
{
    uint32 test1    : 1;
    uint32 test2    : 31;
};
typedef struct endian_test_e endian_test_t;

drv_master_t** p_drv_master = NULL;


#define __DRV_INTERNAL_FUNCTION_

/**
 @brief get host type automatically. Little-Endian or Big-Endian.
*/
static void
_drv_get_host_type(uint8 lchip)
{
    endian_test_t test;
    uint32* p_test = NULL;

    if (!p_drv_master || !p_drv_master[lchip])
    {
        return;
    }

    p_test = (uint32 *)&test;
    *p_test = 0;
    test.test1 = 1;

    if (*p_test == 0x01)
    {
        p_drv_master[lchip]->host_type = HOST_LE;
    }
    else
    {
        p_drv_master[lchip]->host_type = HOST_BE;
    }


    return;
}


/**
 @brief register a Memory field to the register field directory
*/
fields_t *
_drv_find_field(tbls_id_t tbl_id, fld_id_t field_id)
{
    if (!(CHK_TABLE_ID_VALID(tbl_id) | CHK_FIELD_ID_VALID(tbl_id, field_id)))
    {
        DRV_DBG_INFO("ERROR! INVALID TblID or fieldID! TblID: %d, fieldID: %d\n", tbl_id, field_id);
        if (TABLE_NAME(tbl_id))
        {
            DRV_DBG_INFO("ERROR! INVALID TblName:%s\n", TABLE_NAME(tbl_id));
        }
        return NULL;
    }

    return (TABLE_FIELD_INFO_PTR(tbl_id) + field_id);
}

/*mep table need mask cfg, TBD*/
static int32
_drv_ioctl(uint8 chip_id, int32 index, uint32 cmd, void* val)
{
    int32 action;
    tbls_id_t tbl_id;
    uint16 field_id;
    uint32 data_entry[MAX_ENTRY_WORD] = {0};
    uint32 mask_entry[MAX_ENTRY_WORD] = {0};
    tbl_entry_t entry;
    drv_io_callback_fun_t* drv_io_api;

    #if (SDK_WORK_PLATFORM == 0)
    uint32 value0 = 0;
    #endif

    DRV_PTR_VALID_CHECK(val);

    if (!p_drv_master || !p_drv_master[chip_id])
    {
        return DRV_E_NOT_INIT;
    }

    action = DRV_IOC_OP(cmd);
    tbl_id = DRV_IOC_MEMID(cmd);
    field_id = DRV_IOC_FIELDID(cmd);

    DRV_TBL_ID_VALID_CHECK(tbl_id);

    sal_memset(&entry, 0, sizeof(entry));
    entry.data_entry = data_entry;
    entry.mask_entry = mask_entry;

    drv_io_api= &(p_drv_master[chip_id]->drv_io_api);

    switch (action)
    {
    case DRV_IOC_WRITE:
        if ((drv_get_table_type(tbl_id) != DRV_TABLE_TYPE_TCAM)
            && (drv_get_table_type(tbl_id) != DRV_TABLE_TYPE_LPM_TCAM_IP)
            && (drv_get_table_type(tbl_id) != DRV_TABLE_TYPE_LPM_TCAM_NAT)
            && (drv_get_table_type(tbl_id) != DRV_TABLE_TYPE_STATIC_TCAM_KEY))
        {
            /* Write Sram one field of the entry */
            if ((drv_io_api->drv_sram_tbl_read) && (DRV_ENTRY_FLAG != field_id))
            {
                DRV_IF_ERROR_RETURN(drv_io_api->drv_sram_tbl_read(chip_id, tbl_id, index, data_entry));
                DRV_IF_ERROR_RETURN(drv_set_field(tbl_id, field_id, data_entry, (uint32*)val));
            }
            else
            {
                sal_memcpy(data_entry, (uint32*)val, TABLE_ENTRY_SIZE(tbl_id));
            }

            if (drv_io_api->drv_sram_tbl_write)
            {
                DRV_IF_ERROR_RETURN(drv_io_api->drv_sram_tbl_write(chip_id, tbl_id, index, data_entry));
            }
        }
        else
        {
            if ((drv_io_api->drv_tcam_tbl_read) && (DRV_ENTRY_FLAG != field_id))
            {
                DRV_IF_ERROR_RETURN(drv_io_api->drv_tcam_tbl_read(chip_id, tbl_id, index, &entry));
                DRV_IF_ERROR_RETURN(drv_set_field(tbl_id, field_id, entry.data_entry, (uint32 *)((tbl_entry_t*)val)->data_entry));
                DRV_IF_ERROR_RETURN(drv_set_field(tbl_id, field_id, entry.mask_entry, (uint32 *)((tbl_entry_t*)val)->mask_entry));
            }
            else
            {
                sal_memcpy(entry.data_entry, (uint32 *)((tbl_entry_t*)val)->data_entry, TABLE_ENTRY_SIZE(tbl_id));
                sal_memcpy(entry.mask_entry, (uint32 *)((tbl_entry_t*)val)->mask_entry, TABLE_ENTRY_SIZE(tbl_id));
            }

            if (drv_io_api->drv_tcam_tbl_write)
            {
                DRV_IF_ERROR_RETURN(drv_io_api->drv_tcam_tbl_write(chip_id, tbl_id, index, &entry));
            }
        }
        break;
    case DRV_IOC_READ:
        if ((drv_get_table_type(tbl_id) != DRV_TABLE_TYPE_TCAM)
            && (drv_get_table_type(tbl_id) != DRV_TABLE_TYPE_LPM_TCAM_IP)
            && (drv_get_table_type(tbl_id) != DRV_TABLE_TYPE_LPM_TCAM_NAT)
            && (drv_get_table_type(tbl_id) != DRV_TABLE_TYPE_STATIC_TCAM_KEY))
        {
            /* Read Sram one field of the entry */
            if (drv_io_api->drv_sram_tbl_read)
            {
                DRV_IF_ERROR_RETURN(drv_io_api->drv_sram_tbl_read(chip_id, tbl_id, index, data_entry));
            }

            if (DRV_ENTRY_FLAG != field_id)
            {
                DRV_IF_ERROR_RETURN(drv_get_field(tbl_id, field_id, data_entry, (uint32*)val));
            }
            else
            {
                sal_memcpy((uint32*)val, data_entry, TABLE_ENTRY_SIZE(tbl_id));
            }
        }
        else
        {
            /* Read Tcam one field of the entry */
            /* For Tcam entry, we could only operate its data's filed, app should not opreate tcam field */
            if (drv_io_api->drv_tcam_tbl_read)
            {
                DRV_IF_ERROR_RETURN(drv_io_api->drv_tcam_tbl_read(chip_id, tbl_id, index, &entry));
            }

            if (DRV_ENTRY_FLAG != field_id)
            {
                DRV_IF_ERROR_RETURN(drv_get_field(tbl_id, field_id, (entry.data_entry), (uint32 *)((tbl_entry_t*)val)->data_entry));
                DRV_IF_ERROR_RETURN(drv_get_field(tbl_id, field_id, (entry.mask_entry), (uint32 *)((tbl_entry_t*)val)->mask_entry));
            }
            else
            {
                sal_memcpy((uint32 *)((tbl_entry_t*)val)->data_entry, entry.data_entry, TABLE_ENTRY_SIZE(tbl_id));
                sal_memcpy((uint32 *)((tbl_entry_t*)val)->mask_entry, entry.mask_entry, TABLE_ENTRY_SIZE(tbl_id));
            }
        }
        break;
    case DRV_IOC_REMOVE:
    /*just for tcam remove*/
        if ((drv_get_table_type(tbl_id) != DRV_TABLE_TYPE_TCAM)
            && (drv_get_table_type(tbl_id) != DRV_TABLE_TYPE_LPM_TCAM_IP)
            && (drv_get_table_type(tbl_id) != DRV_TABLE_TYPE_LPM_TCAM_NAT)
            && (drv_get_table_type(tbl_id) != DRV_TABLE_TYPE_STATIC_TCAM_KEY))
        {
            return DRV_E_INVALID_TCAM_INDEX;
        }

        if (drv_io_api->drv_tcam_tbl_remove)
        {
            DRV_IF_ERROR_RETURN(drv_io_api->drv_tcam_tbl_remove(chip_id, tbl_id, index));
        }

    default:
        break;
    }

    return DRV_E_NONE;
}


static int32
_drv_oam_mask_ioctl(uint8 chip_id, int32 index, uint32 cmd, void* val)
{
    uint32 cmd_oam = 0;
    uint32* value = NULL;

#if(SDK_WORK_PLATFORM == 0)
    /*write mask*/
    value = (uint32 *)(((tbl_entry_t*)val)->mask_entry);
    cmd_oam = DRV_IOW(OamDsMpDataMask_t, DRV_ENTRY_FLAG);
    DRV_IF_ERROR_RETURN(_drv_ioctl(chip_id, 0, cmd_oam, value));
#endif

    /*write data*/
    value = (uint32 *)(((tbl_entry_t*)val)->data_entry);
    DRV_IF_ERROR_RETURN(_drv_ioctl(chip_id, index, cmd, value));

    return DRV_E_NONE;
}

#define __DRV_API__

/**
  @driver get environmnet type interface
*/
int32
drv_get_platform_type(drv_work_platform_type_t *plaform_type)
{
    if (!p_drv_master || !p_drv_master[0])
    {
        return DRV_E_NOT_INIT;
    }

    if (p_drv_master[0])
    {
       *plaform_type = p_drv_master[0]->plaform_type;
        return DRV_E_NONE;
    }
    else
    {
        DRV_DBG_INFO("@@@ERROR, Driver is not initialized!\n");
        return  DRV_E_NOT_INIT;
    }
}

/**
  @driver get host type interface
*/
host_type_t
drv_get_host_type (void)
{
    if (!p_drv_master || !p_drv_master[0])
    {
        return DRV_E_NOT_INIT;
    }

    return p_drv_master[0]->host_type;
}

/**
  @driver get table property
*/
int32
drv_get_table_property(uint8 type, tbls_id_t tbl_id, uint32 index, void* value)
{
    int32 ret = 0;

    if (!value)
    {
        return DRV_E_INVALID_ADDR;
    }

    DRV_TBL_ID_VALID_CHECK(tbl_id);

    switch(type)
    {
        case DRV_TABLE_PROP_TYPE:
            *((uint32*)value) = drv_get_table_type(tbl_id);

            break;
        case DRV_TABLE_PROP_HW_ADDR:
            ret = drv_table_get_hw_addr(tbl_id, index, (uint32*)value, 0);
            break;

        case DRV_TABLE_PROP_GET_NAME:
            ret = drv_get_tbl_string_by_id(tbl_id, (char*)value);
            break;

        case DRV_TABLE_PROP_BITMAP:
            *((uint32*)value) = DYNAMIC_BITMAP(tbl_id);
            break;

        default:
            ret = DRV_E_INVALID_TBL;
            break;
    }

    return ret;
}

/**
  @driver set chip access type
*/
int32
drv_set_access_type(drv_access_type_t access_type)
{
    if (!p_drv_master || !p_drv_master[0])
    {
        return DRV_E_NOT_INIT;
    }

    p_drv_master[0]->access_type = access_type;

    return DRV_E_NONE;
}

/**
  @driver get chip access type
*/
int32
drv_get_access_type(drv_access_type_t* p_access_type)
{
    if (!p_drv_master || !p_drv_master[0])
    {
        return DRV_E_NOT_INIT;
    }

    *p_access_type = p_drv_master[0]->access_type;

    return DRV_E_NONE;
}
/**
  @driver install drv io/app interface
*/
int32
drv_install_api(uint8 lchip, drv_io_callback_fun_t* cb)
{

    uint8 chip_num = 0;

    dal_get_chip_number(&chip_num);

    if (lchip >= chip_num)
    {
        return DRV_E_NOT_INIT;
    }

    if (!p_drv_master || !p_drv_master[lchip])
    {
        return DRV_E_NOT_INIT;
    }

    if (NULL == cb)
    {
        return DRV_E_NOT_INIT;
    }

    p_drv_master[lchip]->drv_io_api.drv_sram_tbl_read = cb->drv_sram_tbl_read;
    p_drv_master[lchip]->drv_io_api.drv_sram_tbl_write = cb->drv_sram_tbl_write;
    p_drv_master[lchip]->drv_io_api.drv_tcam_tbl_read = cb->drv_tcam_tbl_read;
    p_drv_master[lchip]->drv_io_api.drv_tcam_tbl_write = cb->drv_tcam_tbl_write;
    p_drv_master[lchip]->drv_io_api.drv_tcam_tbl_remove = cb->drv_tcam_tbl_remove;

    return DRV_E_NONE;
}


/**
 @brief Get a field of a memory data entry
*/
int32
drv_get_field(tbls_id_t tbl_id, fld_id_t field_id,
                void* ds, uint32* value)
{
    fields_t* field = NULL;
    int32 seg_id;
    segs_t* seg = NULL;
    uint8 uint32_num  = 0;
    uint8 uint32_idx  = 0;
    uint16 remain_len  = 0;
    uint16 cross_word  = 0;
    uint32 remain_value = 0;
    uint32 seg_value = 0;
    uint32* entry  = NULL;

    DRV_PTR_VALID_CHECK(ds)
    DRV_PTR_VALID_CHECK(value)
    DRV_TBL_ID_VALID_CHECK(tbl_id);

    entry = ds;
    field = _drv_find_field(tbl_id, field_id);
    if (field == NULL)
    {
        DRV_DBG_INFO("ERROR! (drv_mem_get_field): memID-%d, field-%d is not supported\n", tbl_id, field_id);
        return DRV_E_INVALID_FLD;
    }

    seg_id = (field->seg_num-1);
    while( seg_id >= 0)
    {
        seg = &(field->ptr_seg[seg_id]);
        seg_value = (entry[seg->word_offset] >> seg->start) & SHIFT_LEFT_MINUS_ONE(seg->bits);

        value[uint32_idx] = (seg_value << remain_len) | remain_value;
        if ((seg->bits + remain_len) == 32)
        {
            remain_value = 0;
            cross_word = 0;
            uint32_idx ++;
        }
        else if ((seg->bits + remain_len) > 32)
        {
            /*create new remain_value */
            remain_value = seg_value >> (32 - remain_len);
            cross_word = 1;
            uint32_idx ++;
        }
        else
        {
            /*create new remain_value */
            remain_value = (seg_value << remain_len) | remain_value;
            cross_word = 0;
        }
        /*create new remain_len */
        remain_len   = (seg->bits + remain_len) & 0x1F; /*rule out bits that exceeds 32*/
        seg_id --;
    }

    if(cross_word) /* last seg cross word */
    {
        value[uint32_idx] = remain_value;
    }

    return DRV_E_NONE;
}

/**
 @brief Set a field of a memory data entry
*/
int32
drv_set_field(tbls_id_t tbl_id, fld_id_t field_id,
                        void* ds, uint32 *value)
{
    fields_t* field = NULL;
    segs_t* seg = NULL;
    int32 seg_id = 0;
    uint8 cut_len =  0;
    uint8 array_idx = 0;
    uint32 seg_value = 0;
    uint32 value_a = 0;
    uint32 value_b = 0;
    uint32* entry  = NULL;


    DRV_PTR_VALID_CHECK(ds)
    DRV_TBL_ID_VALID_CHECK(tbl_id);

    entry = ds;
    /* register field support check */
    field = _drv_find_field(tbl_id, field_id);

    if (field == NULL)
    {
        DRV_DBG_INFO("ERROR! (drv_mem_set_field): memID-%d, field-%d is not supported\n", tbl_id, field_id);
        return DRV_E_INVALID_FLD;
    }


    seg_id = (field->seg_num-1);
    cut_len = 0;

    array_idx = 0;
    while( seg_id >= 0)
    {
        seg = &(field->ptr_seg[seg_id]);

        if ((cut_len + seg->bits) >= 32)
        {
            value_b = (value[array_idx + 1 ] & SHIFT_LEFT_MINUS_ONE((cut_len + seg->bits - 32)));
            value_a = (value[array_idx] >> cut_len) & SHIFT_LEFT_MINUS_ONE((32- cut_len));
            seg_value = (value_b << (32 - cut_len)) | value_a;

            array_idx++;
        }
        else
        {
            value_a = (value[array_idx] >> cut_len) & SHIFT_LEFT_MINUS_ONE(seg->bits);
            seg_value =  value_a;
        }

        entry[seg->word_offset] &= ~ (SHIFT_LEFT_MINUS_ONE(seg->bits)  << seg->start);
        entry[seg->word_offset] |= (seg_value << seg->start);

        cut_len = (cut_len + seg->bits) & 0x1F; /*rule out bits that exceeds 32*/

        seg_id--;
    }

    return DRV_E_NONE;
}

/**
@brief Get a field  valued of a memory data entry
*/
uint32
drv_get_field_value(tbls_id_t tbl_id, fld_id_t field_id,  void* ds)
{
    uint32 value = 0;
    drv_get_field(tbl_id, field_id,                  ds, &value);
    return value;
}

/**
  @driver Driver IO Api
*/
int32
drv_ioctl_api(uint8 chip_id, int32 index, uint32 cmd, void* val)
{
    tbls_id_t tbl_id;
    uint32 action;
    action = DRV_IOC_OP(cmd);
    tbl_id = DRV_IOC_MEMID(cmd);

    if(((tbl_id == DsEthMep_t) || (tbl_id == DsEthRmep_t) || (tbl_id == DsBfdMep_t) || (tbl_id == DsBfdRmep_t)) &&
        (DRV_IOC_WRITE == action))
    {
        DRV_IF_ERROR_RETURN(_drv_oam_mask_ioctl(chip_id, index, cmd, val));
    }
    else
    {
        DRV_IF_ERROR_RETURN(_drv_ioctl(chip_id, index, cmd, val));
    }

    return DRV_E_NONE;
}

/**
  @driver Driver Acc Api
*/
int32
drv_acc_api(uint8 chip_id, void* in, void* out)
{
    DRV_IF_ERROR_RETURN(drv_acc(chip_id, in, out));

    return DRV_E_NONE;
}

/**
  @driver Driver Init Api,per chip init TBD
*/
int32
drv_init(uint8 lchip, uint8 base)
{
    uint8 chip_num = 0;

    dal_get_chip_number(&chip_num);
    if (!p_drv_master)
    {
        p_drv_master = (drv_master_t**)mem_malloc(MEM_SYSTEM_MODULE, sizeof(void*)*chip_num);
        if (p_drv_master == NULL)
        {
            return DRV_E_NO_MEMORY;
        }
        sal_memset(p_drv_master, 0, sizeof(sizeof(void*)*chip_num));
    }

    p_drv_master[lchip] = (drv_master_t*)mem_malloc(MEM_SYSTEM_MODULE, sizeof(drv_master_t));
    if (NULL == p_drv_master[lchip])
    {
        return DRV_E_NO_MEMORY;
    }

    sal_memset(p_drv_master[lchip], 0, sizeof(drv_master_t));

    p_drv_master[lchip]->plaform_type = SDK_WORK_PLATFORM;
    p_drv_master[lchip]->workenv_type = SDK_WORK_ENV;
    p_drv_master[lchip]->access_type = DRV_PCI_ACCESS;

    _drv_get_host_type(lchip);

    if (0 == SDK_WORK_PLATFORM)
    {
        drv_chip_common_init(lchip);
    }
    else
    {
        drv_model_common_init(lchip);
    }

    return DRV_E_NONE;
}


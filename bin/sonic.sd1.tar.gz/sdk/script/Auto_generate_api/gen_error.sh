echo "************************************************"
echo "auto generate error code "
echo "************************************************"
destfile="../../core/common/src/ctc_error.c"
srcfile="../../core/common/include/ctc_error.h"
echo  '/**'                                                                                                        >$destfile
echo  ' @file ctc_error.c'                                                                                    >>$destfile
echo  ''                                                                                                           >>$destfile
echo  ' @date 2012-08-15'                                                                                          >>$destfile
echo  ''                                                                                                           >>$destfile
echo  ' @version v2.0'                                                                                             >>$destfile
echo  ''                                                                                                           >>$destfile
echo  ' return sdk error description'                                                                              >>$destfile
echo  ' auto generated based on head file'                                                                         >>$destfile
echo  '*/'                                                                                                         >>$destfile
echo  '#include "sal.h"'                                                                                     >>$destfile
echo  '#include "ctc_error.h"'                                                                                     >>$destfile
echo  ''                                                                                                           >>$destfile
echo  'uint32 g_mapping_disable = 0;'                                                                              >>$destfile
echo  'const char *ctc_get_error_desc(enum ctc_err_e error_code)'                                                    >>$destfile
echo  '{'                                                                                                          >>$destfile
echo  '    static char  error_desc[256+1] = {0};'                                                                     >>$destfile
echo  '    error_code = ctc_error_code_mapping(error_code);'                                                       >>$destfile
echo  '    if (error_code == CTC_E_NONE)'                                                                          >>$destfile
echo  '    {'                                                                                                      >>$destfile
echo  '        return " ";'                                                                                        >>$destfile
echo  '    }'                                                                                                      >>$destfile
echo  ''                                                                                                           >>$destfile
echo  '    switch(error_code)'                                                                                     >>$destfile
echo  '    {'                                                                                                      >>$destfile
sed "/^\s*CTC_E/! d;s/^\s*\(CTC_E_\w*\).*<\s*\(.*\)\s*\*.*$/        case \1:  \n          return \"\2\";   /" $srcfile          >>$destfile
echo  '    default:'                                                                                             >>$destfile
echo  '      sal_sprintf(error_desc,"Error code:%d",error_code);'                                                  >>$destfile
echo  '      return error_desc;'                                                                                   >>$destfile
echo  '    }'                                                                                                      >>$destfile
echo  ''                                                                                                           >>$destfile
echo  '}'                                                                                                          >>$destfile
echo '' >>$destfile
echo 'int32' >>$destfile
echo 'ctc_error_code_mapping(int32 error_code)' >>$destfile
echo '{' >>$destfile
echo '    if (g_mapping_disable)' >>$destfile
echo '    {' >>$destfile
echo '        return error_code;' >>$destfile
echo '    }' >>$destfile
echo '' >>$destfile
echo '    if (error_code >= -10000)' >>$destfile
echo '    {' >>$destfile
echo '        switch (error_code)' >>$destfile
echo '        {' >>$destfile
echo '            case -10000:' >>$destfile
echo '                return CTC_E_NO_MEMORY;' >>$destfile
echo '            case -9999:' >>$destfile
echo '                return CTC_E_HW_BUSY;' >>$destfile
echo '            case -9998:' >>$destfile
echo '                return CTC_E_HW_TIME_OUT;' >>$destfile
echo '            case -9997:' >>$destfile
echo '                return CTC_E_HW_INVALID_INDEX;' >>$destfile
echo '            default:' >>$destfile
echo '                return CTC_E_HW_FAIL;' >>$destfile
echo '        }' >>$destfile
echo '    }' >>$destfile
echo '' >>$destfile
echo '    switch (error_code)' >>$destfile
echo '    {' >>$destfile
echo '        case CTC_E_HW_BUSY:' >>$destfile
echo '            return CTC_E_HW_BUSY;' >>$destfile
echo '        case CTC_E_HW_INVALID_INDEX:' >>$destfile
echo '            return CTC_E_HW_INVALID_INDEX;' >>$destfile
echo '        case CTC_E_INVALID_PTR:' >>$destfile
echo '        case CTC_E_VLAN_INVALID_VLAN_PTR:' >>$destfile
echo '            return CTC_E_INVALID_PTR;' >>$destfile
echo '        case CTC_E_INVALID_PORT:' >>$destfile
echo '        case CTC_E_INVALID_GLOBAL_PORT:' >>$destfile
echo '        case CTC_E_INVALID_LOGIC_PORT:' >>$destfile
echo '        case CTC_E_INVALID_LOCAL_PORT:' >>$destfile
echo '        case CTC_E_VPLS_INVALID_VPLSPORT_ID:' >>$destfile
echo '        case CTC_E_STK_TRUNK_MEMBER_PORT_INVALID:' >>$destfile
echo '        case CTC_E_VLAN_EXCEED_MAX_PHY_PORT:' >>$destfile
echo '        case CTC_E_FDB_NOT_LOCAL_MEMBER:' >>$destfile
echo '        case CTC_E_SCL_INVALID_DEFAULT_PORT:' >>$destfile
echo '            return CTC_E_INVALID_PORT;' >>$destfile
echo '        case CTC_E_INVALID_CHIP_ID:' >>$destfile
echo '        case CTC_E_INVALID_GLOBAL_CHIPID:' >>$destfile
echo '        case CTC_E_INVALID_LOCAL_CHIPID:' >>$destfile
echo '        case CTC_E_CHIP_IS_LOCAL:' >>$destfile
echo '        case CTC_E_CHIP_IS_REMOTE:' >>$destfile
echo '        case CTC_E_IPMC_EXCEED_GLOBAL_CHIP:' >>$destfile
echo '            return CTC_E_INVALID_CHIP_ID;' >>$destfile
echo '        case CTC_E_HW_TIME_OUT:' >>$destfile
echo '        case CTC_E_HASH_MEM_INIT_TIMEOUT:' >>$destfile
echo '        case CTC_E_CHIP_TIME_OUT:' >>$destfile
echo '            return CTC_E_HW_TIME_OUT;' >>$destfile
echo '        case CTC_E_HW_NOT_LOCK:' >>$destfile
echo '        case CTC_E_DATAPATH_PLL_NOT_LOCK:' >>$destfile
echo '            return CTC_E_HW_NOT_LOCK;' >>$destfile
echo '        case CTC_E_DMA:' >>$destfile
echo '        case CTC_E_DMA_TX_FAILED:' >>$destfile
echo '        case CTC_E_DMA_TABLE_WRITE_FAILED:' >>$destfile
echo '        case CTC_E_DMA_TABLE_READ_FAILED:' >>$destfile
echo '        case CTC_E_DMA_EXCEED_MAX_DESC_NUM:' >>$destfile
echo '        case CTC_E_DMA_DESC_NOT_DONE:' >>$destfile
echo '            return CTC_E_DMA;' >>$destfile
echo '        case CTC_E_HW_FAIL:' >>$destfile
echo '        case CTC_E_OAM_DRIVER_FAIL:' >>$destfile
echo '        case CTC_E_DATAPATH_HSS_NOT_READY:' >>$destfile
echo '        case CTC_E_SERDES_STATUS_NOT_READY:' >>$destfile
echo '        case CTC_E_SERDES_EYE_TEST_NOT_DONE:' >>$destfile
echo '        case CTC_E_CHIP_SCAN_PHY_REG_FULL:' >>$destfile
echo '        case CTC_E_CHIP_SWITCH_FAILED:' >>$destfile
echo '        case CTC_E_PORT_MAC_PCS_ERR:' >>$destfile
echo '        case CTC_E_DATAPATH_SWITCH_FAIL:' >>$destfile
echo '        case CTC_E_FDB_FIB_DUMP_FAIL:' >>$destfile
echo '        case CTC_E_HW_OP_FAIL:' >>$destfile
echo '        case CTC_E_CHECK_HSS_READY_FAIL:' >>$destfile
echo '        case CTC_E_PTP_TS_NOT_READY:' >>$destfile
echo '        case CTC_E_PTP_TX_TS_ROLL_OVER_FAILURE:' >>$destfile
echo '        case CTC_E_PTP_RX_TS_INFORMATION_NOT_READY:' >>$destfile
echo '        case CTC_E_TRAININT_FAIL:' >>$destfile
echo '            return CTC_E_HW_FAIL;' >>$destfile
echo '        case CTC_E_BADID:' >>$destfile
echo '        case CTC_E_STP_INVALID_STP_ID:' >>$destfile
echo '        case CTC_E_APS_INVALID_GROUP_ID:' >>$destfile
echo '        case CTC_E_OVERLAY_TUNNEL_INVALID_VN_ID:' >>$destfile
echo '        case CTC_E_OVERLAY_TUNNEL_INVALID_FID:' >>$destfile
echo '        case CTC_E_INVALID_DEVICE_ID:' >>$destfile
echo '        case CTC_E_VLAN_INVALID_VLAN_ID:' >>$destfile
echo '        case CTC_E_VLAN_INVALID_FID_ID:' >>$destfile
echo '        case CTC_E_VLAN_INVALID_VRFID:' >>$destfile
echo '        case CTC_E_VLAN_MAPPING_INVALID_SERVICE_ID:' >>$destfile
echo '        case CTC_E_FDB_INVALID_FID:' >>$destfile
echo '        case CTC_E_MIRROR_INVALID_MIRROR_LOG_ID:' >>$destfile
echo '        case CTC_E_L3IF_INVALID_IF_ID:' >>$destfile
echo '        case CTC_E_IPUC_INVALID_VRF:' >>$destfile
echo '        case CTC_E_IPUC_INVALID_L3IF:' >>$destfile
echo '        case CTC_E_IPMC_INVALID_VRF:' >>$destfile
echo '        case CTC_E_INVALID_TID:' >>$destfile
echo '        case CTC_E_SCL_GROUP_ID:' >>$destfile
echo '        case CTC_E_SCL_GROUP_ID_RSVED:' >>$destfile
echo '        case CTC_E_SCL_SERVICE_ID:' >>$destfile
echo '        case CTC_E_ACL_GROUP_ID:' >>$destfile
echo '        case CTC_E_ACL_GROUP_ID_RSVED:' >>$destfile
echo '        case CTC_E_ACL_SERVICE_ID:' >>$destfile
echo '           return CTC_E_BADID;' >>$destfile
echo '        case CTC_E_IN_USE:' >>$destfile
echo '        case CTC_E_NH_GLB_SRAM_IS_INUSE:' >>$destfile
echo '        case CTC_E_NH_GLB_SRAM_ISNOT_INUSE:' >>$destfile
echo '        case CTC_E_NH_EXIST_VC_LABEL:' >>$destfile
echo '        case CTC_E_NH_ECMP_IN_USE:' >>$destfile
echo '        case CTC_E_NH_HR_NH_IN_USE:' >>$destfile
echo '        case CTC_E_NH_CROSS_CHIP_RSPAN_NH_IN_USE:' >>$destfile
echo '        case CTC_E_NH_MCAST_MIRROR_NH_IN_USE:' >>$destfile
echo '        case CTC_E_QUEUE_SERVICE_REGISTERED:' >>$destfile
echo '        case CTC_E_QUEUE_INTERNAL_PORT_IN_USE:' >>$destfile
echo '        case CTC_E_OAM_MAID_ENTRY_REF_BY_MEP:' >>$destfile
echo '        case CTC_E_OAM_NH_OFFSET_IN_USE:' >>$destfile
echo '        case CTC_E_STATS_STATSID_ALREADY_IN_USE:' >>$destfile
echo '        case CTC_E_SCL_LABEL_IN_USE:' >>$destfile
echo '        case CTC_E_ACLQOS_LABEL_IN_USE:' >>$destfile
echo '        case CTC_E_ACL_LABEL_IN_USE:' >>$destfile
echo '        case CTC_E_QOS_POLICER_IN_USE:' >>$destfile
echo '           return CTC_E_IN_USE;' >>$destfile
echo '        case CTC_E_NOT_SUPPORT:' >>$destfile
echo '        case CTC_E_FEATURE_NOT_SUPPORT:' >>$destfile
echo '        case CTC_E_APS_DONT_SUPPORT_HW_BASED_APS_FOR_LINKAGG:' >>$destfile
echo '        case CTC_E_PORT_PVLAN_TYPE_NOT_SUPPORT:' >>$destfile
echo '        case CTC_E_SERDES_MODE_NOT_SUPPORT:' >>$destfile
echo '        case CTC_E_SERDES_PLL_NOT_SUPPORT:' >>$destfile
echo '        case CTC_E_MPLS_ENTRY_NOT_SUPPORT_STATS:' >>$destfile
echo '        case CTC_E_LINKAGG_DYNAMIC_BALANCE_NOT_SUPPORT:' >>$destfile
echo '        case CTC_E_SCL_UNSUPPORT:' >>$destfile
echo '        case CTC_E_INTR_NOT_SUPPORT:' >>$destfile
echo '        case CTC_E_SCL_STATS_NOT_SUPPORT:' >>$destfile
echo '        case CTC_E_SCL_HASH_ENTRY_UNSUPPORT_COPY:' >>$destfile
echo '        case CTC_E_QOS_THIS_PORT_NOT_SUPPORT_POLICER:' >>$destfile
echo '        case CTC_E_QOS_POLICER_NOT_SUPPORT_STATS:' >>$destfile
echo '        case CTC_E_ACL_STATS_NOT_SUPPORT:' >>$destfile
echo '        case CTC_E_ACL_HASH_ENTRY_UNSUPPORT_COPY:' >>$destfile
echo '           return CTC_E_NOT_SUPPORT;' >>$destfile
echo '        case CTC_E_NO_RESOURCE:' >>$destfile
echo '        case CTC_E_FDB_SECURITY_VIOLATION:' >>$destfile
echo '        case CTC_E_NH_NHOFFSET_EXHAUST:' >>$destfile
echo '        case CTC_E_QUEUE_NOT_ENOUGH:' >>$destfile
echo '        case CTC_E_QUEUE_SERVICE_QUEUE_NO_HASH_ENTRY:' >>$destfile
echo '        case CTC_E_QUEUE_NO_FREE_INTERNAL_PORT:' >>$destfile
echo '        case CTC_E_OVERLAY_TUNNEL_NO_DA_INDEX_RESOURCE:' >>$destfile
echo '        case CTC_E_L3IF_ROUTER_MAC_EXHAUSTED:' >>$destfile
echo '        case CTC_E_IPMC_OFFSET_ALLOC_ERROR:' >>$destfile
echo '        case CTC_E_USRID_NO_KEY:' >>$destfile
echo '        case CTC_E_SCL_NO_KEY:' >>$destfile
echo '        case CTC_E_SCL_BUILD_AD_INDEX_FAILED:' >>$destfile
echo '        case CTC_E_SCL_AD_NO_MEMORY:' >>$destfile
echo '        case CTC_E_SCL_L4_PORT_RANGE_EXHAUSTED:' >>$destfile
echo '        case CTC_E_SCL_TCP_FLAG_EXHAUSTED:' >>$destfile
echo '        case CTC_E_ACL_L4_PORT_RANGE_EXHAUSTED:' >>$destfile
echo '        case CTC_E_ACL_TCP_FLAG_EXHAUSTED:' >>$destfile
echo '        case CTC_E_ACL_NO_ROOM_TO_MOVE_ENTRY:' >>$destfile
echo '        case CTC_E_IPUC_TOO_MANY_FRAGMENT:' >>$destfile
echo '        case CTC_E_VLAN_MAPPING_VRANGE_FULL:' >>$destfile
echo '           return CTC_E_NO_RESOURCE;' >>$destfile
echo '        case CTC_E_NO_MEMORY:' >>$destfile
echo '        case CTC_E_CANT_CREATE_AVL:' >>$destfile
echo '        case CTC_E_SPOOL_ADD_UPDATE_FAILED:' >>$destfile
echo '        case CTC_E_RPF_SPOOL_ADD_VECTOR_FAILED:' >>$destfile
echo '        case CTC_E_NO_ROOM_TO_MOVE_ENTRY:' >>$destfile
echo '        case CTC_E_FAIL_CREATE_MUTEX:' >>$destfile
echo '        case CTC_E_CREATE_MEM_CACHE_FAIL:' >>$destfile
echo '        case CTC_E_OAM_MEP_INDEX_VECTOR_ADD_FAIL:' >>$destfile
echo '        case CTC_E_SCL_HASH_INSERT_FAILED:' >>$destfile
echo '        case CTC_E_PTP_TS_ADD_BUFF_FAIL:' >>$destfile
echo '           return CTC_E_NO_MEMORY;' >>$destfile
echo '        case CTC_E_HASH_CONFLICT:' >>$destfile
echo '        case CTC_E_MPLS_NO_RESOURCE:' >>$destfile
echo '        case CTC_E_IPUC_HASH_CONFLICT:' >>$destfile
echo '        case CTC_E_IPMC_HASH_CONFLICT:' >>$destfile
echo '        case CTC_E_SCL_HASH_CONFLICT:' >>$destfile
echo '        case CTC_E_ACL_HASH_CONFLICT:' >>$destfile
echo '            return CTC_E_HASH_CONFLICT;' >>$destfile
echo '        case CTC_E_NOT_INIT:' >>$destfile
echo '        case CTC_E_NH_NOT_INIT:' >>$destfile
echo '        case CTC_E_OAM_NOT_INIT:' >>$destfile
echo '        case CTC_E_OAM_TRPT_NOT_INIT:' >>$destfile
echo '        case CTC_E_BPE_NOT_INIT:' >>$destfile
echo '        case CTC_E_STK_NOT_INIT:' >>$destfile
echo '        case CTC_E_IPMC_GROUP_IS_NOT_INIT:' >>$destfile
echo '        case CTC_E_PTP_NOT_INIT:' >>$destfile
echo '        case CTC_E_DMA_NOT_INIT:' >>$destfile
echo '        case CTC_E_SYNCE_NOT_INIT:' >>$destfile
echo '        case CTC_E_INTR_NOT_INIT:' >>$destfile
echo '           return CTC_E_NOT_INIT;' >>$destfile
echo '        case CTC_E_INIT_FAIL:' >>$destfile
echo '        case CTC_E_SCL_INIT:' >>$destfile
echo '        case CTC_E_ACL_INIT:' >>$destfile
echo '        case CTC_E_DRV_FAIL:' >>$destfile
echo '           return CTC_E_INIT_FAIL;' >>$destfile
echo '        case CTC_E_NOT_READY:' >>$destfile
echo '        case CTC_E_QUEUE_SERVICE_QUEUE_NOT_INITIALIZED:' >>$destfile
echo '        case CTC_E_QUEUE_SERVICE_QUEUE_INITIALIZED:' >>$destfile
echo '        case CTC_E_OAM_MEP_LM_NOT_EN:' >>$destfile
echo '        case CTC_E_OAM_TRPT_SESSION_EN:' >>$destfile
echo '        case CTC_E_OAM_TRPT_SESSION_ALREADY_EN:' >>$destfile
echo '        case CTC_E_OAM_TRPT_SESSION_NOT_CFG:' >>$destfile
echo '        case CTC_E_PORT_ACL_EN_FIRST:' >>$destfile
echo '        case CTC_E_VLAN_CLASS_NOT_ENABLE:' >>$destfile
echo '        case CTC_E_VLAN_MAPPING_NOT_ENABLE:' >>$destfile
echo '        case CTC_E_VLAN_ACL_EN_FIRST:' >>$destfile
echo '        case CTC_E_L3IF_NO_ALLOCED_IPUCSA:' >>$destfile
echo '        case CTC_E_STATS_PORT_NOT_ENABLE:' >>$destfile
echo '        case CTC_E_STATS_NOT_ENABLE:' >>$destfile
echo '        case CTC_E_STATS_DMA_ENABLE_BUT_SW_DISABLE:' >>$destfile
echo '        case CTC_E_IPUC_VERSION_DISABLE:' >>$destfile
echo '        case CTC_E_IPUC_TUNNEL_INVALID:' >>$destfile
echo '        case CTC_E_IPMC_VERSION_DISABLE:' >>$destfile
echo '        case CTC_E_IPMC_RPF_CHECK_DISABLE:' >>$destfile
echo '        case CTC_E_USRID_DISABLE:' >>$destfile
echo '        case CTC_E_USRID_ALREADY_ENABLE:' >>$destfile
echo '        case CTC_E_SCL_DISABLE:' >>$destfile
echo '        case CTC_E_SCL_ALREADY_ENABLE:' >>$destfile
echo '        case CTC_E_SCL_NEED_DEBUG:' >>$destfile
echo '        case CTC_E_ACL_GROUP_NOT_EMPTY:' >>$destfile
echo '        case CTC_E_SCL_GROUP_NOT_EMPTY:' >>$destfile
echo '        case CTC_E_SCL_HAVE_ENABLED:' >>$destfile
echo '        case CTC_E_SCL_NOT_ENABLED:' >>$destfile
echo '        case CTC_E_ACLQOS_HAVE_ENABLED:' >>$destfile
echo '        case CTC_E_ACLQOS_NOT_ENABLED:' >>$destfile
echo '        case CTC_E_ACL_HAVE_ENABLED:' >>$destfile
echo '        case CTC_E_ACL_NOT_ENABLED:' >>$destfile
echo '        case CTC_E_QOS_POLICER_SERVICE_POLICER_NOT_ENABLE:' >>$destfile
echo '        case CTC_E_QOS_POLICER_STATS_NOT_ENABLE:' >>$destfile
echo '        case CTC_E_QOS_QUEUE_STATS_NOT_ENABLE:' >>$destfile
echo '        case CTC_E_SCL_ENTRY_INSTALLED:' >>$destfile
echo '        case CTC_E_SCL_GROUP_NOT_INSTALLED:' >>$destfile
echo '           return CTC_E_NOT_READY;' >>$destfile
echo '        case CTC_E_EXIST:' >>$destfile
echo '        case CTC_E_ENTRY_EXIST:' >>$destfile
echo '        case CTC_E_MEMBER_EXIST:' >>$destfile
echo '        case CTC_E_NH_EXIST:' >>$destfile
echo '        case CTC_E_NH_STATS_EXIST:' >>$destfile
echo '        case CTC_E_QUEUE_CHANNEL_SHAPE_PROF_EXIST:' >>$destfile
echo '        case CTC_E_QUEUE_SERVICE_EXIST:' >>$destfile
echo '        case CTC_E_APS_GROUP_EXIST:' >>$destfile
echo '        case CTC_E_APS_GROUP_NEXT_APS_EXIST:' >>$destfile
echo '        case CTC_E_OAM_MAID_ENTRY_EXIST:' >>$destfile
echo '        case CTC_E_OAM_CHAN_ENTRY_EXIST:' >>$destfile
echo '        case CTC_E_OAM_CHAN_LMEP_EXIST:' >>$destfile
echo '        case CTC_E_OAM_RMEP_EXIST:' >>$destfile
echo '        case CTC_E_OAM_NH_OFFSET_EXIST:' >>$destfile
echo '        case CTC_E_OAM_INDEX_EXIST:' >>$destfile
echo '        case CTC_E_MEMBER_PORT_EXIST:' >>$destfile
echo '        case CTC_E_ALREADY_PHY_IF_EXIST:' >>$destfile
echo '        case CTC_E_ALREADY_SUB_IF_EXIST:' >>$destfile
echo '        case CTC_E_MPLS_ENTRY_STATS_EXIST:' >>$destfile
echo '        case CTC_E_STK_TRUNK_HAS_EXIST:' >>$destfile
echo '        case CTC_E_STK_TRUNK_MEMBER_PORT_EXIST:' >>$destfile
echo '        case CTC_E_DATAPATH_PLL_EXIST_LANE:' >>$destfile
echo '        case CTC_E_VLAN_EXIST:' >>$destfile
echo '        case CTC_E_VLAN_RANGE_EXIST:' >>$destfile
echo '        case CTC_E_FDB_MAC_FILTERING_ENTRY_EXIST:' >>$destfile
echo '        case CTC_E_FDB_MCAST_ENTRY_EXIST:' >>$destfile
echo '        case CTC_E_FDB_KEY_ALREADY_EXIST:' >>$destfile
echo '        case CTC_E_L3IF_EXIST:' >>$destfile
echo '        case CTC_E_STATS_STATSID_EXIST:' >>$destfile
echo '        case CTC_E_IPMC_GROUP_HAS_EXISTED:' >>$destfile
echo '        case CTC_E_LINKAGG_HAS_EXIST:' >>$destfile
echo '        case CTC_E_SCL_GROUP_EXIST:' >>$destfile
echo '        case CTC_E_ACLQOS_ENTRY_EXIST:' >>$destfile
echo '        case CTC_E_ACL_ENTRY_EXIST:' >>$destfile
echo '        case CTC_E_ACL_GROUP_EXIST:' >>$destfile
echo '        case CTC_E_QOS_POLICER_CREATED:' >>$destfile
echo '           return CTC_E_EXIST;' >>$destfile
echo '        case CTC_E_NOT_EXIST:' >>$destfile
echo '        case CTC_E_QUEUE_CPU_REASON_NOT_CREATE:' >>$destfile
echo '        case CTC_E_ENTRY_NOT_EXIST:' >>$destfile
echo '        case CTC_E_MEMBER_NOT_EXIST:' >>$destfile
echo '        case CTC_E_NH_NOT_EXIST:' >>$destfile
echo '        case CTC_E_NH_STATS_NOT_EXIST:' >>$destfile
echo '        case CTC_E_NH_NOT_EXIST_TUNNEL_LABEL:' >>$destfile
echo '        case CTC_E_NH_ECMP_MEM_NOS_EXIST:' >>$destfile
echo '        case CTC_E_QUEUE_DROP_PROF_NOT_EXIST:' >>$destfile
echo '        case CTC_E_QUEUE_SHAPE_PROF_NOT_EXIST:' >>$destfile
echo '        case CTC_E_QUEUE_CHANNEL_SHAPE_PROF_NOT_EXIST:' >>$destfile
echo '        case CTC_E_QUEUE_SERVICE_NOT_EXIST:' >>$destfile
echo '        case CTC_E_QUEUE_SERVICE_GROUP_NOT_EXIST:' >>$destfile
echo '        case CTC_E_APS_GROUP_NOT_EXIST:' >>$destfile
echo '        case CTC_E_APS_RAPS_GROUP_NOT_EXIST:' >>$destfile
echo '        case CTC_E_OAM_MAID_ENTRY_NOT_FOUND:' >>$destfile
echo '        case CTC_E_OAM_CHAN_ENTRY_NOT_FOUND:' >>$destfile
echo '        case CTC_E_OAM_CHAN_MD_LEVEL_NOT_EXIST:' >>$destfile
echo '        case CTC_E_OAM_CHAN_LMEP_NOT_FOUND:' >>$destfile
echo '        case CTC_E_OAM_RMEP_NOT_FOUND:' >>$destfile
echo '        case CTC_E_OAM_NH_OFFSET_NOT_FOUND:' >>$destfile
echo '        case CTC_E_OVERLAY_TUNNEL_VN_FID_NOT_EXIST:' >>$destfile
echo '        case CTC_E_MEMBER_PORT_NOT_EXIST:' >>$destfile
echo '        case CTC_E_LOCAL_PORT_NOT_EXIST:' >>$destfile
echo '        case CTC_E_VPLS_VSI_NOT_CREATE:' >>$destfile
echo '        case CTC_E_MPLS_ENTRY_STATS_NOT_EXIST:' >>$destfile
echo '        case CTC_E_STK_TRUNK_NOT_EXIST:' >>$destfile
echo '        case CTC_E_STK_TRUNK_MEMBER_PORT_NOT_EXIST:' >>$destfile
echo '        case CTC_E_VLAN_NOT_CREATE:' >>$destfile
echo '        case CTC_E_VLAN_RANGE_NOT_EXIST:' >>$destfile
echo '        case CTC_E_FDB_DEFAULT_ENTRY_NOT_EXIST:' >>$destfile
echo '        case CTC_E_FDB_AD_INDEX_NOT_EXIST:' >>$destfile
echo '        case CTC_E_L3IF_VMAC_NOT_EXIST:' >>$destfile
echo '        case CTC_E_L3IF_NOT_EXIST:' >>$destfile
echo '        case CTC_E_L3IF_VRF_STATS_NOT_EXIST:' >>$destfile
echo '        case CTC_E_IPMC_GROUP_NOT_EXIST:' >>$destfile
echo '        case CTC_E_IPMC_STATS_NOT_EXIST:' >>$destfile
echo '        case CTC_E_LINKAGG_NOT_EXIST:' >>$destfile
echo '        case CTC_E_SCL_GROUP_UNEXIST:' >>$destfile
echo '        case CTC_E_SCL_LABEL_NOT_EXIST:' >>$destfile
echo '        case CTC_E_ACLQOS_ENTRY_NOT_EXIST:' >>$destfile
echo '        case CTC_E_ACLQOS_LABEL_NOT_EXIST:' >>$destfile
echo '        case CTC_E_QOS_POLICER_NOT_EXIST:' >>$destfile
echo '        case CTC_E_ACL_ENTRY_UNEXIST:' >>$destfile
echo '        case CTC_E_ACL_GROUP_UNEXIST:' >>$destfile
echo '        case CTC_E_ACL_LABEL_NOT_EXIST:' >>$destfile
echo '           return CTC_E_NOT_EXIST;' >>$destfile
echo '        case CTC_E_INVALID_CONFIG:' >>$destfile
echo '        case CTC_E_GLOBAL_CONFIG_CONFLICT:' >>$destfile
echo '        case CTC_E_MAC_NOT_USED:' >>$destfile
echo '        case CTC_E_NH_INVALID_DSEDIT_PTR:' >>$destfile
echo '        case CTC_E_NH_INVALID_NH_TYPE:' >>$destfile
echo '        case CTC_E_NH_INVALID_NH_SUB_TYPE:' >>$destfile
echo '        case CTC_E_NH_INVALID_VLAN_EDIT_TYPE:' >>$destfile
echo '        case CTC_E_NH_INVALID_DSNH_TYPE:' >>$destfile
echo '        case CTC_E_NH_VLAN_EDIT_CONFLICT:' >>$destfile
echo '        case CTC_E_NH_SHOULD_USE_DSNH8W:' >>$destfile
echo '        case CTC_E_NH_SHOULD_USE_DSNH4W:' >>$destfile
echo '        case CTC_E_NH_NHID_NOT_MATCH_NHTYPE:' >>$destfile
echo '        case CTC_E_NH_NO_LABEL:' >>$destfile
echo '        case CTC_E_NH_ISNT_UNROV:' >>$destfile
echo '        case CTC_E_NH_IS_UNROV:' >>$destfile
echo '        case CTC_E_NH_MEMBER_IS_UPMEP:' >>$destfile
echo '        case CTC_E_NH_EGS_EDIT_CONFLICT_VLAN_AND_MACDA_EDIT:' >>$destfile
echo '        case CTC_E_NH_LABEL_IS_MISMATCH_WITH_STATS:' >>$destfile
echo '        case CTC_E_NH_SUPPORT_PW_APS_UPDATE_BY_INT_ALLOC_DSNH:' >>$destfile
echo '        case CTC_E_QUEUE_DEPTH_NOT_EMPTY:' >>$destfile
echo '        case CTC_E_QUEUE_INVALID_CONFIG:' >>$destfile
echo '        case CTC_E_APS_INTERFACE_ERROR:' >>$destfile
echo '        case CTC_E_APS_MPLS_TYPE_L3IF_NOT_EXIST:' >>$destfile
echo '        case CTC_E_APS_DONT_SUPPORT_2_LEVEL_HW_BASED_APS:' >>$destfile
echo '        case CTC_E_OAM_CHAN_MD_LEVEL_EXIST:' >>$destfile
echo '        case CTC_E_OAM_CHAN_ENTRY_NUM_EXCEED:' >>$destfile
echo '        case CTC_E_OAM_LM_NUM_RXCEED:' >>$destfile
echo '        case CTC_E_OAM_CHAN_NOT_UP_DIRECTION:' >>$destfile
echo '        case CTC_E_OAM_CHAN_NOT_DOWN_DIRECTION:' >>$destfile
echo '        case CTC_E_OAM_TX_GPORT_AND_MASTER_GCHIP_NOT_MATCH:' >>$destfile
echo '        case CTC_E_OAM_TX_GPORT_AND_CHAN_GPORT_NOT_MATCH:' >>$destfile
echo '        case CTC_E_OAM_INVALID_CFG_IN_MEP_TYPE:' >>$destfile
echo '        case CTC_E_OAM_INVALID_CFG_LM:' >>$destfile
echo '        case CTC_E_OAM_NH_OFFSET_ADD_VECTOR_FAIL:' >>$destfile
echo '        case CTC_E_OAM_RMEP_D_LOC_PRESENT:' >>$destfile
echo '        case CTC_E_OAM_ITU_DEFECT_CLEAR_MODE:' >>$destfile
echo '        case CTC_E_OAM_INVALID_OPERATION_ON_CPU_MEP:' >>$destfile
echo '        case CTC_E_OAM_INVALID_OPERATION_ON_P2P_MEP:' >>$destfile
echo '        case CTC_E_OAM_INVALID_GLOBAL_PARAM_TYPE:' >>$destfile
echo '        case CTC_E_OAM_EXCEED_MAX_LEVEL_NUM_PER_CHAN:' >>$destfile
echo '        case CTC_E_OAM_TRPT_INTERVAL_CONFLICT:' >>$destfile
echo '        case CTC_E_BPE_INVALID_BPE_CAPABLE_GPORT:' >>$destfile
echo '        case CTC_E_BPE_INVLAID_BPE_MODE:' >>$destfile
echo '        case CTC_E_PORT_HAS_OTHER_FEATURE:' >>$destfile
echo '        case CTC_E_PORT_FEATURE_MISMATCH:' >>$destfile
echo '        case CTC_E_PORT_HAS_OTHER_RESTRICTION:' >>$destfile
echo '        case CTC_E_CHIP_DATAPATH_NOT_MATCH:' >>$destfile
echo '        case CTC_E_PORT_PROP_COLLISION:' >>$destfile
echo '        case CTC_E_PORT_MAC_IS_DISABLE:' >>$destfile
echo '        case CTC_E_MPLS_LABEL_ERROR:' >>$destfile
echo '        case CTC_E_STK_TRUNK_EXCEED_MAX_MEMBER_PORT:' >>$destfile
echo '        case CTC_E_STK_KEEPLIVE_TWO_MEMBER_AND_ONE_CPU:' >>$destfile
echo '        case CTC_E_DATAPATH_INVALID_PORT_TYPE:' >>$destfile
echo '        case CTC_E_DATAPATH_MAC_ENABLE:' >>$destfile
echo '        case CTC_E_INVALID_PORT_MAC_TYPE:' >>$destfile
echo '        case CTC_E_CANT_CHANGE_SERDES_MODE:' >>$destfile
echo '        case CTC_E_VLAN_RANGE_END_GREATER_START:' >>$destfile
echo '        case CTC_E_VLAN_MAPPING_GET_VLAN_RANGE_FAILED:' >>$destfile
echo '        case CTC_E_VLAN_MAPPING_VRANGE_OVERLAPPED:' >>$destfile
echo '        case CTC_E_VLAN_MAPPING_TAG_APPEND:' >>$destfile
echo '        case CTC_E_VLAN_MAPPING_TAG_SWAP:' >>$destfile
echo '        case CTC_E_FDB_L2MCAST_ADD_MEMBER_FAILED:' >>$destfile
echo '        case CTC_E_FDB_OPERATION_PAUSE:' >>$destfile
echo '        case CTC_E_FDB_HASH_REMOVE_FAILED:' >>$destfile
echo '        case CTC_E_FDB_DEFAULT_ENTRY_NOT_ALLOWED:' >>$destfile
echo '        case CTC_E_FDB_ONLY_SW_LEARN:' >>$destfile
echo '        case CTC_E_FDB_LOGIC_USE_HW_LEARN_DISABLE:' >>$destfile
echo '        case CTC_E_VLAN_FILTER_PORT:' >>$destfile
echo '        case CTC_E_FDB_L2MCAST_MEMBER_INVALID:' >>$destfile
echo '        case CTC_E_L3IF_MISMATCH:' >>$destfile
echo '        case CTC_E_STATS_PORT_STATS_NO_TYPE:' >>$destfile
echo '        case CTC_E_STATS_PHB_STATS_INVALID:' >>$destfile
echo '        case CTC_E_STATS_PORT_NOT_MAP_TO_MAC:' >>$destfile
echo '        case CTC_E_STATS_MAC_STATS_MODE_ASIC:' >>$destfile
echo '        case CTC_E_STATS_TABLE_NUM_NO_EXPECT:' >>$destfile
echo '        case CTC_E_STATS_VLAN_STATS_CONFLICT_WITH_PHB:' >>$destfile
echo '        case CTC_E_STATS_STATSID_TYPE_MISMATCH:' >>$destfile
echo '        case CTC_E_IPUC_NEED_L3IF:' >>$destfile
echo '        case CTC_E_IPUC_RPF_NOT_SUPPORT_THIS_MASK_LEN:' >>$destfile
echo '        case CTC_E_IPUC_NAT_NOT_SUPPORT_THIS_MASK_LEN:' >>$destfile
echo '        case CTC_E_IPUC_TUNNEL_RPF_INFO_MISMATCH:' >>$destfile
echo '        case CTC_E_IPUC_TUNNEL_PAYLOAD_TYPE_MISMATCH:' >>$destfile
echo '        case CTC_E_IPUC_INVALID_ROUTE_FLAG:' >>$destfile
echo '        case CTC_E_IPMC_ADD_MEMBER_FAILED:' >>$destfile
echo '        case CTC_E_IPMC_GROUP_IS_NOT_IP_MAC:' >>$destfile
echo '        case CTC_E_IPMC_GROUP_IS_IP_MAC:' >>$destfile
echo '        case CTC_E_SCL_HASH_CONVERT_FAILED:' >>$destfile
echo '        case CTC_E_SCL_GET_KEY_FAILED:' >>$destfile
echo '        case CTC_E_SCL_KEY_AD_EXIST:' >>$destfile
echo '        case CTC_E_SCL_BUILD_VLAN_ACTION_INDEX_FAILED:' >>$destfile
echo '        case CTC_E_SCL_CANNOT_OVERWRITE:' >>$destfile
echo '        case CTC_E_SCL_LKP_FAILED:' >>$destfile
echo '        case CTC_E_SCL_STATIC_ENTRY:' >>$destfile
echo '        case CTC_E_SCL_UPDATE_FAILED:' >>$destfile
echo '        case CTC_E_SCL_FLAG_COLLISION:' >>$destfile
echo '        case CTC_E_ACL_FLAG_COLLISION:' >>$destfile
echo '        case CTC_E_SCL_GET_NODES_FAILED:' >>$destfile
echo '        case CTC_E_SCL_GROUP_INFO:' >>$destfile
echo '        case CTC_E_SCL_ADD_TCAM_ENTRY_TO_WRONG_GROUP:' >>$destfile
echo '        case CTC_E_SCL_ADD_HASH_ENTRY_TO_WRONG_GROUP:' >>$destfile
echo '        case CTC_E_SCL_HASH_ENTRY_NO_PRIORITY:' >>$destfile
echo '        case CTC_E_SCL_KEY_ACTION_TYPE_NOT_MATCH:' >>$destfile
echo '        case CTC_E_QOS_POLICER_CIR_GREATER_THAN_PIR:' >>$destfile
echo '        case CTC_E_QOS_POLICER_CBS_GREATER_THAN_PBS:' >>$destfile
echo '        case CTC_E_ACLQOS_DIFFERENT_DIR:' >>$destfile
echo '        case CTC_E_ACLQOS_DIFFERENT_TYPE:' >>$destfile
echo '        case CTC_E_ACLQOS_DIFFERENT_CHIP:' >>$destfile
echo '        case CTC_E_PTP_TS_GET_BUFF_FAIL:' >>$destfile
echo '        case CTC_E_PTP_CAN_NOT_SET_TOW:' >>$destfile
echo '        case CTC_E_SYNCE_INVALID_RECOVERED_PORT:' >>$destfile
echo '        case CTC_E_QOS_NO_INT_POLICER_ENTRY:' >>$destfile
echo '        case CTC_E_QOS_NO_EXT_POLICER_ENTRY:' >>$destfile
echo '        case CTC_E_QOS_NO_INT_POLICER_PROFILE_ENTRY:' >>$destfile
echo '        case CTC_E_ACL_PBR_ENTRY_NO_NXTTHOP:' >>$destfile
echo '        case CTC_E_ACL_GET_NODES_FAILED:' >>$destfile
echo '        case CTC_E_SCL_GLOBAL_CFG_ERROR:' >>$destfile
echo '        case CTC_E_QOS_POLICER_NOT_BIND:' >>$destfile
echo '        case CTC_E_ACL_GROUP_INFO:' >>$destfile
echo '        case CTC_E_ACL_ENTRY_INSTALLED:' >>$destfile
echo '        case CTC_E_ACL_GET_STATS_FAILED:' >>$destfile
echo '        case CTC_E_ACL_GROUP_NOT_INSTALLED:' >>$destfile
echo '        case CTC_E_ACL_GLOBAL_CFG_ERROR:' >>$destfile
echo '        case CTC_E_ACL_ADD_TCAM_ENTRY_TO_WRONG_GROUP:' >>$destfile
echo '        case CTC_E_ACL_ADD_HASH_ENTRY_TO_WRONG_GROUP:' >>$destfile
echo '        case CTC_E_ACL_HASH_ENTRY_NO_PRIORITY:' >>$destfile
echo '        case CTC_E_IPUC_ADD_FAILED:' >>$destfile
echo '        case CTC_E_SCL_GET_BLOCK_INDEX_FAILED:' >>$destfile
echo '        case CTC_E_SCL_GET_STATS_FAILED:' >>$destfile
echo '        case CTC_E_ACL_PBR_ECMP_CMP_FAILED:' >>$destfile
echo '        case CTC_E_ACL_PBR_DO_ECMP_FAILED:' >>$destfile
echo '        case CTC_E_MUTEX_BUSY:' >>$destfile
echo '           return CTC_E_INVALID_CONFIG;' >>$destfile
echo '        default:' >>$destfile
echo '            return CTC_E_INVALID_PARAM;' >>$destfile
echo '    }' >>$destfile
echo '' >>$destfile
echo '}' >>$destfile
echo '' >>$destfile
echo 'int32' >>$destfile
echo 'ctc_set_error_code_mapping_en(uint8 enable)' >>$destfile
echo '{' >>$destfile
echo '    g_mapping_disable = !enable;' >>$destfile
echo '    return CTC_E_NONE;' >>$destfile
echo '}' >>$destfile



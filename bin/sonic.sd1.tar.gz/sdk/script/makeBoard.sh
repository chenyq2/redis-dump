cd ..
make targetbase=linux ARCH=powerpc BOARD=ctc-board CHIPNAME=greatbelt all

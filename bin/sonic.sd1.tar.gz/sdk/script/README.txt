Files in this folder are script for centec sdk, their function as follows:

#1. The files in Auto_generate_api folder are script for generating sdk apis
	They can be used to generate one chip's api or merge many chip's api
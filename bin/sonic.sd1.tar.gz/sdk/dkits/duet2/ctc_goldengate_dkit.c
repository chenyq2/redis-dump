#include "drv_api.h"
#include "drv_common.h"

#include "ctc_cli.h"
#include "ctc_dkit.h"
#include "ctc_dkit_common.h"
#include "ctc_goldengate_dkit.h"
#include "ctc_goldengate_dkit_memory.h"
#include "ctc_goldengate_dkit_drv.h"
#include "ctc_goldengate_dkit_captured_info.h"
#include "ctc_goldengate_dkit_path.h"
#include "ctc_goldengate_dkit_discard.h"
#include "ctc_goldengate_dkit_monitor.h"
#if 0
#include "ctc_goldengate_dkit_interface.h"
#endif
#include "ctc_goldengate_dkit_tcam.h"

#include "ctc_goldengate_dkit_dump_cfg.h"
#include "ctc_goldengate_dkit_misc.h"
#if 1
#include "ctc_goldengate_dkit_internal.h"
#endif

ctc_dkit_master_t* g_dkit_master[CTC_DKITS_MAX_LOCAL_CHIP_NUM] = {NULL};
ctc_dkit_api_t* g_dkit_api = NULL;
ctc_dkit_chip_api_t* g_dkit_chip_api = NULL;

int32 ctc_dkit_chip_init(void)
{
    if (g_dkit_chip_api == NULL)
    {
        return CLI_ERROR;
    }
    g_dkit_chip_api->dkits_dump_decode_entry = ctc_goldengate_dkits_dump_decode_entry;
    return 0;
}

/*special for emulation*/
#define __EMULATION__
extern fields_t *
drv_find_field(tbls_id_t tbl_id, fld_id_t field_id);
extern int32
drv_chip_write(uint8 lchip, uint32 offset, uint32 value);
#define TIPS_NONE           0
#define TIPS_TBL_REG        1
#define TIPS_TBL_REG_FIELD  2

int32 show_tips_info(uint8 tips_type, char* inc_str, tbls_id_t id)
{
    tbls_id_t tbl_reg_id = 0;
    char comment[128] = {0};
    char up_comment[128] = {0};
    char up_str[128] = {0};
    uint8  i = 0;
    fld_id_t field_id = 0;

    fields_t* first_f = NULL;
    fields_t* end_f = NULL;
    uint32 num_f = 0;

    if (((NULL == inc_str)&&(TIPS_TBL_REG == tips_type))
        || (TIPS_NONE == tips_type))
    {
        return CLI_ERROR;
    }

    if (NULL != inc_str)
    {
        for (i = 0; i < sal_strlen(inc_str); i++)
        {
            up_str[i] = sal_toupper(inc_str[i]);
        }
    }

    if (TIPS_TBL_REG == tips_type)
    {
        for (tbl_reg_id = 0; tbl_reg_id  < MaxTblId_t; tbl_reg_id++)
        {
            if (DRV_E_NONE != drv_get_tbl_string_by_id(tbl_reg_id, comment))
            {
                ctc_cli_out(" Get TBL_REG_Name by tbl/RegId error! tbl/RegId: %d, Line = %d\n",
                                      tbl_reg_id, __LINE__);
            }
            else
            {
                for (i = 0; i < sal_strlen(comment); i++)
                {
                    up_comment[i] = sal_toupper(comment[i]);
                }
                if (NULL != sal_strstr(up_comment, up_str))
                {
                    ctc_cli_out("ID: %04d, \tNAME: %s\n", tbl_reg_id, comment);
                }
                sal_memset(comment, 0, sizeof(comment));
                sal_memset(up_comment, 0, sizeof(up_comment));
            }
        }
    }
    else if (TIPS_TBL_REG_FIELD == tips_type)
    {
        if (MaxTblId_t <= id)
        {
            ctc_cli_out("\nERROR! INVALID tbl/Reg ID! tbl/Reg ID: %d, file:%s line:%d function:%s\n",
                        id,__FILE__,__LINE__,__FUNCTION__);
            return CLI_ERROR;
        }

        first_f = TABLE_INFO(id).ptr_fields;
        num_f = TABLE_INFO(id).field_num;
        end_f = &first_f[num_f];

        while (first_f < end_f)
        {
            ctc_cli_out("FIELD_ID = %2d, \tFIELD_NAME: %-32s\n", field_id, first_f->ptr_field_name);
            first_f++;
            field_id++;
        }
    }

    return CLI_SUCCESS;
}

int write_entry(uint8 chip_id, tbls_id_t id, uint32 index, uint32 offset, uint32 value)
{
    uint8 chipid_base  = 0;
    uint32 hw_addr_base = 0;
    uint32 entry_size   = 0;
    uint32 max_entry    = 0;
    uint32 hw_addr_offset      = 0;
    int32  ret = 0;
    uint8 addr_offset  = 0;

    if (MaxTblId_t <= id)
    {
        ctc_cli_out("\nERROR! INVALID tbl/RegID! tbl/RegID: %d, file:%s line:%d function:%s\n",
                    id,__FILE__,__LINE__,__FUNCTION__);
        return CLI_ERROR;
    }

    DRV_IF_ERROR_RETURN(drv_get_tbl_index_base(id, index, &addr_offset));
    entry_size      = TABLE_ENTRY_SIZE(id);
    max_entry       = TABLE_MAX_INDEX(id);
    hw_addr_base    = TABLE_DATA_BASE(id, addr_offset);
    if (index >= max_entry)
    {
        return CLI_ERROR;
    }
    /*TODO: dynamic table*/
    if ((4 == entry_size) || (8 == entry_size))
    {/*1w or 2w*/
        hw_addr_offset  =   hw_addr_base + index * entry_size + offset;
    }
    else if (entry_size <= 4*4)
    {/*4w*/
        hw_addr_offset  =   hw_addr_base + index * 4*4 + offset;
    }
    else if (entry_size <= 4*8)
    {/*8w*/
        hw_addr_offset  =   hw_addr_base + index * 4*8 + offset;
    }
    else if (entry_size <= 4*16)
    {/*16w*/
        hw_addr_offset  =   hw_addr_base + index * 4*16 + offset;
    }
    else if (entry_size <= 4*32)
    {/*32w*/
        hw_addr_offset  =   hw_addr_base + index * 4*32 + offset;
    }
    else if (entry_size <= 4*64)
    {/*64w*/
        hw_addr_offset  =   hw_addr_base + index * 4*64 + offset;
    }

    chipid_base = 0;
//-    ret = drv_get_chipid_base(&chipid_base);
    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("Get chipId base ERROR! Value = 0x%08x\n", chipid_base);
        return ret;
    }

    //-ctc_cli_out("Offset write +++! entry_size = %d, max_entry = %d\n", entry_size,max_entry);
    //-ctc_cli_out("Offset write +++! hw_addr_offset = 0x%08x, hw_addr_base = 0x%08x\n", hw_addr_offset,hw_addr_base);
    ret = drv_chip_write(chip_id-chipid_base, hw_addr_offset, value);

    if (ret < DRV_E_NONE)
    {
        ctc_cli_out("0x%08x address write ERROR! Value = 0x%08x\n", hw_addr_offset, value);
        return ret;
    }

    return CLI_SUCCESS;
}

int32 write_tbl_reg(uint8 chip_id, tbls_id_t id, uint32 index, fld_id_t field_id, uint32* value)
{
    fields_t* field = NULL;
    uint32 cmd = 0;
    int32 ret = 0;

    if (MaxTblId_t <= id)
    {
        ctc_cli_out("\nERROR! INVALID tbl/RegID! tbl/RegID: %d, file:%s line:%d function:%s\n",
                    id,__FILE__,__LINE__,__FUNCTION__);
        return CLI_ERROR;
    }

    field = drv_find_field(id, field_id);
    cmd = DRV_IOW(id, field_id);
    ret = DRV_IOCTL(chip_id, index, cmd, value);

    if (ret < 0)
    {
        return ret;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_dbg_tool_write_tbl_fld_reg,
    cli_dbg_tool_write_tbl_reg_fld_cmd,
    "write chip CHIP_ID tbl-reg TBL_REG_ID INDEX (field FIELD_NAME| offset OFFSET) VAL",
    "write chip table or register info",
    "chip information",
    "chipid value",
    "write table or register",
    "table or register ID name",
    "table or register entry index <0>",
    "Table/register fileld id name",
    "Table/register field name(string)",
    "Table offset",
    "Table offset value",
    "Set value")
{
    uint32 chip_id = 0;
    uint8 tips_type = TIPS_NONE;
    char *tip_str = NULL;

    char* id_name = NULL;
    char* field_name = NULL;

    uint32 id = 0;
    uint32 field_id = 0;
    uint32 index = 0;
    uint32 idx = 0;
    uint32 value[DRV_MAX_ARRAY_NUM] = {0};
    uint32 offset = 0xFFFFFFFF;
    int32 ret = 0;

    CTC_CLI_GET_INTEGER("chipid", chip_id, argv[0]);
    chip_id = 0;

    id_name = argv[1];
    if(DRV_E_NONE != drv_get_tbl_id_by_string(&id, id_name))
    {
        ctc_cli_out("can't find tbl %s \n", id_name);
        return CLI_ERROR;
    }
    CTC_CLI_GET_INTEGER("tbl/reg index", index, argv[2]);
    if(3 == argc)
    {
        tips_type = TIPS_TBL_REG_FIELD;
    }
    else
    {
        idx = ctc_cli_get_prefix_item(&argv[0], argc, "field", sal_strlen("field"));
        if (0xFF != idx)
        {
            field_name = argv[idx + 1];
            if (DRV_E_NONE != drv_get_field_id_by_string(id, (fld_id_t*)&field_id, field_name))
            {
                ctc_cli_out("can't find table %s field %s \n", id_name, field_name);
                return CLI_ERROR;
            }

            CTC_CLI_GET_INTEGER_N("field-value", (uint32 *)value, argv[idx + 2]);
        }

        idx = ctc_cli_get_prefix_item(&argv[0], argc, "offset", sal_strlen("offset"));
        if (0xFF != idx)
        {
            CTC_CLI_GET_INTEGER("offset", offset, argv[idx + 1]);
            CTC_CLI_GET_INTEGER_N("field-value", (uint32 *)value, argv[idx + 2]);
        }

    }

    if(TIPS_NONE != tips_type)
    {
        show_tips_info(tips_type, tip_str, id);
    }
    else
    {
        if(0xFFFFFFFF != offset)
        {
            write_entry(chip_id, id, index, offset, value[0]);
        }
        else
        {
            ret = write_tbl_reg(chip_id, id, index, field_id, value);

            if (ret < 0)
            {
                return ret;
            }
        }
    }

    return CLI_SUCCESS;
}


int32 ctc_dkit_init(void)
{
    uint8 lchip = 0;

    g_dkit_api = (ctc_dkit_api_t*)mem_malloc(MEM_CLI_MODULE, sizeof(ctc_dkit_api_t));
    if (NULL == g_dkit_api)
    {
        CTC_DKIT_PRINT("No memory for dkits!!!\n");
        goto ERROE;
    }

    g_dkit_chip_api = (ctc_dkit_chip_api_t*)mem_malloc(MEM_CLI_MODULE, sizeof(ctc_dkit_chip_api_t));
    if (NULL == g_dkit_chip_api)
    {
        CTC_DKIT_PRINT("No memory for dkits!!!\n");
        goto ERROE;
    }

    sal_memset(g_dkit_api, 0 , sizeof(ctc_dkit_api_t));
    sal_memset(g_dkit_chip_api, 0 , sizeof(ctc_dkit_chip_api_t));

    for (lchip = 0; lchip < CTC_DKITS_MAX_LOCAL_CHIP_NUM; lchip++)
    {
        g_dkit_master[lchip] = (ctc_dkit_master_t*)mem_malloc(MEM_CLI_MODULE, sizeof(ctc_dkit_master_t));
        if (NULL == g_dkit_master[lchip])
        {
            CTC_DKIT_PRINT("No memory for dkits!!!\n");
            goto ERROE;
        }
        sal_memset(g_dkit_master[lchip], 0 , sizeof(ctc_dkit_master_t));
    }


    /*register API*/
    /*1. Basic*/
    g_dkit_api->memory_process = ctc_goldengate_dkit_memory_process;
    g_dkit_api->show_discard = ctc_goldengate_dkit_discard_process;
    g_dkit_api->show_discard_type = ctc_goldengate_dkit_discard_show_type;


    /*2. Normal*/
    g_dkit_api->install_captured_flow = ctc_goldengate_dkit_captured_install_flow;
    g_dkit_api->clear_captured_flow = ctc_goldengate_dkit_captured_clear;

    g_dkit_api->show_path = ctc_goldengate_dkit_path_process;


    g_dkit_api->show_queue_depth = ctc_goldengate_dkit_monitor_show_queue_depth;
    g_dkit_api->show_queue_id = ctc_goldengate_dkit_monitor_show_queue_id;
    #if 0
    g_dkit_api->show_interface_status = ctc_goldengate_dkit_interface_show_mac_status;
    #endif

    g_dkit_api->show_tcam_key_type = ctc_goldengate_dkits_tcam_show_key_type;
    g_dkit_api->tcam_capture_start = ctc_goldengate_dkits_tcam_capture_start;
    g_dkit_api->tcam_capture_stop = ctc_goldengate_dkits_tcam_capture_stop;
    g_dkit_api->tcam_capture_show = ctc_goldengate_dkits_tcam_capture_show;
    g_dkit_api->tcam_scan = ctc_goldengate_dkits_tcam_scan;
    g_dkit_api->cfg_usage = ctc_goldengate_dkits_dump_memory_usage;
    g_dkit_api->cfg_dump = ctc_goldengate_dkits_dump_cfg_dump;
    g_dkit_api->cfg_decode = ctc_goldengate_dkits_dump_cfg_decode;
    g_dkit_api->cfg_cmp = ctc_goldengate_dkits_dump_cfg_cmp;

    /*3. Advanced*/
#if 0
    g_dkit_api->show_sensor_result = ctc_goldengate_dkit_monitor_show_sensor_result;
    g_dkit_api->serdes_ctl = ctc_goldengate_dkit_misc_serdes_ctl;
#endif
    g_dkit_api->integrity_check = ctc_goldengate_dkit_misc_integrity_check;

    ctc_dkit_chip_init();

#if 1
    ctc_goldengate_dkit_internal_cli_init(CTC_DKITS_MODE);
    //- ctc_goldengate_dkit_drv_register();
#endif
    install_element(CTC_DKITS_MODE, &cli_dbg_tool_write_tbl_reg_fld_cmd);

    return CLI_SUCCESS;

ERROE:
    CTC_DKIT_PRINT("Dkits init fail!!!\n");
    if (g_dkit_api)
    {
        mem_free(g_dkit_api);
        g_dkit_api = NULL;
    }

    if (g_dkit_chip_api)
    {
        mem_free(g_dkit_chip_api);
        g_dkit_chip_api = NULL;
    }

    for (lchip = 0; lchip < CTC_DKITS_MAX_LOCAL_CHIP_NUM; lchip++)
    {
        if (g_dkit_master[lchip])
        {
            mem_free(g_dkit_master[lchip]);
            g_dkit_master[lchip] = NULL;
        }
    }


    return CLI_SUCCESS;
}


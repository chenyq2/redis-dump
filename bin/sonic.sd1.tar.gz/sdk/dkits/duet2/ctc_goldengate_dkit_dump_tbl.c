#include "drv_api.h"
#include "ctc_cli.h"
#include "ctc_dkit.h"
#include "ctc_goldengate_dkit_tcam.h"
#include "ctc_goldengate_dkit_dump_tbl.h"

tbls_id_t auto_genernate_tbl[] =
{
    /* ... */
    MaxTblId_t
};

tbls_id_t fib_hash_bridge_key_tbl[] =
{
    DsFibHost0MacHashKey_t,
    MaxTblId_t
};

tbls_id_t fib_hash_ipuc_ipv4_key_tbl[] =
{
    DsFibHost0Ipv4HashKey_t,
    DsFibHost1Ipv4NatDaPortHashKey_t,
    DsFibHost1Ipv4NatSaPortHashKey_t,
    MaxTblId_t
};

tbls_id_t fib_hash_ipuc_ipv6_key_tbl[] =
{
    DsFibHost0Ipv6UcastHashKey_t,
    DsFibHost1Ipv6NatDaPortHashKey_t,
    DsFibHost1Ipv6NatSaPortHashKey_t,
    MaxTblId_t
};

tbls_id_t fib_hash_ipmc_ipv4_key_tbl[] =
{
    DsFibHost1Ipv4McastHashKey_t,
    DsFibHost1MacIpv4McastHashKey_t,
    MaxTblId_t
};

tbls_id_t fib_hash_ipmc_ipv6_key_tbl[] =
{
    DsFibHost0Ipv6McastHashKey_t,
    DsFibHost0MacIpv6McastHashKey_t,
    DsFibHost1Ipv6McastHashKey_t,
    DsFibHost1MacIpv6McastHashKey_t,
    MaxTblId_t
};

tbls_id_t fib_hash_fcoe_key_tbl[] =
{
    DsFibHost0FcoeHashKey_t,
    DsFibHost1FcoeRpfHashKey_t,
    MaxTblId_t
};

tbls_id_t fib_hash_trill_key_tbl[] =
{
    DsFibHost0TrillHashKey_t,
    DsFibHost1TrillMcastVlanHashKey_t,
    MaxTblId_t
};

tbls_id_t scl_hash_bridge_key_tbl[] =
{
    DsUserIdCvlanCosPortHashKey_t,
    DsUserIdCvlanPortHashKey_t,
    DsUserIdDoubleVlanPortHashKey_t,
    DsUserIdMacHashKey_t,
    DsUserIdMacPortHashKey_t,
    DsUserIdPortHashKey_t,
    DsUserIdSvlanCosPortHashKey_t,
    DsUserIdSvlanHashKey_t,
    DsUserIdSvlanMacSaHashKey_t,
    DsUserIdSvlanPortHashKey_t,
    DsUserIdSclFlowL2HashKey_t,
    MaxTblId_t
};

tbls_id_t scl_hash_ipv4_key_tbl[] =
{
    DsUserIdIpv4PortHashKey_t,
    DsUserIdIpv4SaHashKey_t,
    MaxTblId_t
};

tbls_id_t scl_hash_ipv6_key_tbl[] =
{
    DsUserIdIpv6PortHashKey_t,
    DsUserIdIpv6SaHashKey_t,
    MaxTblId_t
};

tbls_id_t scl_hash_iptunnel_key_tbl[] =
{
    DsUserIdTunnelIpv4DaHashKey_t,
    DsUserIdTunnelIpv4GreKeyHashKey_t,
    DsUserIdTunnelIpv4HashKey_t,
    DsUserIdTunnelIpv4RpfHashKey_t,
    DsUserIdTunnelIpv4UdpHashKey_t,
    MaxTblId_t
};

tbls_id_t scl_hash_nvgre_tunnel_key_tbl[] =
{
    DsUserIdTunnelIpv4NvgreMode1HashKey_t,
    DsUserIdTunnelIpv4McNvgreMode0HashKey_t,
    DsUserIdTunnelIpv4UcNvgreMode0HashKey_t,
    DsUserIdTunnelIpv4UcNvgreMode1HashKey_t,
    DsUserIdTunnelIpv6McNvgreMode0HashKey_t,
    DsUserIdTunnelIpv6McNvgreMode1HashKey_t,
    DsUserIdTunnelIpv6UcNvgreMode0HashKey_t,
    DsUserIdTunnelIpv6UcNvgreMode1HashKey_t,
    MaxTblId_t
};

tbls_id_t scl_hash_vxlan_tunnel_key_tbl[] =
{
    DsUserIdTunnelIpv4McVxlanMode0HashKey_t,
    DsUserIdTunnelIpv4UcVxlanMode0HashKey_t,
    DsUserIdTunnelIpv4UcVxlanMode1HashKey_t,
    DsUserIdTunnelIpv4VxlanMode1HashKey_t,
    DsUserIdTunnelIpv6McVxlanMode0HashKey_t,
    DsUserIdTunnelIpv6McVxlanMode1HashKey_t,
    DsUserIdTunnelIpv6UcVxlanMode0HashKey_t,
    DsUserIdTunnelIpv6UcVxlanMode1HashKey_t,
    MaxTblId_t
};

tbls_id_t scl_hash_capwap_key_tbl[] =
{
    DsUserIdTunnelCapwapRmacHashKey_t,
    DsUserIdTunnelCapwapRmacRidHashKey_t,
    DsUserIdTunnelIpv4CapwapHashKey_t,
    DsUserIdTunnelIpv6CapwapHashKey_t,
    MaxTblId_t
};

tbls_id_t scl_hash_mpls_tunnel_key_tbl[] =
{
    DsUserIdTunnelMplsHashKey_t,
    MaxTblId_t
};

tbls_id_t scl_hash_pbb_tunnel_key_tbl[] =
{
    DsUserIdTunnelPbbHashKey_t,
    MaxTblId_t
};

tbls_id_t scl_hash_trill_tunnel_key_tbl[] =
{
    DsUserIdTunnelTrillMcAdjHashKey_t,
    DsUserIdTunnelTrillMcDecapHashKey_t,
    DsUserIdTunnelTrillMcRpfHashKey_t,
    DsUserIdTunnelTrillUcDecapHashKey_t,
    DsUserIdTunnelTrillUcRpfHashKey_t,
    MaxTblId_t
};

tbls_id_t ipfix_hash_bridge_key_tbl[] =
{
    DsIpfixL2HashKey_t,
    MaxTblId_t
};

tbls_id_t ipfix_hash_l2l3_key_tbl[] =
{
    DsIpfixL2L3HashKey_t,
    MaxTblId_t
};

tbls_id_t ipfix_hash_ipv4_key_tbl[] =
{
    DsIpfixL3Ipv4HashKey_t,
    MaxTblId_t
};

tbls_id_t ipfix_hash_ipv6_key_tbl[] =
{
    DsIpfixL3Ipv6HashKey_t,
    MaxTblId_t
};

tbls_id_t ipfix_hash_mpls_key_tbl[] =
{
    DsIpfixL3MplsHashKey_t,
    MaxTblId_t
};

tbls_id_t flow_hash_bridge_key_tbl[] =
{
    DsFlowL2HashKey_t,
    MaxTblId_t
};

tbls_id_t flow_hash_l2l3_key_tbl[] =
{
    DsFlowL2L3HashKey_t,
    MaxTblId_t
};

tbls_id_t flow_hash_ipv4_key_tbl[] =
{
    DsFlowL3Ipv4HashKey_t,
    MaxTblId_t
};

tbls_id_t flow_hash_ipv6_key_tbl[] =
{
    DsFlowL3Ipv6HashKey_t,
    MaxTblId_t
};

tbls_id_t flow_hash_mpls_key_tbl[] =
{
    DsFlowL3MplsHashKey_t,
    MaxTblId_t
};

tbls_id_t xcoam_hash_scl_tbl[] =
{
    DsEgressXcOamPortCrossHashKey_t,
    DsEgressXcOamPortHashKey_t,
    DsEgressXcOamPortVlanCrossHashKey_t,
    DsEgressXcOamCvlanCosPortHashKey_t,
    DsEgressXcOamCvlanPortHashKey_t,
    DsEgressXcOamDoubleVlanPortHashKey_t,
    DsEgressXcOamSvlanCosPortHashKey_t,
    DsEgressXcOamSvlanPortHashKey_t,
    DsEgressXcOamSvlanPortMacHashKey_t,
    MaxTblId_t
};

tbls_id_t xcoam_hash_tunnel_tbl[] =
{
    DsEgressXcOamTunnelPbbHashKey_t,
    MaxTblId_t
};

tbls_id_t xcoam_hash_oam_tbl[] =
{
    DsEgressXcOamBfdHashKey_t,
    DsEgressXcOamEthHashKey_t,
    DsEgressXcOamMplsLabelHashKey_t,
    DsEgressXcOamMplsSectionHashKey_t,
    DsEgressXcOamRmepHashKey_t,
    MaxTblId_t
};

#if 0
tbls_id_t oam_tbl[] =
{
    /* APS */
    DsApsBridge_t,
    /* LM */
    DsOamLmStats_t,
    /* MEP */
    DsBfdMep_t,
    DsBfdRmep_t,
    DsEthMep_t,
    DsEthRmep_t,
    /* MA */
    DsMa_t,
    /* MA Name */
    DsMaName_t,

    MaxTblId_t
};
#endif

ctc_dkits_tcam_key_inf_t acl_tcam_ipv4_key_inf[] =
{
    {DsAclQosL3Key160Ing0_t, DKITS_TCAM_ACL_KEY_L3160},
    {DsAclQosL3Key160Ing1_t, DKITS_TCAM_ACL_KEY_L3160},
    {DsAclQosL3Key160Ing2_t, DKITS_TCAM_ACL_KEY_L3160},
    {DsAclQosL3Key160Ing3_t, DKITS_TCAM_ACL_KEY_L3160},
    {DsAclQosL3Key160Ing4_t, DKITS_TCAM_ACL_KEY_L3160},
    {DsAclQosL3Key160Ing5_t, DKITS_TCAM_ACL_KEY_L3160},
    {DsAclQosL3Key160Ing6_t, DKITS_TCAM_ACL_KEY_L3160},
    {DsAclQosL3Key160Ing7_t, DKITS_TCAM_ACL_KEY_L3160},

    {DsAclQosL3Key320Ing0_t, DKITS_TCAM_ACL_KEY_L3320},
    {DsAclQosL3Key320Ing1_t, DKITS_TCAM_ACL_KEY_L3320},
    {DsAclQosL3Key320Ing2_t, DKITS_TCAM_ACL_KEY_L3320},
    {DsAclQosL3Key320Ing3_t, DKITS_TCAM_ACL_KEY_L3320},
    {DsAclQosL3Key320Ing4_t, DKITS_TCAM_ACL_KEY_L3320},
    {DsAclQosL3Key320Ing5_t, DKITS_TCAM_ACL_KEY_L3320},
    {DsAclQosL3Key320Ing6_t, DKITS_TCAM_ACL_KEY_L3320},
    {DsAclQosL3Key320Ing7_t, DKITS_TCAM_ACL_KEY_L3320},

    {DsAclQosL3Key160Egr0_t, DKITS_TCAM_ACL_KEY_L3160},
    {DsAclQosL3Key160Egr1_t, DKITS_TCAM_ACL_KEY_L3160},
    {DsAclQosL3Key160Egr2_t, DKITS_TCAM_ACL_KEY_L3160},

    {DsAclQosL3Key320Egr0_t, DKITS_TCAM_ACL_KEY_L3320},
    {DsAclQosL3Key320Egr1_t, DKITS_TCAM_ACL_KEY_L3320},
    {DsAclQosL3Key320Egr2_t, DKITS_TCAM_ACL_KEY_L3320},

    {MaxTblId_t,             DKITS_TCAM_ACL_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t acl_tcam_l2l3_key_inf[] =
{
    {DsAclQosMacL3Key320Ing0_t, DKITS_TCAM_ACL_KEY_MACL3320},
    {DsAclQosMacL3Key320Ing1_t, DKITS_TCAM_ACL_KEY_MACL3320},
    {DsAclQosMacL3Key320Ing2_t, DKITS_TCAM_ACL_KEY_MACL3320},
    {DsAclQosMacL3Key320Ing3_t, DKITS_TCAM_ACL_KEY_MACL3320},
    {DsAclQosMacL3Key320Ing4_t, DKITS_TCAM_ACL_KEY_MACL3320},
    {DsAclQosMacL3Key320Ing5_t, DKITS_TCAM_ACL_KEY_MACL3320},
    {DsAclQosMacL3Key320Ing6_t, DKITS_TCAM_ACL_KEY_MACL3320},
    {DsAclQosMacL3Key320Ing7_t, DKITS_TCAM_ACL_KEY_MACL3320},

    {DsAclQosMacL3Key640Ing0_t, DKITS_TCAM_ACL_KEY_MACL3640},
    {DsAclQosMacL3Key640Ing1_t, DKITS_TCAM_ACL_KEY_MACL3640},
    {DsAclQosMacL3Key640Ing2_t, DKITS_TCAM_ACL_KEY_MACL3640},
    {DsAclQosMacL3Key640Ing3_t, DKITS_TCAM_ACL_KEY_MACL3640},
    {DsAclQosMacL3Key640Ing4_t, DKITS_TCAM_ACL_KEY_MACL3640},
    {DsAclQosMacL3Key640Ing5_t, DKITS_TCAM_ACL_KEY_MACL3640},
    {DsAclQosMacL3Key640Ing6_t, DKITS_TCAM_ACL_KEY_MACL3640},
    {DsAclQosMacL3Key640Ing7_t, DKITS_TCAM_ACL_KEY_MACL3640},

    {DsAclQosMacIpv6Key640Ing0_t, DKITS_TCAM_ACL_KEY_MACIPV6640},
    {DsAclQosMacIpv6Key640Ing1_t, DKITS_TCAM_ACL_KEY_MACIPV6640},
    {DsAclQosMacIpv6Key640Ing2_t, DKITS_TCAM_ACL_KEY_MACIPV6640},
    {DsAclQosMacIpv6Key640Ing3_t, DKITS_TCAM_ACL_KEY_MACIPV6640},
    {DsAclQosMacIpv6Key640Ing4_t, DKITS_TCAM_ACL_KEY_MACIPV6640},
    {DsAclQosMacIpv6Key640Ing5_t, DKITS_TCAM_ACL_KEY_MACIPV6640},
    {DsAclQosMacIpv6Key640Ing6_t, DKITS_TCAM_ACL_KEY_MACIPV6640},
    {DsAclQosMacIpv6Key640Ing7_t, DKITS_TCAM_ACL_KEY_MACIPV6640},

    {DsAclQosMacL3Key320Egr0_t,   DKITS_TCAM_ACL_KEY_MACL3320},
    {DsAclQosMacL3Key320Egr1_t,   DKITS_TCAM_ACL_KEY_MACL3320},
    {DsAclQosMacL3Key320Egr2_t,   DKITS_TCAM_ACL_KEY_MACL3320},

    {DsAclQosMacL3Key640Egr0_t,   DKITS_TCAM_ACL_KEY_MACL3640},
    {DsAclQosMacL3Key640Egr1_t,   DKITS_TCAM_ACL_KEY_MACL3640},
    {DsAclQosMacL3Key640Egr2_t,   DKITS_TCAM_ACL_KEY_MACL3640},

    {DsAclQosMacIpv6Key640Egr0_t, DKITS_TCAM_ACL_KEY_MACIPV6640},
    {DsAclQosMacIpv6Key640Egr1_t, DKITS_TCAM_ACL_KEY_MACIPV6640},
    {DsAclQosMacIpv6Key640Egr2_t, DKITS_TCAM_ACL_KEY_MACIPV6640},

    {MaxTblId_t,                  DKITS_TCAM_ACL_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t acl_tcam_category_key_inf[] =
{
    {DsAclQosCidKey160Ing0_t,   DKITS_TCAM_ACL_KEY_CID160},
    {DsAclQosCidKey160Ing1_t,   DKITS_TCAM_ACL_KEY_CID160},
    {DsAclQosCidKey160Ing2_t,   DKITS_TCAM_ACL_KEY_CID160},
    {DsAclQosCidKey160Ing3_t,   DKITS_TCAM_ACL_KEY_CID160},
    {DsAclQosCidKey160Ing4_t,   DKITS_TCAM_ACL_KEY_CID160},
    {DsAclQosCidKey160Ing5_t,   DKITS_TCAM_ACL_KEY_CID160},
    {DsAclQosCidKey160Ing6_t,   DKITS_TCAM_ACL_KEY_CID160},
    {DsAclQosCidKey160Ing7_t,   DKITS_TCAM_ACL_KEY_CID160},
    {MaxTblId_t,                DKITS_TCAM_ACL_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t acl_tcam_interface_key_inf[] =
{
    {DsAclQosKey80Ing0_t, DKITS_TCAM_ACL_KEY_SHORT80},
    {DsAclQosKey80Ing1_t, DKITS_TCAM_ACL_KEY_SHORT80},
    {DsAclQosKey80Ing2_t, DKITS_TCAM_ACL_KEY_SHORT80},
    {DsAclQosKey80Ing3_t, DKITS_TCAM_ACL_KEY_SHORT80},
    {DsAclQosKey80Ing4_t, DKITS_TCAM_ACL_KEY_SHORT80},
    {DsAclQosKey80Ing5_t, DKITS_TCAM_ACL_KEY_SHORT80},
    {DsAclQosKey80Ing6_t, DKITS_TCAM_ACL_KEY_SHORT80},
    {DsAclQosKey80Ing7_t, DKITS_TCAM_ACL_KEY_SHORT80},

    {DsAclQosKey80Egr0_t, DKITS_TCAM_ACL_KEY_SHORT80},
    {DsAclQosKey80Egr1_t, DKITS_TCAM_ACL_KEY_SHORT80},
    {DsAclQosKey80Egr2_t, DKITS_TCAM_ACL_KEY_SHORT80},

    {MaxTblId_t,          DKITS_TCAM_ACL_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t acl_tcam_fwd_key_inf[] =
{
    {DsAclQosForwardKey320Ing0_t, DKITS_TCAM_ACL_KEY_FORWARD320},
    {DsAclQosForwardKey320Ing1_t, DKITS_TCAM_ACL_KEY_FORWARD320},
    {DsAclQosForwardKey320Ing2_t, DKITS_TCAM_ACL_KEY_FORWARD320},
    {DsAclQosForwardKey320Ing3_t, DKITS_TCAM_ACL_KEY_FORWARD320},
    {DsAclQosForwardKey320Ing4_t, DKITS_TCAM_ACL_KEY_FORWARD320},
    {DsAclQosForwardKey320Ing5_t, DKITS_TCAM_ACL_KEY_FORWARD320},
    {DsAclQosForwardKey320Ing6_t, DKITS_TCAM_ACL_KEY_FORWARD320},
    {DsAclQosForwardKey320Ing7_t, DKITS_TCAM_ACL_KEY_FORWARD320},

    {DsAclQosForwardKey640Ing0_t, DKITS_TCAM_ACL_KEY_FORWARD640},
    {DsAclQosForwardKey640Ing1_t, DKITS_TCAM_ACL_KEY_FORWARD640},
    {DsAclQosForwardKey640Ing2_t, DKITS_TCAM_ACL_KEY_FORWARD640},
    {DsAclQosForwardKey640Ing3_t, DKITS_TCAM_ACL_KEY_FORWARD640},
    {DsAclQosForwardKey640Ing4_t, DKITS_TCAM_ACL_KEY_FORWARD640},
    {DsAclQosForwardKey640Ing5_t, DKITS_TCAM_ACL_KEY_FORWARD640},
    {DsAclQosForwardKey640Ing6_t, DKITS_TCAM_ACL_KEY_FORWARD640},
    {DsAclQosForwardKey640Ing7_t, DKITS_TCAM_ACL_KEY_FORWARD640},

    {MaxTblId_t,                  DKITS_TCAM_ACL_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t acl_tcam_ipv6_key_inf[] =
{
    {DsAclQosIpv6Key320Ing0_t, DKITS_TCAM_ACL_KEY_IPV6320},
    {DsAclQosIpv6Key320Ing1_t, DKITS_TCAM_ACL_KEY_IPV6320},
    {DsAclQosIpv6Key320Ing2_t, DKITS_TCAM_ACL_KEY_IPV6320},
    {DsAclQosIpv6Key320Ing3_t, DKITS_TCAM_ACL_KEY_IPV6320},
    {DsAclQosIpv6Key320Ing4_t, DKITS_TCAM_ACL_KEY_IPV6320},
    {DsAclQosIpv6Key320Ing5_t, DKITS_TCAM_ACL_KEY_IPV6320},
    {DsAclQosIpv6Key320Ing6_t, DKITS_TCAM_ACL_KEY_IPV6320},
    {DsAclQosIpv6Key320Ing7_t, DKITS_TCAM_ACL_KEY_IPV6320},

    {DsAclQosIpv6Key640Ing0_t, DKITS_TCAM_ACL_KEY_IPV6640},
    {DsAclQosIpv6Key640Ing1_t, DKITS_TCAM_ACL_KEY_IPV6640},
    {DsAclQosIpv6Key640Ing2_t, DKITS_TCAM_ACL_KEY_IPV6640},
    {DsAclQosIpv6Key640Ing3_t, DKITS_TCAM_ACL_KEY_IPV6640},
    {DsAclQosIpv6Key640Ing4_t, DKITS_TCAM_ACL_KEY_IPV6640},
    {DsAclQosIpv6Key640Ing5_t, DKITS_TCAM_ACL_KEY_IPV6640},
    {DsAclQosIpv6Key640Ing6_t, DKITS_TCAM_ACL_KEY_IPV6640},
    {DsAclQosIpv6Key640Ing7_t, DKITS_TCAM_ACL_KEY_IPV6640},

    {DsAclQosIpv6Key320Egr0_t, DKITS_TCAM_ACL_KEY_IPV6320},
    {DsAclQosIpv6Key320Egr1_t, DKITS_TCAM_ACL_KEY_IPV6320},
    {DsAclQosIpv6Key320Egr2_t, DKITS_TCAM_ACL_KEY_IPV6320},

    {DsAclQosIpv6Key640Egr0_t, DKITS_TCAM_ACL_KEY_IPV6640},
    {DsAclQosIpv6Key640Egr1_t, DKITS_TCAM_ACL_KEY_IPV6640},
    {DsAclQosIpv6Key640Egr2_t, DKITS_TCAM_ACL_KEY_IPV6640},

    {MaxTblId_t,               DKITS_TCAM_ACL_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t acl_tcam_bridge_key_inf[] =
{
    {DsAclQosMacKey160Ing0_t,  DKITS_TCAM_ACL_KEY_MAC160},
    {DsAclQosMacKey160Ing1_t,  DKITS_TCAM_ACL_KEY_MAC160},
    {DsAclQosMacKey160Ing2_t,  DKITS_TCAM_ACL_KEY_MAC160},
    {DsAclQosMacKey160Ing3_t,  DKITS_TCAM_ACL_KEY_MAC160},
    {DsAclQosMacKey160Ing4_t,  DKITS_TCAM_ACL_KEY_MAC160},
    {DsAclQosMacKey160Ing5_t,  DKITS_TCAM_ACL_KEY_MAC160},
    {DsAclQosMacKey160Ing6_t,  DKITS_TCAM_ACL_KEY_MAC160},
    {DsAclQosMacKey160Ing7_t,  DKITS_TCAM_ACL_KEY_MAC160},

    {DsAclQosMacKey160Egr0_t,  DKITS_TCAM_ACL_KEY_MAC160},
    {DsAclQosMacKey160Egr1_t,  DKITS_TCAM_ACL_KEY_MAC160},
    {DsAclQosMacKey160Egr2_t,  DKITS_TCAM_ACL_KEY_MAC160},

    {MaxTblId_t,               DKITS_TCAM_ACL_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t scl_tcam_ipv4_key_inf[] =
{
    {DsScl0L3Key160_t,      DKITS_TCAM_SCL_KEY_L3},
    {DsScl1L3Key160_t,      DKITS_TCAM_SCL_KEY_L3},
    {MaxTblId_t,            DKITS_TCAM_SCL_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t scl_tcam_l2l3_key_inf[] =
{
    {DsScl0MacL3Key320_t,   DKITS_TCAM_SCL_KEY_L2L3},
    {DsScl1MacL3Key320_t,   DKITS_TCAM_SCL_KEY_L2L3},
    {DsScl0MacIpv6Key640_t, DKITS_TCAM_SCL_KEY_L2L3},
    {DsScl1MacIpv6Key640_t, DKITS_TCAM_SCL_KEY_L2L3},
    {MaxTblId_t,            DKITS_TCAM_SCL_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t scl_tcam_ipv6_key_inf[] =
{
    {DsScl0Ipv6Key320_t,    DKITS_TCAM_SCL_KEY_L3},
    {DsScl1Ipv6Key320_t,    DKITS_TCAM_SCL_KEY_L3},
    {MaxTblId_t,            DKITS_TCAM_SCL_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t scl_tcam_bridge_key_inf[] =
{
    {DsScl0MacKey160_t,     DKITS_TCAM_SCL_KEY_L2},
    {DsScl1MacKey160_t,     DKITS_TCAM_SCL_KEY_L2},
    {MaxTblId_t,            DKITS_TCAM_SCL_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t scl_tcam_userid_key_inf[] =
{
    {DsUserId0TcamKey80_t,  DKITS_TCAM_SCL_KEY_USERID},
    {DsUserId1TcamKey80_t,  DKITS_TCAM_SCL_KEY_USERID},
    {DsUserId0TcamKey160_t, DKITS_TCAM_SCL_KEY_USERID},
    {DsUserId1TcamKey160_t, DKITS_TCAM_SCL_KEY_USERID},
    {DsUserId0TcamKey320_t, DKITS_TCAM_SCL_KEY_USERID},
    {DsUserId1TcamKey320_t, DKITS_TCAM_SCL_KEY_USERID},
    {MaxTblId_t,            DKITS_TCAM_SCL_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t ip_tcam_prefix_key_inf[] =
{
    {DsLpmTcamIpv4HalfKeyLookup1_t,         DKITS_TCAM_IP_KEY_IPV4UC},
    {DsLpmTcamIpv6DoubleKey0Lookup1_t,      DKITS_TCAM_IP_KEY_IPV6UC},
    {DsLpmTcamIpv4SaHalfKeyLookup1_t,       DKITS_TCAM_IP_KEY_IPV4UC},
    {DsLpmTcamIpv6SaDoubleKey0Lookup1_t,    DKITS_TCAM_IP_KEY_IPV6UC},
    {DsLpmTcamIpv4DaPubHalfKeyLookup1_t,    DKITS_TCAM_IP_KEY_IPV4UC},
    {DsLpmTcamIpv6DaPubDoubleKey0Lookup1_t, DKITS_TCAM_IP_KEY_IPV6UC},
    {DsLpmTcamIpv4SaPubHalfKeyLookup1_t,    DKITS_TCAM_IP_KEY_IPV4UC},
    {DsLpmTcamIpv6SaPubDoubleKey0Lookup1_t, DKITS_TCAM_IP_KEY_IPV6UC},
    {DsLpmTcamIpv6SingleKey_t,              DKITS_TCAM_IP_KEY_IPV6UC},
    {DsLpmTcamIpv6SaSingleKey_t,            DKITS_TCAM_IP_KEY_IPV6UC},
    {DsLpmTcamIpv6DaPubSingleKey_t,         DKITS_TCAM_IP_KEY_IPV6UC},
    {DsLpmTcamIpv6SaPubSingleKey_t,         DKITS_TCAM_IP_KEY_IPV6UC},

    {DsLpmTcamIpv4HalfKeyLookup2_t,         DKITS_TCAM_IP_KEY_IPV4UC},
    {DsLpmTcamIpv6DoubleKey0Lookup2_t,      DKITS_TCAM_IP_KEY_IPV6UC},
    {DsLpmTcamIpv4SaHalfKeyLookup2_t,       DKITS_TCAM_IP_KEY_IPV4UC},
    {DsLpmTcamIpv6SaDoubleKey0Lookup2_t,    DKITS_TCAM_IP_KEY_IPV6UC},
    {DsLpmTcamIpv4DaPubHalfKeyLookup2_t,    DKITS_TCAM_IP_KEY_IPV4UC},
    {DsLpmTcamIpv6DaPubDoubleKey0Lookup2_t, DKITS_TCAM_IP_KEY_IPV6UC},
    {DsLpmTcamIpv4SaPubHalfKeyLookup2_t,    DKITS_TCAM_IP_KEY_IPV4UC},
    {DsLpmTcamIpv6SaPubDoubleKey0Lookup2_t, DKITS_TCAM_IP_KEY_IPV6UC},
    {MaxTblId_t,                            DKITS_TCAM_IP_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t ip_tcam_pbr_ipv4_key_inf[] =
{
    {DsLpmTcamIpv4PbrDoubleKey_t, DKITS_TCAM_NATPBR_KEY_IPV4PBR},
    {MaxTblId_t,                  DKITS_TCAM_NATPBR_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t ip_tcam_pbr_ipv6_key_inf[] =
{
    {DsLpmTcamIpv6QuadKey_t,      DKITS_TCAM_NATPBR_KEY_IPV6PBR},
    {MaxTblId_t,                  DKITS_TCAM_NATPBR_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t ip_tcam_nat_ipv4_key_inf[] =
{
    {DsLpmTcamIpv4NatDoubleKey_t, DKITS_TCAM_NATPBR_KEY_IPV4NAT},
    {MaxTblId_t,                  DKITS_TCAM_NATPBR_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t ip_tcam_nat_ipv6_key_inf[] =
{
    {DsLpmTcamIpv6DoubleKey1_t,   DKITS_TCAM_NATPBR_KEY_IPV6NAT},
    {MaxTblId_t,                  DKITS_TCAM_NATPBR_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t static_cid_tcam_key_inf[] =
{
    {DsCategoryIdPairTcamKey_t,   0},
    {MaxTblId_t,                  DKITS_TCAM_NATPBR_KEY_NUM}
};

ctc_dkits_tcam_key_inf_t static_qmgr_tcam_key_inf[] =
{
    {DsQueueMapTcamKey_t,         0},
    {MaxTblId_t,                  DKITS_TCAM_NATPBR_KEY_NUM}
};

tbls_id_t nh_fwd_tbl[] =
{
    DsFwd_t,
    DsFwdDualHalf_t,
    DsFwdHalf_t,
    MaxTblId_t
};

tbls_id_t nh_met_tbl[] =
{
    DsMetEntry3W_t,
    DsMetEntry6W_t,
    MaxTblId_t
};

tbls_id_t nh_nexthop_tbl[] =
{
    DsNextHop4W_t,
    DsNextHop8W_t,
    MaxTblId_t
};

tbls_id_t nh_edit_tbl[] =
{
    DsL23Edit3W_t,
    DsL23Edit12W_t,
    DsL23Edit6W_t,
    DsL2EditEth3W_t,
    DsL2EditEth6W_t,
    DsL2EditInnerSwap_t,
    DsL2EditFlex_t,
    DsL2EditLoopback_t,
    DsL2EditPbb4W_t,
    DsL2EditPbb8W_t,
    DsL2EditSwap_t,
    DsL2EditOf_t,
    DsL3EditFlex_t,
    DsL3EditLoopback_t,
    DsL3EditMpls3W_t,
    DsL3EditNat3W_t,
    DsL3EditNat6W_t,
    DsL3EditOf6W_t,
    DsL3EditOf12W_t,
    DsL3EditOf12WIpv6Only_t,
    DsL3EditOf12WArpData_t,
    DsL3EditOf12WIpv6L4_t,
    DsL3EditTrill_t,
    DsL3EditTunnelV4_t,
    DsL3EditTunnelV6_t,
    DsL3Edit12W1st_t,
    DsL3Edit12W2nd_t,
    DsL2Edit12WInner_t,
    DsL2Edit12WShare_t,
    DsL2Edit6WShare_t,
    DsL2EditDsLite_t,
    TempInnerEdit12W_t,
    TempOuterEdit12W_t,
    MaxTblId_t
};

#if 0
tbls_id_t lpm_lookup_key_tbl[] =
{
    MaxTblId_t
};

tbls_id_t alias_tbl[] =
{
    MaxTblId_t
};

tbls_id_t stats_tbl[] =
{
    MaxTblId_t
};

tbls_id_t exclude_tbl[] =
{
    MaxTblId_t
};

tbls_id_t serdes_tbl[] =
{
    MaxTblId_t
};
#endif


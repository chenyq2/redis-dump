#include "drv_api.h"
#include "ctc_cli.h"
#include "ctc_dkit.h"
#include "ctc_goldengate_dkit.h"
#include "ctc_goldengate_dkit_discard.h"
#include "ctc_goldengate_dkit_discard_type.h"

#if 0
#include "ctc_goldengate_dkit_bus_info.h"
#include "ctc_goldengate_dkit_captured_info.h"
#endif


#define ADD_DISCARD_REASON(p_discard_info,id,discard_module,port_num,slice_id)    \
            if (p_discard_info->discard_count < CTC_DKIT_DISCARD_REASON_NUM)\
            {\
                p_discard_info->discard_reason[p_discard_info->discard_count].reason_id = id;\
                p_discard_info->discard_reason[p_discard_info->discard_count].module = discard_module;\
                p_discard_info->discard_reason[p_discard_info->discard_count].port = port_num;\
                p_discard_info->slice_ipe = slice_id;\
                p_discard_info->slice_epe = slice_id;\
                p_discard_info->discard_count++;\
            }\

extern ctc_dkit_master_t* g_dkit_master[CTC_DKITS_MAX_LOCAL_CHIP_NUM];


uint32
ctc_goldengate_dkit_get_channel_by_gport(uint8 lchip, uint16 gport)
{
    uint32 lport = 0;
    uint8 local_phy_port = 0;
    uint32 channel = 0xFFFFFFFF;
    uint8 slice = 0;
    uint8 i = 0;
    uint32 cmd = 0;
    uint32 value = 0;

    lport = CTC_DKIT_CTC_GPORT_TO_DRV_LPORT(gport);
    local_phy_port = lport % CTC_DKIT_ONE_SLICE_PORT_NUM;
    slice = (lport >= CTC_DKIT_ONE_SLICE_PORT_NUM)? 1 : 0;

    for (i = (CTC_DKIT_ONE_SLICE_CHANNEL_NUM *slice); i < (CTC_DKIT_ONE_SLICE_CHANNEL_NUM + CTC_DKIT_ONE_SLICE_CHANNEL_NUM *slice); i++)
    {
        cmd = DRV_IOR(IpeHeaderAdjustPhyPortMap_t, IpeHeaderAdjustPhyPortMap_localPhyPort_f);
        DRV_IOCTL(lchip, i, cmd, &value);
        if (value == local_phy_port)
        {
            channel = i;
            break;
        }
    }

    return channel;
}

const char *ctc_goldengate_dkit_get_reason_desc(ctc_dkit_discard_reason_id_t reason_id)
{
    static char  reason_desc[256+1] = {0};

    if (reason_id == CTC_DKIT_DISCARD_INVALIED)
    {
        return " ";
    }

    switch(reason_id)
    {


    case CTC_DKIT_DISCARD_IPE_RESERVED0:
        return "CTC_DKIT_DISCARD_IPE_RESERVED0";
    case CTC_DKIT_DISCARD_IPE_LPBK_HDR_ADJ_RM_ERR:
        return "CTC_DKIT_DISCARD_IPE_LPBK_HDR_ADJ_RM_ERR";
    case CTC_DKIT_DISCARD_IPE_PARSER_LEN_ERR:
        return "CTC_DKIT_DISCARD_IPE_PARSER_LEN_ERR";
    case CTC_DKIT_DISCARD_IPE_UC_TO_LAG_GROUP_NO_MEMBER:
        return "CTC_DKIT_DISCARD_IPE_UC_TO_LAG_GROUP_NO_MEMBER";
    case CTC_DKIT_DISCARD_IPE_EXCEP2_DIS:
        return "CTC_DKIT_DISCARD_IPE_EXCEP2_DIS";
    case CTC_DKIT_DISCARD_IPE_DS_USERID_DIS:
        return "CTC_DKIT_DISCARD_IPE_DS_USERID_DIS";
    case CTC_DKIT_DISCARD_IPE_RECEIVE_DIS:
        return "CTC_DKIT_DISCARD_IPE_RECEIVE_DIS";
    case CTC_DKIT_DISCARD_IPE_MICROFLOW_POLICING_FAIL_DROP:
        return "CTC_DKIT_DISCARD_IPE_MICROFLOW_POLICING_FAIL_DROP";
    case CTC_DKIT_DISCARD_IPE_PROTOCOL_VLAN_DIS:
        return "CTC_DKIT_DISCARD_IPE_PROTOCOL_VLAN_DIS";
    case CTC_DKIT_DISCARD_IPE_AFT_DIS:
        return "CTC_DKIT_DISCARD_IPE_AFT_DIS";
    case CTC_DKIT_DISCARD_IPE_L2_ILLEGAL_PKT_DIS:
        return "CTC_DKIT_DISCARD_IPE_L2_ILLEGAL_PKT_DIS";
    case CTC_DKIT_DISCARD_IPE_STP_DIS:
        return "CTC_DKIT_DISCARD_IPE_STP_DIS";
    case CTC_DKIT_DISCARD_IPE_DEST_MAP_PROFILE_DISCARD:
        return "CTC_DKIT_DISCARD_IPE_DEST_MAP_PROFILE_DISCARD";
    case CTC_DKIT_DISCARD_IPE_STACK_REFLECT_DISCARD:
        return "CTC_DKIT_DISCARD_IPE_STACK_REFLECT_DISCARD";
    case CTC_DKIT_DISCARD_IPE_ARP_DHCP_DIS:
        return "CTC_DKIT_DISCARD_IPE_ARP_DHCP_DIS";
    case CTC_DKIT_DISCARD_IPE_DS_PHYPORT_SRCDIS:
        return "CTC_DKIT_DISCARD_IPE_DS_PHYPORT_SRCDIS";
    case CTC_DKIT_DISCARD_IPE_VLAN_FILTER_DIS:
        return "CTC_DKIT_DISCARD_IPE_VLAN_FILTER_DIS";
    case CTC_DKIT_DISCARD_IPE_DS_ACL_DIS:
        return "CTC_DKIT_DISCARD_IPE_DS_ACL_DIS";
    case CTC_DKIT_DISCARD_IPE_ROUTE_ERROR_PKT_DIS:
        return "CTC_DKIT_DISCARD_IPE_ROUTE_ERROR_PKT_DIS";
    case CTC_DKIT_DISCARD_IPE_SECURITY_CHK_DIS:
        return "CTC_DKIT_DISCARD_IPE_SECURITY_CHK_DIS";
    case CTC_DKIT_DISCARD_IPE_STORM_CTL_DIS:
        return "CTC_DKIT_DISCARD_IPE_STORM_CTL_DIS";
    case CTC_DKIT_DISCARD_IPE_LEARNING_DIS:
        return "CTC_DKIT_DISCARD_IPE_LEARNING_DIS";
    case CTC_DKIT_DISCARD_IPE_NO_FORWARDING_PTR:
        return "CTC_DKIT_DISCARD_IPE_NO_FORWARDING_PTR";
    case CTC_DKIT_DISCARD_IPE_IS_DIS_FORWARDING_PTR:
        return "CTC_DKIT_DISCARD_IPE_IS_DIS_FORWARDING_PTR";
    case CTC_DKIT_DISCARD_IPE_FATAL_EXCEP_DIS:
        return "CTC_DKIT_DISCARD_IPE_FATAL_EXCEP_DIS";
    case CTC_DKIT_DISCARD_IPE_APS_DIS:
        return "CTC_DKIT_DISCARD_IPE_APS_DIS";
    case CTC_DKIT_DISCARD_IPE_DS_FWD_DESTID_DIS:
        return "CTC_DKIT_DISCARD_IPE_DS_FWD_DESTID_DIS";
    case CTC_DKIT_DISCARD_IPE_LOOPBACK_DIS:
        return "CTC_DKIT_DISCARD_IPE_LOOPBACK_DIS";
    case CTC_DKIT_DISCARD_IPE_DISCARD_PACKET_LOG_ALL_TYPE:
        return "CTC_DKIT_DISCARD_IPE_DISCARD_PACKET_LOG_ALL_TYPE";
    case CTC_DKIT_DISCARD_IPE_PORT_MAC_CHECK_DIS:
        return "CTC_DKIT_DISCARD_IPE_PORT_MAC_CHECK_DIS";
    case CTC_DKIT_DISCARD_IPE_L3_EXCEP_DIS:
        return "CTC_DKIT_DISCARD_IPE_L3_EXCEP_DIS";
    case CTC_DKIT_DISCARD_IPE_STACKING_HDR_CHK_ERR:
        return "CTC_DKIT_DISCARD_IPE_STACKING_HDR_CHK_ERR";
    case CTC_DKIT_DISCARD_IPE_TUNNEL_DECAP_MARTIAN_ADD:
        return "CTC_DKIT_DISCARD_IPE_TUNNEL_DECAP_MARTIAN_ADD";
    case CTC_DKIT_DISCARD_IPE_TUNNELID_FWD_PTR_DIS:
        return "CTC_DKIT_DISCARD_IPE_TUNNELID_FWD_PTR_DIS";
    case CTC_DKIT_DISCARD_IPE_VXLAN_FLAG_CHK_ERROR_DISCARD:
        return "CTC_DKIT_DISCARD_IPE_VXLAN_FLAG_CHK_ERROR_DISCARD";
    case CTC_DKIT_DISCARD_IPE_VXLAN_NVGRE_INNER_VTAG_CHK_DIS:
        return "CTC_DKIT_DISCARD_IPE_VXLAN_NVGRE_INNER_VTAG_CHK_DIS";
    case CTC_DKIT_DISCARD_IPE_VXLAN_NVGRE_CHK_FAIL:
        return "CTC_DKIT_DISCARD_IPE_VXLAN_NVGRE_CHK_FAIL";
    case CTC_DKIT_DISCARD_IPE_GENEVE_PAKCET_DISCARD:
        return "CTC_DKIT_DISCARD_IPE_GENEVE_PAKCET_DISCARD";
    case CTC_DKIT_DISCARD_IPE_ICMP_REDIRECT_DIS:
        return "CTC_DKIT_DISCARD_IPE_ICMP_REDIRECT_DIS";
    case CTC_DKIT_DISCARD_IPE_ICMP_ERR_MSG_DIS:
        return "CTC_DKIT_DISCARD_IPE_ICMP_ERR_MSG_DIS";
    case CTC_DKIT_DISCARD_IPE_PTP_PKT_DIS:
        return "CTC_DKIT_DISCARD_IPE_PTP_PKT_DIS";
    case CTC_DKIT_DISCARD_IPE_MUX_PORT_ERR:
        return "CTC_DKIT_DISCARD_IPE_MUX_PORT_ERR";
    case CTC_DKIT_DISCARD_IPE_HW_ERROR_DISCARD:
        return "CTC_DKIT_DISCARD_IPE_HW_ERROR_DISCARD";
    case CTC_DKIT_DISCARD_IPE_USERID_BINDING_DIS:
        return "CTC_DKIT_DISCARD_IPE_USERID_BINDING_DIS";
    case CTC_DKIT_DISCARD_IPE_RESERVED1:
        return "CTC_DKIT_DISCARD_IPE_RESERVED1";
    case CTC_DKIT_DISCARD_IPE_RESERVED2:
        return "CTC_DKIT_DISCARD_IPE_RESERVED2";
    case CTC_DKIT_DISCARD_IPE_DOT1AE_CHK:
        return "CTC_DKIT_DISCARD_IPE_DOT1AE_CHK";
    case CTC_DKIT_DISCARD_IPE_OAM_DISABLE:
        return "CTC_DKIT_DISCARD_IPE_OAM_DISABLE";
    case CTC_DKIT_DISCARD_IPE_OAM_NOT_FOUND:
        return "CTC_DKIT_DISCARD_IPE_OAM_NOT_FOUND";
    case CTC_DKIT_DISCARD_IPE_OAM_NO_MEP_MIP:
        return "CTC_DKIT_DISCARD_IPE_OAM_NO_MEP_MIP";
    case CTC_DKIT_DISCARD_IPE_OAM_ETH_VLAN_CHK:
        return "CTC_DKIT_DISCARD_IPE_OAM_ETH_VLAN_CHK";
    case CTC_DKIT_DISCARD_IPE_OAM_BFD_TTL_CHK:
        return "CTC_DKIT_DISCARD_IPE_OAM_BFD_TTL_CHK";
    case CTC_DKIT_DISCARD_IPE_OAM_FILTER_DIS:
        return "CTC_DKIT_DISCARD_IPE_OAM_FILTER_DIS";
    case CTC_DKIT_DISCARD_IPE_TRILL_CHK:
        return "CTC_DKIT_DISCARD_IPE_TRILL_CHK";
    case CTC_DKIT_DISCARD_IPE_CAPWAP_CHK:
        return "CTC_DKIT_DISCARD_IPE_CAPWAP_CHK";
    case CTC_DKIT_DISCARD_IPE_TUNNEL_ECN_DIS:
        return "CTC_DKIT_DISCARD_IPE_TUNNEL_ECN_DIS";
    case CTC_DKIT_DISCARD_IPE_EFM_DIS:
        return "CTC_DKIT_DISCARD_IPE_EFM_DIS";
    case CTC_DKIT_DISCARD_IPE_BUF_RETRV_DIS:
        return "CTC_DKIT_DISCARD_IPE_BUF_RETRV_DIS";
    case CTC_DKIT_DISCARD_IPE_MPLS_ENTROPY_LABEL_CHK:
        return "CTC_DKIT_DISCARD_IPE_MPLS_ENTROPY_LABEL_CHK";
    case CTC_DKIT_DISCARD_IPE_MPLS_TP_MCC_SCC_DIS:
        return "CTC_DKIT_DISCARD_IPE_MPLS_TP_MCC_SCC_DIS";
    case CTC_DKIT_DISCARD_IPE_MPLS_MC_PKT_ERROR:
        return "CTC_DKIT_DISCARD_IPE_MPLS_MC_PKT_ERROR";
    case CTC_DKIT_DISCARD_IPE_L2_EXCPTION_DIS:
        return "CTC_DKIT_DISCARD_IPE_L2_EXCPTION_DIS";
    case CTC_DKIT_DISCARD_IPE_NAT_PT_CHK:
        return "CTC_DKIT_DISCARD_IPE_NAT_PT_CHK";
    case CTC_DKIT_DISCARD_IPE_RESERVED3:
        return "CTC_DKIT_DISCARD_IPE_RESERVED3";

    case CTC_DKIT_DISCARD_EPE_HDR_ADJ_DESTID_DIS:
        return "CTC_DKIT_DISCARD_EPE_HDR_ADJ_DESTID_DIS";
    case CTC_DKIT_DISCARD_EPE_HDR_ADJ_PKT_ERR:
        return "CTC_DKIT_DISCARD_EPE_HDR_ADJ_PKT_ERR";
    case CTC_DKIT_DISCARD_EPE_HDR_ADJ_REMOVE_ERR:
        return "CTC_DKIT_DISCARD_EPE_HDR_ADJ_REMOVE_ERR";
    case CTC_DKIT_DISCARD_EPE_DS_DESTPHYPORT_DSTID_DIS:
        return "CTC_DKIT_DISCARD_EPE_DS_DESTPHYPORT_DSTID_DIS";
    case CTC_DKIT_DISCARD_EPE_PORT_ISO_DIS:
        return "CTC_DKIT_DISCARD_EPE_PORT_ISO_DIS";
    case CTC_DKIT_DISCARD_EPE_DS_VLAN_TRANSMIT_DIS:
        return "CTC_DKIT_DISCARD_EPE_DS_VLAN_TRANSMIT_DIS";
    case CTC_DKIT_DISCARD_EPE_BRG_TO_SAME_PORT_DIS:
        return "CTC_DKIT_DISCARD_EPE_BRG_TO_SAME_PORT_DIS";
    case CTC_DKIT_DISCARD_EPE_VPLS_HORIZON_SPLIT_DIS:
        return "CTC_DKIT_DISCARD_EPE_VPLS_HORIZON_SPLIT_DIS";
    case CTC_DKIT_DISCARD_EPE_VLAN_FILTER_DIS:
        return "CTC_DKIT_DISCARD_EPE_VLAN_FILTER_DIS";
    case CTC_DKIT_DISCARD_EPE_STP_DIS:
        return "CTC_DKIT_DISCARD_EPE_STP_DIS";
    case CTC_DKIT_DISCARD_EPE_PARSER_LEN_ERR:
        return "CTC_DKIT_DISCARD_EPE_PARSER_LEN_ERR";
    case CTC_DKIT_DISCARD_EPE_PBB_CHK_DIS:
        return "CTC_DKIT_DISCARD_EPE_PBB_CHK_DIS";
    case CTC_DKIT_DISCARD_EPE_UC_MC_FLOODING_DIS:
        return "CTC_DKIT_DISCARD_EPE_UC_MC_FLOODING_DIS";
    case CTC_DKIT_DISCARD_EPE_OAM_802_3_DIS:
        return "CTC_DKIT_DISCARD_EPE_OAM_802_3_DIS";
    case CTC_DKIT_DISCARD_EPE_TTL_FAIL:
        return "CTC_DKIT_DISCARD_EPE_TTL_FAIL";
    case CTC_DKIT_DISCARD_EPE_REMOTE_MIRROR_ESCAP_DIS:
        return "CTC_DKIT_DISCARD_EPE_REMOTE_MIRROR_ESCAP_DIS";
    case CTC_DKIT_DISCARD_EPE_TUNNEL_MTU_CHK_DIS:
        return "CTC_DKIT_DISCARD_EPE_TUNNEL_MTU_CHK_DIS";
    case CTC_DKIT_DISCARD_EPE_INTERF_MTU_CHK_DIS:
        return "CTC_DKIT_DISCARD_EPE_INTERF_MTU_CHK_DIS";
    case CTC_DKIT_DISCARD_EPE_LOGIC_PORT_CHK_DIS:
        return "CTC_DKIT_DISCARD_EPE_LOGIC_PORT_CHK_DIS";
    case CTC_DKIT_DISCARD_EPE_DS_ACL_DIS:
        return "CTC_DKIT_DISCARD_EPE_DS_ACL_DIS";
    case CTC_DKIT_DISCARD_EPE_DS_VLAN_XLATE_DIS:
        return "CTC_DKIT_DISCARD_EPE_DS_VLAN_XLATE_DIS";
    case CTC_DKIT_DISCARD_EPE_CRC_ERR_DIS:
        return "CTC_DKIT_DISCARD_EPE_CRC_ERR_DIS";
    case CTC_DKIT_DISCARD_EPE_ROUTE_PLD_OP_DIS:
        return "CTC_DKIT_DISCARD_EPE_ROUTE_PLD_OP_DIS";
    case CTC_DKIT_DISCARD_EPE_BRIDGE_PLD_OP_DIS:
        return "CTC_DKIT_DISCARD_EPE_BRIDGE_PLD_OP_DIS";
    case CTC_DKIT_DISCARD_EPE_STRIP_OFFSET_LARGE:
        return "CTC_DKIT_DISCARD_EPE_STRIP_OFFSET_LARGE";
    case CTC_DKIT_DISCARD_EPE_BFD_DIS:
        return "CTC_DKIT_DISCARD_EPE_BFD_DIS";
    case CTC_DKIT_DISCARD_EPE_PORT_REFLECTIVE_CHK_DIS:
        return "CTC_DKIT_DISCARD_EPE_PORT_REFLECTIVE_CHK_DIS";
    case CTC_DKIT_DISCARD_EPE_IP_MPLS_TTL_CHK_ERR:
        return "CTC_DKIT_DISCARD_EPE_IP_MPLS_TTL_CHK_ERR";
    case CTC_DKIT_DISCARD_EPE_OAM_EDGE_PORT_DIS:
        return "CTC_DKIT_DISCARD_EPE_OAM_EDGE_PORT_DIS";
    case CTC_DKIT_DISCARD_EPE_NAT_PT_ICMP_ERR:
        return "CTC_DKIT_DISCARD_EPE_NAT_PT_ICMP_ERR";
    case CTC_DKIT_DISCARD_EPE_LATENCY_DISCARD:
        return "CTC_DKIT_DISCARD_EPE_LATENCY_DISCARD";
    case CTC_DKIT_DISCARD_EPE_LOCAL_OAM_DIS:
        return "CTC_DKIT_DISCARD_EPE_LOCAL_OAM_DIS";
    case CTC_DKIT_DISCARD_EPE_OAM_FILTERING_DIS:
        return "CTC_DKIT_DISCARD_EPE_OAM_FILTERING_DIS";
    case CTC_DKIT_DISCARD_EPE_SAME_IPDA_IPSA_DIS:
        return "CTC_DKIT_DISCARD_EPE_SAME_IPDA_IPSA_DIS";
    case CTC_DKIT_DISCARD_EPE_RESERVED2:
        return "CTC_DKIT_DISCARD_EPE_RESERVED2";
    case CTC_DKIT_DISCARD_EPE_TRILL_PLD_OP_DIS:
        return "CTC_DKIT_DISCARD_EPE_TRILL_PLD_OP_DIS";
    case CTC_DKIT_DISCARD_EPE_PBB_CHK_FAIL_DIS:
        return "CTC_DKIT_DISCARD_EPE_PBB_CHK_FAIL_DIS";
    case CTC_DKIT_DISCARD_EPE_DS_NEXTHOP_DATA_VIOLATE:
        return "CTC_DKIT_DISCARD_EPE_DS_NEXTHOP_DATA_VIOLATE";
    case CTC_DKIT_DISCARD_EPE_DEST_VLAN_PTR_DIS:
        return "CTC_DKIT_DISCARD_EPE_DEST_VLAN_PTR_DIS";
    case CTC_DKIT_DISCARD_EPE_DS_L3EDIT_DATA_VIOLATE1:
        return "CTC_DKIT_DISCARD_EPE_DS_L3EDIT_DATA_VIOLATE1";
    case CTC_DKIT_DISCARD_EPE_DS_L3EDIT_DATA_VIOLATE2:
        return "CTC_DKIT_DISCARD_EPE_DS_L3EDIT_DATA_VIOLATE2";
    case CTC_DKIT_DISCARD_EPE_DS_L3EDITNAT_DATA_VIOLATE:
        return "CTC_DKIT_DISCARD_EPE_DS_L3EDITNAT_DATA_VIOLATE";
    case CTC_DKIT_DISCARD_EPE_DS_L2EDIT_DATA_VIOLATE1:
        return "CTC_DKIT_DISCARD_EPE_DS_L2EDIT_DATA_VIOLATE1";
    case CTC_DKIT_DISCARD_EPE_DS_L2EDIT_DATA_VIOLATE2:
        return "CTC_DKIT_DISCARD_EPE_DS_L2EDIT_DATA_VIOLATE2";
    case CTC_DKIT_DISCARD_EPE_PKT_HDR_C2C_TTL_ZERO:
        return "CTC_DKIT_DISCARD_EPE_PKT_HDR_C2C_TTL_ZERO";
    case CTC_DKIT_DISCARD_EPE_PT_UDP_CHKSUM_ZERO:
        return "CTC_DKIT_DISCARD_EPE_PT_UDP_CHKSUM_ZERO";
    case CTC_DKIT_DISCARD_EPE_OAM_TO_LOCAL_DIS:
        return "CTC_DKIT_DISCARD_EPE_OAM_TO_LOCAL_DIS";
    case CTC_DKIT_DISCARD_EPE_HARD_ERROR_DIS:
        return "CTC_DKIT_DISCARD_EPE_HARD_ERROR_DIS";
    case CTC_DKIT_DISCARD_EPE_MICROFLOW_POLICING_FAIL_DROP:
        return "CTC_DKIT_DISCARD_EPE_MICROFLOW_POLICING_FAIL_DROP";
    case CTC_DKIT_DISCARD_EPE_ARP_MISS_DISCARD:
        return "CTC_DKIT_DISCARD_EPE_ARP_MISS_DISCARD";
    case CTC_DKIT_DISCARD_EPE_RESERVED:
        return "CTC_DKIT_DISCARD_EPE_RESERVED";



    default:
        sal_sprintf(reason_desc, "Reason id:%d", reason_id);
        return reason_desc;
    }

}


static int32
_ctc_goldengate_dkit_discard_display_reason(ctc_dkit_discard_reason_t* discard_reason)
{
    DKITS_PTR_VALID_CHECK(discard_reason);

    switch (discard_reason->module)
    {
        case CTC_DKIT_DISCARD_FLAG_IPE:
            {
                if (discard_reason->port != CTC_DKIT_INVALID_PORT)
                {
                    CTC_DKIT_PRINT("Packet discard at IPE on port %d, reason id %d, discard id %d: %s\n", discard_reason->port,
                                discard_reason->reason_id, discard_reason->reason_id - CTC_DKIT_DISCARD_IPE_FEATURE_START, ctc_goldengate_dkit_get_reason_desc(discard_reason->reason_id));
                }
                else
                {
                    CTC_DKIT_PRINT("Packet discard at IPE, reason id %d, discard id %d: %s\n", discard_reason->reason_id, discard_reason->reason_id- CTC_DKIT_DISCARD_IPE_FEATURE_START,
                                ctc_goldengate_dkit_get_reason_desc(discard_reason->reason_id));
                }
            }
            break;
        case CTC_DKIT_DISCARD_FLAG_EPE:
            {
                CTC_DKIT_PRINT("Packet discard at EPE, reason id %d, discard id %d: %s\n",  discard_reason->reason_id, discard_reason->reason_id - CTC_DKIT_DISCARD_EPE_FEATURE_START,
                            ctc_goldengate_dkit_get_reason_desc(discard_reason->reason_id));
            }
            break;
        case CTC_DKIT_DISCARD_FLAG_BSR:
            {
                if (discard_reason->port != CTC_DKIT_INVALID_PORT)
                {
                    CTC_DKIT_PRINT("Packet discard at BSR on channel %d, reason id %d: %s\n", discard_reason->port,
                                discard_reason->reason_id, ctc_goldengate_dkit_get_reason_desc(discard_reason->reason_id));
                }
                else
                {
                    CTC_DKIT_PRINT("Packet discard at BSR, reason id %d: %s\n", discard_reason->reason_id,
                                ctc_goldengate_dkit_get_reason_desc(discard_reason->reason_id));
                }
            }
            break;
        case CTC_DKIT_DISCARD_FLAG_OAM:
            {
                CTC_DKIT_PRINT("Packet discard at OAM engine, reason id %d: %s\n",  discard_reason->reason_id,
                            ctc_goldengate_dkit_get_reason_desc(discard_reason->reason_id));
            }
            break;
        case CTC_DKIT_DISCARD_FLAG_NET_RX:
            {
                if (discard_reason->port != CTC_DKIT_INVALID_PORT)
                {
                    CTC_DKIT_PRINT("Packet discard at NETRX on channel %d, reason id %d: %s\n", discard_reason->port,
                                discard_reason->reason_id, ctc_goldengate_dkit_get_reason_desc(discard_reason->reason_id));
                }
                else
                {
                    CTC_DKIT_PRINT("Packet discard at NETRX, reason id %d: %s\n",  discard_reason->reason_id,
                                ctc_goldengate_dkit_get_reason_desc(discard_reason->reason_id));
                }
            }
            break;
        case CTC_DKIT_DISCARD_FLAG_NET_TX:
            {
                CTC_DKIT_PRINT("Packet discard at NETTX, reason id %d: %s\n",  discard_reason->reason_id,
                            ctc_goldengate_dkit_get_reason_desc(discard_reason->reason_id));
            }
            break;
        default:
            break;
    }
    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_discard_display_bus_reason(ctc_dkit_discard_info_t* p_discard_info)
{
    DKITS_PTR_VALID_CHECK(p_discard_info);
    if ((p_discard_info->discard_reason_bus.gport != CTC_DKIT_INVALID_PORT)&&(1 == p_discard_info->discard_count))
    {
        //CTC_DKIT_PRINT("\n## DETAIL INFO: discard on port 0x%04x\n", p_discard_info->discard_reason_bus.gport);
        CTC_DKIT_PRINT("\n## DETAIL INFO:\n");
    }
    else if (1 == p_discard_info->discard_count)
    {
        CTC_DKIT_PRINT("\n## DETAIL INFO:\n");
    }
    else
    {
        return CLI_SUCCESS;
    }


    if (p_discard_info->discard_reason_bus.reason_id)
    {
        if (p_discard_info->discard_reason_bus.value_type == CTC_DKIT_DISCARD_VALUE_TYPE_NONE)
        {
            CTC_DKIT_PRINT("1. Sub reason id %d: %s\n", p_discard_info->discard_reason_bus.reason_id,
                                        ctc_goldengate_dkit_get_sub_reason_desc(p_discard_info->discard_reason_bus.reason_id));
        }
        else if (p_discard_info->discard_reason_bus.value_type == CTC_DKIT_DISCARD_VALUE_TYPE_1)
        {
            CTC_DKIT_PRINT("1. Sub reason id %d: %s%d\n", p_discard_info->discard_reason_bus.reason_id,
                                        ctc_goldengate_dkit_get_sub_reason_desc(p_discard_info->discard_reason_bus.reason_id),
                                        p_discard_info->discard_reason_bus.value[0]);
        }
        else if (p_discard_info->discard_reason_bus.value_type == CTC_DKIT_DISCARD_VALUE_TYPE_2)
        {
            CTC_DKIT_PRINT("1. Sub reason id %d: %s%d and %d\n", p_discard_info->discard_reason_bus.reason_id,
                                        ctc_goldengate_dkit_get_sub_reason_desc(p_discard_info->discard_reason_bus.reason_id),
                                        p_discard_info->discard_reason_bus.value[0],
                                        p_discard_info->discard_reason_bus.value[1]);
        }
        else if (p_discard_info->discard_reason_bus.value_type == CTC_DKIT_DISCARD_VALUE_TYPE_3)
        {
            CTC_DKIT_PRINT("1. Sub reason id %d: %s%d, %d and %d\n", p_discard_info->discard_reason_bus.reason_id,
                                        ctc_goldengate_dkit_get_sub_reason_desc(p_discard_info->discard_reason_bus.reason_id),
                                        p_discard_info->discard_reason_bus.value[0],
                                        p_discard_info->discard_reason_bus.value[1],
                                        p_discard_info->discard_reason_bus.value[2]);
        }
        else
        {
            CTC_DKIT_PRINT("   N/A");
        }
    }
    else
    {
        CTC_DKIT_PRINT("   N/A");
    }

    return CLI_SUCCESS;
}
static int32
_ctc_goldengate_dkit_discard_display(ctc_dkit_discard_info_t* p_discard_info)
{
    char yes_no[2][4]={" -", "YES"};
    uint8 i = 0;

    DKITS_PTR_VALID_CHECK(p_discard_info);

    /*1. display total*/
    CTC_DKIT_PRINT("\n");
    CTC_DKIT_PRINT("TIME: %s", p_discard_info->systime_str);
    CTC_DKIT_PRINT("============================================================\n");
    CTC_DKIT_PRINT(" %-10s %-10s %-10s %-10s %-10s %-10s\n", "NETRX", "IPE",  "BSR", "EPE", "NETTX", "OAM");
    CTC_DKIT_PRINT("------------------------------------------------------------\n");
    CTC_DKIT_PRINT(" %-10s %-10s %-10s %-10s %-10s %-10s\n",
                yes_no[DKITS_FLAG_ISSET(p_discard_info->discard_flag, CTC_DKIT_DISCARD_FLAG_NET_RX)],
                yes_no[DKITS_FLAG_ISSET(p_discard_info->discard_flag, CTC_DKIT_DISCARD_FLAG_IPE)],
                yes_no[DKITS_FLAG_ISSET(p_discard_info->discard_flag, CTC_DKIT_DISCARD_FLAG_BSR)],
                yes_no[DKITS_FLAG_ISSET(p_discard_info->discard_flag, CTC_DKIT_DISCARD_FLAG_EPE)],
                yes_no[DKITS_FLAG_ISSET(p_discard_info->discard_flag, CTC_DKIT_DISCARD_FLAG_NET_TX)],
                yes_no[DKITS_FLAG_ISSET(p_discard_info->discard_flag, CTC_DKIT_DISCARD_FLAG_OAM)]);
    CTC_DKIT_PRINT("============================================================\n");

    /*2. display by reason id*/
    if (p_discard_info->discard_count > 0)
    {
        CTC_DKIT_PRINT("\n## PRIMARY:\n");
        for (i = 0; i < p_discard_info->discard_count; i++)
        {
            CTC_DKIT_PRINT("%d. ", i + 1);
            _ctc_goldengate_dkit_discard_display_reason(&p_discard_info->discard_reason[i]);
        }
    }

    /*3. display reason from bus info*/
   if (p_discard_info->discard_reason_bus.valid)
   {
       _ctc_goldengate_dkit_discard_display_bus_reason(p_discard_info);
   }

    /*4. display reason from captured info*/
    //if (p_discard_info->discard_reason_captured.reason_id)
    //{
    //    CTC_DKIT_PRINT("\n## FROM CAPTURED INFO:\n");
    //    CTC_DKIT_PRINT("1. Reason id %d: %s\n", p_discard_info->discard_reason_captured.reason_id, ctc_dkit_get_sub_reason_desc(p_discard_info->discard_reason_captured.reason_id));
    //}

    CTC_DKIT_PRINT("\n");

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_discard_get_port_stats(uint8 lchip, ctc_dkit_discard_stats_t* p_stats, uint8  chan_id)
{
    uint32 cmd                     = 0;
    uint32 value                   = 0;
    uint32 tbl_id                  = 0;
    uint8 slice                    = 0;
    uint8 i                        = 0;


    DKITS_PTR_VALID_CHECK(p_stats);

    for (slice = 0; slice < CTC_DKIT_SLICE_NUM; slice++)
    {

        /*1.2 future discard*/
        tbl_id = DsIngressDiscardStats_t + slice;
        cmd = DRV_IOR(tbl_id, DsIngressDiscardStats_packetCount_f);

        for (i = CTC_DKIT_DISCARD_IPE_FEATURE_START; i <= CTC_DKIT_DISCARD_IPE_FEATURE_END; i++)
        {
            DRV_IOCTL(lchip, chan_id*64 + i, cmd, &value);
            p_stats->cnt[i] = value;
        }

        /*2.2 future discard*/
        tbl_id = DsEgressDiscardStats_t + slice;
        cmd = DRV_IOR(tbl_id, DsEgressDiscardStats_packetCount_f);

        for (i = CTC_DKIT_DISCARD_EPE_FEATURE_START; i <= CTC_DKIT_DISCARD_EPE_FEATURE_END; i++)
        {
            DRV_IOCTL(lchip, ((chan_id << 5) + (chan_id << 4) + (chan_id << 3) + i), cmd, &value);
            p_stats->cnt[i] = value;
        }

    }

    return 0;
}


static int32
_ctc_goldengate_dkit_discard_get_stats(uint8 lchip, ctc_dkit_discard_stats_t* p_stats, uint32  fliter_flag)
{


#if 1
    uint32 cmd = 0;
    uint32 value = 0;
    uint32 tbl_id = 0;
    uint8 slice = 0;
    uint8 i =0;
    uint8 j =0;

#if 0
    PktErrStatsMem_m pkt_err_stats_mem_slice;
    QMgrEnqDebugStats_m q_mgr_enq_debug_stats;
    NetTxDebugStats_m net_tx_debug_stats;
    NetRxDebugStats_m net_rx_debug_stats;
    NetRxDebugStatsTable0_m net_rx_debug_stats_table;
#endif

    DKITS_PTR_VALID_CHECK(p_stats);

    /*1. read ipe discard stats*/

#if 0
        /*1.1 asic hard error*/
        tbl_id = IpeHdrAdjDebugStats_t + slice;
        cmd = DRV_IOR(tbl_id, IpeHdrAdjDebugStats_txHardErrorCnt_f);
        DRV_IOCTL(lchip, 0, cmd, &value);
        p_stats->ipe[slice].hw_discard.har_adj = value;

        tbl_id = IpeIntfMapDebugStats_t + slice;
        cmd = DRV_IOR(tbl_id, IpeIntfMapDebugStats_txPiHardErrorCnt_f);
        DRV_IOCTL(lchip, 0, cmd, &value);
        p_stats->ipe[slice].hw_discard.intf_map = value;

        tbl_id = IpeLkupMgrDebugStats_t + slice;
        cmd = DRV_IOR(tbl_id, IpeLkupMgrDebugStats_txHardErrorCnt_f);
        DRV_IOCTL(lchip, 0, cmd, &value);
        p_stats->ipe[slice].hw_discard.lkup_qos = value;

        tbl_id = IpePktProcDebugStats_t + slice;
        cmd = DRV_IOR(tbl_id, IpePktProcDebugStats_txPiHardErrorCnt_f);
        DRV_IOCTL(lchip, 0, cmd, &value);
        p_stats->ipe[slice].hw_discard.pkt_proc = value;

#endif
        /* IPE feature discard*/
        tbl_id = DsIngressDiscardStats_t + slice;
        cmd = DRV_IOR(tbl_id, DsIngressDiscardStats_packetCount_f);
        for (i = CTC_DKIT_DISCARD_IPE_FEATURE_START; i <= CTC_DKIT_DISCARD_IPE_FEATURE_END; i++)
        {
            uint8 discard_type  = 0;
            uint8 channel_id    = 0;

            discard_type = i - CTC_DKIT_DISCARD_IPE_FEATURE_START;

            for (channel_id = 0; channel_id < 70; channel_id++)
            {
                DRV_IOCTL(lchip, channel_id*64 + discard_type, cmd, &value);
                p_stats->cnt[i] += value;
            }
        }


        /* EPE feature discard*/
        tbl_id = DsEgressDiscardStats_t + slice;
        cmd = DRV_IOR(tbl_id, DsEgressDiscardStats_packetCount_f);

        for (i = CTC_DKIT_DISCARD_EPE_FEATURE_START; i <= CTC_DKIT_DISCARD_EPE_FEATURE_END; i++)
        {
            uint8 discard_type  = 0;
            uint8 channel_id    = 0;

            discard_type = i - CTC_DKIT_DISCARD_EPE_FEATURE_START;

            for (channel_id = 0; channel_id < 70; channel_id++)
            {
                DRV_IOCTL(lchip, ((channel_id << 5) + (channel_id << 4) + (channel_id << 3) + discard_type ), cmd, &value);
                p_stats->cnt[i] += value;
            }
        }



#if 0

        /*2. read epe discard stats*/
        /*2.1 asci hard error*/
        tbl_id = EpeHdrEditDebugStats_t + slice;
        cmd = DRV_IOR(tbl_id, EpeHdrEditDebugStats_txPiHardErrorCnt_f);
        DRV_IOCTL(lchip, 0, cmd, &value);
        p_stats->epe[slice].hw_discard.total = value;

        tbl_id = EpeHdrAdjDebugStats_t + slice;
        cmd = DRV_IOR(tbl_id, EpeHdrAdjDebugStats_txPiHardErrorCnt_f);
        DRV_IOCTL(lchip, 0, cmd, &value);
        p_stats->epe[slice].hw_discard.har_adj = value;

        tbl_id =  EpeNextHopDebugStatus_t + slice;
        cmd = DRV_IOR(tbl_id,  EpeNextHopDebugStatus_piHardErrorCnt_f);
        DRV_IOCTL(lchip, 0, cmd, &value);
        p_stats->epe[slice].hw_discard.next_hop = value;

        tbl_id = EpeHdrProcDebugStats_t + slice;
        cmd = DRV_IOR(tbl_id, EpeHdrProcDebugStats_l2EditHardErrorCnt_f);
        DRV_IOCTL(lchip, 0, cmd, &value);
        p_stats->epe[slice].hw_discard.l2_edit = value;

        tbl_id = EpeHdrProcDebugStats_t + slice;
        cmd = DRV_IOR(tbl_id, EpeHdrProcDebugStats_l3EditHardErrorCnt_f);
        DRV_IOCTL(lchip, 0, cmd, &value);
        p_stats->epe[slice].hw_discard.l3_edit = value;

        tbl_id = EpeHdrProcDebugStats_t + slice;
        cmd = DRV_IOR(tbl_id, EpeHdrProcDebugStats_innerL2HardErrorCnt_f);
        DRV_IOCTL(lchip, 0, cmd, &value);
        p_stats->epe[slice].hw_discard.inner_l2 = value;

        tbl_id = EpeHdrProcDebugStats_t + slice;
        cmd = DRV_IOR(tbl_id, EpeHdrProcDebugStats_payloadHardErrorCnt_f);
        DRV_IOCTL(lchip, 0, cmd, &value);
        p_stats->epe[slice].hw_discard.payload = value;

        tbl_id = EpeAclQosDebugStats_t + slice;
        cmd = DRV_IOR(tbl_id, EpeAclQosDebugStats_txAclHardErrorCnt_f);
        DRV_IOCTL(lchip, 0, cmd, &value);
        p_stats->epe[slice].hw_discard.acl_oam = value;

        tbl_id = EpeClaDebugStats_t + slice;
        cmd = DRV_IOR(tbl_id, EpeClaDebugStats_txClaHardErrorCnt_f);
        DRV_IOCTL(lchip, 0, cmd, &value);
        p_stats->epe[slice].hw_discard.classification = value;

        tbl_id = EpeOamDebugStats_t + slice;
        cmd = DRV_IOR(tbl_id, EpeOamDebugStats_oamTxHardErrorCnt_f);
        DRV_IOCTL(lchip, 0, cmd, &value);
        p_stats->epe[slice].hw_discard.oam = value;
#endif




#if 0
    /*3. read bsr discard stats*/
    /*3.1 bufstore discard*/
    for (i = 0; i < (CTC_DKIT_ONE_SLICE_CHANNEL_NUM*2); i++)
    {
        sal_memset(&pkt_err_stats_mem_slice, 0, sizeof(pkt_err_stats_mem_slice));
        tbl_id = PktErrStatsMem_t;
        cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
        DRV_IOCTL(lchip, i, cmd, &pkt_err_stats_mem_slice);
        GetPktErrStatsMem(A, pktAbortCnt_f, &pkt_err_stats_mem_slice, &value);
        p_stats->bsr.bufstore[i].abort_total = value;
        GetPktErrStatsMem(A, pktAbortDataErrorCnt_f, &pkt_err_stats_mem_slice, &value);
        p_stats->bsr.bufstore[i].abort_data_error = value;
        GetPktErrStatsMem(A, pktAbortFramingErrorCnt_f, &pkt_err_stats_mem_slice, &value);
        p_stats->bsr.bufstore[i].abort_frame_error = value;
        GetPktErrStatsMem(A, pktAbortOverLenErrorCnt_f, &pkt_err_stats_mem_slice, &value);
        p_stats->bsr.bufstore[i].abort_over_len_error = value;
        GetPktErrStatsMem(A, pktAbortUnderLenError_f, &pkt_err_stats_mem_slice, &value);
        p_stats->bsr.bufstore[i].abort_under_len = value;
        GetPktErrStatsMem(A, pktAbortMetFifoDropCnt_f, &pkt_err_stats_mem_slice, &value);
        p_stats->bsr.bufstore[i].abort_met_fifo_drop = value;
        GetPktErrStatsMem(A, pktAbortNoBufCnt_f, &pkt_err_stats_mem_slice, &value);
        p_stats->bsr.bufstore[i].abort_no_buf = value;

        GetPktErrStatsMem(A, pktSilentDropCnt_f, &pkt_err_stats_mem_slice, &value);
        p_stats->bsr.bufstore[i].silent_total = value;
        GetPktErrStatsMem(A, pktSilentDropHardDiscardCnt_f, &pkt_err_stats_mem_slice, &value);
        p_stats->bsr.bufstore[i].silent_ipe_discard = value;
        GetPktErrStatsMem(A, pktSilentDropDataErrorCnt_f, &pkt_err_stats_mem_slice, &value);
        p_stats->bsr.bufstore[i].silent_data_error = value;
        GetPktErrStatsMem(A, pktSilentDropChipIdMismatchCnt_f, &pkt_err_stats_mem_slice, &value);
        p_stats->bsr.bufstore[i].silent_chip_mismatch = value;
        GetPktErrStatsMem(A, pktSilentDropNoBufCnt_f, &pkt_err_stats_mem_slice, &value);
        p_stats->bsr.bufstore[i].silent_no_buf = value;
        GetPktErrStatsMem(A, pktSilentDropSelfOrigDiscardCnt_f, &pkt_err_stats_mem_slice, &value);
        p_stats->bsr.bufstore[i].silent_sel_orig_discard = value;
        GetPktErrStatsMem(A, pktSilentDropResrcFailCnt_f, &pkt_err_stats_mem_slice, &value);
        p_stats->bsr.bufstore[i].silent_resrc_fail = value;
    }


    /*3.2 qmgr discard*/
    sal_memset(&q_mgr_enq_debug_stats, 0, sizeof(q_mgr_enq_debug_stats));
    cmd = DRV_IOR(QMgrEnqDebugStats_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &q_mgr_enq_debug_stats);
    GetQMgrEnqDebugStats(A, dropEnqMsgCnt_f, &q_mgr_enq_debug_stats, &value);
    p_stats->bsr.qmgr.total = value;
    GetQMgrEnqDebugStats(A, spanOnDropCnt_f, &q_mgr_enq_debug_stats, &value);
    p_stats->bsr.qmgr.span_on_drop = value;
    GetQMgrEnqDebugStats(A, dropForFreeUsedUpCnt_f, &q_mgr_enq_debug_stats, &value);
    p_stats->bsr.qmgr.no_queue_entry = value;
    GetQMgrEnqDebugStats(A, dropForEnqDiscardCnt_f, &q_mgr_enq_debug_stats, &value);
    p_stats->bsr.qmgr.enq_discard = value;
    GetQMgrEnqDebugStats(A, dropForWredCnt_f, &q_mgr_enq_debug_stats, &value);
    p_stats->bsr.qmgr.wred_discard = value;
    GetQMgrEnqDebugStats(A, dropForEgressResrcMgrCnt_f, &q_mgr_enq_debug_stats, &value);
    p_stats->bsr.qmgr.egr_resrc_mgr = value;
    GetQMgrEnqDebugStats(A, dropForReservChanIdCnt_f, &q_mgr_enq_debug_stats, &value);
    p_stats->bsr.qmgr.reserve_channel = value;
    GetQMgrEnqDebugStats(A, dropCriticalPktCnt_f, &q_mgr_enq_debug_stats, &value);
    p_stats->bsr.qmgr.critical_pkt = value;
    GetQMgrEnqDebugStats(A, dropC2cPktCnt_f, &q_mgr_enq_debug_stats, &value);
    p_stats->bsr.qmgr.c2c_pkt = value;
    GetQMgrEnqDebugStats(A, noChanLinkAggMemDiscardCnt_f, &q_mgr_enq_debug_stats, &value);
    p_stats->bsr.qmgr.no_channel_linkagg_member = value;
    GetQMgrEnqDebugStats(A, mcastLinkAggDiscardCnt_f, &q_mgr_enq_debug_stats, &value);
    p_stats->bsr.qmgr.mcast_linkagg_discard = value;
    GetQMgrEnqDebugStats(A, noPortLinkAggMemberDiscardCnt_f, &q_mgr_enq_debug_stats, &value);
    p_stats->bsr.qmgr.no_port_linkagg_member = value;
    GetQMgrEnqDebugStats(A, stackingDiscardCnt_f, &q_mgr_enq_debug_stats, &value);
    p_stats->bsr.qmgr.stacking_discard = value;

    /*4. read net rx discard stats*/
    for (slice = 0; slice < CTC_DKIT_SLICE_NUM; slice++)
    {
        sal_memset(&net_rx_debug_stats, 0, sizeof(net_rx_debug_stats));
        tbl_id = NetRxDebugStats_t + slice;
        cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
        DRV_IOCTL(lchip, 0, cmd, &net_rx_debug_stats);
        GetNetRxDebugStats(A, rxBpduDropCnt0_f, &net_rx_debug_stats, &value);
        p_stats->netrx.drop[slice].Bpdu_Drop0 = value;
        GetNetRxDebugStats(A, rxBpduDropCnt1_f, &net_rx_debug_stats, &value);
        p_stats->netrx.drop[slice].Bpdu_Drop1 = value;
        GetNetRxDebugStats(A, rxBpduDropCnt2_f, &net_rx_debug_stats, &value);
        p_stats->netrx.drop[slice].Bpdu_Drop2 = value;
        GetNetRxDebugStats(A, rxBpduDropCnt3_f, &net_rx_debug_stats, &value);
        p_stats->netrx.drop[slice].Bpdu_Drop3 = value;
        GetNetRxDebugStats(A, rxPauseDropCnt0_f, &net_rx_debug_stats, &value);
        p_stats->netrx.drop[slice].Pause_Drop0 = value;
        GetNetRxDebugStats(A, rxPauseDropCnt1_f, &net_rx_debug_stats, &value);
        p_stats->netrx.drop[slice].Pause_Drop1 = value;
        GetNetRxDebugStats(A, rxPauseDropCnt2_f, &net_rx_debug_stats, &value);
        p_stats->netrx.drop[slice].Pause_Drop2 = value;
        GetNetRxDebugStats(A, rxPauseDropCnt3_f, &net_rx_debug_stats, &value);
        p_stats->netrx.drop[slice].Pause_Drop3 = value;
    }
    for (i = 0; i < CTC_DKIT_CHANNEL_NUM; i++)
    {
        sal_memset(&net_rx_debug_stats_table, 0, sizeof(net_rx_debug_stats_table));
        tbl_id = NetRxDebugStatsTable0_t + i / (CTC_DKIT_CHANNEL_NUM / 2);
        cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
        DRV_IOCTL(lchip, (i % (CTC_DKIT_CHANNEL_NUM / 2)), cmd, &net_rx_debug_stats_table);
        GetNetRxDebugStatsTable0(A, lenErrDropCnt_f, &net_rx_debug_stats_table, &value);
        p_stats->netrx.dbg_table[i].len_err_drop = value;
        GetNetRxDebugStatsTable0(A, frameErrDropCnt_f, &net_rx_debug_stats_table, &value);
        p_stats->netrx.dbg_table[i].frame_err_drop = value;
        GetNetRxDebugStatsTable0(A, pktErrDropCnt_f, &net_rx_debug_stats_table, &value);
        p_stats->netrx.dbg_table[i].pkt_err_drop = value;
        GetNetRxDebugStatsTable0(A, fullDropCnt_f, &net_rx_debug_stats_table, &value);
        p_stats->netrx.dbg_table[i].full_drop = value;
    }

    /*5. read net tx discard stats*/
    for (slice = 0; slice < CTC_DKIT_SLICE_NUM; slice++)
    {
        sal_memset(&net_tx_debug_stats, 0, sizeof(net_tx_debug_stats));
        tbl_id = NetTxDebugStats_t + slice;
        cmd = DRV_IOR(tbl_id, DRV_ENTRY_FLAG);
        DRV_IOCTL(lchip, 0, cmd, &net_tx_debug_stats);
        GetNetTxDebugStats(A, spanMinLenDropCnt_f, &net_tx_debug_stats, &value);
        p_stats->nettx[slice].span_min_len_drop = value;
        GetNetTxDebugStats(A, spanNoBufDropCnt_f, &net_tx_debug_stats, &value);
        p_stats->nettx[slice].span_no_buf_drop = value;
        GetNetTxDebugStats(A, spanNoEopDropCnt_f, &net_tx_debug_stats, &value);
        p_stats->nettx[slice].span_no_eop_drop = value;
        GetNetTxDebugStats(A, spanNoSopDropCnt_f, &net_tx_debug_stats, &value);
        p_stats->nettx[slice].span_no_sop_drop = value;
        GetNetTxDebugStats(A, epeMinLenDropCnt_f, &net_tx_debug_stats, &value);
        p_stats->nettx[slice].epe_min_len_drop = value;
        GetNetTxDebugStats(A, infoDropCnt_f, &net_tx_debug_stats, &value);
        p_stats->nettx[slice].info_drop = value;
        GetNetTxDebugStats(A, epeNoBufDropCnt_f, &net_tx_debug_stats, &value);
        p_stats->nettx[slice].epe_no_buf_drop = value;
        GetNetTxDebugStats(A, epeNoEopDropCnt_f, &net_tx_debug_stats, &value);
        p_stats->nettx[slice].epe_no_eop_drop = value;
        GetNetTxDebugStats(A, epeNoSopDropCnt_f, &net_tx_debug_stats, &value);
        p_stats->nettx[slice].epe_no_sop_drop = value;
    }

    /*6. read oam discard stats*/
    cmd = DRV_IOR(OamProcDebugStats_t, OamProcDebugStats_linkAggMemDiscardCnt_f);
    DRV_IOCTL(lchip, 0, cmd, &value);
    p_stats->oam.link_agg_no_member = value;
    cmd = DRV_IOR(OamHdrEditDebugStats_t, OamHdrEditDebugStats_asicHardDiscardCnt_f);
    DRV_IOCTL(lchip, 0, cmd, &value);
    p_stats->oam.hw_error = value;
    cmd = DRV_IOR(OamHdrEditDebugStats_t, OamHdrEditDebugStats_exceptionDiscardCnt_f);
    DRV_IOCTL(lchip, 0, cmd, &value);
    p_stats->oam.exception_discard = value;

#endif

#endif

    return CLI_SUCCESS;
}


static int32
_ctc_goldengate_dkit_discard_get_reason(const ctc_dkit_discard_stats_t* p_last_stats,
                                        const ctc_dkit_discard_stats_t* p_cur_stats,
                                        ctc_dkit_discard_info_t* p_discard_info)
{
    uint16 ipe_disacrd_reason_cnt = 0;
    uint8 i = 0;
    uint8 slice = 0;
    sal_time_t tv;
    char* p_time_str = NULL;

    DKITS_PTR_VALID_CHECK(p_last_stats);
    DKITS_PTR_VALID_CHECK(p_cur_stats);
    DKITS_PTR_VALID_CHECK(p_discard_info);

    /*get systime*/
    sal_time(&tv);
    p_time_str = sal_ctime(&tv);
    sal_strncpy(p_discard_info->systime_str, p_time_str, 50);


    /*NETRX discard*/
    for (i = CTC_DKIT_DISCARD_NETRX_START; i <= CTC_DKIT_DISCARD_NETRX_END; i++)
    {
        if (p_last_stats->cnt[i] != p_cur_stats->cnt[i])
        {
            DKITS_SET_FLAG(p_discard_info->discard_flag, CTC_DKIT_DISCARD_FLAG_NET_RX);
            ADD_DISCARD_REASON(p_discard_info, i, CTC_DKIT_DISCARD_FLAG_NET_RX, CTC_DKIT_INVALID_PORT, slice);
        }
    }


    /*IPE discard*/
    for (i = CTC_DKIT_DISCARD_IPE_START; i <= CTC_DKIT_DISCARD_IPE_END; i++)
    {
        if (p_last_stats->cnt[i] != p_cur_stats->cnt[i])
        {
            DKITS_SET_FLAG(p_discard_info->discard_flag, CTC_DKIT_DISCARD_FLAG_IPE);
            ADD_DISCARD_REASON(p_discard_info, i, CTC_DKIT_DISCARD_FLAG_IPE, CTC_DKIT_INVALID_PORT, slice);
        }
    }

    /* BSR discard*/
    for (i = CTC_DKIT_DISCARD_BSR_START; i <= CTC_DKIT_DISCARD_BSR_END; i++)
    {
        if (p_last_stats->cnt[i] != p_cur_stats->cnt[i])
        {
            DKITS_SET_FLAG(p_discard_info->discard_flag, CTC_DKIT_DISCARD_FLAG_BSR);
            ADD_DISCARD_REASON(p_discard_info, i, CTC_DKIT_DISCARD_FLAG_BSR, CTC_DKIT_INVALID_PORT, slice);
         }
    }

    /*EPE discard*/
    for (i = CTC_DKIT_DISCARD_EPE_START; i <= CTC_DKIT_DISCARD_EPE_END; i++)
    {
        if (p_last_stats->cnt[i] != p_cur_stats->cnt[i])
        {
            DKITS_SET_FLAG(p_discard_info->discard_flag, CTC_DKIT_DISCARD_FLAG_EPE);
            ADD_DISCARD_REASON(p_discard_info, i, CTC_DKIT_DISCARD_FLAG_EPE, CTC_DKIT_INVALID_PORT, slice);
        }
    }

    /*NETTX discard*/
    for (i = CTC_DKIT_DISCARD_NETTX_START; i <= CTC_DKIT_DISCARD_NETTX_END; i++)
    {
        if (p_last_stats->cnt[i] != p_cur_stats->cnt[i])
        {
            DKITS_SET_FLAG(p_discard_info->discard_flag, CTC_DKIT_DISCARD_FLAG_NET_TX);
            ADD_DISCARD_REASON(p_discard_info, i, CTC_DKIT_DISCARD_FLAG_NET_TX, CTC_DKIT_INVALID_PORT, slice);
        }
    }

    return CLI_SUCCESS;
}


static int32
_ctc_goldengate_dkit_discard_get_sub_reason(ctc_dkit_discard_para_t* p_discard_para, ctc_dkit_discard_info_t* p_discard_info)
{
    int32 ret = CLI_SUCCESS;

    DKITS_PTR_VALID_CHECK(p_discard_info);
    DKITS_PTR_VALID_CHECK(p_discard_para);

    if (p_discard_info->discard_flag)
    {
        /*1. Get discard reason by bus info*/
        if ((!p_discard_para->on_line) || (p_discard_info->discard_count == 1))/*multi discard occured, can not use bus info!!!*/
        {
        #if 0
            ret = ctc_goldengate_dkit_bus_get_discard_sub_reason(p_discard_para, p_discard_info);
        #endif
        }

        /*2. Get discard reason by captured info*/
        //if (p_discard_para->captured)     not support!!!
        //{
        //    ret = ctc_dkit_captured_get_discard_sub_reason(p_discard_para, p_discard_info);
        //}
    }

    return ret;
}


int32
ctc_goldengate_dkit_discard_process(void* p_para)
{
    ctc_dkit_discard_para_t* p_discard_para = (ctc_dkit_discard_para_t *)p_para;
    ctc_dkit_discard_stats_t* cur_stats = NULL;
    ctc_dkit_discard_info_t* p_discard_info = NULL;
    uint8 front = 0;
    uint8 lchip = 0;

    DKITS_PTR_VALID_CHECK(p_para);
    lchip = p_discard_para->lchip;
    CTC_DKIT_LCHIP_CHECK(lchip);
    DKITS_PTR_VALID_CHECK(g_dkit_master[lchip]);

    cur_stats = (ctc_dkit_discard_stats_t*)mem_malloc(MEM_CLI_MODULE, sizeof(ctc_dkit_discard_stats_t));
    if (NULL == cur_stats)
    {
        return CLI_ERROR;
    }

    p_discard_info = (ctc_dkit_discard_info_t*)mem_malloc(MEM_CLI_MODULE, sizeof(ctc_dkit_discard_info_t));
    if (NULL == p_discard_info)
    {
        mem_free(cur_stats);
        return CLI_ERROR;
    }


    sal_memset(cur_stats, 0, sizeof(ctc_dkit_discard_stats_t));
    sal_memset(p_discard_info, 0, sizeof(ctc_dkit_discard_info_t));

    if (p_discard_para->history)/*show history*/
    {
        front = g_dkit_master[lchip]->discard_history.front;
        while (g_dkit_master[lchip]->discard_history.rear != front)
        {
            _ctc_goldengate_dkit_discard_display(&(g_dkit_master[lchip]->discard_history.discard[front++]));
            front %= CTC_DKIT_DISCARD_HISTORY_NUM;
        }
    }
    else  if (p_discard_para->match_port)/*show discard by port*/
    {
       uint8 chan_id = 0;

        chan_id = ctc_goldengate_dkit_get_channel_by_gport(lchip, p_discard_para->gport);
        /*1. read discard stats*/
        _ctc_goldengate_dkit_discard_get_port_stats(lchip, cur_stats, chan_id);

        /*2. compare discard stats and get reason id*/
        _ctc_goldengate_dkit_discard_get_reason(&(g_dkit_master[lchip]->discard_stats), cur_stats,  p_discard_info);

        if (p_discard_info->discard_flag)
        {
            /*if some discard occured, analyse discard reason from bus and captured info*/
            _ctc_goldengate_dkit_discard_get_sub_reason(p_discard_para, p_discard_info);
        }

        /*3. display result*/
        if (p_discard_info->discard_count > 0)
        {
            uint32 i = 0;

            for (i = 0; i < p_discard_info->discard_count; i++)
            {
                CTC_DKIT_PRINT("%d. ", i + 1);
                _ctc_goldengate_dkit_discard_display_reason(&p_discard_info->discard_reason[i]);
            }
        }

        /*3. display reason from bus info*/
        if (p_discard_info->discard_reason_bus.valid)
        {
            _ctc_goldengate_dkit_discard_display_bus_reason(p_discard_info);
        }

    }
    else
    {
        /*1. read discard stats*/
        _ctc_goldengate_dkit_discard_get_stats(lchip,cur_stats, 0);

        /*2. compare discard stats and get reason id*/
        _ctc_goldengate_dkit_discard_get_reason(&(g_dkit_master[lchip]->discard_stats), cur_stats,  p_discard_info);
        sal_memcpy(&(g_dkit_master[lchip]->discard_stats), cur_stats, sizeof(ctc_dkit_discard_stats_t));

        if (p_discard_info->discard_flag)
        {
            /*if some discard occured, analyse discard reason from bus and captured info*/
            _ctc_goldengate_dkit_discard_get_sub_reason(p_discard_para, p_discard_info);
        }

        /*3. display result*/
        _ctc_goldengate_dkit_discard_display(p_discard_info);

        /*4. store result history*/
        if (p_discard_info->discard_flag != 0)
        {
            sal_memcpy(&(g_dkit_master[lchip]->discard_history.discard[g_dkit_master[lchip]->discard_history.rear++]),
                       p_discard_info, sizeof(ctc_dkit_discard_info_t));
            g_dkit_master[lchip]->discard_history.rear %= CTC_DKIT_DISCARD_HISTORY_NUM;
            if (g_dkit_master[lchip]->discard_history.rear == g_dkit_master[lchip]->discard_history.front)
            {
                g_dkit_master[lchip]->discard_history.front++;
                g_dkit_master[lchip]->discard_history.front %= CTC_DKIT_DISCARD_HISTORY_NUM;
            }
        }
    }

    mem_free(cur_stats);
    mem_free(p_discard_info);

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_discard_print_type(uint32 reason_id, char* module)
{
#define PRINTF_LEN 57
    uint8 desc_len = 0;
    char buff0[64]= {0};
    char buff[128] = {0};
    desc_len = sal_strlen(ctc_goldengate_dkit_get_reason_desc(reason_id));
    sal_sprintf(buff, "%s", ctc_goldengate_dkit_get_reason_desc(reason_id));
    sal_memcpy(buff0, buff, PRINTF_LEN);
    if (desc_len > PRINTF_LEN)
    {
        if ((((buff0[PRINTF_LEN - 1]>='a')&&(buff0[PRINTF_LEN - 1]<='z'))||((buff0[PRINTF_LEN - 1]>='A')&&(buff0[PRINTF_LEN - 1]<='Z')))
            &&((buff[PRINTF_LEN]>='a')&&(buff[PRINTF_LEN]<='z')))
        {
            buff0[PRINTF_LEN] = '-';
            buff0[PRINTF_LEN+1] = '\0';
            CTC_DKIT_PRINT(" %-10d %-9s %-58s\n", reason_id, module, buff0);
        }
        else
        {
            buff0[PRINTF_LEN] = '\0';
            CTC_DKIT_PRINT(" %-10d %-9s %-58s\n", reason_id, module, buff0);
        }
        if (' ' == buff[PRINTF_LEN])
        {
            CTC_DKIT_PRINT(" %-20s %s\n", "", buff + PRINTF_LEN + 1);
        }
        else
        {
            CTC_DKIT_PRINT(" %-20s %s\n", "", buff + PRINTF_LEN);
        }
    }
    else
    {
        CTC_DKIT_PRINT(" %-10d %-9s %-58s\n", reason_id, module, buff);
    }
    return CLI_SUCCESS;
}


int32
ctc_goldengate_dkit_discard_show_type(void* p_para)
{
    uint32 i = 0;
    ctc_dkit_discard_para_t* p_discard_para = (ctc_dkit_discard_para_t *)p_para;
    char* module = "  -";


    DKITS_PTR_VALID_CHECK(p_para);

    CTC_DKIT_PRINT(" %-10s %-9s %s\n", "ReasonId", "Module", "Description");
    CTC_DKIT_PRINT("--------------------------------------------------------------------------------\n");

    if (0xFFFFFFFF == p_discard_para->reason_id)//all
    {
        for (i = CTC_DKIT_DISCARD_IPE_START; i <= CTC_DKIT_DISCARD_IPE_END; i++)
        {
            _ctc_goldengate_dkit_discard_print_type(i, "IPE");
        }
        for (i = CTC_DKIT_DISCARD_EPE_START; i <= CTC_DKIT_DISCARD_EPE_END; i++)
        {
            _ctc_goldengate_dkit_discard_print_type(i, "EPE");
        }
        for (i = CTC_DKIT_DISCARD_BSR_START; i <= CTC_DKIT_DISCARD_BSR_END; i++)
        {
            _ctc_goldengate_dkit_discard_print_type(i, "BSR");
        }
        for (i = CTC_DKIT_DISCARD_NETRX_START; i <= CTC_DKIT_DISCARD_NETRX_END; i++)
        {
            _ctc_goldengate_dkit_discard_print_type(i, "NETRX");
        }
        for (i = CTC_DKIT_DISCARD_NETTX_START; i <= CTC_DKIT_DISCARD_NETTX_END; i++)
        {
            _ctc_goldengate_dkit_discard_print_type(i, "NETTX");
        }
        for (i = CTC_DKIT_DISCARD_OAM_START; i <= CTC_DKIT_DISCARD_OAM_END; i++)
        {
            _ctc_goldengate_dkit_discard_print_type(i, "OAM");
        }
    }
    else
    {
        if ((p_discard_para->reason_id >= CTC_DKIT_DISCARD_IPE_START) && (p_discard_para->reason_id <= CTC_DKIT_DISCARD_IPE_END))
        {
            module = "IPE";
        }
        else if ((p_discard_para->reason_id >= CTC_DKIT_DISCARD_EPE_START) && (p_discard_para->reason_id <= CTC_DKIT_DISCARD_EPE_END))
        {
            module = "EPE";
        }
        else if ((p_discard_para->reason_id >= CTC_DKIT_DISCARD_BSR_START) && (p_discard_para->reason_id <= CTC_DKIT_DISCARD_BSR_END))
        {
            module = "BSR";
        }
        else if ((p_discard_para->reason_id >= CTC_DKIT_DISCARD_NETRX_START) && (p_discard_para->reason_id <= CTC_DKIT_DISCARD_NETRX_END))
        {
            module = "NETRX";
        }
        else if ((p_discard_para->reason_id >= CTC_DKIT_DISCARD_NETTX_START) && (p_discard_para->reason_id <= CTC_DKIT_DISCARD_NETTX_END))
        {
            module = "NETTX";
        }
        else if ((p_discard_para->reason_id >= CTC_DKIT_DISCARD_OAM_START) && (p_discard_para->reason_id <= CTC_DKIT_DISCARD_OAM_END))
        {
            module = "OAM";
        }
        _ctc_goldengate_dkit_discard_print_type(p_discard_para->reason_id, module);
    }
    CTC_DKIT_PRINT("--------------------------------------------------------------------------------\n");

    return CLI_SUCCESS;
}


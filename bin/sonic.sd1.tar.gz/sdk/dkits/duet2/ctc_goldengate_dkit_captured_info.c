#include "drv_api.h"
#include "drv_common.h"
#include "ctc_cli.h"
#include "ctc_dkit.h"
#include "ctc_goldengate_dkit.h"
#include "ctc_goldengate_dkit_drv.h"
#include "ctc_goldengate_dkit_discard.h"
#include "ctc_goldengate_dkit_discard_type.h"
#include "ctc_goldengate_dkit_path.h"
#include "ctc_goldengate_dkit_captured_info.h"

#define DRV_TCAM_IPEACL_3_BASE        (DRV_TCAM_KEY0_MAX_ENTRY_NUM)
#define DRV_TCAM_IPEACL_2_BASE        (DRV_TCAM_IPEACL_3_BASE + DRV_TCAM_KEY1_MAX_ENTRY_NUM)
#define DRV_TCAM_USERID_0_BASE        (DRV_TCAM_IPEACL_2_BASE + DRV_TCAM_KEY2_MAX_ENTRY_NUM)
#define DRV_TCAM_EPEACL_0_BASE        (DRV_TCAM_USERID_0_BASE + DRV_TCAM_KEY3_MAX_ENTRY_NUM)
#define DRV_TCAM_IPEACL_1_BASE        (DRV_TCAM_EPEACL_0_BASE + DRV_TCAM_KEY4_MAX_ENTRY_NUM)
#define DRV_TCAM_IPEACL_0_BASE        (DRV_TCAM_IPEACL_1_BASE + DRV_TCAM_KEY5_MAX_ENTRY_NUM)

#define CTC_DKIT_IPV6_ADDR_STR_LEN    44          /**< IPv6 address string length */

#define CTC_DKIT_CAPTURED_HASH_HIT "HASH lookup hit"
#define CTC_DKIT_CAPTURED_TCAM_HIT "TCAM lookup hit"
#define CTC_DKIT_CAPTURED_NOT_HIT "Not hit any entry!!!"
#define CTC_DKIT_CAPTURED_CONFLICT "HASH lookup conflict"
#define CTC_DKIT_CAPTURED_DEFAULT "HASH lookup hit default entry"

#define CTC_DKIT_SET_USER_MAC(dest, src)     \
    {   \
        (dest)[0] = (src)[1] >> 8;          \
        (dest)[1] = (src)[1] & 0xFF;        \
        (dest)[2] = (src)[0] >> 24;         \
        (dest)[3] = ((src)[0] >> 16) & 0xFF;\
        (dest)[4] = ((src)[0] >> 8) & 0xFF; \
        (dest)[5] = (src)[0] & 0xFF;        \
    }
#if (0 == SDK_WORK_PLATFORM)
#define CTC_DKITS_LPM_TCAM_REAL_ENTRY_NUM        128
#else
#define CTC_DKITS_LPM_TCAM_REAL_ENTRY_NUM        1024
#endif

#define CTC_DKITS_LPM_TCAM_MAX_ENTRY_NUM         1024
struct ctc_dkit_captured_path_info_s
{
      uint8 slice_ipe;
      uint8 slice_epe;
      uint8 is_ipe_captured;
      uint8 is_bsr_captured;

      uint8 is_epe_captured;
      uint8 discard;
      uint8 exception;
      uint8 detail;
      uint32 discard_type;
      uint32 exception_index;
      uint32 exception_sub_index;
      uint8 rx_oam;
      uint8 lchip;
      uint8 path_sel;
      uint8 rsv;
};
typedef struct ctc_dkit_captured_path_info_s ctc_dkit_captured_path_info_t;

static int32
_ctc_goldengate_dkit_ipuc_map_key_index(uint32 tbl_id, uint32 key_index, uint32* mapped_key_idx, uint32* mapped_ad_idx)
{
    uint8 block_num = 0;
    uint32 local_index = key_index & 0xFFF;
    uint32 map_index = 0;
    if(0 <= local_index && local_index < CTC_DKITS_LPM_TCAM_REAL_ENTRY_NUM)
    {
        block_num = 0;
        map_index = local_index;
    }
    else if(CTC_DKITS_LPM_TCAM_MAX_ENTRY_NUM <= local_index && local_index < CTC_DKITS_LPM_TCAM_MAX_ENTRY_NUM+CTC_DKITS_LPM_TCAM_REAL_ENTRY_NUM)
    {
        map_index = local_index-CTC_DKITS_LPM_TCAM_MAX_ENTRY_NUM;
        block_num = 1;
    }

    *mapped_key_idx = ((key_index>>12)&0x3)*CTC_DKITS_LPM_TCAM_REAL_ENTRY_NUM*2/((TCAM_KEY_SIZE(tbl_id)/DRV_LPM_KEY_BYTES_PER_ENTRY)) +
                                    block_num * CTC_DKITS_LPM_TCAM_REAL_ENTRY_NUM/((TCAM_KEY_SIZE(tbl_id)/DRV_LPM_KEY_BYTES_PER_ENTRY)) +
                                        map_index/((TCAM_KEY_SIZE(tbl_id)/DRV_LPM_KEY_BYTES_PER_ENTRY));
    *mapped_ad_idx = ((key_index>>12)&0x3)*CTC_DKITS_LPM_TCAM_REAL_ENTRY_NUM*2 + block_num * CTC_DKITS_LPM_TCAM_REAL_ENTRY_NUM + map_index;

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_discard_process(ctc_dkit_captured_path_info_t* p_info,
                                        uint32 discard, uint32 discard_type, uint32 module)
{
    if (1 == discard)
    {
        p_info->discard = 1;
        p_info->discard_type = discard_type;

        if (CTC_DKIT_IPE == module)/* ipe */
        {
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Drop!!!", ctc_goldengate_dkit_get_reason_desc(discard_type + CTC_DKIT_DISCARD_IPE_FEATURE_START));
        }
        else if (CTC_DKIT_EPE == module)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Drop!!!", ctc_goldengate_dkit_get_reason_desc(discard_type + CTC_DKIT_DISCARD_IPE_FEATURE_START));
        }
    }
    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_exception_process(ctc_dkit_captured_path_info_t* p_info,
                                          uint32 exception, uint32 exception_index, uint32 exception_sub_index)
{
    char* exception_desc[8] =
    {
    "Reserved",   // IPEEXCEPTIONINDEX_RESERVED               CBit(3,'h',"0", 1)
    "Bridge exception",// IPEEXCEPTIONINDEX_BRIDGE_EXCEPTION       CBit(3,'h',"1", 1)
    "Route exception",// IPEEXCEPTIONINDEX_ROUTE_EXCEPTION        CBit(3,'h',"2", 1)
    "Other exception"// IPEEXCEPTIONINDEX_OTHER_EXCEPTION        CBit(3,'h',"3", 1)

    };

    if (1 == exception)
    {
        p_info->exception = 1;
        p_info->exception_index = exception_index;
        p_info->exception_sub_index = exception_sub_index;

        CTC_DKIT_PATH_PRINT("%-15s:%s!!!\n", "Exception",exception_desc[exception_index]);
        CTC_DKIT_PATH_PRINT("%-15s:%d\n", "Excep index", exception_index);
        CTC_DKIT_PATH_PRINT("%-15s:%d\n", "Excep sub index", exception_sub_index);
    }
    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_ipe_exception_check(ctc_dkit_captured_path_info_t* p_info)
{
    uint8 slice = p_info->slice_ipe;
    uint8 lchip = p_info->lchip;
    uint32 cmd = 0;

    /*DbgIpeFwdProcessInfo*/
    uint32 fwd_exceptionEn = 0;
    uint32 fwd_exceptionIndex = 0;
    uint32 fwd_exceptionSubIndex = 0;
    DbgIpeFwdProcessInfo_m dbg_ipe_fwd_process_info;


    /*DbgIpeFwdProcessInfo*/
    sal_memset(&dbg_ipe_fwd_process_info, 0, sizeof(dbg_ipe_fwd_process_info));
    cmd = DRV_IOR(DbgIpeFwdProcessInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_ipe_fwd_process_info);

    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoExceptionEn_f, &dbg_ipe_fwd_process_info, &fwd_exceptionEn);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoExceptionIndex_f, &dbg_ipe_fwd_process_info, &fwd_exceptionIndex);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoExceptionSubIndex_f, &dbg_ipe_fwd_process_info, &fwd_exceptionSubIndex);

    _ctc_goldengate_dkit_captured_path_exception_process(p_info, fwd_exceptionEn, fwd_exceptionIndex, fwd_exceptionSubIndex);
    return CLI_SUCCESS;
}

static char*
_ctc_goldengate_dkit_captured_get_igr_scl_key_desc(uint32 key_type)
{
    switch (key_type)
    {
        case USERIDHASHTYPE_DISABLE:
            return "";
        case USERIDHASHTYPE_DOUBLEVLANPORT:
            return "DsUserIdDoubleVlanPortHashKey";
        case USERIDHASHTYPE_SVLANPORT:
            return "DsUserIdSvlanPortHashKey";
        case USERIDHASHTYPE_CVLANPORT:
            return "DsUserIdCvlanPortHashKey";
        case USERIDHASHTYPE_SVLANCOSPORT:
            return "DsUserIdSvlanCosPortHashKey";
        case USERIDHASHTYPE_CVLANCOSPORT:
            return "DsUserIdCvlanCosPortHashKey";
        case USERIDHASHTYPE_MACPORT:
            return "DsUserIdMacPortHashKey";
        case USERIDHASHTYPE_IPV4PORT:
            return "DsUserIdIpv4PortHashKey";
        case USERIDHASHTYPE_MAC:
            return "DsUserIdMacHashKey";
        case USERIDHASHTYPE_IPV4SA:
            return "DsUserIdIpv4SaHashKey";
        case USERIDHASHTYPE_PORT:
            return "DsUserIdPortHashKey";
        case USERIDHASHTYPE_SVLANMACSA:
            return "DsUserIdSvlanMacSaHashKey";
        case USERIDHASHTYPE_SVLAN:
            return "DsUserIdSvlanHashKey";
        case USERIDHASHTYPE_ECIDNAMESPACE:
            return "DsUserIdEcidNameSpaceHashKey";
        case USERIDHASHTYPE_INGECIDNAMESPACE:
            return "DsUserIdIngEcidNameSpaceHashKey";
        case USERIDHASHTYPE_IPV6SA:
            return "DsUserIdIpv6SaHashKey";
        case USERIDHASHTYPE_IPV6PORT:
            return "DsUserIdIpv6PortHashKey";
        case USERIDHASHTYPE_CAPWAPSTASTATUS:
            return "DsUserIdCapwapStaStatusHashKey";
        case USERIDHASHTYPE_CAPWAPSTASTATUSMC:
            return "DsUserIdCapwapStaStatusMcHashKey";
        case USERIDHASHTYPE_CAPWAPMACDAFORWARD:
            return "DsUserIdCapwapMacDaForwardHashKey";
        case USERIDHASHTYPE_CAPWAPVLANFORWARD:
            return "DsUserIdCapwapVlanForwardHashKey";
        case USERIDHASHTYPE_TUNNELIPV4:
            return "DsUserIdTunnelIpv4HashKey";
        case USERIDHASHTYPE_TUNNELIPV4GREKEY:
            return "DsUserIdTunnelIpv4GreKeyHashKey";
        case USERIDHASHTYPE_TUNNELIPV4UDP:
            return "DsUserIdTunnelIpv4UdpHashKey";
        case USERIDHASHTYPE_TUNNELPBB:
            return "DsUserIdTunnelPbbHashKey";
        case USERIDHASHTYPE_TUNNELTRILLUCRPF:
            return "DsUserIdTunnelTrillUcRpfHashKey";
        case USERIDHASHTYPE_TUNNELTRILLUCDECAP:
            return "DsUserIdTunnelTrillUcDecapHashKey";
        case USERIDHASHTYPE_TUNNELTRILLMCRPF:
            return "DsUserIdTunnelTrillMcRpfHashKey";
        case USERIDHASHTYPE_TUNNELTRILLMCDECAP:
            return "DsUserIdTunnelTrillMcDecapHashKey";
        case USERIDHASHTYPE_TUNNELTRILLMCADJ:
            return "DsUserIdTunnelTrillMcAdjHashKey";
        case USERIDHASHTYPE_TUNNELIPV4RPF:
            return "DsUserIdTunnelIpv4RpfHashKey";
        case USERIDHASHTYPE_TUNNELIPV4UCVXLANMODE0:
            return "DsUserIdTunnelIpv4UcVxlanMode0HashKey";
        case USERIDHASHTYPE_TUNNELIPV4UCVXLANMODE1:
            return "DsUserIdTunnelIpv4UcVxlanMode1HashKey";
        case USERIDHASHTYPE_TUNNELIPV6UCVXLANMODE0:
            return "DsUserIdTunnelIpv6UcVxlanMode0HashKey";
        case USERIDHASHTYPE_TUNNELIPV6UCVXLANMODE1:
            return "DsUserIdTunnelIpv6UcVxlanMode1HashKey";
        case USERIDHASHTYPE_TUNNELIPV4UCNVGREMODE0:
            return "DsUserIdTunnelIpv4UcNvgreMode0HashKey";
        case USERIDHASHTYPE_TUNNELIPV4UCNVGREMODE1:
            return "DsUserIdTunnelIpv4UcNvgreMode1HashKey";
        case USERIDHASHTYPE_TUNNELIPV6UCNVGREMODE0:
            return "DsUserIdTunnelIpv6UcNvgreMode0HashKey";
        case USERIDHASHTYPE_TUNNELIPV6UCNVGREMODE1:
            return "DsUserIdTunnelIpv6UcNvgreMode1HashKey";
        case USERIDHASHTYPE_TUNNELIPV4MCVXLANMODE0:
            return "DsUserIdTunnelIpv4McVxlanMode0HashKey";
        case USERIDHASHTYPE_TUNNELIPV4VXLANMODE1:
            return "DsUserIdTunnelIpv4VxlanMode1HashKey";
        case USERIDHASHTYPE_TUNNELIPV6MCVXLANMODE0:
            return "DsUserIdTunnelIpv6McVxlanMode0HashKey";
        case USERIDHASHTYPE_TUNNELIPV6MCVXLANMODE1:
            return "DsUserIdTunnelIpv6McVxlanMode1HashKey";
        case USERIDHASHTYPE_TUNNELIPV4MCNVGREMODE0:
            return "DsUserIdTunnelIpv4McNvgreMode0HashKey";
        case USERIDHASHTYPE_TUNNELIPV4NVGREMODE1:
            return "DsUserIdTunnelIpv4NvgreMode1HashKey";
        case USERIDHASHTYPE_TUNNELIPV6MCNVGREMODE0:
            return "DsUserIdTunnelIpv6McNvgreMode0HashKey";
        case USERIDHASHTYPE_TUNNELIPV6MCNVGREMODE1:
            return "DsUserIdTunnelIpv6McNvgreMode1HashKey";
        case USERIDHASHTYPE_TUNNELIPV4CAPWAP:
            return "DsUserIdTunnelIpv4CapwapHashKey";
        case USERIDHASHTYPE_TUNNELIPV6CAPWAP:
            return "DsUserIdTunnelIpv6CapwapHashKey";
        case USERIDHASHTYPE_TUNNELCAPWAPRMAC:
            return "DsUserIdTunnelCapwapRmacHashKey";
        case USERIDHASHTYPE_TUNNELCAPWAPRMACRID:
            return "DsUserIdTunnelCapwapRmacRidHashKey";
        case USERIDHASHTYPE_TUNNELIPV4DA:
            return "DsUserIdTunnelIpv4DaHashKey";
        case USERIDHASHTYPE_TUNNELMPLS:
            return "DsUserIdTunnelMplsHashKey";
        case USERIDHASHTYPE_SCLFLOWL2:
            return "DsUserIdSclFlowL2HashKey";
        default:
            return "";
    }
}

static int32
_ctc_goldengate_dkit_captured_is_hit(ctc_dkit_captured_path_info_t* path_info)
{
    uint32 cmd = 0;
    uint32 value = 0;

    ctc_dkit_captured_path_info_t* p_info = (ctc_dkit_captured_path_info_t*)path_info;
    uint8 lchip = path_info->lchip;

    if (NULL == p_info)
    {
        return CLI_ERROR;
    }

    /*1. IPE*/
    cmd = DRV_IOR(DbgIpeLkpMgrInfo_t, DbgIpeLkpMgrInfo_ipeLkpMgrInfoValid_f);
    DRV_IOCTL(lchip, 0, cmd, &value);
    if (value)
    {
        p_info->slice_ipe = 0;
        p_info->is_ipe_captured = 1;
    }

    if (p_info->is_ipe_captured)
    {

        cmd = DRV_IOR(DbgIpeOamInfo_t, DbgIpeOamInfo_ipeOamInfoTempRxOamType_f);
        DRV_IOCTL(lchip, p_info->slice_ipe, cmd, &value);
        p_info->rx_oam = 1;
    }

    /*2. EPE*/
    cmd = DRV_IOR(DbgEpeHdrAdjInfo_t, DbgEpeHdrAdjInfo_epeHdrAdjInfoValid_f);
    DRV_IOCTL(lchip, 0, cmd, &value);
    if (value)
    {
        p_info->slice_epe = 0;
        p_info->is_epe_captured = 1;
    }

    /*3. BSR*/
    cmd = DRV_IOR(DbgFwdBufStoreInfo_t, DbgFwdBufStoreInfo_fwdBufStoreInfoValid_f);
    DRV_IOCTL(lchip, 0, cmd, &value);
    if (value)
    {
        p_info->is_bsr_captured = 1;
    }

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_parser(ctc_dkit_captured_path_info_t* p_info, uint8 type)
{
    uint32 cmd = 0;
    uint8 slice = p_info->slice_ipe;
    uint8 lchip = p_info->lchip;
    uint8 idx1  = 0;
    char* str_parser[] = {"1st", "2nd", "epe"};
    char* str_l3_type[] = {"NONE", "IP", "IPV4", "IPV6", "MPLS", "MPLSUP", "ARP", "FCOE", "TRILL",
                           "ETHEROAM", "SLOWPROTO", "CMAC", "PTP", "DOT1AE", "SATPDU", "FLEXIBLE"};
    char buf[CTC_DKIT_IPV6_ADDR_STR_LEN] = {0};
    uint32 temp_data = 0;
    ipv6_addr_t ip6_address = {0};
    mac_addr_t    mac_address = {0};
    hw_mac_addr_t hw_mac_da = {0};
    hw_mac_addr_t hw_mac_sa = {0};
    uint32      svlan_valid = 0;
    uint32      svlan_id    = 0;
    uint32      stag_cfi    = 0;
    uint32      stag_cos    = 0;
    uint32      cvlan_valid = 0;
    uint32      cvlan_id    = 0;
    uint32      ctag_cfi    = 0;
    uint32      ctag_cos    = 0;
    uint32      ether_type  = 0;
    uint32      gre_flags   = 0;
    uint32      gre_proto_type = 0;
    uint32      layer3_type = 0;
    uint32      layer4_type = 0;
    uint32      l4_src_port = 0;
    uint32      l4_dst_port = 0;
    ipv6_addr_t hw_ip6_da   = {0};
    ipv6_addr_t hw_ip6_sa   = {0};
    uint32      ip4_da      = 0;
    uint32      ip4_sa      = 0;
    uint32      ip_proto    = 0;
    uint32      mpls_label[8] = {0};
    uint32      mpls_label_num = 0;
    uint32      arp_op_code  = 0;
    uint32      arp_proto_type = 0;
    uint32      arp_target_ip = 0;
    hw_mac_addr_t arp_target_mac = {0};
    uint32      arp_sender_ip = 0;
    hw_mac_addr_t arp_sender_mac = {0};
    uint32      fcoe_did    = 0;
    uint32      fcoe_sid    = 0;
    uint32      trill_egress_nickname = 0;
    uint32      trill_ingress_nickname = 0;
    uint32      trill_is_esadi = 0;
    uint32      trill_is_bfd_echo = 0;
    uint32      trill_is_bfd = 0;
    uint32      trill_is_channel = 0;
    uint32      trill_bfd_my_discriminator = 0;
    uint32      trill_inner_vlan_id = 0;
    uint32      trill_inner_vlan_valid = 0;
    uint32      trill_length = 0;
    uint32      trill_multi_hop = 0;
    uint32      trill_multi_cast = 0;
    uint32      trill_version = 0;
    uint32      ether_oam_op_code = 0;
    uint32      ether_oam_level = 0;
    uint32      ether_oam_version = 0;
    uint32      slow_proto_code = 0;
    uint32      slow_proto_flags = 0;
    uint32      slow_proto_subtype = 0;
    uint32      ptp_msg = 0;
    uint32      ptp_version = 0;
    uint32      dot1ae_an = 0;
    uint32      dot1ae_es = 0;
    uint32      dot1ae_pn = 0;
    uint32      dot1ae_sc = 0;
    uint8       dot1ae_sci[9] = {'\0'};
    uint32      dot1ae_sl = 0;
    uint32      dot1ae_unknow = 0;
    uint32      satpdu_mef_oui = 0;
    uint32      satpdu_oui_subtype = 0;
    uint32      satpdu_pdu_byte[2] = {0};
    uint32      flex_data[2] = {0};
    uint32      udf_valid = 0;
    uint32      udf_hit_index = 0;
    uint32      parser_valid = 0;
    uint32      second_parser_en = 0;

    DbgParserFromIpeHdrAdjInfo_m parser_result;
    sal_memset(&parser_result, 0, sizeof(DbgParserFromIpeHdrAdjInfo_m));
    if(0 == type)       /*ipe 1st parser*/
    {
        cmd = DRV_IOR(DbgParserFromIpeHdrAdjInfo_t, DRV_ENTRY_FLAG);
    }
    else if(1 == type)  /*ipe 2nd parser*/
    {
        cmd = DRV_IOR(DbgIpeMplsDecapInfo_t, DbgIpeMplsDecapInfo_ipeMplsDecapInfoSecondParserEn_f);
        DRV_IOCTL(lchip, slice, cmd, &second_parser_en);
        if(!second_parser_en)
        {
            return CLI_SUCCESS;
        }
        cmd = DRV_IOR(DbgParserFromIpeIntfInfo_t, DRV_ENTRY_FLAG);
    }
    else if(2 == type)  /*epe parser*/
    {
        cmd = DRV_IOR(DbgParserFromEpeHdrAdjInfo_t, DRV_ENTRY_FLAG);
    }
    DRV_IOCTL(lchip, slice, cmd, &parser_result);

    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoValid_f, &parser_result, &parser_valid);
    if(!parser_valid)
    {
        return CLI_SUCCESS;
    }
    CTC_DKIT_PRINT("%s Parser Result:\n", str_parser[type]);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoMacDa_f,        &parser_result, &hw_mac_da);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoMacSa_f,        &parser_result, &hw_mac_sa);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoSvlanIdValid_f, &parser_result, &svlan_valid);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoSvlanId_f,      &parser_result, &svlan_id);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoStagCos_f,      &parser_result, &stag_cos);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoStagCfi_f,      &parser_result, &stag_cfi);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoCvlanIdValid_f, &parser_result, &cvlan_valid);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoCvlanId_f,      &parser_result, &cvlan_id);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoCtagCos_f,      &parser_result, &ctag_cos);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoCtagCfi_f,      &parser_result, &ctag_cfi);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoEtherType_f,                    &parser_result, &ether_type);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoLayer3Type_f,                   &parser_result, &layer3_type);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoLayer4Type_f,                   &parser_result, &layer4_type);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoLayer3HeaderProtocol_f,         &parser_result, &ip_proto);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL4Source_gGre_greFlags_f,      &parser_result, &gre_flags);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL4Dest_gGre_greProtocolType_f, &parser_result, &gre_proto_type);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL4Dest_gPort_l4DestPort_f,     &parser_result, &l4_dst_port);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL4Source_gPort_l4SourcePort_f, &parser_result, &l4_src_port);
    /*L3TYPE_IPV4*/
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gIpv4_ipDa_f,   &parser_result, &ip4_da);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Source_gIpv4_ipSa_f, &parser_result, &ip4_sa);
    /*L3TYPE_IPV6*/
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gIpv6_ipDa_f,   &parser_result, &hw_ip6_da);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Source_gIpv6_ipSa_f, &parser_result, &hw_ip6_sa);
    /*L3TYPE_MPLS*/
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gMpls_mplsLabel0_f,   &parser_result, &mpls_label[0]);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gMpls_mplsLabel1_f,   &parser_result, &mpls_label[1]);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gMpls_mplsLabel2_f,   &parser_result, &mpls_label[2]);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gMpls_mplsLabel3_f,   &parser_result, &mpls_label[3]);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Source_gMpls_mplsLabel4_f, &parser_result, &mpls_label[4]);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Source_gMpls_mplsLabel5_f, &parser_result, &mpls_label[5]);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Source_gMpls_mplsLabel6_f, &parser_result, &mpls_label[6]);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Source_gMpls_mplsLabel7_f, &parser_result, &mpls_label[7]);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Tos_gMpls_labelNum_f,      &parser_result, &mpls_label_num);
    /*L3TYPE_MPLSUP*/

    /*L3TYPE_ARP*/
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gArp_arpOpCode_f,      &parser_result, &arp_op_code);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Source_gArp_protocolType_f, &parser_result, &arp_proto_type);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gArp_targetIp_f,       &parser_result, &arp_target_ip);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gArp_targetMac_f,      &parser_result, &arp_target_mac);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Source_gArp_senderIp_f,     &parser_result, &arp_sender_ip);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Source_gArp_senderMac_f,    &parser_result, &arp_sender_mac);
    /*L3TYPE_FCOE*/
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gFcoe_fcoeDid_f,    &parser_result, &fcoe_did);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Source_gFcoe_fcoeSid_f,  &parser_result, &fcoe_sid);
    /*L3TYPE_TRILL*/
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gTrill_egressNickname_f         , &parser_result, &trill_egress_nickname);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Source_gTrill_ingressNickname_f      , &parser_result, &trill_ingress_nickname);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gTrill_isEsadi_f                , &parser_result, &trill_is_esadi);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gTrill_isTrillBfdEcho_f         , &parser_result, &trill_is_bfd_echo);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gTrill_isTrillBfd_f             , &parser_result, &trill_is_bfd);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gTrill_isTrillChannel_f         , &parser_result, &trill_is_channel);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gTrill_trillBfdMyDiscriminator_f, &parser_result, &trill_bfd_my_discriminator);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gTrill_trillInnerVlanId_f       , &parser_result, &trill_inner_vlan_id);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gTrill_trillInnerVlanValid_f    , &parser_result, &trill_inner_vlan_valid);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gTrill_trillLength_f            , &parser_result, &trill_length);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gTrill_trillMultiHop_f          , &parser_result, &trill_multi_hop);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gTrill_trillMulticast_f         , &parser_result, &trill_multi_cast);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gTrill_trillVersion_f           , &parser_result, &trill_version);
    /*L3TYPE_ETHEROAM*/
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gEtherOam_etherOamLevel_f,   &parser_result, &ether_oam_level);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gEtherOam_etherOamOpCode_f,  &parser_result, &ether_oam_op_code);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gEtherOam_etherOamVersion_f, &parser_result, &ether_oam_version);
    /*L3TYPE_SLOWPROTO*/
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gSlowProto_slowProtocolCode_f,    &parser_result, &slow_proto_code);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gSlowProto_slowProtocolFlags_f,   &parser_result, &slow_proto_flags);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gSlowProto_slowProtocolSubType_f, &parser_result, &slow_proto_subtype);
    /*L3TYPE_CMAC*/

    /*L3TYPE_PTP*/
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gPtp_ptpMessageType_f, &parser_result, &ptp_msg);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gPtp_ptpVersion_f,     &parser_result, &ptp_version);
    /*L3TYPE_DOT1AE*/
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gDot1Ae_secTagAn_f,            &parser_result, &dot1ae_an);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gDot1Ae_secTagEs_f,            &parser_result, &dot1ae_es);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gDot1Ae_secTagPn_f,            &parser_result, &dot1ae_pn);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gDot1Ae_secTagSc_f,            &parser_result, &dot1ae_sc);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gDot1Ae_secTagSci_f,           &parser_result, &dot1ae_sci);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gDot1Ae_secTagSl_f,            &parser_result, &dot1ae_sl);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gDot1Ae_unknownDot1AePacket_f, &parser_result, &dot1ae_unknow);
    /*L3TYPE_SATPDU*/
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gSatPdu_mefOui_f,     &parser_result, &satpdu_mef_oui);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gSatPdu_ouiSubType_f, &parser_result, &satpdu_oui_subtype);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gSatPdu_pduByte_f,    &parser_result, &satpdu_pdu_byte);
    /*L3TYPE_FLEXIBLE*/
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUL3Dest_gFlexL3_flexData_f,    &parser_result, &flex_data);
    /*UDF*/
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUdfValid_f,    &parser_result, &udf_valid);
    GetDbgParserFromIpeHdrAdjInfo(A, parserFromIpeHdrAdjInfoUdfHitIndex_f, &parser_result, &udf_hit_index);


    CTC_DKIT_SET_USER_MAC(mac_address, hw_mac_da);
    CTC_DKIT_PATH_PRINT("mac-da:           %.4x.%.4x.%.4x\n", sal_ntohs(*(unsigned short*)&mac_address[0]),
                            sal_ntohs(*(unsigned short*)&mac_address[2]),
                            sal_ntohs(*(unsigned short*)&mac_address[4]));
    CTC_DKIT_SET_USER_MAC(mac_address, hw_mac_sa);
    CTC_DKIT_PATH_PRINT("mac-sa:           %.4x.%.4x.%.4x\n", sal_ntohs(*(unsigned short*)&mac_address[0]),
                            sal_ntohs(*(unsigned short*)&mac_address[2]),
                            sal_ntohs(*(unsigned short*)&mac_address[4]));
    if(svlan_valid)
    {
        CTC_DKIT_PATH_PRINT("svlan id:         %d\n", svlan_id);
        CTC_DKIT_PATH_PRINT("stag-cos:         %d\n", stag_cos);
    }
    if(cvlan_valid)
    {
        CTC_DKIT_PATH_PRINT("cvlan id:         %d\n", cvlan_id);
        CTC_DKIT_PATH_PRINT("ctag-cos:         %d\n", ctag_cos);
    }
    CTC_DKIT_PATH_PRINT("ether-type:       0x%04X\n", ether_type);
    CTC_DKIT_PATH_PRINT("layer3-type:      L3TYPE_%s\n", str_l3_type[layer3_type]);
    switch(layer3_type)
    {
    case L3TYPE_IPV4:
        temp_data = sal_ntohl(ip4_da);
        sal_inet_ntop(AF_INET, &temp_data, buf, CTC_DKIT_IPV6_ADDR_STR_LEN);
        CTC_DKIT_PATH_PRINT("ip-da:            %-30s\n", buf);
        temp_data = sal_ntohl(ip4_sa);
        sal_inet_ntop(AF_INET, &temp_data, buf, CTC_DKIT_IPV6_ADDR_STR_LEN);
        CTC_DKIT_PATH_PRINT("ip-sa:            %-30s\n", buf);
        CTC_DKIT_PATH_PRINT("ip-protocol:      %u\n", ip_proto);
        break;
    case L3TYPE_IPV6:
        ip6_address[0] = sal_ntohl(hw_ip6_da[3]);
        ip6_address[1] = sal_ntohl(hw_ip6_da[2]);
        ip6_address[2] = sal_ntohl(hw_ip6_da[1]);
        ip6_address[3] = sal_ntohl(hw_ip6_da[0]);
        sal_inet_ntop(AF_INET6, ip6_address, buf, CTC_DKIT_IPV6_ADDR_STR_LEN);
        CTC_DKIT_PATH_PRINT("ip6-da:           %-44s\n", buf);
        ip6_address[0] = sal_ntohl(hw_ip6_sa[3]);
        ip6_address[1] = sal_ntohl(hw_ip6_sa[2]);
        ip6_address[2] = sal_ntohl(hw_ip6_sa[1]);
        ip6_address[3] = sal_ntohl(hw_ip6_sa[0]);
        sal_inet_ntop(AF_INET6, ip6_address, buf, CTC_DKIT_IPV6_ADDR_STR_LEN);
        CTC_DKIT_PATH_PRINT("ip6-sa:           %-44s\n", buf);
        CTC_DKIT_PATH_PRINT("ip-protocol:      %u\n", ip_proto);
        break;
    case L3TYPE_MPLS:
        CTC_DKIT_PATH_PRINT("label-num:       %d\n", mpls_label_num);
        for(idx1 = 0; idx1 < mpls_label_num; idx1++)
        {
            CTC_DKIT_PATH_PRINT("mpls-label%d:      0x%X\n", idx1, mpls_label[idx1]);
        }
        break;
    case L3TYPE_MPLSUP:
        break;
    case L3TYPE_ARP:
        CTC_DKIT_PATH_PRINT("arp-op-code:      0x%04x\n", arp_op_code);
        CTC_DKIT_PATH_PRINT("arp-proto-type:   0x%04x\n", arp_proto_type);
        temp_data = sal_ntohl(arp_target_ip);
        sal_inet_ntop(AF_INET, &temp_data, buf, CTC_DKIT_IPV6_ADDR_STR_LEN);
        CTC_DKIT_PATH_PRINT("arp-target-ip:    %-30s\n", buf);
        temp_data = sal_ntohl(arp_sender_ip);
        sal_inet_ntop(AF_INET, &temp_data, buf, CTC_DKIT_IPV6_ADDR_STR_LEN);
        CTC_DKIT_PATH_PRINT("arp-sender-ip:    %-30s\n", buf);
        CTC_DKIT_SET_USER_MAC(mac_address, arp_target_mac);
        CTC_DKIT_PATH_PRINT("arp-target-mac:   %.4x.%.4x.%.4x\n", sal_ntohs(*(unsigned short*)&mac_address[0]),
                                sal_ntohs(*(unsigned short*)&mac_address[2]),
                                sal_ntohs(*(unsigned short*)&mac_address[4]));
        CTC_DKIT_SET_USER_MAC(mac_address, arp_sender_mac);
        CTC_DKIT_PATH_PRINT("arp-sender-mac:   %.4x.%.4x.%.4x\n", sal_ntohs(*(unsigned short*)&mac_address[0]),
                                sal_ntohs(*(unsigned short*)&mac_address[2]),
                                sal_ntohs(*(unsigned short*)&mac_address[4]));
        break;
    case L3TYPE_FCOE:
        CTC_DKIT_PATH_PRINT("fcoe-did:         %u\n", fcoe_did);
        CTC_DKIT_PATH_PRINT("fcoe-sid:         %u\n", fcoe_sid);
        break;
    case L3TYPE_TRILL:
        CTC_DKIT_PATH_PRINT("ingress-nickname: %u\n", trill_ingress_nickname);
        CTC_DKIT_PATH_PRINT("egress-nickname:  %u\n", trill_egress_nickname);
        CTC_DKIT_PATH_PRINT("is-bfd-echo:      %u\n", trill_is_bfd_echo);
        CTC_DKIT_PATH_PRINT("trill-isesadi:    %u\n", trill_is_esadi);
        CTC_DKIT_PATH_PRINT("is-bfd-echo:      %u\n", trill_is_bfd_echo);
        CTC_DKIT_PATH_PRINT("is-bfd:           %u\n", trill_is_bfd);
        CTC_DKIT_PATH_PRINT("is-channel:       %u\n", trill_is_channel);
        CTC_DKIT_PATH_PRINT("bfd-my-discrim:   %u\n", trill_bfd_my_discriminator);
        CTC_DKIT_PATH_PRINT("inner-vlan-id:    %u\n", trill_inner_vlan_id);
        CTC_DKIT_PATH_PRINT("inner-vlan-valid: %u\n", trill_inner_vlan_valid);
        CTC_DKIT_PATH_PRINT("trill-length:     %u\n", trill_length);
        CTC_DKIT_PATH_PRINT("multi-hop:        %u\n", trill_multi_hop);
        CTC_DKIT_PATH_PRINT("trill-multicast:  %u\n", trill_multi_cast);
        CTC_DKIT_PATH_PRINT("trill-version:    %u\n", trill_version);
        break;
    case L3TYPE_ETHEROAM:
        CTC_DKIT_PATH_PRINT("ether-oam-level:  %u\n", ether_oam_level);
        CTC_DKIT_PATH_PRINT("ether-oam-op-code:%u\n", ether_oam_op_code);
        CTC_DKIT_PATH_PRINT("ether-oam-version:%u\n", ether_oam_version);
        break;
    case L3TYPE_SLOWPROTO:
        CTC_DKIT_PATH_PRINT("slow-proto-code:  %u\n", slow_proto_code);
        CTC_DKIT_PATH_PRINT("slow-proto-flags: %u\n", slow_proto_flags);
        CTC_DKIT_PATH_PRINT("slow-proto-subtype:%u\n", slow_proto_subtype);
        break;
    case L3TYPE_CMAC:
        break;
    case L3TYPE_PTP:
        CTC_DKIT_PATH_PRINT("ptp-message:      %u\n", ptp_msg);
        CTC_DKIT_PATH_PRINT("ptp-version:      %u\n", ptp_version);
        break;
    case L3TYPE_DOT1AE:
        CTC_DKIT_PATH_PRINT("dot1ae-an:        %u\n", dot1ae_an);
        CTC_DKIT_PATH_PRINT("dot1ae-es:        %u\n", dot1ae_es);
        CTC_DKIT_PATH_PRINT("dot1ae-pn:        %u\n", dot1ae_pn);
        CTC_DKIT_PATH_PRINT("dot1ae-sc:        %u\n", dot1ae_sc);
        CTC_DKIT_PATH_PRINT("dot1ae-sci:       %s\n", dot1ae_sci);
        CTC_DKIT_PATH_PRINT("dot1ae-sl:        %u\n", dot1ae_sl);
        CTC_DKIT_PATH_PRINT("dot1ae-unknow:    %u\n", dot1ae_unknow);
        break;
    case L3TYPE_SATPDU:
        CTC_DKIT_PATH_PRINT("satpdu-mef-oui:   %u\n", satpdu_mef_oui);
        CTC_DKIT_PATH_PRINT("satpdu-oui-subtype:%u\n", satpdu_oui_subtype);
        CTC_DKIT_PATH_PRINT("satpdu-pdu-byte:  0x%08x%08x\n", satpdu_pdu_byte[1], satpdu_pdu_byte[0]);
        break;
    case L3TYPE_FLEXIBLE:
        CTC_DKIT_PATH_PRINT("flex-data:        0x%08x%08x\n", satpdu_pdu_byte[1], satpdu_pdu_byte[0]);
        break;
    default:
        break;
    }
    if(L4TYPE_GRE == layer4_type)
    {
        CTC_DKIT_PATH_PRINT("gre-flags:        0x%x\n", gre_flags);
        CTC_DKIT_PATH_PRINT("gre-proto-type:   0x%x\n", gre_proto_type);
    }
    else if((layer4_type == L4TYPE_TCP) || (layer4_type == L4TYPE_UDP) || (layer4_type == L4TYPE_RDP)
                || (layer4_type == L4TYPE_SCTP) || (layer4_type == L4TYPE_DCCP))
    {
        CTC_DKIT_PATH_PRINT("l4-src-port:      %u\n", l4_src_port);
        CTC_DKIT_PATH_PRINT("l4-dst-port:      %u\n", l4_dst_port);
    }

    if(udf_valid)
    {
        CTC_DKIT_PATH_PRINT("\nudf-valid:      %u\n", udf_valid);
        CTC_DKIT_PATH_PRINT("udf-hit-index:   %u\n", udf_hit_index);
    }

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_capture_path_ipe_bridge(ctc_dkit_captured_path_info_t* p_info)
{
    uint32 cmd = 0;
    uint32 discard = 0;
    uint32 discard_type = 0;
    uint32 exceptionEn = 0;
    uint32 exceptionIndex = 0;
    uint32 exceptionSubIndex = 0;

    /*DbgFibLkpEngineMacDaHashInfo*/
    uint32 macda_blackHoleMacDaResultValid = 0;
    uint32 macda_blackHoleHitMacDaKeyIndex = 0;
    uint32 macda_macDaHashResultValid = 0;
    uint32 macda_macDaHashLookupConflict = 0;
    uint32 macda_hitHashKeyIndexMacDa = 0;
    uint32 macda_valid = 0;
    DbgFibLkpEngineMacDaHashInfo_m dbg_fib_lkp_engine_mac_da_hash_info;

    /*DbgFibLkpEngineMacSaHashInfo*/
    uint32 macsa_blackHoleMacSaResultValid = 0;
    uint32 macsa_blackHoleHitMacSaKeyIndex = 0;
    uint32 macsa_macSaHashResultValid = 0;
    uint32 macsa_macSaHashLookupConflict = 0;
    uint32 macsa_hitHashKeyIndexMacSa = 0;
    uint32 macsa_valid = 0;
    DbgFibLkpEngineMacSaHashInfo_m dbg_fib_lkp_engine_mac_sa_hash_info;

    /*DbgIpeMacBridgingInfo*/
    uint32 bridge_macDaResultValid = 0;
    uint32 bridge_macDaDefaultEntryValid = 0;
    uint32 bridge_macDaIsPortMac = 0;
    uint32 bridge_discard = 0;
    uint32 bridge_discardType = 0;
    uint32 bridge_dsFwdPtr = 0;
    uint32 bridge_exceptionEn = 0;
    uint32 bridge_exceptionIndex = 0;
    uint32 bridge_exceptionSubIndex = 0;
    uint32 bridge_bridgePacket = 0;
    uint32 bridge_bridgeEscape = 0;
    uint32 bridge_stormCtlEn = 0;
    uint32 bridge_valid = 0;
    DbgIpeMacBridgingInfo_m dbg_ipe_mac_bridging_info;

    /*DbgIpeMacLearningInfo*/
    uint32 lrn_macSaResultPending = 0;
    uint32 lrn_macSaDefaultEntryValid = 0;
    uint32 lrn_macSaHashConflict = 0;
    uint32 lrn_macSaResultValid = 0;
    uint32 lrn_macSaLookupEn = 0;
    uint32 lrn_isInnerMacSaLookup = 0;
    uint32 lrn_fid = 0;
    uint32 lrn_learningSrcPort = 0;
    uint32 lrn_isGlobalSrcPort = 0;
    uint32 lrn_macSecurityDiscard = 0;
    uint32 lrn_learningEn = 0;
    uint32 lrn_discard = 0;
    uint32 lrn_discardType = 0;
    uint32 lrn_valid = 0;
    DbgIpeMacLearningInfo_m dbg_ipe_mac_learning_info;

    uint32 lkp_macDaLookupEn = 0;
    uint32 fid = 0;
    uint32 sa_fid = 0;
    uint32 ad_index = 0;
    uint32 defaultEntryBase = 0;
    uint32 lkp_macSaLookupEn = 0;
    uint32 lrn_type = 0;
    uint32 aging_ptr = 0;

    drv_acc_in_t  in;
    drv_acc_out_t out;

    uint8 lchip = p_info->lchip;

    sal_memset(&in, 0, sizeof(drv_acc_in_t));
    sal_memset(&out, 0, sizeof(drv_acc_out_t));

    /*DbgFibLkpEngineMacDaHashInfo*/
    sal_memset(&dbg_fib_lkp_engine_mac_da_hash_info, 0, sizeof(dbg_fib_lkp_engine_mac_da_hash_info));
    cmd = DRV_IOR(DbgFibLkpEngineMacDaHashInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_fib_lkp_engine_mac_da_hash_info);
    GetDbgFibLkpEngineMacDaHashInfo(A, fibLkpEngineMacDaHashInfoBlackHoleMacDaResultValid_f, &dbg_fib_lkp_engine_mac_da_hash_info, &macda_blackHoleMacDaResultValid);
    GetDbgFibLkpEngineMacDaHashInfo(A, fibLkpEngineMacDaHashInfoBlackHoleHitMacDaKeyIndex_f, &dbg_fib_lkp_engine_mac_da_hash_info, &macda_blackHoleHitMacDaKeyIndex);
    GetDbgFibLkpEngineMacDaHashInfo(A, fibLkpEngineMacDaHashInfoGMacDaLkpResult_macDaResultValid_f, &dbg_fib_lkp_engine_mac_da_hash_info, &macda_macDaHashResultValid);
    GetDbgFibLkpEngineMacDaHashInfo(A, fibLkpEngineMacDaHashInfoGMacDaLkpResult_macDaHashConflict_f, &dbg_fib_lkp_engine_mac_da_hash_info, &macda_macDaHashLookupConflict);
    GetDbgFibLkpEngineMacDaHashInfo(A, fibLkpEngineMacDaHashInfoGMacDaLkpResult_macDaHashKeyHitIndex_f, &dbg_fib_lkp_engine_mac_da_hash_info, &macda_hitHashKeyIndexMacDa);
    GetDbgFibLkpEngineMacDaHashInfo(A, fibLkpEngineMacDaHashInfoGMacDaLkp_macDaLookupEn_f, &dbg_fib_lkp_engine_mac_da_hash_info, &lkp_macDaLookupEn);
    GetDbgFibLkpEngineMacDaHashInfo(A, fibLkpEngineMacDaHashInfoValid_f, &dbg_fib_lkp_engine_mac_da_hash_info, &macda_valid);
    GetDbgFibLkpEngineMacDaHashInfo(A, fibLkpEngineMacDaHashInfoGMacDaLkp_vsiId_f, &dbg_fib_lkp_engine_mac_da_hash_info, &fid);

    /*DbgFibLkpEngineMacSaHashInfo*/
    sal_memset(&dbg_fib_lkp_engine_mac_sa_hash_info, 0, sizeof(dbg_fib_lkp_engine_mac_sa_hash_info));
    cmd = DRV_IOR(DbgFibLkpEngineMacSaHashInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_fib_lkp_engine_mac_sa_hash_info);
    GetDbgFibLkpEngineMacSaHashInfo(A, fibLkpEngineMacSaHashInfoBlackHoleMacSaResultValid_f, &dbg_fib_lkp_engine_mac_sa_hash_info, &macsa_blackHoleMacSaResultValid);
    GetDbgFibLkpEngineMacSaHashInfo(A, fibLkpEngineMacSaHashInfoBlackHoleHitMacSaKeyIndex_f, &dbg_fib_lkp_engine_mac_sa_hash_info, &macsa_blackHoleHitMacSaKeyIndex);
    GetDbgFibLkpEngineMacSaHashInfo(A, fibLkpEngineMacSaHashInfoGMacSaLkpResult_macSaResultValid_f, &dbg_fib_lkp_engine_mac_sa_hash_info, &macsa_macSaHashResultValid);
    GetDbgFibLkpEngineMacSaHashInfo(A, fibLkpEngineMacSaHashInfoGMacSaLkpResult_macSaHashConflict_f, &dbg_fib_lkp_engine_mac_sa_hash_info, &macsa_macSaHashLookupConflict);
    GetDbgFibLkpEngineMacSaHashInfo(A, fibLkpEngineMacSaHashInfoGMacSaLkpResult_macSaHashKeyHitIndex_f, &dbg_fib_lkp_engine_mac_sa_hash_info, &macsa_hitHashKeyIndexMacSa);
    GetDbgFibLkpEngineMacSaHashInfo(A, fibLkpEngineMacSaHashInfoGMacSaLkp_macSaLookupEn_f, &dbg_fib_lkp_engine_mac_sa_hash_info, &lkp_macSaLookupEn);
    GetDbgFibLkpEngineMacSaHashInfo(A, fibLkpEngineMacSaHashInfoValid_f, &dbg_fib_lkp_engine_mac_sa_hash_info, &macsa_valid);
    GetDbgFibLkpEngineMacSaHashInfo(A, fibLkpEngineMacSaHashInfoGMacSaLkp_vsiId_f, &dbg_fib_lkp_engine_mac_sa_hash_info, &sa_fid);

    /*DbgIpeMacBridgingInfo*/
    sal_memset(&dbg_ipe_mac_bridging_info, 0, sizeof(dbg_ipe_mac_bridging_info));
    cmd = DRV_IOR(DbgIpeMacBridgingInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_ipe_mac_bridging_info);
    GetDbgIpeMacBridgingInfo(A, ipeMacBridgingInfoMacDaResultValid_f, &dbg_ipe_mac_bridging_info, &bridge_macDaResultValid);
    GetDbgIpeMacBridgingInfo(A, ipeMacBridgingInfoMacDaDefaultEntryValid_f, &dbg_ipe_mac_bridging_info, &bridge_macDaDefaultEntryValid);
    GetDbgIpeMacBridgingInfo(A, ipeMacBridgingInfoMacDaIsPortMac_f, &dbg_ipe_mac_bridging_info, &bridge_macDaIsPortMac);
    GetDbgIpeMacBridgingInfo(A, ipeMacBridgingInfoDiscard_f, &dbg_ipe_mac_bridging_info, &bridge_discard);
    GetDbgIpeMacBridgingInfo(A, ipeMacBridgingInfoDiscardType_f, &dbg_ipe_mac_bridging_info, &bridge_discardType);
    GetDbgIpeMacBridgingInfo(A, ipeMacBridgingInfoExceptionEn_f, &dbg_ipe_mac_bridging_info, &bridge_exceptionEn);
    GetDbgIpeMacBridgingInfo(A, ipeMacBridgingInfoExceptionIndex_f, &dbg_ipe_mac_bridging_info, &bridge_exceptionIndex);
    GetDbgIpeMacBridgingInfo(A, ipeMacBridgingInfoExceptionSubIndex_f, &dbg_ipe_mac_bridging_info, &bridge_exceptionSubIndex);
    GetDbgIpeMacBridgingInfo(A, ipeMacBridgingInfoBridgePacket_f, &dbg_ipe_mac_bridging_info, &bridge_bridgePacket);
    GetDbgIpeMacBridgingInfo(A, ipeMacBridgingInfoBridgeEscape_f, &dbg_ipe_mac_bridging_info, &bridge_bridgeEscape);
    GetDbgIpeMacBridgingInfo(A, ipeMacBridgingInfoStormCtlEn_f, &dbg_ipe_mac_bridging_info, &bridge_stormCtlEn);
    GetDbgIpeMacBridgingInfo(A, ipeMacBridgingInfoValid_f, &dbg_ipe_mac_bridging_info, &bridge_valid);

    /*DbgIpeMacLearningInfo*/
    sal_memset(&dbg_ipe_mac_learning_info, 0, sizeof(dbg_ipe_mac_learning_info));
    cmd = DRV_IOR(DbgIpeMacLearningInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_ipe_mac_learning_info);
    GetDbgIpeMacLearningInfo(A, ipeMacLearningInfoMacSaResultPending_f, &dbg_ipe_mac_learning_info, &lrn_macSaResultPending);
    GetDbgIpeMacLearningInfo(A, ipeMacLearningInfoMacSaDefaultEntryValid_f, &dbg_ipe_mac_learning_info, &lrn_macSaDefaultEntryValid);
    GetDbgIpeMacLearningInfo(A, ipeMacLearningInfoMacSaHashConflict_f, &dbg_ipe_mac_learning_info, &lrn_macSaHashConflict);
    GetDbgIpeMacLearningInfo(A, ipeMacLearningInfoMacSaResultValid_f, &dbg_ipe_mac_learning_info, &lrn_macSaResultValid);
    GetDbgIpeMacLearningInfo(A, ipeMacLearningInfoIsInnerMacSaLookup_f, &dbg_ipe_mac_learning_info, &lrn_isInnerMacSaLookup);
    GetDbgIpeMacLearningInfo(A, ipeMacLearningInfoLearningFid_f, &dbg_ipe_mac_learning_info, &lrn_fid);
    GetDbgIpeMacLearningInfo(A, ipeMacLearningInfoLearningSrcPort_f, &dbg_ipe_mac_learning_info, &lrn_learningSrcPort);
    GetDbgIpeMacLearningInfo(A, ipeMacLearningInfoLearningUseGlobalSrcPort_f, &dbg_ipe_mac_learning_info, &lrn_isGlobalSrcPort);
    GetDbgIpeMacLearningInfo(A, ipeMacLearningInfoMacSecurityDiscard_f, &dbg_ipe_mac_learning_info, &lrn_macSecurityDiscard);
    GetDbgIpeMacLearningInfo(A, ipeMacLearningInfoLearningEn_f, &dbg_ipe_mac_learning_info, &lrn_learningEn);
    GetDbgIpeMacLearningInfo(A, ipeMacLearningInfoValid_f, &dbg_ipe_mac_learning_info, &lrn_valid);
    GetDbgIpeMacLearningInfo(A, ipeMacLearningInfoLearningType_f, &dbg_ipe_mac_learning_info, &lrn_type);
    GetDbgIpeMacLearningInfo(A, ipeMacLearningInfoAgingIndex_f, &dbg_ipe_mac_learning_info, &aging_ptr);
    GetDbgIpeMacLearningInfo(A, ipeMacLearningInfoDiscardType_f, &dbg_ipe_mac_learning_info, &lrn_discardType);
    GetDbgIpeMacLearningInfo(A, ipeMacLearningInfoDiscard_f, &dbg_ipe_mac_learning_info, &lrn_discard);

    if (0 == p_info->detail)
    {
        goto Discard;
    }

    /*bridge process*/
    if (bridge_valid)
    {
        if (lkp_macDaLookupEn && bridge_bridgePacket)
        {
            CTC_DKIT_PRINT("Bridge Process:\n");
            CTC_DKIT_PATH_PRINT("%-15s\n", "MAC DA lookup--->");
            if (bridge_macDaResultValid)
            {
                CTC_DKIT_PATH_PRINT("%-15s:%d\n", "FID", fid);
                if (macda_blackHoleMacDaResultValid)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", "hit black hole entry");
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", macda_blackHoleHitMacDaKeyIndex);
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", "DsFibMacBlackHoleHashKey");
                    cmd = DRV_IOR(DsFibMacBlackHoleHashKey_t, DsFibMacBlackHoleHashKey_dsAdIndex_f);
                    DRV_IOCTL(lchip, macda_blackHoleHitMacDaKeyIndex, cmd, &ad_index);
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "AD index", ad_index);
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "AD name", "DsMac");
                }
                else if (bridge_macDaDefaultEntryValid)
                {
                    cmd = DRV_IOR(FibEngineLookupResultCtl_t, FibEngineLookupResultCtl_gMacDaLookupResultCtl_defaultEntryBase_f);
                    DRV_IOCTL(lchip, 0, cmd, &defaultEntryBase);
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_DEFAULT);
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "AD index", (fid + (defaultEntryBase << 8)));
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "AD name", "DsMac");
                }
                else if (macda_valid && macda_macDaHashResultValid)
                {

                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_HASH_HIT);
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", macda_hitHashKeyIndexMacDa);
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", "DsFibHost0MacHashKey");

                    in.type = DRV_ACC_TYPE_LOOKUP;
                    in.tbl_id = DsFibHost0MacHashKey_t;
                    in.index = macda_hitHashKeyIndexMacDa;
                    in.op_type = DRV_ACC_OP_BY_INDEX;
                    drv_acc_api(lchip, &in, &out);

                    drv_get_field(DsFibHost0MacHashKey_t, DsFibHost0MacHashKey_dsAdIndex_f, out.data, &ad_index);
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "AD index", ad_index);
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "AD name", "DsMac");
                }
                else
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
                }
            }
            else
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
            }
        }

        if (lrn_valid && lkp_macSaLookupEn&&bridge_bridgePacket)
        {
            CTC_DKIT_PATH_PRINT("%-15s\n", "MAC SA lookup--->");
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Learning Mode", lrn_type?"Hw Learning":"Sw Leaning");
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "FID", sa_fid);
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "Agong ptr", aging_ptr);

            if (lrn_macSaDefaultEntryValid)
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_DEFAULT);
            }
            else if (lrn_macSaHashConflict)
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_CONFLICT);
            }
            else if (lrn_macSaResultValid)
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_HASH_HIT);
            }
            else
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
            }
            if (lrn_learningEn)
            {
                CTC_DKIT_PATH_PRINT("%-15s\n", "MAC SA learning--->");
                if (lrn_isInnerMacSaLookup)
                {
                    CTC_DKIT_PATH_PRINT("%-15s\n", "Inner MAC SA learning--->");
                }

                CTC_DKIT_PATH_PRINT("%-15s:%d\n", "FID", lrn_fid);
                if (!lrn_isGlobalSrcPort)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "logic port", lrn_learningSrcPort);
                }
                else
                {
                    CTC_DKIT_PATH_PRINT("%-15s:0x%04x\n", "source gport", CTC_DKIT_DRV_GPORT_TO_CTC_GPORT(lrn_learningSrcPort));
                }
            }
        }

    }

    if (bridge_discard)
    {
        discard = 1;
        discard_type = bridge_discardType;
    }
    else if (lrn_discard)
    {
        discard = 1;
        discard_type = lrn_discardType;
    }

    if (bridge_exceptionEn)
    {
        exceptionEn = 1;
        exceptionIndex = bridge_exceptionIndex;
        exceptionSubIndex = bridge_exceptionSubIndex;
    }

Discard:
    _ctc_goldengate_dkit_captured_path_discard_process(p_info, discard, discard_type, CTC_DKIT_IPE);
    _ctc_goldengate_dkit_captured_path_exception_process(p_info, exceptionEn, exceptionIndex, exceptionSubIndex);

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_capture_path_ipe_route(ctc_dkit_captured_path_info_t* p_info)
{
    uint32 discard = 0;
    uint32 discard_type = 0;
    uint32 exceptionEn = 0;
    uint32 exceptionIndex = 0;
    uint32 exceptionSubIndex = 0;
    uint32 cmd = 0;
    uint32 cmd1 = 0;
    uint32 cmd2 = 0;
    uint32 key_index = 0;
    uint32 mapped_key_index = 0;
    uint32 mapped_ad_index = 0;
    uint32 ds_ip_da_idx = 0;
    uint32 pointer = 0;
    uint32 route_l3DaLookupEn = 0;
    uint32 route_l3SaLookupEn = 0;
    uint32 route_l3DaResultValid = 0;
    uint32 route_l3SaResultValid = 0;
    uint32 route_flowForceRouteUseIpSa = 0;
    uint32 route_ipMartianAddress = 0;
    uint32 route_ipLinkScopeAddress = 0;
    uint32 route_packetTtl = 0;
    uint32 route_shareType = 0;
    uint32 route_layer3Exception = 0;
    uint32 route_discard = 0;
    uint32 route_discardType = 0;
    uint32 route_exceptionEn = 0;
    uint32 route_exceptionIndex = 0;
    uint32 route_exceptionSubIndex = 0;
    uint32 route_fatalExceptionValid = 0;
    uint32 route_fatalException = 0;
    uint32 route_payloadPacketType = 0;
    uint32 route_valid = 0;
    DbgIpeIpRoutingInfo_m dbg_ipe_ip_routing_info;

    /*DbgFibLkpEnginel3DaHashInfo*/
    uint32 l3Da_first_hash_ResultValid = 0;
    uint32 l3Da_second_hash_ResultValid = 0;
    uint32 l3Da_first_hitHashKeyIndexl3Da = 0;
    uint32 l3Da_second_hitHashKeyIndexl3Da = 0;
    uint32 l3Da_hashvalid = 0;
    uint32 lpmtcam_lkp1_pri_valid = 0;
    uint32 lpmtcam_lkp1_pub_valid = 0;
    uint32 lpmtcam_lkp2_pri_valid = 0;
    uint32 lpmtcam_lkp2_pub_valid = 0;
    DbgFibLkpEnginel3DaHashInfo_m dbg_fib_lkp_enginel3_da_hash_info;

    /*DbgFibLkpEnginel3SaHashInfo*/
    uint32 l3Sa_l3SaHashResultValid = 0;
    uint32 l3Sa_hitHashKeyIndexl3Sa = 0;
    uint32 l3Sa_hitTcamKeyIndexl3Sa = 0;
    uint32 l3Sa_valid = 0;
    uint32 l3Sa_key_type = 0;
    uint32 l3Sa_nat_tcam = 0;
    uint32 l3Sa_rpf_tcam = 0;

    DbgFibLkpEnginel3SaHashInfo_m dbg_fib_lkp_enginel3_sa_hash_info;
    char* key_name = NULL;
    char* result = NULL;

    uint8 lchip = p_info->lchip;
    uint32 key_type = 0;
    uint32 ad_index = 0;
    uint32 vrf_id = 0;
    uint32 index = 0;
    char* ad_name = NULL;

    /*DbgLpmTcamEngineResult0Info*/
    DbgLpmTcamEngineResult0Info_m dbg_lpm_tcam_res0;
    uint32 grp0_valid[6] = {0};
    uint32 grp0_index[6] = {0};

    /*DbgLpmTcamEngineResult1Info*/
    DbgLpmTcamEngineResult1Info_m dbg_lpm_tcam_res1;
    uint32 grp1_valid[6] = {0};
    uint32 grp1_index[6] = {0};

    uint32 pipeline_valid = 0;
    uint32 lpm_type0 = 0;
    uint32 lpm_type1 = 0;


    /*DbgFibLkpEnginel3DaHashInfo*/
    sal_memset(&dbg_fib_lkp_enginel3_da_hash_info, 0, sizeof(dbg_fib_lkp_enginel3_da_hash_info));
    cmd = DRV_IOR(DbgFibLkpEnginel3DaHashInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_fib_lkp_enginel3_da_hash_info);
    GetDbgFibLkpEnginel3DaHashInfo(A, fibLkpEnginel3DaHashInfoHostHashFirstL3DaResultValid_f,
        &dbg_fib_lkp_enginel3_da_hash_info, &l3Da_first_hash_ResultValid);
    GetDbgFibLkpEnginel3DaHashInfo(A, fibLkpEnginel3DaHashInfoHostHashSecondDaResultValid_f,
        &dbg_fib_lkp_enginel3_da_hash_info, &l3Da_second_hash_ResultValid);
    GetDbgFibLkpEnginel3DaHashInfo(A, fibLkpEnginel3DaHashInfoL3DaLookupEn_f, &dbg_fib_lkp_enginel3_da_hash_info, &route_l3DaLookupEn);
    GetDbgFibLkpEnginel3DaHashInfo(A, fibLkpEnginel3DaHashInfoHostHashFirstL3DaKeyIndex_f,
        &dbg_fib_lkp_enginel3_da_hash_info, &l3Da_first_hitHashKeyIndexl3Da);
    GetDbgFibLkpEnginel3DaHashInfo(A, fibLkpEnginel3DaHashInfoHostHashSecondDaKeyIndex_f,
        &dbg_fib_lkp_enginel3_da_hash_info, &l3Da_second_hitHashKeyIndexl3Da);
    GetDbgFibLkpEnginel3DaHashInfo(A, fibLkpEnginel3DaHashInfoValid_f, &dbg_fib_lkp_enginel3_da_hash_info, &l3Da_hashvalid);
    GetDbgFibLkpEnginel3DaHashInfo(A, fibLkpEnginel3DaHashInfoL3DaKeyType_f, &dbg_fib_lkp_enginel3_da_hash_info, &key_type);
    GetDbgFibLkpEnginel3DaHashInfo(A, fibLkpEnginel3DaHashInfoVrfId_f, &dbg_fib_lkp_enginel3_da_hash_info, &vrf_id);
    GetDbgFibLkpEnginel3DaHashInfo(A, fibLkpEnginel3DaHashInfoL3DaAdindexForDebug_f, &dbg_fib_lkp_enginel3_da_hash_info, &ad_index);

    /*lpm info*/
    GetDbgFibLkpEnginel3DaHashInfo(A, fibLkpEnginel3DaHashInfoL3DaTcamLookup1PrivateResultValid_f,
            &dbg_fib_lkp_enginel3_da_hash_info, &lpmtcam_lkp1_pri_valid);
    GetDbgFibLkpEnginel3DaHashInfo(A, fibLkpEnginel3DaHashInfoL3DaTcamLookup1PublicResultValid_f,
            &dbg_fib_lkp_enginel3_da_hash_info, &lpmtcam_lkp1_pub_valid);
    GetDbgFibLkpEnginel3DaHashInfo(A, fibLkpEnginel3DaHashInfoL3DaTcamLookup2PrivateResultValid_f,
            &dbg_fib_lkp_enginel3_da_hash_info, &lpmtcam_lkp2_pri_valid);
    GetDbgFibLkpEnginel3DaHashInfo(A, fibLkpEnginel3DaHashInfoL3DaTcamLookup2PublicResultValid_f,
            &dbg_fib_lkp_enginel3_da_hash_info, &lpmtcam_lkp2_pub_valid);

    /*DbgFibLkpEnginel3SaHashInfo*/
    sal_memset(&dbg_fib_lkp_enginel3_sa_hash_info, 0, sizeof(dbg_fib_lkp_enginel3_sa_hash_info));
    cmd = DRV_IOR(DbgFibLkpEnginel3SaHashInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_fib_lkp_enginel3_sa_hash_info);
    GetDbgFibLkpEnginel3SaHashInfo(A, fibLkpEnginel3SaHashInfoL3SaResultValid_f, &dbg_fib_lkp_enginel3_sa_hash_info, &l3Sa_l3SaHashResultValid);
    GetDbgFibLkpEnginel3SaHashInfo(A, fibLkpEnginel3SaHashInfoL3SaLookupEn_f, &dbg_fib_lkp_enginel3_sa_hash_info, &route_l3SaLookupEn);
    GetDbgFibLkpEnginel3SaHashInfo(A, fibLkpEnginel3SaHashInfoValid_f, &dbg_fib_lkp_enginel3_sa_hash_info, &l3Sa_valid);
    GetDbgFibLkpEnginel3SaHashInfo(A, fibLkpEnginel3SaHashInfoL3SaKeyType_f, &dbg_fib_lkp_enginel3_sa_hash_info, &l3Sa_key_type);
    GetDbgFibLkpEnginel3SaHashInfo(A, fibLkpEnginel3SaHashInfoHostHashFirstSaNatTcamResultValid_f,
        &dbg_fib_lkp_enginel3_sa_hash_info, &l3Sa_nat_tcam);
    GetDbgFibLkpEnginel3SaHashInfo(A, fibLkpEnginel3SaHashInfoHostHashFirstSaRpfTcamResultValid_f,
        &dbg_fib_lkp_enginel3_sa_hash_info, &l3Sa_rpf_tcam);
    GetDbgFibLkpEnginel3SaHashInfo(A, fibLkpEnginel3SaHashInfoHostHashSecondSaKeyIndex_f,
        &dbg_fib_lkp_enginel3_sa_hash_info, &l3Sa_hitHashKeyIndexl3Sa);
    GetDbgFibLkpEnginel3SaHashInfo(A, fibLkpEnginel3SaHashInfoHostHashFirstSaTcamHitIndex_f,
        &dbg_fib_lkp_enginel3_sa_hash_info, &l3Sa_hitTcamKeyIndexl3Sa);
    /*DbgIpeIpRoutingInfo*/
    sal_memset(&dbg_ipe_ip_routing_info, 0, sizeof(dbg_ipe_ip_routing_info));
    cmd = DRV_IOR(DbgIpeIpRoutingInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_ipe_ip_routing_info);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoIpDaResultValid_f, &dbg_ipe_ip_routing_info, &route_l3DaResultValid);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoIpSaResultValid_f, &dbg_ipe_ip_routing_info, &route_l3SaResultValid);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoFlowForceRouteUseIpSa_f, &dbg_ipe_ip_routing_info, &route_flowForceRouteUseIpSa);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoIpMartianAddress_f, &dbg_ipe_ip_routing_info, &route_ipMartianAddress);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoIpLinkScopeAddress_f, &dbg_ipe_ip_routing_info, &route_ipLinkScopeAddress);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoPacketTtl_f, &dbg_ipe_ip_routing_info, &route_packetTtl);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoShareType_f, &dbg_ipe_ip_routing_info, &route_shareType);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoLayer3Exception_f, &dbg_ipe_ip_routing_info, &route_layer3Exception);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoDiscard_f, &dbg_ipe_ip_routing_info, &route_discard);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoDiscardType_f, &dbg_ipe_ip_routing_info, &route_discardType);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoExceptionEn_f, &dbg_ipe_ip_routing_info, &route_exceptionEn);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoExceptionIndex_f, &dbg_ipe_ip_routing_info, &route_exceptionIndex);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoExceptionSubIndex_f, &dbg_ipe_ip_routing_info, &route_exceptionSubIndex);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoFatalExceptionValid_f, &dbg_ipe_ip_routing_info, &route_fatalExceptionValid);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoFatalException_f, &dbg_ipe_ip_routing_info, &route_fatalException);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoPayloadPacketType_f, &dbg_ipe_ip_routing_info, &route_payloadPacketType);
    GetDbgIpeIpRoutingInfo(A, ipeIpRoutingInfoValid_f, &dbg_ipe_ip_routing_info, &route_valid);

    /*DbgLpmTcamEngineResult0Info*/
    sal_memset(&dbg_lpm_tcam_res0, 0, sizeof(dbg_lpm_tcam_res0));
    cmd = DRV_IOR(DbgLpmTcamEngineResult0Info_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_lpm_tcam_res0);
    for (index = 0; index < 6; index++)
    {
        DRV_IOR_FIELD(DbgLpmTcamEngineResult0Info_t, DbgLpmTcamEngineResult0Info_lpmTcamEngineResult0InfoGTcamGroup_0_lookupResultValid_f+index*2,
            &grp0_valid[index], &dbg_lpm_tcam_res0);

        DRV_IOR_FIELD(DbgLpmTcamEngineResult0Info_t, DbgLpmTcamEngineResult0Info_lpmTcamEngineResult0InfoGTcamGroup_0_tcamHitIndex_f+index*2,
            &grp0_index[index], &dbg_lpm_tcam_res0);
    }

    /*DbgLpmTcamEngineResult1Info*/
    sal_memset(&dbg_lpm_tcam_res1, 0, sizeof(dbg_lpm_tcam_res1));
    cmd = DRV_IOR(DbgLpmTcamEngineResult1Info_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_lpm_tcam_res1);
    for (index = 0; index < 6; index++)
    {
        DRV_IOR_FIELD(DbgLpmTcamEngineResult1Info_t, DbgLpmTcamEngineResult1Info_lpmTcamEngineResult1InfoGTcamGroup_0_lookupResultValid_f+index*2,
            &grp1_valid[index], &dbg_lpm_tcam_res1);

        DRV_IOR_FIELD(DbgLpmTcamEngineResult0Info_t, DbgLpmTcamEngineResult1Info_lpmTcamEngineResult1InfoGTcamGroup_0_tcamHitIndex_f+index*2,
            &grp1_index[index], &dbg_lpm_tcam_res1);
    }

    if (0 == p_info->detail)
    {
        goto Discard;
    }

    if (route_valid)
    {
        if (route_l3DaLookupEn)
        {
            CTC_DKIT_PRINT("\n");
            CTC_DKIT_PRINT("Route Process:\n");
            CTC_DKIT_PATH_PRINT("%-15s\n", "IP DA lookup--->");
            if (route_l3DaResultValid)
            {
                if (l3Da_first_hash_ResultValid || l3Da_second_hash_ResultValid)/*hash result*/
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_HASH_HIT);
                    if (l3Da_first_hash_ResultValid)
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", l3Da_first_hitHashKeyIndexl3Da);
                    }
                    else
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", l3Da_second_hitHashKeyIndexl3Da);
                    }
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "Vrf id", vrf_id);

                    if ((CTC_DKITS_L3DA_TYPE_IPV4UCAST == key_type) ||
                        (CTC_DKITS_L3DA_TYPE_IPV4MCAST == key_type))/* FIBDAKEYTYPE_IPV4UCAST or FIBDAKEYTYPE_IPV4MCAST */
                    {
                        key_name = "DsFibHost0Ipv4HashKey";
                    }
                    else if (CTC_DKITS_L3DA_TYPE_IPV6UCAST == key_type)/* FIBDAKEYTYPE_IPV6UCAST */
                    {
                        key_name = "DsFibHost0Ipv6UcastHashKey";
                    }
                    else if (CTC_DKITS_L3DA_TYPE_IPV6MCAST == key_type)/* FIBDAKEYTYPE_IPV6MCAST */
                    {
                        key_name = "DsFibHost0MacIpv6McastHashKey";
                    }
                    else
                    {
                        /* TODO, PBR... */
                        key_name = "Unkown";
                    }
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", key_name);
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "AD index", ad_index);
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "AD name", "DsIpDa\n");

                }
                else if (lpmtcam_lkp1_pri_valid || lpmtcam_lkp1_pub_valid || lpmtcam_lkp2_pri_valid || lpmtcam_lkp2_pub_valid)/*lpm result*/
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", "LPM tcam lookup hit");

                    if (lpmtcam_lkp1_pri_valid)
                    {
                        for (index = 0; index < 6; index++)
                        {
                            if (grp0_valid[index])
                            {
                                CTC_DKIT_PATH_PRINT("%-15s:%s%d\n", "tcam key:", "Lookup1 private block ",index);
                                key_index = grp0_index[index];
                                break;
                            }
                        }
                    }

                    if (lpmtcam_lkp1_pub_valid)
                    {
                        for (index = 0; index < 6; index++)
                        {
                            if (grp0_valid[index])
                            {
                                CTC_DKIT_PATH_PRINT("%-15s:%s%d\n", "tcam key:", "Lookup1 public block ", index);
                                key_index = grp0_index[index];
                                break;
                            }
                        }
                    }

                    if (lpmtcam_lkp2_pri_valid)
                    {
                        for (index = 0; index < 6; index++)
                        {
                            if (grp1_valid[index])
                            {
                                CTC_DKIT_PATH_PRINT("%-15s:%s%d\n", "tcam key:", "Lookup2 private block ", index);
                                key_index = grp1_index[index];
                                break;
                            }
                        }
                    }

                    if (lpmtcam_lkp2_pub_valid)
                    {
                        for (index = 0; index < 6; index++)
                        {
                            if (grp1_valid[index])
                            {
                                CTC_DKIT_PATH_PRINT("%-15s:%s%d\n", "tcam key:", "Lookup2 public block ", index);
                                key_index = grp1_index[index];
                                break;
                            }
                        }
                    }

                    if (CTC_DKITS_L3DA_TYPE_IPV4UCAST == key_type)
                    {
                        key_name = "DsLpmTcamIpv4HalfKey";
                        ad_name = "DsLpmTcamIpv4HalfKeyAd";
                        cmd = DRV_IOR(DsLpmTcamIpv4HalfKeyAd_t, DsLpmTcamIpv4HalfKeyAd_lpmPipelineValid_f);
                        cmd1 = DRV_IOR(DsLpmTcamIpv4HalfKeyAd_t, DsLpmTcamIpv4HalfKeyAd_nexthop_f);
                        cmd2 = DRV_IOR(DsLpmTcamIpv4HalfKeyAd_t, DsLpmTcamIpv4HalfKeyAd_pointer_f);

                        _ctc_goldengate_dkit_ipuc_map_key_index(DsLpmTcamIpv4HalfKey_t, key_index, &mapped_key_index, &mapped_ad_index);

                    }
                    else if (CTC_DKITS_L3DA_TYPE_IPV6UCAST == key_type)
                    {
                        key_name = "DsLpmTcamIpv6DoubleKey0";
                        ad_name = "DsLpmTcamIpv6DoubleKey0Ad";
                        cmd = DRV_IOR(DsLpmTcamIpv6DoubleKey0Ad_t, DsLpmTcamIpv6DoubleKey0Ad_lpmPipelineValid_f);
                        cmd1 = DRV_IOR(DsLpmTcamIpv6DoubleKey0Ad_t, DsLpmTcamIpv6DoubleKey0Ad_nexthop_f);
                        cmd2 = DRV_IOR(DsLpmTcamIpv6DoubleKey0Ad_t, DsLpmTcamIpv6DoubleKey0Ad_pointer_f);

                        _ctc_goldengate_dkit_ipuc_map_key_index(DsLpmTcamIpv6DoubleKey0_t, key_index, &mapped_key_index, &mapped_ad_index);
                    }

                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "Spec tcam index", key_index);
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", mapped_key_index);
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", key_name);
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "tcam AD index", mapped_ad_index);
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "tcam AD name", ad_name);

                    DRV_IOCTL(lchip, mapped_ad_index, cmd, &pipeline_valid);

                    if (!pipeline_valid)
                    {
                        DRV_IOCTL(lchip, mapped_ad_index, cmd1, &ds_ip_da_idx);
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "AD index", ds_ip_da_idx);
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "AD name", "DsIpDa\n");
                    }
                    else
                    {
                        CTC_DKIT_PATH_PRINT("\n");
                        DRV_IOCTL(lchip, mapped_ad_index, cmd2, &pointer);
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Pipeline0", "LPM pipeline0 lookup hit");
                        key_index = pointer;  /*Later should optimise, dbg info should record lpm pipeline index*/

                        cmd = DRV_IOR(DsLpmLookupKey_t, DsLpmLookupKey_type0_f);
                        DRV_IOCTL(lchip, key_index, cmd, &lpm_type0);
                        cmd = DRV_IOR(DsLpmLookupKey_t, DsLpmLookupKey_type1_f);
                        DRV_IOCTL(lchip, key_index, cmd, &lpm_type1);
                        if ((lpm_type0 == 1) || (lpm_type0 == 2))
                        {
                            cmd = DRV_IOR(DsLpmLookupKey_t, DsLpmLookupKey_nexthop0_f);
                            DRV_IOCTL(lchip, key_index, cmd, &ad_index);
                        }
                        else if ((lpm_type1 == 1) || (lpm_type0 == 2))
                        {
                            cmd = DRV_IOR(DsLpmLookupKey_t, DsLpmLookupKey_nexthop1_f);
                            DRV_IOCTL(lchip, key_index, cmd, &ad_index);
                        }

                        if ((lpm_type0 == 2) || (lpm_type1 == 2))
                        {
                            pipeline_valid = 1;
                        }
                        else
                        {
                            pipeline_valid = 0;
                        }

                        key_name = "DsLpmLookupKey";
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", key_index);
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", key_name);

                        if (!pipeline_valid)
                        {
                            CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "AD index", ad_index);
                            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "AD name", "DsIpDa\n");
                        }
                        else
                        {
                            CTC_DKIT_PATH_PRINT("\n");
                            key_index = ad_index;
                            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Pipeline1", "LPM pipeline1 lookup hit");
                            cmd = DRV_IOR(DsLpmLookupKey_t, DsLpmLookupKey_type0_f);
                            DRV_IOCTL(lchip, key_index, cmd, &lpm_type0);
                            cmd = DRV_IOR(DsLpmLookupKey_t, DsLpmLookupKey_type1_f);
                            DRV_IOCTL(lchip, key_index, cmd, &lpm_type1);
                            if (lpm_type0 == 1)
                            {
                                cmd = DRV_IOR(DsLpmLookupKey_t, DsLpmLookupKey_nexthop0_f);
                                DRV_IOCTL(lchip, key_index, cmd, &ad_index);
                            }
                            else if (lpm_type1 == 1)
                            {
                                cmd = DRV_IOR(DsLpmLookupKey_t, DsLpmLookupKey_nexthop1_f);
                                DRV_IOCTL(lchip, key_index, cmd, &ad_index);
                            }
                            key_name = "DsLpmLookupKey";
                            CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", key_index);
                            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", key_name);
                            CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "AD index", ad_index);
                            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "AD name", "DsIpDa\n");
                        }
                    }
                }
            }
            else
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
            }

        }

        if(route_l3SaLookupEn)
        {
            CTC_DKIT_PATH_PRINT("%-15s\n", "IP SA lookup--->");
            if (route_l3SaResultValid)
            {
                if (l3Sa_key_type == CTC_DKITS_L3SA_TYPE_IPV4NATSA)
                {
                    if (l3Sa_nat_tcam)
                    {
                        result = "IPv4 Nat LPM Tcam lookup hit";
                        key_name = "DsLpmTcamIpv4NatDoubleKey";
                        key_index = l3Sa_hitTcamKeyIndexl3Sa;
                    }
                    else if (l3Sa_l3SaHashResultValid)
                    {
                        result = "IPv4 Nat HASH lookup hit";
                        key_name = "DsFibHost1Ipv4NatSaPortHashKey";
                        key_index = l3Sa_hitHashKeyIndexl3Sa;
                    }
                }
                else if (l3Sa_key_type == CTC_DKITS_L3SA_TYPE_IPV6NATSA)
                {
                    if (l3Sa_nat_tcam)
                    {
                        result = "IPv6 Nat LPM Tcam lookup hit";
                        key_name = "DsLpmTcamIpv6DoubleKey0";
                        key_index = l3Sa_hitTcamKeyIndexl3Sa;
                    }
                    else if (l3Sa_l3SaHashResultValid)
                    {
                        result = "IPv6 Nat HASH lookup hit";
                        key_name = "DsFibHost1Ipv6NatSaPortHashKey";
                        key_index = l3Sa_hitHashKeyIndexl3Sa;
                    }
                }
                else if (l3Sa_key_type == CTC_DKITS_L3SA_TYPE_IPV4RPF)
                {
                    if (l3Sa_rpf_tcam)
                    {
                        result = "IPv4 RPF LPM Tcam lookup hit";
                        key_name = "DsLpmTcamIpv4NatDoubleKey";
                        key_index = l3Sa_hitTcamKeyIndexl3Sa;
                    }
                    else if (l3Sa_l3SaHashResultValid)
                    {
                        result = "IPv4 RPF HASH lookup hit";
                        key_name = "DsFibHost1Ipv4NatSaPortHashKey";
                        key_index = l3Sa_hitHashKeyIndexl3Sa;
                    }
                }
                else if (l3Sa_key_type == CTC_DKITS_L3SA_TYPE_IPV6RPF)
                {
                    if (l3Sa_rpf_tcam)
                    {
                        result = "IPv6 RPF LPM Tcam lookup hit";
                        key_name = "DsLpmTcamIpv6DoubleKey0";
                        key_index = l3Sa_hitTcamKeyIndexl3Sa;
                    }
                    else if (l3Sa_l3SaHashResultValid)
                    {
                        result = "IPv6 RPF HASH lookup hit";
                        key_name = "DsFibHost1Ipv6NatSaPortHashKey";
                        key_index = l3Sa_hitHashKeyIndexl3Sa;
                    }
                }

                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", result);
                CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", l3Sa_hitHashKeyIndexl3Sa);
                CTC_DKIT_PATH_PRINT("%-15s:%s\n\n", "key name", key_name);

                /*pbr TBD*/
            }
            else
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
            }

        }

    }

    if (route_discard)
    {
        discard = 1;
        discard_type = route_discardType;
    }

    if (route_exceptionEn)
    {
        exceptionEn = 1;
        exceptionIndex = route_exceptionIndex;
        exceptionSubIndex = route_exceptionSubIndex;
    }
Discard:
    _ctc_goldengate_dkit_captured_path_discard_process(p_info, discard, discard_type, CTC_DKIT_IPE);
    _ctc_goldengate_dkit_captured_path_exception_process(p_info, exceptionEn, exceptionIndex, exceptionSubIndex);

    return 0;
}

static int32
_ctc_goldengate_dkit_captured_path_ipe_parser(ctc_dkit_captured_path_info_t* p_info)
{
    _ctc_goldengate_dkit_captured_path_parser(p_info, 0);
    _ctc_goldengate_dkit_captured_path_parser(p_info, 1);

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_ipe_scl(ctc_dkit_captured_path_info_t* p_info)
{
    uint8 slice = p_info->slice_ipe;
    uint8 lchip = p_info->lchip;
    uint32 cmd = 0;
    char* acl_key_type_desc[4] = {"TCAML2KEY", "TCAML2L3KEY", "TCAML3KEY", "TCAMVLANKEY"};

    /*DbgIpeUserIdInfo*/
    uint32 scl_sclFlowHashEn = 0;
    uint32 scl_exceptionEn = 0;
    uint32 scl_exceptionIndex = 0;
    uint32 scl_exceptionSubIndex = 0;
    uint32 scl_localPhyPort = 0;
    uint32 scl_discard = 0;
    uint32 scl_discardType = 0;
    uint32 scl_bypassAll = 0;
    uint32 scl_dsFwdPtrValid = 0;
    uint32 scl_dsFwdPtr = 0;
    uint32 scl_userIdTcam1En = 0;
    uint32 scl_userIdTcam2En = 0;
    uint32 scl_userIdTcam1Type = 0;
    uint32 scl_userIdTcam2Type = 0;
    uint32 scl_valid = 0;
    DbgIpeUserIdInfo_m dbg_ipe_user_id_info;
    /*DbgUserIdHashEngineForUserId0Info*/
    uint32 hash0_lookupResultValid = 0;
    uint32 hash0_defaultEntryValid = 0;
    uint32 hash0_keyIndex = 0;
    uint32 hash0_adIndex = 0;
    uint32 hash0_hashConflict = 0;
    uint32 hash0_keyType = 0;
    uint32 hash0_valid = 0;
    DbgUserIdHashEngineForUserId0Info_m dbg_user_id_hash_engine_for_user_id0_info;
    /*DbgUserIdHashEngineForUserId1Info*/
    uint32 hash1_lookupResultValid = 0;
    uint32 hash1_defaultEntryValid = 0;
    uint32 hash1_keyIndex = 0;
    uint32 hash1_adIndex = 0;
    uint32 hash1_hashConflict = 0;
    uint32 hash1_keyType = 0;
    uint32 hash1_valid = 0;
    DbgUserIdHashEngineForUserId1Info_m dbg_user_id_hash_engine_for_user_id1_info;
    /*DbgFlowTcamEngineUserIdInfo*/
    uint32 tcam_userId0TcamResultValid = 0;
    uint32 tcam_userId0TcamIndex = 0;
    uint32 tcam_userId0Valid = 0;
    uint32 tcam_userId1TcamResultValid = 0;
    uint32 tcam_userId1TcamIndex = 0;
    uint32 tcam_userId1Valid = 0;
    uint32 tcam_userId2TcamResultValid = 0;
    uint32 tcam_userId2TcamIndex = 0;
    uint32 tcam_userId2Valid = 0;
    DbgFlowTcamEngineUserIdInfo0_m dbg_flow_tcam_engine_user_id_info;

    /*DbgIpeUserIdInfo*/
    sal_memset(&dbg_ipe_user_id_info, 0, sizeof(dbg_ipe_user_id_info));
    cmd = DRV_IOR(DbgIpeUserIdInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_ipe_user_id_info);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoLocalPhyPort_f, &dbg_ipe_user_id_info, &scl_localPhyPort);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoExceptionEn_f, &dbg_ipe_user_id_info, &scl_exceptionEn);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoExceptionIndex_f, &dbg_ipe_user_id_info, &scl_exceptionIndex);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoExceptionSubIndex_f, &dbg_ipe_user_id_info, &scl_exceptionSubIndex);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoDiscard_f, &dbg_ipe_user_id_info, &scl_discard);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoDiscardType_f, &dbg_ipe_user_id_info, &scl_discardType);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoBypassAll_f, &dbg_ipe_user_id_info, &scl_bypassAll);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoDsFwdPtrValid_f, &dbg_ipe_user_id_info, &scl_dsFwdPtrValid);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoDsFwdPtr_f, &dbg_ipe_user_id_info, &scl_dsFwdPtr);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoUserIdTcamLookupEn0_f, &dbg_ipe_user_id_info, &scl_userIdTcam1En);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoUserIdTcamLookupEn1_f, &dbg_ipe_user_id_info, &scl_userIdTcam2En);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoUserIdTcamKeyType0_f, &dbg_ipe_user_id_info, &scl_userIdTcam1Type);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoUserIdTcamKeyType1_f, &dbg_ipe_user_id_info, &scl_userIdTcam2Type);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoValid_f, &dbg_ipe_user_id_info, &scl_valid);

    cmd = DRV_IOR(DsPhyPortExt_t, DsPhyPortExt_sclFlowHashEn_f);
    DRV_IOCTL(lchip, scl_localPhyPort, cmd, &scl_sclFlowHashEn);

    /*DbgUserIdHashEngineForUserId0Info*/
    sal_memset(&dbg_user_id_hash_engine_for_user_id0_info, 0, sizeof(dbg_user_id_hash_engine_for_user_id0_info));
    cmd = DRV_IOR(DbgUserIdHashEngineForUserId0Info_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_user_id_hash_engine_for_user_id0_info);
    GetDbgUserIdHashEngineForUserId0Info(A, userIdHashEngineForUserId0InfoLookupResultValid_f, &dbg_user_id_hash_engine_for_user_id0_info, &hash0_lookupResultValid);
    GetDbgUserIdHashEngineForUserId0Info(A, userIdHashEngineForUserId0InfoDefaultEntryValid_f, &dbg_user_id_hash_engine_for_user_id0_info, &hash0_defaultEntryValid);
    GetDbgUserIdHashEngineForUserId0Info(A, userIdHashEngineForUserId0InfoKeyIndex_f, &dbg_user_id_hash_engine_for_user_id0_info, &hash0_keyIndex);
    GetDbgUserIdHashEngineForUserId0Info(A, userIdHashEngineForUserId0InfoAdIndex_f, &dbg_user_id_hash_engine_for_user_id0_info, &hash0_adIndex);
    GetDbgUserIdHashEngineForUserId0Info(A, userIdHashEngineForUserId0InfoHashConflict_f, &dbg_user_id_hash_engine_for_user_id0_info, &hash0_hashConflict);
    GetDbgUserIdHashEngineForUserId0Info(A, userIdHashEngineForUserId0InfoUserIdKeyType_f, &dbg_user_id_hash_engine_for_user_id0_info, &hash0_keyType);
    GetDbgUserIdHashEngineForUserId0Info(A, userIdHashEngineForUserId0InfoValid_f, &dbg_user_id_hash_engine_for_user_id0_info, &hash0_valid);

    /*DbgUserIdHashEngineForUserId1Info*/
    sal_memset(&dbg_user_id_hash_engine_for_user_id1_info, 0, sizeof(dbg_user_id_hash_engine_for_user_id1_info));
    cmd = DRV_IOR(DbgUserIdHashEngineForUserId1Info_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_user_id_hash_engine_for_user_id1_info);
    GetDbgUserIdHashEngineForUserId1Info(A, userIdHashEngineForUserId1InfoLookupResultValid_f, &dbg_user_id_hash_engine_for_user_id1_info, &hash1_lookupResultValid);
    GetDbgUserIdHashEngineForUserId1Info(A, userIdHashEngineForUserId1InfoDefaultEntryValid_f, &dbg_user_id_hash_engine_for_user_id1_info, &hash1_defaultEntryValid);
    GetDbgUserIdHashEngineForUserId1Info(A, userIdHashEngineForUserId1InfoKeyIndex_f, &dbg_user_id_hash_engine_for_user_id1_info, &hash1_keyIndex);
    GetDbgUserIdHashEngineForUserId1Info(A, userIdHashEngineForUserId1InfoAdIndex_f, &dbg_user_id_hash_engine_for_user_id1_info, &hash1_adIndex);
    GetDbgUserIdHashEngineForUserId1Info(A, userIdHashEngineForUserId1InfoHashConflict_f, &dbg_user_id_hash_engine_for_user_id1_info, &hash1_hashConflict);
    GetDbgUserIdHashEngineForUserId1Info(A, userIdHashEngineForUserId1InfoUserIdKeyType_f, &dbg_user_id_hash_engine_for_user_id1_info, &hash1_keyType);
    GetDbgUserIdHashEngineForUserId1Info(A, userIdHashEngineForUserId1InfoValid_f, &dbg_user_id_hash_engine_for_user_id1_info, &hash1_valid);

    /*DbgFlowTcamEngineUserIdInfo0*/
    sal_memset(&dbg_flow_tcam_engine_user_id_info, 0, sizeof(dbg_flow_tcam_engine_user_id_info));
    cmd = DRV_IOR(DbgFlowTcamEngineUserIdInfo0_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_flow_tcam_engine_user_id_info);
    GetDbgFlowTcamEngineUserIdInfo0(A, flowTcamEngineUserIdInfo0TcamResultValid0_f, &dbg_flow_tcam_engine_user_id_info, &tcam_userId0TcamResultValid);
    GetDbgFlowTcamEngineUserIdInfo0(A, flowTcamEngineUserIdInfo0TcamIndex0_f, &dbg_flow_tcam_engine_user_id_info, &tcam_userId0TcamIndex);
    GetDbgFlowTcamEngineUserIdInfo0(A, flowTcamEngineUserIdInfo0Valid_f, &dbg_flow_tcam_engine_user_id_info, &tcam_userId0Valid);
    /*DbgFlowTcamEngineUserIdInfo1*/
    cmd = DRV_IOR(DbgFlowTcamEngineUserIdInfo1_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_flow_tcam_engine_user_id_info);
    GetDbgFlowTcamEngineUserIdInfo1(A, flowTcamEngineUserIdInfo1TcamResultValid1_f, &dbg_flow_tcam_engine_user_id_info, &tcam_userId1TcamResultValid);
    GetDbgFlowTcamEngineUserIdInfo1(A, flowTcamEngineUserIdInfo1TcamIndex1_f, &dbg_flow_tcam_engine_user_id_info, &tcam_userId1TcamIndex);
    GetDbgFlowTcamEngineUserIdInfo1(A, flowTcamEngineUserIdInfo1Valid_f, &dbg_flow_tcam_engine_user_id_info, &tcam_userId1Valid);
    /*DbgFlowTcamEngineUserIdInfo2*/
    cmd = DRV_IOR(DbgFlowTcamEngineUserIdInfo2_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_flow_tcam_engine_user_id_info);
    GetDbgFlowTcamEngineUserIdInfo2(A, flowTcamEngineUserIdInfo2TcamResultValid2_f, &dbg_flow_tcam_engine_user_id_info, &tcam_userId2TcamResultValid);
    GetDbgFlowTcamEngineUserIdInfo2(A, flowTcamEngineUserIdInfo2TcamIndex2_f, &dbg_flow_tcam_engine_user_id_info, &tcam_userId2TcamIndex);
    GetDbgFlowTcamEngineUserIdInfo2(A, flowTcamEngineUserIdInfo2Valid_f, &dbg_flow_tcam_engine_user_id_info, &tcam_userId2Valid);

    if (0 == p_info->detail)
    {
        goto Discard;
    }

    if(scl_valid)
    {
        if (hash0_keyType|| hash1_keyType || scl_userIdTcam1En || scl_userIdTcam2En)
        {
            CTC_DKIT_PRINT("SCL Process:\n");
            /*hash0*/
            if (hash0_keyType && hash0_valid)
            {
                CTC_DKIT_PATH_PRINT("%-15s\n", "HASH0 lookup--->");
                if (hash0_hashConflict)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_CONFLICT);
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", hash0_keyIndex);
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", _ctc_goldengate_dkit_captured_get_igr_scl_key_desc(hash0_keyType));
                }
                else if (hash0_defaultEntryValid)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_DEFAULT);
                }
                else if (hash0_lookupResultValid)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_HASH_HIT);
                }
                else
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
                }
                if (hash0_defaultEntryValid || hash0_lookupResultValid)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", hash0_keyIndex);
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", _ctc_goldengate_dkit_captured_get_igr_scl_key_desc(hash0_keyType));
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "AD index", hash0_adIndex/2);
                    if (scl_sclFlowHashEn)
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "AD name", "DsSclFlow");
                    }
                    else if (hash0_keyType && (hash0_keyType < USERIDHASHTYPE_TUNNELIPV4))
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "AD name", "DsUserId");
                    }
                    else if (hash0_keyType >= USERIDHASHTYPE_TUNNELIPV4)
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "AD name", "DsTunnelId");
                    }
                }
            }
            /*hash1*/
            if (hash1_keyType && hash1_valid)
            {
                CTC_DKIT_PATH_PRINT("%-15s\n", "HASH1 lookup--->");
                if (hash1_hashConflict)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_CONFLICT);
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", hash1_keyIndex);
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", _ctc_goldengate_dkit_captured_get_igr_scl_key_desc(hash1_keyType));
                }
                else if (hash1_defaultEntryValid)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_DEFAULT);
                }
                else if (hash1_lookupResultValid)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_HASH_HIT);
                }
                else
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
                }
                if (hash1_defaultEntryValid || hash1_lookupResultValid)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", hash1_keyIndex);
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", _ctc_goldengate_dkit_captured_get_igr_scl_key_desc(hash1_keyType));
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "AD index", hash1_adIndex/2);
                    if (hash1_keyType && (hash1_keyType < USERIDHASHTYPE_TUNNELIPV4))
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "AD name", "DsUserId");
                    }
                    else if (hash1_keyType >= USERIDHASHTYPE_TUNNELIPV4)
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "AD name", "DsTunnelId");
                    }
                }
            }
            /*tcam0*/
            if (scl_userIdTcam1En && tcam_userId0Valid)
            {
                CTC_DKIT_PATH_PRINT("%-15s\n", "TCAM0 lookup--->");
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key type", acl_key_type_desc[scl_userIdTcam1Type]);
                if (tcam_userId0TcamResultValid)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_TCAM_HIT);
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", tcam_userId0TcamIndex*2 - DRV_TCAM_USERID_0_BASE);
                }
                else
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
                }
            }
            /*tcam1*/
            if (scl_userIdTcam2En && tcam_userId1Valid)
            {
                CTC_DKIT_PATH_PRINT("%-15s\n", "TCAM1 lookup--->");
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key type", acl_key_type_desc[scl_userIdTcam2Type]);
                if (tcam_userId1TcamResultValid)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_TCAM_HIT);
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", tcam_userId1TcamIndex*2);
                }
                else
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
                }
            }
        }
    }

Discard:
    _ctc_goldengate_dkit_captured_path_discard_process(p_info, scl_discard, scl_discardType, CTC_DKIT_IPE);
    _ctc_goldengate_dkit_captured_path_exception_process(p_info, scl_exceptionEn, scl_exceptionIndex, scl_exceptionSubIndex);

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_ipe_interface(ctc_dkit_captured_path_info_t* p_info)
{
    uint8 slice = p_info->slice_ipe;
    uint8 lchip = p_info->lchip;
    uint32 cmd = 0;
    uint16 gport = 0;
    uint8 gchip = 0;
    uint32 value = 0;
    uint32 bridge_en = 0;
    uint32 route_en = 0;
    uint32 mpls_en = 0;
    char* vlan_action[4] = {"None", "Replace", "Add","Delete"};

    uint32 dot1ae_encrypted = 0;
    uint32 dot1ae_decrypted = 0;
    /* DbgIpeUserIdInfo */
    uint32 localPhyPort = 0;
    uint32 globalSrcPort = 0;
    uint32 outerVlanIsCVlan = 0;
    /* DbgIpeIntfMapperInfo */
    uint32 vlanId = 0;
    uint32 isLoop = 0;
    uint32 isPortMac = 0;
    uint32 sourceCos = 0;
    uint32 sourceCfi = 0;
    uint32 ctagCos = 0;
    uint32 ctagCfi = 0;
    uint32 svlanTagOperationValid = 0;
    uint32 cvlanTagOperationValid = 0;
    uint32 classifyStagCos = 0;
    uint32 classifyStagCfi = 0;
    uint32 classifyCtagCos = 0;
    uint32 classifyCtagCfi = 0;
    uint32 vlanPtr = 0;
    uint32 interfaceId = 0;
    uint32 isRouterMac = 0;
    uint32 discard = 0;
    uint32 discardType = 0;
    uint32 bypassAll = 0;
    uint32 exceptionEn = 0;
    uint32 exceptionIndex = 0;
    uint32 exceptionSubIndex = 0;
    uint32 dsFwdPtrValid = 0;
    uint32 dsFwdPtr = 0;
    uint32 protocolVlanEn = 0;
    uint32 tempBypassAll = 0;
    uint32 routeAllPacket = 0;
    uint32 valid = 0;
    DbgIpeUserIdInfo_m dbg_ipe_user_id_info;
    DbgIpeIntfMapperInfo_m dbg_ipe_intf_mapper_info;

    CTC_DKIT_PRINT("Interface Process:\n");
    sal_memset(&dbg_ipe_user_id_info, 0, sizeof(dbg_ipe_user_id_info));
    cmd = DRV_IOR(DbgIpeUserIdInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_ipe_user_id_info);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoLocalPhyPort_f, &dbg_ipe_user_id_info, &localPhyPort);
    //GetDbgIpeUserIdInfo(A, globalSrcPort_f, &dbg_ipe_user_id_info, &globalSrcPort);
    //GetDbgIpeUserIdInfo(A, outerVlanIsCVlan_f, &dbg_ipe_user_id_info, &outerVlanIsCVlan);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoDiscard_f, &dbg_ipe_user_id_info, &discard);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoDiscardType_f, &dbg_ipe_user_id_info, &discardType);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoExceptionEn_f, &dbg_ipe_user_id_info, &exceptionEn);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoExceptionIndex_f, &dbg_ipe_user_id_info, &exceptionIndex);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoExceptionSubIndex_f, &dbg_ipe_user_id_info, &exceptionSubIndex);
    GetDbgIpeUserIdInfo(A, ipeUserIdInfoValid_f, &dbg_ipe_user_id_info, &valid);

    if (valid)
    {
        if (CTC_DKIT_DRV_GPORT_IS_LINKAGG_PORT(globalSrcPort))
        {

            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "linkagg group", CTC_DKIT_DRV_GPORT_TO_LINKAGG_ID(globalSrcPort));
        }
        CTC_DKIT_GET_GCHIP(lchip, gchip);
        gport = CTC_DKIT_DRV_LPORT_TO_CTC_GPORT(gchip, (localPhyPort + slice*CTC_DKIT_ONE_SLICE_PORT_NUM));
        CTC_DKIT_PATH_PRINT("%-15s:0x%04x\n", "source gport", gport);
    }

    sal_memset(&dbg_ipe_intf_mapper_info, 0, sizeof(dbg_ipe_intf_mapper_info));
    cmd = DRV_IOR(DbgIpeIntfMapperInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_ipe_intf_mapper_info);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoVlanId_f, &dbg_ipe_intf_mapper_info, &vlanId);
    //GetDbgIpeIntfMapperInfo(A, isLoop_f, &dbg_ipe_intf_mapper_info, &isLoop);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoIsPortMac_f, &dbg_ipe_intf_mapper_info, &isPortMac);
    //GetDbgIpeIntfMapperInfo(A, sourceCos_f, &dbg_ipe_intf_mapper_info, &sourceCos);
    //GetDbgIpeIntfMapperInfo(A, sourceCfi_f, &dbg_ipe_intf_mapper_info, &sourceCfi);
    //GetDbgIpeIntfMapperInfo(A, ctagCos_f, &dbg_ipe_intf_mapper_info, &ctagCos);
    //GetDbgIpeIntfMapperInfo(A, ctagCfi_f, &dbg_ipe_intf_mapper_info, &ctagCfi);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoSvlanTagOperationValid_f, &dbg_ipe_intf_mapper_info, &svlanTagOperationValid);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoCvlanTagOperationValid_f, &dbg_ipe_intf_mapper_info, &cvlanTagOperationValid);
    //GetDbgIpeIntfMapperInfo(A, classifyStagCos_f, &dbg_ipe_intf_mapper_info, &classifyStagCos);
    //GetDbgIpeIntfMapperInfo(A, classifyStagCfi_f, &dbg_ipe_intf_mapper_info, &classifyStagCfi);
    //GetDbgIpeIntfMapperInfo(A, classifyCtagCos_f, &dbg_ipe_intf_mapper_info, &classifyCtagCos);
    //GetDbgIpeIntfMapperInfo(A, classifyCtagCfi_f, &dbg_ipe_intf_mapper_info, &classifyCtagCfi);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoVlanPtr_f, &dbg_ipe_intf_mapper_info, &vlanPtr);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoInterfaceId_f, &dbg_ipe_intf_mapper_info, &interfaceId);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoIsRouterMac_f, &dbg_ipe_intf_mapper_info, &isRouterMac);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoDiscard_f, &dbg_ipe_intf_mapper_info, &discard);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoDiscardType_f, &dbg_ipe_intf_mapper_info, &discardType);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoBypassAll_f, &dbg_ipe_intf_mapper_info, &bypassAll);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoExceptionEn_f, &dbg_ipe_intf_mapper_info, &exceptionEn);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoExceptionIndex_f, &dbg_ipe_intf_mapper_info, &exceptionIndex);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoExceptionSubIndex_f, &dbg_ipe_intf_mapper_info, &exceptionSubIndex);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoDsFwdPtrValid_f, &dbg_ipe_intf_mapper_info, &dsFwdPtrValid);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoDsFwdPtr_f, &dbg_ipe_intf_mapper_info, &dsFwdPtr);
    //GetDbgIpeIntfMapperInfo(A, protocolVlanEn_f, &dbg_ipe_intf_mapper_info, &protocolVlanEn);
    //GetDbgIpeIntfMapperInfo(A, tempBypassAll_f, &dbg_ipe_intf_mapper_info, &tempBypassAll);
    //GetDbgIpeIntfMapperInfo(A, routeAllPacket_f, &dbg_ipe_intf_mapper_info, &routeAllPacket);
    GetDbgIpeIntfMapperInfo(A, ipeIntfMapperInfoValid_f, &dbg_ipe_intf_mapper_info, &valid);
    if (valid)
    {
        if (vlanPtr < 4096)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "vlan ptr", vlanPtr);
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "vlan domain", outerVlanIsCVlan?"cvlan domain":"svlan domain");
        }
        if (interfaceId)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "l3 intf id", interfaceId);
            cmd = DRV_IOR(DsSrcInterface_t, DsSrcInterface_vrfId_f);
            DRV_IOCTL(lchip, interfaceId, cmd, &value);
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "intf vrfid", value);
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "route mac", isRouterMac?"YES":"NO");
        }
    }
    /*bridge en*/
    cmd = DRV_IOR(DsSrcPort_t, DsSrcPort_bridgeEn_f);
    DRV_IOCTL(lchip, (localPhyPort + slice*CTC_DKIT_ONE_SLICE_PORT_NUM), cmd, &bridge_en);
    if (vlanPtr < 4096)
    {
        cmd = DRV_IOR(DsSrcVlan_t, DsSrcVlan_bridgeDisable_f);
        DRV_IOCTL(lchip, vlanPtr, cmd, &value);
    }
    bridge_en = bridge_en && (!value);
    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "bridge port", bridge_en?"YES":"NO");
    /*route en*/
    cmd = DRV_IOR(DsSrcPort_t, DsSrcPort_routedPort_f);
    DRV_IOCTL(lchip, (localPhyPort + slice*CTC_DKIT_ONE_SLICE_PORT_NUM), cmd, &route_en);
    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "route port", route_en?"YES":"NO");

    /*mpls en*/
    if (interfaceId)
    {
        cmd = DRV_IOR(DsSrcInterface_t, DsSrcInterface_mplsEn_f);
        DRV_IOCTL(lchip, interfaceId, cmd, &mpls_en);
        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "MPLS port", mpls_en? "YES" : "NO");
    }

    if(p_info->is_bsr_captured)
    {
        /*DbgFwdBufStoreInfo*/
        uint32 valid = 0;
        uint32 operationType = 0;
        uint32 svlanTagOperationValid = 0;
        uint32 sTagAction = 0;
        uint32 sourceCos = 0;
        uint32 sourceCfi = 0;
        uint32 svlanTpidIndex = 0;
        uint32 srcVlanId = 0;
        uint32 cvlanTagOperationValid = 0;
        uint32 cTagAction = 0;
        uint32 srcCtagCos = 0;
        uint32 srcCtagCfi = 0;
        uint32 srcCvlanId = 0;

        uint32 svlanTpid = 0;
        uint32 cvlanTagTpid = 0;

        DbgFwdBufStoreInfo_m dbg_fwd_buf_store_info;
        sal_memset(&dbg_fwd_buf_store_info, 0, sizeof(dbg_fwd_buf_store_info));
        cmd = DRV_IOR(DbgFwdBufStoreInfo_t, DRV_ENTRY_FLAG);
        DRV_IOCTL(lchip, 0, cmd, &dbg_fwd_buf_store_info);
        GetDbgFwdBufStoreInfo(A, fwdBufStoreInfoValid_f, &dbg_fwd_buf_store_info, &valid);
#if 0
        GetDbgFwdBufStoreInfo(A, operationType_f, &dbg_fwd_buf_store_info, &operationType);
        GetDbgFwdBufStoreInfo(A, svlanTagOperationValid_f, &dbg_fwd_buf_store_info, &svlanTagOperationValid);
        GetDbgFwdBufStoreInfo(A, stagAction_f, &dbg_fwd_buf_store_info, &sTagAction);
        GetDbgFwdBufStoreInfo(A, sourceCos_f, &dbg_fwd_buf_store_info, &sourceCos);
        GetDbgFwdBufStoreInfo(A, sourceCfi_f, &dbg_fwd_buf_store_info, &sourceCfi);
        GetDbgFwdBufStoreInfo(A, srcVlanId_f, &dbg_fwd_buf_store_info, &srcVlanId);
#endif
        //GetDbgFwdBufStoreInfo(A, svlanTpidIndex_f, &dbg_fwd_buf_store_info, &svlanTpidIndex);

        //GetDbgFwdBufStoreInfo(A, u1_normal_cvlanTagOperationValid_f, &dbg_fwd_buf_store_info, &cvlanTagOperationValid);
        //GetDbgFwdBufStoreInfo(A, u1_normal_cTagAction_f, &dbg_fwd_buf_store_info, &cTagAction);
        //GetDbgFwdBufStoreInfo(A, u1_normal_srcCtagCos_f, &dbg_fwd_buf_store_info, &srcCtagCos);
        //GetDbgFwdBufStoreInfo(A, u1_normal_srcCtagCfi_f, &dbg_fwd_buf_store_info, &srcCtagCfi);
        //GetDbgFwdBufStoreInfo(A, u1_normal_srcCvlanId_f, &dbg_fwd_buf_store_info, &srcCvlanId);

        if (valid)
        {

             if ((svlanTagOperationValid && sTagAction) || (cvlanTagOperationValid && cTagAction&&(OPERATIONTYPE_NORMAL == operationType)))
             {
                 CTC_DKIT_PATH_PRINT("%-15s\n", "vlan edit--->");
             }
            if (svlanTagOperationValid)
            {
                uint32 field_id[4] = {EpeHdrAdjustCtl_array_0_svlanTagTpid_f,EpeHdrAdjustCtl_array_1_svlanTagTpid_f,
                                                       EpeHdrAdjustCtl_array_2_svlanTagTpid_f,EpeHdrAdjustCtl_array_3_svlanTagTpid_f};
                cmd = DRV_IOR(EpeHdrAdjustCtl_t, field_id[svlanTpidIndex]);
                DRV_IOCTL(lchip, 0, cmd, &svlanTpid);
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "svlan edit", vlan_action[sTagAction]);
                if ((VTAGACTIONTYPE_MODIFY == sTagAction) || (VTAGACTIONTYPE_ADD == sTagAction))
                {
                    CTC_DKIT_PATH_PRINT("%-15s:0x%04x\n", "new TPID", svlanTpid);
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new COS", sourceCos);
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new CFI", sourceCfi);
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new vlan id", srcVlanId);
                }
            }
            if((cvlanTagOperationValid)&&(OPERATIONTYPE_NORMAL == operationType))
            {
                cmd = DRV_IOR(EpeHdrAdjustCtl_t, EpeHdrAdjustCtl_cvlanTagTpid_f);
                DRV_IOCTL(lchip, 0, cmd, &cvlanTagTpid);
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "cvlan edit", vlan_action[cTagAction]);
                if ((VTAGACTIONTYPE_MODIFY == cTagAction) || (VTAGACTIONTYPE_ADD == cTagAction))
                {
                    CTC_DKIT_PATH_PRINT("%-15s:0x%04x\n", "new TPID", cvlanTagTpid);
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new COS", srcCtagCos);
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new CFI", srcCtagCfi);
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new vlan id", srcCvlanId);
                }
            }
        }
    }

    _ctc_goldengate_dkit_captured_path_discard_process(p_info, discard, discardType, CTC_DKIT_IPE);
    _ctc_goldengate_dkit_captured_path_exception_process(p_info, exceptionEn, exceptionIndex, exceptionSubIndex);
    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_ipe_tunnel(ctc_dkit_captured_path_info_t* p_info)
{
    uint8 slice = p_info->slice_ipe;
    uint8 lchip = p_info->lchip;
    uint32 cmd = 0;
    /*DbgUserIdHashEngineForMpls0Info*/
    uint32 mpls0_lookupResultValid = 0;
    uint32 mpls0_defaultEntryValid = 0;
    uint32 mpls0_keyIndex = 0;
    uint32 mpls0_adIndex = 0;
    uint32 mpls0_hashConflict = 0;
    uint32 mpls0_CAMlookupResultValid = 0;
    uint32 mpls0_keyIndexCam = 0;
    uint32 mpls0_valid = 0;
    DbgUserIdHashEngineForMpls0Info_m dbg_user_id_hash_engine_for_mpls0_info;
    /*DbgUserIdHashEngineForMpls1Info*/
    uint32 mpls1_lookupResultValid = 0;
    uint32 mpls1_defaultEntryValid = 0;
    uint32 mpls1_keyIndex = 0;
    uint32 mpls1_adIndex = 0;
    uint32 mpls1_hashConflict = 0;
    uint32 mpls1_CAMlookupResultValid = 0;
    uint32 mpls1_keyIndexCam = 0;
    uint32 mpls1_valid = 0;
    DbgUserIdHashEngineForMpls1Info_m dbg_user_id_hash_engine_for_mpls1_info;
    /*DbgUserIdHashEngineForMpls2Info*/
    uint32 mpls2_lookupResultValid = 0;
    uint32 mpls2_defaultEntryValid = 0;
    uint32 mpls2_keyIndex = 0;
    uint32 mpls2_adIndex = 0;
    uint32 mpls2_hashConflict = 0;
    uint32 mpls2_CAMlookupResultValid = 0;
    uint32 mpls2_keyIndexCam = 0;
    uint32 mpls2_valid = 0;
    DbgUserIdHashEngineForMpls2Info_m dbg_user_id_hash_engine_for_mpls2_info;
    /*DbgIpeMplsDecapInfo*/
    uint32 tunnel_tunnelDecap1 = 0;
    uint32 tunnel_tunnelDecap2 = 0;
    uint32 tunnel_ipMartianAddress = 0;
    uint32 tunnel_labelNum = 0;
    uint32 tunnel_isMplsSwitched = 0;
    uint32 tunnel_contextLabelExist = 0;
    uint32 tunnel_innerPacketLookup = 0;
    uint32 tunnel_forceParser = 0;
    uint32 tunnel_secondParserForEcmp = 0;
    uint32 tunnel_isDecap = 0;
    uint32 tunnel_srcDscp = 0;
    uint32 tunnel_mplsLabelOutOfRange = 0;
    uint32 tunnel_useEntropyLabelHash = 0;
    uint32 tunnel_rxOamType = 0;
    uint32 tunnel_packetTtl = 0;
    uint32 tunnel_isLeaf = 0;
    uint32 tunnel_logicPortType = 0;
    uint32 tunnel_serviceAclQosEn = 0;
    uint32 tunnel_payloadPacketType = 0;
    uint32 tunnel_dsFwdPtrValid = 0;
    uint32 tunnel_nextHopPtrValid = 0;
    uint32 tunnel_isPtpTunnel = 0;
    uint32 tunnel_ptpDeepParser = 0;
    uint32 tunnel_ptpExtraLabelNum = 0;
    uint32 tunnel_dsFwdPtr = 0;
    uint32 tunnel_discard = 0;
    uint32 tunnel_discardType = 0;
    uint32 tunnel_bypassAll = 0;
    uint32 tunnel_exceptionEn = 0;
    uint32 tunnel_exceptionIndex = 0;
    uint32 tunnel_exceptionSubIndex = 0;
    uint32 tunnel_fatalExceptionValid = 0;
    uint32 tunnel_fatalException = 0;
    uint32 tunnel_innerParserOffset = 0;
    uint32 tunnel_innerParserPacketType = 0;
    uint32 tunnel_mplsLmEn0 = 0;
    uint32 tunnel_mplsLmEn1 = 0;
    uint32 tunnel_mplsLmEn2 = 0;
    uint32 tunnel_firstLabel = 0;
    uint32 tunnel_valid = 0;
    DbgIpeMplsDecapInfo_m dbg_ipe_mpls_decap_info;

    /*DbgUserIdHashEngineForMpls0Info*/
    sal_memset(&dbg_user_id_hash_engine_for_mpls0_info, 0, sizeof(dbg_user_id_hash_engine_for_mpls0_info));
    cmd = DRV_IOR(DbgUserIdHashEngineForMpls0Info_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_user_id_hash_engine_for_mpls0_info);
    GetDbgUserIdHashEngineForMpls0Info(A, userIdHashEngineForMpls0InfoLookupResultValid_f, &dbg_user_id_hash_engine_for_mpls0_info, &mpls0_lookupResultValid );
    //- GetDbgUserIdHashEngineForMpls0Info(A, defaultEntryValid_f, &dbg_user_id_hash_engine_for_mpls0_info, &mpls0_defaultEntryValid );
    GetDbgUserIdHashEngineForMpls0Info(A, userIdHashEngineForMpls0InfoKeyIndex_f, &dbg_user_id_hash_engine_for_mpls0_info, &mpls0_keyIndex);
    GetDbgUserIdHashEngineForMpls0Info(A, userIdHashEngineForMpls0InfoAdIndex_f, &dbg_user_id_hash_engine_for_mpls0_info, &mpls0_adIndex);
    //- GetDbgUserIdHashEngineForMpls0Info(A, hashConflict_f, &dbg_user_id_hash_engine_for_mpls0_info, &mpls0_hashConflict);
    //- GetDbgUserIdHashEngineForMpls0Info(A, camLookupResultValid_f, &dbg_user_id_hash_engine_for_mpls0_info, &mpls0_CAMlookupResultValid);
    //- GetDbgUserIdHashEngineForMpls0Info(A, keyIndexCam_f, &dbg_user_id_hash_engine_for_mpls0_info, &mpls0_keyIndexCam);
    GetDbgUserIdHashEngineForMpls0Info(A, userIdHashEngineForMpls0InfoValid_f, &dbg_user_id_hash_engine_for_mpls0_info, &mpls0_valid);

    /*DbgUserIdHashEngineForMpls1Info*/
    sal_memset(&dbg_user_id_hash_engine_for_mpls1_info, 0, sizeof(dbg_user_id_hash_engine_for_mpls1_info));
    cmd = DRV_IOR(DbgUserIdHashEngineForMpls1Info_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_user_id_hash_engine_for_mpls1_info);
    GetDbgUserIdHashEngineForMpls1Info(A, userIdHashEngineForMpls1InfoLookupResultValid_f, &dbg_user_id_hash_engine_for_mpls1_info, &mpls1_lookupResultValid );
    //- GetDbgUserIdHashEngineForMpls1Info(A, defaultEntryValid_f, &dbg_user_id_hash_engine_for_mpls1_info, &mpls1_defaultEntryValid );
    GetDbgUserIdHashEngineForMpls1Info(A, userIdHashEngineForMpls1InfoKeyIndex_f, &dbg_user_id_hash_engine_for_mpls1_info, &mpls1_keyIndex);
    GetDbgUserIdHashEngineForMpls1Info(A, userIdHashEngineForMpls1InfoAdIndex_f, &dbg_user_id_hash_engine_for_mpls1_info, &mpls1_adIndex);
    //- GetDbgUserIdHashEngineForMpls1Info(A, hashConflict_f, &dbg_user_id_hash_engine_for_mpls1_info, &mpls1_hashConflict);
    //- GetDbgUserIdHashEngineForMpls1Info(A, camLookupResultValid_f, &dbg_user_id_hash_engine_for_mpls1_info, &mpls1_CAMlookupResultValid);
    //- GetDbgUserIdHashEngineForMpls1Info(A, keyIndexCam_f, &dbg_user_id_hash_engine_for_mpls1_info, &mpls1_keyIndexCam);
    GetDbgUserIdHashEngineForMpls1Info(A, userIdHashEngineForMpls1InfoValid_f, &dbg_user_id_hash_engine_for_mpls1_info, &mpls1_valid);

    /*DbgUserIdHashEngineForMpls2Info*/
    sal_memset(&dbg_user_id_hash_engine_for_mpls2_info, 0, sizeof(dbg_user_id_hash_engine_for_mpls2_info));
    cmd = DRV_IOR(DbgUserIdHashEngineForMpls2Info_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_user_id_hash_engine_for_mpls2_info);
    GetDbgUserIdHashEngineForMpls2Info(A, userIdHashEngineForMpls2InfoLookupResultValid_f, &dbg_user_id_hash_engine_for_mpls2_info, &mpls2_lookupResultValid );
    //- GetDbgUserIdHashEngineForMpls2Info(A, defaultEntryValid_f, &dbg_user_id_hash_engine_for_mpls2_info, &mpls2_defaultEntryValid );
    GetDbgUserIdHashEngineForMpls2Info(A, userIdHashEngineForMpls2InfoKeyIndex_f, &dbg_user_id_hash_engine_for_mpls2_info, &mpls2_keyIndex);
    GetDbgUserIdHashEngineForMpls2Info(A, userIdHashEngineForMpls2InfoAdIndex_f, &dbg_user_id_hash_engine_for_mpls2_info, &mpls2_adIndex);
    //- GetDbgUserIdHashEngineForMpls2Info(A, hashConflict_f, &dbg_user_id_hash_engine_for_mpls2_info, &mpls2_hashConflict);
    //- GetDbgUserIdHashEngineForMpls2Info(A, camLookupResultValid_f, &dbg_user_id_hash_engine_for_mpls2_info, &mpls2_CAMlookupResultValid);
    //- GetDbgUserIdHashEngineForMpls2Info(A, keyIndexCam_f, &dbg_user_id_hash_engine_for_mpls2_info, &mpls2_keyIndexCam);
    GetDbgUserIdHashEngineForMpls2Info(A, userIdHashEngineForMpls2InfoValid_f, &dbg_user_id_hash_engine_for_mpls2_info, &mpls2_valid);

    /*DbgIpeMplsDecapInfo*/
    sal_memset(&dbg_ipe_mpls_decap_info, 0, sizeof(dbg_ipe_mpls_decap_info));
    cmd = DRV_IOR(DbgIpeMplsDecapInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_ipe_mpls_decap_info);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoTunnelDecap1_f, &dbg_ipe_mpls_decap_info, &tunnel_tunnelDecap1);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoTunnelDecap2_f, &dbg_ipe_mpls_decap_info, &tunnel_tunnelDecap2);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoIpMartianAddress_f, &dbg_ipe_mpls_decap_info, &tunnel_ipMartianAddress);
    //- GetDbgIpeMplsDecapInfo(A, labelNum_f, &dbg_ipe_mpls_decap_info, &tunnel_labelNum);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoIsMplsSwitched_f, &dbg_ipe_mpls_decap_info, &tunnel_isMplsSwitched);
    //- GetDbgIpeMplsDecapInfo(A, contextLabelExist_f, &dbg_ipe_mpls_decap_info, &tunnel_contextLabelExist);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoInnerPacketLookup_f, &dbg_ipe_mpls_decap_info, &tunnel_innerPacketLookup);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoForceParser_f, &dbg_ipe_mpls_decap_info, &tunnel_forceParser);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoSecondParserForEcmp_f, &dbg_ipe_mpls_decap_info, &tunnel_secondParserForEcmp);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoIsDecap_f, &dbg_ipe_mpls_decap_info, &tunnel_isDecap);
    //- GetDbgIpeMplsDecapInfo(A, srcDscp_f, &dbg_ipe_mpls_decap_info, &tunnel_srcDscp);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoMplsLabelOutOfRange_f, &dbg_ipe_mpls_decap_info, &tunnel_mplsLabelOutOfRange);
    //- GetDbgIpeMplsDecapInfo(A, useEntropyLabelHash_f, &dbg_ipe_mpls_decap_info, &tunnel_useEntropyLabelHash);
    //- GetDbgIpeMplsDecapInfo(A, rxOamType_f, &dbg_ipe_mpls_decap_info, &tunnel_rxOamType);
    //- GetDbgIpeMplsDecapInfo(A, packetTtl_f, &dbg_ipe_mpls_decap_info, &tunnel_packetTtl);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoIsLeaf_f, &dbg_ipe_mpls_decap_info, &tunnel_isLeaf);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoLogicPortType_f, &dbg_ipe_mpls_decap_info, &tunnel_logicPortType);
    //- GetDbgIpeMplsDecapInfo(A, serviceAclQosEn_f, &dbg_ipe_mpls_decap_info, &tunnel_serviceAclQosEn);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoPayloadPacketType_f, &dbg_ipe_mpls_decap_info, &tunnel_payloadPacketType);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoDsFwdPtrValid_f, &dbg_ipe_mpls_decap_info, &tunnel_dsFwdPtrValid);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoNextHopPtrValid_f, &dbg_ipe_mpls_decap_info, &tunnel_nextHopPtrValid);
    //- GetDbgIpeMplsDecapInfo(A, isPtpTunnel_f, &dbg_ipe_mpls_decap_info, &tunnel_isPtpTunnel);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoPtpDeepParser_f, &dbg_ipe_mpls_decap_info, &tunnel_ptpDeepParser);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoPtpExtraLabelNum_f, &dbg_ipe_mpls_decap_info, &tunnel_ptpExtraLabelNum);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoDsFwdPtr_f, &dbg_ipe_mpls_decap_info, &tunnel_dsFwdPtr);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoDiscard_f, &dbg_ipe_mpls_decap_info, &tunnel_discard);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoDiscardType_f, &dbg_ipe_mpls_decap_info, &tunnel_discardType);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoBypassAll_f, &dbg_ipe_mpls_decap_info, &tunnel_bypassAll);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoExceptionEn_f, &dbg_ipe_mpls_decap_info, &tunnel_exceptionEn);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoExceptionIndex_f, &dbg_ipe_mpls_decap_info, &tunnel_exceptionIndex);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoExceptionSubIndex_f, &dbg_ipe_mpls_decap_info, &tunnel_exceptionSubIndex);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoFatalExceptionValid_f, &dbg_ipe_mpls_decap_info, &tunnel_fatalExceptionValid);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoFatalException_f, &dbg_ipe_mpls_decap_info, &tunnel_fatalException);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoInnerParserOffset_f, &dbg_ipe_mpls_decap_info, &tunnel_innerParserOffset);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoInnerParserPacketType_f, &dbg_ipe_mpls_decap_info, &tunnel_innerParserPacketType);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoMplsLmEn0_f, &dbg_ipe_mpls_decap_info, &tunnel_mplsLmEn0);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoMplsLmEn1_f, &dbg_ipe_mpls_decap_info, &tunnel_mplsLmEn1);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoMplsLmEn2_f, &dbg_ipe_mpls_decap_info, &tunnel_mplsLmEn2);
    //- GetDbgIpeMplsDecapInfo(A, firstLabel_f, &dbg_ipe_mpls_decap_info, &tunnel_firstLabel);
    GetDbgIpeMplsDecapInfo(A, ipeMplsDecapInfoValid_f, &dbg_ipe_mpls_decap_info, &tunnel_valid);

    if (0 == p_info->detail)
    {
        goto Discard;
    }

    if (tunnel_valid)
    {
        if (tunnel_tunnelDecap1 || tunnel_tunnelDecap2)
        {
            CTC_DKIT_PRINT("Tunnel Process:\n");
            if (tunnel_innerPacketLookup)
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "forward by", "inner packet");
            }
            else
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "forward by", "tunnel");
            }
        }
        else if (tunnel_isMplsSwitched)
        {
            uint8 i = 0;
            uint32 mpls_valid[3] = {mpls0_valid, mpls1_valid, mpls2_valid};
            uint32 mpls_key_index[3] = {mpls0_keyIndex, mpls1_keyIndex, mpls2_keyIndex};
            uint32 mpls_ad_index[3] = {mpls0_adIndex, mpls1_adIndex, mpls2_adIndex};
            uint32 mpls_conflict[3] = {mpls0_hashConflict, mpls1_hashConflict, mpls2_hashConflict};
            uint32 mpls_default[3] = {mpls0_defaultEntryValid, mpls1_defaultEntryValid, mpls2_defaultEntryValid};
            uint32 mpls_result_valid[3] = {mpls0_lookupResultValid, mpls1_lookupResultValid, mpls2_lookupResultValid};
            CTC_DKIT_PRINT("MPLS Process:\n");
            for (i = 0; i < 3; i++)
            {
                if (mpls_valid[i])
                {
                    if (0 == i)
                    {
                        CTC_DKIT_PATH_PRINT("%-15s\n", "1st label lookup--->");
                    }
                    else if (1 == i)
                    {
                        CTC_DKIT_PATH_PRINT("%-15s\n", "2nd label lookup--->");
                    }
                    else if (2 == i)
                    {
                        CTC_DKIT_PATH_PRINT("%-15s\n", "3th label lookup--->");
                    }
                    if (mpls_conflict[i])
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_CONFLICT);
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", mpls_key_index[i]);
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", "DsUserIdTunnelMplsHashKey");
                    }
                    else if (mpls_default[i])
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_DEFAULT);
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", mpls_key_index[i]);
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", "DsUserIdTunnelMplsHashKey");
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "AD index", (mpls_ad_index[i] / 2));
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "AD name", "DsMpls");
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "pop lable", "YES");
                    }
                    else if (mpls_result_valid[i])
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_HASH_HIT);
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", mpls_key_index[i]);
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", "DsUserIdTunnelMplsHashKey");
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "AD index", (mpls_ad_index[i] / 2));
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "AD name", "DsMpls");
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "pop lable", "YES");
                    }
                    else
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
                    }
                }
            }
            if(tunnel_innerPacketLookup)
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "forward by", "inner packet");
            }
            else
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "forward by", "MPLS label");
            }
        }
    }

Discard:
    _ctc_goldengate_dkit_captured_path_discard_process(p_info, tunnel_discard, tunnel_discardType, CTC_DKIT_IPE);
    _ctc_goldengate_dkit_captured_path_exception_process(p_info, tunnel_exceptionEn, tunnel_exceptionIndex, tunnel_exceptionSubIndex);

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_ipe_flow_hash(ctc_dkit_captured_path_info_t* p_info)
{
    uint8  slice = p_info->slice_ipe;
    uint8  lchip = p_info->lchip;
    uint32 cmd = 0;

    char*  str_hash_key_name[] = {"Invalid", "DsFlowL2HashKey", "DsFlowL2L3HashKey", "DsFlowL3Ipv4HashKey",
                                    "DsFlowL3Ipv6HashKey", "DsFlowL3MplsHashKey"};
    char*  str_field_sel_name[] = {"Invalid", "FlowL2HashFieldSelect", "FlowL2L3HashFieldSelect", "FlowL3Ipv4HashFieldSelect",
                                    "FlowL3Ipv6HashFieldSelect", "FlowL3MplsHashFieldSelect"};

    /*DbgFibLkpEngineFlowHashInfo*/
    uint32 hashKeyType = 0;
    uint32 hashLookupEn = 0;
    uint32 flowFieldSel = 0;
    uint32 flowL2KeyUseCvlan = 0;
    uint32 lookupResultValid = 0;
    uint32 hashConflict = 0;
    uint32 keyIndex = 0;
    uint32 dsAdIndex = 0;
    uint32 hash_valid = 0;
    DbgFibLkpEngineFlowHashInfo_m dbg_fib_lkp_engine_flow_hash_info;


    /*DbgFibLkpEngineFlowHashInfo*/
    sal_memset(&dbg_fib_lkp_engine_flow_hash_info, 0, sizeof(dbg_fib_lkp_engine_flow_hash_info));
    cmd = DRV_IOR(DbgFibLkpEngineFlowHashInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_fib_lkp_engine_flow_hash_info);
    GetDbgFibLkpEngineFlowHashInfo(A, fibLkpEngineFlowHashInfoGFlowHashLkp_hashKeyType_f, &dbg_fib_lkp_engine_flow_hash_info, &hashKeyType);
    GetDbgFibLkpEngineFlowHashInfo(A, fibLkpEngineFlowHashInfoGFlowHashLkp_flowHashLookupEn_f, &dbg_fib_lkp_engine_flow_hash_info, &hashLookupEn);
    GetDbgFibLkpEngineFlowHashInfo(A, fibLkpEngineFlowHashInfoGFlowHashLkp_flowFieldSel_f, &dbg_fib_lkp_engine_flow_hash_info, &flowFieldSel);
    GetDbgFibLkpEngineFlowHashInfo(A, fibLkpEngineFlowHashInfoGFlowHashLkp_flowL2KeyUseCvlan_f, &dbg_fib_lkp_engine_flow_hash_info, &flowL2KeyUseCvlan);
    GetDbgFibLkpEngineFlowHashInfo(A, fibLkpEngineFlowHashInfoGFlowHashResult_lookupResultValid_f, &dbg_fib_lkp_engine_flow_hash_info, &lookupResultValid);
    GetDbgFibLkpEngineFlowHashInfo(A, fibLkpEngineFlowHashInfoGFlowHashResult_hashConflict_f, &dbg_fib_lkp_engine_flow_hash_info, &hashConflict);
    GetDbgFibLkpEngineFlowHashInfo(A, fibLkpEngineFlowHashInfoGFlowHashResult_keyIndex_f, &dbg_fib_lkp_engine_flow_hash_info, &keyIndex);
    GetDbgFibLkpEngineFlowHashInfo(A, fibLkpEngineFlowHashInfoGFlowHashResult_dsAdIndex_f, &dbg_fib_lkp_engine_flow_hash_info, &dsAdIndex);
    GetDbgFibLkpEngineFlowHashInfo(A, fibLkpEngineFlowHashInfoValid_f, &dbg_fib_lkp_engine_flow_hash_info, &hash_valid);

    if (0 == p_info->detail)
    {
        goto Discard;
    }

    /*hash*/
    if (hash_valid && hashLookupEn)
    {
        CTC_DKIT_PRINT("Flow HASH lookup--->");
        if (hashConflict)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_CONFLICT);
            CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", keyIndex);
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", str_hash_key_name[hashKeyType]);
        }
        else if (lookupResultValid)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_HASH_HIT);
            CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", keyIndex);
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", str_hash_key_name[hashKeyType]);
            CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "field sel", flowFieldSel);
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "field sel name", str_field_sel_name[hashKeyType]);
            CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "AD index", dsAdIndex);
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "AD name", "DsFlow");
        }
        else
        {
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
        }

    }

Discard:
 //   _ctc_goldengate_dkit_captured_path_discard_process(p_info, acl_discard, acl_discardType, CTC_DKIT_IPE);
 //   _ctc_goldengate_dkit_captured_path_exception_process(p_info, acl_exceptionEn, acl_exceptionIndex, acl_exceptionSubIndex);

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_ipe_acl(ctc_dkit_captured_path_info_t* p_info)
{
    uint8 slice = p_info->slice_ipe;
    uint8 lchip = p_info->lchip;
    uint32 cmd = 0;
    uint8 idx = 0;

    char* acl_key_type_desc[] = {"TCAML2KEY", "TCAML2L3KEY", "TCAMVLANKEY", "TCAML3EXTKEY", "TCAML2L3EXTKEY",
                                 "TCAMCIDKEY", "TCAMINTFKEY", "TCAMFWDKEY", "TCAMFWDEXT"};

    /*DbgFlowTcamEngineIpeAclInfo*/
    uint32 acl0TcamResultValid = 0;
    uint32 acl0TcamIndex = 0;
    uint32 acl0TcamValid = 0;
    uint32 acl1TcamResultValid = 0;
    uint32 acl1TcamIndex = 0;
    uint32 acl1TcamValid = 0;
    uint32 acl2TcamResultValid = 0;
    uint32 acl2TcamIndex = 0;
    uint32 acl2TcamValid = 0;
    uint32 acl3TcamResultValid = 0;
    uint32 acl3TcamIndex = 0;
    uint32 acl3TcamValid = 0;
    uint32 acl4TcamResultValid = 0;
    uint32 acl4TcamIndex = 0;
    uint32 acl4TcamValid = 0;
    uint32 acl5TcamResultValid = 0;
    uint32 acl5TcamIndex = 0;
    uint32 acl5TcamValid = 0;
    uint32 acl6TcamResultValid = 0;
    uint32 acl6TcamIndex = 0;
    uint32 acl6TcamValid = 0;
    uint32 acl7TcamResultValid = 0;
    uint32 acl7TcamIndex = 0;
    uint32 acl7TcamValid = 0;
    DbgFlowTcamEngineIpeAclInfo0_m dbg_flow_tcam_engine_ipe_acl_info;

    /*DbgFlowTcamEngineIpeAclKeyInfo0-7*/
    uint32 acl_key_info[10] = {0};
    uint32 acl_key_valid = 0;
    DbgFlowTcamEngineIpeAclKeyInfo0_m dbg_acl_key_info;
    uint8  step = DbgFlowTcamEngineIpeAclKeyInfo1_flowTcamEngineIpeAclKeyInfo1Key_f -       \
                        DbgFlowTcamEngineIpeAclKeyInfo0_flowTcamEngineIpeAclKeyInfo0Key_f;
    uint32 acl_key_info_key_id[8] = {DbgFlowTcamEngineIpeAclKeyInfo0_t, DbgFlowTcamEngineIpeAclKeyInfo1_t,
                                     DbgFlowTcamEngineIpeAclKeyInfo2_t, DbgFlowTcamEngineIpeAclKeyInfo3_t,
                                     DbgFlowTcamEngineIpeAclKeyInfo4_t, DbgFlowTcamEngineIpeAclKeyInfo5_t,
                                     DbgFlowTcamEngineIpeAclKeyInfo6_t, DbgFlowTcamEngineIpeAclKeyInfo7_t};
    uint32 acl_key_type = 0;

    uint32 acl_lkup_en_bitmap = 0;

    /*DbgIpeAclProcInfo*/
    uint32 acl_merge_result_valid0 = 0;
    uint32 acl_merge_result_valid1 = 0;
    uint32 acl_merge_result_valid2 = 0;
    uint32 acl_merge_result_valid3 = 0;
    uint32 acl_merge_result_valid4 = 0;
    uint32 acl_merge_result_valid5 = 0;
    uint32 acl_merge_result_valid6 = 0;
    uint32 acl_merge_result_valid7 = 0;

    uint32 acl_valid = 0;
    DbgIpeAclProcInfo_m dbg_ipe_acl_proc_info;

    /*DbgFlowTcamEngineIpeAclInfo0*/
    sal_memset(&dbg_flow_tcam_engine_ipe_acl_info, 0, sizeof(dbg_flow_tcam_engine_ipe_acl_info));
    cmd = DRV_IOR(DbgFlowTcamEngineIpeAclInfo0_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_flow_tcam_engine_ipe_acl_info);
    GetDbgFlowTcamEngineIpeAclInfo0(A, flowTcamEngineIpeAclInfo0IngrTcamResultValid0_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl0TcamResultValid);
    GetDbgFlowTcamEngineIpeAclInfo0(A, flowTcamEngineIpeAclInfo0IngrTcamIndex0_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl0TcamIndex);
    GetDbgFlowTcamEngineIpeAclInfo0(A, flowTcamEngineIpeAclInfo0Valid_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl0TcamValid);

    /*DbgFlowTcamEngineIpeAclInfo1*/
    sal_memset(&dbg_flow_tcam_engine_ipe_acl_info, 0, sizeof(dbg_flow_tcam_engine_ipe_acl_info));
    cmd = DRV_IOR(DbgFlowTcamEngineIpeAclInfo1_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_flow_tcam_engine_ipe_acl_info);
    GetDbgFlowTcamEngineIpeAclInfo1(A, flowTcamEngineIpeAclInfo1IngrTcamResultValid1_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl1TcamResultValid);
    GetDbgFlowTcamEngineIpeAclInfo1(A, flowTcamEngineIpeAclInfo1IngrTcamIndex1_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl1TcamIndex);
    GetDbgFlowTcamEngineIpeAclInfo1(A, flowTcamEngineIpeAclInfo1Valid_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl1TcamValid);

    /*DbgFlowTcamEngineIpeAclInfo2*/
    sal_memset(&dbg_flow_tcam_engine_ipe_acl_info, 0, sizeof(dbg_flow_tcam_engine_ipe_acl_info));
    cmd = DRV_IOR(DbgFlowTcamEngineIpeAclInfo2_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_flow_tcam_engine_ipe_acl_info);
    GetDbgFlowTcamEngineIpeAclInfo2(A, flowTcamEngineIpeAclInfo2IngrTcamResultValid2_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl2TcamResultValid);
    GetDbgFlowTcamEngineIpeAclInfo2(A, flowTcamEngineIpeAclInfo2IngrTcamIndex2_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl2TcamIndex);
    GetDbgFlowTcamEngineIpeAclInfo2(A, flowTcamEngineIpeAclInfo2Valid_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl2TcamValid);

    /*DbgFlowTcamEngineIpeAclInfo3*/
    sal_memset(&dbg_flow_tcam_engine_ipe_acl_info, 0, sizeof(dbg_flow_tcam_engine_ipe_acl_info));
    cmd = DRV_IOR(DbgFlowTcamEngineIpeAclInfo3_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_flow_tcam_engine_ipe_acl_info);
    GetDbgFlowTcamEngineIpeAclInfo3(A, flowTcamEngineIpeAclInfo3IngrTcamResultValid3_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl3TcamResultValid);
    GetDbgFlowTcamEngineIpeAclInfo3(A, flowTcamEngineIpeAclInfo3IngrTcamIndex3_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl3TcamIndex);
    GetDbgFlowTcamEngineIpeAclInfo3(A, flowTcamEngineIpeAclInfo3Valid_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl3TcamValid);

    /*DbgFlowTcamEngineIpeAclInfo4*/
    sal_memset(&dbg_flow_tcam_engine_ipe_acl_info, 0, sizeof(dbg_flow_tcam_engine_ipe_acl_info));
    cmd = DRV_IOR(DbgFlowTcamEngineIpeAclInfo4_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_flow_tcam_engine_ipe_acl_info);
    GetDbgFlowTcamEngineIpeAclInfo4(A, flowTcamEngineIpeAclInfo4IngrTcamResultValid4_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl4TcamResultValid);
    GetDbgFlowTcamEngineIpeAclInfo4(A, flowTcamEngineIpeAclInfo4IngrTcamIndex4_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl4TcamIndex);
    GetDbgFlowTcamEngineIpeAclInfo4(A, flowTcamEngineIpeAclInfo4Valid_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl4TcamValid);

    /*DbgFlowTcamEngineIpeAclInfo5*/
    sal_memset(&dbg_flow_tcam_engine_ipe_acl_info, 0, sizeof(dbg_flow_tcam_engine_ipe_acl_info));
    cmd = DRV_IOR(DbgFlowTcamEngineIpeAclInfo5_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_flow_tcam_engine_ipe_acl_info);
    GetDbgFlowTcamEngineIpeAclInfo5(A, flowTcamEngineIpeAclInfo5IngrTcamResultValid5_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl5TcamResultValid);
    GetDbgFlowTcamEngineIpeAclInfo5(A, flowTcamEngineIpeAclInfo5IngrTcamIndex5_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl5TcamIndex);
    GetDbgFlowTcamEngineIpeAclInfo5(A, flowTcamEngineIpeAclInfo5Valid_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl5TcamValid);

    /*DbgFlowTcamEngineIpeAclInfo6*/
    sal_memset(&dbg_flow_tcam_engine_ipe_acl_info, 0, sizeof(dbg_flow_tcam_engine_ipe_acl_info));
    cmd = DRV_IOR(DbgFlowTcamEngineIpeAclInfo6_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_flow_tcam_engine_ipe_acl_info);
    GetDbgFlowTcamEngineIpeAclInfo6(A, flowTcamEngineIpeAclInfo6IngrTcamResultValid6_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl6TcamResultValid);
    GetDbgFlowTcamEngineIpeAclInfo6(A, flowTcamEngineIpeAclInfo6IngrTcamIndex6_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl6TcamIndex);
    GetDbgFlowTcamEngineIpeAclInfo6(A, flowTcamEngineIpeAclInfo6Valid_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl6TcamValid);

    /*DbgFlowTcamEngineIpeAclInfo7*/
    sal_memset(&dbg_flow_tcam_engine_ipe_acl_info, 0, sizeof(dbg_flow_tcam_engine_ipe_acl_info));
    cmd = DRV_IOR(DbgFlowTcamEngineIpeAclInfo7_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_flow_tcam_engine_ipe_acl_info);
    GetDbgFlowTcamEngineIpeAclInfo7(A, flowTcamEngineIpeAclInfo7IngrTcamResultValid7_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl7TcamResultValid);
    GetDbgFlowTcamEngineIpeAclInfo7(A, flowTcamEngineIpeAclInfo7IngrTcamIndex7_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl7TcamIndex);
    GetDbgFlowTcamEngineIpeAclInfo7(A, flowTcamEngineIpeAclInfo7Valid_f, &dbg_flow_tcam_engine_ipe_acl_info, &acl7TcamValid);

    /*DbgIpeFwdProcessInfo*/
    cmd = DRV_IOR(DbgIpeFwdProcessInfo_t, DbgIpeFwdProcessInfo_ipeFwdProcessInfoAclEnBitMap_f);
    DRV_IOCTL(lchip, slice, cmd, &acl_lkup_en_bitmap);

     /*DbgIpeAclProcInfo*/
    sal_memset(&dbg_ipe_acl_proc_info, 0, sizeof(dbg_ipe_acl_proc_info));
    cmd = DRV_IOR(DbgIpeAclProcInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_ipe_acl_proc_info);

    if (0 == p_info->detail)
    {
        goto Discard;
    }

    if (acl_lkup_en_bitmap)
    {
        CTC_DKIT_PRINT("ACL Process:\n");

        /*tcam*/
        if (acl0TcamValid || acl1TcamValid || acl2TcamValid || acl3TcamValid ||
            acl4TcamValid || acl5TcamValid || acl6TcamValid || acl7TcamValid)
        {
            char* lookup_result[8] = {"TCAM0 lookup--->", "TCAM1 lookup--->", "TCAM2 lookup--->", "TCAM3 lookup--->",
                                      "TCAM4 lookup--->", "TCAM5 lookup--->", "TCAM6 lookup--->", "TCAM7 lookup--->"};
            uint32 result_valid[8] = {acl0TcamResultValid, acl1TcamResultValid, acl2TcamResultValid, acl3TcamResultValid,
                                      acl4TcamResultValid, acl5TcamResultValid, acl6TcamResultValid, acl7TcamResultValid};
            uint32 tcam_index[8] = {acl0TcamIndex, acl1TcamIndex, acl2TcamIndex, acl3TcamIndex,
                                    acl4TcamIndex, acl5TcamIndex, acl6TcamIndex, acl7TcamIndex};

            for (idx = 0; idx < 8 ; idx++)
            {
                if ((acl_lkup_en_bitmap >> idx) & 0x1)
                {
                    CTC_DKIT_PATH_PRINT("%-15s\n", lookup_result[idx]);

                    cmd = DRV_IOR(acl_key_info_key_id[idx], DRV_ENTRY_FLAG);
                    DRV_IOCTL(lchip, 0, cmd, &dbg_acl_key_info);
                    DRV_GET_FIELD_A(acl_key_info_key_id[idx], DbgFlowTcamEngineIpeAclKeyInfo0_flowTcamEngineIpeAclKeyInfo0Key_f + step * idx,
                                    &dbg_acl_key_info, &acl_key_info);
                    DRV_GET_FIELD_A(acl_key_info_key_id[idx], DbgFlowTcamEngineIpeAclKeyInfo0_flowTcamEngineIpeAclKeyInfo0Valid_f + step * idx,
                                    &dbg_acl_key_info, &acl_key_valid);
                    /*get key type*/
                    if(acl_key_valid)
                    {
                        GetDsAclQosL3Key320Ing0(A, aclQosKeyType0_f, acl_key_info, &acl_key_type);
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key type", acl_key_type_desc[acl_key_type]);
                    }
                    else
                    {
                        CTC_DKIT_PATH_PRINT("DbgFlowTcamEngineIpeAclKeyInfo is not valid (just for test)!");
                    }
                    if (result_valid[idx])
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_TCAM_HIT);
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x%s (160bit)\n", "key index", tcam_index[idx]);
                    }
                    else
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
                    }
                }
            }
        }

    }

Discard:
//    _ctc_goldengate_dkit_captured_path_discard_process(p_info, acl_discard, acl_discardType, CTC_DKIT_IPE);
 //   _ctc_goldengate_dkit_captured_path_exception_process(p_info, acl_exceptionEn, acl_exceptionIndex, acl_exceptionSubIndex);

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_capture_path_ipe_cid_pair(ctc_dkit_captured_path_info_t* p_info)
{
    uint8  slice = p_info->slice_ipe;
    uint8  lchip = p_info->lchip;
    uint32 cmd = 0;

    uint32  cid_pair_en = 0;
    char*  str_hash_key_name[] = {"DsCategoryIdPairHashRightKey", "DsCategoryIdPairHashLeftKey"};
    char*  str_hash_ad_name[] = {"DsCategoryIdPairHashRightAd", "DsCategoryIdPairHashLeftAd"};

    uint32 cidPairHashAdIndex = 0;
    uint32 cidPairHashEntryOffset = 0;
    uint32 cidPairHashHit = 0;
    uint32 cidPairHashIsLeft = 0;
    uint32 cidPairHashKeyIndex = 0;
    uint32 cidPairTcamHitIndex = 0;
    uint32 cidPairTcamResultValid = 0;
    uint32 destCategoryIdClassfied = 0;
    uint32 destCategoryId = 0;
    uint32 srcCategoryIdClassfied = 0;
    uint32 srcCategoryId = 0;
    DbgIpeFwdProcessInfo_m dbg_fwd_proc_info;

    uint32 aclLookupLevel = 0;
    uint32 operationMode = 0;
    uint32 aclLabel = 0;
    uint32 aclUseGlobalPortType = 0;
    uint32 aclUsePIVlan = 0;
    uint32 keepAclLabel = 0;
    uint32 keepAclUseGlobalPortType = 0;
    uint32 keepAclUsePIVlan = 0;
    uint32 lookupType = 0;
    uint32 deny = 0;
    uint32 permit = 0;
    DsCategoryIdPair_m     ds_cid_pair;

    if (0 == p_info->detail)
    {
        goto Discard;
    }

    sal_memset(&dbg_fwd_proc_info, 0, sizeof(DbgIpeFwdProcessInfo_m));
    sal_memset(&ds_cid_pair,       0, sizeof(DsCategoryIdPair_m));

    cmd = DRV_IOR(IpeFwdCategoryCtl_t, IpeFwdCategoryCtl_categoryIdPairLookupEn_f);
    DRV_IOCTL(lchip, 0, cmd, &cid_pair_en);

    cmd = DRV_IOR(DbgIpeFwdProcessInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_fwd_proc_info);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoGCidLkp_cidPairHashAdIndex_f     , &dbg_fwd_proc_info, &cidPairHashAdIndex);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoGCidLkp_cidPairHashEntryOffset_f , &dbg_fwd_proc_info, &cidPairHashEntryOffset);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoGCidLkp_cidPairHashHit_f         , &dbg_fwd_proc_info, &cidPairHashHit);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoGCidLkp_cidPairHashIsLeft_f      , &dbg_fwd_proc_info, &cidPairHashIsLeft);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoGCidLkp_cidPairHashKeyIndex_f    , &dbg_fwd_proc_info, &cidPairHashKeyIndex);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoGCidLkp_cidPairTcamHitIndex_f    , &dbg_fwd_proc_info, &cidPairTcamHitIndex);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoGCidLkp_cidPairTcamResultValid_f , &dbg_fwd_proc_info, &cidPairTcamResultValid);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoGCidLkp_destCategoryIdClassfied_f, &dbg_fwd_proc_info, &destCategoryIdClassfied);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoGCidLkp_destCategoryId_f         , &dbg_fwd_proc_info, &destCategoryId);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoGCidLkp_srcCategoryIdClassfied_f , &dbg_fwd_proc_info, &srcCategoryIdClassfied);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoGCidLkp_srcCategoryId_f          , &dbg_fwd_proc_info, &srcCategoryId);

    if(cid_pair_en)
    {
        CTC_DKIT_PRINT("Cid Pair Process:\n");
        if(srcCategoryIdClassfied)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%u\n", "src category id", srcCategoryId);
        }
        else
        {
            CTC_DKIT_PATH_PRINT("src category id not valid!\n");
        }
        if(destCategoryIdClassfied)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%u\n", "dst category id", destCategoryId);
        }
        else
        {
            CTC_DKIT_PATH_PRINT("dest category id not valid!\n");
        }
        CTC_DKIT_PATH_PRINT("Cid Hash Lookup--->\n");
        if (cidPairHashHit)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_HASH_HIT);
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "key index", cidPairHashKeyIndex);
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "array offset", cidPairHashEntryOffset);
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", str_hash_key_name[cidPairHashIsLeft]);
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "Ad index", cidPairHashAdIndex);
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Ad name", str_hash_ad_name[cidPairHashIsLeft]);
            if(cidPairHashIsLeft)
            {
                cmd = DRV_IOR(DsCategoryIdPairHashRightAd_t, DRV_ENTRY_FLAG);
            }
            else
            {
                cmd = DRV_IOR(DsCategoryIdPairHashLeftAd_t, DRV_ENTRY_FLAG);
            }
            DRV_IOCTL(lchip, cidPairHashAdIndex, cmd, &ds_cid_pair);
        }
        else
        {
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
        }
        CTC_DKIT_PATH_PRINT("Cid Tcam Lookup--->\n");
        if (cidPairTcamResultValid)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_TCAM_HIT);
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "key index", cidPairTcamHitIndex);
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", "DsCategoryIdPairTcamKey");
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "Ad index", cidPairTcamHitIndex);
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Ad name", "DsCategoryIdPairTcamAd");
            cmd = DRV_IOR(DsCategoryIdPairTcamAd_t, DRV_ENTRY_FLAG);
            DRV_IOCTL(lchip, cidPairTcamHitIndex, cmd, &ds_cid_pair);
        }
        else
        {
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
        }
        if(cidPairHashHit || cidPairTcamResultValid)
        {
            GetDsCategoryIdPair(A, aclLookupLevel_f                , &ds_cid_pair, &aclLookupLevel);
            GetDsCategoryIdPair(A, operationMode_f                 , &ds_cid_pair, &operationMode);
            GetDsCategoryIdPair(A, u1_g1_aclLabel_f                , &ds_cid_pair, &aclLabel);
            GetDsCategoryIdPair(A, u1_g1_aclUseGlobalPortType_f    , &ds_cid_pair, &aclUseGlobalPortType);
            GetDsCategoryIdPair(A, u1_g1_aclUsePIVlan_f            , &ds_cid_pair, &aclUsePIVlan);
            GetDsCategoryIdPair(A, u1_g1_keepAclLabel_f            , &ds_cid_pair, &keepAclLabel);
            GetDsCategoryIdPair(A, u1_g1_keepAclUseGlobalPortType_f, &ds_cid_pair, &keepAclUseGlobalPortType);
            GetDsCategoryIdPair(A, u1_g1_keepAclUsePIVlan_f        , &ds_cid_pair, &keepAclUsePIVlan);
            GetDsCategoryIdPair(A, u1_g1_lookupType_f              , &ds_cid_pair, &lookupType);
            GetDsCategoryIdPair(A, u1_g2_deny_f                    , &ds_cid_pair, &deny);
            GetDsCategoryIdPair(A, u1_g2_permit_f                  , &ds_cid_pair, &permit);
            if(operationMode)
            {
                if(permit)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Action", "Permit");
                }
                else if(deny)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Action", "Deny");
                }
            }
            else
            {
                CTC_DKIT_PATH_PRINT("%-15s:Overwrite Acl %d\n", "Action", aclLookupLevel);
                CTC_DKIT_PATH_PRINT("%-15s:%d\n", "Acl lkup type", lookupType);
                if(!keepAclLabel)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "Acl label", aclLabel);
                }
                if(!keepAclUsePIVlan)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "use mapped vlan", aclUsePIVlan);
                }

            }

        }
    }

Discard:

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_ipe_forward(ctc_dkit_captured_path_info_t* p_info)
{
    uint8  lchip = p_info->lchip;
    uint32 cmd = 0;

    uint32 phbInfoClassifiedCfi   = 0;
    uint32 phbInfoClassifiedCos   = 0;
    uint32 phbInfoClassifiedDscp  = 0;
    uint32 phbInfoClassifiedTc    = 0;
    uint32 phbInfoColor           = 0;
    uint32 phbInfoPrio            = 0;
    uint32 phbInfoSrcDscpValid    = 0;
    uint32 phbInfoSrcDscp         = 0;
    uint32 phbInfoValid           = 0;
    DbgIpePerHopBehaviorInfo_m dbg_phb_info;

    char*  str_color[] = {"None", "Red", "Yellow", "Green"};

    /*bridge process*/
    _ctc_goldengate_dkit_capture_path_ipe_bridge(p_info);

    /*route process*/
    _ctc_goldengate_dkit_capture_path_ipe_route(p_info);

    /*phb process*/
    sal_memset(&dbg_phb_info, 0, sizeof(DbgIpePerHopBehaviorInfo_m));
    cmd = DRV_IOR(DbgIpePerHopBehaviorInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_phb_info);
    GetDbgIpePerHopBehaviorInfo(A, ipePerHopBehaviorInfoClassifiedCfi_f    , &dbg_phb_info, &phbInfoClassifiedCfi);
    GetDbgIpePerHopBehaviorInfo(A, ipePerHopBehaviorInfoClassifiedCos_f    , &dbg_phb_info, &phbInfoClassifiedCos);
    GetDbgIpePerHopBehaviorInfo(A, ipePerHopBehaviorInfoClassifiedDscp_f   , &dbg_phb_info, &phbInfoClassifiedDscp);
    GetDbgIpePerHopBehaviorInfo(A, ipePerHopBehaviorInfoClassifiedTc_f     , &dbg_phb_info, &phbInfoClassifiedTc);
    GetDbgIpePerHopBehaviorInfo(A, ipePerHopBehaviorInfoColor_f            , &dbg_phb_info, &phbInfoColor);
    GetDbgIpePerHopBehaviorInfo(A, ipePerHopBehaviorInfoPrio_f             , &dbg_phb_info, &phbInfoPrio);
    GetDbgIpePerHopBehaviorInfo(A, ipePerHopBehaviorInfoSrcDscpValid_f     , &dbg_phb_info, &phbInfoSrcDscpValid);
    GetDbgIpePerHopBehaviorInfo(A, ipePerHopBehaviorInfoSrcDscp_f          , &dbg_phb_info, &phbInfoSrcDscp);
    GetDbgIpePerHopBehaviorInfo(A, ipePerHopBehaviorInfoValid_f            , &dbg_phb_info, &phbInfoValid);

    /*policer*/
    if(phbInfoValid)
    {
        CTC_DKIT_PRINT("Phb Process:\n");
        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Phb Color", str_color[phbInfoColor]);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Phb Prio", phbInfoPrio);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Phb ClassifiedCfi", phbInfoClassifiedCfi);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Phb ClassifiedCos", phbInfoClassifiedCos);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Phb ClassifiedDscp", phbInfoClassifiedDscp);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Phb ClassifiedTc", phbInfoClassifiedTc);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Phb SrcDscpValid", phbInfoSrcDscpValid);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Phb SrcDscp", phbInfoSrcDscp);
    }

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_ipe_oam(ctc_dkit_captured_path_info_t* p_info)
{
    uint8 slice = p_info->slice_ipe;
    uint8 lchip = p_info->lchip;
    uint32 cmd = 0;
    uint8 i = 0;
    char* lookup_result[4] = {"ETHER lookup--->", "BFD lookup--->", "TP lookup--->", "Section lookup--->"};
    char* key_name[4] = {"DsEgressXcOamEthHashKey", "DsEgressXcOamBfdHashKey",
                                             "DsEgressXcOamMplsLabelHashKey", "DsEgressXcOamMplsSectionHashKey"};
    /*DbgEgrXcOamHashEngineFromIpeOam0Info*/
    uint32 hash0_resultValid = 0;
    uint32 hash0_egressXcOamHashConflict = 0;
    uint32 hash0_keyIndex = 0;
    uint32 hash0_valid = 0;
    DbgEgrXcOamHashEngineFromIpeOam0Info_m dbg_egr_xc_oam_hash_engine_from_ipe_oam0_info;
    /*DbgEgrXcOamHashEngineFromIpeOam1Info*/
    uint32 hash1_resultValid = 0;
    uint32 hash1_egressXcOamHashConflict = 0;
    uint32 hash1_keyIndex = 0;
    uint32 hash1_valid = 0;
    DbgEgrXcOamHashEngineFromIpeOam1Info_m dbg_egr_xc_oam_hash_engine_from_ipe_oam1_info;
    /*DbgEgrXcOamHashEngineFromIpeOam2Info*/
    uint32 hash2_resultValid = 0;
    uint32 hash2_egressXcOamHashConflict = 0;
    uint32 hash2_keyIndex = 0;
    uint32 hash2_valid = 0;
    DbgEgrXcOamHashEngineFromIpeOam2Info_m dbg_egr_xc_oam_hash_engine_from_ipe_oam2_info;
    /*DbgIpeLkpMgrInfo*/
    uint32 lkp_oamUseFid = 0;
    uint32 lkp_mplsLmValid = 0;
    uint32 lkp_mplsSectionLmValid = 0;
    uint32 lkp_ingressOamKeyType0 = 0;
    uint32 lkp_ingressOamKeyType1 = 0;
    uint32 lkp_ingressOamKeyType2 = 0;
    uint32 lkp_valid = 0;
    DbgIpeLkpMgrInfo_m dbg_ipe_lkp_mgr_info;
    /*DbgIpeOamInfo*/
    uint32 oam_oamLookupEn = 0;
    uint32 oam_lmStatsEn0 = 0;
    uint32 oam_lmStatsEn1 = 0;
    uint32 oam_lmStatsEn2 = 0;
    uint32 oam_lmStatsIndex = 0;
    uint32 oam_lmStatsPtr0 = 0;
    uint32 oam_lmStatsPtr1 = 0;
    uint32 oam_lmStatsPtr2 = 0;
    uint32 oam_etherLmValid = 0;
    uint32 oam_mplsLmValid = 0;
    uint32 oam_oamDestChipId = 0;
    uint32 oam_mepIndex = 0;
    uint32 oam_mepEn = 0;
    uint32 oam_mipEn = 0;
    uint32 oam_tempRxOamType = 0;
    uint32 oam_valid = 0;
    DbgIpeOamInfo_m dbg_ipe_oam_info;
    uint8 key_type[3] = {lkp_ingressOamKeyType0, lkp_ingressOamKeyType1, lkp_ingressOamKeyType2};
    uint8 hash_valid[3] = {hash0_valid, hash1_valid, hash2_valid};
    uint8 confict[3] = {hash0_egressXcOamHashConflict, hash1_egressXcOamHashConflict, hash2_egressXcOamHashConflict};
    uint32 key_index[3] = {hash0_keyIndex, hash1_keyIndex, hash2_keyIndex};
    uint8 hash_resultValid[3] = {hash0_resultValid,hash1_resultValid,hash2_resultValid};

    /*DbgEgrXcOamHashEngineFromIpeOam0Info*/
    sal_memset(&dbg_egr_xc_oam_hash_engine_from_ipe_oam0_info, 0, sizeof(dbg_egr_xc_oam_hash_engine_from_ipe_oam0_info));
    cmd = DRV_IOR(DbgEgrXcOamHashEngineFromIpeOam0Info_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_egr_xc_oam_hash_engine_from_ipe_oam0_info);
    GetDbgEgrXcOamHashEngineFromIpeOam0Info(A, egrXcOamHashEngineFromIpeOam0InfoResultValid_f, &dbg_egr_xc_oam_hash_engine_from_ipe_oam0_info, &hash0_resultValid);
    GetDbgEgrXcOamHashEngineFromIpeOam0Info(A, egrXcOamHashEngineFromIpeOam0InfoHashConflict_f, &dbg_egr_xc_oam_hash_engine_from_ipe_oam0_info, &hash0_egressXcOamHashConflict);
    GetDbgEgrXcOamHashEngineFromIpeOam0Info(A, egrXcOamHashEngineFromIpeOam0InfoKeyIndex_f, &dbg_egr_xc_oam_hash_engine_from_ipe_oam0_info, &hash0_keyIndex);
    GetDbgEgrXcOamHashEngineFromIpeOam0Info(A, egrXcOamHashEngineFromIpeOam0InfoValid_f, &dbg_egr_xc_oam_hash_engine_from_ipe_oam0_info, &hash0_valid);
    /*DbgEgrXcOamHashEngineFromIpeOam1Info*/
    sal_memset(&dbg_egr_xc_oam_hash_engine_from_ipe_oam1_info, 0, sizeof(dbg_egr_xc_oam_hash_engine_from_ipe_oam1_info));
    cmd = DRV_IOR(DbgEgrXcOamHashEngineFromIpeOam1Info_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_egr_xc_oam_hash_engine_from_ipe_oam1_info);
    GetDbgEgrXcOamHashEngineFromIpeOam1Info(A, egrXcOamHashEngineFromIpeOam1InfoResultValid_f, &dbg_egr_xc_oam_hash_engine_from_ipe_oam1_info, &hash1_resultValid);
    GetDbgEgrXcOamHashEngineFromIpeOam1Info(A, egrXcOamHashEngineFromIpeOam1InfoHashConflict_f, &dbg_egr_xc_oam_hash_engine_from_ipe_oam1_info, &hash1_egressXcOamHashConflict);
    GetDbgEgrXcOamHashEngineFromIpeOam1Info(A, egrXcOamHashEngineFromIpeOam1InfoKeyIndex_f, &dbg_egr_xc_oam_hash_engine_from_ipe_oam1_info, &hash1_keyIndex);
    GetDbgEgrXcOamHashEngineFromIpeOam1Info(A, egrXcOamHashEngineFromIpeOam1InfoValid_f, &dbg_egr_xc_oam_hash_engine_from_ipe_oam1_info, &hash1_valid);
    /*DbgEgrXcOamHashEngineFromIpeOam2Info*/
    sal_memset(&dbg_egr_xc_oam_hash_engine_from_ipe_oam2_info, 0, sizeof(dbg_egr_xc_oam_hash_engine_from_ipe_oam2_info));
    cmd = DRV_IOR(DbgEgrXcOamHashEngineFromIpeOam2Info_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_egr_xc_oam_hash_engine_from_ipe_oam2_info);
    GetDbgEgrXcOamHashEngineFromIpeOam2Info(A, egrXcOamHashEngineFromIpeOam2InfoResultValid_f, &dbg_egr_xc_oam_hash_engine_from_ipe_oam2_info, &hash2_resultValid);
    GetDbgEgrXcOamHashEngineFromIpeOam2Info(A, egrXcOamHashEngineFromIpeOam2InfoHashConflict_f, &dbg_egr_xc_oam_hash_engine_from_ipe_oam2_info, &hash2_egressXcOamHashConflict);
    GetDbgEgrXcOamHashEngineFromIpeOam2Info(A, egrXcOamHashEngineFromIpeOam2InfoKeyIndex_f, &dbg_egr_xc_oam_hash_engine_from_ipe_oam2_info, &hash2_keyIndex);
    GetDbgEgrXcOamHashEngineFromIpeOam2Info(A, egrXcOamHashEngineFromIpeOam2InfoValid_f, &dbg_egr_xc_oam_hash_engine_from_ipe_oam2_info, &hash2_valid);
    /*DbgIpeLkpMgrInfo*/
    sal_memset(&dbg_ipe_lkp_mgr_info, 0, sizeof(dbg_ipe_lkp_mgr_info));
    cmd = DRV_IOR(DbgIpeLkpMgrInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_ipe_lkp_mgr_info);
    GetDbgIpeLkpMgrInfo(A, ipeLkpMgrInfoOamUseFid_f, &dbg_ipe_lkp_mgr_info, &lkp_oamUseFid);
    GetDbgIpeLkpMgrInfo(A, ipeLkpMgrInfoMplsLmValid_f, &dbg_ipe_lkp_mgr_info, &lkp_mplsLmValid);
    GetDbgIpeLkpMgrInfo(A, ipeLkpMgrInfoMplsSectionLmValid_f, &dbg_ipe_lkp_mgr_info, &lkp_mplsSectionLmValid);
    GetDbgIpeLkpMgrInfo(A, ipeLkpMgrInfoIngressOamKeyType0_f, &dbg_ipe_lkp_mgr_info, &lkp_ingressOamKeyType0);
    GetDbgIpeLkpMgrInfo(A, ipeLkpMgrInfoIngressOamKeyType1_f, &dbg_ipe_lkp_mgr_info, &lkp_ingressOamKeyType1);
    GetDbgIpeLkpMgrInfo(A, ipeLkpMgrInfoIngressOamKeyType2_f, &dbg_ipe_lkp_mgr_info, &lkp_ingressOamKeyType2);
    GetDbgIpeLkpMgrInfo(A, ipeLkpMgrInfoValid_f, &dbg_ipe_lkp_mgr_info, &lkp_valid);
    /*DbgIpeOamInfo*/
    sal_memset(&dbg_ipe_oam_info, 0, sizeof(dbg_ipe_oam_info));
    cmd = DRV_IOR(DbgIpeOamInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_ipe_oam_info);
    GetDbgIpeOamInfo(A, ipeOamInfoOamLookupEn_f, &dbg_ipe_oam_info, &oam_oamLookupEn);
    GetDbgIpeOamInfo(A, ipeOamInfoLmStatsEn0_f, &dbg_ipe_oam_info, &oam_lmStatsEn0);
    GetDbgIpeOamInfo(A, ipeOamInfoLmStatsEn1_f, &dbg_ipe_oam_info, &oam_lmStatsEn1);
    GetDbgIpeOamInfo(A, ipeOamInfoLmStatsEn2_f, &dbg_ipe_oam_info, &oam_lmStatsEn2);
    GetDbgIpeOamInfo(A, ipeOamInfoLmStatsIndex_f, &dbg_ipe_oam_info, &oam_lmStatsIndex);
    GetDbgIpeOamInfo(A, ipeOamInfoLmStatsPtr0_f, &dbg_ipe_oam_info, &oam_lmStatsPtr0);
    GetDbgIpeOamInfo(A, ipeOamInfoLmStatsPtr1_f, &dbg_ipe_oam_info, &oam_lmStatsPtr1);
    GetDbgIpeOamInfo(A, ipeOamInfoLmStatsPtr2_f, &dbg_ipe_oam_info, &oam_lmStatsPtr2);
    GetDbgIpeOamInfo(A, ipeOamInfoEtherLmValid_f, &dbg_ipe_oam_info, &oam_etherLmValid);
    GetDbgIpeOamInfo(A, ipeOamInfoMplsLmValid_f, &dbg_ipe_oam_info, &oam_mplsLmValid);
    GetDbgIpeOamInfo(A, ipeOamInfoOamDestChipId_f, &dbg_ipe_oam_info, &oam_oamDestChipId);
    GetDbgIpeOamInfo(A, ipeOamInfoMepIndex_f, &dbg_ipe_oam_info, &oam_mepIndex);
    GetDbgIpeOamInfo(A, ipeOamInfoMepEn_f, &dbg_ipe_oam_info, &oam_mepEn);
    GetDbgIpeOamInfo(A, ipeOamInfoMipEn_f, &dbg_ipe_oam_info, &oam_mipEn);
    GetDbgIpeOamInfo(A, ipeOamInfoTempRxOamType_f, &dbg_ipe_oam_info, &oam_tempRxOamType);
    GetDbgIpeOamInfo(A, ipeOamInfoValid_f, &dbg_ipe_oam_info, &oam_valid);

    if (0 == p_info->detail)
    {
        goto Discard;
    }

    if (lkp_ingressOamKeyType0 || lkp_ingressOamKeyType1 || lkp_ingressOamKeyType2)
    {

        CTC_DKIT_PRINT("OAM Process:\n");

        for (i = 0; i < 3; i++)
        {
            if (key_type[i])
            {
                CTC_DKIT_PATH_PRINT("%s%d %s\n", "hash",i,lookup_result[key_type[i] - EGRESSXCOAMHASHTYPE_ETH]);
                if (hash_valid[i])
                {
                    if (confict[i])
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_CONFLICT);
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", key_index[i]);
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", key_name[key_type[i] - EGRESSXCOAMHASHTYPE_ETH]);
                    }
                    else if (hash_resultValid[i])
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_HASH_HIT);
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", key_index[i]);
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", key_name[key_type[i] - EGRESSXCOAMHASHTYPE_ETH]);
                    }
                    else
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
                    }
                }
            }
        }
    }

    if (oam_valid)
    {
        if (hash0_resultValid || hash1_resultValid || hash2_resultValid)
        {
            if (oam_mepEn)
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "hit MEP", "YES");
                CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "mep index", oam_mepIndex);
                CTC_DKIT_PATH_PRINT("%-15s:%d\n", "Master chip id", oam_oamDestChipId);
            }
            if (oam_mipEn)
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "hit MIP", "YES");
                CTC_DKIT_PATH_PRINT("%-15s:%d\n", "Master chip id", oam_oamDestChipId);
            }
            if (oam_tempRxOamType)
            {
                char* oam_type[RXOAMTYPE_TRILLBFD] =
                {
                    "ETHER OAM", "IP BFD", "PBT OAM", "PBBBSI", "PBBBV",
                                                                                        "MPLS OAM", "MPLS BFD", "ACH OAM", "RSV", "TRILL BFD"};
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "OAM type", oam_type[oam_tempRxOamType - 1]);
                }
                if (oam_mplsLmValid || oam_etherLmValid)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s 0x%x\n", "read LM from", "DsOamLmStats", oam_lmStatsIndex);
                }
                if (oam_lmStatsEn0)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s 0x%x\n", "write LM to", "DsOamLmStats", oam_lmStatsPtr0);
                }
                if (oam_lmStatsEn1)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s 0x%x\n", "write LM to", "DsOamLmStats", oam_lmStatsPtr1);
                }
                if (oam_lmStatsEn2)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s 0x%x\n", "write LM to", "DsOamLmStats", oam_lmStatsPtr2);
                }
            }
        }

Discard:

    return CLI_SUCCESS;
}

static int32
 _ctc_goldengate_dkit_captured_path_ipe_destination(ctc_dkit_captured_path_info_t* p_info)
 {
    uint8 slice = p_info->slice_ipe;
    uint8 lchip = p_info->lchip;
    uint32 cmd = 0;
    uint8 is_mcast = 0;
    uint8 is_link_agg = 0;
    uint16 dest_port = 0;
    uint32 rx_oam_type = 0;
    uint8 dest_chip = 0;
    uint16 gport = 0;
    uint32 dsNextHopInternalBase = 0;
    uint8 fwd_to_cpu = 0;
    /*DbgIpeEcmpProcInfo*/
    uint32 ecmp_ecmpGroupId = 0;
    uint32 ecmp_ecmpEn = 0;
    uint32 ecmp_valid = 0;
    DbgIpeEcmpProcInfo_m dbg_ipe_ecmp_proc_info;
    /*DbgIpeForwardingInfo*/

    uint32 fwd_ingressHeaderValid = 0;
    uint32 fwd_timestampValid = 0;
    uint32 fwd_muxDestinationValid = 0;
    uint32 fwd_srcPortStatsEn = 0;
    uint32 fwd_acl0StatsValid = 0;
    uint32 fwd_acl1StatsValid = 0;
    uint32 fwd_acl2StatsValid = 0;
    uint32 fwd_acl3StatsValid = 0;
    uint32 fwd_ifStatsValid = 0;
    uint32 fwd_ipfixFlowLookupEn = 0;
    uint32 fwd_shareType = 0;
    uint32 fwd_discardType = 0;
    uint32 fwd_exceptionEn = 0;
    uint32 fwd_exceptionIndex = 0;
    uint32 fwd_exceptionSubIndex = 0;
    uint32 fwd_fatalExceptionValid = 0;
    uint32 fwd_fatalException = 0;
    uint32 fwd_apsSelectValid0 = 0;
    uint32 fwd_apsSelectGroupId0 = 0;
    uint32 fwd_apsSelectValid1 = 0;
    uint32 fwd_apsSelectGroupId1 = 0;
    uint32 fwd_discard = 0;
    uint32 fwd_destMap = 0;
    uint32 fwd_apsBridgeEn0 = 0;
    uint32 fwd_apsBridgeEn1 = 0;
    uint32 fwd_apsGroup0 = 0;
    uint32 fwd_apsGroup1 = 0;
    uint32 fwd_nextHopExt = 0;
    uint32 fwd_nextHopIndex = 0;
    uint32 fwd_headerHash = 0;
    uint32 fwd_valid = 0;
    uint32 fwd_acl_en = 0;
    uint32 fwd_acl_fwd_valid = 0;
    uint32 fwd_bypass_lag = 0;
    uint32 fwd_bypass_policer = 0;
    uint32 fwd_bypass_stormctl = 0;
    uint32 fwd_learn = 0;
    uint32 fwd_ptr_valid1 = 0;
    uint32 fwd_ptr1 = 0;
    uint32 fwd_ptr_valid0 = 0;
    uint32 fwd_ptr0 = 0;
    uint32 fwd_nexthop_valid0 = 0;
    uint32 fwd_nexthop_valid1 = 0;
    uint32 fwd_ipfix_en = 0;
    uint32 fwd_share_type = 0;

    DbgIpeFwdProcessInfo_m dbg_ipe_forwarding_info;

    /*DbgIpeEcmpProcInfo*/
    sal_memset(&dbg_ipe_ecmp_proc_info, 0, sizeof(dbg_ipe_ecmp_proc_info));
    cmd = DRV_IOR(DbgIpeEcmpProcInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_ipe_ecmp_proc_info);
    GetDbgIpeEcmpProcInfo(A, ipeEcmpProcInfoEcmpGroupId_f, &dbg_ipe_ecmp_proc_info, &ecmp_ecmpGroupId);
    GetDbgIpeEcmpProcInfo(A, ipeEcmpProcInfoEcmpEn_f, &dbg_ipe_ecmp_proc_info, &ecmp_ecmpEn);
    GetDbgIpeEcmpProcInfo(A, ipeEcmpProcInfoValid_f, &dbg_ipe_ecmp_proc_info, &ecmp_valid);
    /*DbgIpeForwardingInfo*/
    sal_memset(&dbg_ipe_forwarding_info, 0, sizeof(dbg_ipe_forwarding_info));
    cmd = DRV_IOR(DbgIpeFwdProcessInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_ipe_forwarding_info);

    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoAclDsFwdPtrValid_f, &dbg_ipe_forwarding_info, &fwd_acl_fwd_valid);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoAclEnBitMap_f, &dbg_ipe_forwarding_info, &fwd_acl_en);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoApsBridgeIndex0_f, &dbg_ipe_forwarding_info, &fwd_apsGroup0);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoApsBridgeIndex1_f, &dbg_ipe_forwarding_info, &fwd_apsGroup1);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoApsBridgeValid0_f, &dbg_ipe_forwarding_info, &fwd_apsBridgeEn0);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoApsBridgeValid1_f,  &dbg_ipe_forwarding_info, &fwd_apsBridgeEn1);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoApsSelectGroupId0_f, &dbg_ipe_forwarding_info, &fwd_apsSelectGroupId0);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoApsSelectGroupId1_f,  &dbg_ipe_forwarding_info, &fwd_apsSelectGroupId1);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoApsSelectValid0_f,  &dbg_ipe_forwarding_info, &fwd_apsSelectValid0);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoApsSelectValid1_f,  &dbg_ipe_forwarding_info, &fwd_apsSelectValid1);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoBypassAccessLagEngine_f,  &dbg_ipe_forwarding_info, &fwd_bypass_lag);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoBypassPolicingOp_f,  &dbg_ipe_forwarding_info, &fwd_bypass_policer);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoBypassStormCtlOp_f,  &dbg_ipe_forwarding_info, &fwd_bypass_stormctl);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoDestMap_f,  &dbg_ipe_forwarding_info, &fwd_destMap);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoDiscardType_f,  &dbg_ipe_forwarding_info, &fwd_discardType);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoDiscard_f,  &dbg_ipe_forwarding_info, &fwd_discard);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoDoLearningOperation_f,  &dbg_ipe_forwarding_info, &fwd_learn);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoFirstDsFwdPtrValid_f,  &dbg_ipe_forwarding_info, &fwd_ptr_valid0);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoFirstDsFwdPtr_f,  &dbg_ipe_forwarding_info, &fwd_ptr0);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoFirstNextHopPtrValid_f,  &dbg_ipe_forwarding_info, &fwd_nexthop_valid0);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoSecondDsFwdPtrValid_f,  &dbg_ipe_forwarding_info, &fwd_ptr_valid1);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoSecondDsFwdPtr_f,  &dbg_ipe_forwarding_info, &fwd_ptr1);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoSecondNextHopPtrValid_f,  &dbg_ipe_forwarding_info, &fwd_nexthop_valid1);

#if 0
/*temply not support cid*/
    GetDbgIpeFwdProcessInfo(A, gCidLkp_cidPairHashAdIndex_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    GetDbgIpeFwdProcessInfo(A, gCidLkp_cidPairHashEntryOffset_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    GetDbgIpeFwdProcessInfo(A, gCidLkp_cidPairHashHit_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    GetDbgIpeFwdProcessInfo(A, gCidLkp_cidPairHashIsLeft_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    GetDbgIpeFwdProcessInfo(A, gCidLkp_cidPairHashKeyIndex_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    GetDbgIpeFwdProcessInfo(A, gCidLkp_cidPairTcamHitIndex_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    GetDbgIpeFwdProcessInfo(A, gCidLkp_cidPairTcamResultValid_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    GetDbgIpeFwdProcessInfo(A, gCidLkp_destCategoryIdClassfied_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    GetDbgIpeFwdProcessInfo(A, gCidLkp_destCategoryId_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    GetDbgIpeFwdProcessInfo(A, gCidLkp_srcCategoryIdClassfied_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    GetDbgIpeFwdProcessInfo(A, gCidLkp_srcCategoryId_f,  &dbg_ipe_forwarding_info, &fwd_valid);
#endif

    //-GetDbgIpeFwdProcessInfo(A, ingfwdType_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    //-GetDbgIpeFwdProcessInfo(A, ingressHeaderValid_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoIpfixFlowLookupEn_f,  &dbg_ipe_forwarding_info, &fwd_ipfix_en);
    //-GetDbgIpeFwdProcessInfo(A, macKnown_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    //-GetDbgIpeFwdProcessInfo(A, mcastMac_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    //-GetDbgIpeFwdProcessInfo(A, microFlowLookupEn_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    //-GetDbgIpeFwdProcessInfo(A, mutationTableId_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    //-GetDbgIpeFwdProcessInfo(A, muxDestinationValid_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoNextHopExt_f,  &dbg_ipe_forwarding_info, &fwd_nextHopExt);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoNextHopPtr_f,  &dbg_ipe_forwarding_info, &fwd_nextHopIndex);
    //-GetDbgIpeFwdProcessInfo(A, policyProfId_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoShareType_f,  &dbg_ipe_forwarding_info, &fwd_share_type);
   //- GetDbgIpeFwdProcessInfo(A, skipTimestampOperation_f,  &dbg_ipe_forwarding_info, &fwd_valid);
   //-  GetDbgIpeFwdProcessInfo(A, srcDscp_f,  &dbg_ipe_forwarding_info, &fwd_valid);
   //-  GetDbgIpeFwdProcessInfo(A, stagCos_f,  &dbg_ipe_forwarding_info, &fwd_valid);
    GetDbgIpeFwdProcessInfo(A, ipeFwdProcessInfoValid_f,  &dbg_ipe_forwarding_info, &fwd_valid);

    cmd = DRV_IOR(DbgIpeOamInfo_t, DbgIpeOamInfo_ipeOamInfoTempRxOamType_f);
    DRV_IOCTL(lchip, slice, cmd, &rx_oam_type);

     if (fwd_valid)
     {
         CTC_DKIT_PRINT("Destination Process:\n");
         if (ecmp_valid && ecmp_ecmpEn && ecmp_ecmpGroupId)
         {
             CTC_DKIT_PATH_PRINT("%-15s:%d\n", "do ecmp, group", ecmp_ecmpGroupId);
         }
         if (fwd_apsBridgeEn0)
         {
             CTC_DKIT_PATH_PRINT("%-15s:%s\n", "do APS, group", fwd_apsGroup0);
             if (fwd_apsBridgeEn1)
             {
                 CTC_DKIT_PRINT("2nd level APS Process:\n");
                 CTC_DKIT_PATH_PRINT("%-15s:%s\n", "do APS, group", fwd_apsGroup1);
             }
         }
         else
         {
             if (fwd_apsSelectValid0)
             {
                 CTC_DKIT_PATH_PRINT("%-15s:%s\n", "APS selector0", "YES");
                 CTC_DKIT_PATH_PRINT("%-15s:%d\n", "APS group", fwd_apsSelectGroupId0);
             }
             if (fwd_apsSelectValid1)
             {
                 CTC_DKIT_PATH_PRINT("%-15s:%s\n", "APS selector2", "YES");
                 CTC_DKIT_PATH_PRINT("%-15s:%d\n", "APS group", fwd_apsSelectGroupId1);
             }
         }
         if (!fwd_discard)
         {
             if (rx_oam_type)
             {
                 CTC_DKIT_PATH_PRINT("%-15s:%s\n", "destination", "OAM engine");
             }
             else
             {
                 is_mcast = IS_BIT_SET(fwd_destMap, 18);
                 fwd_to_cpu = IS_BIT_SET(fwd_destMap, 16);
                 dest_port = fwd_destMap&0x1FF;
                 if (0x3FFFF == fwd_nextHopIndex)
                 {
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Drop!!!", "next hop is invalid, nextHopPtr=0x3FFFF");
                 }
                 else if (is_mcast)
                 {
                     CTC_DKIT_PATH_PRINT("%-15s:%d\n", "do mcast, group", fwd_destMap&0xFFFF);
                 }
                 else
                 {
                     dest_chip = (fwd_destMap >> 9)&0x7F;
                     is_link_agg = (dest_chip == 0x1F);
                     if (fwd_to_cpu)
                     {
                         CTC_DKIT_PATH_PRINT("%-15s:%s\n", "destination", "CPU");
                     }
                     else
                     {
                         if (is_link_agg)
                         {
                             CTC_DKIT_PATH_PRINT("%-15s:%d\n", "do linkagg, group", fwd_destMap&CTC_DKIT_DRV_LINKAGGID_MASK);
                         }
                         else
                         {
                             gport = CTC_DKIT_DRV_LPORT_TO_CTC_GPORT(dest_chip, dest_port&0x1FF);
                             CTC_DKIT_PATH_PRINT("%-15s:0x%04x\n", "dest gport", gport);
                         }

                         cmd = DRV_IOR(EpeHdrAdjustCtl_t, EpeHdrAdjustCtl_dsNextHopInternalBase_f);
                         DRV_IOCTL(lchip, 0, cmd, &dsNextHopInternalBase);
                         CTC_DKIT_PATH_PRINT("%-15s\n", "nexthop info--->");
                         CTC_DKIT_PATH_PRINT("%-15s:%s\n", "is 8Wnhp", fwd_nextHopExt? "YES" : "NO");
                         if (((fwd_nextHopIndex >> 4)&0x3FFF) != dsNextHopInternalBase)
                         {
                             CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "nexthop index", fwd_nextHopIndex);
                             CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", fwd_nextHopExt? "DsNextHop8W" : "DsNextHop4W");
                         }
                         else
                         {
                             CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "nexthop index", (fwd_nextHopIndex&0xF));
                             CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", "EpeNextHopInternal");
                         }
                     }
                 }
             }
         }
         else
         {
             _ctc_goldengate_dkit_captured_path_discard_process(p_info, fwd_discard, fwd_discardType, CTC_DKIT_IPE);
             if ((fwd_discard) && (CTC_DKIT_DISCARD_IPE_FATAL_EXCEP_DIS == (fwd_discardType+CTC_DKIT_DISCARD_IPE_FEATURE_START)))
             {
                 if (fwd_fatalExceptionValid)
                 {
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Fatal exception",
                                         ctc_goldengate_dkit_get_sub_reason_desc(fwd_fatalException + CTC_DKIT_SUB_IPE_FATAL_UC_IP_HDR_ERROR_OR_MARTION_ADDR));
                 }
             }
         }
         _ctc_goldengate_dkit_captured_path_exception_process(p_info, fwd_exceptionEn, fwd_exceptionIndex, fwd_exceptionSubIndex);
     }

     return CLI_SUCCESS;
 }
static int32
_ctc_goldengate_dkit_captured_path_ipfix(ctc_dkit_captured_path_info_t* p_info, uint8 dir)
{
    uint32 cmd = 0;
    DbgIpfixAccIngInfo_m ipfix_info;
    uint8 lchip = p_info->lchip;
    /*DbgIpfixAccIngInfo*/
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_byPassIpfixProcess = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_denyIpfixInsertOperation = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_destinationInfo = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_destinationType = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_disableIpfixAndMfp = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_flowFieldSel = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_hashConflict = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_hashKeyType = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_ipfixCfgProfileId = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_ipfixEn = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_isAddOperation = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_isSamplingPkt = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_isUpdateOperation = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_keyIndex = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_mfpEn = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_microflowPolicingProfId = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_resultValid = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_samplingEn = 0;
    uint32 DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_valid = 0;

    if(dir == 0)
    {
        cmd = DRV_IOR(DbgIpfixAccIngInfo_t, DRV_ENTRY_FLAG);
    }
    else
    {
        cmd = DRV_IOR(DbgIpfixAccEgrInfo_t, DRV_ENTRY_FLAG);
    }

    DRV_IOCTL(lchip, 0, cmd, &ipfix_info);

    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_byPassIpfixProcess_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_byPassIpfixProcess);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_denyIpfixInsertOperation_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_denyIpfixInsertOperation);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_destinationInfo_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_destinationInfo);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_destinationType_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_destinationType);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_disableIpfixAndMfp_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_disableIpfixAndMfp);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_flowFieldSel_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_flowFieldSel);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_hashConflict_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_hashConflict);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_hashKeyType_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_hashKeyType);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_ipfixCfgProfileId_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_ipfixCfgProfileId);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_ipfixEn_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_ipfixEn);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_isAddOperation_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_isAddOperation);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_isSamplingPkt_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_isSamplingPkt);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_isUpdateOperation_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_isUpdateOperation);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_keyIndex_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_keyIndex);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_mfpEn_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_mfpEn);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_microflowPolicingProfId_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_microflowPolicingProfId);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_resultValid_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_resultValid);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_samplingEn_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_samplingEn);
    GetDbgIpfixAccIngInfo(A, ipfixAccIngInfoGIngr_valid_f, &ipfix_info, &DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_valid);

    if(DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_valid)
    {
        if(dir == 0)
        {
            CTC_DKIT_PRINT("Ipe ipfix process:\n");
        }
        else
        {
            CTC_DKIT_PRINT("Epe ipfix process:\n");
        }
        CTC_DKIT_PATH_PRINT("ipfix enable:    %s\n", DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_ipfixEn?"enable":"disable");
        CTC_DKIT_PATH_PRINT("ipfix configure profile Id:    %d\n", DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_flowFieldSel);
        CTC_DKIT_PATH_PRINT("hash key type:    %d\n", DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_hashKeyType);
        CTC_DKIT_PATH_PRINT("Hash field select Id:    %d\n", DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_hashKeyType);

        if(DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_resultValid)
        {
            CTC_DKIT_PATH_PRINT("Hash lookup result:\n");
            CTC_DKIT_PATH_PRINT("    Key index:    %d\n",DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_keyIndex);
            CTC_DKIT_PATH_PRINT("    Is conflict packet: %s\n",DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_hashConflict?"yes":"no");
        }

        if(DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_samplingEn)
        {
            CTC_DKIT_PATH_PRINT("Enable sample and %s", DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_isSamplingPkt?"is sample packet":"is not sample packet");
        }

        CTC_DKIT_PATH_PRINT("Is add operation:    %s\n", DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_isAddOperation ? "yes" :"no");
        CTC_DKIT_PATH_PRINT("Is update operation:    %s\n", DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_isUpdateOperation ? "yes":"no");
        CTC_DKIT_PATH_PRINT("Bypass ipfix process:    %s\n", DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_byPassIpfixProcess ? "yes":"no");
        CTC_DKIT_PATH_PRINT("deny ipfix learning:    %s\n", DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_denyIpfixInsertOperation ? "yes":"no");
        CTC_DKIT_PATH_PRINT("disable ipfix:    %s\n", DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_disableIpfixAndMfp ? "yes":"no");

        if(DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_mfpEn)
        {
            CTC_DKIT_PATH_PRINT("Enable ipfix with rate!!!\n");
            CTC_DKIT_PATH_PRINT("Mfp policing profile Id:    %d\n", DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_microflowPolicingProfId);
        }

        CTC_DKIT_PATH_PRINT("Destinatio Info:    %d\n", DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_destinationInfo);
        CTC_DKIT_PATH_PRINT("Destinatio Type:    %d\n", DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_destinationType);
    }

    return CLI_SUCCESS;
}
static int32
_ctc_goldengate_dkit_captured_path_ipe_ipfix(ctc_dkit_captured_path_info_t* p_info)
{
    _ctc_goldengate_dkit_captured_path_ipfix(p_info, 0);

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_ipe_misc(ctc_dkit_captured_path_info_t* p_info)
{
    uint8  slice = p_info->slice_ipe;
    uint8  lchip = p_info->lchip;
    uint32 cmd = 0;

    char*  str_color[] = {"None", "Red", "Yellow", "Green"};
    char*  str_stmctl_type[] = {"Unknow-Ucast", "Broadcast", "Unknow-Mcast", " ",   \
                                    "Know-Ucast", "Broadcast", "Know-Mcast", " "};

    uint32 policerColor              = 0;
    uint32 policerMuxLenType         = 0;
    uint32 policer0SplitModeValid    = 0;
    uint32 policer1SplitModeValid    = 0;
    uint32 policerLayer3Offset       = 0;
    uint32 policerLength             = 0;
    uint32 policerPhbEn0             = 0;
    uint32 policerPhbEn1             = 0;
    uint32 policerPtr0               = 0;
    uint32 policerPtr1               = 0;
    uint32 policerStatsPtr0          = 0;
    uint32 policerStatsPtr1          = 0;
    uint32 policerValid0             = 0;
    uint32 policerValid1             = 0;
    uint32 policyProfId              = 0;
    uint32 portPolicer0En            = 0;
    uint32 portPolicer1En            = 0;
    uint32 vlanPolicer0En            = 0;
    uint32 vlanPolicer1En            = 0;
    uint32 policerInfoValid          = 0;
    DbgIpeFwdPolicingInfo_m dbg_policer_info;
    uint32 stormCtlColor       = 0;
    uint32 stormCtlOffsetSel   = 0;
    uint32 stormCtlDrop        = 0;
    uint32 stormCtlEn          = 0;
    uint32 stormCtlExceptionEn = 0;
    uint32 stormCtlLen         = 0;
    uint32 stormCtlPtr0        = 0;
    uint32 stormCtlPtr1        = 0;
    uint32 stormCtlPtrValid0   = 0;
    uint32 stormCtlPtrValid1   = 0;
    uint32 stormCtlInfoValid   = 0;
    DbgIpeFwdStormCtlInfo_m dbg_storm_ctl_info;
    uint32 coppInfoColor     = 0;
    uint32 coppInfoCoppDrop  = 0;
    uint32 coppInfoCoppLen   = 0;
    uint32 coppInfoCoppPtr   = 0;
    uint32 coppInfoCoppValid = 0;
    uint32 coppInfoValid     = 0;
    DbgIpeFwdCoppInfo_m dbg_copp_info;

    if (0 == p_info->detail)
    {
        goto Discard;
    }

    sal_memset(&dbg_policer_info, 0, sizeof(DbgIpeFwdPolicingInfo_m));
    cmd = DRV_IOR(DbgIpeFwdPolicingInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_storm_ctl_info);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoColor_f                     , &dbg_policer_info, &policerColor);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoMuxLengthType_f             , &dbg_policer_info, &policerMuxLenType);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoPolicer0SplitModeValid_f    , &dbg_policer_info, &policer0SplitModeValid);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoPolicer1SplitModeValid_f    , &dbg_policer_info, &policer1SplitModeValid);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoPolicerLayer3Offset_f       , &dbg_policer_info, &policerLayer3Offset);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoPolicerLength_f             , &dbg_policer_info, &policerLength);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoPolicerPhbEn0_f             , &dbg_policer_info, &policerPhbEn0);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoPolicerPhbEn1_f             , &dbg_policer_info, &policerPhbEn1);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoPolicerPtr0_f               , &dbg_policer_info, &policerPtr0);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoPolicerPtr1_f               , &dbg_policer_info, &policerPtr1);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoPolicerStatsPtr0_f          , &dbg_policer_info, &policerStatsPtr0);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoPolicerStatsPtr1_f          , &dbg_policer_info, &policerStatsPtr1);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoPolicerValid0_f             , &dbg_policer_info, &policerValid0);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoPolicerValid1_f             , &dbg_policer_info, &policerValid1);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoPolicyProfId_f              , &dbg_policer_info, &policyProfId);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoPortPolicer0En_f            , &dbg_policer_info, &portPolicer0En);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoPortPolicer1En_f            , &dbg_policer_info, &portPolicer1En);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoValid_f                     , &dbg_policer_info, &policerInfoValid);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoVlanPolicer0En_f            , &dbg_policer_info, &vlanPolicer0En);
    GetDbgIpeFwdPolicingInfo(A, ipeFwdPolicingInfoVlanPolicer1En_f            , &dbg_policer_info, &vlanPolicer1En);

    /*policer*/
    if(policerInfoValid)
    {
        CTC_DKIT_PRINT("Policer Process:\n");
        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Policer Color", str_color[policerColor]);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Policer0 SplitEn", policer0SplitModeValid);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Policer1 SplitEn", policer1SplitModeValid);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Policer Length", policerLength);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Policer0 PhbEn", policerPhbEn0);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Policer1 PhbEn", policerPhbEn1);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Policer0 Ptr", policerPtr0);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Policer1 Ptr", policerPtr1);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Policer0 StatsPtr", policerStatsPtr0);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Policer1 StatsPtr", policerStatsPtr1);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Policer0 Valid", policerValid0);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Policer1 Valid", policerValid1);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "PolicyProfId", policyProfId);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Port Policer0En", portPolicer0En);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Port Policer1En", portPolicer1En);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Vlan Policer0En", vlanPolicer0En);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Vlan Policer1En", vlanPolicer1En);

    }

    sal_memset(&dbg_storm_ctl_info, 0, sizeof(DbgIpeFwdStormCtlInfo_m));
    cmd = DRV_IOR(DbgIpeFwdStormCtlInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_storm_ctl_info);
    GetDbgIpeFwdStormCtlInfo(A, ipeFwdStormCtlInfoColor_f               , &dbg_storm_ctl_info, &stormCtlColor);
    GetDbgIpeFwdStormCtlInfo(A, ipeFwdStormCtlInfoOffsetSel_f           , &dbg_storm_ctl_info, &stormCtlOffsetSel);
    GetDbgIpeFwdStormCtlInfo(A, ipeFwdStormCtlInfoStormCtlDrop_f        , &dbg_storm_ctl_info, &stormCtlDrop);
    GetDbgIpeFwdStormCtlInfo(A, ipeFwdStormCtlInfoStormCtlEn_f          , &dbg_storm_ctl_info, &stormCtlEn);
    GetDbgIpeFwdStormCtlInfo(A, ipeFwdStormCtlInfoStormCtlExceptionEn_f , &dbg_storm_ctl_info, &stormCtlExceptionEn);
    GetDbgIpeFwdStormCtlInfo(A, ipeFwdStormCtlInfoStormCtlLen_f         , &dbg_storm_ctl_info, &stormCtlLen);
    GetDbgIpeFwdStormCtlInfo(A, ipeFwdStormCtlInfoStormCtlPtr0_f        , &dbg_storm_ctl_info, &stormCtlPtr0);
    GetDbgIpeFwdStormCtlInfo(A, ipeFwdStormCtlInfoStormCtlPtr1_f        , &dbg_storm_ctl_info, &stormCtlPtr1);
    GetDbgIpeFwdStormCtlInfo(A, ipeFwdStormCtlInfoStormCtlPtrValid0_f   , &dbg_storm_ctl_info, &stormCtlPtrValid0);
    GetDbgIpeFwdStormCtlInfo(A, ipeFwdStormCtlInfoStormCtlPtrValid1_f   , &dbg_storm_ctl_info, &stormCtlPtrValid1);
    GetDbgIpeFwdStormCtlInfo(A, ipeFwdStormCtlInfoValid_f               , &dbg_storm_ctl_info, &stormCtlInfoValid);
    /*stormctl*/
    if(stormCtlEn && stormCtlInfoValid)
    {
        CTC_DKIT_PRINT("StormCtl Process:\n");
        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "StormCtl Type", str_stmctl_type[stormCtlOffsetSel]);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "StormCtl Ptr0", stormCtlPtr0);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Ptr0 valid", stormCtlPtrValid0);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "StormCtl Ptr1", stormCtlPtr1);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Ptr1 valid", stormCtlPtrValid1);
        if(stormCtlDrop)
        {
            CTC_DKIT_PATH_PRINT("StormCtl Drop!\n");
        }
        if(stormCtlExceptionEn)
        {
            CTC_DKIT_PATH_PRINT("StormCtl Exception!\n");
        }
    }

    sal_memset(&dbg_copp_info, 0, sizeof(DbgIpeFwdCoppInfo_m));
    cmd = DRV_IOR(DbgIpeFwdCoppInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_copp_info);
    GetDbgIpeFwdCoppInfo(A, ipeFwdCoppInfoColor_f,     &dbg_copp_info, &coppInfoColor);
    GetDbgIpeFwdCoppInfo(A, ipeFwdCoppInfoCoppDrop_f,  &dbg_copp_info, &coppInfoCoppDrop);
    GetDbgIpeFwdCoppInfo(A, ipeFwdCoppInfoCoppLen_f,   &dbg_copp_info, &coppInfoCoppLen);
    GetDbgIpeFwdCoppInfo(A, ipeFwdCoppInfoCoppPtr_f,   &dbg_copp_info, &coppInfoCoppPtr);
    GetDbgIpeFwdCoppInfo(A, ipeFwdCoppInfoCoppValid_f, &dbg_copp_info, &coppInfoCoppValid);
    GetDbgIpeFwdCoppInfo(A, ipeFwdCoppInfoValid_f,     &dbg_copp_info, &coppInfoValid);
    /*copp*/
    if(coppInfoValid && coppInfoCoppValid)
    {
        CTC_DKIT_PRINT("Copp Process:\n");
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Copp Ptr", coppInfoCoppPtr);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Copp Length", coppInfoCoppLen);
        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Copp Color", str_color[coppInfoColor]);
        if(coppInfoCoppDrop)
        {
            CTC_DKIT_PATH_PRINT("Copp Drop!\n");
        }
    }

Discard:
    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_ipe(ctc_dkit_captured_path_info_t* p_info)
{

    CTC_DKIT_PRINT("\nINGRESS PROCESS  \n-----------------------------------\n");

    /*1. Parser*/
    if (!p_info->discard)
    {
        _ctc_goldengate_dkit_captured_path_ipe_parser(p_info);
    }
    /*2. SCL*/
    if ((!p_info->discard)||(p_info->rx_oam))
    {
        _ctc_goldengate_dkit_captured_path_ipe_scl(p_info);
    }
    /*3. Interface*/
    if ((!p_info->discard)||(p_info->rx_oam))
    {
        _ctc_goldengate_dkit_captured_path_ipe_interface(p_info);
    }
    /*4. Tunnel*/
    if ((!p_info->discard)||(p_info->rx_oam))
    {
        _ctc_goldengate_dkit_captured_path_ipe_tunnel(p_info);
    }
    /*5. Flow Hash*/
    if ((!p_info->discard)||(p_info->rx_oam))
    {
        _ctc_goldengate_dkit_captured_path_ipe_flow_hash(p_info);
    }
    /*6. Forward*/
    if ((!p_info->discard)||(p_info->rx_oam))
    {
        _ctc_goldengate_dkit_captured_path_ipe_forward(p_info);
    }
    /*7. OAM*/
    if ((!p_info->discard)||(p_info->rx_oam))
    {
        _ctc_goldengate_dkit_captured_path_ipe_oam(p_info);
    }
    /*8. Destination*/
    if ((!p_info->discard)||(p_info->rx_oam))
    {
        _ctc_goldengate_dkit_captured_path_ipe_destination(p_info);
    }
    /*9. Cid Pair*/
    if ((!p_info->discard)||(p_info->rx_oam))
    {
        _ctc_goldengate_dkit_capture_path_ipe_cid_pair(p_info);
    }
    /*10. ACL*/
    _ctc_goldengate_dkit_captured_path_ipe_acl(p_info);
    /*11. Ipfix*/
    _ctc_goldengate_dkit_captured_path_ipe_ipfix(p_info);
    /*12. policer/stormctl/copp...*/
    if ((!p_info->discard)||(p_info->rx_oam))
    {
        _ctc_goldengate_dkit_captured_path_ipe_misc(p_info);
    }

    if ((p_info->discard) && (!p_info->exception)&&(!p_info->rx_oam))/*check exception when discard but no exception*/
    {
        _ctc_goldengate_dkit_captured_path_ipe_exception_check(p_info);
    }

    if (p_info->discard && (0 == p_info->detail))
    {
        CTC_DKIT_PRINT("Packet Drop at IPE:\n");
        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "reason", ctc_goldengate_dkit_get_reason_desc(p_info->discard_type + CTC_DKIT_DISCARD_IPE_FEATURE_START));
    }

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_bsr_mcast(ctc_dkit_captured_path_info_t* p_info)
{
    uint32 cmd = 0;
    uint32 ret = CLI_SUCCESS;
    uint32 local_chip = 0;
    uint32 dest_map = 0;
    uint32 groupIdShiftBit = 0;
    uint32 remaining_rcd = 0xFFF;
    uint32 end_replication = 0;
    uint32 dsMetEntryBase = 0;
    uint32 metEntryPtr =0;
    uint32 dsNextHopInternalBase = 0;
    uint8 lchip = p_info->lchip;
    /*DbgFwdMetFifoInfo*/
    uint32 met_doMet = 0;
    uint32 met_valid = 0;
    uint32 met_enqueueDiscard = 0;
    uint32 exce_vec = 0;
    /*DsMetEntry*/
    uint32 currentMetEntryType = 0;
    uint32 isMet = 0;
    uint32 nextMetEntryPtr = 0;
    uint32 endLocalRep = 0;
    uint32  isLinkAggregation = 0;
    uint32  remoteChip = 0;
    uint32  replicationCtl = 0;
    uint32  ucastId = 0;
    uint32   nexthopExt = 0;
    uint32  nexthopPtr = 0;
    uint32 mcastMode = 0;
    uint32 apsBridgeEn = 0;
    uint8 port_bitmap[8] = {0};
    uint8 port_bitmap_high[9] = {0};
    uint8 port_bitmap_low[8] = {0};

    DsMetEntry6W_m ds_met_entry6_w;
    DsMetEntry_m ds_met_entry;
    DbgFwdMetFifoInfo1_m dbg_fwd_met_fifo_info1;
    DbgFwdMetFifoInfo2_m dbg_fwd_met_fifo_info2;
    DbgFwdBufStoreInfo_m dbg_fwd_buf_store_info;

    sal_memset(&ds_met_entry6_w, 0, sizeof(ds_met_entry6_w));
    sal_memset(&ds_met_entry, 0, sizeof(ds_met_entry));

    /*DbgFwdMetFifoInfo1*/
    sal_memset(&dbg_fwd_met_fifo_info1, 0, sizeof(dbg_fwd_met_fifo_info1));
    cmd = DRV_IOR(DbgFwdMetFifoInfo1_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_fwd_met_fifo_info1);
    GetDbgFwdMetFifoInfo1(A, fwdMetFifoInfo1ExceptionVector_f, &dbg_fwd_met_fifo_info1, &exce_vec);
    /*DbgFwdMetFifoInfo2*/
    sal_memset(&dbg_fwd_met_fifo_info2, 0, sizeof(dbg_fwd_met_fifo_info2));
    cmd = DRV_IOR(DbgFwdMetFifoInfo2_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_fwd_met_fifo_info2);
    GetDbgFwdMetFifoInfo2(A, fwdMetFifoInfo2Valid_f, &dbg_fwd_met_fifo_info2, &met_valid);
    //GetDbgFwdMetFifoInfo2(A, doMet_f, &dbg_fwd_met_fifo_info2, &met_doMet);
    GetDbgFwdMetFifoInfo2(A, fwdMetFifoInfo2EnqueueDiscard_f, &dbg_fwd_met_fifo_info2, &met_enqueueDiscard);
    /*DbgFwdBufStoreInfo*/
    sal_memset(&dbg_fwd_buf_store_info, 0, sizeof(dbg_fwd_buf_store_info));
    cmd = DRV_IOR(DbgFwdBufStoreInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_fwd_buf_store_info);

    cmd = DRV_IOR(EpeHdrAdjustCtl_t, EpeHdrAdjustCtl_dsNextHopInternalBase_f);
    DRV_IOCTL(lchip, 0, cmd, &dsNextHopInternalBase);

    if (met_valid )
    {
        if(p_info->path_sel == 1)
        {
            CTC_DKIT_PRINT("Multicast Process:\n");
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "mcast group", dest_map&0xFFFF);

            cmd = DRV_IOR(MetFifoCtl_t, MetFifoCtl_chipId_f);
            DRV_IOCTL(lchip, 0, cmd, &local_chip);
            cmd = DRV_IOR(MetFifoCtl_t, MetFifoCtl_dsMetEntryBase_f);
            DRV_IOCTL(lchip, 0, cmd, &dsMetEntryBase);
            cmd = DRV_IOR(MetFifoCtl_t, MetFifoCtl_groupIdShiftBit_f);
            DRV_IOCTL(lchip, 0, cmd, &groupIdShiftBit);
            nextMetEntryPtr = (dest_map&0xFFFF) << groupIdShiftBit;
            for (;;)
            {
                metEntryPtr =  nextMetEntryPtr + dsMetEntryBase;
                CTC_DKIT_PATH_PRINT("%-15s\n", "DsMetEntry--->");
                CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "index", metEntryPtr);
                cmd = DRV_IOR(DsMetEntry6W_t, DRV_ENTRY_FLAG);
                ret = DRV_IOCTL(lchip, (metEntryPtr&0x1FFFE), cmd, &ds_met_entry6_w);
                if (ret != DRV_E_NONE)
                {
                    return CLI_ERROR;
                }
                GetDsMetEntry6W(A, currentMetEntryType_f, &ds_met_entry6_w, &currentMetEntryType);
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", currentMetEntryType? "DsMetEntry6W" : "DsMetEntry3W");
                if (currentMetEntryType)
                {
                    sal_memcpy((uint8*)&ds_met_entry, (uint8*)&ds_met_entry6_w, sizeof(ds_met_entry6_w));
                }
                else
                {
                    if (IS_BIT_SET(metEntryPtr, 0))
                    {
                        sal_memcpy((uint8*)&ds_met_entry, ((uint8 *)&ds_met_entry6_w) + sizeof(ds_met_entry), sizeof(ds_met_entry));
                    }
                    else
                    {
                        sal_memcpy((uint8*)&ds_met_entry, ((uint8 *)&ds_met_entry6_w), sizeof(ds_met_entry6_w));
                    }
                    sal_memset(((uint8*)&ds_met_entry) + sizeof(ds_met_entry), 0, sizeof(ds_met_entry));
                }

                GetDsMetEntry(A, nextMetEntryPtr_f, &ds_met_entry, &nextMetEntryPtr);
                GetDsMetEntry(A, endLocalRep_f, &ds_met_entry, &endLocalRep);
                GetDsMetEntry(A, isLinkAggregation_f, &ds_met_entry, &isLinkAggregation);

#if 0
                GetDsMetEntry(A, remoteChip_f, &ds_met_entry, &remoteChip);
                GetDsMetEntry(A, isMet_f, &ds_met_entry, &isMet);
#endif

                GetDsMetEntry(A, u1_g2_replicationCtl_f, &ds_met_entry, &replicationCtl);
                GetDsMetEntry(A, u1_g2_ucastId_f, &ds_met_entry, &ucastId);
                GetDsMetEntry(A, nextHopExt_f, &ds_met_entry, &nexthopExt);
                GetDsMetEntry(A, nextHopPtr_f, &ds_met_entry, &nexthopPtr);
                GetDsMetEntry(A, mcastMode_f, &ds_met_entry, &mcastMode);
                GetDsMetEntry(A, u1_g2_apsBridgeEn_f, &ds_met_entry, &apsBridgeEn);

                if(remoteChip)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "to remote chip", "YES");
                }
                else
                {
                    if (!mcastMode && apsBridgeEn)
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "APS bridge", "YES");
                        CTC_DKIT_PATH_PRINT("%-15s:%d\n", "APS group", ucastId);
                    }

                    if (!mcastMode)
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "met mode", "link list");
                        if (isLinkAggregation)
                        {
                            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "do linkagg, group", ucastId&CTC_DKIT_DRV_LINKAGGID_MASK);
                        }
                        else
                        {
                            CTC_DKIT_PATH_PRINT("%-15s:0x%04x\n", "dest gport",
                                                                          CTC_DKIT_DRV_LPORT_TO_CTC_GPORT(local_chip, ucastId&0x1FF));
                        }
                        CTC_DKIT_PATH_PRINT("%-15s:%d\n", "replication cnt", replicationCtl&0x1F);

                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "is 8Wnhp", nexthopExt? "YES" : "NO");
                        if ((((replicationCtl >> 5) >> 4)&0x3FFF) != dsNextHopInternalBase)
                        {
                            CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "nexthop index", (replicationCtl >> 5));
                            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", nexthopExt? "DsNextHop8W" : "DsNextHop4W");
                        }
                        else
                        {
                            CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "nexthop index", ((replicationCtl >> 5) >> 4));
                            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", "EpeNextHopInternal");
                        }
                    }
                    else
                    {
                        GetDsMetEntry(A, portBitmapHigh_f, &ds_met_entry, &port_bitmap_high);
                        GetDsMetEntry(A, u1_g1_portBitmap_f, &ds_met_entry, &port_bitmap_low);
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "met mode", "port bitmap");
                        if (isLinkAggregation)
                        {
                            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "do linkagg", "YES");
                        }
                        else
                        {
                            sal_memcpy(port_bitmap, port_bitmap_low, 8);
                            port_bitmap[7] |= (port_bitmap_high[0] << 3);
                            CTC_DKIT_PATH_PRINT("%-15s:", "dest port63~0");
                            CTC_DKIT_PRINT("0x%02x", port_bitmap[7]);
                            CTC_DKIT_PRINT("%02x", port_bitmap[6]);
                            CTC_DKIT_PRINT("%02x", port_bitmap[5]);
                            CTC_DKIT_PRINT("%02x", port_bitmap[4]);
                            CTC_DKIT_PRINT("%02x", port_bitmap[3]);
                            CTC_DKIT_PRINT("%02x", port_bitmap[2]);
                            CTC_DKIT_PRINT("%02x", port_bitmap[1]);
                            CTC_DKIT_PRINT("%02x\n", port_bitmap[0]);
                            sal_memset(port_bitmap, 0 , 8);
                            port_bitmap[0] = (port_bitmap_high[1] << 3) + (port_bitmap_high[0] >> 5);
                            port_bitmap[1] = (port_bitmap_high[2] << 3) + (port_bitmap_high[1] >> 5);
                            port_bitmap[2] = (port_bitmap_high[3] << 3) + (port_bitmap_high[2] >> 5);
                            port_bitmap[3] = (port_bitmap_high[4] << 3) + (port_bitmap_high[3] >> 5);
                            port_bitmap[4] = (port_bitmap_high[5] << 3) + (port_bitmap_high[4] >> 5);
                            port_bitmap[5] = (port_bitmap_high[6] << 3) + (port_bitmap_high[5] >> 5);
                            port_bitmap[6] = (port_bitmap_high[7] << 3) + (port_bitmap_high[6] >> 5);
                            port_bitmap[7] = (port_bitmap_high[8] << 3) + (port_bitmap_high[7] >> 5);
                            CTC_DKIT_PATH_PRINT("%-15s:", "dest port125~64");
                            CTC_DKIT_PRINT("0x%02x", port_bitmap[7]);
                            CTC_DKIT_PRINT("%02x", port_bitmap[6]);
                            CTC_DKIT_PRINT("%02x", port_bitmap[5]);
                            CTC_DKIT_PRINT("%02x", port_bitmap[4]);
                            CTC_DKIT_PRINT("%02x", port_bitmap[3]);
                            CTC_DKIT_PRINT("%02x", port_bitmap[2]);
                            CTC_DKIT_PRINT("%02x", port_bitmap[1]);
                            CTC_DKIT_PRINT("%02x\n", port_bitmap[0]);

                            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "is 8wnhp", nexthopExt? "YES" : "NO");
                            if (((nexthopPtr >> 4)&0x3FFF) != dsNextHopInternalBase)
                            {
                                CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "nexthop index", nexthopPtr);
                                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", nexthopExt? "DsNextHop8W" : "DsNextHop4W");
                            }
                            else
                            {
                                CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "nexthop index", (nexthopPtr &0xF));
                                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", "EpeNextHopInternal");
                            }
                        }
                    }
                }
                end_replication = (0xFFFF == nextMetEntryPtr) || (1 == remaining_rcd) || (!isMet);
                remaining_rcd--;

                if (end_replication)
                {
                    break;
                }
            }
        }
        else if(p_info->path_sel == 2 || p_info->path_sel == 3)
        {
            CTC_DKIT_PRINT("Exception Process:\n");
            CTC_DKIT_PATH_PRINT("%-15s: 0x%-08x\n", "exception Vector", exce_vec);
        }
    }
    if (met_enqueueDiscard)
    {
        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Drop!!!", "Drop at METFIFO");
    }
    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_bsr_linkagg(ctc_dkit_captured_path_info_t* p_info)
{
    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_bsr_queue(ctc_dkit_captured_path_info_t* p_info)
{
    uint32 cmd = 0;
    uint8 lchip = p_info->lchip;
    /*DbgFwdQWriteInfo*/
    uint32 qmgr_channelIdValid = 0;
    uint32 qmgr_channelId = 0;
    uint32 qmgr_cnAction = 0;
    uint32 qmgr_cutThroughEn = 0;
    uint32 qmgr_dsQueueMapTcamData = 0;
    uint32 qmgr_dsQueueMapTcamKey = 0;
    uint32 qmgr_enqueueDiscard = 0;
    uint32 qmgr_forwardDropValid = 0;
    uint32 qmgr_freePtr = 0;
    uint32 qmgr_hitIndex = 0;
    uint32 qmgr_mcastLinkAggregationDiscard = 0;
    uint32 qmgr_noLinkAggregationMemberDiscard = 0;
    uint32 qmgr_pktLenAdjFinal = 0;
    uint32 qmgr_queueId = 0;
    uint32 qmgr_replicationCtl = 0;
    uint32 qmgr_reservedChannelDropValid = 0;
    uint32 qmgr_spanOnDropValid = 0;
    uint32 qmgr_stackingDiscard = 0;
    uint32 qmgr_statsPtr = 0;
    uint32 qmgr_tcamResultValid = 0;
    uint32 qmgr_valid = 0;
    DbgFwdQWriteInfo_m dbg_fwd_que_mgr_info;

    /*DbgErmResrcAllocInfo*/
    uint32 enq_aqmPortCnt = 0;
    uint32 enq_aqmPortEn = 0;
    uint32 enq_aqmPortStall = 0;
    uint32 enq_aqmQueueEn = 0;
    uint32 enq_avgQueueLen = 0;
    uint32 enq_c2cCnt = 0;
    uint32 enq_c2cPass = 0;
    uint32 enq_cngLevel = 0;
    uint32 enq_congestionValid = 0;
    uint32 enq_criticalCnt = 0;
    uint32 enq_criticalPass = 0;
    uint32 enq_dpThrd = 0;
    uint32 enq_isC2cPacket = 0;
    uint32 enq_isCriticalPacket = 0;
    uint32 enq_isEcnMarkValid = 0;
    uint32 enq_isPortGuaranteed = 0;
    uint32 enq_isQueueGuaranteed = 0;
    uint32 enq_microburstValid = 0;
    uint32 enq_portCnt = 0;
    uint32 enq_portCongestionValid = 0;
    uint32 enq_portRemain = 0;
    uint32 enq_portThrdPass = 0;
    uint32 enq_pseudoRandomNumber = 0;
    uint32 enq_queueCnt = 0;
    uint32 enq_queueThrdPass = 0;
    uint32 enq_resourceCheckPass = 0;
    uint32 enq_scCnt = 0;
    uint32 enq_scRemain = 0;
    uint32 enq_scThrdPass = 0;
    uint32 enq_spanCnt = 0;
    uint32 enq_spanOnDropPass = 0;
    uint32 enq_spanOnDropValid = 0;
    uint32 enq_totalCnt = 0;
    uint32 enq_totalThrdPass = 0;
    uint32 enq_valid = 0;
    DbgErmResrcAllocInfo_m  dbg_q_mgr_enq_info;

    sal_memset(&dbg_fwd_que_mgr_info, 0, sizeof(DbgFwdQWriteInfo_m));
    cmd = DRV_IOR(DbgFwdQWriteInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_fwd_que_mgr_info);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoChannelIdValid_f, &dbg_fwd_que_mgr_info, &qmgr_channelIdValid);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoChannelId_f, &dbg_fwd_que_mgr_info, &qmgr_channelId);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoCnAction_f, &dbg_fwd_que_mgr_info, &qmgr_cnAction);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoCutThroughEn_f, &dbg_fwd_que_mgr_info, &qmgr_cutThroughEn);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoDsQueueMapTcamData_f, &dbg_fwd_que_mgr_info, &qmgr_dsQueueMapTcamData);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoDsQueueMapTcamKey_f, &dbg_fwd_que_mgr_info, &qmgr_dsQueueMapTcamKey);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoEnqueueDiscard_f, &dbg_fwd_que_mgr_info, &qmgr_enqueueDiscard);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoForwardDropValid_f, &dbg_fwd_que_mgr_info, &qmgr_forwardDropValid);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoFreePtr_f, &dbg_fwd_que_mgr_info, &qmgr_freePtr);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoHitIndex_f, &dbg_fwd_que_mgr_info, &qmgr_hitIndex);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoMcastLinkAggregationDiscard_f, &dbg_fwd_que_mgr_info, &qmgr_mcastLinkAggregationDiscard);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoNoLinkAggregationMemberDiscard_f, &dbg_fwd_que_mgr_info, &qmgr_noLinkAggregationMemberDiscard);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoPktLenAdjFinal_f, &dbg_fwd_que_mgr_info, &qmgr_pktLenAdjFinal);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoQueueId_f, &dbg_fwd_que_mgr_info, &qmgr_queueId);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoReplicationCtl_f, &dbg_fwd_que_mgr_info, &qmgr_replicationCtl);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoReservedChannelDropValid_f, &dbg_fwd_que_mgr_info, &qmgr_reservedChannelDropValid);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoSpanOnDropValid_f, &dbg_fwd_que_mgr_info, &qmgr_spanOnDropValid);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoStackingDiscard_f, &dbg_fwd_que_mgr_info, &qmgr_stackingDiscard);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoStatsPtr_f, &dbg_fwd_que_mgr_info, &qmgr_statsPtr);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoTcamResultValid_f, &dbg_fwd_que_mgr_info, &qmgr_tcamResultValid);
    GetDbgFwdQWriteInfo(A, fwdQWriteInfoValid_f, &dbg_fwd_que_mgr_info, &qmgr_valid);

    sal_memset(&dbg_q_mgr_enq_info, 0, sizeof(DbgErmResrcAllocInfo_m));
    cmd = DRV_IOR(DbgErmResrcAllocInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_q_mgr_enq_info);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoAqmPortCnt_f, &dbg_q_mgr_enq_info, &enq_aqmPortCnt);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoAqmPortEn_f, &dbg_q_mgr_enq_info, &enq_aqmPortEn);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoAqmPortStall_f, &dbg_q_mgr_enq_info, &enq_aqmPortStall);
    //-GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoAdmQueueEn_f, &dbg_q_mgr_enq_info, &enq_aqmQueueEn);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoAvgQueueLen_f, &dbg_q_mgr_enq_info, &enq_avgQueueLen);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoC2cCnt_f, &dbg_q_mgr_enq_info, &enq_c2cCnt);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoC2cPass_f, &dbg_q_mgr_enq_info, &enq_c2cPass);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoCngLevel_f, &dbg_q_mgr_enq_info, &enq_cngLevel);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoCongestionValid_f, &dbg_q_mgr_enq_info, &enq_congestionValid);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoCriticalCnt_f, &dbg_q_mgr_enq_info, &enq_criticalCnt);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoCriticalPass_f, &dbg_q_mgr_enq_info, &enq_criticalPass);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoDpThrd_f, &dbg_q_mgr_enq_info, &enq_dpThrd);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoIsC2cPacket_f, &dbg_q_mgr_enq_info, &enq_isC2cPacket);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoIsCriticalPacket_f, &dbg_q_mgr_enq_info, &enq_isCriticalPacket);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoIsEcnMarkValid_f, &dbg_q_mgr_enq_info, &enq_isEcnMarkValid);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoIsPortGuaranteed_f, &dbg_q_mgr_enq_info, &enq_isPortGuaranteed);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoIsQueueGuaranteed_f, &dbg_q_mgr_enq_info, &enq_isQueueGuaranteed);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoMicroburstValid_f, &dbg_q_mgr_enq_info, &enq_microburstValid);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoScCnt_f, &dbg_q_mgr_enq_info, &enq_portCnt);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoScRemain_f, &dbg_q_mgr_enq_info, &enq_portRemain);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoScThrdPass_f, &dbg_q_mgr_enq_info, &enq_portThrdPass);
    //-GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoSseudoRandomNumber_f, &dbg_q_mgr_enq_info, &enq_pseudoRandomNumber);
    //-GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoSueueCnt_f, &dbg_q_mgr_enq_info, &enq_queueCnt);
    //-GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoSueueThrdPass_f, &dbg_q_mgr_enq_info, &enq_queueThrdPass);
    //-GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoSesourceCheckPass_f, &dbg_q_mgr_enq_info, &enq_resourceCheckPass);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoScCnt_f, &dbg_q_mgr_enq_info, &enq_scCnt);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoScRemain_f, &dbg_q_mgr_enq_info, &enq_scRemain);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoScThrdPass_f, &dbg_q_mgr_enq_info, &enq_scThrdPass);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoSpanCnt_f, &dbg_q_mgr_enq_info, &enq_spanCnt);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoSpanOnDropPass_f, &dbg_q_mgr_enq_info, &enq_spanOnDropPass);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoSpanOnDropValid_f, &dbg_q_mgr_enq_info, &enq_spanOnDropValid);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoTotalCnt_f, &dbg_q_mgr_enq_info, &enq_totalCnt);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoTotalThrdPass_f, &dbg_q_mgr_enq_info, &enq_totalThrdPass);
    GetDbgErmResrcAllocInfo(A, ermResrcAllocInfoValid_f, &dbg_q_mgr_enq_info, &enq_valid);

    if (qmgr_valid)
    {
        CTC_DKIT_PRINT("Queue Process:\n");

        if (qmgr_noLinkAggregationMemberDiscard)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Drop!!!", "port linkagg no member");
        }
        else if (qmgr_mcastLinkAggregationDiscard)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Drop!!!", "mcast linkagg no member");
        }
        else if (qmgr_stackingDiscard)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Drop!!!", "stacking discard");
        }
        else
        {
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "queue id", qmgr_queueId);
        }

        if (enq_valid)
        {
            if (!enq_resourceCheckPass)
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Drop!!!", "enqueue discard");
            }
        }

    }

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_bsr(ctc_dkit_captured_path_info_t* p_info)
{
    CTC_DKIT_PRINT("\nRELAY PROCESS    \n-----------------------------------\n");

    /*1. Mcast Or exception*/
    if (p_info->detail)
    {
        _ctc_goldengate_dkit_captured_path_bsr_mcast(p_info);
    }
    /*2. Linkagg*/
    if ((!p_info->discard) && (p_info->detail))
    {
        _ctc_goldengate_dkit_captured_path_bsr_linkagg(p_info);
    }
    /*3. Queue*/
    if (p_info->detail)
    {
        _ctc_goldengate_dkit_captured_path_bsr_queue(p_info);
    }

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_epe_parser(ctc_dkit_captured_path_info_t* p_info)
{
    _ctc_goldengate_dkit_captured_path_parser(p_info, 2);

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_epe_scl(ctc_dkit_captured_path_info_t* p_info)
{
     uint8 slice = p_info->slice_epe;
     uint8 lchip = p_info->lchip;
     uint32 cmd = 0;
     char* key_name[11] =
     {
         "None", "DsEgressXcOamDoubleVlanPortHashKey", "DsEgressXcOamSvlanPortHashKey", "DsEgressXcOamCvlanPortHashKey",
          "DsEgressXcOamSvlanCosPortHashKey", "DsEgressXcOamCvlanCosPortHashKey", "DsEgressXcOamPortVlanCrossHashKey",
          "DsEgressXcOamPortCrossHashKey", "DsEgressXcOamPortHashKey", "DsEgressXcOamSvlanPortMacHashKey",
          "DsEgressXcOamTunnelPbbHashKey"
     };

     /*DbgEgrXcOamHash0EngineFromEpeNhpInfo*/
     uint32 hash0_resultValid = 0;
     uint32 hash0_defaultEntryValid = 0;
     //uint32 hash0_egressXcOamHashConflict = 0;
     uint32 hash0_keyIndex = 0;
     uint32 hash0_valid = 0;
     DbgEgrXcOamHash0EngineFromEpeNhpInfo_m dbg_egr_xc_oam_hash0_engine_from_epe_nhp_info;
     /*DbgEgrXcOamHash1EngineFromEpeNhpInfo*/
     uint32 hash1_resultValid = 0;
     uint32 hash1_defaultEntryValid = 0;
     //uint32 hash1_egressXcOamHashConflict = 0;
     uint32 hash1_keyIndex = 0;
     uint32 hash1_valid = 0;
     DbgEgrXcOamHash1EngineFromEpeNhpInfo_m dbg_egr_xc_oam_hash1_engine_from_epe_nhp_info;
     /*DbgEpeNextHopInfo*/
     uint32 scl_discard = 0;
     uint32 scl_discardType = 0;
     uint32 scl_lookup1Valid = 0;
     uint32 scl_vlanHash1Type = 0;
     uint32 scl_lookup2Valid = 0;
     uint32 scl_vlanHash2Type = 0;
     uint32 scl_vlanXlateResult1Valid = 0;
     uint32 scl_vlanXlateResult2Valid = 0;
     uint32 scl_hashPort = 0;
     uint32 scl_valid = 0;
     DbgEpeNextHopInfo_m dbg_epe_next_hop_info;

     /*DbgEgrXcOamHash0EngineFromEpeNhpInfo*/
     sal_memset(&dbg_egr_xc_oam_hash0_engine_from_epe_nhp_info, 0, sizeof(dbg_egr_xc_oam_hash0_engine_from_epe_nhp_info));
     cmd = DRV_IOR(DbgEgrXcOamHash0EngineFromEpeNhpInfo_t, DRV_ENTRY_FLAG);
     DRV_IOCTL(lchip, slice, cmd, &dbg_egr_xc_oam_hash0_engine_from_epe_nhp_info);
     GetDbgEgrXcOamHash0EngineFromEpeNhpInfo(A, egrXcOamHash0EngineFromEpeNhpInfoResultValid_f, &dbg_egr_xc_oam_hash0_engine_from_epe_nhp_info, &hash0_resultValid);
     GetDbgEgrXcOamHash0EngineFromEpeNhpInfo(A, egrXcOamHash0EngineFromEpeNhpInfoDefaultEntryValid_f, &dbg_egr_xc_oam_hash0_engine_from_epe_nhp_info, &hash0_defaultEntryValid);
     GetDbgEgrXcOamHash0EngineFromEpeNhpInfo(A, egrXcOamHash0EngineFromEpeNhpInfoKeyIndex_f, &dbg_egr_xc_oam_hash0_engine_from_epe_nhp_info, &hash0_keyIndex);
     GetDbgEgrXcOamHash0EngineFromEpeNhpInfo(A, egrXcOamHash0EngineFromEpeNhpInfoValid_f, &dbg_egr_xc_oam_hash0_engine_from_epe_nhp_info, &hash0_valid);

     /*DbgEgrXcOamHash1EngineFromEpeNhpInfo*/
     sal_memset(&dbg_egr_xc_oam_hash1_engine_from_epe_nhp_info, 0, sizeof(dbg_egr_xc_oam_hash1_engine_from_epe_nhp_info));
     cmd = DRV_IOR(DbgEgrXcOamHash1EngineFromEpeNhpInfo_t, DRV_ENTRY_FLAG);
     DRV_IOCTL(lchip, slice, cmd, &dbg_egr_xc_oam_hash1_engine_from_epe_nhp_info);
     GetDbgEgrXcOamHash1EngineFromEpeNhpInfo(A, egrXcOamHash1EngineFromEpeNhpInfoResultValid_f, &dbg_egr_xc_oam_hash1_engine_from_epe_nhp_info, &hash1_resultValid);
     GetDbgEgrXcOamHash1EngineFromEpeNhpInfo(A, egrXcOamHash1EngineFromEpeNhpInfoDefaultEntryValid_f, &dbg_egr_xc_oam_hash1_engine_from_epe_nhp_info, &hash1_defaultEntryValid);
     GetDbgEgrXcOamHash1EngineFromEpeNhpInfo(A, egrXcOamHash1EngineFromEpeNhpInfoKeyIndex_f, &dbg_egr_xc_oam_hash1_engine_from_epe_nhp_info, &hash1_keyIndex);
     GetDbgEgrXcOamHash1EngineFromEpeNhpInfo(A, egrXcOamHash1EngineFromEpeNhpInfoValid_f, &dbg_egr_xc_oam_hash1_engine_from_epe_nhp_info, &hash1_valid);
     /*DbgEpeNextHopInfo*/
     sal_memset(&dbg_epe_next_hop_info, 0, sizeof(dbg_epe_next_hop_info));
     cmd = DRV_IOR(DbgEpeNextHopInfo_t, DRV_ENTRY_FLAG);
     DRV_IOCTL(lchip, slice, cmd, &dbg_epe_next_hop_info);
     GetDbgEpeNextHopInfo(A, epeNextHopInfoDiscard_f, &dbg_epe_next_hop_info, &scl_discard);
     GetDbgEpeNextHopInfo(A, epeNextHopInfoDiscardType_f, &dbg_epe_next_hop_info, &scl_discardType);
     GetDbgEpeNextHopInfo(A, epeNextHopInfoLookup1Valid_f, &dbg_epe_next_hop_info, &scl_lookup1Valid);
     GetDbgEpeNextHopInfo(A, epeNextHopInfoVlanHash1Type_f, &dbg_epe_next_hop_info, &scl_vlanHash1Type);
     GetDbgEpeNextHopInfo(A, epeNextHopInfoLookup2Valid_f, &dbg_epe_next_hop_info, &scl_lookup2Valid);
     GetDbgEpeNextHopInfo(A, epeNextHopInfoVlanHash2Type_f, &dbg_epe_next_hop_info, &scl_vlanHash2Type);
     GetDbgEpeNextHopInfo(A, epeNextHopInfoVlanXlateResult1Valid_f, &dbg_epe_next_hop_info, &scl_vlanXlateResult1Valid);
     GetDbgEpeNextHopInfo(A, epeNextHopInfoVlanXlateResult2Valid_f, &dbg_epe_next_hop_info, &scl_vlanXlateResult2Valid);
     GetDbgEpeNextHopInfo(A, epeNextHopInfoHashPort_f, &dbg_epe_next_hop_info, &scl_hashPort);
     GetDbgEpeNextHopInfo(A, epeNextHopInfoValid_f, &dbg_epe_next_hop_info, &scl_valid);

    if (0 == p_info->detail)
    {
        goto Discard;
    }

     if (scl_valid)
     {
         if (hash0_valid || hash1_valid)
         {
             CTC_DKIT_PRINT("SCL Process:\n");
             if (scl_lookup1Valid)
             {
                 CTC_DKIT_PATH_PRINT("%-15s\n", "HASH0 lookup--->");
                 if (hash0_defaultEntryValid)
                 {
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_DEFAULT);
                     CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", hash0_keyIndex);
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", key_name[scl_vlanHash1Type]);
                 }
                 /*else if (hash1_egressXcOamHashConflict)
                 {
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_CONFLICT);
                     CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", hash0_keyIndex);
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", "");
                 }*/
                 else if (hash0_resultValid)
                 {
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_HASH_HIT);
                     CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", hash0_keyIndex);
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", key_name[scl_vlanHash1Type]);
                 }
                 else
                 {
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
                 }
             }

             if (scl_lookup2Valid)
             {
                 CTC_DKIT_PATH_PRINT("%-15s\n", "HASH1 lookup--->");
                 if (hash1_defaultEntryValid)
                 {
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_DEFAULT);
                     CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", hash1_keyIndex);
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", key_name[scl_vlanHash2Type]);
                 }
                 /*else if (hash1_egressXcOamHashConflict)
                 {
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_CONFLICT);
                     CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", hash1_keyIndex);
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", key_name[scl_vlanHash2Type]);
                 }*/
                 else if (hash1_resultValid)
                 {
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_HASH_HIT);
                     CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", hash1_keyIndex);
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", key_name[scl_vlanHash2Type]);
                 }
                 else
                 {
                     CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
                 }
             }
         }
     }

Discard:
         //_ctc_goldengate_dkit_captured_path_discard_process(p_info, scl_discard, scl_discardType, CTC_DKIT_EPE);

    return CLI_SUCCESS;
}
static int32
_ctc_goldengate_dkit_captured_path_epe_interface(ctc_dkit_captured_path_info_t* p_info)
{
    uint8 slice = p_info->slice_epe;
    uint8 lchip = p_info->lchip;
    uint32 cmd = 0;
    uint32 localPhyPort = 0;
    uint32 interfaceId = 0;
    uint32 destVlanPtr = 0;
    uint32 globalDestPort = 0;
    uint16 gport = 0;
    uint8 gchip = 0;
    uint32 valid = 0;
    uint32 packetOffset = 0;
    uint32 discard = 0;
    uint32 discard_type = 0;

    CTC_DKIT_PRINT("Interface Process:\n");

    cmd = DRV_IOR(DbgEpeHdrAdjInfo_t, DbgEpeHdrAdjInfo_epeHdrAdjInfoValid_f);
    DRV_IOCTL(lchip, slice, cmd, &valid);
    if (valid)
    {
        cmd = DRV_IOR(DbgEpeHdrAdjInfo_t, DbgEpeHdrAdjInfo_epeHdrAdjInfoLocalPhyPort_f);
        DRV_IOCTL(lchip, slice, cmd, &localPhyPort);
        cmd = DRV_IOR(DsDestPort_t, DsDestPort_globalDestPort_f);
        DRV_IOCTL(lchip, (localPhyPort + slice*CTC_DKIT_ONE_SLICE_PORT_NUM), cmd, &globalDestPort);
        if (CTC_DKIT_DRV_GPORT_IS_LINKAGG_PORT(globalDestPort))
        {
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "linkagg group", CTC_DKIT_DRV_GPORT_TO_LINKAGG_ID(globalDestPort));
        }
        CTC_DKIT_GET_GCHIP(lchip, gchip);
        gport = CTC_DKIT_DRV_LPORT_TO_CTC_GPORT(gchip, (localPhyPort + slice*CTC_DKIT_ONE_SLICE_PORT_NUM));
        CTC_DKIT_PATH_PRINT("%-15s:0x%04x\n", "dest gport", gport);

        cmd = DRV_IOR(DbgEpeHdrAdjInfo_t, DbgEpeHdrAdjInfo_epeHdrAdjInfoPacketOffset_f);
        DRV_IOCTL(lchip, slice, cmd, &packetOffset);
        if (packetOffset)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%d bytes\n", "strip packet", packetOffset);
        }
    }

    cmd = DRV_IOR(DbgEpeNextHopInfo_t, DbgEpeNextHopInfo_epeNextHopInfoValid_f);
    DRV_IOCTL(lchip, slice, cmd, &valid);
    if (valid)
    {
        cmd = DRV_IOR(DbgEpeNextHopInfo_t, DbgEpeNextHopInfo_epeNextHopInfoDestVlanPtr_f);
        DRV_IOCTL(lchip, slice, cmd, &destVlanPtr);
        cmd = DRV_IOR(DbgEpeNextHopInfo_t, DbgEpeNextHopInfo_epeNextHopInfoInterfaceId_f);
        DRV_IOCTL(lchip, slice, cmd, &interfaceId);
        if (destVlanPtr < 4096)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "vlan ptr", destVlanPtr);
        }
        if (interfaceId)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "l3 intf id", interfaceId);
        }
    }

    cmd = DRV_IOR(DbgEpeHdrAdjInfo_t, DbgEpeHdrAdjInfo_epeHdrAdjInfoDiscard_f);
    DRV_IOCTL(lchip, slice, cmd, &discard);
    cmd = DRV_IOR(DbgEpeHdrAdjInfo_t, DbgEpeHdrAdjInfo_epeHdrAdjInfoDiscardType_f);
    DRV_IOCTL(lchip, slice, cmd, &discard_type);
    if (!discard)
    {
        cmd = DRV_IOR(DbgEpeNextHopInfo_t, DbgEpeNextHopInfo_epeNextHopInfoDiscard_f);
        DRV_IOCTL(lchip, slice, cmd, &discard);
        cmd = DRV_IOR(DbgEpeNextHopInfo_t, DbgEpeNextHopInfo_epeNextHopInfoDiscardType_f);
        DRV_IOCTL(lchip, slice, cmd, &discard_type);
    }
    _ctc_goldengate_dkit_captured_path_discard_process(p_info, discard, discard_type, CTC_DKIT_EPE);

    return CLI_SUCCESS;
}
static int32
_ctc_goldengate_dkit_captured_path_epe_acl(ctc_dkit_captured_path_info_t* p_info)
{
    uint8 slice = p_info->slice_epe;
    uint8 lchip = p_info->lchip;
    uint32 cmd = 0;
    uint8  idx = 0;
    char* acl_key_type_desc[10] = {"TCAML2KEY", "TCAML2L3KEY", "TCAML3KEY", "TCAMVLANKEY", "TCAML3EXTKEY",
                                "TCAML2L3EXTKEY", "TCAMCIDKEY", "TCAMINTFKEY", "TCAMFWDKEY", "TCAMFWDEXTKEY"};
    /*DbgFlowTcamEngineEpeAclInfo*/
    uint32 tcam_egressAcl0TcamResultValid = 0;
    uint32 tcam_egressAcl0TcamIndex = 0;
    uint32 tcam_egressAcl0_valid = 0;
    uint32 tcam_egressAcl1TcamResultValid = 0;
    uint32 tcam_egressAcl1TcamIndex = 0;
    uint32 tcam_egressAcl1_valid = 0;
    uint32 tcam_egressAcl2TcamResultValid = 0;
    uint32 tcam_egressAcl2TcamIndex = 0;
    uint32 tcam_egressAcl2_valid = 0;
    DbgFlowTcamEngineEpeAclInfo0_m dbg_flow_tcam_engine_epe_acl_info;

    /*DbgFlowTcamEngineEpeAclKeyInfo0-3*/
    uint32 acl_key_info[10] = {0};
    uint32 acl_key_valid = 0;
    DbgFlowTcamEngineEpeAclKeyInfo0_m dbg_acl_key_info;
    uint8  step = DbgFlowTcamEngineEpeAclKeyInfo1_flowTcamEngineEpeAclKeyInfo1Key_f -       \
                        DbgFlowTcamEngineEpeAclKeyInfo0_flowTcamEngineEpeAclKeyInfo0Key_f;
    uint32 acl_key_info_key_id[3] = {DbgFlowTcamEngineEpeAclKeyInfo0_t, DbgFlowTcamEngineEpeAclKeyInfo1_t,
                                 DbgFlowTcamEngineEpeAclKeyInfo2_t};
    uint32 acl_key_type = 0;

    /*DbgEpeAclInfo*/
    uint32 acl_discard = 0;
    uint32 acl_discardType = 0;
    uint32 acl_exceptionEn = 0;
    uint32 acl_exceptionIndex = 0;
    uint32 acl_en_bitmap = 0;
    uint32 acl_valid = 0;
    DbgEpeAclInfo_m dbg_epe_acl_info;

    /*DbgFlowTcamEngineEpeAclInfo0*/
    sal_memset(&dbg_flow_tcam_engine_epe_acl_info, 0, sizeof(dbg_flow_tcam_engine_epe_acl_info));
    cmd = DRV_IOR(DbgFlowTcamEngineEpeAclInfo0_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_flow_tcam_engine_epe_acl_info);
    GetDbgFlowTcamEngineEpeAclInfo0(A, flowTcamEngineEpeAclInfo0EgrTcamResultValid0_f, &dbg_flow_tcam_engine_epe_acl_info, &tcam_egressAcl0TcamResultValid);
    GetDbgFlowTcamEngineEpeAclInfo0(A, flowTcamEngineEpeAclInfo0EgrTcamIndex0_f, &dbg_flow_tcam_engine_epe_acl_info, &tcam_egressAcl0TcamIndex);
    GetDbgFlowTcamEngineEpeAclInfo0(A, flowTcamEngineEpeAclInfo0Valid_f, &dbg_flow_tcam_engine_epe_acl_info, &tcam_egressAcl0_valid);

    /*DbgFlowTcamEngineEpeAclInfo1*/
    sal_memset(&dbg_flow_tcam_engine_epe_acl_info, 0, sizeof(dbg_flow_tcam_engine_epe_acl_info));
    cmd = DRV_IOR(DbgFlowTcamEngineEpeAclInfo1_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_flow_tcam_engine_epe_acl_info);
    GetDbgFlowTcamEngineEpeAclInfo1(A, flowTcamEngineEpeAclInfo1EgrTcamResultValid1_f, &dbg_flow_tcam_engine_epe_acl_info, &tcam_egressAcl1TcamResultValid);
    GetDbgFlowTcamEngineEpeAclInfo1(A, flowTcamEngineEpeAclInfo1EgrTcamIndex1_f, &dbg_flow_tcam_engine_epe_acl_info, &tcam_egressAcl1TcamIndex);
    GetDbgFlowTcamEngineEpeAclInfo1(A, flowTcamEngineEpeAclInfo1Valid_f, &dbg_flow_tcam_engine_epe_acl_info, &tcam_egressAcl1_valid);

    /*DbgFlowTcamEngineEpeAclInfo2*/
    sal_memset(&dbg_flow_tcam_engine_epe_acl_info, 0, sizeof(dbg_flow_tcam_engine_epe_acl_info));
    cmd = DRV_IOR(DbgFlowTcamEngineEpeAclInfo2_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &dbg_flow_tcam_engine_epe_acl_info);
    GetDbgFlowTcamEngineEpeAclInfo2(A, flowTcamEngineEpeAclInfo2EgrTcamResultValid2_f, &dbg_flow_tcam_engine_epe_acl_info, &tcam_egressAcl2TcamResultValid);
    GetDbgFlowTcamEngineEpeAclInfo2(A, flowTcamEngineEpeAclInfo2EgrTcamIndex2_f, &dbg_flow_tcam_engine_epe_acl_info, &tcam_egressAcl2TcamIndex);
    GetDbgFlowTcamEngineEpeAclInfo2(A, flowTcamEngineEpeAclInfo2Valid_f, &dbg_flow_tcam_engine_epe_acl_info, &tcam_egressAcl2_valid);

    /*DbgEpeAclInfo*/
    sal_memset(&dbg_epe_acl_info, 0, sizeof(dbg_epe_acl_info));
    cmd = DRV_IOR(DbgEpeAclInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_epe_acl_info);
    GetDbgEpeAclInfo(A, epeAclInfoExceptionEn_f, &dbg_epe_acl_info, &acl_exceptionEn);
    GetDbgEpeAclInfo(A, epeAclInfoExceptionIndex_f, &dbg_epe_acl_info, &acl_exceptionIndex);
    GetDbgEpeAclInfo(A, epeAclInfoAclLookupLevelEnBitMap_f, &dbg_epe_acl_info, &acl_en_bitmap);
    GetDbgEpeAclInfo(A, epeAclInfoValid_f, &dbg_epe_acl_info, &acl_valid);

    if (0 == p_info->detail)
    {
        goto Discard;
    }

    if (acl_en_bitmap && acl_valid)
    {
        CTC_DKIT_PRINT("ACL Process:\n");

        /*tcam*/
        if (tcam_egressAcl0_valid || tcam_egressAcl1_valid || tcam_egressAcl2_valid)
        {
            char* lookup_result[3] = {"TCAM0 lookup--->", "TCAM1 lookup--->", "TCAM2 lookup--->"};
            uint32 result_valid[8] = {tcam_egressAcl0TcamResultValid, tcam_egressAcl1TcamResultValid,
                                        tcam_egressAcl2TcamResultValid};
            uint32 tcam_index[8] = {tcam_egressAcl0TcamIndex, tcam_egressAcl1TcamIndex,
                                        tcam_egressAcl2TcamIndex};

            for (idx = 0; idx < 3 ; idx++)
            {
                if ((acl_en_bitmap >> idx) & 0x1)
                {
                    CTC_DKIT_PATH_PRINT("%-15s\n", lookup_result[idx]);

                    cmd = DRV_IOR(acl_key_info_key_id[idx], DRV_ENTRY_FLAG);
                    DRV_IOCTL(lchip, 0, cmd, &dbg_acl_key_info);
                    DRV_GET_FIELD_A(acl_key_info_key_id[idx], DbgFlowTcamEngineEpeAclKeyInfo0_flowTcamEngineEpeAclKeyInfo0Key_f + step * idx,
                                    &dbg_acl_key_info, &acl_key_info);
                    DRV_GET_FIELD_A(acl_key_info_key_id[idx], DbgFlowTcamEngineEpeAclKeyInfo0_flowTcamEngineEpeAclKeyInfo0Valid_f + step * idx,
                                    &dbg_acl_key_info, &acl_key_valid);
                    /*get key type*/
                    if(acl_key_valid)
                    {
                        GetDsAclQosL3Key320Ing0(A, aclQosKeyType0_f, acl_key_info, &acl_key_type);
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key type", acl_key_type_desc[acl_key_type]);
                    }
                    else
                    {
                        CTC_DKIT_PATH_PRINT("DbgFlowTcamEngineEpeAclKeyInfo is not valid (just for test)!");
                    }
                    if (result_valid[idx])
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_TCAM_HIT);
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x%s (160bit)\n", "key index", tcam_index[idx]);
                    }
                    else
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
                    }
                }
            }
        }

    }


Discard:
     if (acl_discard)
     {
         if ((acl_discardType + CTC_DKIT_DISCARD_EPE_FEATURE_START) == CTC_DKIT_DISCARD_EPE_DS_ACL_DIS)
         {
             _ctc_goldengate_dkit_captured_path_discard_process(p_info, acl_discard, acl_discardType, CTC_DKIT_EPE);
         }
     }

     if (acl_exceptionEn)
     {
         CTC_DKIT_PATH_PRINT("%-15s:%s!!!\n", "Exception", "To CPU");
     }

    return CLI_SUCCESS;
}
static int32
_ctc_goldengate_dkit_captured_path_epe_oam(ctc_dkit_captured_path_info_t* p_info)
{
    uint8 slice = p_info->slice_epe;
    uint8 lchip = p_info->lchip;
    uint32 cmd = 0;
    uint8 i = 0;
    char* lookup_result[4] = {"ETHER lookup--->", "BFD lookup--->", "TP lookup--->", "Section lookup--->"};
    char* key_name[4] = {"DsEgressXcOamEthHashKey", "DsEgressXcOamBfdHashKey",
                                             "DsEgressXcOamMplsLabelHashKey", "DsEgressXcOamMplsSectionHashKey"};

    /*DbgEgrXcOamHashEngineFromEpeOam0Info*/
    uint32 hash0_resultValid = 0;
    uint32 hash0_egressXcOamHashConflict = 0;
    uint32 hash0_keyIndex = 0;
    uint32 hash0_valid = 0;
    DbgEgrXcOamHashEngineFromEpeOam0Info_m dbg_egr_xc_oam_hash_engine_from_epe_oam0_info;
    /*DbgEgrXcOamHashEngineFromEpeOam1Info*/
    uint32 hash1_resultValid = 0;
    uint32 hash1_egressXcOamHashConflict = 0;
    uint32 hash1_keyIndex = 0;
    uint32 hash1_valid = 0;
    DbgEgrXcOamHashEngineFromEpeOam1Info_m dbg_egr_xc_oam_hash_engine_from_epe_oam1_info;
    /*DbgEgrXcOamHashEngineFromEpeOam2Info*/
    uint32 hash2_resultValid = 0;
    uint32 hash2_egressXcOamHashConflict = 0;
    uint32 hash2_keyIndex = 0;
    uint32 hash2_valid = 0;
    DbgEgrXcOamHashEngineFromEpeOam2Info_m dbg_egr_xc_oam_hash_engine_from_epe_oam2_info;
    /*DbgEpeAclInfo*/
    uint32 lkp_egressXcOamKeyType0 = 0;
    uint32 lkp_egressXcOamKeyType1 = 0;
    uint32 lkp_egressXcOamKeyType2 = 0;
    uint32 lkp_valid = 0;
    DbgEpeAclInfo_m dbg_epe_acl_info;
    /*DbgEpeOamInfo*/
    uint32 oam_lmStatsEn0 = 0;
    uint32 oam_lmStatsEn1 = 0;
    uint32 oam_lmStatsEn2 = 0;
    uint32 oam_lmStatsIndex = 0;
    uint32 oam_lmStatsPtr0 = 0;
    uint32 oam_lmStatsPtr1 = 0;
    uint32 oam_lmStatsPtr2 = 0;
    uint32 oam_etherLmValid = 0;
    uint32 oam_mplsLmValid = 0;
    uint32 oam_oamDestChipId = 0;
    uint32 oam_mepIndex = 0;
    uint32 oam_mepEn = 0;
    uint32 oam_mipEn = 0;
    uint32 oam_tempRxOamType = 0;
    uint32 oam_valid = 0;
    DbgEpeOamInfo_m dbg_epe_oam_info;

    /*DbgEpeHdrEditInfo*/
    uint32 hdr_valid = 0;
    uint32 hdr_shareType = 0;
    uint32 hdr_loopbackEn = 0;

    uint8 key_type[3] = {lkp_egressXcOamKeyType0, lkp_egressXcOamKeyType1, lkp_egressXcOamKeyType2};
    uint8 hash_valid[3] = {hash0_valid, hash1_valid, hash2_valid};
    uint8 confict[3] = {hash0_egressXcOamHashConflict, hash1_egressXcOamHashConflict, hash2_egressXcOamHashConflict};
    uint32 key_index[3] = {hash0_keyIndex, hash1_keyIndex, hash2_keyIndex};
    uint8 hash_resultValid[3] = {hash0_resultValid,hash1_resultValid,hash2_resultValid};

    /*DbgEgrXcOamHashEngineFromEpeOam0Info*/
    sal_memset(&dbg_egr_xc_oam_hash_engine_from_epe_oam0_info, 0, sizeof(dbg_egr_xc_oam_hash_engine_from_epe_oam0_info));
    cmd = DRV_IOR(DbgEgrXcOamHashEngineFromEpeOam0Info_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_egr_xc_oam_hash_engine_from_epe_oam0_info);
    GetDbgEgrXcOamHashEngineFromEpeOam0Info(A, egrXcOamHashEngineFromEpeOam0InfoResultValid_f, &dbg_egr_xc_oam_hash_engine_from_epe_oam0_info, &hash0_resultValid);
    GetDbgEgrXcOamHashEngineFromEpeOam0Info(A, egrXcOamHashEngineFromEpeOam0InfoHashConflict_f, &dbg_egr_xc_oam_hash_engine_from_epe_oam0_info, &hash0_egressXcOamHashConflict);
    GetDbgEgrXcOamHashEngineFromEpeOam0Info(A, egrXcOamHashEngineFromEpeOam0InfoKeyIndex_f, &dbg_egr_xc_oam_hash_engine_from_epe_oam0_info, &hash0_keyIndex);
    GetDbgEgrXcOamHashEngineFromEpeOam0Info(A, egrXcOamHashEngineFromEpeOam0InfoValid_f, &dbg_egr_xc_oam_hash_engine_from_epe_oam0_info, &hash0_valid);
    /*DbgEgrXcOamHashEngineFromEpeOam1Info*/
    sal_memset(&dbg_egr_xc_oam_hash_engine_from_epe_oam1_info, 0, sizeof(dbg_egr_xc_oam_hash_engine_from_epe_oam1_info));
    cmd = DRV_IOR(DbgEgrXcOamHashEngineFromEpeOam1Info_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_egr_xc_oam_hash_engine_from_epe_oam1_info);
    GetDbgEgrXcOamHashEngineFromEpeOam1Info(A, egrXcOamHashEngineFromEpeOam1InfoResultValid_f, &dbg_egr_xc_oam_hash_engine_from_epe_oam1_info, &hash1_resultValid);
    GetDbgEgrXcOamHashEngineFromEpeOam1Info(A, egrXcOamHashEngineFromEpeOam1InfoHashConflict_f, &dbg_egr_xc_oam_hash_engine_from_epe_oam1_info, &hash1_egressXcOamHashConflict);
    GetDbgEgrXcOamHashEngineFromEpeOam1Info(A, egrXcOamHashEngineFromEpeOam1InfoKeyIndex_f, &dbg_egr_xc_oam_hash_engine_from_epe_oam1_info, &hash1_keyIndex);
    GetDbgEgrXcOamHashEngineFromEpeOam1Info(A, egrXcOamHashEngineFromEpeOam1InfoValid_f, &dbg_egr_xc_oam_hash_engine_from_epe_oam1_info, &hash1_valid);
    /*DbgEgrXcOamHashEngineFromEpeOam2Info*/
    sal_memset(&dbg_egr_xc_oam_hash_engine_from_epe_oam2_info, 0, sizeof(dbg_egr_xc_oam_hash_engine_from_epe_oam2_info));
    cmd = DRV_IOR(DbgEgrXcOamHashEngineFromEpeOam2Info_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_egr_xc_oam_hash_engine_from_epe_oam2_info);
    GetDbgEgrXcOamHashEngineFromEpeOam2Info(A, egrXcOamHashEngineFromEpeOam2InfoResultValid_f, &dbg_egr_xc_oam_hash_engine_from_epe_oam2_info, &hash2_resultValid);
    GetDbgEgrXcOamHashEngineFromEpeOam2Info(A, egrXcOamHashEngineFromEpeOam2InfoHashConflict_f, &dbg_egr_xc_oam_hash_engine_from_epe_oam2_info, &hash2_egressXcOamHashConflict);
    GetDbgEgrXcOamHashEngineFromEpeOam2Info(A, egrXcOamHashEngineFromEpeOam2InfoKeyIndex_f, &dbg_egr_xc_oam_hash_engine_from_epe_oam2_info, &hash2_keyIndex);
    GetDbgEgrXcOamHashEngineFromEpeOam2Info(A, egrXcOamHashEngineFromEpeOam2InfoValid_f, &dbg_egr_xc_oam_hash_engine_from_epe_oam2_info, &hash2_valid);
    /*DbgEpeAclInfo*/
    sal_memset(&dbg_epe_acl_info, 0, sizeof(dbg_epe_acl_info));
    cmd = DRV_IOR(DbgEpeAclInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_epe_acl_info);
   // GetDbgEpeAclInfo(A, epeAclInfoEgressXcOamKeyType0_f, &dbg_epe_acl_info, &lkp_egressXcOamKeyType0);
   // GetDbgEpeAclInfo(A, epeAclInfoEgressXcOamKeyType1_f, &dbg_epe_acl_info, &lkp_egressXcOamKeyType1);
   // GetDbgEpeAclInfo(A, epeAclInfoEgressXcOamKeyType2_f, &dbg_epe_acl_info, &lkp_egressXcOamKeyType2);
   // GetDbgEpeAclInfo(A, epeAclInfoValid_f, &dbg_epe_acl_info, &lkp_valid);
    /*DbgEpeOamInfo*/
    sal_memset(&dbg_epe_oam_info, 0, sizeof(dbg_epe_oam_info));
    cmd = DRV_IOR(DbgEpeOamInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_epe_oam_info);
    GetDbgEpeOamInfo(A, epeOamInfoLmStatsEn0_f, &dbg_epe_oam_info, &oam_lmStatsEn0);
    GetDbgEpeOamInfo(A, epeOamInfoLmStatsEn1_f, &dbg_epe_oam_info, &oam_lmStatsEn1);
    GetDbgEpeOamInfo(A, epeOamInfoLmStatsEn2_f, &dbg_epe_oam_info, &oam_lmStatsEn2);
    GetDbgEpeOamInfo(A, epeOamInfoLmStatsIndex_f, &dbg_epe_oam_info, &oam_lmStatsIndex);
    GetDbgEpeOamInfo(A, epeOamInfoLmStatsPtr0_f, &dbg_epe_oam_info, &oam_lmStatsPtr0);
    GetDbgEpeOamInfo(A, epeOamInfoLmStatsPtr1_f, &dbg_epe_oam_info, &oam_lmStatsPtr1);
    GetDbgEpeOamInfo(A, epeOamInfoLmStatsPtr2_f, &dbg_epe_oam_info, &oam_lmStatsPtr2);
    GetDbgEpeOamInfo(A, epeOamInfoEtherLmValid_f, &dbg_epe_oam_info, &oam_etherLmValid);
    GetDbgEpeOamInfo(A, epeOamInfoMplsLmValid_f, &dbg_epe_oam_info, &oam_mplsLmValid);
    GetDbgEpeOamInfo(A, epeOamInfoOamDestChipId_f, &dbg_epe_oam_info, &oam_oamDestChipId);
    GetDbgEpeOamInfo(A, epeOamInfoMepIndex_f, &dbg_epe_oam_info, &oam_mepIndex);
    GetDbgEpeOamInfo(A, epeOamInfoMepEn_f, &dbg_epe_oam_info, &oam_mepEn);
    GetDbgEpeOamInfo(A, epeOamInfoMipEn_f, &dbg_epe_oam_info, &oam_mipEn);
    GetDbgEpeOamInfo(A, epeOamInfoTempRxOamType_f, &dbg_epe_oam_info, &oam_tempRxOamType);
    GetDbgEpeOamInfo(A, epeOamInfoValid_f, &dbg_epe_oam_info, &oam_valid);

    /*DbgEpeHdrEditInfo*/
    cmd = DRV_IOR(DbgEpeHdrEditInfo_t, DbgEpeHdrEditInfo_epeHdrEditInfoValid_f);
    DRV_IOCTL(lchip, slice, cmd, &hdr_valid);
    cmd = DRV_IOR(DbgEpeHdrEditInfo_t, DbgEpeHdrEditInfo_epeHdrEditInfoShareType_f);
    DRV_IOCTL(lchip, slice, cmd, &hdr_shareType);
    cmd = DRV_IOR(DbgEpeHdrEditInfo_t, DbgEpeHdrEditInfo_epeHdrEditInfoLoopbackEn_f);
    DRV_IOCTL(lchip, slice, cmd, &hdr_loopbackEn);

    if (0 == p_info->detail)
    {
        goto Discard;
    }

    if (lkp_egressXcOamKeyType0 || lkp_egressXcOamKeyType1 || lkp_egressXcOamKeyType2)
    {

        CTC_DKIT_PRINT("OAM Process:\n");

        for (i = 0; i < 3; i++)
        {
            if (key_type[i])
            {
                CTC_DKIT_PATH_PRINT("%s%d %s\n", "hash",i,lookup_result[key_type[i] - EGRESSXCOAMHASHTYPE_ETH]);
                if (hash_valid[i])
                {
                    if (confict[i])
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_CONFLICT);
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", key_index[i]);
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", key_name[key_type[i] - EGRESSXCOAMHASHTYPE_ETH]);
                    }
                    else if (hash_resultValid[i])
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_HASH_HIT);
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "key index", key_index[i]);
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "key name", key_name[key_type[i] - EGRESSXCOAMHASHTYPE_ETH]);
                    }
                    else
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "result", CTC_DKIT_CAPTURED_NOT_HIT);
                    }
                }
            }
        }
    }

    if (oam_valid)
    {
        if (hash0_resultValid || hash1_resultValid || hash2_resultValid)
        {

            if (oam_mepEn)
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "hit MEP", "YES");
                CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "mep index", oam_mepIndex);
                CTC_DKIT_PATH_PRINT("%-15s:%d\n", "Master chip id", oam_oamDestChipId);
            }
            if (oam_mipEn)
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "hit MIP", "YES");
                CTC_DKIT_PATH_PRINT("%-15s:%d\n", "Master chip id", oam_oamDestChipId);
            }
            if (oam_tempRxOamType)
            {
                char* oam_type[RXOAMTYPE_TRILLBFD] =
                {
                    "ETHER OAM", "IP BFD", "PBT OAM", "PBBBSI", "PBBBV",
                                                                                      "MPLS OAM", "MPLS BFD", "ACH OAM", "RSV", "TRILL BFD"};
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "OAM type", oam_type[oam_tempRxOamType - 1]);
                }
                if (oam_mplsLmValid || oam_etherLmValid)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s 0x%x\n", "read LM from", "DsOamLmStats", oam_lmStatsIndex);
                }
                if (oam_lmStatsEn0)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s 0x%x\n", "write LM to", "DsOamLmStats", oam_lmStatsPtr0);
                }
                if (oam_lmStatsEn1)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s 0x%x\n", "write LM to", "DsOamLmStats", oam_lmStatsPtr1);
                }
                if (oam_lmStatsEn2)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s 0x%x\n", "write LM to", "DsOamLmStats", oam_lmStatsPtr2);
                }
            }
        }

    if ((hdr_valid) && (SHARETYPE_OAM == hdr_shareType))
    {
        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "destination", "OAM engine");
    }

Discard:

    return CLI_SUCCESS;
}
static int32
_ctc_goldengate_dkit_captured_path_epe_edit(ctc_dkit_captured_path_info_t* p_info)
{
    uint8 slice = p_info->slice_epe;
    uint8 lchip = p_info->lchip;
    uint32 cmd = 0;
    uint32 value = 0;
    uint32 next_edit_ptr = 0;
    uint32 next_edit_type = 0;
    uint32 dsNextHopInternalBase = 0;
    uint32 nhpShareType = 0;
    uint32 discard = 0;
    uint32 discard_type = 0;
    uint8 do_l2_edit = 0;
    uint32 l2_edit_ptr = 0;
    uint8 l2_individual_memory = 0;
    uint32 dest_map = 0;
    uint8 no_l3_edit = 1;
    uint8 no_l2_edit = 1;
    uint32 nhpOuterEditPtrType = 0;

    hw_mac_addr_t hw_mac = {0};
    mac_addr_t mac_da = {0};
    DsNextHop8W_m ds_next_hop8_w;
    DsNextHop4W_m ds_next_hop4_w;
    DsL2EditEth3W_m ds_l2_edit_eth3_w;
    DsL3EditMpls3W_m ds_l3_edit_mpls3_w;
    DsL2Edit6WOuter_m ds_l2_edit6_w_outer;
    DsL2EditSwap_m ds_l2_edit_swap;
    DsL2EditInnerSwap_m ds_l2_edit_inner_swap;
    char* l3_edit[12] =
    {
        "NONE edit--->",
        "MPLS edit--->",
        "RESERVED edit--->",
        "NAT edit--->",
        "NAT edit--->",
        "TUNNELV4 edit--->",
        "TUNNELV6 edit--->",
        "L3FLEX edit--->",
        "OPEN FLOW edit--->",
        "OPEN FLOW edit--->",
        "LOOPBACK edit--->",
        "TRILL edit--->"
    };
    char* l3_edit_name[12] =
    {
        " ",
        "DsL3EditMpls3W",
        " ",
        "DsL3EditNat3W",
        "DsL3EditNat6W",
        "DsL3EditTunnelV4",
        "DsL3EditTunnelV6",
        "DsL3EditFlex",
        "DsL3EditOf6W",
        "DsL3EditOf12W",
        "DsL3EditLoopback",
        "DsL3EditTrill"
    };
    char* vlan_action[4] = {"None", "Replace", "Add","Delete"};

    /*DbgEpeHdrAdjInfo*/
    uint32 adj_channelId = 0;
    uint32 adj_packetHeaderEn = 0;
    uint32 adj_packetHeaderEnEgress = 0;
    uint32 adj_bypassAll = 0;
    uint32 adj_discard = 0;
    uint32 adj_discardType = 0;
    uint32 adj_microBurstValid = 0;
    uint32 adj_isSendtoCpuEn = 0;
    uint32 adj_packetLengthIsTrue = 0;
    uint32 adj_localPhyPort = 0;
    uint32 adj_nextHopPtr = 0;
    uint32 adj_parserOffset = 0;
    uint32 adj_packetLengthAdjustType = 0;
    uint32 adj_packetLengthAdjust = 0;
    uint32 adj_sTagAction = 0;
    uint32 adj_cTagAction = 0;
    uint32 adj_packetOffset = 0;
    uint32 adj_aclDscp = 0;
    uint32 adj_newIpChecksum = 0;
    uint32 adj_isidValid = 0;
    uint32 adj_muxLengthType = 0;
    uint32 adj_cvlanTagOperationValid = 0;
    uint32 adj_svlanTagOperationValid = 0;
    uint32 adj_debugOpType = 0;
    uint32 adj_valid = 0;
    DbgEpeHdrAdjInfo_m dbg_epe_hdr_adj_info;
    /*DbgEpeNextHopInfo*/
    uint32 nhp_discard = 0;
    uint32 nhp_discardType = 0;
    uint32 nhp_payloadOperation = 0;
    uint32 nhp_editBypass = 0;
    uint32 nhp_innerEditHashEn = 0;
    uint32 nhp_outerEditHashEn = 0;
    uint32 nhp_etherOamDiscard = 0;
    uint32 nhp_isVxlanRouteOp = 0;
    uint32 nhp_exceptionEn = 0;
    uint32 nhp_exceptionIndex = 0;
    uint32 nhp_portReflectiveDiscard = 0;
    uint32 nhp_interfaceId = 0;
    uint32 nhp_destVlanPtr = 0;
    uint32 nhp_mcast = 0;
    uint32 nhp_routeNoL2Edit = 0;
    uint32 nhp_outputSvlanIdValid = 0;
    uint32 nhp_outputSvlanId = 0;
    uint32 nhp_logicDestPort = 0;
    uint32 nhp_outputCvlanIdValid = 0;
    uint32 nhp_outputCvlanId = 0;
    uint32 nhp__priority = 0;
    uint32 nhp_color = 0;
    uint32 nhp_l3EditDisable = 0;
    uint32 nhp_l2EditDisable = 0;
    uint32 nhp_isEnd = 0;
    uint32 nhp_bypassAll = 0;
    uint32 nhp_nhpIs8w = 0;
    uint32 nhp_portIsolateValid = 0;
    uint32 nhp_lookup1Valid = 0;
    uint32 nhp_vlanHash1Type = 0;
    uint32 nhp_lookup2Valid = 0;
    uint32 nhp_vlanHash2Type = 0;
    uint32 nhp_vlanXlateResult1Valid = 0;
    uint32 nhp_vlanXlateResult2Valid = 0;
    uint32 nhp_hashPort = 0;
    uint32 nhp_isLabel = 0;
    uint32 nhp_svlanId = 0;
    uint32 nhp_stagCos = 0;
    uint32 nhp_cvlanId = 0;
    uint32 nhp_ctagCos = 0;
    uint32 nhp_vlanXlateVlanRangeValid = 0;
    uint32 nhp_vlanXlateVlanRangeMax = 0;
    uint32 nhp_aclVlanRangeValid = 0;
    uint32 nhp_aclVlanRangeMax = 0;
    uint32 nhp_innerEditPtrOffset = 0;
    uint32 nhp_outerEditPtrOffset = 0;
    uint32 nhp_valid = 0;
    uint32 nhp_innerEditPtr = 0;
    uint32 nhp_outerEditPtr = 0;
    DbgEpeNextHopInfo_m dbg_epe_next_hop_info;
    /*DbgEpePayLoadInfo*/
    uint32 pld_discard = 0;
    uint32 pld_discardType = 0;
    uint32 pld_exceptionEn = 0;
    uint32 pld_exceptionIndex = 0;
    //uint32 pld_shareType = 0;
    //uint32 pld_fid = 0;
    uint32 pld_payloadOperation = 0;
    uint32 pld_newTtlValid = 0;
    uint32 pld_newTtl = 0;
    uint32 pld_newDscpValid = 0;
    //uint32 pld_replaceDscp = 0;
    //uint32 pld_useOamTtlOrExp = 0;
    //uint32 pld_copyDscp = 0;
    uint32 pld_newDscp = 0;
    uint32 pld_svlanTagOperation = 0;
    uint32 pld_l2NewSvlanTag = 0;
    uint32 pld_cvlanTagOperation = 0;
    uint32 pld_l2NewCvlanTag = 0;
    uint32 pld_stripOffset = 0;
    //uint32 pld_mirroredPacket = 0;
    //uint32 pld_isL2Ptp = 0;
    //uint32 pld_isL4Ptp = 0;
    uint32 pld_valid = 0;
    DbgEpePayLoadInfo_m dbg_epe_pay_load_info;
    /*DbgEpeEgressEditInfo*/
    uint32 edit_discard = 0;
    uint32 edit_discardType = 0;
    uint32 edit_nhpOuterEditLocation = 0;
    uint32 edit_innerEditExist = 0;
    uint32 edit_innerEditPtrType = 0;
    uint32 edit_outerEditPipe1Exist = 0;
    uint32 edit_outerEditPipe1Type = 0;
    uint32 edit_outerEditPipe2Exist = 0;
    uint32 edit_outerEditPipe3Exist = 0;
    uint32 edit_outerEditPipe3Type = 0;
    uint32 edit_l3RewriteType = 0;
    uint32 edit_l3EditMplsPwExist = 0;
    uint32 edit_l3EditMplsLspExist = 0;
    uint32 edit_l3EditMplsSpmeExist = 0;
    uint32 edit_innerL2RewriteType = 0;
    uint32 edit_l2RewriteType = 0;
    uint32 edit_valid = 0;
    DbgEpeEgressEditInfo_m dbg_epe_egress_edit_info;
    /*DbgEpeInnerL2EditInfo*/
    uint32 innerL2_valid = 0;
    uint32 innerL2_isInnerL2EthSwapOp = 0;
    uint32 innerL2_isInnerL2EthAddOp = 0;
    uint32 innerL2_isInnerDsLiteOp = 0;
    DbgEpeInnerL2EditInfo_m dbg_epe_inner_l2_edit_info;
    /*DbgEpeOuterL2EditInfo*/
    uint32 l2edit_l2EditDisable = 0;
    uint32 l2edit_routeNoL2Edit = 0;
    uint32 l2edit_destMuxPortType = 0;
    uint32 l2edit_newMacSaValid = 0;
    uint32 l2edit_newMacDaValid = 0;
    uint32 l2edit_portMacSaEn = 0;
    uint32 l2edit_loopbackEn = 0;
    uint32 l2edit_svlanTagOperation = 0;
    uint32 l2edit_cvlanTagOperation = 0;
    uint32 l2edit_l2RewriteType = 0;
    uint32 l2edit_isEnd = 0;
    uint32 l2edit_len = 0;
    uint32 l2edit_valid = 0;
    DbgEpeOuterL2EditInfo_m dbg_epe_outer_l2_edit_info;
    /*DbgEpeL3EditInfo*/
    uint32 l3edit_l3EditDisable = 0;
    uint32 l3edit_loopbackEn = 0;
    uint32 l3edit_l3RewriteType = 0;
    uint32 l3edit_label0Valid = 0;
    uint32 l3edit_label1Valid = 0;
    uint32 l3edit_label2Valid = 0;
    uint32 l3edit_isLspLabelEntropy0 = 0;
    uint32 l3edit_isLspLabelEntropy1 = 0;
    uint32 l3edit_isLspLabelEntropy2 = 0;
    uint32 l3edit_isPwLabelEntropy0 = 0;
    uint32 l3edit_isPwLabelEntropy1 = 0;
    uint32 l3edit_isPwLabelEntropy2 = 0;
    uint32 l3edit_cwLabelValid = 0;
    uint32 l3edit_needDot1aeEncrypt = 0;
    uint32 l3edit_dot1aeSaIndex = 0;
    uint32 l3edit_dot1aeSaIndexBase = 0;
    uint32 l3edit_isEnd = 0;
    uint32 l3edit_valid = 0;
    DbgEpeL3EditInfo_m dbg_epe_l3_edit_info;

    /*Dot1AE*/
    uint8  step = 0;
    uint32 dot1ae_sci_en = 0;
    uint32 dot1ae_current_an = 0;
    uint32 dot1ae_next_an = 0;
    uint32 dot1ae_pn = 0;
    uint32 dot1ae_pn_thrd = 0;
    uint32 dot1ae_ebit_cbit[4] = {0};

    /*DbgEpeHdrEditInfo*/
    uint32 hdr_valid = 0;
    uint32 hdr_stripOffset = 0;

    cmd = DRV_IOR(DbgEpeHdrEditInfo_t, DbgEpeHdrEditInfo_epeHdrEditInfoValid_f);
    DRV_IOCTL(lchip, slice, cmd, &hdr_valid);
    cmd = DRV_IOR(DbgEpeHdrEditInfo_t, DbgEpeHdrEditInfo_epeHdrEditInfoStripOffset_f);
    DRV_IOCTL(lchip, slice, cmd, &hdr_stripOffset);

    sal_memset(&ds_next_hop8_w, 0, sizeof(ds_next_hop8_w));
    sal_memset(&ds_next_hop4_w, 0, sizeof(ds_next_hop4_w));
    sal_memset(&ds_l2_edit_eth3_w, 0, sizeof(ds_l2_edit_eth3_w));
    sal_memset(&ds_l3_edit_mpls3_w, 0, sizeof(ds_l3_edit_mpls3_w));
    sal_memset(&ds_l2_edit6_w_outer, 0, sizeof(ds_l2_edit6_w_outer));
    sal_memset(&ds_l2_edit_swap, 0, sizeof(ds_l2_edit_swap));
    sal_memset(&ds_l2_edit_inner_swap, 0, sizeof(ds_l2_edit_inner_swap));
    /*DbgEpeHdrAdjInfo*/
    sal_memset(&dbg_epe_hdr_adj_info, 0, sizeof(dbg_epe_hdr_adj_info));
    cmd = DRV_IOR(DbgEpeHdrAdjInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_epe_hdr_adj_info);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoChannelId_f, &dbg_epe_hdr_adj_info, &adj_channelId);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoPacketHeaderEn_f, &dbg_epe_hdr_adj_info, &adj_packetHeaderEn);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoPacketHeaderEnEgress_f, &dbg_epe_hdr_adj_info, &adj_packetHeaderEnEgress);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoBypassAll_f, &dbg_epe_hdr_adj_info, &adj_bypassAll);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoDiscard_f, &dbg_epe_hdr_adj_info, &adj_discard);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoDiscardType_f, &dbg_epe_hdr_adj_info, &adj_discardType);
   // GetDbgEpeHdrAdjInfo(A, microBurstValid_f, &dbg_epe_hdr_adj_info, &adj_microBurstValid);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoIsSendtoCpuEn_f, &dbg_epe_hdr_adj_info, &adj_isSendtoCpuEn);
   // GetDbgEpeHdrAdjInfo(A, packetLengthIsTrue_f, &dbg_epe_hdr_adj_info, &adj_packetLengthIsTrue);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoLocalPhyPort_f, &dbg_epe_hdr_adj_info, &adj_localPhyPort);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoNextHopPtr_f, &dbg_epe_hdr_adj_info, &adj_nextHopPtr);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoParserOffset_f, &dbg_epe_hdr_adj_info, &adj_parserOffset);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoPacketLengthAdjustType_f, &dbg_epe_hdr_adj_info, &adj_packetLengthAdjustType);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoPacketLengthAdjust_f, &dbg_epe_hdr_adj_info, &adj_packetLengthAdjust);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoSTagAction_f, &dbg_epe_hdr_adj_info, &adj_sTagAction);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoCTagAction_f, &dbg_epe_hdr_adj_info, &adj_cTagAction);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoPacketOffset_f, &dbg_epe_hdr_adj_info, &adj_packetOffset);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoIsidValid_f, &dbg_epe_hdr_adj_info, &adj_isidValid);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoMuxLengthType_f, &dbg_epe_hdr_adj_info, &adj_muxLengthType);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoCvlanTagOperationValid_f, &dbg_epe_hdr_adj_info, &adj_cvlanTagOperationValid);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoSvlanTagOperationValid_f, &dbg_epe_hdr_adj_info, &adj_svlanTagOperationValid);
    //GetDbgEpeHdrAdjInfo(A, debugOpType_f, &dbg_epe_hdr_adj_info, &adj_debugOpType);
    GetDbgEpeHdrAdjInfo(A, epeHdrAdjInfoValid_f, &dbg_epe_hdr_adj_info, &adj_valid);
    /*DbgEpeNextHopInfo*/
    sal_memset(&dbg_epe_next_hop_info, 0, sizeof(dbg_epe_next_hop_info));
    cmd = DRV_IOR(DbgEpeNextHopInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_epe_next_hop_info);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoDiscard_f, &dbg_epe_next_hop_info, &nhp_discard);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoDiscardType_f, &dbg_epe_next_hop_info, &nhp_discardType);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoPayloadOperation_f, &dbg_epe_next_hop_info, &nhp_payloadOperation);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoEditBypass_f, &dbg_epe_next_hop_info, &nhp_editBypass);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoInnerEditHashEn_f, &dbg_epe_next_hop_info, &nhp_innerEditHashEn);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoOuterEditHashEn_f, &dbg_epe_next_hop_info, &nhp_outerEditHashEn);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoEtherOamDiscard_f, &dbg_epe_next_hop_info, &nhp_etherOamDiscard);
    //GetDbgEpeNextHopInfo(A, isVxlanRouteOp_f, &dbg_epe_next_hop_info, &nhp_isVxlanRouteOp);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoExceptionEn_f, &dbg_epe_next_hop_info, &nhp_exceptionEn);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoExceptionIndex_f, &dbg_epe_next_hop_info, &nhp_exceptionIndex);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoPortReflectiveDiscard_f, &dbg_epe_next_hop_info, &nhp_portReflectiveDiscard);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoInterfaceId_f, &dbg_epe_next_hop_info, &nhp_interfaceId);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoDestVlanPtr_f, &dbg_epe_next_hop_info, &nhp_destVlanPtr);
    //GetDbgEpeNextHopInfo(A, mcast_f, &dbg_epe_next_hop_info, &nhp_mcast);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoRouteNoL2Edit_f, &dbg_epe_next_hop_info, &nhp_routeNoL2Edit);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoOutputSvlanIdValid_f, &dbg_epe_next_hop_info, &nhp_outputSvlanIdValid);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoOutputSvlanId_f, &dbg_epe_next_hop_info, &nhp_outputSvlanId);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoLogicDestPort_f, &dbg_epe_next_hop_info, &nhp_logicDestPort);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoOutputCvlanIdValid_f, &dbg_epe_next_hop_info, &nhp_outputCvlanIdValid);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoOutputCvlanId_f, &dbg_epe_next_hop_info, &nhp_outputCvlanId);
    //GetDbgEpeNextHopInfo(A, _priority_f, &dbg_epe_next_hop_info, &nhp__priority);
    //GetDbgEpeNextHopInfo(A, color_f, &dbg_epe_next_hop_info, &nhp_color);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoL3EditDisable_f, &dbg_epe_next_hop_info, &nhp_l3EditDisable);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoL2EditDisable_f, &dbg_epe_next_hop_info, &nhp_l2EditDisable);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoIsEnd_f, &dbg_epe_next_hop_info, &nhp_isEnd);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoBypassAll_f, &dbg_epe_next_hop_info, &nhp_bypassAll);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoNhpIs8w_f, &dbg_epe_next_hop_info, &nhp_nhpIs8w);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoPortIsolateValid_f, &dbg_epe_next_hop_info, &nhp_portIsolateValid);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoLookup1Valid_f, &dbg_epe_next_hop_info, &nhp_lookup1Valid);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoVlanHash1Type_f, &dbg_epe_next_hop_info, &nhp_vlanHash1Type);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoLookup2Valid_f, &dbg_epe_next_hop_info, &nhp_lookup2Valid);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoVlanHash2Type_f, &dbg_epe_next_hop_info, &nhp_vlanHash2Type);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoVlanXlateResult1Valid_f, &dbg_epe_next_hop_info, &nhp_vlanXlateResult1Valid);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoVlanXlateResult2Valid_f, &dbg_epe_next_hop_info, &nhp_vlanXlateResult2Valid);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoHashPort_f, &dbg_epe_next_hop_info, &nhp_hashPort);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoInnerEditPtrOffset_f, &dbg_epe_next_hop_info, &nhp_innerEditPtrOffset);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoOuterEditPtrOffset_f, &dbg_epe_next_hop_info, &nhp_outerEditPtrOffset);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoValid_f, &dbg_epe_next_hop_info, &nhp_valid);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoPayloadOperation_f, &dbg_epe_next_hop_info, &pld_payloadOperation);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoNhpInnerEditPtr_f, &dbg_epe_next_hop_info, &nhp_innerEditPtr);
    GetDbgEpeNextHopInfo(A, epeNextHopInfoPayloadOperation_f, &dbg_epe_next_hop_info, &nhp_outerEditPtr);
    /*DbgEpePayLoadInfo*/
    sal_memset(&dbg_epe_pay_load_info, 0, sizeof(dbg_epe_pay_load_info));
    cmd = DRV_IOR(DbgEpePayLoadInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_epe_pay_load_info);
    GetDbgEpePayLoadInfo(A, epePayLoadInfoDiscard_f, &dbg_epe_pay_load_info, &pld_discard);
    GetDbgEpePayLoadInfo(A, epePayLoadInfoDiscardType_f, &dbg_epe_pay_load_info, &pld_discardType);
    GetDbgEpePayLoadInfo(A, epePayLoadInfoExceptionEn_f, &dbg_epe_pay_load_info, &pld_exceptionEn);
    GetDbgEpePayLoadInfo(A, epePayLoadInfoExceptionIndex_f, &dbg_epe_pay_load_info, &pld_exceptionIndex);
    //GetDbgEpePayLoadInfo(A, shareType_f, &dbg_epe_pay_load_info, &pld_shareType);
    //GetDbgEpePayLoadInfo(A, fid_f, &dbg_epe_pay_load_info, &pld_fid);

    GetDbgEpePayLoadInfo(A, epePayLoadInfoNewTtlValid_f, &dbg_epe_pay_load_info, &pld_newTtlValid);
    GetDbgEpePayLoadInfo(A, epePayLoadInfoNewTtl_f, &dbg_epe_pay_load_info, &pld_newTtl);
    GetDbgEpePayLoadInfo(A, epePayLoadInfoNewDscpValid_f, &dbg_epe_pay_load_info, &pld_newDscpValid);
    //GetDbgEpePayLoadInfo(A, replaceDscp_f, &dbg_epe_pay_load_info, &pld_replaceDscp);
    //GetDbgEpePayLoadInfo(A, useOamTtlOrExp_f, &dbg_epe_pay_load_info, &pld_useOamTtlOrExp);
    //GetDbgEpePayLoadInfo(A, copyDscp_f, &dbg_epe_pay_load_info, &pld_copyDscp);
    //<zhaozc>GetDbgEpePayLoadInfo(A, newDscp_f, &dbg_epe_pay_load_info, &pld_newDscp);
    GetDbgEpePayLoadInfo(A, epePayLoadInfoSvlanTagOperation_f, &dbg_epe_pay_load_info, &pld_svlanTagOperation);
    GetDbgEpePayLoadInfo(A, epePayLoadInfoL2NewSvlanTag_f, &dbg_epe_pay_load_info, &pld_l2NewSvlanTag);
    GetDbgEpePayLoadInfo(A, epePayLoadInfoCvlanTagOperation_f, &dbg_epe_pay_load_info, &pld_cvlanTagOperation);
    GetDbgEpePayLoadInfo(A, epePayLoadInfoL2NewCvlanTag_f, &dbg_epe_pay_load_info, &pld_l2NewCvlanTag);
    GetDbgEpePayLoadInfo(A, epePayLoadInfoStripOffset_f, &dbg_epe_pay_load_info, &pld_stripOffset);
    //GetDbgEpePayLoadInfo(A, mirroredPacket_f, &dbg_epe_pay_load_info, &pld_mirroredPacket);
    //GetDbgEpePayLoadInfo(A, isL2Ptp_f, &dbg_epe_pay_load_info, &pld_isL2Ptp);
    //GetDbgEpePayLoadInfo(A, isL4Ptp_f, &dbg_epe_pay_load_info, &pld_isL4Ptp);
    GetDbgEpePayLoadInfo(A, epePayLoadInfoValid_f, &dbg_epe_pay_load_info, &pld_valid);
    /*DbgEpeEgressEditInfo*/
    sal_memset(&dbg_epe_egress_edit_info, 0, sizeof(dbg_epe_egress_edit_info));
    cmd = DRV_IOR(DbgEpeEgressEditInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_epe_egress_edit_info);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoDiscard_f, &dbg_epe_egress_edit_info, &edit_discard);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoDiscardType_f, &dbg_epe_egress_edit_info, &edit_discardType);
    //<TBD zhaozc>GetDbgEpeEgressEditInfo(A, nhpOuterEditLocation_f, &dbg_epe_egress_edit_info, &edit_nhpOuterEditLocation);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoInnerEditExist_f, &dbg_epe_egress_edit_info, &edit_innerEditExist);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoInnerEditPtrType_f, &dbg_epe_egress_edit_info, &edit_innerEditPtrType);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoOuterEditPipe1Exist_f, &dbg_epe_egress_edit_info, &edit_outerEditPipe1Exist);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoOuterEditPipe1Type_f, &dbg_epe_egress_edit_info, &edit_outerEditPipe1Type);
    //GetDbgEpeEgressEditInfo(A, nhpOuterEditPtr_f, &dbg_epe_egress_edit_info, &nhp_outerEditPtr);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoOuterEditPipe2Exist_f, &dbg_epe_egress_edit_info, &edit_outerEditPipe2Exist);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoOuterEditPipe3Exist_f, &dbg_epe_egress_edit_info, &edit_outerEditPipe3Exist);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoOuterEditPipe3Type_f, &dbg_epe_egress_edit_info, &edit_outerEditPipe3Type);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoL3RewriteType_f, &dbg_epe_egress_edit_info, &edit_l3RewriteType);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoL3EditMplsPwExist_f, &dbg_epe_egress_edit_info, &edit_l3EditMplsPwExist);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoL3EditMplsLspExist_f, &dbg_epe_egress_edit_info, &edit_l3EditMplsLspExist);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoL3EditMplsSpmeExist_f, &dbg_epe_egress_edit_info, &edit_l3EditMplsSpmeExist);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoInnerL2RewriteType_f, &dbg_epe_egress_edit_info, &edit_innerL2RewriteType);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoL2RewriteType_f, &dbg_epe_egress_edit_info, &edit_l2RewriteType);
    GetDbgEpeEgressEditInfo(A, epeEgressEditInfoValid_f, &dbg_epe_egress_edit_info, &edit_valid);
    /*DbgEpeInnerL2EditInfo*/
    sal_memset(&dbg_epe_inner_l2_edit_info, 0, sizeof(dbg_epe_inner_l2_edit_info));
    cmd = DRV_IOR(DbgEpeInnerL2EditInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_epe_inner_l2_edit_info);
    GetDbgEpeInnerL2EditInfo(A, epeInnerL2EditInfoValid_f, &dbg_epe_inner_l2_edit_info, &innerL2_valid);
    GetDbgEpeInnerL2EditInfo(A, epeInnerL2EditInfoIsInnerL2EthSwapOp_f, &dbg_epe_inner_l2_edit_info, &innerL2_isInnerL2EthSwapOp);
    GetDbgEpeInnerL2EditInfo(A, epeInnerL2EditInfoIsInnerL2EthAddOp_f, &dbg_epe_inner_l2_edit_info, &innerL2_isInnerL2EthAddOp);
    GetDbgEpeInnerL2EditInfo(A, epeInnerL2EditInfoIsInnerDsLiteOp_f, &dbg_epe_inner_l2_edit_info, &innerL2_isInnerDsLiteOp);
    /*DbgEpeOuterL2EditInfo*/
    sal_memset(&dbg_epe_outer_l2_edit_info, 0, sizeof(dbg_epe_outer_l2_edit_info));
    cmd = DRV_IOR(DbgEpeOuterL2EditInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_epe_outer_l2_edit_info);
    GetDbgEpeOuterL2EditInfo(A, epeOuterL2EditInfoL2EditDisable_f, &dbg_epe_outer_l2_edit_info, &l2edit_l2EditDisable);
    GetDbgEpeOuterL2EditInfo(A, epeOuterL2EditInfoRouteNoL2Edit_f, &dbg_epe_outer_l2_edit_info, &l2edit_routeNoL2Edit);
    //GetDbgEpeOuterL2EditInfo(A, destMuxPortType_f, &dbg_epe_outer_l2_edit_info, &l2edit_destMuxPortType);
    GetDbgEpeOuterL2EditInfo(A, epeOuterL2EditInfoNewMacSaValid_f, &dbg_epe_outer_l2_edit_info, &l2edit_newMacSaValid);
    GetDbgEpeOuterL2EditInfo(A, epeOuterL2EditInfoNewMacDaValid_f, &dbg_epe_outer_l2_edit_info, &l2edit_newMacDaValid);
    //GetDbgEpeOuterL2EditInfo(A, portMacSaEn_f, &dbg_epe_outer_l2_edit_info, &l2edit_portMacSaEn);
    //GetDbgEpeOuterL2EditInfo(A, loopbackEn_f, &dbg_epe_outer_l2_edit_info, &l2edit_loopbackEn);
    GetDbgEpeOuterL2EditInfo(A, epeOuterL2EditInfoSvlanTagOperation_f, &dbg_epe_outer_l2_edit_info, &l2edit_svlanTagOperation);
    GetDbgEpeOuterL2EditInfo(A, epeOuterL2EditInfoCvlanTagOperation_f, &dbg_epe_outer_l2_edit_info, &l2edit_cvlanTagOperation);
    GetDbgEpeOuterL2EditInfo(A, epeOuterL2EditInfoL2RewriteType_f, &dbg_epe_outer_l2_edit_info, &l2edit_l2RewriteType);
    GetDbgEpeOuterL2EditInfo(A, epeOuterL2EditInfoIsEnd_f, &dbg_epe_outer_l2_edit_info, &l2edit_isEnd);
    //GetDbgEpeOuterL2EditInfo(A, len_f, &dbg_epe_outer_l2_edit_info, &l2edit_len);
    GetDbgEpeOuterL2EditInfo(A, epeOuterL2EditInfoValid_f, &dbg_epe_outer_l2_edit_info, &l2edit_valid);
    /*DbgEpeL3EditInfo*/
    sal_memset(&dbg_epe_l3_edit_info, 0, sizeof(dbg_epe_l3_edit_info));
    cmd = DRV_IOR(DbgEpeL3EditInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, slice, cmd, &dbg_epe_l3_edit_info);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoL3EditDisable_f, &dbg_epe_l3_edit_info, &l3edit_l3EditDisable);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoL3RewriteType_f, &dbg_epe_l3_edit_info, &l3edit_l3RewriteType);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoLabel0Valid_f, &dbg_epe_l3_edit_info, &l3edit_label0Valid);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoLabel1Valid_f, &dbg_epe_l3_edit_info, &l3edit_label1Valid);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoLabel2Valid_f, &dbg_epe_l3_edit_info, &l3edit_label2Valid);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoIsLspLabelEntropy0_f, &dbg_epe_l3_edit_info, &l3edit_isLspLabelEntropy0);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoIsLspLabelEntropy1_f, &dbg_epe_l3_edit_info, &l3edit_isLspLabelEntropy1);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoIsLspLabelEntropy2_f, &dbg_epe_l3_edit_info, &l3edit_isLspLabelEntropy2);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoIsPwLabelEntropy0_f, &dbg_epe_l3_edit_info, &l3edit_isPwLabelEntropy0);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoIsPwLabelEntropy1_f, &dbg_epe_l3_edit_info, &l3edit_isPwLabelEntropy1);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoIsPwLabelEntropy2_f, &dbg_epe_l3_edit_info, &l3edit_isPwLabelEntropy2);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoCwLabelValid_f, &dbg_epe_l3_edit_info, &l3edit_cwLabelValid);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoNeedDot1AeEncrypt_f, &dbg_epe_l3_edit_info, &l3edit_needDot1aeEncrypt);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoDot1AeSaIndexBase_f, &dbg_epe_l3_edit_info, &l3edit_dot1aeSaIndexBase);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoDot1AeSaIndex_f, &dbg_epe_l3_edit_info, &l3edit_dot1aeSaIndex);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoIsEnd_f, &dbg_epe_l3_edit_info, &l3edit_isEnd);
    GetDbgEpeL3EditInfo(A, epeL3EditInfoValid_f, &dbg_epe_l3_edit_info, &l3edit_valid);

    if (0 == p_info->detail)
    {
        goto Discard;
    }

    CTC_DKIT_PRINT("Edit Process:\n");
    if (hdr_valid&&hdr_stripOffset)
    {
        CTC_DKIT_PATH_PRINT("%-15s:%d bytes\n", "strip packet", hdr_stripOffset);
    }

    if (pld_valid)
    {

        CTC_DKIT_PATH_PRINT("%-15s:%d\n", "pld Operation", pld_payloadOperation);
        if (pld_svlanTagOperation || pld_cvlanTagOperation)
        {
            CTC_DKIT_PATH_PRINT("%-15s\n", "vlan edit on pld operation--->");
            no_l2_edit = 0;
            if (pld_svlanTagOperation)
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "svlan edit", vlan_action[pld_svlanTagOperation]);
                if ((VTAGACTIONTYPE_MODIFY == pld_svlanTagOperation) || (VTAGACTIONTYPE_ADD == pld_svlanTagOperation))
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new COS", (pld_l2NewSvlanTag >> 13)&0x7);
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new CFI", (pld_l2NewSvlanTag >> 12)&0x1);
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new vlan id", pld_l2NewSvlanTag&0xFFF);
                }
            }
            if (pld_cvlanTagOperation)
            {
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "cvlan edit", vlan_action[pld_cvlanTagOperation]);
                if ((VTAGACTIONTYPE_MODIFY == pld_cvlanTagOperation) || (VTAGACTIONTYPE_ADD == pld_cvlanTagOperation))
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new COS", (pld_l2NewCvlanTag >> 13)&0x7);
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new CFI", (pld_l2NewCvlanTag >> 12)&0x1);
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new vlan id", pld_l2NewCvlanTag&0xFFF);
                }
            }
        }
        if (pld_newTtlValid)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new TTL", pld_newTtl);
        }
        if (pld_newDscpValid)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new DSCP", pld_newDscp);
        }
    }

    cmd = DRV_IOR(EpeHdrAdjustCtl_t, EpeHdrAdjustCtl_dsNextHopInternalBase_f);
    DRV_IOCTL(lchip, 0, cmd, &dsNextHopInternalBase);

    if ((adj_nextHopPtr >> 4) != dsNextHopInternalBase)
    {
        cmd = DRV_IOR(DsNextHop8W_t, DRV_ENTRY_FLAG);
        DRV_IOCTL(lchip, (adj_nextHopPtr >> 1) << 1, cmd, &ds_next_hop8_w);

        if (!nhp_nhpIs8w)
        {
            if (IS_BIT_SET((adj_nextHopPtr), 0))
            {
                sal_memcpy((uint8*)&ds_next_hop4_w, (uint8*)&ds_next_hop8_w + sizeof(ds_next_hop4_w), sizeof(ds_next_hop4_w));
            }
            else
            {
                sal_memcpy((uint8*)&ds_next_hop4_w, (uint8*)&ds_next_hop8_w , sizeof(ds_next_hop4_w));
            }
        }
    }
    else
    {
        cmd = DRV_IOR(EpeNextHopInternal_t, DRV_ENTRY_FLAG);
        DRV_IOCTL(lchip, ((adj_nextHopPtr&0xF) >> 1), cmd, &ds_next_hop8_w);
        if (!nhp_nhpIs8w)
        {
            if (IS_BIT_SET((adj_nextHopPtr&0xF), 0))
            {
                sal_memcpy((uint8*)&ds_next_hop4_w, (uint8*)&ds_next_hop8_w + sizeof(ds_next_hop4_w), sizeof(ds_next_hop4_w));
            }
            else
            {
                sal_memcpy((uint8*)&ds_next_hop4_w, (uint8*)&ds_next_hop8_w , sizeof(ds_next_hop4_w));
            }
        }
    }

    if(l3edit_needDot1aeEncrypt)
    {
        step = EpeDot1AeAnCtl0_array_1_currentAn_f - EpeDot1AeAnCtl0_array_0_currentAn_f;
        cmd = DRV_IOR(EpeDot1AeAnCtl0_t, EpeDot1AeAnCtl0_array_0_currentAn_f + step * l3edit_dot1aeSaIndexBase);
        DRV_IOCTL(lchip, 0, cmd, &dot1ae_current_an);
        step = EpeDot1AeAnCtl1_array_1_nextAn_f - EpeDot1AeAnCtl1_array_0_nextAn_f;
        cmd = DRV_IOR(EpeDot1AeAnCtl1_t, EpeDot1AeAnCtl1_array_0_nextAn_f + step * l3edit_dot1aeSaIndexBase);
        DRV_IOCTL(lchip, 0, cmd, &dot1ae_next_an);
        cmd = DRV_IOR(DsDestPort_t, DsDestPort_dot1AeSciEn_f);
        DRV_IOCTL(lchip, adj_localPhyPort, cmd, &dot1ae_sci_en);
        cmd = DRV_IOR(DsEgressDot1AePn_t, DsEgressDot1AePn_pn_f);
        DRV_IOCTL(lchip, l3edit_dot1aeSaIndex, cmd, &dot1ae_pn);
        cmd = DRV_IOR(EpePktProcCtl_t, EpePktProcCtl_dot1AePnThreshold_f);
        DRV_IOCTL(lchip, 0, cmd, &dot1ae_pn_thrd);
        cmd = DRV_IOR(EpePktProcCtl_t, EpePktProcCtl_dot1AeTciEbitCbit_f);
        DRV_IOCTL(lchip, 0, cmd, &dot1ae_ebit_cbit);
        CTC_DKIT_PATH_PRINT("%-15s\n", "Dot1AE Edit--->");
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Current AN", dot1ae_current_an);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Next AN", dot1ae_next_an);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Current PN", dot1ae_pn - 1);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "PN Threhold", dot1ae_pn_thrd);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Tx SCI En", dot1ae_sci_en);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Ebit Cbit",
                            CTC_DKIT_IS_BIT_SET(dot1ae_ebit_cbit[l3edit_dot1aeSaIndex/32], l3edit_dot1aeSaIndex%32));
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "SA Index Base", l3edit_dot1aeSaIndexBase);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "SA Index", l3edit_dot1aeSaIndex);
    }

    if (nhp_nhpIs8w)
    {
        GetDsNextHop8W(A, shareType_f, &ds_next_hop8_w, &nhpShareType);
    }
    else
    {
        GetDsNextHop4W(A, shareType_f, &ds_next_hop4_w, &nhpShareType);
    }

    if ((PAYLOADOPERATION_ROUTE_COMPACT == pld_payloadOperation)
        ||((PAYLOADOPERATION_NONE == pld_payloadOperation)&&nhp_routeNoL2Edit))
    {
        cmd = DRV_IOR( DbgFwdMetFifoInfo1_t,  DbgFwdMetFifoInfo1_fwdMetFifoInfo1DestMap_f);
        DRV_IOCTL(lchip, 0, cmd, &dest_map);
        if (!IS_BIT_SET(dest_map,19))
        {
            GetDsNextHop4W(A, u1_g3_macDa_f, &ds_next_hop4_w, hw_mac);
            CTC_DKIT_SET_USER_MAC(mac_da, hw_mac);
            if (IS_BIT_SET(mac_da[0], 0))/* mcast mode */
            {

            }
            else
            {
                CTC_DKIT_PATH_PRINT("%-15s\n", "MAC edit--->");
                CTC_DKIT_PATH_PRINT("%-15s:%02X%02X.%02X%02X.%02X%02X\n", "new MAC DA",
                                    mac_da[0], mac_da[1], mac_da[2], mac_da[3], mac_da[4], mac_da[5]);
            }
            no_l2_edit = 0;
        }
    }
    else if ((NHPSHARETYPE_L2EDIT_PLUS_L3EDIT_OP == nhpShareType) || (nhp_nhpIs8w))
    {
        if (nhp_nhpIs8w)
        {
            GetDsNextHop8W(A, outerEditPtrType_f, &ds_next_hop8_w, &nhpOuterEditPtrType);
        }
        else
        {
            GetDsNextHop4W(A, u1_g1_outerEditPtrType_f, &ds_next_hop4_w, &nhpOuterEditPtrType);
        }
        /*inner edit*/
        if (edit_valid && edit_innerEditExist && (!edit_innerEditPtrType))/* inner for l2edit */
        {
            if (innerL2_valid)
            {
                CTC_DKIT_PATH_PRINT("%-15s\n", "Inner MAC edit--->");
                CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "l2edit index", nhp_innerEditPtr);
                if (innerL2_isInnerL2EthSwapOp)
                {
                    uint32 replaceInnerMacDa;
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", "DsL2EditInnerSwap");
                    cmd = DRV_IOR(DsL2EditInnerSwap_t, DRV_ENTRY_FLAG);
                    DRV_IOCTL(lchip, nhp_innerEditPtr, cmd, &ds_l2_edit_inner_swap);
                    GetDsL2EditInnerSwap(A, replaceInnerMacDa_f, &ds_l2_edit_inner_swap, &replaceInnerMacDa);
                    if (replaceInnerMacDa)
                    {
                        GetDsL2EditInnerSwap(A, macDa_f, &ds_l2_edit_inner_swap, hw_mac);
                        CTC_DKIT_SET_USER_MAC(mac_da, hw_mac);
                        CTC_DKIT_PATH_PRINT("%-15s:%02X%02X.%02X%02X.%02X%02X\n", "new MAC DA",
                                            mac_da[0], mac_da[1], mac_da[2], mac_da[3], mac_da[4], mac_da[5]);
                    }
                }
                else if (innerL2_isInnerL2EthAddOp)
                {
                    if (L2REWRITETYPE_ETH8W == edit_innerL2RewriteType)
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", "DsL2EditEth6W");
                    }
                    else if (L2REWRITETYPE_ETH4W == edit_innerL2RewriteType)
                    {
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", "DsL2EditEth3W");
                    }
                }
                else if (innerL2_isInnerDsLiteOp)
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", "DsL2EditDsLite");
                }
            }
            else if (l2edit_valid)
            {
                do_l2_edit = 1;
                l2_edit_ptr = nhp_innerEditPtr;
                l2_individual_memory = 0;
            }
            no_l2_edit = 0;
        }
        else if (edit_valid && edit_innerEditExist && (edit_innerEditPtrType))/* inner for l3edit */
        {
            if (l3edit_valid)
            {
                if (L3REWRITETYPE_MPLS4W == l3edit_l3RewriteType)
                {
                    cmd = DRV_IOR(DsL3EditMpls3W_t, DRV_ENTRY_FLAG);
                    DRV_IOCTL(lchip, nhp_innerEditPtr, cmd, &ds_l3_edit_mpls3_w);
                    GetDsL3EditMpls3W(A, label_f, &ds_l3_edit_mpls3_w, &value);
                    CTC_DKIT_PATH_PRINT("%-15s\n", "MPLS edit--->");
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "l3edit index", nhp_innerEditPtr);
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", "DsL3EditMpls3W");
                    CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new label", value);
                    no_l3_edit = 0;
                }
                else if (L3REWRITETYPE_NONE != l3edit_l3RewriteType)
                {
                    CTC_DKIT_PATH_PRINT("%-15s\n", l3_edit[l3edit_l3RewriteType]);
                    CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "l3edit index", nhp_innerEditPtr);
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", l3_edit_name[l3edit_l3RewriteType]);
                    no_l3_edit = 0;
                }
            }
        }

        /*outer pipeline1*/
        if (edit_valid && edit_outerEditPipe1Exist)
        {
            if (l3edit_valid && nhpOuterEditPtrType)/* l3edit */
            {
                if (edit_nhpOuterEditLocation)/* individual memory */
                {
                    /* no use */
                }
                else/* share memory */
                {
                    cmd = DRV_IOR(DsL3EditMpls3W_t, DRV_ENTRY_FLAG);
                    DRV_IOCTL(lchip, nhp_outerEditPtr, cmd, &ds_l3_edit_mpls3_w);
                    /* outerEditPtr and outerEditPtrType are in the same position in all l3edit, refer to DsL3Edit3WTemplate  */
                    GetDsL3EditMpls3W(A, outerEditPtr_f, &ds_l3_edit_mpls3_w, &next_edit_ptr);
                    GetDsL3EditMpls3W(A, outerEditPtrType_f, &ds_l3_edit_mpls3_w, &next_edit_type);
                    if (L3REWRITETYPE_MPLS4W == l3edit_l3RewriteType)
                    {
                        GetDsL3EditMpls3W(A, label_f, &ds_l3_edit_mpls3_w, &value);
                        CTC_DKIT_PATH_PRINT("%-15s\n", "MPLS edit--->");
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "l3edit index", nhp_outerEditPtr);
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", "DsL3EditMpls3W");
                        CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new label", value);
                        no_l3_edit = 0;
                    }
                    else if (L3REWRITETYPE_NONE != l3edit_l3RewriteType)
                    {
                        CTC_DKIT_PATH_PRINT("%-15s\n", l3_edit[l3edit_l3RewriteType]);
                        CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "l3edit index", nhp_outerEditPtr);
                        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", l3_edit_name[l3edit_l3RewriteType]);
                        no_l3_edit = 0;
                    }
                }
            }
            else if (l2edit_valid)/* l2edit */
            {
                do_l2_edit = 1;
                l2_edit_ptr = nhp_outerEditPtr;
                l2_individual_memory = edit_nhpOuterEditLocation? 1 : 0;
            }
        }
        /*outer pipeline2*/
        if (edit_valid && edit_outerEditPipe2Exist)/* outer pipeline2, individual memory for SPME */
        {
            if (l3edit_valid && next_edit_type)/* l3edit */
            {
                cmd = DRV_IOR(DsL3Edit3W3rd_t, DRV_ENTRY_FLAG);
                DRV_IOCTL(lchip, next_edit_ptr, cmd, &ds_l3_edit_mpls3_w);
                GetDsL3EditMpls3W(A, label_f, &ds_l3_edit_mpls3_w, &value);
                CTC_DKIT_PATH_PRINT("%-15s\n", "MPLS edit--->");
                CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "l3edit index", next_edit_ptr);
                CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", "DsL3Edit3W3rd");
                CTC_DKIT_PATH_PRINT("%-15s:%d\n", "new label", value);

                GetDsL3EditMpls3W(A, outerEditPtr_f, &ds_l3_edit_mpls3_w, &next_edit_ptr);
                GetDsL3EditMpls3W(A, outerEditPtrType_f, &ds_l3_edit_mpls3_w, &next_edit_type);
                no_l3_edit = 0;
            }
            else if (l2edit_valid)/* l2edit */
            {
                do_l2_edit = 1;
                if (!edit_outerEditPipe1Exist)
                {
                    l2_edit_ptr = nhp_outerEditPtr;
                }
                else
                {
                    l2_edit_ptr = next_edit_ptr;
                }
                l2_individual_memory = 1;
            }
        }
        /*outer pipeline3*/
        if (l2edit_valid && edit_valid && edit_outerEditPipe3Exist)/* outer pipeline3, individual memory for l2edit */
        {
            do_l2_edit = 1;
            if (!edit_outerEditPipe1Exist)
            {
                l2_edit_ptr = nhp_outerEditPtr;
            }
            else
            {
                l2_edit_ptr = next_edit_ptr;
            }
            l2_individual_memory = 1;
        }


    }
    else if (NHPSHARETYPE_L2EDIT_PLUS_STAG_OP == nhpShareType)
    {
        if (l2edit_valid)/* l2edit */
        {
            do_l2_edit = 1;
            l2_edit_ptr = nhp_outerEditPtr;
            l2_individual_memory = edit_nhpOuterEditLocation? 1 : 0;
        }
    }

    if (do_l2_edit)
    {
        if (l2_individual_memory)/* individual memory */
        {
            cmd = DRV_IOR(DsL2Edit6WOuter_t, DRV_ENTRY_FLAG);
            DRV_IOCTL(lchip, (l2_edit_ptr >> 1), cmd, &ds_l2_edit6_w_outer);
            if (L2REWRITETYPE_ETH4W == l2edit_l2RewriteType)
            {
                if (l2_edit_ptr % 2 == 0)
                {
                    sal_memcpy((uint8*)&ds_l2_edit_eth3_w, (uint8*)&ds_l2_edit6_w_outer, sizeof(ds_l2_edit_eth3_w));
                }
                else
                {
                    sal_memcpy((uint8*)&ds_l2_edit_eth3_w, (uint8*)&ds_l2_edit6_w_outer + sizeof(ds_l2_edit_eth3_w), sizeof(ds_l2_edit_eth3_w));
                }
            }
            else if (L2REWRITETYPE_MAC_SWAP == l2edit_l2RewriteType)
            {
                sal_memcpy((uint8*)&ds_l2_edit_swap, (uint8*)&ds_l2_edit6_w_outer, sizeof(ds_l2_edit_swap));
            }
        }
        else/* share memory */
        {
            if (L2REWRITETYPE_ETH4W == l2edit_l2RewriteType)
            {
                cmd = DRV_IOR(DsL2EditEth3W_t, DRV_ENTRY_FLAG);
                DRV_IOCTL(lchip, l2_edit_ptr, cmd, &ds_l2_edit_eth3_w);

            }
            else if (L2REWRITETYPE_MAC_SWAP == l2edit_l2RewriteType)
            {
                cmd = DRV_IOR(DsL2EditSwap_t, DRV_ENTRY_FLAG);
                DRV_IOCTL(lchip, l2_edit_ptr, cmd, &ds_l2_edit_swap);
            }
        }

        if (L2REWRITETYPE_ETH4W == l2edit_l2RewriteType)
        {
            GetDsL2EditEth3W(A, macDa_f, &ds_l2_edit_eth3_w, hw_mac);
            CTC_DKIT_SET_USER_MAC(mac_da, hw_mac);
            CTC_DKIT_PATH_PRINT("%-15s\n", "MAC edit--->");
            CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "l2edit index", l2_individual_memory?(l2_edit_ptr/2):l2_edit_ptr);
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", l2_individual_memory? "DsL2Edit6WOuter" : "DsL2EditEth3W");
            CTC_DKIT_PATH_PRINT("%-15s:%02X%02X.%02X%02X.%02X%02X\n", "new MAC DA",
                                mac_da[0], mac_da[1], mac_da[2], mac_da[3], mac_da[4], mac_da[5]);
            no_l2_edit = 0;
        }
        else if (L2REWRITETYPE_MAC_SWAP == l2edit_l2RewriteType)
        {
            uint32 deriveMcastMac;
            uint32 _type = 0;
            uint32 outputVlanIdValid = 0;
            uint32 overwriteEtherType = 0;
            GetDsL2EditSwap(A, deriveMcastMac_f, &ds_l2_edit_swap, &deriveMcastMac);
            GetDsL2EditSwap(A, _type_f, &ds_l2_edit_swap, &_type);
            GetDsL2EditSwap(A, outputVlanIdValid_f, &ds_l2_edit_swap, &outputVlanIdValid);
            GetDsL2EditSwap(A, overwriteEtherType_f, &ds_l2_edit_swap, &overwriteEtherType);

            CTC_DKIT_PATH_PRINT("%-15s\n", "MAC swap--->");
            CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "l2edit index", l2_individual_memory?(l2_edit_ptr/2):l2_edit_ptr);
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "table name", l2_individual_memory? "DsL2Edit6WOuter" : "DsL2EditSwap");
            if (deriveMcastMac)
            {
                if (_type)
                {
                    GetDsL2EditSwap(A, macDa_f, &ds_l2_edit_eth3_w, hw_mac);
                    CTC_DKIT_SET_USER_MAC(mac_da, hw_mac);
                    CTC_DKIT_PATH_PRINT("%-15s:%02X%02X.%02X%02X.%02X%02X\n", "new MAC DA",
                                        mac_da[0], mac_da[1], mac_da[2], mac_da[3], mac_da[4], mac_da[5]);
                }
                else
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "new MAC DA", "MAC SA of the packet");
                }
            }
            if (outputVlanIdValid)
            {
                if (overwriteEtherType)
                {
                    GetDsL2EditSwap(A, macSa_f, &ds_l2_edit_eth3_w, hw_mac);
                    CTC_DKIT_SET_USER_MAC(mac_da, hw_mac);
                    CTC_DKIT_PATH_PRINT("%-15s:%02X%02X.%02X%02X.%02X%02X\n", "new MAC SA",
                                        mac_da[0], mac_da[1], mac_da[2], mac_da[3], mac_da[4], mac_da[5]);
                }
                else
                {
                    CTC_DKIT_PATH_PRINT("%-15s:%s\n", "new MAC SA", "MAC DA of the packet");
                }
            }
            no_l2_edit = 0;
        }
        else if (L2REWRITETYPE_NONE != l2edit_l2RewriteType)
        {
            CTC_DKIT_PATH_PRINT("%-15s\n", "L2edit--->");
            CTC_DKIT_PATH_PRINT("%-15s:%d\n", "L2edit type", l2edit_l2RewriteType);
            CTC_DKIT_PATH_PRINT("%-15s:0x%x\n", "l2edit index", l2_edit_ptr);
            no_l2_edit = 0;
        }
    }


    if (no_l3_edit)
    {
        CTC_DKIT_PATH_PRINT("%-15s\n", "not do L3 edit!");
    }
    if (no_l2_edit)
    {
        CTC_DKIT_PATH_PRINT("%-15s\n", "not do L2 edit!");
    }

Discard:
    if (nhp_discard)
    {
        discard = 1;
        discard_type = nhp_discardType;
    }
    else if (pld_discard)
    {
        discard = 1;
        discard_type = pld_discardType;
    }
    else if (edit_discard)
    {
        discard = 1;
        discard_type = edit_discardType;
    }
    _ctc_goldengate_dkit_captured_path_discard_process(p_info, discard, discard_type, CTC_DKIT_EPE);
    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_epe_ipfix(ctc_dkit_captured_path_info_t* p_info)
{
    _ctc_goldengate_dkit_captured_path_ipfix(p_info, 1);

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_wlan_engine(ctc_dkit_captured_path_info_t* p_info)
{
    uint8  lchip = p_info->lchip;
    uint32 cmd = 0;
    char*  str_error_code[] = {"None", "WlanEncryptGeneralError", "WlanDecryptGeneralError", "WlanDecryptMacError",
                               "WlanDecryptSeqError", "WlanDecryptEpochError", "WlanReassembleError",
                               "Dot1aeEncryptError", "Dot1aeDecryptUnknowPkt", "Dot1aeDecryptIcvError",
                               "Dot1aeCipherModeMismatch", "Dot1aeDecryptPnError", "Dot1aeSciError"};
    char*  str_exc_code[] = {"None", "WlanSnThrdMatch", "Dot1aeThrdMatch", "Dot1aeIcvFailOrCipherMis"};
    uint32 macsecDecryptEn = 0;
    uint32 macsecDecryptKeyIndex = 0;
    uint32 macsecDecryptDot1AeEs = 0;
    uint32 macsecDecryptDot1AePn = 0;
    uint32 macsecDecryptDot1AeSc = 0;
    uint8  macsecDecryptDot1AeSci[9] = {'\0'};
    uint32 macsecDecryptDot1AeSl = 0;
    uint32 macsecDecryptErrorCode = 0;
    uint32 macsecDecryptExceptionCode = 0;
    uint32 macsecDecryptPacketLength = 0;
    uint32 macsecDecryptSecTagCbit = 0;
    uint32 macsecDecryptSecTagEbit = 0;
    uint32 macsecDecryptValid = 0;
    DbgMACSecDecryptEngineInfo_m macsec_decrypt_info;

    uint32 macsecEncryptDot1AePn = 0;
    uint8  macsecEncryptDot1AeSci[9] = {'\0'};
    uint32 macsecEncryptEn = 0;
    uint32 macsecEncryptKeyIndex = 0;
    uint32 macsecEncryptErrorCode = 0;
    uint32 macsecEncryptPacketLength = 0;
    uint32 macsecEncryptSecTagSc = 0;
    uint32 macsecEncryptValid = 0;
    DbgMACSecEncryptEngineInfo_m macsec_encrypt_info;

    sal_memset(&macsec_decrypt_info, 0, sizeof(DbgMACSecDecryptEngineInfo_m));
    cmd = DRV_IOR(DbgMACSecDecryptEngineInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &macsec_decrypt_info);
    GetDbgMACSecDecryptEngineInfo(A, mACSecDecryptEngineInfoDecryptEn_f,       &macsec_decrypt_info, &macsecDecryptEn);
    GetDbgMACSecDecryptEngineInfo(A, mACSecDecryptEngineInfoDecryptKeyIndex_f, &macsec_decrypt_info, &macsecDecryptKeyIndex);
    GetDbgMACSecDecryptEngineInfo(A, mACSecDecryptEngineInfoDot1AeEs_f,        &macsec_decrypt_info, &macsecDecryptDot1AeEs);
    GetDbgMACSecDecryptEngineInfo(A, mACSecDecryptEngineInfoDot1AePn_f,        &macsec_decrypt_info, &macsecDecryptDot1AePn);
    GetDbgMACSecDecryptEngineInfo(A, mACSecDecryptEngineInfoDot1AeSc_f,        &macsec_decrypt_info, &macsecDecryptDot1AeSc);
    GetDbgMACSecDecryptEngineInfo(A, mACSecDecryptEngineInfoDot1AeSci_f,       &macsec_decrypt_info, &macsecDecryptDot1AeSci);
    GetDbgMACSecDecryptEngineInfo(A, mACSecDecryptEngineInfoDot1AeSl_f,        &macsec_decrypt_info, &macsecDecryptDot1AeSl);
    GetDbgMACSecDecryptEngineInfo(A, mACSecDecryptEngineInfoErrorCode_f,       &macsec_decrypt_info, &macsecDecryptErrorCode);
    GetDbgMACSecDecryptEngineInfo(A, mACSecDecryptEngineInfoExceptionCode_f,   &macsec_decrypt_info, &macsecDecryptExceptionCode);
    GetDbgMACSecDecryptEngineInfo(A, mACSecDecryptEngineInfoPacketLength_f,    &macsec_decrypt_info, &macsecDecryptPacketLength);
    GetDbgMACSecDecryptEngineInfo(A, mACSecDecryptEngineInfoSecTagCbit_f,      &macsec_decrypt_info, &macsecDecryptSecTagCbit);
    GetDbgMACSecDecryptEngineInfo(A, mACSecDecryptEngineInfoSecTagEbit_f,      &macsec_decrypt_info, &macsecDecryptSecTagEbit);
    GetDbgMACSecDecryptEngineInfo(A, mACSecDecryptEngineInfoValid_f,           &macsec_decrypt_info, &macsecDecryptValid);

    sal_memset(&macsec_encrypt_info, 0, sizeof(DbgMACSecEncryptEngineInfo_m));
    cmd = DRV_IOR(DbgMACSecEncryptEngineInfo_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &macsec_encrypt_info);
    GetDbgMACSecEncryptEngineInfo(A, mACSecEncryptEngineInfoDot1AePn_f,        &macsec_encrypt_info, &macsecEncryptDot1AePn);
    GetDbgMACSecEncryptEngineInfo(A, mACSecEncryptEngineInfoDot1AeSci_f,       &macsec_encrypt_info, &macsecEncryptDot1AeSci);
    GetDbgMACSecEncryptEngineInfo(A, mACSecEncryptEngineInfoEncryptEn_f,       &macsec_encrypt_info, &macsecEncryptEn);
    GetDbgMACSecEncryptEngineInfo(A, mACSecEncryptEngineInfoEncryptKeyIndex_f, &macsec_encrypt_info, &macsecEncryptKeyIndex);
    GetDbgMACSecEncryptEngineInfo(A, mACSecEncryptEngineInfoErrorCode_f,       &macsec_encrypt_info, &macsecEncryptErrorCode);
    GetDbgMACSecEncryptEngineInfo(A, mACSecEncryptEngineInfoPacketLength_f,    &macsec_encrypt_info, &macsecEncryptPacketLength);
    GetDbgMACSecEncryptEngineInfo(A, mACSecEncryptEngineInfoSecTagSc_f,        &macsec_encrypt_info, &macsecEncryptSecTagSc);
    GetDbgMACSecEncryptEngineInfo(A, mACSecEncryptEngineInfoValid_f,           &macsec_encrypt_info, &macsecEncryptValid);

    CTC_DKIT_PRINT("\nWLAN PROCESS   \n-----------------------------------\n");

    if(macsecDecryptValid && macsecDecryptEn)
    {
        CTC_DKIT_PRINT("MacSec Decrypt Process:\n");
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "SecTag ES", macsecDecryptDot1AeEs);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "SecTag SC", macsecDecryptDot1AeSc);
        if(macsecDecryptDot1AeSc)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "SecTag SC", macsecDecryptDot1AeSci);
        }
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "SecTag SL", macsecDecryptDot1AeSl);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "SecTag Cbit", macsecDecryptSecTagCbit);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "SecTag Ebit", macsecDecryptSecTagEbit);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "SecTag PN", macsecDecryptDot1AePn);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Key Index", macsecDecryptKeyIndex);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Pkt Length", macsecDecryptPacketLength);
        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Error Code", str_error_code[macsecDecryptErrorCode]);
        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Exception Code", str_exc_code[macsecDecryptExceptionCode]);
    }

    if(macsecEncryptValid && macsecEncryptEn)
    {
        CTC_DKIT_PRINT("MacSec Encrypt Process:\n");
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "SecTag SC", macsecEncryptSecTagSc);
        if(macsecDecryptDot1AeSc)
        {
            CTC_DKIT_PATH_PRINT("%-15s:%s\n", "SecTag SC", macsecEncryptDot1AeSci);
        }
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "SecTag PN", macsecEncryptDot1AePn);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Key Index", macsecEncryptKeyIndex);
        CTC_DKIT_PATH_PRINT("%-15s:%u\n", "Pkt Length", macsecEncryptPacketLength);
        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "Error Code", str_error_code[macsecEncryptErrorCode]);
    }

    return CLI_SUCCESS;
}

static int32
_ctc_goldengate_dkit_captured_path_epe(ctc_dkit_captured_path_info_t* p_info)
{
    CTC_DKIT_PRINT("\nEGRESS PROCESS   \n-----------------------------------\n");

    /*1. Parser*/
    if (!p_info->discard)
    {
        _ctc_goldengate_dkit_captured_path_epe_parser(p_info);
    }
    /*2. SCL*/
    if (!p_info->discard)
    {
        _ctc_goldengate_dkit_captured_path_epe_scl(p_info);
    }
    /*3. Interface*/
    if (!p_info->discard)
    {
        _ctc_goldengate_dkit_captured_path_epe_interface(p_info);
    }
    /*4. ACL*/
    if (!p_info->discard)
    {
        _ctc_goldengate_dkit_captured_path_epe_acl(p_info);
    }
    /*5. OAM*/
    if (!p_info->discard)
    {
        _ctc_goldengate_dkit_captured_path_epe_oam(p_info);
    }
    /*6. Edit*/
    if (!p_info->discard)
    {
        _ctc_goldengate_dkit_captured_path_epe_edit(p_info);
    }

    /*7. Ipfix*/

    _ctc_goldengate_dkit_captured_path_epe_ipfix(p_info);

    if (p_info->discard && (0 == p_info->detail))
    {
        CTC_DKIT_PRINT("Packet Drop at EPE:\n");
        CTC_DKIT_PATH_PRINT("%-15s:%s\n", "reason", ctc_goldengate_dkit_get_reason_desc(p_info->discard_type + CTC_DKIT_DISCARD_EPE_FEATURE_START));
    }

    return CLI_SUCCESS;
}

int32
ctc_goldengate_dkit_captured_path_process(void* p_para)
{
    ctc_dkit_path_para_t* p_path_para = (ctc_dkit_path_para_t*)p_para;
    ctc_dkit_captured_path_info_t path_info ;
    ctc_dkit_captured_t ctc_dkit_captured;
    uint32 path_sel = 0;
    uint32 cmd = 0;
    uint8 lchip = 0;
    DKITS_PTR_VALID_CHECK(p_para);
    if (p_path_para->captured_session)
    {
        CTC_DKIT_PRINT("invalid session id!\n");
        return CLI_ERROR;
    }

    sal_memset(&path_info, 0, sizeof(ctc_dkit_captured_path_info_t));
    sal_memset(&ctc_dkit_captured, 0, sizeof(ctc_dkit_captured_t));

    path_info.lchip = p_path_para->lchip;
    _ctc_goldengate_dkit_captured_is_hit( &path_info);

    path_info.detail = p_path_para->detail;

    lchip = p_path_para->lchip;
    cmd = DRV_IOR(MetFifoDebugCtl_t, MetFifoDebugCtl_gSrcChanType_0_debugPathSel_f);  /*TBD*/
    DRV_IOCTL(lchip, 0, cmd, &path_sel);

    path_info.path_sel = path_sel;
    if (path_info.is_ipe_captured | path_info.is_bsr_captured | path_info.is_epe_captured)
    {
        if ((path_info.is_ipe_captured) && (!path_info.discard))
        {
            _ctc_goldengate_dkit_captured_path_ipe(&path_info);
        }
        if ((path_info.is_bsr_captured)  && (path_info.detail))
        {
            _ctc_goldengate_dkit_captured_path_bsr(&path_info);
        }
        if ((path_info.is_epe_captured) && (!path_info.discard) && (path_info.path_sel == 1))
        {
            _ctc_goldengate_dkit_captured_path_epe(&path_info);
        }

        if (!path_info.discard)
        {
            _ctc_goldengate_dkit_captured_path_wlan_engine(&path_info);
        }

        ctc_dkit_captured.captured_session = p_path_para->captured_session;
        ctc_dkit_captured.flag = p_path_para->flag;
        ctc_goldengate_dkit_captured_clear((void*)(&ctc_dkit_captured));
    }
    else
    {
        CTC_DKIT_PRINT("Not Captured Flow!\n");
    }

    return CLI_SUCCESS;
}


int32
ctc_goldengate_dkit_captured_clear(void* p_para)
{
    ctc_dkit_captured_t* p_captured_para = (ctc_dkit_captured_t*)p_para;
    uint32 flag = 0;
    uint32 cmd = 0;
    uint32 value = 0;
    uint8 lchip = 0;
    uint32 temp_v = 0;


    DKITS_PTR_VALID_CHECK(p_para);
    lchip = p_captured_para->lchip;
    CTC_DKIT_LCHIP_CHECK(lchip);
    if (p_captured_para->captured_session)
    {
        CTC_DKIT_PRINT("invalid session id!\n");
        return CLI_ERROR;
    }
    flag = p_captured_para->flag;

    if ((CTC_DKIT_CAPTURED_CLEAR_RESULT == flag) || (CTC_DKIT_CAPTURED_CLEAR_ALL == flag))
    {
        value = 1;
        cmd = DRV_IOW(DebugSessionStatusCtl_t, DebugSessionStatusCtl_isFree_f);
        DRV_IOCTL(lchip, 0, cmd, &value);

        value = 1;
        cmd = DRV_IOW(EpeHdrAdjustChanCtl_t, EpeHdrAdjustChanCtl_debugIsFree_f);
        DRV_IOCTL(lchip, 0, cmd, &value);

        cmd = DRV_IOW(DbgFwdBufRetrvHeaderInfo_t, DbgFwdBufRetrvHeaderInfo_fwdBufRetrvHeaderInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFwdBufRetrvInfo_t, DbgFwdBufRetrvInfo_fwdBufRetrvInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFwdBufStoreInfo_t, DbgFwdBufRetrvInfo_fwdBufRetrvInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFwdBufStoreInfo2_t, DbgFwdBufStoreInfo2_fwdBufStoreInfo2Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIrmResrcAllocInfo_t, DbgIrmResrcAllocInfo_irmResrcAllocInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgWlanDecryptEngineInfo_t, DbgWlanDecryptEngineInfo_wlanDecryptEngineInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgWlanEncryptAndFragmentEngineInfo_t, DbgWlanEncryptAndFragmentEngineInfo_wlanEncryptAndFragmentEngineInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgWlanReassembleEngineInfo_t, DbgWlanReassembleEngineInfo_wlanReassembleEngineInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgDlbEngineInfo_t, DbgDlbEngineInfo_dlbEngineInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgOamApsSwitch_t, DbgOamApsSwitch_oamApsSwitchValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEfdEngineInfo_t, DbgEfdEngineInfo_efdEngineInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEgrXcOamHash0EngineFromEpeNhpInfo_t, DbgEgrXcOamHash0EngineFromEpeNhpInfo_egrXcOamHash0EngineFromEpeNhpInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEgrXcOamHash1EngineFromEpeNhpInfo_t, DbgEgrXcOamHash1EngineFromEpeNhpInfo_egrXcOamHash1EngineFromEpeNhpInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEgrXcOamHashEngineFromEpeOam0Info_t, DbgEgrXcOamHashEngineFromEpeOam0Info_egrXcOamHashEngineFromEpeOam0InfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEgrXcOamHashEngineFromEpeOam1Info_t, DbgEgrXcOamHashEngineFromEpeOam0Info_egrXcOamHashEngineFromEpeOam0InfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEgrXcOamHashEngineFromEpeOam2Info_t, DbgEgrXcOamHashEngineFromEpeOam2Info_egrXcOamHashEngineFromEpeOam2InfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEgrXcOamHashEngineFromIpeOam0Info_t, DbgEgrXcOamHashEngineFromIpeOam0Info_egrXcOamHashEngineFromIpeOam0InfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEgrXcOamHashEngineFromIpeOam1Info_t, DbgEgrXcOamHashEngineFromIpeOam1Info_egrXcOamHashEngineFromIpeOam1InfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEgrXcOamHashEngineFromIpeOam2Info_t, DbgEgrXcOamHashEngineFromIpeOam2Info_egrXcOamHashEngineFromIpeOam2InfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEpeAclInfo_t, DbgEpeAclInfo_epeAclInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEpeClassificationInfo_t, DbgEpeClassificationInfo_epeClassificationInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEpeOamInfo_t, DbgEpeOamInfo_epeOamInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEpeHdrAdjInfo_t, DbgEpeHdrAdjInfo_epeHdrAdjInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEpeHdrEditCflexHdrInfo_t, DbgEpeHdrEditCflexHdrInfo_epeHdrEditCflexHdrInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEpeHdrEditInfo_t, DbgEpeHdrEditInfo_epeHdrEditInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEpeEgressEditInfo_t, DbgEpeEgressEditInfo_epeEgressEditInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEpeInnerL2EditInfo_t, DbgEpeInnerL2EditInfo_epeInnerL2EditInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEpeL3EditInfo_t, DbgEpeL3EditInfo_epeL3EditInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEpeOuterL2EditInfo_t, DbgEpeOuterL2EditInfo_epeOuterL2EditInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEpePayLoadInfo_t, DbgEpePayLoadInfo_epePayLoadInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgParserFromEpeHdrAdjInfo_t, DbgParserFromEpeHdrAdjInfo_parserFromEpeHdrAdjInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgEpeNextHopInfo_t, DbgEpeNextHopInfo_epeNextHopInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFibLkpEngineFlowHashInfo_t, DbgFibLkpEngineFlowHashInfo_fibLkpEngineFlowHashInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFibLkpEngineMacDaHashInfo_t, DbgFibLkpEngineMacDaHashInfo_fibLkpEngineMacDaHashInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFibLkpEngineMacSaHashInfo_t, DbgFibLkpEngineMacSaHashInfo_fibLkpEngineMacSaHashInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFibLkpEnginel3DaHashInfo_t, DbgFibLkpEnginel3DaHashInfo_fibLkpEnginel3DaHashInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFibLkpEnginel3SaHashInfo_t, DbgFibLkpEnginel3SaHashInfo_fibLkpEnginel3SaHashInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpfixAccEgrInfo_t, DbgIpfixAccEgrInfo_ipfixAccEgrInfoGEgr_valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpfixAccIngInfo_t, DbgIpfixAccIngInfo_ipfixAccIngInfoGIngr_valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineEpeAclInfo0_t, DbgFlowTcamEngineEpeAclInfo0_flowTcamEngineEpeAclInfo0Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineEpeAclInfo1_t, DbgFlowTcamEngineEpeAclInfo1_flowTcamEngineEpeAclInfo1Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineEpeAclInfo2_t, DbgFlowTcamEngineEpeAclInfo2_flowTcamEngineEpeAclInfo2Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineEpeAclKeyInfo0_t, DbgFlowTcamEngineEpeAclKeyInfo0_flowTcamEngineEpeAclKeyInfo0Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineEpeAclKeyInfo1_t, DbgFlowTcamEngineEpeAclKeyInfo1_flowTcamEngineEpeAclKeyInfo1Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineEpeAclKeyInfo2_t, DbgFlowTcamEngineEpeAclKeyInfo2_flowTcamEngineEpeAclKeyInfo2Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclInfo0_t, DbgFlowTcamEngineIpeAclInfo0_flowTcamEngineIpeAclInfo0Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclInfo1_t, DbgFlowTcamEngineIpeAclInfo1_flowTcamEngineIpeAclInfo1Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclInfo2_t, DbgFlowTcamEngineIpeAclInfo2_flowTcamEngineIpeAclInfo2Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclInfo3_t, DbgFlowTcamEngineIpeAclInfo3_flowTcamEngineIpeAclInfo3Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclInfo4_t, DbgFlowTcamEngineIpeAclInfo4_flowTcamEngineIpeAclInfo4Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclInfo5_t, DbgFlowTcamEngineIpeAclInfo5_flowTcamEngineIpeAclInfo5Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclInfo6_t, DbgFlowTcamEngineIpeAclInfo6_flowTcamEngineIpeAclInfo6Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclInfo7_t, DbgFlowTcamEngineIpeAclInfo7_flowTcamEngineIpeAclInfo7Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclKeyInfo0_t, DbgFlowTcamEngineIpeAclKeyInfo0_flowTcamEngineIpeAclKeyInfo0Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclKeyInfo1_t, DbgFlowTcamEngineIpeAclKeyInfo1_flowTcamEngineIpeAclKeyInfo1Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclKeyInfo2_t, DbgFlowTcamEngineIpeAclKeyInfo2_flowTcamEngineIpeAclKeyInfo2Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclKeyInfo3_t, DbgFlowTcamEngineIpeAclKeyInfo3_flowTcamEngineIpeAclKeyInfo3Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclKeyInfo4_t, DbgFlowTcamEngineIpeAclKeyInfo4_flowTcamEngineIpeAclKeyInfo4Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclKeyInfo5_t, DbgFlowTcamEngineIpeAclKeyInfo5_flowTcamEngineIpeAclKeyInfo5Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclKeyInfo6_t, DbgFlowTcamEngineIpeAclKeyInfo6_flowTcamEngineIpeAclKeyInfo6Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineIpeAclKeyInfo7_t, DbgFlowTcamEngineIpeAclKeyInfo7_flowTcamEngineIpeAclKeyInfo7Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineUserIdInfo0_t, DbgFlowTcamEngineUserIdInfo0_flowTcamEngineUserIdInfo0Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineUserIdInfo1_t, DbgFlowTcamEngineUserIdInfo1_flowTcamEngineUserIdInfo1Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineUserIdInfo2_t, DbgFlowTcamEngineUserIdInfo2_flowTcamEngineUserIdInfo2Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineUserIdKeyInfo0_t, DbgFlowTcamEngineUserIdKeyInfo0_flowTcamEngineUserIdKeyInfo0Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFlowTcamEngineUserIdKeyInfo1_t, DbgFlowTcamEngineUserIdKeyInfo1_flowTcamEngineUserIdKeyInfo1Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeAclProcInfo_t, DbgIpeAclProcInfo_ipeAclProcInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeEcmpProcInfo_t, DbgIpeEcmpProcInfo_ipeEcmpProcInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeFwdCoppInfo_t, DbgIpeFwdCoppInfo_ipeFwdCoppInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeFwdPolicingInfo_t, DbgIpeFwdPolicingInfo_ipeFwdPolicingInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeFwdProcessInfo_t, DbgIpeFwdProcessInfo_ipeFwdProcessInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeFwdStormCtlInfo_t, DbgIpeFwdStormCtlInfo_ipeFwdStormCtlInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeIntfMapperInfo_t, DbgIpeIntfMapperInfo_ipeIntfMapperInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeMplsDecapInfo_t, DbgIpeMplsDecapInfo_ipeMplsDecapInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeUserIdInfo_t, DbgIpeUserIdInfo_ipeUserIdInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeLkpMgrInfo_t, DbgIpeLkpMgrInfo_ipeLkpMgrInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgParserFromIpeIntfInfo_t, DbgParserFromIpeIntfInfo_parserFromIpeIntfInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeFcoeInfo_t, DbgIpeFcoeInfo_ipeFcoeInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeFlowProcessInfo_t, DbgIpeFlowProcessInfo_ipeFlowProcessInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeIpRoutingInfo_t, DbgIpeIpRoutingInfo_ipeIpRoutingInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeMacBridgingInfo_t, DbgIpeMacBridgingInfo_ipeMacBridgingInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeMacLearningInfo_t, DbgIpeMacLearningInfo_ipeMacLearningInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeOamInfo_t, DbgIpeOamInfo_ipeOamInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpePacketProcessInfo_t, DbgIpePacketProcessInfo_ipePacketProcessInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpePerHopBehaviorInfo_t, DbgIpePerHopBehaviorInfo_ipePerHopBehaviorInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgIpeTrillInfo_t, DbgIpeTrillInfo_ipeTrillInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgLagEngineInfoFromBsrEnqueue_t, DbgLagEngineInfoFromBsrEnqueue_lagEngineInfoFromBsrEnqueueValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgLagEngineInfoFromIpeFwd_t, DbgLagEngineInfoFromIpeFwd_lagEngineInfoFromIpeFwdValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgLpmTcamEngineResult0Info_t, DbgLpmTcamEngineResult0Info_lpmTcamEngineResult0InfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgLpmTcamEngineResult1Info_t, DbgLpmTcamEngineResult1Info_lpmTcamEngineResult1InfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgMACSecDecryptEngineInfo_t, DbgMACSecDecryptEngineInfo_mACSecDecryptEngineInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgMACSecEncryptEngineInfo_t, DbgMACSecEncryptEngineInfo_mACSecEncryptEngineInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFwdMetFifoInfo1_t, DbgFwdMetFifoInfo1_fwdMetFifoInfo1Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFwdMetFifoInfo2_t, DbgFwdMetFifoInfo2_fwdMetFifoInfo2Valid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgOamHdrEdit_t, DbgOamHdrEdit_oamHdrEditValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgOamHdrAdj_t, DbgOamHdrAdj_oamHdrAdjValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgOamParser_t, DbgOamParser_oamParserValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgOamDefectProc_t, DbgOamDefectProc_oamDefectProcValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgOamRxProc_t, DbgOamRxProc_oamRxProcValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgOamTxProc_t, DbgOamTxProc_oamTxProcValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgErmResrcAllocInfo_t, DbgErmResrcAllocInfo_ermResrcAllocInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgFwdQWriteInfo_t, DbgFwdQWriteInfo_fwdQWriteInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgParserFromIpeHdrAdjInfo_t, DbgParserFromIpeHdrAdjInfo_parserFromIpeHdrAdjInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        /*cmd = DRV_IOW(DbgSubSchProcDmaInfo_t, DbgSubSchProcDmaInfo_subSchProcDmaInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgSubSchProcNetInfo_t, DbgSubSchProcNetInfo_subSchProcNetInfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);*/                                                         /*TBD*/
        cmd = DRV_IOW(DbgUserIdHashEngineForMpls0Info_t, DbgUserIdHashEngineForMpls0Info_userIdHashEngineForMpls0InfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgUserIdHashEngineForMpls1Info_t, DbgUserIdHashEngineForMpls1Info_userIdHashEngineForMpls1InfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgUserIdHashEngineForMpls2Info_t, DbgUserIdHashEngineForMpls2Info_userIdHashEngineForMpls2InfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgUserIdHashEngineForUserId0Info_t, DbgUserIdHashEngineForUserId0Info_userIdHashEngineForUserId0InfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);
        cmd = DRV_IOW(DbgUserIdHashEngineForUserId1Info_t, DbgUserIdHashEngineForUserId1Info_userIdHashEngineForUserId1InfoValid_f);
        DRV_IOCTL(lchip, 0, cmd, &temp_v);


    }

    if ((CTC_DKIT_CAPTURED_CLEAR_FLOW == flag) || (CTC_DKIT_CAPTURED_CLEAR_ALL == flag))
    {
        value = 0;
        cmd = DRV_IOW(IpeUserIdFlowCtl_t, IpeUserIdFlowCtl_flowEn_f);
        DRV_IOCTL(lchip, 0, cmd, &value);
    }
    return CLI_SUCCESS;
}




int32
ctc_goldengate_dkit_captured_install_flow(void* p_para)
{
    ctc_dkit_captured_t* p_captured_para = (ctc_dkit_captured_t*)p_para;
    uint32 value = 0;
    uint32 path_sel = 0;
    uint32 cmd = 0;
    uint8 local_phy_port = 0;
    mac_addr_t mac_mask;
    ipv6_addr_t ipv6_mask;
    ParserResult_m parser_result;
    ParserResult_m parser_result_mask;
    IpeUserIdFlowCam_m ds_flow_cam;
    EpeHdrAdjustDebugCam_m epe_dbg_cam;
    uint8 lchip = 0;
    uint32 index = 0;

    DKITS_PTR_VALID_CHECK(p_para);
    lchip = p_captured_para->lchip;
    CTC_DKIT_LCHIP_CHECK(lchip);

    sal_memset(&parser_result, 0, sizeof(ParserResult_m));
    sal_memset(&parser_result_mask, 0, sizeof(ParserResult_m));
    sal_memset(&ds_flow_cam, 0, sizeof(IpeUserIdFlowCam_m));
    sal_memset(&epe_dbg_cam, 0, sizeof(EpeHdrAdjustDebugCam_m));
    sal_memset(&mac_mask, 0xFF, sizeof(mac_mask));
    sal_memset(&ipv6_mask, 0xFF, sizeof(ipv6_mask));

    if (p_captured_para->captured_session)
    {
        CTC_DKIT_PRINT("invalid session id!\n");
        return CLI_ERROR;
    }
    p_captured_para->flag = CTC_DKIT_CAPTURED_CLEAR_ALL;
    ctc_goldengate_dkit_captured_clear(p_captured_para);

    if(p_captured_para->path_sel > 2)
    {
        CTC_DKIT_PRINT("invalid path select id!\n");
        return CLI_ERROR;
    }
    path_sel = p_captured_para->path_sel + 1;
    /*1. enable debug session*/
    value = 1;
    cmd = DRV_IOW(DebugSessionStatusCtl_t, DebugSessionStatusCtl_isFree_f);
    DRV_IOCTL(lchip, 0, cmd, &value);

    cmd = DRV_IOW(EpeHdrAdjustChanCtl_t, EpeHdrAdjustChanCtl_debugIsFree_f);
    DRV_IOCTL(lchip, 0, cmd, &value);
    cmd = DRV_IOW(EpeHdrAdjustCtl_t, EpeHdrAdjustCtl_debugLookupEn_f);
    DRV_IOCTL(lchip, 0, cmd, &value);
    cmd = DRV_IOW(IpeUserIdFlowCtl_t, IpeUserIdFlowCtl_flowEn_f);
    DRV_IOCTL(lchip, 0, cmd, &value);
    cmd = DRV_IOW(BufStoreDebugCtl_t, BufStoreDebugCtl_debugLookupEn_f);
    DRV_IOCTL(lchip, 0, cmd, &value);
    cmd = DRV_IOW(DbgOamHdrAdj_t, DbgOamHdrAdj_oamHdrAdjDebugSessionEn_f);
    DRV_IOCTL(lchip, 0, cmd, &value);

    cmd = DRV_IOW(MetFifoDebugCtl_t, MetFifoDebugCtl_gSrcChanType_0_debugPathSel_f);   /*TBD*/
    DRV_IOCTL(lchip, 0, cmd, &path_sel);

    cmd = DRV_IOW(DsMetFifoExcp_t, DsMetFifoExcp_debugEn_f);
    for(index=0; index < TABLE_MAX_INDEX(DsMetFifoExcp_t); ++index)
    {
        DRV_IOCTL(lchip, index, cmd, &value);
    }

    if(1 == p_captured_para->flow_info_mask.port)
    {
        local_phy_port = CTC_DKIT_CTC_GPORT_TO_DRV_LPORT(p_captured_para->flow_info.port);
        SetIpeUserIdFlowCam(V, g_0_localPhyPort_f, &ds_flow_cam, local_phy_port);  /*key*/
        SetIpeUserIdFlowCam(V, g_1_localPhyPort_f, &ds_flow_cam, 0xFF);            /*mask*/
    }


    /*2. store flow by parser result*/
    if (1 == p_captured_para->flow_info_mask.mac_da[0])
    {
        SetParserResult(A, macDa_f, &parser_result, p_captured_para->flow_info.mac_da);
        SetParserResult(A, macDa_f, &parser_result_mask, mac_mask);

    }
    if (1 == p_captured_para->flow_info_mask.mac_sa[0])
    {
        SetParserResult(A, macSa_f, &parser_result, p_captured_para->flow_info.mac_sa);
        SetParserResult(A, macSa_f, &parser_result_mask, mac_mask);
    }
    if (1 == p_captured_para->flow_info_mask.svlan_id)
    {
        SetParserResult(V, svlanId_f, &parser_result, p_captured_para->flow_info.svlan_id);
        SetParserResult(V, svlanId_f, &parser_result_mask, 0xFFF);
        SetParserResult(V, svlanIdValid_f, &parser_result, 1);
        SetParserResult(V, svlanIdValid_f, &parser_result_mask, 1);
    }
    if (1 == p_captured_para->flow_info_mask.cvlan_id)
    {
        SetParserResult(V, cvlanId_f, &parser_result, p_captured_para->flow_info.cvlan_id);
        SetParserResult(V, cvlanId_f, &parser_result_mask, 0xFFF);
        SetParserResult(V, cvlanIdValid_f, &parser_result, 1);
        SetParserResult(V, cvlanIdValid_f, &parser_result_mask, 1);
    }
    if (1 == p_captured_para->flow_info_mask.ether_type)
    {
        SetParserResult(V, etherType_f, &parser_result, p_captured_para->flow_info.ether_type);
        SetParserResult(V, etherType_f, &parser_result_mask, 0xFFFF);
    }
    if (1 == p_captured_para->flow_info_mask.l3_type)
    {
        switch (p_captured_para->flow_info.l3_type)
        {
        case CTC_DKIT_CAPTURED_IPV4:
            if (1 == p_captured_para->flow_info_mask.u_l3.ipv4.ip_da)
            {
                SetParserResult(V, uL3Dest_gIpv4_ipDa_f, &parser_result, p_captured_para->flow_info.u_l3.ipv4.ip_da);
                SetParserResult(V, uL3Dest_gIpv4_ipDa_f, &parser_result_mask, 0xFFFFFFFF);
            }

            if (1 == p_captured_para->flow_info_mask.u_l3.ipv4.ip_sa)
            {
                SetParserResult(V, uL3Source_gIpv4_ipSa_f, &parser_result, p_captured_para->flow_info.u_l3.ipv4.ip_sa);
                SetParserResult(V, uL3Source_gIpv4_ipSa_f, &parser_result_mask, 0xFFFFFFFF);
            }
            if (1 == p_captured_para->flow_info_mask.u_l3.ipv4.ip_check_sum)
            {
                SetParserResult(V, uL3Source_gIpv4_ipChecksum_f, &parser_result, p_captured_para->flow_info.u_l3.ipv4.ip_check_sum);
                SetParserResult(V, uL3Source_gIpv4_ipChecksum_f, &parser_result_mask, 0xFFFF);
            }
            break;
        case CTC_DKIT_CAPTURED_IPV6:
            if (1 == p_captured_para->flow_info_mask.u_l3.ipv6.ip_da[0])
            {
                SetParserResult(A, uL3Dest_gIpv6_ipDa_f, &parser_result, p_captured_para->flow_info.u_l3.ipv6.ip_da);
                SetParserResult(A, uL3Dest_gIpv6_ipDa_f, &parser_result_mask, ipv6_mask);
            }
            if (1 == p_captured_para->flow_info_mask.u_l3.ipv6.ip_sa[0])
            {
                SetParserResult(A, uL3Source_gIpv6_ipSa_f, &parser_result, p_captured_para->flow_info.u_l3.ipv6.ip_sa);
                SetParserResult(A, uL3Source_gIpv6_ipSa_f, &parser_result_mask, ipv6_mask);
            }
            break;
        case CTC_DKIT_CAPTURED_MPLS:
            if (1 == p_captured_para->flow_info_mask.u_l3.mpls.mpls_label0)
            {
                SetParserResult(V, uL3Dest_gMpls_mplsLabel0_f, &parser_result, p_captured_para->flow_info.u_l3.mpls.mpls_label0);
                SetParserResult(V, uL3Dest_gMpls_mplsLabel0_f, &parser_result_mask, 0xFFFFFFFF);
            }
            if (1 == p_captured_para->flow_info_mask.u_l3.mpls.mpls_label1)
            {
                SetParserResult(V, uL3Dest_gMpls_mplsLabel1_f, &parser_result, p_captured_para->flow_info.u_l3.mpls.mpls_label1);
                SetParserResult(V, uL3Dest_gMpls_mplsLabel1_f, &parser_result_mask, 0xFFFFFFFF);
            }
            if (1 == p_captured_para->flow_info_mask.u_l3.mpls.mpls_label2)
            {
                SetParserResult(V, uL3Dest_gMpls_mplsLabel2_f, &parser_result, p_captured_para->flow_info.u_l3.mpls.mpls_label2);
                SetParserResult(V, uL3Dest_gMpls_mplsLabel2_f, &parser_result_mask, 0xFFFFFFFF);
            }
            if (1 == p_captured_para->flow_info_mask.u_l3.mpls.mpls_label3)
            {
                SetParserResult(V, uL3Dest_gMpls_mplsLabel3_f, &parser_result, p_captured_para->flow_info.u_l3.mpls.mpls_label3);
                SetParserResult(V, uL3Dest_gMpls_mplsLabel3_f, &parser_result_mask, 0xFFFFFFFF);
            }
            break;
        case CTC_DKIT_CAPTURED_SLOW_PROTOCOL:
            if (1 == p_captured_para->flow_info_mask.u_l3.slow_proto.sub_type)
            {
                SetParserResult(V, uL3Dest_gSlowProto_slowProtocolSubType_f, &parser_result, p_captured_para->flow_info.u_l3.slow_proto.sub_type);
                SetParserResult(V, uL3Dest_gSlowProto_slowProtocolSubType_f, &parser_result_mask, 0xFF);
            }
            if (1 == p_captured_para->flow_info_mask.u_l3.slow_proto.flags)
            {
                SetParserResult(V, uL3Dest_gSlowProto_slowProtocolFlags_f, &parser_result, p_captured_para->flow_info.u_l3.slow_proto.flags);
                SetParserResult(V, uL3Dest_gSlowProto_slowProtocolFlags_f, &parser_result_mask, 0xFFFF);
            }
            if (1 == p_captured_para->flow_info_mask.u_l3.slow_proto.code)
            {
                SetParserResult(V, uL3Dest_gSlowProto_slowProtocolCode_f, &parser_result, p_captured_para->flow_info.u_l3.slow_proto.code);
                SetParserResult(V, uL3Dest_gSlowProto_slowProtocolCode_f, &parser_result_mask, 0xFF);
            }
            break;
        case CTC_DKIT_CAPTURED_ETHOAM:
            if (1 == p_captured_para->flow_info_mask.u_l3.ether_oam.level)
            {
                SetParserResult(V, uL3Dest_gEtherOam_etherOamLevel_f, &parser_result, p_captured_para->flow_info.u_l3.ether_oam.level);
                SetParserResult(V, uL3Dest_gEtherOam_etherOamLevel_f, &parser_result_mask, 0x7);
            }
            if (1 == p_captured_para->flow_info_mask.u_l3.ether_oam.version)
            {
                SetParserResult(V, uL3Dest_gEtherOam_etherOamVersion_f, &parser_result, p_captured_para->flow_info.u_l3.ether_oam.version);
                SetParserResult(V, uL3Dest_gEtherOam_etherOamVersion_f, &parser_result_mask, 0x1F);
            }
            if (1 == p_captured_para->flow_info_mask.u_l3.ether_oam.opcode)
            {
                SetParserResult(V, uL3Dest_gEtherOam_etherOamOpCode_f, &parser_result, p_captured_para->flow_info.u_l3.ether_oam.opcode);
                SetParserResult(V, uL3Dest_gEtherOam_etherOamOpCode_f, &parser_result_mask, 0xFF);
            }
            break;
        default:
            break;
        }
    }

    SetIpeUserIdFlowCam(A, g_0_data_f, &ds_flow_cam, &parser_result);
    SetIpeUserIdFlowCam(A, g_1_data_f, &ds_flow_cam, &parser_result_mask);
    cmd = DRV_IOW(IpeUserIdFlowCam_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &ds_flow_cam);

    value = 1;
    SetEpeHdrAdjustDebugCam(A, g_0_isDebuggedPkt_f, &epe_dbg_cam, &value);
    SetEpeHdrAdjustDebugCam(A, g_1_isDebuggedPkt_f, &epe_dbg_cam, &value);
    cmd = DRV_IOW(EpeHdrAdjustDebugCam_t, DRV_ENTRY_FLAG);
    DRV_IOCTL(lchip, 0, cmd, &epe_dbg_cam);

    return CLI_SUCCESS;
}


int32
ctc_goldengate_dkit_captured_get_discard_sub_reason(ctc_dkit_discard_para_t* p_para, ctc_dkit_discard_info_t* p_discard_info)
{
    DKITS_PTR_VALID_CHECK(p_discard_info);
    DKITS_PTR_VALID_CHECK(p_para);
    p_discard_info->discard_reason_captured.reason_id = CTC_DKIT_SUB_DISCARD_INVALIED;


    return CLI_SUCCESS;
}
extern int32
_ctc_goldengate_dkit_memory_show_ram_by_data_tbl_addr( uint32 tbl_id, uint32 index, uint32* data_entry, uint32 addr);
int32
ctc_goldengate_dkit_captured_show_bridge_header(uint8 lchip, uint8 mode)
{
    uint32 cmd = 0;
    uint32 header_valid   = 0;

    MsPacketHeader_m ms_pkt_hdr;
    DbgFwdBufRetrvHeaderInfo_m dbg_buf_retrv_header;
    DbgFwdBufStoreInfo2_m      dbg_buf_store_info;

    sal_memset(&ms_pkt_hdr, 0, sizeof(MsPacketHeader_m));
    sal_memset(&dbg_buf_retrv_header, 0, sizeof(DbgFwdBufRetrvHeaderInfo_m));
    sal_memset(&dbg_buf_store_info, 0, sizeof(DbgFwdBufStoreInfo2_m));

    CTC_DKIT_PRINT("\nBridge Header Info\n-----------------------------------\n");

    if(0 == mode)
    {
        cmd = DRV_IOR(DbgFwdBufRetrvHeaderInfo_t, DRV_ENTRY_FLAG);
        DRV_IOCTL(lchip, 0, cmd, &dbg_buf_retrv_header);
        GetDbgFwdBufRetrvHeaderInfo(A, fwdBufRetrvHeaderInfoValid_f, &dbg_buf_retrv_header, &header_valid);
        GetDbgFwdBufRetrvHeaderInfo(A, fwdBufRetrvHeaderInfoPacketHeader_f, &dbg_buf_retrv_header, &ms_pkt_hdr);
    }
    else if(1 == mode)
    {
        cmd = DRV_IOR(DbgFwdBufStoreInfo2_t, DRV_ENTRY_FLAG);
        DRV_IOCTL(lchip, 0, cmd, &dbg_buf_store_info);
        GetDbgFwdBufStoreInfo2(A, fwdBufStoreInfo2Valid_f, &dbg_buf_store_info, &header_valid);
        GetDbgFwdBufStoreInfo2(A, fwdBufStoreInfo2PacketHeader_f, &dbg_buf_store_info, &ms_pkt_hdr);
    }

    if(header_valid)
    {
        _ctc_goldengate_dkit_memory_show_ram_by_data_tbl_addr(MsPacketHeader_t, 0, (uint32*)(&ms_pkt_hdr), 0);
    }
    else
    {
        CTC_DKIT_PATH_PRINT("Header Info not Invalid!\n");
    }


    return CLI_SUCCESS;
}


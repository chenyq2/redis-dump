#ifndef _CTC_DKIT_GOLDENGATE_DISCARD_H_
#define _CTC_DKIT_GOLDENGATE_DISCARD_H_


#ifdef __cplusplus
extern "C" {
#endif


#include "sal.h"

#define CTC_DKIT_IPE_DISCARD_TYPE_NUM     64
#define CTC_DKIT_EPE_DISCARD_TYPE_NUM     64
#define CTC_DKIT_INVALID_PORT             0xFFFF
#define CTC_DKIT_REASON_LEN               64
#define CTC_DKIT_CHANNEL_NUM              128
#define CTC_DKIT_SLICE_NUM                1




enum ctc_dkit_discard_reason_id_e
{

    CTC_DKIT_DISCARD_INVALIED,

   /*-----------------------  IPE   ------------------------*/
    CTC_DKIT_DISCARD_IPE_START                              ,


    CTC_DKIT_DISCARD_IPE_FEATURE_START                      = CTC_DKIT_DISCARD_IPE_START,
    CTC_DKIT_DISCARD_IPE_RESERVED0                          = CTC_DKIT_DISCARD_IPE_FEATURE_START,
    CTC_DKIT_DISCARD_IPE_LPBK_HDR_ADJ_RM_ERR                ,
    CTC_DKIT_DISCARD_IPE_PARSER_LEN_ERR                     ,
    CTC_DKIT_DISCARD_IPE_UC_TO_LAG_GROUP_NO_MEMBER          ,
    CTC_DKIT_DISCARD_IPE_EXCEP2_DIS                         ,
    CTC_DKIT_DISCARD_IPE_DS_USERID_DIS                      ,
    CTC_DKIT_DISCARD_IPE_RECEIVE_DIS                        ,
    CTC_DKIT_DISCARD_IPE_MICROFLOW_POLICING_FAIL_DROP       ,
    CTC_DKIT_DISCARD_IPE_PROTOCOL_VLAN_DIS                  ,
    CTC_DKIT_DISCARD_IPE_AFT_DIS                            ,
    CTC_DKIT_DISCARD_IPE_L2_ILLEGAL_PKT_DIS                 ,
    CTC_DKIT_DISCARD_IPE_STP_DIS                            ,
    CTC_DKIT_DISCARD_IPE_DEST_MAP_PROFILE_DISCARD           ,
    CTC_DKIT_DISCARD_IPE_STACK_REFLECT_DISCARD              ,
    CTC_DKIT_DISCARD_IPE_ARP_DHCP_DIS                       ,
    CTC_DKIT_DISCARD_IPE_DS_PHYPORT_SRCDIS                  ,
    CTC_DKIT_DISCARD_IPE_VLAN_FILTER_DIS                    ,
    CTC_DKIT_DISCARD_IPE_DS_ACL_DIS                         ,
    CTC_DKIT_DISCARD_IPE_ROUTE_ERROR_PKT_DIS                ,
    CTC_DKIT_DISCARD_IPE_SECURITY_CHK_DIS                   ,
    CTC_DKIT_DISCARD_IPE_STORM_CTL_DIS                      ,
    CTC_DKIT_DISCARD_IPE_LEARNING_DIS                       ,
    CTC_DKIT_DISCARD_IPE_NO_FORWARDING_PTR                  ,
    CTC_DKIT_DISCARD_IPE_IS_DIS_FORWARDING_PTR              ,
    CTC_DKIT_DISCARD_IPE_FATAL_EXCEP_DIS                    ,
    CTC_DKIT_DISCARD_IPE_APS_DIS                            ,
    CTC_DKIT_DISCARD_IPE_DS_FWD_DESTID_DIS                  ,
    CTC_DKIT_DISCARD_IPE_LOOPBACK_DIS                       ,
    CTC_DKIT_DISCARD_IPE_DISCARD_PACKET_LOG_ALL_TYPE        ,
    CTC_DKIT_DISCARD_IPE_PORT_MAC_CHECK_DIS                 ,
    CTC_DKIT_DISCARD_IPE_L3_EXCEP_DIS                       ,
    CTC_DKIT_DISCARD_IPE_STACKING_HDR_CHK_ERR               ,
    CTC_DKIT_DISCARD_IPE_TUNNEL_DECAP_MARTIAN_ADD           ,
    CTC_DKIT_DISCARD_IPE_TUNNELID_FWD_PTR_DIS               ,
    CTC_DKIT_DISCARD_IPE_VXLAN_FLAG_CHK_ERROR_DISCARD       ,
    CTC_DKIT_DISCARD_IPE_VXLAN_NVGRE_INNER_VTAG_CHK_DIS     ,
    CTC_DKIT_DISCARD_IPE_VXLAN_NVGRE_CHK_FAIL               ,
    CTC_DKIT_DISCARD_IPE_GENEVE_PAKCET_DISCARD              ,
    CTC_DKIT_DISCARD_IPE_ICMP_REDIRECT_DIS                  ,
    CTC_DKIT_DISCARD_IPE_ICMP_ERR_MSG_DIS                   ,
    CTC_DKIT_DISCARD_IPE_PTP_PKT_DIS                        ,
    CTC_DKIT_DISCARD_IPE_MUX_PORT_ERR                       ,
    CTC_DKIT_DISCARD_IPE_HW_ERROR_DISCARD                   ,
    CTC_DKIT_DISCARD_IPE_USERID_BINDING_DIS                 ,
    CTC_DKIT_DISCARD_IPE_RESERVED1                          ,
    CTC_DKIT_DISCARD_IPE_RESERVED2                          ,
    CTC_DKIT_DISCARD_IPE_DOT1AE_CHK                         ,
    CTC_DKIT_DISCARD_IPE_OAM_DISABLE                        ,
    CTC_DKIT_DISCARD_IPE_OAM_NOT_FOUND                      ,
    CTC_DKIT_DISCARD_IPE_OAM_NO_MEP_MIP                     ,
    CTC_DKIT_DISCARD_IPE_OAM_ETH_VLAN_CHK                   ,
    CTC_DKIT_DISCARD_IPE_OAM_BFD_TTL_CHK                    ,
    CTC_DKIT_DISCARD_IPE_OAM_FILTER_DIS                     ,
    CTC_DKIT_DISCARD_IPE_TRILL_CHK                          ,
    CTC_DKIT_DISCARD_IPE_CAPWAP_CHK                         ,
    CTC_DKIT_DISCARD_IPE_TUNNEL_ECN_DIS                     ,
    CTC_DKIT_DISCARD_IPE_EFM_DIS                            ,
    CTC_DKIT_DISCARD_IPE_BUF_RETRV_DIS                      ,
    CTC_DKIT_DISCARD_IPE_MPLS_ENTROPY_LABEL_CHK             ,
    CTC_DKIT_DISCARD_IPE_MPLS_TP_MCC_SCC_DIS                ,
    CTC_DKIT_DISCARD_IPE_MPLS_MC_PKT_ERROR                  ,
    CTC_DKIT_DISCARD_IPE_L2_EXCPTION_DIS                    ,
    CTC_DKIT_DISCARD_IPE_NAT_PT_CHK                         ,
    CTC_DKIT_DISCARD_IPE_RESERVED3                          ,
    CTC_DKIT_DISCARD_IPE_FEATURE_END                        = CTC_DKIT_DISCARD_IPE_RESERVED3,


    CTC_DKIT_DISCARD_IPE_END                                = CTC_DKIT_DISCARD_IPE_FEATURE_END,

   /*-----------------------  EPE   ------------------------*/
    CTC_DKIT_DISCARD_EPE_START                              ,

    CTC_DKIT_DISCARD_EPE_FEATURE_START                      = CTC_DKIT_DISCARD_EPE_START,
    CTC_DKIT_DISCARD_EPE_HDR_ADJ_DESTID_DIS                 = CTC_DKIT_DISCARD_EPE_FEATURE_START,
    CTC_DKIT_DISCARD_EPE_HDR_ADJ_PKT_ERR                    ,
    CTC_DKIT_DISCARD_EPE_HDR_ADJ_REMOVE_ERR                 ,
    CTC_DKIT_DISCARD_EPE_DS_DESTPHYPORT_DSTID_DIS           ,
    CTC_DKIT_DISCARD_EPE_PORT_ISO_DIS                       ,
    CTC_DKIT_DISCARD_EPE_DS_VLAN_TRANSMIT_DIS               ,
    CTC_DKIT_DISCARD_EPE_BRG_TO_SAME_PORT_DIS               ,
    CTC_DKIT_DISCARD_EPE_VPLS_HORIZON_SPLIT_DIS             ,
    CTC_DKIT_DISCARD_EPE_VLAN_FILTER_DIS                    ,
    CTC_DKIT_DISCARD_EPE_STP_DIS                            ,
    CTC_DKIT_DISCARD_EPE_PARSER_LEN_ERR                     ,
    CTC_DKIT_DISCARD_EPE_PBB_CHK_DIS                        ,
    CTC_DKIT_DISCARD_EPE_UC_MC_FLOODING_DIS                 ,
    CTC_DKIT_DISCARD_EPE_OAM_802_3_DIS                      ,
    CTC_DKIT_DISCARD_EPE_TTL_FAIL                           ,
    CTC_DKIT_DISCARD_EPE_REMOTE_MIRROR_ESCAP_DIS            ,
    CTC_DKIT_DISCARD_EPE_TUNNEL_MTU_CHK_DIS                 ,
    CTC_DKIT_DISCARD_EPE_INTERF_MTU_CHK_DIS                 ,
    CTC_DKIT_DISCARD_EPE_LOGIC_PORT_CHK_DIS                 ,
    CTC_DKIT_DISCARD_EPE_DS_ACL_DIS                         ,
    CTC_DKIT_DISCARD_EPE_DS_VLAN_XLATE_DIS                  ,
    CTC_DKIT_DISCARD_EPE_CRC_ERR_DIS                        ,
    CTC_DKIT_DISCARD_EPE_ROUTE_PLD_OP_DIS                   ,
    CTC_DKIT_DISCARD_EPE_BRIDGE_PLD_OP_DIS                  ,
    CTC_DKIT_DISCARD_EPE_STRIP_OFFSET_LARGE                 ,
    CTC_DKIT_DISCARD_EPE_BFD_DIS                            ,
    CTC_DKIT_DISCARD_EPE_PORT_REFLECTIVE_CHK_DIS            ,
    CTC_DKIT_DISCARD_EPE_IP_MPLS_TTL_CHK_ERR                ,
    CTC_DKIT_DISCARD_EPE_OAM_EDGE_PORT_DIS                  ,
    CTC_DKIT_DISCARD_EPE_NAT_PT_ICMP_ERR                    ,
    CTC_DKIT_DISCARD_EPE_LATENCY_DISCARD                    ,
    CTC_DKIT_DISCARD_EPE_LOCAL_OAM_DIS                      ,
    CTC_DKIT_DISCARD_EPE_OAM_FILTERING_DIS                  ,
    CTC_DKIT_DISCARD_EPE_SAME_IPDA_IPSA_DIS                 ,
    CTC_DKIT_DISCARD_EPE_RESERVED2                          ,
    CTC_DKIT_DISCARD_EPE_TRILL_PLD_OP_DIS                   ,
    CTC_DKIT_DISCARD_EPE_PBB_CHK_FAIL_DIS                   ,
    CTC_DKIT_DISCARD_EPE_DS_NEXTHOP_DATA_VIOLATE            ,
    CTC_DKIT_DISCARD_EPE_DEST_VLAN_PTR_DIS                  ,
    CTC_DKIT_DISCARD_EPE_DS_L3EDIT_DATA_VIOLATE1            ,
    CTC_DKIT_DISCARD_EPE_DS_L3EDIT_DATA_VIOLATE2            ,
    CTC_DKIT_DISCARD_EPE_DS_L3EDITNAT_DATA_VIOLATE          ,
    CTC_DKIT_DISCARD_EPE_DS_L2EDIT_DATA_VIOLATE1            ,
    CTC_DKIT_DISCARD_EPE_DS_L2EDIT_DATA_VIOLATE2            ,
    CTC_DKIT_DISCARD_EPE_PKT_HDR_C2C_TTL_ZERO               ,
    CTC_DKIT_DISCARD_EPE_PT_UDP_CHKSUM_ZERO                 ,
    CTC_DKIT_DISCARD_EPE_OAM_TO_LOCAL_DIS                   ,
    CTC_DKIT_DISCARD_EPE_HARD_ERROR_DIS                     ,
    CTC_DKIT_DISCARD_EPE_MICROFLOW_POLICING_FAIL_DROP       ,
    CTC_DKIT_DISCARD_EPE_ARP_MISS_DISCARD                   ,
    CTC_DKIT_DISCARD_EPE_RESERVED                           ,
    CTC_DKIT_DISCARD_EPE_FEATURE_END                        = CTC_DKIT_DISCARD_EPE_RESERVED,


    CTC_DKIT_DISCARD_EPE_HW_START                           ,
    CTC_DKIT_DISCARD_EPE_HW_HAR_ADJ                         = CTC_DKIT_DISCARD_EPE_HW_START,
    CTC_DKIT_DISCARD_EPE_HW_NEXT_HOP                        ,
    CTC_DKIT_DISCARD_EPE_HW_L2_EDIT                         ,
    CTC_DKIT_DISCARD_EPE_HW_L3_EDIT                         ,
    CTC_DKIT_DISCARD_EPE_HW_INNER_L2                        ,
    CTC_DKIT_DISCARD_EPE_HW_PAYLOAD                         ,
    CTC_DKIT_DISCARD_EPE_HW_ACL_OAM                         ,
    CTC_DKIT_DISCARD_EPE_HW_CLASS                           ,
    CTC_DKIT_DISCARD_EPE_HW_OAM                             ,
    CTC_DKIT_DISCARD_EPE_HW_EDIT                            ,
    CTC_DKIT_DISCARD_EPE_HW_END                             = CTC_DKIT_DISCARD_EPE_HW_EDIT,


    CTC_DKIT_DISCARD_EPE_END                                = CTC_DKIT_DISCARD_EPE_HW_END,

   /*-----------------------  BSR   ------------------------*/
    CTC_DKIT_DISCARD_BSR_START                              ,
    CTC_DKIT_DISCARD_BSR_BUFSTORE_HW_ABORT                  = CTC_DKIT_DISCARD_BSR_START,
    CTC_DKIT_DISCARD_BSR_BUFSTORE_HW_LEN_ERROR              ,
    CTC_DKIT_DISCARD_BSR_BUFSTORE_HW_SILENT                 ,
    CTC_DKIT_DISCARD_BSR_BUFSTORE_HW_IGR_RESRC              ,
    CTC_DKIT_DISCARD_BSR_BUFSTORE_HW_DATA_ERR               ,
    CTC_DKIT_DISCARD_BSR_BUFSTORE_HW_CHIP_MISMATCH          ,
    CTC_DKIT_DISCARD_BSR_BUFSTORE_HW_NO_BUFF                ,
    CTC_DKIT_DISCARD_BSR_QMGR_RESERVE_CHANNEL               ,
    CTC_DKIT_DISCARD_BSR_QMGR_CRITICAL                      ,
    CTC_DKIT_DISCARD_BSR_QMGR_C2C                           ,
    CTC_DKIT_DISCARD_BSR_QMGR_CHANNEL_AGG_NO_MEMBER         ,
    CTC_DKIT_DISCARD_BSR_QMGR_LINK_AGG_NO_MEMBER            ,
    CTC_DKIT_DISCARD_BSR_QMGR_MCAST_AGG_NO_MEMBER           ,
    CTC_DKIT_DISCARD_BSR_QMGR_STACKING                      ,
    CTC_DKIT_DISCARD_BSR_QMGR_NO_Q                          ,
    CTC_DKIT_DISCARD_BSR_QMGR_IN_Q                          ,
    CTC_DKIT_DISCARD_BSR_QMGR_EGR_RESRC                     ,
    CTC_DKIT_DISCARD_BSR_QMGR_OTHER                         ,
    CTC_DKIT_DISCARD_BSR_END                                = CTC_DKIT_DISCARD_BSR_QMGR_OTHER,

   /*-----------------------  NETRX   ----------------------*/
    CTC_DKIT_DISCARD_NETRX_START                            ,
    CTC_DKIT_DISCARD_NETRX_NO_BUFFER                        = CTC_DKIT_DISCARD_NETRX_START,
    CTC_DKIT_DISCARD_NETRX_LEN_ERROR                        ,
    CTC_DKIT_DISCARD_NETRX_PKT_ERROR                        ,
    CTC_DKIT_DISCARD_NETRX_BPDU_ERROR                       ,
    CTC_DKIT_DISCARD_NETRX_END                              = CTC_DKIT_DISCARD_NETRX_BPDU_ERROR,

   /*-----------------------  NETTX   ----------------------*/
    CTC_DKIT_DISCARD_NETTX_START                            ,
    CTC_DKIT_DISCARD_NETTX_MIN_LEN                          = CTC_DKIT_DISCARD_NETTX_START,
    CTC_DKIT_DISCARD_NETTX_NO_BUFFER                        ,
    CTC_DKIT_DISCARD_NETTX_SOP_EOP                          ,
    CTC_DKIT_DISCARD_NETTX_PI_ERROR                         ,
    CTC_DKIT_DISCARD_NETTX_END                              = CTC_DKIT_DISCARD_NETTX_PI_ERROR,

   /*-----------------------   OAM   ------------------------*/
    CTC_DKIT_DISCARD_OAM_START                              ,
    CTC_DKIT_DISCARD_OAM_LINK_AGG_NO_MEMBER                 = CTC_DKIT_DISCARD_OAM_START,
    CTC_DKIT_DISCARD_OAM_HW_ERROR                           ,
    CTC_DKIT_DISCARD_OAM_EXCEPTION                          ,
    CTC_DKIT_DISCARD_OAM_END                                = CTC_DKIT_DISCARD_OAM_EXCEPTION,

    CTC_DKIT_DISCARD_MAX/**< */

};

typedef enum ctc_dkit_discard_reason_id_e ctc_dkit_discard_reason_id_t;


struct ctc_dkit_discard_stats_s
{
    uint16 cnt[CTC_DKIT_DISCARD_MAX];
};
typedef struct ctc_dkit_discard_stats_s ctc_dkit_discard_stats_t;


enum ctc_dkit_discard_flag_e
{
    CTC_DKIT_DISCARD_FLAG_NONE = 0x00,
    CTC_DKIT_DISCARD_FLAG_IPE=0x01,
    CTC_DKIT_DISCARD_FLAG_EPE=0x02,
    CTC_DKIT_DISCARD_FLAG_BSR=0x04,
    CTC_DKIT_DISCARD_FLAG_OAM=0x08,
    CTC_DKIT_DISCARD_FLAG_NET_RX=0x10,
    CTC_DKIT_DISCARD_FLAG_NET_TX=0x20
} ;
typedef enum ctc_dkit_discard_flag_e ctc_dkit_discard_flag_t;


struct ctc_dkit_discard_reason_s
{
    uint8 module;/*indicate which module discard packet, only one module valid, refer to ctc_dkit_discard_flag_t*/
    uint8 rsv;
    uint16 port;

    uint32 reason_id;
};
typedef struct ctc_dkit_discard_reason_s ctc_dkit_discard_reason_t;


enum ctc_dkit_discard_value_type_e
{
    CTC_DKIT_DISCARD_VALUE_TYPE_NONE = 0,
    CTC_DKIT_DISCARD_VALUE_TYPE_1,    /*1 valid value*/
    CTC_DKIT_DISCARD_VALUE_TYPE_2,    /*2 valid value*/
    CTC_DKIT_DISCARD_VALUE_TYPE_3,    /*3 valid value*/

} ;
typedef enum ctc_dkit_discard_value_type_e ctc_dkit_discard_value_type_t;

struct ctc_dkit_discard_reason_bus_s
{
    uint32 reason_id;

    uint16 gport;/*ctc global port*/
    uint8 value_type;  /*ctc_dkit_discard_value_type_t*/
    uint8 valid;

    uint32 value[4];/*some value used for show reason*/
};
typedef struct ctc_dkit_discard_reason_bus_s ctc_dkit_discard_reason_bus_t;


struct ctc_dkit_discard_reason_captured_s
{
    uint32 reason_id;

    uint8 value_type;  /*ctc_dkit_discard_value_type_t*/
    uint8 rsv[3];

    uint32 value[4];/*some value used for show reason*/
};
typedef struct ctc_dkit_discard_reason_captured_s ctc_dkit_discard_reason_captured_t;


#define CTC_DKIT_DISCARD_REASON_NUM 16
struct ctc_dkit_discard_info_s
{
      char systime_str[50];

      uint8 discard_flag; /*indicate which module discard packet, refer to ctc_dkit_discard_flag_t*/
      uint8 discard_count; /*if discard_count>1, can not use bus info*/
      uint8 slice_ipe; /*only for read bus*/
      uint8 slice_epe;
      uint8 lchip;

      ctc_dkit_discard_reason_t discard_reason[CTC_DKIT_DISCARD_MAX];
      ctc_dkit_discard_reason_bus_t discard_reason_bus;
      ctc_dkit_discard_reason_captured_t discard_reason_captured;
};
typedef struct ctc_dkit_discard_info_s ctc_dkit_discard_info_t;

#define CTC_DKIT_DISCARD_HISTORY_NUM  8
struct ctc_dkit_discard_history_s
{
    ctc_dkit_discard_info_t discard[CTC_DKIT_DISCARD_HISTORY_NUM];
    uint8 front;
    uint8 rear;/*the position is empty*/
};
typedef struct ctc_dkit_discard_history_s ctc_dkit_discard_history_t;


extern const char *
ctc_goldengate_dkit_get_reason_desc(ctc_dkit_discard_reason_id_t reason_id);

extern int32
ctc_goldengate_dkit_discard_process(void* p_para);

extern int32
ctc_goldengate_dkit_discard_show_type(void* p_para);

#ifdef __cplusplus
}
#endif

#endif









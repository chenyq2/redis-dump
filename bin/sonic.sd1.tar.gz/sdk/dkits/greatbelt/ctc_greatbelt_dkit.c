#include "drv_lib.h"
#include "ctc_cli.h"
#include "ctc_dkit.h"
#include "ctc_dkit_common.h"

#include "ctc_greatbelt_dkit.h"
#include "ctc_greatbelt_dkit_memory.h"
#include "ctc_greatbelt_dkit_drv.h"
#include "ctc_greatbelt_dkit_misc.h"
#include "ctc_greatbelt_dkit_internal.h"
#include "ctc_greatbelt_dkit_monitor.h"
#include "ctc_greatbelt_dkit_discard.h"
#include "ctc_greatbelt_dkit_dump_cfg.h"
#include "ctc_greatbelt_dkit_tcam.h"

ctc_dkit_master_t* g_dkit_master[CTC_DKITS_MAX_LOCAL_CHIP_NUM] = {NULL};
ctc_dkit_api_t* g_dkit_api = NULL;
ctc_dkit_chip_api_t* g_dkit_chip_api = NULL;

int32 ctc_dkit_chip_init(void)
{
    if (g_dkit_chip_api == NULL)
    {
        return CLI_ERROR;
    }

    g_dkit_chip_api->dkits_dump_decode_entry = ctc_greatbelt_dkits_dump_decode_entry;
    return 0;
}

int32 ctc_dkit_init(void)
{
    uint8 lchip = 0;

    g_dkit_api = (ctc_dkit_api_t*)mem_malloc(MEM_CLI_MODULE, sizeof(ctc_dkit_api_t));
    if (NULL == g_dkit_api)
    {
        CTC_DKIT_PRINT("No memory for dkits!!!\n");
        goto ERROE;
    }

    g_dkit_chip_api = (ctc_dkit_chip_api_t*)mem_malloc(MEM_CLI_MODULE, sizeof(ctc_dkit_chip_api_t));
    if (NULL == g_dkit_chip_api)
    {
        CTC_DKIT_PRINT("No memory for dkits!!!\n");
        goto ERROE;
    }

    sal_memset(g_dkit_api, 0 , sizeof(ctc_dkit_api_t));
    sal_memset(g_dkit_chip_api, 0 , sizeof(ctc_dkit_chip_api_t));

    for (lchip = 0; lchip < CTC_DKITS_MAX_LOCAL_CHIP_NUM; lchip++)
    {
        g_dkit_master[lchip] = (ctc_dkit_master_t*)mem_malloc(MEM_CLI_MODULE, sizeof(ctc_dkit_master_t));
        if (NULL == g_dkit_master[lchip])
        {
            CTC_DKIT_PRINT("No memory for dkits!!!\n");
            goto ERROE;
        }
        sal_memset(g_dkit_master[lchip], 0 , sizeof(ctc_dkit_master_t));
    }


    /*register API*/
    /*1. Basic*/
    g_dkit_api->memory_process = ctc_greatbelt_dkit_memory_process;

    /*2. Normal*/
    g_dkit_api->show_path = ctc_greatbelt_dkit_path_process;
    g_dkit_api->show_discard = ctc_greatbelt_dkit_discard_process;
    g_dkit_api->show_discard_type = ctc_greatbelt_dkit_discard_show_type;

    /*3. Advanced*/
    g_dkit_api->show_sensor_result = ctc_greatbelt_dkit_monitor_show_sensor_result;
    g_dkit_api->show_queue_id = ctc_greatbelt_dkit_monitor_show_queue_id;
    g_dkit_api->show_queue_depth = ctc_greatbelt_dkit_monitor_show_queue_depth;
    g_dkit_api->serdes_ctl = ctc_greatbelt_dkit_misc_serdes_ctl;
    g_dkit_api->integrity_check = ctc_greatbelt_dkit_misc_integrity_check;
    g_dkit_api->packet_dump = ctc_greatbelt_dkit_misc_packet_dump;

    g_dkit_api->tcam_scan = ctc_greatbelt_dkits_tcam_scan;
    g_dkit_api->tcam_capture_start = ctc_greatbelt_dkits_tcam_capture_start;
    g_dkit_api->tcam_capture_stop = ctc_greatbelt_dkits_tcam_capture_stop;
    g_dkit_api->tcam_capture_show = ctc_greatbelt_dkits_tcam_capture_show;
    g_dkit_api->cfg_usage = ctc_greatbelt_dkits_dump_memory_usage;
    g_dkit_api->cfg_dump = ctc_greatbelt_dkits_dump_cfg_dump;
    g_dkit_api->cfg_decode = ctc_greatbelt_dkits_dump_cfg_decode;
    g_dkit_api->cfg_cmp = ctc_greatbelt_dkits_dump_cfg_cmp;

    ctc_dkit_chip_init();

    ctc_greatbelt_dkit_internal_cli_init(CTC_DKITS_MODE);
    ctc_greatbelt_dkit_drv_register();
    return CLI_SUCCESS;
ERROE:
    CTC_DKIT_PRINT("Dkits init fail!!!\n");
    if (g_dkit_api)
    {
        mem_free(g_dkit_api);
        g_dkit_api = NULL;
    }

    if (g_dkit_chip_api)
    {
        mem_free(g_dkit_chip_api);
        g_dkit_chip_api = NULL;
    }

    for (lchip = 0; lchip < CTC_DKITS_MAX_LOCAL_CHIP_NUM; lchip++)
    {
        if (g_dkit_master[lchip])
        {
            mem_free(g_dkit_master[lchip]);
            g_dkit_master[lchip] = NULL;
        }
    }

    return CLI_SUCCESS;
}


#include "sal.h"
#include "ctc_greatbelt_dkit_discard_type.h"

const char *ctc_greatbelt_dkit_get_reason_desc(ctc_dkit_discard_reason_id_t reason_id)
{
    static char  reason_desc[256+1] = {0};
    if (reason_id == CTC_DKIT_DISCARD_INVALIED)
    {
        return " ";
    }

    switch(reason_id)
    {
     case CTC_DKIT_IPE_USER_ID_BINDING_DISCARD:  
       return "The data in packet is not as SCL config, such as MAC DA, port, vlan, IP SA";   
     case CTC_DKIT_IPE_HDR_ADJ_BYTE_RMV_ERR_DISCARD:  
       return "Loopback Header Adjust byte remove error discard";   
     case CTC_DKIT_IPE_PSR_LEN_ERR:  
       return "Parser length error discard";   
     case CTC_DKIT_IPE_MAC_ISOLATED_DISCARD:  
       return "MAC Isolated Discard";   
     case CTC_DKIT_IPE_EXCEP_2_DISCARD:  
       return "Exception 2 discard";   
     case CTC_DKIT_IPE_USER_ID_DISCARD:  
       return "SCL config as discard";   
     case CTC_DKIT_IPE_PORT_OR_DS_VLAN_RCV_DIS:  
       return "Port/DsVlan receive disable discard";   
     case CTC_DKIT_IPE_ITAG_CHK_FAIL:  
       return "ITag check failure, or invalid bmac, or loop MacSa of PIP port type in PBB";   
     case CTC_DKIT_IPE_PTL_VLAN_DISCARD:  
       return "Portocol VLAN discard";   
     case CTC_DKIT_IPE_VLAN_TAG_CTL_DISCARD:  
       return "AFT discard";   
     case CTC_DKIT_IPE_NOT_ALLOW_MCAST_MAC_SA_DISCARD:  
       return "Mcast Mac SA/Same Mac SA DA/Same IP Da Sa discard/TCP Or UDP Header Error/ ICMP fragment packet/mismatch GRE version";   
     case CTC_DKIT_IPE_STP_DISCARD:  
       return "STP discard";   
     case CTC_DKIT_IPE_RESERVED0:  
       return "Reserved";   
     case CTC_DKIT_IPE_PBB_OAM_DISCARD:  
       return "PBB OAM discard";   
     case CTC_DKIT_IPE_ARP_DHCP_DISCARD:  
       return "ARP/DHCP/FIP discard";   
     case CTC_DKIT_IPE_DS_PHYPORT_SRC_DISCARD:  
       return "Ingress phyport discard";   
     case CTC_DKIT_IPE_VLAN_STATUS_FILTER_DISCARD:  
       return "Vlan filtering discard";   
     case CTC_DKIT_IPE_ACLQOS_DISCARD_PKT:  
       return "ACL deny discard";   
     case CTC_DKIT_IPE_ROUTING_MCAST_IP_ADDR_CHK_DISCARD:  
       return "Routing multicast IP address check discard or IP Protocal Translation discard";   
     case CTC_DKIT_IPE_BRG_BPDU_ETC_DISCARD:  
       return "Bridge Port Match or unknow Mcast/Ucast MAC address discard";   
     case CTC_DKIT_IPE_STORM_CTL_DISCARD:  
       return "Storm Control discard";   
     case CTC_DKIT_IPE_LEARNING_DISCARD:  
       return "MAC Sa discard/MAC Move/exceed to mac limit";   
     case CTC_DKIT_IPE_POLICING_DISCARD:  
       return "Policing discard";   
     case CTC_DKIT_IPE_NO_FWD_PTR_DISCARD:  
       return "Not find next hop, no dsFwdPtr";   
     case CTC_DKIT_IPE_FWD_PTR_ALL_F_OR_VALID_DISCARD:  
       return "Next hop index is invalid";   
     case CTC_DKIT_IPE_FATAL_EXCEPTION_DSCD:  
       return "Fatal Exception discard";   
     case CTC_DKIT_IPE_APS_DISCARD:  
       return "APS bridge or select discard";   
     case CTC_DKIT_IPE_FWD_DEST_ID_DISCARD:  
       return "DestId Discard";   
     case CTC_DKIT_IPE_RESERVED1:  
       return "Reserved";   
     case CTC_DKIT_IPE_HDR_AJUST_SMALL_PKT_DISCARD:  
       return "Header Adjust small packet discard";   
     case CTC_DKIT_IPE_HDR_ADJUST_PKT_ERR:  
       return "Header Adjust packet error";   
     case CTC_DKIT_IPE_TRILL_ESADI_PKT_DISCARD:  
       return "TRILL OAM packet discard, send to CPU";   
     case CTC_DKIT_IPE_LOOPBACK_DISCARD:  
       return "Loopback discard";   
     case CTC_DKIT_IPE_EFM_DISCARD:  
       return "EFM OAM packet discard, send to CPU";   
     case CTC_DKIT_IPE_CAPWAP_FROM_AC_ERR_OR_UNEXPECTABLE:  
       return "CAPWAP form AC error discard, CAPWAP unexpectable discard";   
     case CTC_DKIT_IPE_STACKING_NETWORK_HEADER_CHK_ERR:  
       return "Stacking network header check error";   
     case CTC_DKIT_IPE_TRILL_FILTER_ERR:  
       return "TRILL filter discard / invalid TRILL MacDa on edge port";   
     case CTC_DKIT_IPE_CAPWAP_CONTROL_EXCEPTION:  
       return "CAPWAP control exception discard, send to CPU";   
     case CTC_DKIT_IPE_L3_EXCEPTION:  
       return "L3 exception discard, send to CPU";   
     case CTC_DKIT_IPE_L2_EXCEPTION:  
       return "L2 exception discard, send to CPU";   
     case CTC_DKIT_IPE_TRILL_MCAST_ADDR_CHK_ERR:  
       return "TRILL Mcast address check error discard";   
     case CTC_DKIT_IPE_TRILL_VERSION_CHK_ERR:  
       return "TRILL version check error / inner VLAN ID check discard";   
     case CTC_DKIT_IPE_PTP_VERSION_CHK_ERR:  
       return "PTP version check error discard";   
     case CTC_DKIT_IPE_PTPT_P2P_TRANS_CLOCK_DELAY_DISCARD:  
       return "PTPT P2P transparent clock discard delay";   
     case CTC_DKIT_IPE_OAM_NOT_FOUND_DISCARD:  
       return "OAM MEP not found discard";   
     case CTC_DKIT_IPE_OAM_STP_VLAN_FILTER_DISCARD:  
       return "OAM STP/VLAN filter discard";   
     case CTC_DKIT_IPE_BFD_SINGLE_HOP_OAM_TTL_CHK_ERR:  
       return "BFD single hop OAM TTL check error discard";   
     case CTC_DKIT_IPE_CAPWAP_DTLS_DISCARD:  
       return "CAPWAP DTLS discard";   
     case CTC_DKIT_IPE_NO_MEP_MIP_DISCARD:  
       return "No MEP/MIP discard";   
     case CTC_DKIT_IPE_OAM_DIS:  
       return "MPLS OAM disable discard";   
     case CTC_DKIT_IPE_PBB_DECAP_DISCARD:  
       return "PBB decap discard";   
     case CTC_DKIT_IPE_MPLS_TMPLS_OAM_DISCARD:  
       return "MPLS/T-MPLS OAM discard";   
     case CTC_DKIT_IPE_MPLSTP_MCC_SCC_DISCARD:  
       return "MPLS-TP MCC/SCC discard, send to CPU";   
     case CTC_DKIT_IPE_ICMP_ERR_MSG_DISCARD:  
       return "ICMP error message discard, send to CPU";   
     case CTC_DKIT_IPE_PTP_ACL_EXCEPTION:  
       return "PTP ACL exception discard";   
     case CTC_DKIT_IPE_ETHER_SERVICE_OAM_DISCARD:  
       return "Ethernet service OAM without vlan tag discard";   
     case CTC_DKIT_IPE_LINK_OAM_DISCARD:  
       return "Ethernet link OAM with vlan tag discard";   
     case CTC_DKIT_IPE_TUNNEL_DECAP_OUTER_MARTIAN_ADDR_DISCARD:  
       return "Tunnel Decap outer header martian address discard";   
     case CTC_DKIT_IPE_CAPWAP_BSSID_LKP_OR_LOGIC_PORT_CHK_DISCARD:  
       return "CAPWAP BSSID lookup failure discard / CAPWAP logic port check discard";   
     case CTC_DKIT_IPE_USER_ID_FWD_PTR_ALL_F_DISCARD:  
       return "Tunnel discard forwarding pointer discard";   
     case CTC_DKIT_IPE_CAPWAP_FRAGMEN_DISCARD:  
       return "CAPWAP Fragment discard";   
     case CTC_DKIT_IPE_TRILL_RPF_CHK_FAIL:  
       return "TRILL RPF check fail discard";   
     case CTC_DKIT_IPE_MUX_PORT_ERR:  
       return "Mux Port error discard";   
     case CTC_DKIT_IPE_RESERVED2:  
       return "Reserved";   
     case CTC_DKIT_IPE_HW_HAR_ADJ:  
       return "some hardware error occurred at header adjust";   
     case CTC_DKIT_IPE_HW_INT_MAP:  
       return "some hardware error occurred at interface mapper";   
     case CTC_DKIT_IPE_HW_LKUP:  
       return "some hardware error occurred at lookup manager ";   
     case CTC_DKIT_IPE_HW_PKT_PROC:  
       return "some hardware error occurred when do packet process";   
     case CTC_DKIT_IPE_HW_PKT_FWD:  
       return "some hardware error occurred at forward";   
     case CTC_DKIT_IPE_MAX:  
       return "";   
     case CTC_DKIT_EPE_EPE_HDR_ADJ_DEST_ID_DISCARD:  
       return "EPE Bridge header destId Dicard";   
     case CTC_DKIT_EPE_EPE_HDR_ADJ_PKT_ERR_DISCARD:  
       return "EPE Header Adjust pktErr discard";   
     case CTC_DKIT_EPE_EPE_HDR_ADJ_BYTE_REMOVE_ERR:  
       return "EPE Header Adjust byte remove error discard";   
     case CTC_DKIT_EPE_DEST_PHY_PORT_DEST_ID_DISCARD:  
       return "DestPort Discard";   
     case CTC_DKIT_EPE_PORT_ISOLATE_DISCARD:  
       return "Port isolate discard";   
     case CTC_DKIT_EPE_DS_VLAN_TRANS_DIS:  
       return "Port/DsVlan transmit disable discard";   
     case CTC_DKIT_EPE_BRG_TO_SAME_PORT_DISCARD:  
       return "Bridge to same port discard";   
     case CTC_DKIT_EPE_VPLS_HORIZON_SPLIT_DISCARD:  
       return "VPLS horizon  split or E-tree discard";   
     case CTC_DKIT_EPE_EGRESS_VLAN_FILTER_DISCARD:  
       return "Egress VLAN filter discard";   
     case CTC_DKIT_EPE_EGRESS_STP_DISCARD:  
       return "Egress STP discard";   
     case CTC_DKIT_EPE_EGRESS_PARSER_LEN_ERR_DISCARD:  
       return "Egress parser length error discard ";   
     case CTC_DKIT_EPE_EGRESS_PBB_CHK_DISCARD:  
       return "Egress PBB check discard ";   
     case CTC_DKIT_EPE_UCAST_MCAST_FLOOD_DISCARD:  
       return "Discard unkown Unicast/mcast/broadcast on edge port ";   
     case CTC_DKIT_EPE_802_3_OAM_DISCARD:  
       return "Discard non-EFM OAM packet ";   
     case CTC_DKIT_EPE_EGRESS_TTL_FAIL:  
       return "Egress TTL failed discard ";   
     case CTC_DKIT_EPE_REMOTE_MIRROR_ESCAPE_DISCARD:  
       return "Remote mirror filtering discard ";   
     case CTC_DKIT_EPE_TUNNEL_MTU_CHK_DISCARD:  
       return "Tunnel MTU check discard ";   
     case CTC_DKIT_EPE_INTERFACE_MTU_CHK_DISCARD:  
       return "Interface MTU check discard ";   
     case CTC_DKIT_EPE_LOGIC_PORT_CHK_DISCARD:  
       return "Logic port check discard ";   
     case CTC_DKIT_EPE_EGRESS_ACL_DISCARD:  
       return "Egress ACL deny ";   
     case CTC_DKIT_EPE_EGRESS_QOS_DISCARD:  
       return "Egress QoS discard ";   
     case CTC_DKIT_EPE_EGRESS_POLICING_DISCARD:  
       return "Egress policing discard ";   
     case CTC_DKIT_EPE_CRC_ERR:  
       return "Egress CRC error ";   
     case CTC_DKIT_EPE_ROUTE_PAYLOAD_OPERATION_DISCARD:  
       return "Route Payload operation no IP packet discard ";   
     case CTC_DKIT_EPE_BRG_PAYLOAD_OPERATION_DISCARD:  
       return "Bridge payload operation bridge disable discard ";   
     case CTC_DKIT_EPE_PT_LAYER4_OFFSET_LAGER_DISCARD:  
       return "Packet edit strip too large discard ";   
     case CTC_DKIT_EPE_BFD_DISCARD:  
       return "BFD discard ";   
     case CTC_DKIT_EPE_PORT_REFLECTIVE_CHK_DISCARD:  
       return "Port reflective check discard ";   
     case CTC_DKIT_EPE_IP_MPLS_TTL_CHK_ERR_DISCARD:  
       return "IP/MPLS TTL check error discard ";   
     case CTC_DKIT_EPE_OAM_EGDE_PORT_DISCARD:  
       return "OAM edge port discard ";   
     case CTC_DKIT_EPE_NAT_PT_ICMP_ERR:  
       return "NAT/PT ICMP error discard ";   
     case CTC_DKIT_EPE_RESERVED0:  
       return "Reserved";   
     case CTC_DKIT_EPE_LOCAL_OAM_DISCARD:  
       return "local OAM discard ";   
     case CTC_DKIT_EPE_OAM_FILTERING_DISCARD:  
       return "OAM filtering discard ";   
     case CTC_DKIT_EPE_OAM_HASH_CONFILICT_DISCARD:  
       return "OAM hash confilict discard ";   
     case CTC_DKIT_EPE_IPDA_EQUALS_TO_IPSA_DISCARD:  
       return "Same Mac Da Sa or IP da sa discard ";   
     case CTC_DKIT_EPE_RESERVED1:  
       return "Reserved ";   
     case CTC_DKIT_EPE_TRILL_PAYLOAD_OPERATION_DISCARD:  
       return "TRILL payload operation discard ";   
     case CTC_DKIT_EPE_PBB_CHK_FAIL_DISCARD:  
       return "PBB check fail discard ";   
     case CTC_DKIT_EPE_DS_NEXT_HOP_DATA_VIOLATE:  
       return "DsNextHop data violate ";   
     case CTC_DKIT_EPE_DEST_VLAN_PTR_DISCARD:  
       return "destVlanPtr discard";   
     case CTC_DKIT_EPE_DS_L3_EDIT_DATA_VIOLATE_1:  
       return "discard by DsL3Edit";   
     case CTC_DKIT_EPE_DS_L3_EDIT_DATA_VIOLATE_2:  
       return "discard by DsL3Edit";   
     case CTC_DKIT_EPE_DS_L3_EDIT_NAT_DATA_VIOLATE:  
       return "discard by DsL3EditNat ";   
     case CTC_DKIT_EPE_DS_L2_EDIT_DATA_VIOLATE_1:  
       return "discard by DsL2Edit";   
     case CTC_DKIT_EPE_DS_L2_EDIT_DATA_VIOLATE_2:  
       return "discard by DsL2Edit";   
     case CTC_DKIT_EPE_PACKET_HEADER_C2C_TTL_ZERO:  
       return "PacketHeader C2C TTL zero ";   
     case CTC_DKIT_EPE_PT_UDP_CHECKSUM_IS_ZERO:  
       return "PT UDP checksum is zero ";   
     case CTC_DKIT_EPE_OAM_TO_LOCAL_DISCARD:  
       return "OAM to local discard ";   
     case CTC_DKIT_EPE_HW_HAR_ADJ:  
       return "some hardware error occurred at header adjust";   
     case CTC_DKIT_EPE_HW_NEXT_HOP:  
       return "some hardware error occurred at nexthop mapper";   
     case CTC_DKIT_EPE_HW_ACL_QOS:  
       return "some hardware error occurred when do ACL or QoS";   
     case CTC_DKIT_EPE_HW_OAM:  
       return "some hardware error occurred when do OAM process";   
     case CTC_DKIT_EPE_HW_EDIT:  
       return "some hardware error occurred at header edit";   
     case CTC_DKIT_EPE_MAX:  
       return "";   
     case CTC_DKIT_BSR_BUFSTORE_HW_ABORT:  
       return "ipe discard or hardware error at BUFSTORE, read PktErrStatsMem to confirm";   
     case CTC_DKIT_BSR_BUFSTORE_HW_LEN_ERROR:  
       return "packet length error at BUFSTORE, read PktErrStatsMem to confirm";   
     case CTC_DKIT_BSR_BUFSTORE_HW_SILENT:  
       return "hardware error at BUFSTORE, read PktErrStatsMem to confirm";   
     case CTC_DKIT_BSR_BUFSTORE_HW_DATA_ERR:  
       return "data error at BUFSTORE, read PktErrStatsMem to confirm";   
     case CTC_DKIT_BSR_BUFSTORE_HW_CHIP_MISMATCH:  
       return "chip mismatch at BUFSTORE, read PktErrStatsMem to confirm";   
     case CTC_DKIT_BSR_BUFSTORE_HW_NO_BUFF:  
       return "no buffer at BUFSTORE, read PktErrStatsMem to confirm";   
     case CTC_DKIT_BSR_BUFSTORE_HW_OTHER:  
       return "drop at BUFSTORE, read PktErrStatsMem to confirm";   
     case CTC_DKIT_BSR_QMGR_CRITICAL:  
       return "critical packet discard at QMGR, read QMgrEnqDebugStats to confirm";   
     case CTC_DKIT_BSR_QMGR_C2C:  
       return "C2C packet discard at QMGR, read QMgrEnqDebugStats to confirm";   
     case CTC_DKIT_BSR_QMGR_IN_Q:  
       return "Enqueue discard at QMGR, read QMgrEnqDebugStats to confirm";   
     case CTC_DKIT_BSR_QMGR_EGR_RESRC:  
       return "egress resource manager discard at QMGR, read QMgrEnqDebugStats to confirm";   
     case CTC_DKIT_BSR_QMGR_OTHER:  
       return "drop at QMGR, read QMgrEnqDebugStats to confirm";   
     case CTC_DKIT_BSR_MAX:  
       return "";   
     case CTC_DKIT_NETRX_NO_BUFFER:  
       return "buffer is full, read NetRxDebugStats to confirm";   
     case CTC_DKIT_NETRX_LEN_ERROR:  
       return "packet length error, read NetRxDebugStats to confirm";   
     case CTC_DKIT_NETRX_PKT_ERROR:  
       return "packet or frame error, read NetRxDebugStats to confirm";   
     case CTC_DKIT_NETRX_SOP_EOP:  
       return "sop/eop error discard, read NetRxDebugStats to confirm";   
     case CTC_DKIT_NETRX_MAX:  
       return "";   
     case CTC_DKIT_NETTX_MIN_LEN:  
       return "packet length is too short, read NetTxDebugStats to confirm";   
     case CTC_DKIT_NETTX_NO_BUFFER:  
       return "buffer is full, read NetTxDebugStats to confirm";   
     case CTC_DKIT_NETTX_SOP_EOP:  
       return "sop/eop error discard, read NetTxDebugStats to confirm";   
     case CTC_DKIT_NETTX_PI_ERROR:  
       return "packet info error, read NetTxDebugStats to confirm";   
     case CTC_DKIT_NETTX_MAX:  
       return "";   
     case CTC_DKIT_OAM_HW_ERROR:  
       return "some hardware error occured";   
     case CTC_DKIT_OAM_MAX:  
       return "";   
      default:
      sal_sprintf(reason_desc,"Reason id:%d",reason_id);
      return reason_desc;
    }

}

const char *ctc_greatbelt_dkit_get_sub_reason_desc(ctc_dkit_discard_sub_reason_id_t reason_id)
{
    static char  reason_desc[256+1] = {0};
    if (reason_id == CTC_DKIT_SUB_DISCARD_INVALIED)
    {
        return " ";
    }

    switch(reason_id)
    {
     case CTC_DKIT_SUB_DISCARD_INVALIED:  
       return "no discard";   
     case CTC_DKIT_SUB_DISCARD_AMBIGUOUS:  
       return "the discard reason is ambiguous, try to use captured info";   
     case CTC_DKIT_SUB_DISCARD_NEED_PARAM:  
       return "please input filter param to get the detail reason";   
      default:
      sal_sprintf(reason_desc,"Sub reason id:%d",reason_id);
      return reason_desc;
    }

}


#ifndef _CTC_DKIT_GREATBELT_MEMORY_H
#define _CTC_DKIT_GREATBELT_MEMORY_H
#ifdef __cplusplus
extern "C" {
#endif

#include "sal.h"
#include "ctc_cli.h"
#include "ctc_dkit.h"

extern int32
ctc_greatbelt_dkit_memory_process(void* p_para);

extern int32
ctc_greatbelt_dkit_memory_is_invalid_table(uint32 tbl_id);

#ifdef __cplusplus
}
#endif

#endif



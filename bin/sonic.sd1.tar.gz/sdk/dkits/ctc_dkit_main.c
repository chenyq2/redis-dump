
#include "sal.h"
#include "dal.h"
#include "drv_ftm.h"

#include "ctc_dkit_cli.h"
#include "ctc_cli.h"

extern int32 dal_set_device_access_type(dal_access_type_t device_type);
extern int32 dal_op_init(dal_op_t* p_dal_op);
extern int32 drv_init(uint8 lchip, uint8 base);

uint8 cli_end = 0;

void
ctc_cli_mode_exit(void)
{
    switch (g_ctc_vti->node)
    {
    case EXEC_MODE:
        g_ctc_vti->quit(g_ctc_vti);
        break;

    case CTC_DKITS_MODE:
        g_ctc_vti->node = EXEC_MODE;
        break;

    default:
        g_ctc_vti->node = EXEC_MODE;
        break;

        break;
    }
}

CTC_CLI(exit_config,
        exit_cmd,
        "exit",
        "End current mode and down to previous mode")
{
    ctc_cli_mode_exit();
    return CLI_SUCCESS;
}

CTC_CLI(quit_config,
        quit_cmd,
        "quit",
        "Exit current mode and down to previous mode")
{
    ctc_cli_mode_exit();
    return CLI_SUCCESS;
}

ctc_cmd_node_t dkit_node =
{
    CTC_DKITS_MODE,
    "\rCTC_CLI(ctc-dkits)# ",
};

ctc_cmd_node_t sdk_node =
{
    CTC_SDK_MODE,
    "\rCTC_CLI(ctc-dkits)# ",
};

ctc_cmd_node_t exec_node =
{
    EXEC_MODE,
    "\rCTC_CLI# ",
};

int ctc_master_printf(struct ctc_vti_struct_s* vti, const char *szPtr, const int szPtr_len)
{
    sal_write(0,(void*)szPtr,szPtr_len);
    return 0;
}

int ctc_master_quit(struct ctc_vti_struct_s* vti)
{
    cli_end = 1;

    return 0;
}


int
ctc_dkit_cli_master(void)
{
    uint32  nbytes = 0;
    int8*   pread_buf = NULL;

    ctc_cmd_init(0);

    ctc_install_node(&dkit_node, NULL);
    ctc_install_node(&sdk_node, NULL);
    ctc_install_node(&exec_node, NULL);
    ctc_vti_init(CTC_DKITS_MODE);

    install_element(CTC_DKITS_MODE, &exit_cmd);
    install_element(CTC_DKITS_MODE, &quit_cmd);
    install_element(EXEC_MODE, &exit_cmd);
    install_element(EXEC_MODE, &quit_cmd);

    ctc_dkit_cli_init(CTC_DKITS_MODE);
    ctc_sort_node();

    pread_buf = sal_malloc(CTC_VTI_BUFSIZ);

    if(NULL == pread_buf)
    {
        return -1;
    }

    set_terminal_raw_mode(CTC_VTI_SHELL_MODE_DEFAULT);

    g_ctc_vti->printf = ctc_master_printf;
    g_ctc_vti->quit   = ctc_master_quit;

    while (cli_end == 0)
    {
        nbytes = ctc_vti_read(pread_buf,CTC_VTI_BUFSIZ,CTC_VTI_SHELL_MODE_DEFAULT);
        ctc_vti_read_cmd(g_ctc_vti,pread_buf,nbytes);
    }

    restore_terminal_mode(CTC_VTI_SHELL_MODE_DEFAULT);

    return 0;
}

int
main()
{
    int ret = 0;
    drv_ftm_profile_info_t profile;

    mem_mgr_init();

    if (0 == SDK_WORK_PLATFORM)
    {
        /* dal module init */
        ret = dal_set_device_access_type(DAL_PCIE_MM);
        if (ret < 0)
        {
            ctc_cli_out("Failed to register dal callback\r\n");
            return ret;
        }

        ret = dal_op_init(NULL);
        if (ret != 0)
        {
            ctc_cli_out("Failed to register dal callback\r\n");
            return ret;
        }
    }

    /* drv module init */
#if defined(GOLDENGATE) || defined(GREATBELT)
    drv_init(1, 0);
#else
    drv_init(0, 0);
#endif

    /* drv profile init */
    sal_memset(&profile, 0, sizeof(profile));
    drv_ftm_mem_alloc(&profile);

    /* install dbg tools cli */
    ctc_dkit_cli_master();

    return 0;
}


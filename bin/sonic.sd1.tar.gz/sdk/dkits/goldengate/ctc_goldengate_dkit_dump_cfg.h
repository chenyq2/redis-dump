#ifndef _CTC_GOLDENGATE_DKIT_DUMP_H_
#define _CTC_GOLDENGATE_DKIT_DUMP_H_

#ifdef __cplusplus
extern "C" {
#endif
#include "sal.h"

extern int32 ctc_goldengate_dkits_dump_memory_usage(uint8 lchip, void* p_para);
extern int32 ctc_goldengate_dkits_dump_cfg_dump(void* p_info);
extern int32 ctc_goldengate_dkits_dump_cfg_decode(void* p_para);
extern int32 ctc_goldengate_dkits_dump_cfg_cmp(void* p_para1, void* p_para2);
extern int32 ctc_goldengate_dkits_dump_decode_entry(void* p_para1, void* p_para2);

#ifdef __cplusplus
}
#endif

#endif


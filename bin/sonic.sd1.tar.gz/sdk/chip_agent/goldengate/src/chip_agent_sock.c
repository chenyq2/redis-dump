/**
  @file chip_agent_sock.c

  @date 2012-02-26

  @version v5.1

  The file implement chip agent socket
*/

#include "sal.h"
#include "ctc_debug.h"
#include "ctc_macro.h"
#include "chip_agent.h"
#include "chip_agent_priv.h"
#include "drv_chip_agent.h"

static int32
_chip_agent_server_sock_reinit(chip_agent_sock_server_t* p_server);
static char*
_chip_agent_sock_mode_str(chip_agent_sock_mode_t mode)
{
    switch (mode)
    {
    case CHIP_AGT_SOCK_SYNC:
        return "sync";

    case CHIP_AGT_SOCK_ASYNC:
        return "async";

    default:
        return "invalid";
    }
}

static chip_agent_dec_ret_t
_chip_agent_decode_hdr(uint8* data, uint32 length, chip_agent_msg_hdr_t* p_hdr)
{
    chip_agent_dec_ret_t ret;
    uint32 dec_length = length;
    uint8* dec_data = data;
    uint8** pnt = &dec_data;
    uint32* size = &dec_length;

    if (length < CHIP_AGT_HDR_SIZE)
    {
        ret.consumed = 0;
        ret.code = CHIP_AGT_DEC_MORE;
        return ret;
    }

    DECODE_GETC(p_hdr->version);
    DECODE_GETC(p_hdr->type);
    DECODE_GETW(p_hdr->length);
    DECODE_GETL(p_hdr->seq);

    if (p_hdr->length > length)
    {
        ret.consumed = 0;
        ret.code = CHIP_AGT_DEC_MORE;
    }
    else
    {
        p_hdr->data = data + CHIP_AGT_HDR_SIZE;
        ret.consumed = p_hdr->length;
        ret.code = CHIP_AGT_DEC_OK;
    }

    return ret;
}

static int32
_chip_agent_sock_session_close(chip_agent_sock_session_t* p_session)
{
    /*if (NULL != p_session->t_read)
    {
        sal_task_destroy(p_session->t_read);
        p_session->t_read = NULL;
    }*/

    if (p_session->sock > 0)
    {
        sal_close(p_session->sock);
        p_session->sock = -1;
    }

    p_session->connected = 0;
    p_session->is_server = 0;
    p_session->tx_seq = 0;
    p_session->rx_seq = 0;
    p_session->buf_len = 0;
    p_session->mode = 0;
    return CHIP_AGT_E_NONE;
}

static int32
_chip_agent_sock_close(chip_agent_sock_session_t* p_disconnected, uint32 init_check)
{
    chip_agent_sock_single_client_t* p_single_client = NULL;
    chip_agent_sock_server_t* p_server = NULL;
    chip_agent_sock_session_t* p_session = NULL;
    uint32 do_close = FALSE;
    uint32 i = 0;

    if (p_disconnected->is_server)
    {
        p_server = &g_chip_agent.server;

        for (i = CHIP_AGT_SOCK_SYNC; i < CHIP_AGT_SOCK_MAX; i++)
        {
            p_session = &(p_server->session[i]);

            if (p_session->sock > 0)
            {
                do_close = TRUE;
            }

            _chip_agent_sock_session_close(p_session);
        }

        if (do_close)
        {
            p_server->disconnect_count++;
            CHIP_AGT_LOG(CHIP_AGT_STR "server %s session disconnected, close sessions %d times\n",
                         _chip_agent_sock_mode_str(p_disconnected->mode), p_server->disconnect_count);
        }

        sal_memset(&p_server->client_addr, 0, sizeof(p_server->client_addr));
        p_server->endian_op = 0;
    }
    else
    {
        p_single_client = &g_chip_agent.client.client_single[p_disconnected->server_id];

        for (i = CHIP_AGT_SOCK_SYNC; i < CHIP_AGT_SOCK_MAX; i++)
        {
            p_session = &(p_single_client->session[i]);

            if (p_session->sock > 0)
            {
                do_close = TRUE;
            }

            _chip_agent_sock_session_close(p_session);
        }

        if (init_check)
        {
            p_single_client->init_disconnect_count++;
            CHIP_AGT_LOG(CHIP_AGT_STR "client %s session disconnected for init check fail, sessions %d times closed \n",
                         _chip_agent_sock_mode_str(p_disconnected->mode), p_single_client->init_disconnect_count);
        }
        else
        {
            if (do_close)
            {
                p_single_client->disconnect_count++;
                CHIP_AGT_LOG(CHIP_AGT_STR "client %s session disconnected, sessions %d times closed \n",
                             _chip_agent_sock_mode_str(p_disconnected->mode), p_single_client->disconnect_count);
            }
        }
    }

    sal_task_sleep(1000);

    return CHIP_AGT_E_NONE;
}

static int32
_chip_agent_sock_session_recv_dispatch(chip_agent_sock_session_t* p_session, chip_agent_msg_hdr_t* p_hdr)
{
    /* check version */
    if (p_hdr->version != CHIP_AGT_VERSION_0)
    {
        p_session->stats.abnormal.version_mismatch++;
    }

    /* check seq */
    if (p_hdr->seq != 0)
    {
        if ((p_session->rx_seq + 1) != p_hdr->seq)
        {
            p_session->stats.abnormal.seq_mismatch++;
        }
    }

    p_session->rx_seq = p_hdr->seq;

    if (p_hdr->type >= CHIP_AGT_MSG_MAX)
    {
        p_session->stats.abnormal.invalid++;
        return CHIP_AGT_E_SOCK_ERROR;
    }

    p_session->stats.normal[p_hdr->type].rx++;

    if (p_session->is_server)
    {
        return chip_agent_server_recv(p_session, p_hdr);
    }
    else
    {
        return chip_agent_client_recv(p_session, p_hdr);
    }

    return CHIP_AGT_E_NONE;
}

static int32
_chip_agent_sock_session_recv(chip_agent_sock_session_t* p_session)
{
    uint8* p = NULL;
    int32 count = 0;
    int32 left = 0;
    int32 ret = 0;
    chip_agent_dec_ret_t dec_rc;
    chip_agent_msg_hdr_t hdr;

    count = CHIP_AGT_BUF_SIZE - p_session->buf_len;
    ret = sal_read(p_session->sock, p_session->buf + p_session->buf_len, count);

    if (ret < 0)
    {
        if (errno == EINTR || errno == EAGAIN || errno == EINPROGRESS)
        {
            return CHIP_AGT_E_NONE;
        }

        CHIP_AGT_LOCK(p_session->p_tx_mutex);
        _chip_agent_sock_close(p_session, FALSE);
        CHIP_AGT_UNLOCK(p_session->p_tx_mutex);
        return CHIP_AGT_E_SOCK_ERROR;
    }
    else if (ret == 0)
    {
        CHIP_AGT_LOCK(p_session->p_tx_mutex);
        _chip_agent_sock_close(p_session, FALSE);
        CHIP_AGT_UNLOCK(p_session->p_tx_mutex);
        return CHIP_AGT_E_SOCK_ERROR;
    }

    p_session->buf_len += ret;
    p = p_session->buf;
    left = p_session->buf_len;

    for (;;)
    {
        dec_rc = _chip_agent_decode_hdr(p, left, &hdr);

        switch (dec_rc.code)
        {
        case CHIP_AGT_DEC_OK:
            CHIP_AGT_DBG_SOCK(CHIP_AGT_SOCK_STR "session %s RX type %s len %d seq %d\n",
                              _chip_agent_sock_mode_str(p_session->mode), chip_agent_msg_type_str(hdr.type),
                              hdr.length, hdr.seq);
            hdr.length -= CHIP_AGT_HDR_SIZE;
            _chip_agent_sock_session_recv_dispatch(p_session, &hdr);
            p += dec_rc.consumed;
            left -= dec_rc.consumed;

            if (left == 0)
            {
                p_session->buf_len = 0;
                return CHIP_AGT_E_NONE;
            }

            break;

        case CHIP_AGT_DEC_MORE:

            if (left > 0 && p_session->buf != p)
            {
                sal_memmove(p_session->buf, p, left);
            }

            p_session->buf_len = left;
            return CHIP_AGT_E_NONE;

        case CHIP_AGT_DEC_FAIL:
            CHIP_AGT_LOCK(p_session->p_tx_mutex);
            _chip_agent_sock_close(p_session, FALSE);
            CHIP_AGT_UNLOCK(p_session->p_tx_mutex);
            return CHIP_AGT_E_SOCK_ERROR;
        }
    }

    return CHIP_AGT_E_NONE;
}

static void
_chip_agent_sock_client_recv_thread(void* param)
{
    chip_agent_sock_single_client_t* p_single_client = (chip_agent_sock_single_client_t*)param;
    chip_agent_sock_session_t* p_session = NULL;
    struct timeval timeout;
    fd_set fds;
    uint32 i = 0;
    int32 maxfdp = 0;
    int32 ret = 0;

    for (;;)
    {
        maxfdp = 0;
        FD_ZERO(&fds);

        for (i = CHIP_AGT_SOCK_ASYNC; i < CHIP_AGT_SOCK_MAX; i++)
        {
            p_session = &(p_single_client->session[i]);

            if (p_session->sock > 0 && p_session->connected)
            {
                FD_SET(p_session->sock, &fds);

                if (maxfdp < p_session->sock)
                {
                    maxfdp = p_session->sock;
                }
            }
        }

        maxfdp += 1;

        timeout.tv_sec = 0;
        timeout.tv_usec = CHIP_AGT_SYNC_TIMEOUT * 1000;

        /* First check for sockets.  Return immediately.  */
        ret = select(maxfdp, &fds, NULL, NULL, &timeout);

        if (ret < 0)
        {
            continue;
        }

        if (ret == 0)
        {
            continue;
        }

        for (i = CHIP_AGT_SOCK_ASYNC; i < CHIP_AGT_SOCK_MAX; i++)
        {
            p_session = &(p_single_client->session[i]);

            if ((p_session->sock > 0) && FD_ISSET(p_session->sock, &fds))
            {
                ret = _chip_agent_sock_session_recv(p_session);

                if (ret < 0)
                {
                    return;
                }
            }
        }
    }

    return;
}

static void
_chip_agent_sock_server_recv_thread(void* param)
{
    chip_agent_sock_server_t* p_server = (chip_agent_sock_server_t*)param;
    chip_agent_sock_session_t* p_session = NULL;
    struct timeval timeout;
    fd_set fds;
    uint32 i = 0;
    int32 maxfdp = 0;
    int32 ret = 0;

    for (;;)
    {
        maxfdp = 0;
        FD_ZERO(&fds);

        for (i = CHIP_AGT_SOCK_SYNC; i < CHIP_AGT_SOCK_MAX; i++)
        {
            p_session = &(p_server->session[i]);

            if (p_session->sock > 0 && p_session->connected)
            {
                FD_SET(p_session->sock, &fds);

                if (maxfdp < p_session->sock)
                {
                    maxfdp = p_session->sock;
                }
            }
        }

        maxfdp += 1;

        timeout.tv_sec = 0;
        timeout.tv_usec = CHIP_AGT_SYNC_TIMEOUT * 1000;

        /* First check for sockets.  Return immediately.  */
        ret = select(maxfdp, &fds, NULL, NULL, &timeout);

        if (ret < 0)
        {
            continue;
        }

        if (ret == 0)
        {
            continue;
        }

        for (i = CHIP_AGT_SOCK_SYNC; i < CHIP_AGT_SOCK_MAX; i++)
        {
            p_session = &(p_server->session[i]);

            if ((p_session->sock > 0) && FD_ISSET(p_session->sock, &fds))
            {
                ret = _chip_agent_sock_session_recv(p_session);

                if (ret < 0)
                {
                    continue;
                }
            }
        }
    }

    return;
}

static void
_chip_agent_sock_client_connect(void* param)
{
    chip_agent_sock_single_client_t* p_single_client = (chip_agent_sock_single_client_t*)param;
    chip_agent_sock_session_t* p_session = NULL;
    struct sal_sockaddr_in* p_addr = &p_single_client->addr;
    uint32 i = 0;
    uint32 opt_len = 0;
    int32 opt_val = 0;
    int32 ret = 0;
    int32 size = 0;

    for (;;)
    {
        if (p_single_client->init_disconnect_count >= CHIP_AGT_INIT_FAIL_COUNT)
        {
            CHIP_AGT_LOG(CHIP_AGT_STR "Init check fail %d times, please exit and use matched SDK version and Profile\n",
                         p_single_client->init_disconnect_count);
            sal_task_sleep(10000);
            continue;
        }

        for (i = CHIP_AGT_SOCK_SYNC; i < CHIP_AGT_SOCK_MAX; i++)
        {
            p_session = &(p_single_client->session[i]);

            if (p_session->connected)
            {
                continue;
            }

            if (p_session->sock <= 0)
            {
                p_session->sock = sal_socket(AF_INET, SOCK_STREAM, 0);

                if (p_session->sock < 0)
                {
                    continue;
                }
            }

            /* Async session must connect after sync is connected */
            if (CHIP_AGT_SOCK_ASYNC == i)
            {
                if (!p_single_client->session[CHIP_AGT_SOCK_SYNC].connected)
                {
                    break;
                }
            }

            ret = sal_connect(p_session->sock, (struct sal_sockaddr*)p_addr, sizeof(struct sal_sockaddr));

            if (0 == ret)
            {
                opt_len = sizeof(opt_val);
                ret = sal_getsockopt(p_session->sock, SOL_SOCKET, SO_ERROR, (int8*)&opt_val, (uint32*)&opt_len);

                if (!opt_val)
                {
                    p_session->buf_len = 0;
                    p_session->is_server = FALSE;

                    size = CHIP_AGT_SOCKET_RCV_BUFF;
                    ret = sal_setsockopt (p_session->sock, SOL_SOCKET, SO_RCVBUF, &size, sizeof(size));

                    if (CHIP_AGT_SOCK_SYNC == i)
                    {
                        CHIP_AGT_LOG(CHIP_AGT_STR "sync session connect success, start init check\n");
                        p_session->connected = TRUE;
                        /* sync session need do init check client and server */
                        
                        #if 1
                        ret = chip_agent_client_send_init(p_session);

                        if (ret)
                        {
                            CHIP_AGT_LOCK(p_session->p_tx_mutex);
                            _chip_agent_sock_close(p_session, TRUE);
                            CHIP_AGT_UNLOCK(p_session->p_tx_mutex);
                        }
                        else
                        #endif    
                        {
                            p_session->connected = TRUE;
                            p_session->mode = CHIP_AGT_SOCK_SYNC;
                            CHIP_AGT_LOG(CHIP_AGT_STR "sync session do init check success\n");
                            ret = sal_task_create(&p_session->t_read, "ctcAgtRx",//SAL_DEF_TASK_STACK_SIZE
                                                  64*1024, 0, _chip_agent_sock_client_recv_thread, p_single_client);
                        }
                    }
                    else
                    {
                        /* sync session need do init check client and server */
                        CHIP_AGT_LOG(CHIP_AGT_STR "async session connect success\n");
                        p_session->connected = TRUE;
                        p_session->mode = CHIP_AGT_SOCK_ASYNC;
                    }
                }
            }
        }

        sal_task_sleep(2000);
    }

    return;
}

static void
_chip_agent_sock_server_accept(void* param)
{
    chip_agent_sock_server_t* p_server = (chip_agent_sock_server_t*)param;
    chip_agent_sock_session_t* p_session_sync = &(p_server->session[CHIP_AGT_SOCK_SYNC]);
    chip_agent_sock_session_t* p_session_async = &(p_server->session[CHIP_AGT_SOCK_ASYNC]);
    struct sal_sockaddr_in client_addr;
    char ip_addr[16];
    uint32 addr_size = 0;
    int32 client_fd = 0;
    int32 ret = 0;

    for (;;)
    {
        addr_size = sizeof(struct sal_sockaddr_in);
        client_fd = sal_accept(p_server->sock, (struct sal_sockaddr*)&client_addr, (uint32*)&addr_size);

        if (client_fd < 0)
        {
            CHIP_AGT_ERR(CHIP_AGT_STR "Accept error\n");
            continue;
        }

        p_server->client_addr = client_addr;
        sal_inet_ntop(AF_INET, &client_addr.sin_addr, ip_addr, sizeof(ip_addr));

        /* both session is connected */
        if (p_server->init_success)
        {
            CHIP_AGT_ERR(CHIP_AGT_STR "server receive connection from %s:%d but both session has been connected\n",
                         ip_addr, sal_ntohs(client_addr.sin_port));
            _chip_agent_server_sock_reinit(p_server);
            p_server->init_success = 0;
        }

        if (p_session_sync->sock <= 0)
        {
            if(!p_session_sync->t_read)
            {
                /* accept sync socket */
                ret = sal_task_create(&p_session_sync->t_read, "ctcAgtRx",//SAL_DEF_TASK_STACK_SIZE
                                      (64 * 1024), 0, _chip_agent_sock_server_recv_thread, p_server);

                if (ret < 0)
                {
                    sal_close(client_fd);
                    continue;
                }
            }
            CHIP_AGT_LOG(CHIP_AGT_STR "server accept sync connection from %s:%d, sock %d \n", ip_addr, sal_ntohs(client_addr.sin_port), client_fd);
            p_session_sync->buf_len = 0;
            p_session_sync->is_server = TRUE;
            p_session_sync->connected = TRUE;
            p_session_sync->sock = client_fd;
        }
        else
        {
            /* accept async socket */
            CHIP_AGT_LOG(CHIP_AGT_STR "server accept async connection from %s:%d, sock %d \n", ip_addr, sal_ntohs(client_addr.sin_port), client_fd);
            p_session_async->buf_len = 0;
            p_session_async->is_server = TRUE;
            p_session_async->connected = TRUE;
            p_session_async->sock = client_fd;
            p_server->init_success = 1;
        }
    }

    return;
}

int32
chip_agent_sock_client_global_init(void)
{
    chip_agent_sock_client_t* p_client = &g_chip_agent.client;
    int32 ret = 0;

    if (CHIP_AGT_MODE_SERVER == g_chip_agent.mode)
    {
        return CHIP_AGT_E_MODE_SERVER;
    }
    
    sal_memset(p_client, 0, sizeof(chip_agent_sock_client_t));
    
    chip_agent_client_register_intr_cb(chip_agent_intr_cb);
    //chip_agent_client_register_pkt_rx_cb(ctc_packet_sample_rx);
    g_chip_agent.cfg.print_pkt_rx = TRUE;
    p_client->sync_timeout = CHIP_AGT_SYNC_CNT;

    return ret;
}
int32
chip_agent_sock_client_init(char* address, uint32 port, uint32 server_id)
{
    chip_agent_sock_single_client_t * p_single_client = &g_chip_agent.client.client_single[server_id];
    struct sal_sockaddr_in* p_addr = &p_single_client->addr;
    int32 ret = 0;

    if((NULL == address) || (port < 1024) || (port > 65535) || (server_id > CHIP_AGT_MAX_SERVER))
    {
        return -1;
    }
    
    if (CHIP_AGT_MODE_SERVER == g_chip_agent.mode)
    {
        return CHIP_AGT_E_MODE_SERVER;
    }

    if (0 != p_single_client->addr.sin_addr.s_addr)
    {
        return CHIP_AGT_E_MODE_CLIENT;
    }

    sal_memset(p_single_client, 0, sizeof(chip_agent_sock_single_client_t));

    p_single_client->session[CHIP_AGT_SOCK_SYNC].sock = -1;
    p_single_client->session[CHIP_AGT_SOCK_ASYNC].sock = -1;
    p_single_client->session[CHIP_AGT_SOCK_SYNC].server_id = server_id;
    p_single_client->session[CHIP_AGT_SOCK_ASYNC].server_id = server_id;

    sal_mutex_create(&p_single_client->p_sync_mutex);

    if (NULL == p_single_client->p_sync_mutex)
    {
        ret = CHIP_AGT_E_MUTEX_CREAT;
        goto error_exit;
    }

    sal_mutex_create(&p_single_client->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex);

    if (NULL == p_single_client->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex)
    {
        ret = CHIP_AGT_E_MUTEX_CREAT;
        goto error_exit;
    }

    sal_mutex_create(&p_single_client->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex);

    if (NULL == p_single_client->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex)
    {
        ret = CHIP_AGT_E_MUTEX_CREAT;
        goto error_exit;
    }

    if (0 == port)
    {
        port = CHIP_AGT_SOCKET_PORT;
    }

    p_addr->sin_family = AF_INET;
    p_addr->sin_port = sal_htons(port);
    ret = sal_inet_pton(AF_INET, address, &p_addr->sin_addr);

    if (ret < 0)
    {
        ret = CHIP_AGT_E_SOCK_ADDR;
        goto error_exit;
    }

    CHIP_AGT_LOG(CHIP_AGT_STR "server IP is %s:%d, connecting ...\n", address, port);
    ret = sal_task_create(&p_single_client->t_connect, "ctcAgtCon",
                          SAL_DEF_TASK_STACK_SIZE, 0, _chip_agent_sock_client_connect, p_single_client);

    if (ret < 0)
    {
        ret = CHIP_AGT_E_TASK;
        goto error_exit;
    }

    g_chip_agent.mode = CHIP_AGT_MODE_CLIENT;

    return CHIP_AGT_E_NONE;

error_exit:

    if (p_single_client->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex)
    {
        sal_mutex_destroy(p_single_client->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex);
        p_single_client->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex = NULL;
    }

    if (p_single_client->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex)
    {
        sal_mutex_destroy(p_single_client->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex);
        p_single_client->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex = NULL;
    }

    if (p_single_client->p_sync_mutex)
    {
        sal_mutex_destroy(p_single_client->p_sync_mutex);
        p_single_client->p_sync_mutex = NULL;
    }

    return ret;
}

static int32
_chip_agent_server_sock_reinit(chip_agent_sock_server_t* p_server)
{
    chip_agent_sock_session_t* p_session = NULL;
    uint32 do_close = FALSE;
    uint32 i = 0;

    p_server = &g_chip_agent.server;

    for (i = CHIP_AGT_SOCK_SYNC; i < CHIP_AGT_SOCK_MAX; i++)
    {
        p_session = &(p_server->session[i]);

        if (p_session->sock > 0)
        {
            do_close = TRUE;
        }

        if (p_session->sock > 0)
        {
            sal_close(p_session->sock);
            p_session->sock = -1;
        }

        p_session->connected = 0;
        p_session->is_server = 0;
        p_session->tx_seq = 0;
        p_session->rx_seq = 0;
        p_session->buf_len = 0;
        p_session->mode = 0;
    }

    if (do_close)
    {
        p_server->disconnect_count++;
        CHIP_AGT_LOG(CHIP_AGT_STR "server session disconnected, close sessions %d times\n",
                     p_server->disconnect_count);
    }

    sal_memset(&p_server->client_addr, 0, sizeof(p_server->client_addr));
    p_server->endian_op = 0;

    return CHIP_AGT_E_NONE;
}

int32
chip_agent_sock_server_init(uint32 port)
{
    chip_agent_sock_server_t* p_server = &g_chip_agent.server;
    struct sal_sockaddr_in addr;
    int32 flags = 1;
    int32 ret = 0;

    if (CHIP_AGT_MODE_CLIENT == g_chip_agent.mode)
    {
        return CHIP_AGT_E_MODE_CLIENT;
    }

    if (p_server->sock > 0)
    {
        return CHIP_AGT_E_SOCK_EXIST;
    }

    sal_memset(p_server, 0, sizeof(chip_agent_sock_server_t));
    p_server->session[CHIP_AGT_SOCK_SYNC].sock = -1;
    p_server->session[CHIP_AGT_SOCK_ASYNC].sock = -1;
    sal_memset(&addr, 0, sizeof(addr));
    p_server->sock = -1;

    sal_mutex_create(&p_server->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex);

    if (NULL == p_server->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex)
    {
        ret = CHIP_AGT_E_MUTEX_CREAT;
        goto error_exit;
    }

    sal_mutex_create(&p_server->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex);

    if (NULL == p_server->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex)
    {
        ret = CHIP_AGT_E_MUTEX_CREAT;
        goto error_exit;
    }

    p_server->sock = sal_socket(AF_INET, SOCK_STREAM, 0);

    if (p_server->sock < 0)
    {
        ret = CHIP_AGT_E_SOCK_CREAT;
        goto error_exit;
    }

    if (0 == port)
    {
        port = CHIP_AGT_SOCKET_PORT;
    }

    addr.sin_family = AF_INET;
    addr.sin_port = sal_htons(port);
    addr.sin_addr.s_addr = INADDR_ANY;

    ret = sal_setsockopt(p_server->sock, SOL_SOCKET, SO_REUSEADDR, (void*)&flags, sizeof(flags));

    if (ret < 0)
    {
        ret = CHIP_AGT_E_SOCK_SET_OPT;
        goto error_exit;
    }

    ret = sal_bind(p_server->sock, (struct sal_sockaddr*)&addr, sizeof(struct sal_sockaddr));

    if (ret < 0)
    {
        ret = CHIP_AGT_E_SOCK_BIND;
        goto error_exit;
    }

    CHIP_AGT_ERR(CHIP_AGT_STR "is binding to TCP Port %d\n", port);

    ret = sal_listen(p_server->sock, 1);

    if (ret < 0)
    {
        ret = CHIP_AGT_E_SOCK_LISTEN;
        goto error_exit;
    }

    ret = sal_task_create(&p_server->t_accept, "ctcAgtAcpt",
                          SAL_DEF_TASK_STACK_SIZE, 0, _chip_agent_sock_server_accept, p_server);

    if (ret < 0)
    {
        return CHIP_AGT_E_TASK;
    }

    g_chip_agent.mode = CHIP_AGT_MODE_SERVER;

    return CHIP_AGT_E_NONE;

error_exit:

    if (p_server->sock > 0)
    {
        sal_close(p_server->sock);
        p_server->sock = -1;
    }

    if (p_server->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex)
    {
        sal_mutex_destroy(p_server->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex);
        p_server->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex = NULL;
    }

    if (p_server->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex)
    {
        sal_mutex_destroy(p_server->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex);
        p_server->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex = NULL;
    }

    return ret;
}

static int32
_chip_agent_do_send(chip_agent_sock_session_t* p_session, chip_agent_msg_type_t type, uint8* p_req, uint32 req_len)
{
    uint32 total_len = 0;
    int32 pkt_size_left = CHIP_AGT_HDR_SIZE;
    int32* size = NULL;
    uint8** pnt = NULL;
    uint8* ptr = NULL;
    uint32 len = 0;
    uint32 i = 0;
    int32 ret = 0;
 
    ptr = p_req;
    size = &pkt_size_left;
    pnt = &ptr;

    if (type >= CHIP_AGT_MSG_MAX)
    {
        return CHIP_AGT_E_SOCK_ERROR;
    }

    p_session->stats.normal[type].tx++;
    p_session->tx_seq++;

    total_len = CHIP_AGT_HDR_SIZE + req_len;

    ENCODE_PUTC(CHIP_AGT_VERSION_0);
    ENCODE_PUTC(type);
    ENCODE_PUTW(total_len);
    ENCODE_PUTL(p_session->tx_seq);

    ptr = p_req;
    len = total_len;

    CHIP_AGT_DBG_SOCK(CHIP_AGT_SOCK_STR "session %s TX type %s len %d seq %d\n",
                      _chip_agent_sock_mode_str(p_session->mode), chip_agent_msg_type_str(type), len, p_session->tx_seq);

#define CHIP_AGT_SEND_CNT 1000

    while (i < CHIP_AGT_SEND_CNT)
    {
        ret = sal_send(p_session->sock, ptr, len, 0);

        if (ret < 0)
        {
            if (errno == EINTR || errno == EAGAIN || errno == EINPROGRESS)
            {
                sal_task_sleep(10);
                i++;
                continue;
            }

            _chip_agent_sock_close(p_session, FALSE);
            return CHIP_AGT_E_SOCK_ERROR;
        }
        else if (ret == len)
        {
            return CHIP_AGT_E_NONE;
        }
        else
        {
            ptr += ret;
            len -= ret;
        }

        i++;
    }

    return CHIP_AGT_E_SOCK_ERROR;
}

int32
chip_agent_send(chip_agent_sock_session_t* p_session, chip_agent_msg_type_t type, uint8* p_req, uint32 req_len)
{
    int32 ret = CHIP_AGT_E_NONE;

    if ((p_session->sock < 0) || (!p_session->connected))
    {
        return CHIP_AGT_E_SOCK_NOT_CONNECT;
    }

    CHIP_AGT_LOCK(p_session->p_tx_mutex);
    ret = _chip_agent_do_send(p_session, type, p_req, req_len);
    CHIP_AGT_UNLOCK(p_session->p_tx_mutex);

    return ret;
}

int32
chip_agent_send_syn_cnt(chip_agent_sock_session_t* p_session, chip_agent_msg_type_t type, uint8* p_req, uint32 req_len,
                        uint8* p_resp, uint32* p_resp_len, uint32 repeat)
{
    struct timeval timeout;
    fd_set fds;
    int32 maxfdp = 0;
    chip_agent_dec_ret_t dec_rc;
    chip_agent_msg_hdr_t hdr;
    uint8* p = NULL;
    uint8* data = NULL;
    uint32 has_resp = FALSE;
    int32 count = 0;
    int32 buf_size = 0;
    int32 left = 0;
    int32 ret = 0;

    sal_memset(&hdr, 0, sizeof(chip_agent_msg_hdr_t));
    sal_memset(&dec_rc, 0, sizeof(chip_agent_dec_ret_t));

    if ((p_session->sock < 0) || (!p_session->connected))
    {
        return CHIP_AGT_E_SOCK_NOT_CONNECT;
    }

    *p_resp_len = 0;

    ret = chip_agent_send(p_session, type, p_req, req_len);

    if (ret)
    {
        CHIP_AGT_LOG(CHIP_AGT_STR "send failed, ret %d \n", ret);
        return ret;
    }

    while (count < repeat)
    {
        FD_ZERO(&fds);
        FD_SET(p_session->sock, &fds);

        maxfdp = p_session->sock + 1;
        timeout.tv_sec = 0;
        timeout.tv_usec = CHIP_AGT_SYNC_TIMEOUT * 1000;

        /* First check for sockets.  Return immediately.  */
        ret = select(maxfdp, &fds, NULL, NULL, &timeout);

        if ((ret <= 0) || (!FD_ISSET(p_session->sock, &fds)))
        {
            count++;
            continue;
        }

        buf_size = CHIP_AGT_BUF_SIZE - p_session->buf_len;
        ret = sal_read(p_session->sock, p_session->buf + p_session->buf_len, buf_size);

        if (ret < 0)
        {
            if (errno == EINTR || errno == EAGAIN || errno == EINPROGRESS)
            {
                return CHIP_AGT_E_NONE;
            }

            CHIP_AGT_LOCK(p_session->p_tx_mutex);
            _chip_agent_sock_close(p_session, FALSE);
            CHIP_AGT_UNLOCK(p_session->p_tx_mutex);
            return CHIP_AGT_E_SOCK_ERROR;
        }
        else if (ret == 0)
        {
            CHIP_AGT_LOCK(p_session->p_tx_mutex);
            _chip_agent_sock_close(p_session, FALSE);
            CHIP_AGT_UNLOCK(p_session->p_tx_mutex);
            return CHIP_AGT_E_SOCK_ERROR;
        }

        p_session->buf_len += ret;
        p = p_session->buf;
        left = p_session->buf_len;

        while (1)
        {
            dec_rc = _chip_agent_decode_hdr(p, left, &hdr);

            if (CHIP_AGT_DEC_OK == dec_rc.code)
            {
                CHIP_AGT_DBG_SOCK(CHIP_AGT_SOCK_STR "session %s RX type %s len %d tx_seq %d rx_seq %d\n",
                                  _chip_agent_sock_mode_str(p_session->mode), chip_agent_msg_type_str(hdr.type),
                                  hdr.length, p_session->tx_seq, hdr.seq);
                hdr.length -= CHIP_AGT_HDR_SIZE;
                data = p + CHIP_AGT_HDR_SIZE;

                if (CHIP_AGT_MSG_RESP == hdr.type)
                {
                    has_resp = TRUE;

                    if (p_session->tx_seq != hdr.seq)
                    {
                        p_session->stats.abnormal.syn_seq_mismatch++;
                        has_resp = FALSE;
                    }

                    /* check version */
                    if (hdr.version != CHIP_AGT_VERSION_0)
                    {
                        p_session->stats.abnormal.version_mismatch++;
                        has_resp = FALSE;
                    }

                    if (hdr.type >= CHIP_AGT_MSG_MAX)
                    {
                        p_session->stats.abnormal.invalid++;
                        has_resp = FALSE;
                    }

                    if (has_resp)
                    {
                        sal_memcpy(p_resp, data, hdr.length);
                        *p_resp_len = hdr.length;
                        p_session->rx_seq = hdr.seq;
                    }
                }
                else
                {
                    /* get other msg */
                }

                p += dec_rc.consumed;
                left -= dec_rc.consumed;

                if (left == 0)
                {
                    p_session->buf_len = 0;
                    break;  /* break for all data is decoded */
                }
            }
            else if (CHIP_AGT_DEC_MORE == dec_rc.code)
            {
                if (left > 0 && p_session->buf != p)
                {
                    sal_memmove(p_session->buf, p, left);
                }

                p_session->buf_len = left;
                break;      /* break for need more data */
            }
            else
            {
                /* CHIP_AGT_DEC_FAIL */
                return CHIP_AGT_E_SOCK_ERROR;
            }
        }

        if (has_resp)
        {
            p_session->stats.normal[hdr.type].rx++;
            return CHIP_AGT_E_NONE;
        }

        count++;
    }

    return CHIP_AGT_E_SOCK_SYNC_TO;
}

int32
chip_agent_send_syn(chip_agent_sock_session_t* p_session, chip_agent_msg_type_t type, uint8* p_req, uint32 req_len,
                    uint8* p_resp, uint32* p_resp_len)
{
    int32 ret = CHIP_AGT_E_NONE;
    sal_systime_t tv_tx;
    sal_systime_t tv_rx;
    int32 delta = 0;
    int32 delta_s = 0;
    int32 delta_10ms = 0;
    chip_agent_cache_t* p_drvio_cache = &g_chip_agent.client.client_single[p_session->server_id].drvio_cache;

    if (!p_session->connected)
    {
        /*CHIP_AGT_LOG(CHIP_AGT_STR "chip_agent_send_syn times when EADP does not connectted\n");*/
        return CHIP_AGT_E_SOCK_NOT_CONNECT;
    }
    CHIP_AGT_LOCK(g_chip_agent.client.client_single[p_session->server_id].p_sync_mutex);
    sal_gettime(&tv_tx);
    ret = chip_agent_send_syn_cnt(p_session, type, p_req, req_len, p_resp, p_resp_len, g_chip_agent.client.sync_timeout);
    if (ret != CHIP_AGT_E_NONE)
    {
        CHIP_AGT_UNLOCK(g_chip_agent.client.client_single[p_session->server_id].p_sync_mutex);
        CHIP_AGT_LOG(CHIP_AGT_STR "call chip_agent_send_syn_cnt  failed  error code: :%d !!!!!!! \n",ret);
        return ret;
    }

    sal_gettime(&tv_rx);

    delta = (tv_rx.tv_sec - tv_tx.tv_sec) * 1000000 + (tv_rx.tv_usec - tv_tx.tv_usec);
    delta_s = delta / 1000000;
    delta_10ms = delta / 10000;

    if (delta_s < CHIP_AGT_SYNC_SEC_MAX)
    {
        g_chip_agent.client.client_single[p_session->server_id].sync_s[delta_s]++;
    }

    if (delta_10ms < CHIP_AGT_SYNC_10MS_MAX)
    {
        g_chip_agent.client.client_single[p_session->server_id].sync_10ms[delta_10ms]++;
    }

    if (CHIP_AGT_MSG_IO == type)
    {
        chip_agent_add_cache_entry(&p_drvio_cache->tx, &tv_tx, p_session->tx_seq, p_req + CHIP_AGT_HDR_SIZE, req_len);
        chip_agent_add_cache_entry(&p_drvio_cache->rx, &tv_rx, p_session->rx_seq, p_resp, *p_resp_len);
    }

    CHIP_AGT_UNLOCK(g_chip_agent.client.client_single[p_session->server_id].p_sync_mutex);
    return ret;
}

int32
chip_agent_client_init()
{
    return chip_agent_sock_client_init(g_chip_agent.cfg.addr[0], g_chip_agent.cfg.tcp_port, 0);
}

int32
chip_agent_client_deinit()
{
    chip_agent_sock_client_t* p_client = &g_chip_agent.client;
    chip_agent_sock_single_client_t* p_single_client = NULL;
    chip_agent_sock_session_t* p_session = NULL;
    uint32 i = 0;

    for(i = 0; i < CHIP_AGT_MAX_SERVER; i++)
    {
        p_single_client = &g_chip_agent.client.client_single[i];
        if (NULL != p_single_client->t_connect)
        {
            sal_task_destroy(p_single_client->t_connect);
            p_single_client->t_connect = NULL;
        }

        if (CHIP_AGT_MODE_CLIENT == g_chip_agent.mode)
        {
                p_session = &(g_chip_agent.client.client_single[i].session[CHIP_AGT_SOCK_SYNC]);
        }
        else
        {
                p_session = &(g_chip_agent.server.session[CHIP_AGT_SOCK_SYNC]);
        }
        CHIP_AGT_LOCK(p_session->p_tx_mutex);
        _chip_agent_sock_close(p_session, FALSE);
        CHIP_AGT_UNLOCK(p_session->p_tx_mutex);

        if (p_single_client->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex)
        {
            sal_mutex_destroy(p_single_client->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex);
            p_single_client->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex = NULL;
        }

        if (p_single_client->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex)
        {
            sal_mutex_destroy(p_single_client->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex);
            p_single_client->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex = NULL;
        }

        if (p_single_client->p_sync_mutex)
        {
            sal_mutex_destroy(p_single_client->p_sync_mutex);
            p_single_client->p_sync_mutex = NULL;
        }
    }

    sal_memset(p_client, 0, sizeof(chip_agent_sock_client_t));

    return CHIP_AGT_E_NONE;
}


#define _SOCKET_FOR_DMA_TEST_
//added for gg eadp dma pkt test. add one unix socket.
static void
_chip_agent_dma_sock_client_connect(void* param)
{
    chip_agent_sock_single_client_t* p_single_client = (chip_agent_sock_single_client_t*)param;
    chip_agent_sock_session_t* p_session = NULL;
    struct sal_sockaddr_in* p_addr = &p_single_client->addr;
    uint32 i = 0;
    uint32 opt_len = 0;
    int32 opt_val = 0;
    int32 ret = 0;

    for (;;)
    {
        if (p_single_client->init_disconnect_count >= CHIP_AGT_INIT_FAIL_COUNT)
        {
            CHIP_AGT_LOG(CHIP_AGT_STR "Init check fail %d times, please exit and use matched SDK version and Profile\n",
                         p_single_client->init_disconnect_count);
            sal_task_sleep(10000);
            continue;
        }

        for (i = CHIP_AGT_SOCK_SYNC; i < CHIP_AGT_SOCK_MAX; i++)
        {
            p_session = &(p_single_client->session[i]);

            if (p_session->connected)
            {
                continue;
            }

            if (p_session->sock <= 0)
            {
                p_session->sock = sal_socket(AF_INET, SOCK_STREAM, 0);

                if (p_session->sock < 0)
                {
                    continue;
                }
            }

            /* Async session must connect after sync is connected */
            if (CHIP_AGT_SOCK_ASYNC == i)
            {
                if (!p_single_client->session[CHIP_AGT_SOCK_SYNC].connected)
                {
                    break;
                }
            }

            ret = sal_connect(p_session->sock, (struct sal_sockaddr*)p_addr, sizeof(struct sal_sockaddr));

            if (0 == ret)
            {
                opt_len = sizeof(opt_val);
                ret = sal_getsockopt(p_session->sock, SOL_SOCKET, SO_ERROR, (int8*)&opt_val, (uint32*)&opt_len);

                if (!opt_val)
                {
                    p_session->buf_len = 0;
                    p_session->is_server = FALSE;

                    if (CHIP_AGT_SOCK_SYNC == i)
                    {
                        CHIP_AGT_LOG(CHIP_AGT_STR "sync session connect success, start init check\n");
                        p_session->connected = TRUE;
                        /* sync session need do init check client and server */
                        #if 0
                        ret = chip_agent_client_send_init();

                        if (ret)
                        {
                            CHIP_AGT_LOCK(p_session->p_tx_mutex);
                            _chip_agent_sock_close(p_session, TRUE);
                            CHIP_AGT_UNLOCK(p_session->p_tx_mutex);
                        }
                        else
                        #endif
                        {
                            p_session->connected = TRUE;
                            p_session->mode = CHIP_AGT_SOCK_SYNC;
                            CHIP_AGT_LOG(CHIP_AGT_STR "sync session do init check success\n");
                            ret = sal_task_create(&p_session->t_read, "ctcAgtRx",//SAL_DEF_TASK_STACK_SIZE
                                                  SAL_DEF_TASK_STACK_SIZE, 0, _chip_agent_sock_client_recv_thread, p_single_client);
                        }
                    }
                    else
                    {
                        /* sync session need do init check client and server */
                        CHIP_AGT_LOG(CHIP_AGT_STR "async session connect success\n");
                        p_session->connected = TRUE;
                        p_session->mode = CHIP_AGT_SOCK_ASYNC;
                    }
                }
            }
        }

        sal_task_sleep(2000);
    }

    return;
}


int32
chip_agent_dma_sock_client_init(char* address, uint32 port, uint32 server_id)
{
    chip_agent_sock_single_client_t* p_single_client = &g_chip_agent.dma_client.client_single[server_id];
    struct sal_sockaddr_in* p_addr = &p_single_client->addr;
    int32 ret = 0;

    if (0 != p_single_client->addr.sin_addr.s_addr)
    {
        return CHIP_AGT_E_MODE_CLIENT;
    }

    sal_memset(p_single_client, 0, sizeof(chip_agent_sock_single_client_t));

    chip_agent_client_register_intr_cb(chip_agent_intr_cb);

    p_single_client->session[CHIP_AGT_SOCK_SYNC].sock = -1;
    p_single_client->session[CHIP_AGT_SOCK_ASYNC].sock = -1;
    p_single_client->session[CHIP_AGT_SOCK_SYNC].server_id = server_id;
    p_single_client->session[CHIP_AGT_SOCK_ASYNC].server_id = server_id;
    g_chip_agent.dma_client.sync_timeout = CHIP_AGT_SYNC_CNT;

    sal_mutex_create(&p_single_client->p_sync_mutex);

    if (NULL == p_single_client->p_sync_mutex)
    {
        ret = CHIP_AGT_E_MUTEX_CREAT;
        goto error_exit;
    }

    sal_mutex_create(&p_single_client->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex);

    if (NULL == p_single_client->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex)
    {
        ret = CHIP_AGT_E_MUTEX_CREAT;
        goto error_exit;
    }

    sal_mutex_create(&p_single_client->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex);

    if (NULL == p_single_client->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex)
    {
        ret = CHIP_AGT_E_MUTEX_CREAT;
        goto error_exit;
    }

    if (0 == port)
    {
        port = CHIP_AGT_DMA_SOCKET_PORT;
    }

    p_addr->sin_family = AF_INET;
    p_addr->sin_port = sal_htons(port);
    ret = sal_inet_pton(AF_INET, address, &p_addr->sin_addr);

    if (ret < 0)
    {
        ret = CHIP_AGT_E_SOCK_ADDR;
        goto error_exit;
    }

    CHIP_AGT_LOG(CHIP_AGT_STR "server IP is %s:%d, connecting ...\n", address, port);
    ret = sal_task_create(&p_single_client->t_connect, "ctcAgtCon",
                          SAL_DEF_TASK_STACK_SIZE, 0, _chip_agent_dma_sock_client_connect, p_single_client);

    if (ret < 0)
    {
        ret = CHIP_AGT_E_TASK;
        goto error_exit;
    }

    return CHIP_AGT_E_NONE;

error_exit:

    if (p_single_client->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex)
    {
        sal_mutex_destroy(p_single_client->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex);
        p_single_client->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex = NULL;
    }

    if (p_single_client->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex)
    {
        sal_mutex_destroy(p_single_client->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex);
        p_single_client->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex = NULL;
    }

    if (p_single_client->p_sync_mutex)
    {
        sal_mutex_destroy(p_single_client->p_sync_mutex);
        p_single_client->p_sync_mutex = NULL;
    }

    return ret;
}


static void
_chip_agent_dma_sock_server_recv_thread(void* param)
{
    chip_agent_sock_server_t* p_server = (chip_agent_sock_server_t*)param;
    chip_agent_sock_session_t* p_session = NULL;
    struct timeval timeout;
    fd_set fds;
    uint32 i = 0;
    int32 maxfdp = 0;
    int32 ret = 0;

    for (;;)
    {
        maxfdp = 0;
        FD_ZERO(&fds);

        for (i = CHIP_AGT_SOCK_SYNC; i < CHIP_AGT_SOCK_MAX; i++)
        {
            p_session = &(p_server->session[i]);

            if (p_session->sock > 0 && p_session->connected)
            {
                FD_SET(p_session->sock, &fds);

                if (maxfdp < p_session->sock)
                {
                    maxfdp = p_session->sock;
                }
            }
        }

        maxfdp += 1;

        timeout.tv_sec = 0;
        timeout.tv_usec = CHIP_AGT_SYNC_TIMEOUT * 1000;

        /* First check for sockets.  Return immediately.  */
        ret = select(maxfdp, &fds, NULL, NULL, &timeout);

        if (ret < 0)
        {
            continue;
        }

        if (ret == 0)
        {
            continue;
        }

        for (i = CHIP_AGT_SOCK_SYNC; i < CHIP_AGT_SOCK_MAX; i++)
        {
            p_session = &(p_server->session[i]);

            if ((p_session->sock > 0) && FD_ISSET(p_session->sock, &fds))
            {
                ret = _chip_agent_sock_session_recv(p_session);

                if (ret < 0)
                {
                    return;
                }
            }
        }
    }

    return;
}

static void
_chip_agent_dma_sock_server_accept(void* param)
{
    chip_agent_sock_server_t* p_server = (chip_agent_sock_server_t*)param;
    chip_agent_sock_session_t* p_session_sync = &(p_server->session[CHIP_AGT_SOCK_SYNC]);
    chip_agent_sock_session_t* p_session_async = &(p_server->session[CHIP_AGT_SOCK_ASYNC]);
    struct sal_sockaddr_in client_addr;
    char ip_addr[16];
    uint32 addr_size = 0;
    int32 client_fd = 0;
    int32 ret = 0;

    for (;;)
    {
        addr_size = sizeof(struct sal_sockaddr_in);
        client_fd = sal_accept(p_server->sock, (struct sal_sockaddr*)&client_addr, (uint32*)&addr_size);

        if (client_fd < 0)
        {
            CHIP_AGT_ERR(CHIP_AGT_STR "Accept error\n");
            continue;
        }

        p_server->client_addr = client_addr;
        sal_inet_ntop(AF_INET, &client_addr.sin_addr, ip_addr, sizeof(ip_addr));

        /* both session is connected */
        if (p_session_async->sock > 0)
        {
            CHIP_AGT_ERR(CHIP_AGT_STR "server receive connection from %s:%d but both session has been connected\n",
                         ip_addr, sal_ntohs(client_addr.sin_port));
            sal_close(client_fd);
            continue;
        }

        if (p_session_sync->sock <= 0)
        {
            /* accept sync socket */
            ret = sal_task_create(&p_session_sync->t_read, "ctcAgtRx",//SAL_DEF_TASK_STACK_SIZE
                                  (64 * 1024), 0, _chip_agent_dma_sock_server_recv_thread, p_server);

            if (ret < 0)
            {
                sal_close(client_fd);
                continue;
            }

            CHIP_AGT_LOG(CHIP_AGT_STR "server accept sync connection from %s:%d \n", ip_addr, sal_ntohs(client_addr.sin_port));
            p_session_sync->buf_len = 0;
            p_session_sync->is_server = TRUE;
            p_session_sync->connected = TRUE;
            p_session_sync->sock = client_fd;
        }
        else
        {
            /* accept async socket */
            CHIP_AGT_LOG(CHIP_AGT_STR "server accept async connection from %s:%d\n", ip_addr, sal_ntohs(client_addr.sin_port));
            p_session_async->buf_len = 0;
            p_session_async->is_server = TRUE;
            p_session_async->connected = TRUE;
            p_session_async->sock = client_fd;
        }
    }

    return;
}

int32
chip_agent_dma_sock_server_init(uint32 port)
{
    chip_agent_sock_server_t* p_server = &g_chip_agent.dma_server;
    struct sal_sockaddr_in addr;
    int32 flags = 1;
    int32 ret = 0;

    if (CHIP_AGT_MODE_CLIENT == g_chip_agent.mode)
    {
        return CHIP_AGT_E_MODE_CLIENT;
    }

    if (p_server->sock > 0)
    {
        return CHIP_AGT_E_SOCK_EXIST;
    }

    sal_memset(p_server, 0, sizeof(chip_agent_sock_server_t));
    p_server->session[CHIP_AGT_SOCK_SYNC].sock = -1;
    p_server->session[CHIP_AGT_SOCK_ASYNC].sock = -1;
    sal_memset(&addr, 0, sizeof(addr));
    p_server->sock = -1;

    sal_mutex_create(&p_server->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex);

    if (NULL == p_server->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex)
    {
        ret = CHIP_AGT_E_MUTEX_CREAT;
        goto error_exit;
    }

    sal_mutex_create(&p_server->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex);

    if (NULL == p_server->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex)
    {
        ret = CHIP_AGT_E_MUTEX_CREAT;
        goto error_exit;
    }

    p_server->sock = sal_socket(AF_INET, SOCK_STREAM, 0);

    if (p_server->sock < 0)
    {
        ret = CHIP_AGT_E_SOCK_CREAT;
        goto error_exit;
    }

    if (0 == port)
    {
        port = CHIP_AGT_DMA_SOCKET_PORT;
    }

    addr.sin_family = AF_INET;
    addr.sin_port = sal_htons(port);
    addr.sin_addr.s_addr = INADDR_ANY;

    ret = sal_setsockopt(p_server->sock, SOL_SOCKET, SO_REUSEADDR, (void*)&flags, sizeof(flags));

    if (ret < 0)
    {
        ret = CHIP_AGT_E_SOCK_SET_OPT;
        goto error_exit;
    }

    ret = sal_bind(p_server->sock, (struct sal_sockaddr*)&addr, sizeof(struct sal_sockaddr));

    if (ret < 0)
    {
        ret = CHIP_AGT_E_SOCK_BIND;
        goto error_exit;
    }

    CHIP_AGT_ERR(CHIP_AGT_STR "is binding to TCP Port %d\n", port);

    ret = sal_listen(p_server->sock, 1);

    if (ret < 0)
    {
        ret = CHIP_AGT_E_SOCK_LISTEN;
        goto error_exit;
    }

    ret = sal_task_create(&p_server->t_accept, "ctcAgtAcpt",
                          SAL_DEF_TASK_STACK_SIZE, 0, _chip_agent_dma_sock_server_accept, p_server);

    if (ret < 0)
    {
        return CHIP_AGT_E_TASK;
    }

    g_chip_agent.mode = CHIP_AGT_MODE_SERVER;

    return CHIP_AGT_E_NONE;

error_exit:

    if (p_server->sock > 0)
    {
        sal_close(p_server->sock);
        p_server->sock = -1;
    }

    if (p_server->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex)
    {
        sal_mutex_destroy(p_server->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex);
        p_server->session[CHIP_AGT_SOCK_ASYNC].p_tx_mutex = NULL;
    }

    if (p_server->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex)
    {
        sal_mutex_destroy(p_server->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex);
        p_server->session[CHIP_AGT_SOCK_SYNC].p_tx_mutex = NULL;
    }

    return ret;
}




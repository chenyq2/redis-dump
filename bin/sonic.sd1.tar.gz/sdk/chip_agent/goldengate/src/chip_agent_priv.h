/**
 @file chip_agent_priv.h

 @date 2012-08-16

 @version v2.0

provide the private defination and functions for chip agent
*/
#ifndef _CHIP_AGENT_PRIV_H_
#define _CHIP_AGENT_PRIV_H_

#define CHIP_AGT_VERSION_0          0
#define CHIP_AGT_HDR_SIZE           8

#define CHIP_AGT_INIT_FAIL_COUNT    10
#define CHIP_AGT_SOCKET_PORT        60000
#define CHIP_AGT_DMA_SOCKET_PORT    60001
#define CHIP_AGT_SYNC_TIMEOUT       10   /* ms */

#define MAX(a, b) (((a) > (b)) ? (a) : (b))
#if 0
#define CHIP_AGT_DBG_SOCK(FMT, ...) \
    CTC_DEBUG_OUT(chipagent, chipagent, CHIP_AGT_SOCKET, CTC_DEBUG_LEVEL_INFO, FMT, ##__VA_ARGS__)

#define CHIP_AGT_DBG_CODE(FMT, ...) \
    CTC_DEBUG_OUT(chipagent, chipagent, CHIP_AGT_CODE, CTC_DEBUG_LEVEL_INFO, FMT, ##__VA_ARGS__)

#define CHIP_AGT_LOCK(mutex_type) \
    if (mutex_type) sal_mutex_lock(mutex_type)

#define CHIP_AGT_UNLOCK(mutex_type) \
    if (mutex_type) sal_mutex_unlock(mutex_type)


#define ENCODE_PUTC(V)                      \
    do {                                    \
        *(*pnt) = (V) & 0xFF;               \
        (*pnt)++;                           \
        (*size)--;                          \
    } while (0)

#define ENCODE_PUTW(V)                      \
    do {                                    \
        *(*pnt) = ((V) >> 8) & 0xFF;        \
        *(*pnt + 1) = (V) & 0xFF;           \
        *pnt += 2;                          \
        *size -= 2;                         \
    } while (0)

#define ENCODE_PUTL(V)                      \
    do {                                    \
        *(*pnt) = ((V) >> 24) & 0xFF;       \
        *(*pnt + 1) = ((V) >> 16) & 0xFF;   \
        *(*pnt + 2) = ((V) >> 8) & 0xFF;    \
        *(*pnt + 3) = (V) & 0xFF;           \
        *pnt += 4;                          \
        *size -= 4;                         \
    } while (0)

#define ENCODE_PUT_EMPTY(L)                 \
    do {                                    \
        sal_memset((void*)(*pnt), 0, (L));  \
        *pnt += (L);                        \
        *size -= (L);                       \
    } while (0)

#define ENCODE_PUT(P, L)                                    \
    do {                                                    \
        sal_memcpy((void*)(*pnt), (void*)(P), (L));         \
        *pnt += (L);                                        \
        *size -= (L);                                       \
    } while (0)

#define DECODE_GETC(V)                                      \
    do {                                                    \
        (V) = **pnt;                                        \
        (*pnt)++;                                           \
        (*size)--;                                          \
    } while (0)

#define DECODE_GETW(V)                                      \
    do {                                                    \
        (V) = ((*(*pnt)) << 8)                              \
            + (*(*pnt + 1));                              \
        *pnt += 2;                                          \
        *size -= 2;                                         \
    } while (0)

#define DECODE_GETL(V)                                      \
    do {                                                    \
        (V) = ((uint32_t)(*(*pnt)) << 24)                   \
            + ((uint32_t)(*(*pnt + 1)) << 16)             \
            + ((uint32_t)(*(*pnt + 2)) << 8)              \
            + (uint32_t)(*(*pnt + 3));                    \
        *pnt += 4;                                          \
        *size -= 4;                                         \
    } while (0)

#define DECODE_GET(V, L)                                    \
    do {                                                    \
        sal_memcpy((void*)(V), (const void*)(*pnt), (L));   \
        *pnt += (L);                                        \
        *size -= (L);                                       \
    } while (0)

#define DECODE_GET_EMPTY(L)                                 \
    do {                                                    \
        *pnt += (L);                                        \
        *size -= (L);                                       \
    } while (0)

#define CHIP_AGT_DECODE_BUF(P, L)                           \
    do {                                                    \
        if (L)                                              \
        {                                                   \
            if ((P))                                        \
            {                                               \
                DECODE_GET((P), (L));                       \
            }                                               \
            else                                            \
            {                                               \
                return CHIP_AGT_E_DECODE_NULL_PTR;          \
            }                                               \
        }                                                   \
    } while (0)

#endif

typedef enum chip_agent_dec_rc_e
{
    CHIP_AGT_DEC_OK,           /* Decoded successfully */
    CHIP_AGT_DEC_MORE,         /* More data expected, call again */
    CHIP_AGT_DEC_FAIL          /* Failure to decode data */
} chip_agent_dec_rc_t;

typedef enum
{
    CHIP_AGT_SIM_DBG_ACT_STOP = 0x0,
    CHIP_AGT_SIM_DBG_ACT_LOCAL_PRINTF,
    CHIP_AGT_SIM_DBG_ACT_REMOTE_PRINTF,
    CHIP_AGT_SIM_DBG_ACT_REMOTE_FILE
} chip_agent_sim_dbg_action_t;

typedef struct chip_agent_dec_ret_s
{
    chip_agent_dec_rc_t code;      /* Result code */
    uint32 consumed;        /* Number of bytes consumed */
} chip_agent_dec_ret_t;

typedef struct chip_agent_msg_hdr_s
{
    uint8   version;
    uint8   type;
    uint16  length;
    uint32  seq;
    uint8*  data;
} chip_agent_msg_hdr_t;

extern chip_agent_t  g_chip_agent;

char*
chip_agent_msg_type_str(uint32 type);

int32
chip_agent_send(chip_agent_sock_session_t* p_session, chip_agent_msg_type_t type, uint8* p_req, uint32 req_len);

int32
chip_agent_send_syn(chip_agent_sock_session_t* p_session, chip_agent_msg_type_t type, uint8* p_req, uint32 req_len,
                    uint8* p_resp, uint32* p_resp_len);


int32
chip_agent_client_recv(chip_agent_sock_session_t* p_session, chip_agent_msg_hdr_t* p_hdr);

int32
chip_agent_server_recv(chip_agent_sock_session_t* p_session, chip_agent_msg_hdr_t* p_hdr);

int32
chip_agent_sock_client_global_init(void);

int32
chip_agent_sock_client_init(char* address, uint32 port, uint32 server_id);

int32
chip_agent_sock_server_init(uint32 port);

int32
chip_agent_dma_sock_client_init(char* address, uint32 port, uint32 server_id);

int32
chip_agent_add_cache_entry(chip_agent_cache_info_t* p_cache, sal_systime_t* tv, uint32 seq, uint8* data, uint32 len);

int32
chip_agent_client_init();

int32
chip_agent_client_deinit();

#endif /*end of _CHIP_AGENT_PRIV_H_*/


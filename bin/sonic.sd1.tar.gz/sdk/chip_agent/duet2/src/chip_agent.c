/**
 @file chip_agent.c

 @author  Copyright (C) 2011 Centec Networks Inc.  All rights reserved.

 @date 2012-08-16

 @version v2.0

 This file contains chip agent related function.
*/

#ifdef CHIP_AGENT
#include "sal.h"
#include "ctc_error.h"
#include "ctc_debug.h"
#include "ctc_const.h"
#include "ctc_interrupt.h"
#include "ctc_learning_aging.h"
#include "ctc_ipfix.h"
#include "ctc_monitor.h"
#include "ctc_oam.h"
#include "drv_api.h"
#include "chip_agent.h"
#include "chip_agent_priv.h"
#include "drv_chip_agent.h"
#include "ctc_packet.h"
#include "../../app/sample/ctc_app_packet.h"


#include "ctc_api.h"
#define EADP_DMA_PACKET_SIZE_PER_DESC 256     /* minisize is 256Bytes */
#define EADP_DMA_SOCKET_PATH       "/tmp/.eadp_dma_socket_msg"

chip_agent_t g_chip_agent;




#define CTC_CHIP_AGENT_CONFIG "chip_agent.cfg"

extern int32
ctc_cli_set_gw(char* gw_address, uint32 is_add);


#if (SDK_WORK_PLATFORM == 1 && SDK_WORK_ENV == 1)  /*simulation */

#if 0 //NotSupport CPU Tx
extern int32
swemu_received_cpu_packet_process(uint8* packet,
                                  uint32 len,
                                  uint32 mode,
                                  uint32 chipid_offset);
#endif

extern bool cmodel_internal_output;
extern bool ctc_cmodel_debug_on;
extern uint32 ctc_cmodel_debug_flag;
#else


#endif



#define CHIP_AGENT_MISC_FUNC

static char*
_chip_agent_engine_str(uint32 is_asic)
{
    if (is_asic)
    {
        return "asic";
    }
    else
    {
        return "simulator";
    }
}

static char*
_chip_agent_get_ver_date(uint32 is_ver, char* buf)
{
    if (is_ver)
    {
        sal_strcpy(buf, CTC_SDK_VERSION_STR);
    }
    else
    {
        sal_strcpy(buf, CTC_SDK_RELEASE_DATE);
    }

    return buf;
}

static char*
_chip_agent_endian_op_str(chip_agent_endian_op_t op)
{
    switch (op)
    {
    case CHIP_AGT_ENDIAN_OP_NONE:
        return "no swap";

    case CHIP_AGT_ENDIAN_OP_LITTLE_TO_BIG:
        return "little to big";

    case CHIP_AGT_ENDIAN_OP_BIG_TO_LITTLE:
        return "big to little";

    default:
        return "invalid";
    }
}

static int32
_chip_agent_dump8(uint8* data, uint32 len, uint32 is_log)
{
    uint32 cnt = 0;
    char line[256];
    char tmp[32];

    if (0 == len)
    {
        return CHIP_AGT_E_NONE;
    }

    for (cnt = 0; cnt < len; cnt++)
    {
        if ((cnt % 16) == 0)
        {
            if (cnt != 0)
            {
                if (is_log)
                {
                    CHIP_AGT_LOG("%s", line);
                }
                else
                {
                    CHIP_AGT_DBG_CODE("%s", line);
                }
            }

            sal_memset(line, 0, sizeof(line));
            sal_snprintf(tmp, 32, "\n0x%04x:  ", cnt);
            sal_strcat(line, tmp);
        }

        sal_snprintf(tmp, 32, "%02x", data[cnt]);
        sal_strcat(line, tmp);

        if ((cnt % 2) == 1)
        {
            sal_strcat(line, " ");
        }
    }

    if (is_log)
    {
        CHIP_AGT_LOG("%s", line);
    }
    else
    {
        CHIP_AGT_DBG_CODE("%s", line);
    }

    if (is_log)
    {
        CHIP_AGT_LOG("\n");
    }
    else
    {
        CHIP_AGT_DBG_CODE("\n");
    }

    return CHIP_AGT_E_NONE;
}

static int32
_chip_agent_dump32(uint32* data, uint32 len, uint32 converted)
{
    uint32 cnt = 0;

    CHIP_AGT_DBG_CODE(CHIP_AGT_STR "endian %s convert", (converted) ? "after" : "before");

    for (cnt = 0; cnt < len; cnt++)
    {
        if ((cnt % 8) == 0)
        {
            CHIP_AGT_DBG_CODE("\n%04d:  ", cnt);
        }

        CHIP_AGT_DBG_CODE("%08X ", data[cnt]);
    }

    CHIP_AGT_DBG_CODE("\n");

    return CHIP_AGT_E_NONE;
}



static int32
_chip_agent_force_swap32(uint32* data, uint32 len, chip_agent_endian_op_t op)
{
    uint32 cnt = 0;

    for (cnt = 0; cnt < len; cnt++)
    {
        data[cnt] = SWAP32(data[cnt]);
    }

    return CHIP_AGT_E_NONE;
}

static int32
_chip_agent_endian_convert(chip_agent_endian_op_t op, uint8* data, uint32 len)
{
    uint32 dword_len = CHIP_AGT_E_NONE;
    int32 ret = CHIP_AGT_E_NONE;

    if (len == 0)
    {
        return CHIP_AGT_E_NONE;
    }

    dword_len = len / 4;

    CHIP_AGT_DBG_CODE(CHIP_AGT_STR "endian action %s length %d\n", _chip_agent_endian_op_str(op), len);
    _chip_agent_dump32((uint32*)data, dword_len, FALSE);

    if ((len % 4) != 0)
    {
        return CHIP_AGT_E_GEN;
    }

    switch (op)
    {
    case CHIP_AGT_ENDIAN_OP_NONE:
        return CHIP_AGT_E_NONE;

    case CHIP_AGT_ENDIAN_OP_LITTLE_TO_BIG:
        ret = _chip_agent_force_swap32((uint32*)data, dword_len, CHIP_AGT_ENDIAN_OP_LITTLE_TO_BIG);
        break;

    case CHIP_AGT_ENDIAN_OP_BIG_TO_LITTLE:
        ret = _chip_agent_force_swap32((uint32*)data, dword_len, CHIP_AGT_ENDIAN_OP_BIG_TO_LITTLE);
        break;

    default:
        return CHIP_AGT_E_GEN;
    }

    _chip_agent_dump32((uint32*)data, dword_len, TRUE);

    return ret;
}

char*
chip_agent_msg_type_str(uint32 type)
{
    switch (type)
    {
    case CHIP_AGT_MSG_INIT:
        return "Init";

    case CHIP_AGT_MSG_MODEL:
        return "Model";

    case CHIP_AGT_MSG_CTRL:
        return "Control";

    case CHIP_AGT_MSG_IO:
        return "IO";

    case CHIP_AGT_MSG_RESP:
        return "Resp";

    case CHIP_AGT_MSG_PACKET:
        return "Packet";

    case CHIP_AGT_MSG_INTERRUPT:
        return "Interrupt";

    case CHIP_AGT_MSG_DMA:
        return "DMA";

    case CHIP_AGT_MSG_LOG:
        return "Log";

    default:
        return "Unknown";
    }
}

char*
chip_agent_error_str(int32 error)
{
    switch (error)
    {
    case CHIP_AGT_E_NONE:
        return "success";

    case CHIP_AGT_E_GEN:
        return "general";

    case CHIP_AGT_E_TASK:
        return "task create";

    case CHIP_AGT_E_MUTEX_CREAT:
        return "mutex create fail";

    case CHIP_AGT_E_MODE_SERVER:
        return "has been in server mode";

    case CHIP_AGT_E_MODE_CLIENT:
        return "cannot change server-ip";

    case CHIP_AGT_E_SOCK_SYNC_TO:
        return "socket sync timeout";

    case CHIP_AGT_E_SOCK_ERROR:
        return "socket error";

    case CHIP_AGT_E_SOCK_CREAT:
        return "socket create";

    case CHIP_AGT_E_SOCK_EXIST:
        return "socket exist";

    case CHIP_AGT_E_SOCK_NONEXIST:
        return "socket not exist";

    case CHIP_AGT_E_SOCK_SET_OPT:
        return "socket set option";

    case CHIP_AGT_E_SOCK_ADDR:
        return "invalid IP address";

    case CHIP_AGT_E_SOCK_CONNECT:
        return "socket connected";

    case CHIP_AGT_E_SOCK_NOT_CONNECT:
        return "socket not connected";

    case CHIP_AGT_E_SOCK_BIND:
        return "socket bind";

    case CHIP_AGT_E_SOCK_LISTEN:
        return "socket listen";

    case CHIP_AGT_E_MSG_LEN:
        return "message length";

    case CHIP_AGT_E_MSG_LEN_EXCEED:
        return "message length exceed";

    case CHIP_AGT_E_MSG_IO_TYPE:
        return "invalid driver IO type";

    case CHIP_AGT_E_IO_UNSUP:
        return "unsupport driver IO operation";

    case CHIP_AGT_E_VER_MISMATCH:
        return "SDK version mismatch";

    case CHIP_AGT_E_DATE_MISMATCH:
        return "SDK date mismatch";

    case CHIP_AGT_E_PROFILE_MISMATCH:
        return "SDK profile type mismatch";

    case CHIP_AGT_E_ENGINE_MISMATCH:
        return "EADP Engine mismatch";

    case CHIP_AGT_E_DECODE_NULL_PTR:
        return "NULL pointer when decode";

    case CHIP_AGT_E_DECODE_ZERO_LEN:
        return "zero length when decode";

    case CHIP_AGT_E_SIM_DGB_ACT_SAME:
        return "simulator debug already in this action";

    case CHIP_AGT_E_SIM_DGB_ACT_LOCAL_PRINTF:
        return "simulator debug already in Log print on server";

    case CHIP_AGT_E_SIM_DGB_ACT_REMOTE_PRINTF:
        return "simulator debug already in Log print on client";

    case CHIP_AGT_E_SIM_DGB_ACT_REMOTE_FILE:
        return "simulator debug already in Log file on client";

    default:
        return "Unknown";
    }
}

char*
chip_agent_sim_dbg_action_str(uint32 action)
{
    switch (action)
    {
    case CHIP_AGT_SIM_DBG_ACT_STOP:
        return "Stop";

    case CHIP_AGT_SIM_DBG_ACT_LOCAL_PRINTF:
        return "Log print on server";

    case CHIP_AGT_SIM_DBG_ACT_REMOTE_PRINTF:
        return "Log print on client";

    case CHIP_AGT_SIM_DBG_ACT_REMOTE_FILE:
        return "Log file on client";

    default:
        return "Unknown";
    }
}



static chip_agent_sock_session_t*
_chip_agent_get_send_session(chip_agent_msg_type_t type, uint8 server_id)
{
    if (CHIP_AGT_MODE_SERVER == g_chip_agent.mode)
    {
        switch (type)
        {
        case CHIP_AGT_MSG_RESP:
            return &(g_chip_agent.server.session[CHIP_AGT_SOCK_SYNC]);

        case CHIP_AGT_MSG_PACKET:
        case CHIP_AGT_MSG_INTERRUPT:
        case CHIP_AGT_MSG_DMA:
        case CHIP_AGT_MSG_LOG:
        case CHIP_AGT_MSG_RX_PACKET:
        case CHIP_AGT_MSG_OAM_ISR:
            return &(g_chip_agent.server.session[CHIP_AGT_SOCK_ASYNC]);

        case CHIP_AGT_MSG_DMA_PACKET:
            return &(g_chip_agent.dma_client.client_single[server_id].session[CHIP_AGT_SOCK_ASYNC]);

        default:
            return NULL;
        }
    }
    else
    {
        switch (type)
        {
            case CHIP_AGT_MSG_INIT:
            case CHIP_AGT_MSG_MODEL:
            case CHIP_AGT_MSG_CTRL:
            case CHIP_AGT_MSG_IO:
                return &(g_chip_agent.client.client_single[server_id].session[CHIP_AGT_SOCK_SYNC]);

            case CHIP_AGT_MSG_PACKET:
                return &(g_chip_agent.client.client_single[server_id].session[CHIP_AGT_SOCK_ASYNC]);

            case CHIP_AGT_MSG_DMA_PACKET:
                return &(g_chip_agent.dma_server.session[CHIP_AGT_SOCK_ASYNC]);

            default:
                return NULL;
        }
    }
}

static chip_agent_endian_op_t
_chip_agent_server_get_endian_op()
{
    return g_chip_agent.server.endian_op;
}

uint32
chip_agent_get_mode()
{
    return g_chip_agent.mode;
}

uint32
chip_agent_engine_is_asic()
{
    return g_chip_agent.cfg.is_asic;
}

uint32
chip_agent_get_standalone()
{
    return g_chip_agent.cfg.standalone;
}

uint32
chip_agent_get_cpu_mirror_port()
{
    return g_chip_agent.cfg.mirror_port;
}

#define CHIP_AGENT_OUT_API
int32
chip_agent_client_set_pkt_rx_print_en(uint32 enable)
{
    g_chip_agent.cfg.print_pkt_rx = enable;
    return CHIP_AGT_E_NONE;
}

static int32
_chip_agent_dma_type_copy_data(uint8 type, chip_agent_msg_dma_para_t* para, void*  p_dma_info)
{
    uint32 i = 0;
    uint8 *pnt = NULL;
    uint32 number = 0;
    ctc_learning_cache_entry_t*  p_learn_data = NULL;
    ctc_aging_info_entry_t*      p_aging_data = NULL;
    ctc_ipfix_data_t*            p_ipfix_data = NULL;

    switch (type)
    {
    case CHIP_AGENT_DMA_INFO_TYPE_LEARN:
        p_learn_data = ((ctc_learning_cache_t* )p_dma_info)->learning_entry;
        number = ((ctc_learning_cache_t* )p_dma_info)->entry_num;
        pnt = (uint8 *)para->data_buf;
        for(i = 0; i < number; i++)
        {
            p_learn_data->logic_port  = sal_htons(p_learn_data->logic_port);
            p_learn_data->fid  = sal_htons(p_learn_data->fid);
            p_learn_data->global_src_port  = sal_htons(p_learn_data->global_src_port);
            p_learn_data->cvlan_id  = sal_htons(p_learn_data->cvlan_id);
            p_learn_data->svlan_id  = sal_htons(p_learn_data->svlan_id);

            sal_memcpy((void*)pnt, p_learn_data, sizeof(ctc_learning_cache_entry_t));
            pnt += sizeof(ctc_learning_cache_entry_t);
            p_learn_data = (ctc_learning_cache_entry_t*)((uint8*)p_learn_data+sizeof(ctc_learning_cache_entry_t));
        }
        break;

    case CHIP_AGENT_DMA_INFO_TYPE_AGING:
        p_aging_data = ((ctc_aging_fifo_info_t*)p_dma_info)->aging_entry;;
        number = ((ctc_aging_fifo_info_t* )p_dma_info)->fifo_idx_num;
        pnt = (uint8 *)para->data_buf;
        for(i = 0; i < number; i++)
        {
            p_aging_data->fid  = sal_htons(p_aging_data->fid);
            p_aging_data->vrf_id  = sal_htons(p_aging_data->vrf_id);
            p_aging_data->ip_da.ipv6[0] =  sal_htonl(p_aging_data->ip_da.ipv6[0]);
            p_aging_data->ip_da.ipv6[1] =  sal_htonl(p_aging_data->ip_da.ipv6[1]);
            p_aging_data->ip_da.ipv6[2] =  sal_htonl(p_aging_data->ip_da.ipv6[2]);
            p_aging_data->ip_da.ipv6[3] =  sal_htonl(p_aging_data->ip_da.ipv6[3]);

            sal_memcpy((void*)pnt, p_aging_data, sizeof(ctc_aging_info_entry_t));
            pnt += sizeof(ctc_aging_info_entry_t);
            p_aging_data = (ctc_aging_info_entry_t*)((uint8*)p_aging_data+sizeof(ctc_aging_info_entry_t));
        }
        break;

    case CHIP_AGENT_DMA_INFO_TYPE_IPFIX:
        p_ipfix_data = (ctc_ipfix_data_t* )p_dma_info;
        p_ipfix_data->dir = sal_htonl(p_ipfix_data->dir);
        p_ipfix_data->export_reason = sal_htonl(p_ipfix_data->export_reason);
        p_ipfix_data->flags = sal_htonl(p_ipfix_data->flags);
        p_ipfix_data->gport = sal_htons(p_ipfix_data->gport);
        p_ipfix_data->logic_port = sal_htons(p_ipfix_data->logic_port);
        p_ipfix_data->svlan = sal_htons(p_ipfix_data->svlan);
        p_ipfix_data->svlan_prio = sal_htons(p_ipfix_data->svlan_prio);
        p_ipfix_data->ether_type = sal_htons(p_ipfix_data->ether_type);
        //p_ipfix_data->rsv = sal_htons(p_ipfix_data->rsv);

        p_ipfix_data->l3_info.ipv4.ipda = sal_htonl(p_ipfix_data->l3_info.ipv4.ipda);
        p_ipfix_data->l3_info.ipv4.ipsa = sal_htonl(p_ipfix_data->l3_info.ipv4.ipsa);
        p_ipfix_data->l3_info.ipv6.ipda[0] = sal_htonl(p_ipfix_data->l3_info.ipv6.ipda[0]);
        p_ipfix_data->l3_info.ipv6.ipda[1] = sal_htonl(p_ipfix_data->l3_info.ipv6.ipda[1]);
        p_ipfix_data->l3_info.ipv6.ipda[2] = sal_htonl(p_ipfix_data->l3_info.ipv6.ipda[2]);
        p_ipfix_data->l3_info.ipv6.ipda[3] = sal_htonl(p_ipfix_data->l3_info.ipv6.ipda[3]);
        p_ipfix_data->l3_info.ipv6.ipsa[0] = sal_htonl(p_ipfix_data->l3_info.ipv6.ipsa[0]);
        p_ipfix_data->l3_info.ipv6.ipsa[1] = sal_htonl(p_ipfix_data->l3_info.ipv6.ipsa[1]);
        p_ipfix_data->l3_info.ipv6.ipsa[2] = sal_htonl(p_ipfix_data->l3_info.ipv6.ipsa[2]);
        p_ipfix_data->l3_info.ipv6.ipsa[3] = sal_htonl(p_ipfix_data->l3_info.ipv6.ipsa[3]);
        p_ipfix_data->l3_info.mpls.label[0].label = sal_htonl(p_ipfix_data->l3_info.mpls.label[0].label);
        p_ipfix_data->l3_info.mpls.label[1].label = sal_htonl(p_ipfix_data->l3_info.mpls.label[1].label);
        p_ipfix_data->l3_info.mpls.label[2].label = sal_htonl(p_ipfix_data->l3_info.mpls.label[2].label);

        p_ipfix_data->l4_info.l4_port.source_port = sal_htons(p_ipfix_data->l4_info.l4_port.source_port);
        p_ipfix_data->l4_info.l4_port.dest_port = sal_htons(p_ipfix_data->l4_info.l4_port.dest_port);
        p_ipfix_data->l4_info.gre_key = sal_htonl(p_ipfix_data->l4_info.gre_key);
        p_ipfix_data->l4_info.vni = sal_htonl(p_ipfix_data->l4_info.vni);

        p_ipfix_data->start_timestamp = sal_htonl(p_ipfix_data->start_timestamp);
        p_ipfix_data->last_timestamp = sal_htonl(p_ipfix_data->last_timestamp);
        p_ipfix_data->byte_count = sal_htonl(p_ipfix_data->byte_count);
        p_ipfix_data->pkt_count = sal_htonl(p_ipfix_data->pkt_count);
        p_ipfix_data->dest_gport = sal_htons(p_ipfix_data->dest_gport);
        p_ipfix_data->dest_group_id = sal_htons(p_ipfix_data->dest_group_id);

        sal_memcpy((void*)para->data_buf, p_ipfix_data,sizeof(ctc_ipfix_data_t));
        break;

    case CHIP_AGENT_DMA_INFO_TYPE_MONITOR:
        sal_memcpy((void*)para->data_buf, p_dma_info,sizeof(ctc_monitor_data_t));
        break;

    default:
        return CHIP_AGT_E_GEN;
    }

    return CHIP_AGT_E_NONE;

}


#define GG_CHIP_AGENT_DONT_USE

int32
chip_agent_server_set_sim_dbg_action(uint32 action)
{
    return CHIP_AGT_E_NONE;
}



uint32
chip_agent_server_get_sim_dbg_action()
{
#if (SDK_WORK_PLATFORM == 1 && SDK_WORK_ENV == 1)  /*simulation */
    return g_chip_agent.server.sim_debug_action;
#else
    return 0;
#endif
}




#define CHIP_AGENT_SOCK_PROCESS


 int32
_chip_agent_dma_sock_client_recv_pkt(chip_agent_sock_session_t* p_session, chip_agent_msg_hdr_t* p_hdr)
{
    chip_agent_msg_pkt_para_t para;
    uint8 pkt_buf[CHIP_AGT_BUF_SIZE];

    para.pkt_len = 0;
    para.pkt = pkt_buf;

    DRV_IF_ERROR_RETURN(drv_agent_decode_pkt(p_hdr->data, &para, p_hdr->length));

    /* call dma??? */

    return CHIP_AGT_E_NONE;
}

int32
chip_agent_client_send_init(void* param)
{
    chip_agent_msg_init_para_t para;
    uint8 tx_buf[CHIP_AGT_BUF_SIZE];
    uint8 rx_buf[CHIP_AGT_BUF_SIZE];
    char lver_buf[64];
    char ldate_buf[64];
    char ver_buf[64];
    char date_buf[64];
    uint8* req = tx_buf;
    uint8* data = req + CHIP_AGT_HDR_SIZE;
    uint8* resp = rx_buf;
    uint32 req_len = 0;
    uint32 resp_len = 0;
    uint32 lprofile_type = 0;
    int32 ret = 0;
    chip_agent_sock_session_t* p_session = (chip_agent_sock_session_t*)param;

    if (NULL == p_session)
    {
        return CHIP_AGT_E_GEN;
    }

    if (!p_session->connected)
    {
        CHIP_AGT_LOG(CHIP_AGT_STR "chip_agent_client_send_init does not connectted\n");
        return CHIP_AGT_E_SOCK_NOT_CONNECT;
    }

        CHIP_AGT_LOG(CHIP_AGT_STR "chip_agent_client_send_init()!!!!!!!\n");

    sal_memset(&para, 0, sizeof(para));
    sal_memset(&lver_buf, 0, sizeof(lver_buf));
    sal_memset(&ldate_buf, 0, sizeof(ldate_buf));
    sal_memset(&ver_buf, 0, sizeof(ver_buf));
    sal_memset(&date_buf, 0, sizeof(date_buf));

    //sys_greatbelt_ftm_get_profile(&lprofile_type); ???
    para.profile_type = lprofile_type;
    para.endian = HOST_IS_LE;
    para.is_asic = g_chip_agent.cfg.is_asic;
    para.sim_debug_action = g_chip_agent.client.sim_debug_action;
    para.sim_packet_debug = TRUE;
    para.ver = lver_buf;
    para.date = ldate_buf;
    _chip_agent_get_ver_date(TRUE, para.ver);
    para.ver_len = sal_strlen(para.ver) + 1;
    _chip_agent_get_ver_date(FALSE, para.date);
    para.date_len = sal_strlen(para.date) + 1;
    DRV_IF_ERROR_RETURN(drv_agent_encode_init(data, &para, &req_len));
    DRV_IF_ERROR_RETURN(chip_agent_send_syn(p_session, CHIP_AGT_MSG_INIT, req, req_len, resp, &resp_len));
    para.ver = ver_buf;
    para.date = date_buf;
    ret = drv_agent_decode_init(resp, &para, resp_len);

    if (ret)
    {
        return ret;
    }

    switch (para.ret)
    {
    case CHIP_AGT_E_NONE:
        CHIP_AGT_ERR("Version %s, Date %s, Profile Type %d Match\n", lver_buf, ldate_buf, lprofile_type);
        break;

    case CHIP_AGT_E_VER_MISMATCH:
        CHIP_AGT_ERR("Version Mismatch : client is %s, server is %s\n", lver_buf, ver_buf);
        break;

    case CHIP_AGT_E_DATE_MISMATCH:
        CHIP_AGT_ERR("Date Mismatch : client is %s, server is %s\n", ldate_buf, date_buf);
        break;

    case CHIP_AGT_E_PROFILE_MISMATCH:
        CHIP_AGT_ERR("Profile Mismatch : client is %d, server is %d\n", lprofile_type, para.profile_type);
        break;

    case CHIP_AGT_E_ENGINE_MISMATCH:
        CHIP_AGT_ERR("Engine Mismatch : client is %s, server is %s\n",
            _chip_agent_engine_str(g_chip_agent.cfg.is_asic), _chip_agent_engine_str(para.is_asic));
        break;

    default:
        CHIP_AGT_ERR("Init check failed for unexpected error code %d\n", para.ret);
        break;
    }

    return para.ret;
}





#define CHIP_AGENT_DUMP_DEBUG


uint32
chip_agent_server_get_sim_chip_model()
{
#if 0
#if (SDK_WORK_PLATFORM == 1 && SDK_WORK_ENV == 1)  /*simulation */
    return ctc_cmodel_debug_flag;
#else
    return 0;
#endif
#endif
    return 0;
}

int32
chip_agent_client_set_ctrl_en(uint32 type, uint32 flag, uint32 enable)
{
    chip_agent_msg_ctrl_para_t para;
    uint8 tx_buf[CHIP_AGT_BUF_SIZE];
    uint8 rx_buf[CHIP_AGT_BUF_SIZE];
    uint8* req = tx_buf;
    uint8* data = req + CHIP_AGT_HDR_SIZE;
    uint8* resp = rx_buf;
    uint32 req_len = 0;
    uint32 resp_len = 0;
    int32 ret = 0;
    chip_agent_sock_session_t* p_session = NULL;

    p_session = _chip_agent_get_send_session(CHIP_AGT_MSG_CTRL, 0);

    if (NULL == p_session)
    {
        return CHIP_AGT_E_GEN;
    }

    sal_memset(&para, 0, sizeof(para));

    para.action = CHIP_AGT_CTRL_ACT_SET;
    para.type = type;
    para.flag = flag;
    para.enable = enable;
    DRV_IF_ERROR_RETURN(drv_agent_encode_ctrl(data, &para, &req_len));
    DRV_IF_ERROR_RETURN(chip_agent_send_syn(p_session, CHIP_AGT_MSG_CTRL, req, req_len, resp, &resp_len));
    ret = drv_agent_decode_ctrl(resp, &para, resp_len);

    if (ret)
    {
        return ret;
    }

    return CHIP_AGT_E_NONE;
}

int32
chip_agent_client_get_ctrl_en(uint32 type, uint32* flag)
{
    chip_agent_msg_ctrl_para_t para;
    uint8 tx_buf[CHIP_AGT_BUF_SIZE];
    uint8 rx_buf[CHIP_AGT_BUF_SIZE];
    uint8* req = tx_buf;
    uint8* data = req + CHIP_AGT_HDR_SIZE;
    uint8* resp = rx_buf;
    uint32 req_len = 0;
    uint32 resp_len = 0;
    int32 ret = 0;
    chip_agent_sock_session_t* p_session = NULL;

    p_session = _chip_agent_get_send_session(CHIP_AGT_MSG_CTRL, 0);

    if (NULL == p_session)
    {
        return CHIP_AGT_E_GEN;
    }

    sal_memset(&para, 0, sizeof(para));

    para.action = CHIP_AGT_CTRL_ACT_GET;
    para.type = type;
    DRV_IF_ERROR_RETURN(drv_agent_encode_ctrl(data, &para, &req_len));
    DRV_IF_ERROR_RETURN(chip_agent_send_syn(p_session, CHIP_AGT_MSG_CTRL, req, req_len, resp, &resp_len));
    ret = drv_agent_decode_ctrl(resp, &para, resp_len);

    if (ret)
    {
        return ret;
    }

    *flag = para.flag;

    return CHIP_AGT_E_NONE;
}



int32
chip_agent_client_set_sim_dbg_action(uint32 action)
{
    chip_agent_sock_client_t* p_client = &g_chip_agent.client;
    int32 ret = 0;

    if (action == p_client->sim_debug_action)
    {
        return CHIP_AGT_E_SIM_DGB_ACT_SAME;
    }

    if (action)
    {
        if (CHIP_AGT_SIM_DBG_ACT_LOCAL_PRINTF == p_client->sim_debug_action)
        {
            return CHIP_AGT_E_SIM_DGB_ACT_LOCAL_PRINTF;
        }
        else if (CHIP_AGT_SIM_DBG_ACT_REMOTE_PRINTF == p_client->sim_debug_action)
        {
            return CHIP_AGT_E_SIM_DGB_ACT_REMOTE_PRINTF;
        }
        else if (CHIP_AGT_SIM_DBG_ACT_REMOTE_FILE == p_client->sim_debug_action)
        {
            return CHIP_AGT_E_SIM_DGB_ACT_REMOTE_FILE;
        }
    }

    ret = chip_agent_client_set_ctrl_en(CHIP_AGT_CTRL_DBG_ACTION, action, 0);

    if (ret < 0)
    {
        return ret;
    }

    if (CHIP_AGT_SIM_DBG_ACT_REMOTE_FILE == action)
    {
        // open file
        p_client->sim_debug_fp = fopen("simulator_log.txt", "w+");

        if (!p_client->sim_debug_fp)
        {
            return CHIP_AGT_E_GEN;
        }
    }
    else if (CHIP_AGT_SIM_DBG_ACT_STOP == action)
    {
        if (p_client->sim_debug_fp)
        {
            fclose(p_client->sim_debug_fp);
            p_client->sim_debug_fp = NULL;
        }
    }

    p_client->sim_debug_action = action;

    return CHIP_AGT_E_NONE;
}

int32
chip_agent_client_get_sim_dbg_action(uint32* action)
{
    return chip_agent_client_get_ctrl_en(CHIP_AGT_CTRL_DBG_ACTION, action);
}


static int32
_chip_agent_sock_session_dump(chip_agent_sock_session_t* p_session)
{
    chip_agent_sock_stats_t* p_stats = &p_session->stats;
    uint32 type = 0;
    uint32 total_tx = 0;
    uint32 total_rx = 0;

    CHIP_AGT_LOG("Is Server:                %d\n", p_session->is_server);
    CHIP_AGT_LOG("TX Sequence:              %d\n", p_session->tx_seq);
    CHIP_AGT_LOG("RX Sequence:              %d\n", p_session->rx_seq);
    CHIP_AGT_LOG("Socket FD:                %d\n", p_session->sock);
    CHIP_AGT_LOG("Read Thread:              %p\n", p_session->t_read);
    CHIP_AGT_LOG("TX Mutex:                 %p\n", p_session->p_tx_mutex);
    CHIP_AGT_LOG("Connected State:          %d\n", p_session->connected);
    CHIP_AGT_LOG("Buffer length:            %d\n", p_session->buf_len);

    CHIP_AGT_LOG("\nMessage Statistics\n");
    CHIP_AGT_LOG("%-10s %-10s %-10s\n", "Type", "TX", "RX");
    CHIP_AGT_LOG("--------------------------------\n");

    for (type = 0; type < CHIP_AGT_MSG_MAX; type++)
    {
        CHIP_AGT_LOG("%-10s %-10d %-10d\n", chip_agent_msg_type_str(type),
                     p_stats->normal[type].tx, p_stats->normal[type].rx);
        total_tx += p_stats->normal[type].tx;
        total_rx += p_stats->normal[type].rx;
    }

    CHIP_AGT_LOG("%-10s %-10d %-10d\n", "Total", total_tx, total_rx);

    CHIP_AGT_LOG("\nAbnormal Message Statistics\n");
    CHIP_AGT_LOG("--------------------------------\n");
    CHIP_AGT_LOG("Invalid:                  %d\n", p_stats->abnormal.invalid);
    CHIP_AGT_LOG("Version Mismatch:         %d\n", p_stats->abnormal.version_mismatch);
    CHIP_AGT_LOG("Sequence Mismatch:        %d\n", p_stats->abnormal.seq_mismatch);
    CHIP_AGT_LOG("Sync Sequence Mismatch:   %d\n", p_stats->abnormal.syn_seq_mismatch);

    return CHIP_AGT_E_NONE;
}

static int32
_chip_agent_show_drvio_cache_entry_detail(chip_agent_cache_entry_t* p_entry)
{

#if 0
    chip_agent_msg_io_hdr_t hdr;
    chip_agent_msg_io_para_t io_para;
    chip_agent_msg_tcam_remove_para_t tcam_para;
    chip_agent_msg_hash_ioctl_para_t hash_io_para;
    chip_agent_msg_hash_lookup_para_t hash_lkp_para;
    chip_agent_msg_fib_acc_t  acc_para;
    uint32 tbl_id = 0;
    char* tbl_name = NULL;

    uint32 data_entry[MAX_ENTRY_WORD] = {0};
    uint32 mask_entry[MAX_ENTRY_WORD] = {0};

    sal_memset(&hdr, 0, sizeof(hdr));
    sal_memset(&io_para, 0, sizeof(io_para));
    sal_memset(&tcam_para, 0, sizeof(tcam_para));
    sal_memset(&hash_io_para, 0, sizeof(hash_io_para));
    sal_memset(&hash_lkp_para, 0, sizeof(hash_lkp_para));
    sal_memset(&acc_para, 0, sizeof(chip_agent_msg_fib_acc_t));

    CHIP_AGT_LOG("raw data");
    _chip_agent_dump8(p_entry->data, p_entry->len, TRUE);
    CHIP_AGT_LOG("\n");

    DRV_IF_ERROR_RETURN(drv_agent_decode_io_header(p_entry->data, &hdr, p_entry->len));
    CHIP_AGT_LOG("IO header: opcode %s, chip %d, length %d\n", _chip_agent_io_op_str(hdr.op), hdr.chip_id, hdr.len);

//123
    switch (hdr.op)
    {
    case CHIP_IO_OP_IOCTL:
        io_para.val = data_entry;
        io_para.mask = mask_entry;
        DRV_IF_ERROR_RETURN(drv_agent_decode_io_ioctl(p_entry->data, &io_para, p_entry->len));
        tbl_id = DRV_IOC_MEMID(io_para.cmd);
        tbl_name = (tbl_id < MaxTblId_t) ? TABLE_NAME(tbl_id) : "Invalid";
#if 0
        CHIP_AGT_LOG("index %d, cmd 0x%08X(%s,%s/%d,%d), fld_val %d, ret %d, val_len %d, mask_len %d\n",
                     io_para.index, io_para.cmd, _chip_agent_cmd_action_str(DRV_IOC_OP(io_para.cmd)), tbl_name, tbl_id,
                     DRV_IOC_FIELDID(io_para.cmd), io_para.fld_val, io_para.ret, io_para.val_len, io_para.mask_len);
#endif

        CHIP_AGT_LOG("Table[%s], index[%d], cmd[0x%08X](%s,TableId[%d],FiledId[%d]), fld_val[%d], ret[%d], val_len[%d], mask_len[%d]\n\n",
                     tbl_name, io_para.index, io_para.cmd, _chip_agent_cmd_action_str(DRV_IOC_OP(io_para.cmd)), tbl_id,
                     DRV_IOC_FIELDID(io_para.cmd), io_para.fld_val, io_para.ret, io_para.val_len, io_para.mask_len);

        if (io_para.val_len)
        {
            CHIP_AGT_LOG("val raw data:");
            _chip_agent_dump8(io_para.val, io_para.val_len, TRUE);
        }

        if (io_para.mask_len)
        {
            CHIP_AGT_LOG("mask raw data:");
            _chip_agent_dump8(io_para.mask, io_para.mask_len, TRUE);
        }

        break;

    case CHIP_IO_OP_TCAM_REMOVE:
        DRV_IF_ERROR_RETURN(drv_agent_decode_io_tcam_remove(p_entry->data, &tcam_para, p_entry->len));
        CHIP_AGT_LOG("index %d, table_id %d, ret %d\n", tcam_para.index, tcam_para.table_id, tcam_para.ret);
        break;

    case CHIP_IO_OP_ACC:
        //DRV_IF_ERROR_RETURN(drv_agent_decode_io_fib_acc_ioctl(p_entry->data, &acc_para, p_entry->len));
        //CHIP_AGT_LOG("FIB-ACC  index[%d], acc_op_type[%s], ret[%d] \n", io_para.index, _chip_agent_cmd_fib_acc_type_str(acc_para.acc_op_type), acc_para.ret);
        break;

    case CHIP_IO_OP_FIB_ACC:
    case CHIP_IO_OP_CPU_ACC:
    case CHIP_IO_OP_IPFIX_ACC:
    case CHIP_IO_OP_HASH_KEY_IOCTL:
    case CHIP_IO_OP_HASH_LOOKUP:

    default:
        CHIP_AGT_LOG("Invalid IO opcode %d\n", hdr.op);
        break;
    }

    CHIP_AGT_LOG("-----------------------------------------\n");
#endif
    return CHIP_AGT_E_NONE;
}

static int32
_chip_agent_show_drvio_cache_dir(chip_agent_cache_info_t* p_cache, uint32 last_count, uint32 detail)
{
    chip_agent_cache_entry_t* p_entry = NULL;
    uint32 start = 0;
    uint32 count = 0;
    uint32 i = 0;
    uint32 index = 0;

    if (0 == p_cache->count)
    {
        CHIP_AGT_LOG("No entry\n");
        return CHIP_AGT_E_NONE;
    }

    if (p_cache->count >= CHIP_AGT_CACHE_SIZE)
    {
        start = p_cache->index;
        count = CHIP_AGT_CACHE_SIZE;

        if (last_count < count)
        {
            start += (count - last_count);

            if (start >= CHIP_AGT_CACHE_SIZE)
            {
                start -= CHIP_AGT_CACHE_SIZE;
            }

            count = last_count;
        }
    }
    else
    {
        start = 0;
        count = p_cache->index;

        if (last_count < count)
        {
            start += (count - last_count);

            if (start >= CHIP_AGT_CACHE_SIZE)
            {
                start -= CHIP_AGT_CACHE_SIZE;
            }

            count = last_count;
        }
    }

    CHIP_AGT_LOG("%-5s %-8s %-17s %-8s\n", "Index", "Sequence", "TimeStamp", "Length");
    CHIP_AGT_LOG("-----------------------------------------\n");

    for (i = 0, index = start; i < count; i++, index++)
    {
        if (index >= CHIP_AGT_CACHE_SIZE)
        {
            index -= CHIP_AGT_CACHE_SIZE;
        }

        p_entry = &(p_cache->entry[index]);
        CHIP_AGT_LOG("%-5d %-8d %-10d.%06d %-8d\n", i, p_entry->seq, p_entry->tv.tv_sec, p_entry->tv.tv_usec, p_entry->len);

        if (detail)
        {
            _chip_agent_show_drvio_cache_entry_detail(p_entry);
        }
    }

    return CHIP_AGT_E_NONE;
}


int32
chip_agent_show_drvio_cache(uint32 dir, uint32 last_count, uint32 detail)
{
    uint32 i = 0;

    if (CHIP_AGT_MODE_NONE == g_chip_agent.mode)
    {
        CHIP_AGT_LOG(CHIP_AGT_STR "is not configured\n");
    }
    else if (CHIP_AGT_MODE_CLIENT == g_chip_agent.mode)
    {
        for(i = 0; i < CHIP_AGT_MAX_SERVER; i++)
        {
            if (NULL != g_chip_agent.client.client_single[i].t_connect)
            {
                CHIP_AGT_LOG("########## Client %d Driver IO Cache ##########\n", i);

                if (CTC_FLAG_ISSET(dir, 0x01))
                {
                    CHIP_AGT_LOG("TX\n");
                    _chip_agent_show_drvio_cache_dir(&g_chip_agent.client.client_single[i].drvio_cache.tx, last_count, detail);
                    CHIP_AGT_LOG("\n");
                }

                if (CTC_FLAG_ISSET(dir, 0x02))
                {
                    CHIP_AGT_LOG("RX\n");
                    _chip_agent_show_drvio_cache_dir(&g_chip_agent.client.client_single[i].drvio_cache.rx, last_count, detail);
                }
            }
        }
    }
    else if (CHIP_AGT_MODE_SERVER == g_chip_agent.mode)
    {
        CHIP_AGT_LOG("########## Server Driver IO Cache ##########\n");

        if (CTC_FLAG_ISSET(dir, 0x02))
        {
            CHIP_AGT_LOG("RX\n");
            _chip_agent_show_drvio_cache_dir(&g_chip_agent.server.drvio_cache.rx, last_count, detail);
            CHIP_AGT_LOG("\n");
        }

        if (CTC_FLAG_ISSET(dir, 0x01))
        {
            CHIP_AGT_LOG("TX\n");
            _chip_agent_show_drvio_cache_dir(&g_chip_agent.server.drvio_cache.tx, last_count, detail);
        }
    }

    return CHIP_AGT_E_NONE;
}


int32
chip_agent_show()
{
    chip_agent_sock_client_t* p_client = &g_chip_agent.client;
    chip_agent_sock_single_client_t* p_single_client = NULL;
    chip_agent_sock_server_t* p_server = &g_chip_agent.server;
    uint32 i = 0;
    char ip_addr[16];
    char tmp[12];
    uint8 id_temp;

    if (CHIP_AGT_MODE_NONE == g_chip_agent.mode)
    {
        CHIP_AGT_LOG(CHIP_AGT_STR "is not configured\n");
    }
    else if (CHIP_AGT_MODE_CLIENT == g_chip_agent.mode)
    {
        CHIP_AGT_LOG("########## %s Client ##########\n", CHIP_AGT_STR);
        CHIP_AGT_LOG("Engine:                   %s\n", _chip_agent_engine_str(g_chip_agent.cfg.is_asic));
        CHIP_AGT_LOG("Simulator debug action:   %s\n", chip_agent_sim_dbg_action_str(p_client->sim_debug_action));
        CHIP_AGT_LOG("Simulator debug FP:       %p\n", p_client->sim_debug_fp);
        CHIP_AGT_LOG("Sync Timeout:             %d ms\n", p_client->sync_timeout * CHIP_AGT_SYNC_TIMEOUT);
        CHIP_AGT_LOG("Packet CPU RX Callback:   %p\n", p_client->p_pkt_rx_cb);
        CHIP_AGT_LOG("Packet CPU RX Print:      %s\n", g_chip_agent.cfg.print_pkt_rx ? "On" : "Off");

        for(id_temp = 0; id_temp < CHIP_AGT_MAX_SERVER; id_temp++)
        {
            p_single_client = &g_chip_agent.client.client_single[id_temp];
            if (NULL == p_single_client->t_connect)
            {
                continue;
            }

            sal_inet_ntop(AF_INET, &p_single_client->addr.sin_addr, ip_addr, sizeof(ip_addr));
            CHIP_AGT_LOG("########## %s Client %u ##########\n", CHIP_AGT_STR, id_temp);

            CHIP_AGT_LOG("Server Address:           %s\n", ip_addr);

            CHIP_AGT_LOG("Connecting Thread:        %p\n", p_single_client->t_connect);
            CHIP_AGT_LOG("Disconnect Count:         %d\n", p_single_client->disconnect_count);
            CHIP_AGT_LOG("Init Disconnect Count:    %d\n", p_single_client->init_disconnect_count);


            CHIP_AGT_LOG("######### Sync IO Time ######### \n");

            CHIP_AGT_LOG("%-12s %-10s \n", "MS", "Count");
            CHIP_AGT_LOG("---------------------------------- \n");

            for (i = 0; i < CHIP_AGT_SYNC_10MS_MAX; i++)
            {
                if (p_single_client->sync_10ms[i])
                {
                    sal_snprintf(tmp, 12, "[%d, %d)", i * 10, (i + 1) * 10);
                    CHIP_AGT_LOG("%-12s %-10d \n", tmp, p_single_client->sync_10ms[i]);
                }
            }

            CHIP_AGT_LOG("%-12s %-10s \n", "Second", "Count");
            CHIP_AGT_LOG("---------------------------------- \n");

            for (i = 0; i < CHIP_AGT_SYNC_SEC_MAX; i++)
            {
                if (p_single_client->sync_s[i])
                {
                    sal_snprintf(tmp, 12, "[%d, %d)", i, i + 1);
                    CHIP_AGT_LOG("%-12s %-10d \n", tmp, p_single_client->sync_s[i]);
                }
            }

            CHIP_AGT_LOG("\n########## Client Sync Session ##########\n");
            _chip_agent_sock_session_dump(&p_single_client->session[CHIP_AGT_SOCK_SYNC]);
            CHIP_AGT_LOG("\n########## Client Async Session ##########\n");
            _chip_agent_sock_session_dump(&p_single_client->session[CHIP_AGT_SOCK_ASYNC]);

            CHIP_AGT_LOG("\n");
        }
    }
    else if (CHIP_AGT_MODE_SERVER == g_chip_agent.mode)
    {
        sal_inet_ntop(AF_INET, &p_server->client_addr.sin_addr, ip_addr, sizeof(ip_addr));
        CHIP_AGT_LOG("########## %s Server ##########\n", CHIP_AGT_STR);
        CHIP_AGT_LOG("Engine:                   %s\n", _chip_agent_engine_str(g_chip_agent.cfg.is_asic));
        CHIP_AGT_LOG("Situation:                %s\n", g_chip_agent.cfg.standalone ? "standalone" : "dual");
        CHIP_AGT_LOG("Socket FD:                %d\n", p_server->sock);
        CHIP_AGT_LOG("Client Address:           %s\n", ip_addr);
        CHIP_AGT_LOG("Mirror Port for CPU:      %d\n", g_chip_agent.cfg.mirror_port);
        CHIP_AGT_LOG("Accept Thread:            %p\n", p_server->t_accept);
        CHIP_AGT_LOG("Disconnect Count:         %d\n", p_server->disconnect_count);
        CHIP_AGT_LOG("Endian Operation:         %s\n", _chip_agent_endian_op_str(p_server->endian_op));

        CHIP_AGT_LOG("######### Sync IO Time ######### \n");

        CHIP_AGT_LOG("%-12s %-10s \n", "MS", "Count");
        CHIP_AGT_LOG("-------------------------------- \n");

        for (i = 0; i < CHIP_AGT_SYNC_10MS_MAX; i++)
        {
            if (g_chip_agent.server.sync_10ms[i])
            {
                sal_snprintf(tmp, 12, "[%d, %d)", i * 10, (i + 1) * 10);
                CHIP_AGT_LOG("%-12s %-10d \n", tmp, g_chip_agent.server.sync_10ms[i]);
            }
        }

        CHIP_AGT_LOG("%-12s %-10s \n", "Second", "Count");
        CHIP_AGT_LOG("-------------------------------- \n");

        for (i = 0; i < CHIP_AGT_SYNC_SEC_MAX; i++)
        {
            if (g_chip_agent.server.sync_s[i])
            {
                sal_snprintf(tmp, 12, "[%d, %d)", i, i + 1);
                CHIP_AGT_LOG("%-12s %-10d \n", tmp, g_chip_agent.server.sync_s[i]);
            }
        }

        CHIP_AGT_LOG("\n########## Server Sync Session ##########\n");
        _chip_agent_sock_session_dump(&p_server->session[CHIP_AGT_SOCK_SYNC]);
        CHIP_AGT_LOG("\n########## Server Async Session ##########\n");
        _chip_agent_sock_session_dump(&p_server->session[CHIP_AGT_SOCK_ASYNC]);
    }

    return CHIP_AGT_E_NONE;
}


int32
chip_agent_show_error()
{
    chip_agt_err_t error;

    CHIP_AGT_LOG("%-10s %-30s\n", "NO.", "Description");

    for (error = CHIP_AGT_E_GEN; error < CHIP_AGT_E_MAX; error++)
    {
        CHIP_AGT_LOG("%-10d %-30s\n", error, chip_agent_error_str(error));
    }

    return CHIP_AGT_E_NONE;
}


int32
chip_agent_clear_stats()
{
    chip_agent_sock_single_client_t* p_single_client = NULL;
    chip_agent_sock_server_t* p_server = &g_chip_agent.server;
    chip_agent_sock_session_t* p_session = NULL;
    uint32 i = 0;

    if (CHIP_AGT_MODE_NONE == g_chip_agent.mode)
    {
        CHIP_AGT_LOG(CHIP_AGT_STR "is not configured\n");
    }
    else if (CHIP_AGT_MODE_CLIENT == g_chip_agent.mode)
    {
        for(i = 0; i < CHIP_AGT_MAX_SERVER; i++)
        {
            p_single_client = &g_chip_agent.client.client_single[i];
            p_single_client->disconnect_count = 0;
            p_single_client->init_disconnect_count = 0;
            sal_memset(p_single_client->sync_s, 0, sizeof(p_single_client->sync_s));
            sal_memset(p_single_client->sync_10ms, 0, sizeof(p_single_client->sync_10ms));

            for (i = 0; i < CHIP_AGT_SOCK_MAX; i++)
            {
                p_session = &p_single_client->session[i];
                sal_memset(&p_session->stats, 0, sizeof(p_session->stats));
            }
        }
    }
    else if (CHIP_AGT_MODE_SERVER == g_chip_agent.mode)
    {
        p_server->disconnect_count = 0;
        sal_memset(p_server->sync_s, 0, sizeof(p_server->sync_s));
        sal_memset(p_server->sync_10ms, 0, sizeof(p_server->sync_10ms));

        for (i = 0; i < CHIP_AGT_SOCK_MAX; i++)
        {
            p_session = &p_server->session[i];
            sal_memset(&p_session->stats, 0, sizeof(p_session->stats));
        }
    }

    return CHIP_AGT_E_NONE;
}


int32
chip_agent_clear_drvio_cache()
{
    chip_agent_sock_client_t* p_client = &g_chip_agent.client;
    chip_agent_sock_server_t* p_server = &g_chip_agent.server;
    uint32 i = 0;

    if (CHIP_AGT_MODE_NONE == g_chip_agent.mode)
    {
        CHIP_AGT_LOG(CHIP_AGT_STR "is not configured\n");
    }
    else if (CHIP_AGT_MODE_CLIENT == g_chip_agent.mode)
    {
        for(i = 0; i < CHIP_AGT_MAX_SERVER; i++)
        {
            sal_memset(&p_client->client_single[i].drvio_cache, 0, sizeof(p_client->client_single[i].drvio_cache));
        }
    }
    else if (CHIP_AGT_MODE_SERVER == g_chip_agent.mode)
    {
        sal_memset(&p_server->drvio_cache, 0, sizeof(p_server->drvio_cache));
    }

    return CHIP_AGT_E_NONE;
}


int32
chip_agent_add_cache_entry(chip_agent_cache_info_t* p_cache, sal_systime_t* tv, uint32 seq, uint8* data, uint32 len)
{
    chip_agent_cache_entry_t* p_entry = NULL;

    if (0 == p_cache->count)
    {
        p_cache->index = 0;
    }

    p_cache->count++;
    p_entry = &(p_cache->entry[p_cache->index]);
    sal_memcpy(&p_entry->tv, tv, sizeof(sal_systime_t));
    p_entry->seq = seq;
    p_entry->len = len;
    sal_memcpy(p_entry->data, data, len);
    p_cache->index++;

    if (p_cache->index >= CHIP_AGT_CACHE_SIZE)
    {
        p_cache->index = 0;
    }

    return CHIP_AGT_E_NONE;
}



/*---------------------------------------------------------------------------------------------------
*
*                     Client function set
*
----------------------------------------------------------------------------------------------------*/
#define CLIENT_FUNCTION_SETS



static int32
_chip_agent_client_recv_rx_pkt(chip_agent_sock_session_t* p_session, chip_agent_msg_hdr_t* p_hdr)
{
    chip_agent_msg_pkt_rx_para_t para;
    uint8 pkt_buf[CHIP_AGT_BUF_SIZE];
    uint8 i = 0;
    uint8* pnt=NULL;
    uint32 last_frag_len = 0;
    ctc_pkt_rx_t pkt_rx;
    uint8 lchip = 0;
    para.pkt_len = 0;
    para.pkt = pkt_buf;

    lchip = p_session->server_id;
    CHIP_AGT_DBG_CODE(CHIP_AGT_STR "Recv pkt from lchip %d\n", lchip);

    DRV_IF_ERROR_RETURN(drv_agent_decode_rx_pkt(p_hdr->data, &para, p_hdr->length));
    sal_memset(&pkt_rx, 0, sizeof(ctc_pkt_rx_t));
    pkt_rx.pkt_buf = (ctc_pkt_buf_t*)sal_malloc(sizeof(ctc_pkt_buf_t) * (para.buf_count));

    pkt_rx.mode = para.pkt_mode;
    pkt_rx.dma_chan = para.dma_chan;
    pkt_rx.pkt_len = para.pkt_len;
    pkt_rx.buf_count = para.buf_count;
    last_frag_len = para.pkt_buf_len;
    pnt = para.pkt;

    for(i=0;i<(para.buf_count-1);i++)
    {
        pkt_rx.pkt_buf[i].data = (uint8*)sal_malloc(EADP_DMA_PACKET_SIZE_PER_DESC);
        if(pkt_rx.pkt_buf[i].data==NULL)
        {
            CHIP_AGT_ERR("_chip_agent_client_recv_rx_pkt malloc failed!! no memory %d\n");
            return CHIP_AGT_E_NONE;
        }
        sal_memcpy((void*)pkt_rx.pkt_buf[i].data, (void*)(pnt), EADP_DMA_PACKET_SIZE_PER_DESC);
        (pkt_rx.pkt_buf[i].len) = EADP_DMA_PACKET_SIZE_PER_DESC;
        pnt += EADP_DMA_PACKET_SIZE_PER_DESC;
    }

    pkt_rx.pkt_buf[i].len = last_frag_len;
    pkt_rx.pkt_buf[i].data = (uint8*)sal_malloc(last_frag_len);
    sal_memcpy((void*)pkt_rx.pkt_buf[i].data, (void*)(pnt), last_frag_len);

    CTC_ERROR_RETURN(DRV_AGENT_FUNC(DRV_AGENT_CB_PKT_RX)(lchip, (void*)&pkt_rx));

    for(i=0;i<(para.buf_count);i++)
    {
        sal_free(pkt_rx.pkt_buf[i].data);
    }

    sal_free(pkt_rx.pkt_buf);

    return CHIP_AGT_E_NONE;
}

static int32
_chip_agent_client_recv_oam_isr(chip_agent_sock_session_t* p_session, chip_agent_msg_hdr_t* p_hdr)
{
    uint8 lchip = 0;
    void *user_data = NULL;
    DRV_AGENT_OAM_DEFECT_PROCESS_FUNC  p_oam_defect_process = NULL;


    lchip = p_session->server_id;

    CTC_ERROR_RETURN(DRV_AGENT_FUNC(DRV_AGENT_CB_GET_OAM_DEFECT)(lchip, (void**)&p_oam_defect_process, &user_data));

    if (p_oam_defect_process)
    {
        (*p_oam_defect_process)(lchip, user_data);
    }

    return CHIP_AGT_E_NONE;
}

static int32
_chip_agent_client_recv_log(chip_agent_sock_session_t* p_session, chip_agent_msg_hdr_t* p_hdr)
{
    chip_agent_sock_client_t* p_client = &g_chip_agent.client;
    chip_agent_msg_log_para_t para;
    uint8 buf[CHIP_AGT_BUF_SIZE];

    para.len = 0;
    para.data = buf;

    sal_memset(buf, 0, sizeof(buf));
    DRV_IF_ERROR_RETURN(drv_agent_decode_log(p_hdr->data, &para, p_hdr->length));

    if (CHIP_AGT_SIM_DBG_ACT_REMOTE_PRINTF == p_client->sim_debug_action)
    {
        CHIP_AGT_LOG("%s", buf);
    }
    else if (CHIP_AGT_SIM_DBG_ACT_REMOTE_FILE == p_client->sim_debug_action)
    {
        if (p_client->sim_debug_fp)
        {
            fputs((char*)buf, p_client->sim_debug_fp);
            fflush(p_client->sim_debug_fp);
        }
    }

    return CHIP_AGT_E_NONE;
}

static int32
_chip_agent_client_recv_dma_info(chip_agent_sock_session_t* p_session, chip_agent_msg_hdr_t* p_hdr)
{
    chip_agent_msg_dma_para_t *p_para = NULL;
    ctc_learning_cache_t learn_info;
    ctc_aging_fifo_info_t  aging_info;
    ctc_ipfix_data_t         ipfix_info;
    ctc_monitor_data_t       monitor_info;
    CTC_INTERRUPT_EVENT_FUNC p_dma_cb = NULL;
    ctc_ipfix_fn_t p_ipfix_cb = NULL;
    ctc_monitor_fn_t  p_monitor_cb = NULL;
    void* user_data;
    uint32 number = 0;
    uint32 i = 0;
    uint8* pnt = NULL;
    ctc_learning_cache_entry_t* p_learn_data = NULL;
    ctc_aging_info_entry_t*     p_aging_data = NULL;
    ctc_ipfix_data_t* p_ipfix_data = NULL;
    uint8 lchip = 0;
    uint8 gchip = 0;

    p_para = (chip_agent_msg_dma_para_t *)sal_malloc(sizeof(chip_agent_msg_dma_para_t));
    sal_memset(p_para, 0, sizeof(chip_agent_msg_dma_para_t));
    sal_memset(&learn_info, 0, sizeof(ctc_learning_cache_t));
    sal_memset(&aging_info, 0, sizeof(ctc_aging_info_entry_t));
    sal_memset(&ipfix_info, 0, sizeof(ctc_ipfix_data_t));
    sal_memset(&monitor_info, 0, sizeof(ctc_monitor_data_t));

    chip_agent_endian_op_t endian_op = _chip_agent_server_get_endian_op();

    DRV_IF_ERROR_RETURN(drv_agent_decode_dma(p_hdr->data, p_para, p_hdr->length));
    DRV_IF_ERROR_RETURN(_chip_agent_endian_convert(endian_op, (uint8* )p_para->data_buf, MAX_DMA_NUM*4));
    lchip = p_session->server_id;
    ctc_get_gchip_id(lchip, &gchip);

    CHIP_AGT_DBG_CODE(CHIP_AGT_STR "Recv dma info type %d from lchip %d\n", p_para->op, lchip);

    if (CHIP_AGENT_DMA_INFO_TYPE_LEARN == p_para->op)
    {
        learn_info.entry_num = p_para->num;

        number = p_para->num;
        pnt = (uint8*)learn_info.learning_entry;
        p_learn_data = (ctc_learning_cache_entry_t* )(p_para->data_buf);

        for(i=0;i<number;i++)
        {
            p_learn_data->fid  = sal_ntohs(p_learn_data->fid);
            p_learn_data->logic_port  = sal_ntohs(p_learn_data->logic_port);
            p_learn_data->cvlan_id  = sal_ntohs(p_learn_data->cvlan_id);
            p_learn_data->svlan_id  = sal_ntohs(p_learn_data->svlan_id);
            p_learn_data->global_src_port  = sal_ntohs(p_learn_data->global_src_port);

            sal_memcpy((void*)pnt, p_learn_data, sizeof(ctc_learning_cache_entry_t));
            pnt += sizeof(ctc_learning_cache_entry_t);
            p_learn_data = (ctc_learning_cache_entry_t* )((uint8*)p_learn_data+sizeof(ctc_learning_cache_entry_t));
        }
        sal_memcpy(learn_info.learning_entry, p_para->data_buf,sizeof(ctc_learning_cache_entry_t)* (p_para->num));

        learn_info.sync_mode = 1;

        DRV_AGENT_FUNC(DRV_AGENT_CB_GET_LEARN)(lchip, (void**)&p_dma_cb, &user_data);

        if (p_dma_cb)
        {
            (*p_dma_cb)(gchip, &learn_info);
        }

    }
    else if (CHIP_AGENT_DMA_INFO_TYPE_AGING == p_para->op)
    {
        aging_info.fifo_idx_num = p_para->num;

        number = p_para->num;
        pnt = (uint8*)aging_info.aging_entry;
        p_aging_data = (ctc_aging_info_entry_t* )p_para->data_buf;

        for(i=0;i<number;i++)
        {
            p_aging_data->fid  = sal_htons(p_aging_data->fid);
            p_aging_data->vrf_id  = sal_htons(p_aging_data->vrf_id);
            p_aging_data->ip_da.ipv6[0] =  sal_ntohl(p_aging_data->ip_da.ipv6[0]);
            p_aging_data->ip_da.ipv6[1] =  sal_ntohl(p_aging_data->ip_da.ipv6[1]);
            p_aging_data->ip_da.ipv6[2] =  sal_ntohl(p_aging_data->ip_da.ipv6[2]);
            p_aging_data->ip_da.ipv6[3] =  sal_ntohl(p_aging_data->ip_da.ipv6[3]);

            sal_memcpy((void*)pnt, p_aging_data, sizeof(ctc_aging_info_entry_t));
            pnt += sizeof(ctc_aging_info_entry_t);
            p_aging_data = (ctc_aging_info_entry_t* )((uint8*)p_aging_data+sizeof(ctc_aging_info_entry_t));
        }
        sal_memcpy(aging_info.aging_entry, p_para->data_buf,sizeof(ctc_aging_info_entry_t)* (p_para->num));

        aging_info.sync_mode = 1;


         DRV_AGENT_FUNC(DRV_AGENT_CB_GET_AGING)(lchip, (void**)&p_dma_cb, &user_data);
        if (p_dma_cb)
        {
            (*p_dma_cb)(gchip, &aging_info);
        }

    }
    else if (CHIP_AGENT_DMA_INFO_TYPE_IPFIX == p_para->op)
    {
        p_ipfix_data = (ctc_ipfix_data_t* )p_para->data_buf;

        p_ipfix_data->dir = sal_ntohl(p_ipfix_data->dir);
        p_ipfix_data->export_reason = sal_ntohl(p_ipfix_data->export_reason);
        p_ipfix_data->flags = sal_ntohl(p_ipfix_data->flags);
        p_ipfix_data->gport = sal_ntohs(p_ipfix_data->gport);
        p_ipfix_data->logic_port = sal_ntohs(p_ipfix_data->logic_port);
        p_ipfix_data->svlan = sal_ntohs(p_ipfix_data->svlan);
        p_ipfix_data->svlan_prio = sal_ntohs(p_ipfix_data->svlan_prio);
        p_ipfix_data->ether_type = sal_ntohs(p_ipfix_data->ether_type);

        p_ipfix_data->l3_info.ipv4.ipda = sal_ntohl(p_ipfix_data->l3_info.ipv4.ipda);
        p_ipfix_data->l3_info.ipv4.ipsa = sal_ntohl(p_ipfix_data->l3_info.ipv4.ipsa);
        p_ipfix_data->l3_info.ipv6.ipda[0] = sal_ntohl(p_ipfix_data->l3_info.ipv6.ipda[0]);
        p_ipfix_data->l3_info.ipv6.ipda[1] = sal_ntohl(p_ipfix_data->l3_info.ipv6.ipda[1]);
        p_ipfix_data->l3_info.ipv6.ipda[2] = sal_ntohl(p_ipfix_data->l3_info.ipv6.ipda[2]);
        p_ipfix_data->l3_info.ipv6.ipda[3] = sal_ntohl(p_ipfix_data->l3_info.ipv6.ipda[3]);
        p_ipfix_data->l3_info.ipv6.ipsa[0] = sal_ntohl(p_ipfix_data->l3_info.ipv6.ipsa[0]);
        p_ipfix_data->l3_info.ipv6.ipsa[1] = sal_ntohl(p_ipfix_data->l3_info.ipv6.ipsa[1]);
        p_ipfix_data->l3_info.ipv6.ipsa[2] = sal_ntohl(p_ipfix_data->l3_info.ipv6.ipsa[2]);
        p_ipfix_data->l3_info.ipv6.ipsa[3] = sal_ntohl(p_ipfix_data->l3_info.ipv6.ipsa[3]);
        p_ipfix_data->l3_info.mpls.label[0].label = sal_ntohl(p_ipfix_data->l3_info.mpls.label[0].label);
        p_ipfix_data->l3_info.mpls.label[1].label = sal_ntohl(p_ipfix_data->l3_info.mpls.label[1].label);
        p_ipfix_data->l3_info.mpls.label[2].label = sal_ntohl(p_ipfix_data->l3_info.mpls.label[2].label);

        p_ipfix_data->l4_info.l4_port.source_port = sal_ntohs(p_ipfix_data->l4_info.l4_port.source_port);
        p_ipfix_data->l4_info.l4_port.dest_port = sal_ntohs(p_ipfix_data->l4_info.l4_port.dest_port);
        p_ipfix_data->l4_info.gre_key = sal_ntohl(p_ipfix_data->l4_info.gre_key);
        p_ipfix_data->l4_info.vni = sal_ntohl(p_ipfix_data->l4_info.vni);

        p_ipfix_data->start_timestamp = sal_ntohl(p_ipfix_data->start_timestamp);
        p_ipfix_data->last_timestamp = sal_ntohl(p_ipfix_data->last_timestamp);
        p_ipfix_data->byte_count = sal_ntohl(p_ipfix_data->byte_count);
        p_ipfix_data->pkt_count = sal_ntohl(p_ipfix_data->pkt_count);
        p_ipfix_data->dest_gport = sal_ntohs(p_ipfix_data->dest_gport);
        p_ipfix_data->dest_group_id = sal_ntohs(p_ipfix_data->dest_group_id);

        sal_memcpy(&ipfix_info, p_ipfix_data,sizeof(ctc_ipfix_data_t));

        DRV_AGENT_FUNC(DRV_AGENT_CB_IPFIX_EXPORT)(lchip, p_ipfix_data->export_reason, p_ipfix_data->pkt_count, p_ipfix_data->byte_count);
        DRV_AGENT_FUNC(DRV_AGENT_CB_GET_IPFIX)(lchip, (void**)&p_ipfix_cb, &user_data);

        if (p_ipfix_cb)
        {
            (*p_ipfix_cb)(&ipfix_info, user_data);
        }
    }
    else if(CHIP_AGENT_DMA_INFO_TYPE_MONITOR == p_para->op)
    {
        sal_memcpy(&monitor_info, p_para->data_buf, sizeof(ctc_monitor_data_t));
        DRV_AGENT_FUNC(DRV_AGENT_CB_GET_MONITOR)(lchip, (void**)&p_monitor_cb, &user_data);
        if (p_monitor_cb)
        {
            (*p_monitor_cb)(&monitor_info, user_data);
        }
    }
    else
    {
        return CHIP_AGT_E_IO_UNSUP;
    }

    if(p_para)
    {
        sal_free(p_para);
        p_para = NULL;
    }

    return CHIP_AGT_E_NONE;
}

int32
chip_agent_client_recv(chip_agent_sock_session_t* p_session, chip_agent_msg_hdr_t* p_hdr)
{
    switch (p_hdr->type)
    {
    case CHIP_AGT_MSG_RX_PACKET:
        _chip_agent_client_recv_rx_pkt(p_session, p_hdr);
        break;

    case CHIP_AGT_MSG_OAM_ISR:
        _chip_agent_client_recv_oam_isr(p_session, p_hdr);
        break;

    case CHIP_AGT_MSG_LOG:
        _chip_agent_client_recv_log(p_session, p_hdr);
        break;

    case CHIP_AGT_MSG_DMA:
        _chip_agent_client_recv_dma_info(p_session, p_hdr);
        break;

    case CHIP_AGT_MSG_INIT:
    case CHIP_AGT_MSG_IO:
    case CHIP_AGT_MSG_RESP:
    case CHIP_AGT_MSG_PACKET:
    case CHIP_AGT_MSG_INTERRUPT:
    default:
        break;
    }

    return CHIP_AGT_E_NONE;
}

/*---------------------------------------------------------------------------------------------------
*
*                     Server function set
*
----------------------------------------------------------------------------------------------------*/
#define SERVER_FUNCTION_SETS

static int32
_chip_agent_server_recv_init(chip_agent_sock_session_t* p_session, chip_agent_msg_hdr_t* p_hdr)
{
    chip_agent_msg_init_para_t para;
    uint8 resp[CHIP_AGT_BUF_SIZE];
    uint8* data = &resp[CHIP_AGT_HDR_SIZE];
    uint32 resp_len = 0;
    uint32 lprofile_type = 0;
    char ver_buf[64];
    char date_buf[64];
    char lver_buf[64];
    char ldate_buf[64];
    char* l_ver = lver_buf;
    char* l_date = ldate_buf;

    sal_memset(&para, 0, sizeof(para));
    sal_memset(&ver_buf, 0, sizeof(ver_buf));
    sal_memset(&date_buf, 0, sizeof(date_buf));
    sal_memset(&lver_buf, 0, sizeof(lver_buf));
    sal_memset(&ldate_buf, 0, sizeof(ldate_buf));
    _chip_agent_get_ver_date(TRUE, l_ver);
    _chip_agent_get_ver_date(FALSE, l_date);
    // sys_greatbelt_ftm_get_profile(&lprofile_type); use what?
    para.ver = ver_buf;
    para.date = date_buf;

    DRV_IF_ERROR_RETURN(drv_agent_decode_init(p_hdr->data, &para, p_hdr->length));
    para.ret = CHIP_AGT_E_NONE;

    /* check profile type */
    if (para.profile_type != lprofile_type)
    {
        para.ret = CHIP_AGT_E_PROFILE_MISMATCH;
    }

    if (sal_strcmp(l_ver, para.ver))
    {
        para.ver = l_ver;
        para.ver_len = sal_strlen(l_ver) + 1;
        para.ret = CHIP_AGT_E_VER_MISMATCH;
    }

    if (sal_strcmp(l_date, para.date))
    {
        para.date = l_date;
        para.date_len = sal_strlen(l_date) + 1;
        para.ret = CHIP_AGT_E_DATE_MISMATCH;
    }

    if (g_chip_agent.cfg.is_asic != para.is_asic)
    {
        para.ret = CHIP_AGT_E_ENGINE_MISMATCH;
    }

    switch (para.ret)
    {
    case CHIP_AGT_E_NONE:
        CHIP_AGT_ERR("Version %s, Date %s, Profile Type %d Match\n", lver_buf, ldate_buf, lprofile_type);
        break;

    case CHIP_AGT_E_VER_MISMATCH:
        CHIP_AGT_ERR("Version Mismatch : client is %s, server is %s\n", ver_buf, lver_buf);
        break;

    case CHIP_AGT_E_DATE_MISMATCH:
        CHIP_AGT_ERR("Date Mismatch : client is %s, server is %s\n", date_buf, ldate_buf);
        break;

    case CHIP_AGT_E_PROFILE_MISMATCH:
        CHIP_AGT_ERR("Profile Mismatch : client is %d, server is %d\n", para.profile_type, lprofile_type);
        para.profile_type = lprofile_type;
        break;

    case CHIP_AGT_E_ENGINE_MISMATCH:
        CHIP_AGT_ERR("Engine Mismatch : client is %s, server is %s\n",
            _chip_agent_engine_str(para.is_asic), _chip_agent_engine_str(g_chip_agent.cfg.is_asic));
        para.is_asic = g_chip_agent.cfg.is_asic;
        break;

    default:
        CHIP_AGT_ERR("Init check failed for unexpected error code %d\n", para.ret);
        break;
    }

    if (CHIP_AGT_E_NONE == para.ret)
    {
        /* get endian */
        if (para.endian != HOST_IS_LE)
        {
            g_chip_agent.server.endian_op = (HOST_IS_LE) ? CHIP_AGT_ENDIAN_OP_BIG_TO_LITTLE : CHIP_AGT_ENDIAN_OP_LITTLE_TO_BIG;
        }
    }

    DRV_IF_ERROR_RETURN(chip_agent_server_set_sim_dbg_action(para.sim_debug_action));
    DRV_IF_ERROR_RETURN(drv_agent_encode_init(data, &para, &resp_len));
    DRV_IF_ERROR_RETURN(chip_agent_send(p_session, CHIP_AGT_MSG_RESP, resp, resp_len));

    return CHIP_AGT_E_NONE;
}

static int32
_chip_agent_server_recv_model(chip_agent_sock_session_t* p_session, chip_agent_msg_hdr_t* p_hdr)
{
    chip_agent_msg_model_para_t para;
    uint8 resp[CHIP_AGT_BUF_SIZE];
    uint8* data = &resp[CHIP_AGT_HDR_SIZE];
    uint32 resp_len = 0;

    sal_memset(&para, 0, sizeof(para));
    DRV_IF_ERROR_RETURN(drv_agent_decode_model(p_hdr->data, &para, p_hdr->length));
    para.ret = CHIP_AGT_E_NONE;

    switch (para.type)
    {
    case CHIP_AGT_MODEL_TYPE_OAM:
        para.ret = 0;
        break;

    default:
        para.ret = CTC_E_INVALID_PARAM;
        break;
    }

    /* send resp first for model maybe task many time */
    DRV_IF_ERROR_RETURN(drv_agent_encode_model(data, &para, &resp_len));
    DRV_IF_ERROR_RETURN(chip_agent_send(p_session, CHIP_AGT_MSG_RESP, resp, resp_len));

    switch (para.type)
    {
    case CHIP_AGT_MODEL_TYPE_OAM:
        break;

    default:
        return CHIP_AGT_E_NONE;
    }

    return CHIP_AGT_E_NONE;
}


static int32
_chip_agent_server_recv_ioctl(chip_agent_sock_session_t* p_session,
                              chip_agent_msg_hdr_t* p_hdr,
                              uint8* p_resp,
                              uint32* p_resp_len)
{
    tbl_entry_t tcam_key;
    chip_agent_msg_io_hdr_t hdr;
    uint32 dma_buffer[MAX_DMA_NUM] = {0};
    uint32 data_entry[MAX_ENTRY_WORD] = {0};
    uint32 mask_entry[MAX_ENTRY_WORD] = {0};
    uint8* data = &p_resp[CHIP_AGT_HDR_SIZE];
    chip_agent_msg_io_para_t msg_para;
    uint32 resp_len = 0;

    sal_memset(&msg_para, 0, sizeof(msg_para));
    sal_memset(&hdr, 0, sizeof(hdr));

    DRV_IF_ERROR_RETURN(drv_agent_decode_io_header(p_hdr->data, &hdr, p_hdr->length));

    switch (hdr.op)
    {
        case CHIP_IO_OP_IOCTL_SRAM_READ:
        case CHIP_IO_OP_IOCTL_SRAM_WRITE:
            msg_para.para.u.ioctl.val = data_entry;
            break;

        case CHIP_IO_OP_IOCTL_TCAM_READ:
        case CHIP_IO_OP_IOCTL_TCAM_WRITE:
            tcam_key.data_entry = data_entry;
            tcam_key.mask_entry = mask_entry;
            msg_para.para.u.ioctl.val = &tcam_key;
            break;

        case CHIP_IO_OP_DMA_DUMP:
            msg_para.para.u.dma_dump.val = dma_buffer;
            break;

    }

    DRV_IF_ERROR_RETURN(drv_agent_decode_io_ioctl(p_hdr->data, &msg_para, p_hdr->length));
    DRV_IF_ERROR_RETURN(drv_agent_io_callback(&msg_para));
    DRV_IF_ERROR_RETURN(drv_agent_encode_io_ioctl(data, &msg_para, &resp_len));

    DRV_IF_ERROR_RETURN(chip_agent_send(p_session, CHIP_AGT_MSG_RESP, p_resp, resp_len));

    *p_resp_len = resp_len;

    return CHIP_AGT_E_NONE;
}

static int32
_chip_agent_server_recv_pkt(chip_agent_sock_session_t* p_session, chip_agent_msg_hdr_t* p_hdr)
{
    chip_agent_msg_pkt_para_t para;
    uint8 pkt_buf[CHIP_AGT_BUF_SIZE];
    uint8* pkt = NULL;
    chip_agent_endian_op_t endian_op = _chip_agent_server_get_endian_op();

    para.pkt_len = 0;
    para.pkt = pkt_buf;

    DRV_IF_ERROR_RETURN(drv_agent_decode_pkt(p_hdr->data, &para, p_hdr->length));

    CHIP_AGT_DBG_CODE(CHIP_AGT_STR "Server recv pkt len %d\n", para.pkt_len);
    _chip_agent_dump8(para.pkt, para.pkt_len, FALSE);

    pkt = (uint8*)sal_malloc(CHIP_AGT_BUF_SIZE);

    if (!pkt)
    {
        return CHIP_AGT_E_GEN;
    }

    if(CTC_PKT_MODE_DMA == para.pkt_mode)
    {// dma mode
        DRV_IF_ERROR_RETURN(_chip_agent_endian_convert(endian_op,  para.pkt, GG_BRIDGE_HEADER_LEN));
    }

    sal_memcpy(pkt, para.pkt, para.pkt_len);

#if (SDK_WORK_PLATFORM == 1 && SDK_WORK_ENV == 1)  /*simulation */
    if(CTC_PKT_MODE_ETH == para.pkt_mode)
    {// eth mode
       //NotSupport CPU Tx  swemu_received_cpu_packet_process(pkt, para.pkt_len, para.pkt_mode, 0);
    }
    else if(CTC_PKT_MODE_DMA == para.pkt_mode)
    {
        //dma
        ctc_pkt_tx_t pkt_tx;
        sal_memset(&pkt_tx, 0, sizeof(pkt_tx));
        pkt_tx.skb.data = pkt;
        pkt_tx.skb.len = para.pkt_len;
        return DRV_AGENT_FUNC(DRV_AGENT_CB_PKT_TX)(&pkt_tx);
    }

#else
    if(CTC_PKT_MODE_DMA == para.pkt_mode)
    {
        //dma
        ctc_pkt_tx_t pkt_tx;
        sal_memset(&pkt_tx, 0, sizeof(pkt_tx));
        pkt_tx.skb.data = pkt;
        pkt_tx.skb.len = para.pkt_len;
        return DRV_AGENT_FUNC(DRV_AGENT_CB_PKT_TX)(&pkt_tx);
    }
#endif

    return CHIP_AGT_E_NONE;
}


//temp for dma socket test.
static int32
_chip_agent_dma_sock_server_recv_pkt(chip_agent_sock_session_t* p_session, chip_agent_msg_hdr_t* p_hdr)
{
    chip_agent_msg_pkt_para_t para;
    uint8 pkt_buf[CHIP_AGT_BUF_SIZE];
    uint8* pkt = NULL;

    para.pkt_len = 0;
    para.pkt = pkt_buf;

    DRV_IF_ERROR_RETURN(drv_agent_decode_pkt(p_hdr->data, &para, p_hdr->length));

    CHIP_AGT_DBG_CODE(CHIP_AGT_STR "Server recv pkt len %d\n", para.pkt_len);
    _chip_agent_dump8(para.pkt, para.pkt_len, FALSE);

    pkt = (uint8*)sal_malloc(CHIP_AGT_BUF_SIZE);

    if (!pkt)
    {
        return CHIP_AGT_E_GEN;
    }

    sal_memcpy(pkt, para.pkt, para.pkt_len);

#if (SDK_WORK_PLATFORM == 1 && SDK_WORK_ENV == 1)  /*simulation */
    if(CTC_PKT_MODE_DMA == para.pkt_mode)
    {
        //dma
        ctc_pkt_tx_t pkt_tx;
        sal_memset(&pkt_tx, 0, sizeof(pkt_tx));
        pkt_tx.skb.data = pkt;
        pkt_tx.skb.len = para.pkt_len;
        return DRV_AGENT_FUNC(DRV_AGENT_CB_PKT_TX)(&pkt_tx);
    }
    else
    {
        return CHIP_AGT_E_GEN;
    }
    //to gg cmodel cpu!???
#else
    if (g_chip_agent.server.p_pkt_rx_cb)
    {
        g_chip_agent.server.p_pkt_rx_cb((void*)pkt);
    }
#endif

    return CHIP_AGT_E_NONE;
}


int32
chip_agent_server_recv(chip_agent_sock_session_t* p_session, chip_agent_msg_hdr_t* p_hdr)
{
    chip_agent_cache_t* p_drvio_cache = &g_chip_agent.server.drvio_cache;
    sal_systime_t tv_rx;
    sal_systime_t tv_tx;
    uint32 do_sync_time = FALSE;
    int32 delta = 0;
    int32 delta_s = 0;
    int32 delta_10ms = 0;
    int32 ret = CHIP_AGT_E_NONE;
    uint8 resp[CHIP_AGT_BUF_SIZE] = {0};
    uint32 resp_len = 0;

    if (CHIP_AGT_MSG_INIT == p_hdr->type || CHIP_AGT_MSG_MODEL == p_hdr->type || CHIP_AGT_MSG_CTRL == p_hdr->type || CHIP_AGT_MSG_IO == p_hdr->type)
    {
        do_sync_time = TRUE;
    }

    if (do_sync_time)
    {
        sal_gettime(&tv_rx);
    }

    switch (p_hdr->type)
    {
    case CHIP_AGT_MSG_INIT:
        ret = _chip_agent_server_recv_init(p_session, p_hdr);
        break;

    case CHIP_AGT_MSG_MODEL:
        ret = _chip_agent_server_recv_model(p_session, p_hdr);
        break;

    case CHIP_AGT_MSG_IO:
        ret = _chip_agent_server_recv_ioctl(p_session, p_hdr, resp, &resp_len);
        break;

    case CHIP_AGT_MSG_PACKET:     /* server <-> client */
        ret = _chip_agent_server_recv_pkt(p_session, p_hdr);
        break;

    case CHIP_AGT_MSG_DMA_PACKET: /* server <-> client */
        ret = _chip_agent_dma_sock_server_recv_pkt(p_session, p_hdr);
        break;

    case CHIP_AGT_MSG_CTRL:
    case CHIP_AGT_MSG_INTERRUPT:  /* server -> client */
        break;

    default:
        break;
    }

    if (do_sync_time)
    {
        sal_gettime(&tv_tx);
        delta = (tv_tx.tv_sec - tv_rx.tv_sec) * 1000000 + (tv_tx.tv_usec - tv_rx.tv_usec);
        delta_s = delta / 1000000;
        delta_10ms = delta / 10000;

        if (delta_s < CHIP_AGT_SYNC_SEC_MAX)
        {
            g_chip_agent.server.sync_s[delta_s]++;
        }

        if (delta_10ms < CHIP_AGT_SYNC_10MS_MAX)
        {
            g_chip_agent.server.sync_10ms[delta_10ms]++;
        }

        if (CHIP_AGT_MSG_IO == p_hdr->type)
        {
            chip_agent_add_cache_entry(&p_drvio_cache->tx, &tv_tx, p_session->tx_seq, resp + CHIP_AGT_HDR_SIZE, resp_len);
            chip_agent_add_cache_entry(&p_drvio_cache->rx, &tv_rx, p_session->rx_seq, p_hdr->data, p_hdr->length);
        }
    }

    return ret;
}


/*---------------------------------------------------------------------------------------------------
*
*                     Callback function set
*
----------------------------------------------------------------------------------------------------*/
#define CALLBACK_FUNCTION_SETS

int32
chip_agent_client_register_pkt_rx_cb(CHIP_AGENT_PKT_RX_CALLBACK cb)
{
    g_chip_agent.client.p_pkt_rx_cb = cb;
    return DRV_E_NONE;
}

int32
chip_agent_server_register_pkt_rx_cb(CHIP_AGENT_PKT_RX_CALLBACK cb)
{
    g_chip_agent.server.p_pkt_rx_cb = cb;
    return DRV_E_NONE;
}


/*---------------------------------------------------------------------------------------------------
*
*                     Init function set
*
----------------------------------------------------------------------------------------------------*/
#define INIT_FUNCTION_SETS


/*************************************
*   server->client  packet rx
****************************************/
extern int32
drv_agent_encode_rx_pkt(uint8* buf, chip_agent_msg_pkt_rx_para_t* para, uint32* req_len);

int32
_chip_agent_send_pkt_rx_info(ctc_pkt_rx_t* p_pkt_rx)
{
    chip_agent_msg_pkt_rx_para_t para;
    uint8 tx_buf[CHIP_AGT_BUF_SIZE];
    uint8* req = tx_buf;
    uint8* data = req + CHIP_AGT_HDR_SIZE;
    uint32 req_len = 0;
    uint8 i = 0;
    chip_agent_sock_session_t* p_session = NULL;
    uint8* pnt = NULL;

    p_session = _chip_agent_get_send_session(CHIP_AGT_MSG_RX_PACKET, 0);

    if (NULL == p_session)
    {
        return CHIP_AGT_E_GEN;
    }

    if (p_pkt_rx->pkt_len > 2000)
    {
        return CHIP_AGT_E_MSG_LEN_EXCEED;
    }

    sal_memset(&para, 0, sizeof(para));
    para.pkt = (uint8*)sal_malloc(CHIP_AGT_BUF_SIZE);
    para.pkt_len = p_pkt_rx->pkt_len;
    para.pkt_mode = p_pkt_rx->mode;
    para.dma_chan = p_pkt_rx->dma_chan;
    para.buf_count = p_pkt_rx->buf_count;
    pnt = (para.pkt);

    for(i=0;i<para.buf_count;i++)
    {
        //para.pkt = p_pkt_rx->pkt_buf->data;
        sal_memcpy((void*)(pnt), (void*)(p_pkt_rx->pkt_buf[i].data), (p_pkt_rx->pkt_buf[i].len));
        pnt += (p_pkt_rx->pkt_buf[i].len);
    }

    para.pkt_buf_len = p_pkt_rx->pkt_buf[i-1].len;

    DRV_IF_ERROR_RETURN(drv_agent_encode_rx_pkt(data, &para, &req_len));
    DRV_IF_ERROR_RETURN(chip_agent_send(p_session, CHIP_AGT_MSG_RX_PACKET, req, req_len));

    sal_free(para.pkt);

    return CHIP_AGT_E_NONE;
}


int32
agent_agent_pkt_rx(void* p_pkt_rx)
{
    int32 ret = CTC_E_NONE;
    chip_agent_mode_t mode = CHIP_AGT_MODE_NONE;
    ctc_pkt_rx_t* p_tmp;

    p_tmp = p_pkt_rx;
    p_tmp = p_tmp;

    mode = chip_agent_get_mode();

    if (CHIP_AGT_MODE_CLIENT == mode) /* CHIP_AGT_MODE_CLIENT */
    {
        //client no dma no process.
    }
    else if (CHIP_AGT_MODE_SERVER == mode) /* CHIP_AGT_MODE_SERVER */
    {
        //chip_agent_server_send_pkt(p_tmp->pkt_buf[0].data, p_tmp->pkt_len, CTC_PKT_MODE_DMA);
        CHIP_AGT_DBG_CODE("agent_agent_pkt_rx   board-->cpu Server-->Client\n");
        _chip_agent_send_pkt_rx_info(p_pkt_rx);
    }
    else
    {
        CHIP_AGT_DBG_CODE(CHIP_AGT_STR "agent_agent_pkt_rx error!\n");
    }

    return ret;
}



/*************************************
*   server->client  dma learning sync
****************************************/

int32
chip_agent_server_send_dma_info(uint8 type, void* p_dma_info)
{
    chip_agent_msg_dma_para_t para;
    uint8 tx_buf[CHIP_AGT_BUF_SIZE];
    uint8* req = tx_buf;
    uint8* data = req + CHIP_AGT_HDR_SIZE;
    uint32 req_len = 0;
    chip_agent_sock_session_t* p_session = NULL;

    p_session = _chip_agent_get_send_session(CHIP_AGT_MSG_DMA, 0);
    if (NULL == p_session)
    {
        return CHIP_AGT_E_GEN;
    }

    sal_memset(&para, 0, sizeof(para));
    para.op = type;

    if(CHIP_AGENT_DMA_INFO_TYPE_LEARN == type)
    {
        para.num = ((ctc_learning_cache_t*)p_dma_info)->entry_num;
    }
    else if (CHIP_AGENT_DMA_INFO_TYPE_AGING == type)
    {
        para.num = ((ctc_aging_fifo_info_t*)p_dma_info)->fifo_idx_num;
    }
    else
    {
        para.num = 1;
    }

    DRV_IF_ERROR_RETURN(_chip_agent_dma_type_copy_data(type,&para,p_dma_info));
    DRV_IF_ERROR_RETURN(drv_agent_encode_dma(data, &para, &req_len));
    DRV_IF_ERROR_RETURN(chip_agent_send(p_session, CHIP_AGT_MSG_DMA, req, req_len));

    return CHIP_AGT_E_NONE;
}


int32
chip_agent_dma_sync_learning_func(uint8 gchip, void* info)
{
    uint32 mode = 0;

    mode = drv_chip_agent_mode();
    if (DRV_CHIP_AGT_MODE_SERVER == mode)  /* CHIP_AGT_MODE_SERVER */
    {
        chip_agent_server_send_dma_info(CHIP_AGENT_DMA_INFO_TYPE_LEARN, info);
    }

    return CTC_E_NONE;
}

/*************************************
*   server->client  dma aging sync
****************************************/


int32
chip_agent_dma_sync_aging_func(uint8 gchip, void* info)
{
    uint32 mode = 0;

    mode = drv_chip_agent_mode();
    if (DRV_CHIP_AGT_MODE_SERVER == mode)  /* CHIP_AGT_MODE_SERVER */
    {
        chip_agent_server_send_dma_info(CHIP_AGENT_DMA_INFO_TYPE_AGING, info);
    }

    return CTC_E_NONE;
}


/*************************************
*   server->client  oam processt
****************************************/

int32
chip_agent_server_send_oam_isr(uint8 lchip, void* p_data)
{

#if 1
    uint8 tx_buf[CHIP_AGT_BUF_SIZE];
    uint8* req = tx_buf;
    uint8* data = req + CHIP_AGT_HDR_SIZE;
    uint32 req_len = 0;
    chip_agent_sock_session_t* p_session = NULL;

    p_session = _chip_agent_get_send_session(CHIP_AGT_MSG_OAM_ISR, lchip);

    if (NULL == p_session)
    {
        return CHIP_AGT_E_GEN;
    }
     sal_printf("chip_agent_server_send_oam_isr!!!!!!!!!\n");
    DRV_IF_ERROR_RETURN(chip_agent_send(p_session, CHIP_AGT_MSG_OAM_ISR, req, req_len));
#endif

    return CHIP_AGT_E_NONE;
}


void
chip_agent_oam_process_isr(uint8 lchip, void* p_data)
{
    uint32 mode = 0;

    mode = drv_chip_agent_mode();
    if (DRV_CHIP_AGT_MODE_SERVER == mode)  /* CHIP_AGT_MODE_SERVER */
    {
        chip_agent_server_send_oam_isr(lchip, p_data);
    }

    return;
}



/*************************************
*   server->client  ipfix export
****************************************/
void
chip_agent_ipfix_export(void* info, void* userdata)
{
    uint32 mode = 0;

    mode = drv_chip_agent_mode();
    if (DRV_CHIP_AGT_MODE_SERVER == mode)  /* CHIP_AGT_MODE_SERVER */
    {
        chip_agent_server_send_dma_info(CHIP_AGENT_DMA_INFO_TYPE_IPFIX,info);
    }

    return;
}



/*************************************
*   server->client   monitor export
****************************************/
void
chip_agent_monitor_export(void* info, void* userdata)
{
    uint32 mode = 0;

    mode = drv_chip_agent_mode();
    if (DRV_CHIP_AGT_MODE_SERVER == mode)  /* CHIP_AGT_MODE_SERVER */
    {
        chip_agent_server_send_dma_info(CHIP_AGENT_DMA_INFO_TYPE_MONITOR,info);
    }

    return;
}


/*************************************
*   client-> server  packet tx
****************************************/

static int32
_chip_agent_do_send_pkt(uint8 server_id, uint8* pkt, uint32 len, uint32 mode)
{
    chip_agent_msg_pkt_para_t para;
    uint8 tx_buf[CHIP_AGT_BUF_SIZE];
    uint8* req = tx_buf;
    uint8* data = req + CHIP_AGT_HDR_SIZE;
    uint32 req_len = 0;
    chip_agent_sock_session_t* p_session = NULL;

    p_session = _chip_agent_get_send_session(CHIP_AGT_MSG_PACKET, server_id);

    if (NULL == p_session)
    {
        return CHIP_AGT_E_GEN;
    }

    if (len > 2000)
    {
        return CHIP_AGT_E_MSG_LEN_EXCEED;
    }

    sal_memset(&para, 0, sizeof(para));
    para.pkt_len = len;
    para.pkt_mode = mode;
    para.pkt = pkt;

    DRV_IF_ERROR_RETURN(drv_agent_encode_pkt(data, &para, &req_len));
    DRV_IF_ERROR_RETURN(chip_agent_send(p_session, CHIP_AGT_MSG_PACKET, req, req_len));

    return CHIP_AGT_E_NONE;
}


int32
chip_agent_client_send_pkt(uint8 server_id, uint8* pkt, uint32 len, uint32 mode)
{
    return _chip_agent_do_send_pkt(server_id, pkt, len, mode);
}


int32
chip_agent_pkt_tx(void* p_pkt_tx)
{
    int32 ret = CTC_E_NONE;
    chip_agent_mode_t mode = CHIP_AGT_MODE_NONE;
    ctc_pkt_tx_t* p_tmp;
    uint8 server_id = 0;

    p_tmp = p_pkt_tx;

    /* eadp only support dma mode */
    if(CTC_PKT_MODE_ETH == p_tmp->mode)
    {
        CHIP_AGT_ERR("chip_agent_pkt_tx   error! [eadp only support dma mode!!!]\n");
        return CTC_E_INVALID_PARAM;
    }

    mode = chip_agent_get_mode();

    if (CHIP_AGT_MODE_CLIENT == mode) /* CHIP_AGT_MODE_CLIENT */
    {
        server_id = p_tmp->lchip;
        /* encode header */
        CHIP_AGT_ERR("chip_agent_pkt_tx   cpu-->board Client-->Server\n");

        ret = chip_agent_client_send_pkt(server_id, p_tmp->skb.data, p_tmp->skb.len, CTC_PKT_MODE_DMA);
        if (ret < 0)
        {
            CHIP_AGT_DBG_CODE(CHIP_AGT_STR "chip agent send failed!\n");
            return CTC_E_UNEXPECT;
        }
    }
    else if (CHIP_AGT_MODE_SERVER == mode) /* CHIP_AGT_MODE_SERVER */
    {
        /* call ctc DMA TX API */
        return ctc_packet_tx(p_pkt_tx); //dma mode
    }
    else
    {
        CHIP_AGT_DBG_CODE(CHIP_AGT_STR "chip_agent_pkt_tx error!\n");
    }

    return ret;
}



int32
chip_agent_client_io_callback(uint8 lchip, void* p)
{
    chip_io_para_t* para_io = (chip_io_para_t*)p;
    chip_agent_msg_io_para_t msg_io;
    chip_agent_sock_session_t* p_session = NULL;

    uint8 tx_buf[CHIP_AGT_BUF_SIZE];
    uint8 rx_buf[CHIP_AGT_BUF_SIZE];
    uint8* req = tx_buf;
    uint8* data = req + CHIP_AGT_HDR_SIZE;
    uint8* resp = rx_buf;
    uint32 req_len = 0;
    uint32 resp_len = 0;
    uint8 chip_id = 0;;

    chip_id = para_io->chip_id;

    p_session = _chip_agent_get_send_session(CHIP_AGT_MSG_IO, chip_id);

    if (NULL == p_session)
    {
        return CHIP_AGT_E_GEN;
    }

    sal_memset(&msg_io, 0, sizeof(msg_io));
    msg_io.hdr.op = para_io->op;
    msg_io.hdr.chip_id = chip_id;


    sal_memcpy(&(msg_io.para), para_io, sizeof(msg_io.para));

    DRV_IF_ERROR_RETURN(drv_agent_encode_io_ioctl(data, &msg_io, &req_len));

    DRV_IF_ERROR_RETURN(chip_agent_send_syn(p_session, CHIP_AGT_MSG_IO, req, req_len, resp, &resp_len));
    DRV_IF_ERROR_RETURN(drv_agent_decode_io_ioctl(resp, &msg_io, resp_len));

    return msg_io.hdr.ret;

}

extern int32
ctc_app_chip_agent_init(const char* file_name, chip_agent_t* p_agent);


int32
chip_agent_init_mode()
{
    int32 ret = CHIP_AGT_E_NONE;
    unix_sock_server_t sock_server;
    sal_msg_t msg;
    sal_memset(&sock_server,0,sizeof(unix_sock_server_t));
    sal_memset(&msg,0,sizeof(sal_msg_t));
    uint32 i;
    uint8 lchip = 0;

    switch (chip_agent_get_mode())
    {
    case CHIP_AGT_MODE_CLIENT:
        CHIP_AGT_LOG("Init as EADP Client\n");
        drv_register_chip_agent_cb(chip_agent_client_io_callback);
        for (lchip = 0; lchip < CTC_MAX_LOCAL_CHIP_NUM; lchip++)
        {
            DRV_AGENT_FUNC(DRV_AGENT_CB_SET_PKT_TX)(lchip, (void*)chip_agent_pkt_tx);
            drv_agent_init(lchip);
        }

        chip_agent_sock_client_global_init();
        for(i = 0; i < g_chip_agent.cfg.server_count; i++)
        {
            if (g_chip_agent.cfg.addr[i][0])
            {
                chip_agent_sock_client_init(g_chip_agent.cfg.addr[i], g_chip_agent.cfg.tcp_port, i);
            }
        }

        break;

    case CHIP_AGT_MODE_SERVER:
        CHIP_AGT_LOG("Init as EADP Server with %s situation\n",
                     g_chip_agent.cfg.standalone ? "standalone" : "dual");

        if (g_chip_agent.cfg.mirror_port)
        {
            CHIP_AGT_LOG("CPU Mirror Port is %d\n", g_chip_agent.cfg.mirror_port);
        }
        else
        {
            CHIP_AGT_LOG("CPU Mirror Port is not configured\n");
        }

        if (g_chip_agent.cfg.gw[0])
        {

#if defined(SDK_IN_USERMODE)
            ret = ctc_cli_set_gw(g_chip_agent.cfg.gw, TRUE);
            if (ret == 0)
            {
                CHIP_AGT_ERR("Set Default Gateway %s\n", g_chip_agent.cfg.gw);
            }
#endif /* SDK_IN_USERMODE */
        }

        chip_agent_sock_server_init(g_chip_agent.cfg.tcp_port);
        ctc_interrupt_register_event_cb(CTC_EVENT_L2_SW_LEARNING,  (void*)chip_agent_dma_sync_learning_func);
        ctc_interrupt_register_event_cb(CTC_EVENT_L2_SW_AGING,     (void*)chip_agent_dma_sync_aging_func);
        ctc_ipfix_register_cb((void*)chip_agent_ipfix_export, NULL);
        ctc_monitor_register_cb((void*)chip_agent_monitor_export, NULL);
        DRV_AGENT_FUNC(DRV_AGENT_CB_SET_OAM_DEFECT)(lchip, (void*)chip_agent_oam_process_isr);
        DRV_AGENT_FUNC(DRV_AGENT_CB_SET_PKT_RX)(lchip, (void*)agent_agent_pkt_rx);

        extern app_pkt_sample_master_t *g_app_pkt_sample_master;
        g_app_pkt_sample_master->rx_cb = (void *)agent_agent_pkt_rx;

        break;

    default:
        break;
    }

    return CHIP_AGT_E_NONE;
}


int32
ctc_chip_agent_init()
{
    int32 ret  = 0;
    chip_agent_t chip_agent;

    sal_memset(&chip_agent, 0, sizeof(chip_agent_t));

    /* should get Chip Agent Mode at first */
    ret = ctc_app_chip_agent_init(CTC_CHIP_AGENT_CONFIG, &chip_agent);
    if (ret != 0)
    {
        CHIP_AGT_LOG("chip_agent_init_mode failed:%s@%d \n",  __FUNCTION__, __LINE__);
        return ret;
    }

    sal_memcpy(&g_chip_agent, &chip_agent, sizeof(chip_agent_t));
    CHIP_AGT_LOG("chip_agent_init_mode Mode:%d \n", g_chip_agent.mode);

    return DRV_E_NONE;
}

#endif




#ifndef _CTC_SAI_NEXTHOP_GROUP_CLI_H_
#define _CTC_SAI_NEXTHOP_GROUP_CLI_H_


#ifdef __cplusplus
extern C {
#endif


#include <sal.h>

extern int32 ctc_sai_nexthop_group_cli_init(uint8 cli_tree_mode);

#ifdef __cplusplus
}
#endif

#endif

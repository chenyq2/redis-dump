#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include "ctc_linklist.h"
#include "ctc_hash.h"
#include "ctc_opf.h"
#include <sys/socket.h>
#include "ctc_sai_hostif.h"
#include <ctc_sai_common.h>

extern ctc_sai_hostif_info_t g_hostif_info;

int32 ctc_sai_host_if_display_fdb(void* bucket_data, void* user_data)
{
    ctc_sai_arp_fdb_t *pt_fdb = NULL;

    pt_fdb = bucket_data;

    ctc_cli_out("%.2x:%.2x:%.2x:%.2x:%.2x:%.2x %-8d %-8d %-8d\n",
        pt_fdb->mac_address[0], pt_fdb->mac_address[1], pt_fdb->mac_address[2], 
        pt_fdb->mac_address[3], pt_fdb->mac_address[4], pt_fdb->mac_address[5],
        pt_fdb->vlanid, pt_fdb->port, pt_fdb->live_time);
    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_host_if_display_fdb,
        cli_sai_host_if_display_fdb_cmd,
        "show sai hostif fdb",
        "show host interface",
        "sai",
        "hostif",
        "fdb")
{
    ctc_cli_out("%-17s %-8s %-8s %-8s\n",
        "mac address", "vlan", "port", "livetime");
    ctc_hash_traverse(g_hostif_info.hostif_arp_fdb_hash, ctc_sai_host_if_display_fdb, NULL);
    return CLI_SUCCESS;
}

int32 ctc_sai_host_if_display(void* bucket_data, void* user_data)
{
    ctc_sai_hostif_t *hif = NULL;

    hif = bucket_data;

    ctc_cli_out("%-20s %-10x %-10x %-10d %-5d %-10x\n",
       hif->ifname, hif->hostif_id, hif->port, hif->vlanid, hif->fd, hif->nexthop_ptr);
    return CLI_SUCCESS;
}

CTC_CLI(cli_show_sai_host_if_display,
        cli_show_sai_host_if_display_cmd,
        "show sai hostif",
        "host interface",
        "get",
        "fdb")
{
    ctc_cli_out("Max count: %d\n", g_hostif_info.max_count);
    ctc_cli_out("     Name: %s\n", g_hostif_info.name);
    ctc_cli_out("%-20s %-10s %-10s %-10s %-5s %-10s\n",
        "mame", "hostif-id", "port", "vlanid", "fd", "nexthop_ptr");
    ctc_hash_traverse(g_hostif_info.hostif_hash, ctc_sai_host_if_display, NULL);
    return CLI_SUCCESS;
}

int32
ctc_sai_hostif_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_host_if_display_fdb_cmd);
    install_element(cli_tree_mode, &cli_show_sai_host_if_display_cmd);
    return CLI_SUCCESS;
}


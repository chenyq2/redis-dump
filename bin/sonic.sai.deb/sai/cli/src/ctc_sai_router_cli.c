#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include <ctc_sai_common.h>

CTC_CLI(cli_sai_router_create,
        cli_sai_router_create_cmd,
        "router create",
        "Router",
        "Create virtual router")
{
    sai_virtual_router_api_t*  vr_api = NULL;
    sai_object_id_t            vr_id  = 0;
    sai_status_t               ret    = SAI_STATUS_SUCCESS;

    ret = sai_api_query(SAI_API_VIRTUAL_ROUTER,(void**)&vr_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vr_api->create_virtual_router(&vr_id,0,NULL);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%llx\n","router-id",CTC_SAI_OBJECT_INDEX_GET(vr_id));

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_remove,
        cli_sai_router_remove_cmd,
        "router remove (router-id SAI_OBJ_ID)",
        "Router",
        "Remove virtual router",
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE)
{
    sai_virtual_router_api_t*  vr_api  = NULL;
    sai_object_id_t            vr_id   = 0;
    sai_status_t               ret     = SAI_STATUS_SUCCESS;

    SAI_CLI_GET_ROUTER_ID(vr_id);

    ret = sai_api_query(SAI_API_VIRTUAL_ROUTER,(void**)&vr_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vr_api->remove_virtual_router(vr_id);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_set_router_attr_admin_ipv4_state,
        cli_sai_router_set_router_attr_admin_ipv4_state_cmd,
        "router set-attribute (router-id SAI_OBJ_ID) admin-v4-state (true | false)",
        "Router",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Admin V4 state (default to TRUE)",
        "true",
        "false")
{
    sai_virtual_router_api_t*  vr_api = NULL;
    sai_object_id_t            vr_id  = 0;
    sai_status_t               ret    = SAI_STATUS_SUCCESS;
    sai_attribute_t            attr;

    SAI_CLI_GET_ROUTER_ID(vr_id);

    attr.id = SAI_VIRTUAL_ROUTER_ATTR_ADMIN_V4_STATE;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("true"))
    {
        attr.value.booldata = true;
    }
    else
    {
        attr.value.booldata = false;
    }

    ret = sai_api_query(SAI_API_VIRTUAL_ROUTER,(void**)&vr_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vr_api->set_virtual_router_attribute(vr_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_get_router_attr_admin_ipv4_state,
        cli_sai_router_get_router_attr_admin_ipv4_state_cmd,
        "router get-attribute (router-id SAI_OBJ_ID) admin-v4-state",
        "Router",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Admin V4 state (default to TRUE)")
{
    sai_virtual_router_api_t*  vr_api = NULL;
    sai_object_id_t            vr_id  = 0;
    sai_status_t               ret    = SAI_STATUS_SUCCESS;
    sai_attribute_t            attr;

    sal_memset(&attr,0,sizeof(sai_attribute_t));

    SAI_CLI_GET_ROUTER_ID(vr_id);

    attr.id = SAI_VIRTUAL_ROUTER_ATTR_ADMIN_V4_STATE;

    ret = sai_api_query(SAI_API_VIRTUAL_ROUTER,(void**)&vr_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vr_api->get_virtual_router_attribute(vr_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","Admin V4 state",attr.value.booldata ? "TRUE" : "FALSE");

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_set_router_attr_admin_ipv6_state,
        cli_sai_router_set_router_attr_admin_ipv6_state_cmd,
        "router set-attribute (router-id SAI_OBJ_ID) admin-v6-state (true | false)",
        "Router",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Admin V6 state (default to TRUE)",
        "true",
        "false")
{
    sai_virtual_router_api_t*   vr_api   = NULL;
    sai_object_id_t             vr_id    = 0;
    sai_status_t                ret      = SAI_STATUS_SUCCESS;
    sai_attribute_t             attr;

    SAI_CLI_GET_ROUTER_ID(vr_id);

    attr.id = SAI_VIRTUAL_ROUTER_ATTR_ADMIN_V6_STATE;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("true"))
    {
        attr.value.booldata = true;
    }
    else
    {
        attr.value.booldata = false;
    }

    ret = sai_api_query(SAI_API_VIRTUAL_ROUTER,(void**)&vr_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vr_api->set_virtual_router_attribute(vr_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_get_router_attr_admin_ipv6_state,
        cli_sai_router_get_router_attr_admin_ipv6_state_cmd,
        "router get-attribute (router-id SAI_OBJ_ID) admin-v6-state",
        "Router",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Admin V6 state (default to TRUE)")
{
    sai_virtual_router_api_t*   vr_api = NULL;
    sai_object_id_t             vr_id  = 0;
    sai_status_t                ret    = SAI_STATUS_SUCCESS;
    sai_attribute_t             attr;

    sal_memset(&attr,0,sizeof(sai_attribute_t));

    SAI_CLI_GET_ROUTER_ID(vr_id);

    attr.id = SAI_VIRTUAL_ROUTER_ATTR_ADMIN_V6_STATE;

    ret = sai_api_query(SAI_API_VIRTUAL_ROUTER,(void**)&vr_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vr_api->get_virtual_router_attribute(vr_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","Admin V6 state",attr.value.booldata ? "TRUE" : "FALSE");

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_set_router_attr_mac_state,
        cli_sai_router_set_router_attr_mac_state_cmd,
        "router set-attribute (router-id SAI_OBJ_ID) src-mac-address (mac MAC)",
        "Router",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "MAC Address (equal to the SAI_SWITCH_ATTR_ATTR_SRC_MAC_ADDRESS by default)",
        "true",
        "false")
{
    sai_virtual_router_api_t*  vr_api = NULL;
    sai_object_id_t            vr_id  = 0;
    sai_status_t               ret    = SAI_STATUS_SUCCESS;
    sai_attribute_t            attr;

    SAI_CLI_GET_ROUTER_ID(vr_id);

    SAI_CLI_GET_MAC_ADDRESS(&attr.value.mac);

    attr.id = SAI_VIRTUAL_ROUTER_ATTR_SRC_MAC_ADDRESS;

    ret = sai_api_query(SAI_API_VIRTUAL_ROUTER,(void**)&vr_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vr_api->set_virtual_router_attribute(vr_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_get_router_attr_mac_state,
        cli_sai_router_get_router_attr_mac_state_cmd,
        "router get-attribute (router-id SAI_OBJ_ID) src-mac-address",
        "Router",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "MAC Address (equal to the SAI_SWITCH_ATTR_ATTR_SRC_MAC_ADDRESS by default)")
{
    sai_virtual_router_api_t*   vr_api  = NULL;
    sai_object_id_t             vr_id   = 0;
    sai_status_t                ret     = SAI_STATUS_SUCCESS;
    sai_attribute_t             attr;

    sal_memset(&attr,0,sizeof(sai_attribute_t));

    SAI_CLI_GET_ROUTER_ID(vr_id);

    attr.id = SAI_VIRTUAL_ROUTER_ATTR_SRC_MAC_ADDRESS;

    ret = sai_api_query(SAI_API_VIRTUAL_ROUTER,(void**)&vr_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vr_api->get_virtual_router_attribute(vr_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%02x:%02x:%02x:%02x:%02x:%02x\n",
        "src-mac-address",
        attr.value.mac[0],
        attr.value.mac[1],
        attr.value.mac[2],
        attr.value.mac[3],
        attr.value.mac[4],
        attr.value.mac[5]);

    return CLI_SUCCESS;
}


CTC_CLI(cli_sai_router_set_router_attr_violation_ttl1_action,
        cli_sai_router_set_router_attr_violation_ttl1_action_cmd,
        "router set-attribute (router-id SAI_OBJ_ID) violation-ttl1-action (drop | forward | trap | log)",
        "Router",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Action for Packets with TTL 0 or 1 (default to SAI_PACKET_ACTION_TRAP)",
        "Drop Packet",
        "Forward Packet",
        "Trap Packet to CPU",
        "Log (Trap + Forward) Packet")
{
    sai_virtual_router_api_t*   vr_api  = NULL;
    sai_object_id_t             vr_id   = 0;
    sai_status_t                ret     = SAI_STATUS_SUCCESS;
    sai_attribute_t             attr;

    SAI_CLI_GET_ROUTER_ID(vr_id);

    attr.id = SAI_VIRTUAL_ROUTER_ATTR_VIOLATION_TTL1_ACTION;

    if(CTC_CLI_GET_ARGC_INDEX("drop") != 0xFF)
    {
        attr.value.s32 = SAI_PACKET_ACTION_DROP;
    }else if(CTC_CLI_GET_ARGC_INDEX("forward") != 0xFF){
        attr.value.s32 = SAI_PACKET_ACTION_FORWARD;
    }else if(CTC_CLI_GET_ARGC_INDEX("trap") != 0xFF){
        attr.value.s32 = SAI_PACKET_ACTION_TRAP;
    }else if(CTC_CLI_GET_ARGC_INDEX("log") != 0xFF){
        attr.value.s32 = SAI_PACKET_ACTION_LOG;
    }

    ret = sai_api_query(SAI_API_VIRTUAL_ROUTER,(void**)&vr_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vr_api->set_virtual_router_attribute(vr_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_get_router_attr_violation_ttl1_action,
        cli_sai_router_get_router_attr_violation_ttl1_action_cmd,
        "router get-attribute (router-id SAI_OBJ_ID) violation-ttl1-action",
        "Router",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Action for Packets with TTL 0 or 1 (default to SAI_PACKET_ACTION_TRAP)")
{
    sai_virtual_router_api_t*   vr_api  = NULL;
    sai_object_id_t             vr_id   = 0;
    sai_status_t                ret     = SAI_STATUS_SUCCESS;
    sai_attribute_t             attr;
    const char*                 sz_action[] = {"Drop","Forward","Trap","Log"};

    SAI_CLI_GET_ROUTER_ID(vr_id);

    attr.id = SAI_VIRTUAL_ROUTER_ATTR_VIOLATION_TTL1_ACTION;

    ret = sai_api_query(SAI_API_VIRTUAL_ROUTER,(void**)&vr_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vr_api->get_virtual_router_attribute(vr_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","violation-ttl1-action",sz_action[attr.value.s32 % 4]);

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_set_router_attr_violation_ip_options_action,
        cli_sai_router_set_router_attr_violation_ip_options_action_cmd,
        "router set-attribute (router-id SAI_OBJ_ID) violation-ip-options (drop | forward | trap | log)",
        "Router",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Action for Packets with IP options (default to SAI_PACKET_ACTION_TRAP)",
        "Drop Packet",
        "Forward Packet",
        "Trap Packet to CPU",
        "Log (Trap + Forward) Packet")
{
    sai_virtual_router_api_t*   vr_api  = NULL;
    sai_object_id_t             vr_id   = 0;
    sai_status_t                ret     = SAI_STATUS_SUCCESS;
    sai_attribute_t             attr;

    SAI_CLI_GET_ROUTER_ID(vr_id);

    attr.id = SAI_VIRTUAL_ROUTER_ATTR_VIOLATION_IP_OPTIONS;

    if(CTC_CLI_GET_ARGC_INDEX("drop") != 0xFF)
    {
        attr.value.s32 = SAI_PACKET_ACTION_DROP;
    }else if(CTC_CLI_GET_ARGC_INDEX("forward") != 0xFF){
        attr.value.s32 = SAI_PACKET_ACTION_FORWARD;
    }else if(CTC_CLI_GET_ARGC_INDEX("trap") != 0xFF){
        attr.value.s32 = SAI_PACKET_ACTION_TRAP;
    }else if(CTC_CLI_GET_ARGC_INDEX("log") != 0xFF){
        attr.value.s32 = SAI_PACKET_ACTION_LOG;
    }

    ret = sai_api_query(SAI_API_VIRTUAL_ROUTER,(void**)&vr_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vr_api->set_virtual_router_attribute(vr_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_get_router_attr_violation_ip_options_action,
        cli_sai_router_get_router_attr_violation_ip_options_action_cmd,
        "router get-attribute (router-id SAI_OBJ_ID) violation-ip-options",
        "Router",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Action for Packets with IP options (default to SAI_PACKET_ACTION_TRAP)")
{
    sai_virtual_router_api_t*   vr_api  = NULL;
    sai_object_id_t             vr_id   = 0;
    sai_status_t                ret     = SAI_STATUS_SUCCESS;
    sai_attribute_t             attr;
    const char*                 sz_action[] = {"Drop","Forward","Trap","Log"};

    SAI_CLI_GET_ROUTER_ID(vr_id);

    attr.id = SAI_VIRTUAL_ROUTER_ATTR_VIOLATION_IP_OPTIONS;

    ret = sai_api_query(SAI_API_VIRTUAL_ROUTER,(void**)&vr_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vr_api->get_virtual_router_attribute(vr_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","violation-ttl1-action",sz_action[attr.value.s32 % 4]);

    return CLI_SUCCESS;
}


int32
ctc_sai_router_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_router_create_cmd);
    install_element(cli_tree_mode, &cli_sai_router_remove_cmd);
    install_element(cli_tree_mode, &cli_sai_router_set_router_attr_admin_ipv4_state_cmd);
    install_element(cli_tree_mode, &cli_sai_router_set_router_attr_admin_ipv6_state_cmd);
    install_element(cli_tree_mode, &cli_sai_router_set_router_attr_mac_state_cmd);
    install_element(cli_tree_mode, &cli_sai_router_set_router_attr_violation_ttl1_action_cmd);
    install_element(cli_tree_mode, &cli_sai_router_set_router_attr_violation_ip_options_action_cmd);
    install_element(cli_tree_mode, &cli_sai_router_get_router_attr_admin_ipv4_state_cmd);
    install_element(cli_tree_mode, &cli_sai_router_get_router_attr_admin_ipv6_state_cmd);
    install_element(cli_tree_mode, &cli_sai_router_get_router_attr_mac_state_cmd);
    install_element(cli_tree_mode, &cli_sai_router_get_router_attr_violation_ttl1_action_cmd);
    install_element(cli_tree_mode, &cli_sai_router_get_router_attr_violation_ip_options_action_cmd);

    return CLI_SUCCESS;
}

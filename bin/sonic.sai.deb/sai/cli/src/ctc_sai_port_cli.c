#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include <ctc_sai_common.h>
#include <ctc_port.h>
#include <ctc_sai_port.h>
#include <ctc_sai_policer.h>

#ifdef GOLDENGATE
#include <sys_goldengate_datapath.h>
#include <sys_goldengate_chip.h>
#endif

#define CTC_SAI_PORT_SPEED_10M      10
#define CTC_SAI_PORT_SPEED_100M     100
#define CTC_SAI_PORT_SPEED_1000M    1000
#define CTC_SAI_PORT_SPEED_2G5      2500
#define CTC_SAI_PORT_SPEED_10G      10000
#define CTC_SAI_PORT_SPEED_40G      40000
#define CTC_SAI_PORT_SPEED_100G     100000

extern ctc_sai_port_info_t     g_sai_port_info;

CTC_CLI(cli_sai_port_get_port_attr_type,
        cli_sai_port_get_port_attr_type_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) type",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Port Type")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;
    const char          *port_type[] = {"Actual port","CPU Port","Link-Aggregation Port"};

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_TYPE;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","type",port_type[attr.value.s32]);


    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_operational_status,
        cli_sai_port_get_port_attr_operational_status_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) oper-status",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Operational Status")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;
    const char          *opera_status[] = {"Unknown","Up","Down","Test Running","Not Present"};

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_OPER_STATUS;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","oper-status",opera_status[attr.value.s32]);


    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_hw_line_list,
        cli_sai_port_get_port_attr_hw_line_list_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) hw-lane-list",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Hardware Lane list")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_HW_LANE_LIST;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_supported_breakout_mode,
        cli_sai_port_get_port_attr_supported_breakout_mode_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) supported-breakout-mode",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Breakout mode(s) supported")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_SUPPORTED_BREAKOUT_MODE;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_current_breakout_mode,
        cli_sai_port_get_port_attr_current_breakout_mode_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) current-breakout-mode",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Current breakout mode")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_CURRENT_BREAKOUT_MODE;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_speed,
        cli_sai_port_get_port_attr_speed_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) speed",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Speed in Mbps")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_SPEED;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10d\n","speed",attr.value.u32);

    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_admin_state,
        cli_sai_port_get_port_attr_admin_state_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) admin-state",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Admin Mode , (default to FALSE)")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_ADMIN_STATE;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","admin-state",attr.value.booldata ? "TRUE" : "FALSE");

    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_media_type,
        cli_sai_port_get_port_attr_media_type_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) media-type",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Media Type , (default to SAI_PORT_MEDIA_TYPE_NOT_PRESENT)")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_MEDIA_TYPE;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_default_vlan,
        cli_sai_port_get_port_attr_default_vlan_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) default-vlan",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Default VLAN")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_PORT_VLAN_ID;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10d\n","default-vlan",attr.value.u16);

    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_default_vlan_priority,
        cli_sai_port_get_port_attr_default_vlan_priority_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) default-vlan-priority",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Default VLAN Priority (default to 0)")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_DEFAULT_VLAN_PRIORITY;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10d\n","default-vlan-priority",attr.value.u8);

    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_ingress_filtering,
        cli_sai_port_get_port_attr_ingress_filtering_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) ingress-filtering",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Ingress Filtering (default to FALSE)")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_INGRESS_FILTERING;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","ingress-filtering",attr.value.booldata ? "TRUE" : "FALSE");

    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_drop_untagged,
        cli_sai_port_get_port_attr_drop_untagged_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) drop-untagged",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Dropping of untagged frames on ingress (default to FALSE)")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_DROP_UNTAGGED;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","drop-untagged",attr.value.booldata ? "TRUE" : "FALSE");

    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_drop_tagged,
        cli_sai_port_get_port_attr_drop_tagged_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) drop-tagged",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Dropping of tagged frames on ingress (default to FALSE)")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_DROP_TAGGED;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","drop-tagged",attr.value.booldata ? "TRUE" : "FALSE");

    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_internal_loopback,
        cli_sai_port_get_port_attr_internal_loopback_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) internal-loopback",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Internal loopback control (default to SAI_PORT_INTERNAL_LOOPBACK_NONE)")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_INTERNAL_LOOPBACK;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_fdb_learning,
        cli_sai_port_get_port_attr_fdb_learning_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) fdb-learning",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "FDB Learning mode (default to SAI_PORT_LEARN_MODE_HW)")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;
    const char          *learn_type[] = {"drop","disable","hw","cpu"};

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_FDB_LEARNING;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","fdb-learning",learn_type[attr.value.s32]);

    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_update_dscp,
        cli_sai_port_get_port_attr_update_dscp_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) update-dscp",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Update DSCP of outgoing packets (default to FALSE)")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_UPDATE_DSCP;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","update-dscp",attr.value.booldata ? "TRUE" : "FALSE");

    return ret;
}

CTC_CLI(cli_sai_port_get_port_attr_mtu,
        cli_sai_port_get_port_attr_mtu_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) mtu",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "MTU (default to 1514 bytes)")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_MTU;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10d\n","mtu",attr.value.u32);

    return ret;
}

CTC_CLI(cli_sai_port_get_port_storm_control,
        cli_sai_port_get_port_storm_control_cmd,
        "port PORT_ID attribute get (flood|broadcast|multicast) storm_control",
        "port","port id",
        "attribute",
        "get",
        "flood",
        "broadcast",
        "multicast",
        "storm_control")
{

    sai_status_t        ret = SAI_STATUS_SUCCESS; 
    sai_port_api_t*     port_api = NULL;
    sai_object_id_t     port_oid = 0;
    sai_attribute_t     attr;
    uint32              port_id = 0;
    uint32              type = 0;
    
    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    CTC_CLI_GET_UINT16_RANGE("src-port", port_id, argv[0], 0, CTC_MAX_UINT16_VALUE);
    port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,port_id);

    if (0 == sal_strcmp(argv[1], "flood"))
    {
        type = SAI_PORT_ATTR_FLOOD_STORM_CONTROL_POLICER_ID;
    }
    else if (0 == sal_strcmp(argv[1], "broadcast"))
    {
        type = SAI_PORT_ATTR_BROADCAST_STORM_CONTROL_POLICER_ID;
    }
    else if (0 == sal_strcmp(argv[1], "multicast"))
    {
        type = SAI_PORT_ATTR_MULTICAST_STORM_CONTROL_POLICER_ID;
    }
    attr.id = type;
    
    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = port_api->get_port_attribute(port_oid,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    
    switch (attr.id)
    {
    case SAI_PORT_ATTR_FLOOD_STORM_CONTROL_POLICER_ID:
        ctc_cli_out("%-10s:%-10s\n","flood storm control", attr.value.booldata ?"TRUE":"FALSE");  
        break;
    case SAI_PORT_ATTR_BROADCAST_STORM_CONTROL_POLICER_ID:
        ctc_cli_out("%-10s:%-10s\n","broadcast storm control", attr.value.booldata ?"TRUE":"FALSE");  
        break;
    case SAI_PORT_ATTR_MULTICAST_STORM_CONTROL_POLICER_ID:
        ctc_cli_out("%-10s:%-10s\n","multicast storm control", attr.value.booldata ?"TRUE":"FALSE"); 
        break;
    }
    return ret;
}

CTC_CLI(cli_sai_port_get_global_flow_control,
        cli_sai_port_get_port_global_flow_control_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) flow-control",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "flow-control (default to SAI_PORT_FLOW_CONTROL_DISABLE)")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_GLOBAL_FLOW_CONTROL;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    if (SAI_PORT_FLOW_CONTROL_TX_ONLY == attr.value.s32)
    {   
        ctc_cli_out("%-10s:%-10s %-10s %-10s\n", "Global flow Control","TRUE", "Direction:","TX");  
    }
    else if (SAI_PORT_FLOW_CONTROL_RX_ONLY == attr.value.s32)
    {
        ctc_cli_out("%-10s:%-10s %-10s %-10s\n", "Global flow Control","TRUE", "Direction:", "RX");
    }
    else if (SAI_PORT_FLOW_CONTROL_BOTH_ENABLE == attr.value.s32)
    {
        ctc_cli_out("%-10s:%-10s %-10s %-10s\n", "Global flow Control","TRUE", "Direction:", "BOTH");  
    }
    else
    {
        ctc_cli_out("%-10s:%-10s \n", "Global flow Control:","FALSE"); 
    }

    return ret;
}

CTC_CLI(cli_sai_port_get_max_learned_address,
        cli_sai_port_get_port_max_learned_address_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) max-learned-address",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Maximum number of learned MAC addresses")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_MAX_LEARNED_ADDRESSES;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10d\n","max-learned-address",attr.value.u32);

    return ret;
}

CTC_CLI(cli_sai_port_get_fdb_learning_limit_violation,
        cli_sai_port_get_port_fdb_learning_limit_violation_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) fdb-learning-limit-violation",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Action for packets with unknown source mac address when FDB learning limit is reached. (default to SAI_PACKET_ACTION_DROP)")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;
    const char          *action[] = {"drop","forward","trap","log"};

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_FDB_LEARNING_LIMIT_VIOLATION;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","fdb-learning-limit-violation",action[attr.value.s32]);

    return ret;
}
 

CTC_CLI(cli_sai_port_get_mirror_session,
        cli_sai_port_get_port_mirror_session_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) mirror direction (ingress|egress)",
        "port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "mirror",
        "direction",
        "ingress",
        "egress")
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_port_api_t* port_api;
    uint32_t        port_id = 0;
    sai_object_id_t port_oid = 0;
    sai_attribute_t attr;
    sai_object_id_t sai_session_oid[1];
    uint32          session_id = 0;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));
    
    CTC_CLI_GET_UINT16_RANGE("src-port", port_id, argv[0], 0, CTC_MAX_UINT16_VALUE);
    port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,port_id);

    if (0 == sal_strcmp(argv[1], "ingress"))
    {
         attr.id= SAI_PORT_ATTR_INGRESS_MIRROR_SESSION;
    }
    else if (0 == sal_strcmp(argv[1], "egress"))
    {
         attr.id = SAI_PORT_ATTR_EGRESS_MIRROR_SESSION;
    } 
    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    attr.value.objlist.count = 1;
    attr.value.objlist.list = sai_session_oid;
    ret = port_api->get_port_attribute(port_oid,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    
    switch(attr.id)
    {
    case SAI_PORT_ATTR_INGRESS_MIRROR_SESSION:
        if (0 != attr.value.objlist.count)
        {   
            session_id = CTC_SAI_OBJECT_INDEX_GET(attr.value.objlist.list[0]);
            ctc_cli_out("%-10s:%-10s %-10s %-10u\n", "Ingress ","enable",  "session id: ", session_id);
            break;
        }
        else
        {
            ctc_cli_out("%-10s \n", "Ingress is disable");
            break;
        }
    case SAI_PORT_ATTR_EGRESS_MIRROR_SESSION:
        if (0 != attr.value.objlist.count)
        {   
            session_id = CTC_SAI_OBJECT_INDEX_GET(attr.value.objlist.list[0]);
            ctc_cli_out("%-10s:%-10s %-10s %-10u\n", "Egress ","enable",  "session id: ", session_id);
            break;
        }
        else
        {
             ctc_cli_out("%-10s\n", "Egress is disable");
             break;
        }
    default:
        break;
    }
    return CLI_SUCCESS;

}

CTC_CLI(cli_sai_port_get_ingress_samplepacket_enable,
        cli_sai_port_get_ingress_samplepacket_enable_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) ingress-samplepacket-enable",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Enable/Disable Samplepacket session")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_INGRESS_SAMPLEPACKET_ENABLE;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_port_get_egress_samplepacket_enable,
        cli_sai_port_get_egress_samplepacket_enable_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) egress-samplepacket-enable",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Enable/Disable Samplepacket session")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_EGRESS_SAMPLEPACKET_ENABLE;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}


#define AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

CTC_CLI(cli_sai_port_set_port_attr_speed,
        cli_sai_port_set_port_attr_speed_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) speed (10M|100M|1000M|2G5|10G|40G|100G)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Speed in Mbps",
        "10M",
        "100M",
        "1000M",
        "2G5",
        "10G",
        "40G",
        "100G")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_SPEED;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("10M"))
    {
        attr.value.u32 = CTC_SAI_PORT_SPEED_10M;
    }
    else if(0xFF != CTC_CLI_GET_ARGC_INDEX("100M"))
    {
        attr.value.u32 = CTC_SAI_PORT_SPEED_100M;
    }
    else if(0xFF != CTC_CLI_GET_ARGC_INDEX("1000M"))
    {
        attr.value.u32 = CTC_SAI_PORT_SPEED_1000M;
    }
    else if(0xFF != CTC_CLI_GET_ARGC_INDEX("2G5"))
    {
        attr.value.u32 = CTC_SAI_PORT_SPEED_2G5;
    }
    else if(0xFF != CTC_CLI_GET_ARGC_INDEX("10G"))
    {
        attr.value.u32 = CTC_SAI_PORT_SPEED_10G;
    }
    else if(0xFF != CTC_CLI_GET_ARGC_INDEX("40G"))
    {
        attr.value.u32 = CTC_SAI_PORT_SPEED_40G;
    }
    else
    {
        attr.value.u32 = CTC_SAI_PORT_SPEED_100G;
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:%-10d\n","Speed",attr.value.u32);

    return ret;
}

CTC_CLI(cli_sai_port_set_port_attr_admin_state,
        cli_sai_port_set_port_attr_admin_state_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) admin-state (true | false)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Admin Mode [bool], (default to FALSE)",
        "TRUE",
        "FALSE")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_ADMIN_STATE;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("true"))
    {
        attr.value.booldata = true;
    }
    else
    {
        attr.value.booldata = false;
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:%-10d\n","Admin State",attr.value.booldata ? "TRUE" : "FALSE");

    return ret;
}

CTC_CLI(cli_sai_port_set_port_attr_media_type,
        cli_sai_port_set_port_attr_media_type_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) media-type (not-present|unknow|qsfp-fiber|qsfp-copper|sfp-fiber|sfp-copper)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Media Type , (default to SAI_PORT_MEDIA_TYPE_NOT_PRESENT)",
        "Media not present",
        "Media type not known",
        "Media type QSFP fiber optic",
        "Media type QSFP copper optic",
        "Media type SFP fiber optic",
        "Media type SFP copper optic")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_MEDIA_TYPE;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("not-present"))
    {
        attr.value.s32 = SAI_PORT_MEDIA_TYPE_NOT_PRESENT;
    }

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("unknow"))
    {
        attr.value.s32 = SAI_PORT_MEDIA_TYPE_UNKNONWN;
    }

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("qsfp-fiber"))
    {
        attr.value.s32 = SAI_PORT_MEDIA_TYPE_QSFP_FIBER;
    }

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("qsfp-copper"))
    {
        attr.value.s32 = SAI_PORT_MEDIA_TYPE_QSFP_COPPER;
    }

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("sfp-fiber"))
    {
        attr.value.s32 = SAI_PORT_MEDIA_TYPE_SFP_FIBER;
    }

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("sfp-copper"))
    {
        attr.value.s32 = SAI_PORT_MEDIA_TYPE_SFP_COPPER;
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_port_set_port_attr_default_vlan,
        cli_sai_port_set_port_attr_default_vlan_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) default-vlan (vlan VLAN)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Default VLAN",
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC)
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_PORT_VLAN_ID;

    SAI_CLI_GET_VLAN(attr.value.u16);

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:%-10d\n","Default Vlan",attr.value.u16);

    return ret;
}

CTC_CLI(cli_sai_port_set_port_attr_default_vlan_priority,
        cli_sai_port_set_port_attr_default_vlan_priority_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) (default-vlan-priority VALUE)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Default VLAN Priority (default to 0)")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;
    uint8_t             priority_value = 0;
    uint32_t            index;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_DEFAULT_VLAN_PRIORITY;

    index = CTC_CLI_GET_ARGC_INDEX("default-vlan-priority");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT8_RANGE("priority-value", priority_value, argv[index + 1], 0, CTC_MAX_UINT8_VALUE);
        attr.value.u8 = priority_value;
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:%-10d\n","Default Vlan Priority",attr.value.u8);

    return ret;
}

CTC_CLI(cli_sai_port_set_port_attr_ingress_filtering,
        cli_sai_port_set_port_attr_ingress_filtering_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) ingress-filtering (true | false)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Ingress Filtering (default to FALSE)",
        "TRUE",
        "FALSE")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_INGRESS_FILTERING;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("true"))
    {
        attr.value.booldata = true;
    }
    else
    {
        attr.value.booldata = false;
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:%-10d\n","Ingress Filtering",attr.value.booldata ? "TRUE" : "FALSE");

    return ret;
}

CTC_CLI(cli_sai_port_set_port_attr_drop_untagged,
        cli_sai_port_set_port_attr_drop_untagged_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) drop-untagged (true | false)",
        "port","port id",
        "attribute",
        "set",
        "drop",
        "untagged",
        "true",
        "false")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_DROP_UNTAGGED;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("true"))
    {
        attr.value.booldata = true;
    }
    else
    {
        attr.value.booldata = false;
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:%-10d\n","Drop Untagged",attr.value.booldata ? "TRUE" : "FALSE");

    return ret;
}

CTC_CLI(cli_sai_port_set_port_attr_drop_tagged,
        cli_sai_port_set_port_attr_drop_tagged_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) drop-tagged (true | false)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Dropping of tagged frames on ingress (default to FALSE)",
        "TRUE",
        "FALSE")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_DROP_TAGGED;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("true"))
    {
        attr.value.booldata = true;
    }
    else
    {
        attr.value.booldata = false;
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_port_set_port_attr_internal_loopback,
        cli_sai_port_set_port_attr_internal_loopback_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) internal-loopback (none | phy | mac)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Internal loopback control (default to SAI_PORT_INTERNAL_LOOPBACK_NONE)",
        "disable internal loopback",
        "port internal loopback at phy module",
        "port internal loopback at mac module")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_INTERNAL_LOOPBACK;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("none"))
    {
        attr.value.s32 = SAI_PORT_INTERNAL_LOOPBACK_NONE;
    }
    else if(0xFF != CTC_CLI_GET_ARGC_INDEX("phy"))
    {
        attr.value.s32 = SAI_PORT_INTERNAL_LOOPBACK_PHY;
    }
    else
    {
        attr.value.s32 = SAI_PORT_INTERNAL_LOOPBACK_MAC;
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_port_set_port_attr_fdb_learning,
        cli_sai_port_set_port_attr_fdb_learning_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) fdb-learning (drop | disable | hw | cpu)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "FDB Learning mode (default to SAI_PORT_LEARN_MODE_HW)",
        "Drop packets with unknown source MAC.",
        "Do not learn unknown source MAC.",
        "Hardware learning. Learn source MAC.",
        "Trap packets with unknown source MAC to CPU.")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;
    const char          *learn_type[] = {"drop","disable","hw","cpu"};

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_FDB_LEARNING;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("drop"))
    {
        attr.value.s32 = SAI_PORT_LEARN_MODE_DROP;
    }
    else if(0xFF != CTC_CLI_GET_ARGC_INDEX("disable"))
    {
        attr.value.s32 = SAI_PORT_LEARN_MODE_DISABLE;
    }
    else if(0xFF != CTC_CLI_GET_ARGC_INDEX("hw"))
    {
        attr.value.s32 = SAI_PORT_LEARN_MODE_HW;
    }
    else
    {
        attr.value.s32 = SAI_PORT_LEARN_MODE_CPU_LOG;
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id, &attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:%-10s\n","Operational Status",learn_type[attr.value.s32]);

    return ret;
}

CTC_CLI(cli_sai_port_set_port_attr_update_dscp,
        cli_sai_port_set_port_attr_update_dscp_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) update-dscp (true|false)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Update DSCP of outgoing packets (default to FALSE)",
        "TRUE",
        "FALSE")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_UPDATE_DSCP;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("true"))
    {
        attr.value.booldata = true;
    }
    else
    {
        attr.value.booldata = false;
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id, &attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_port_set_port_attr_mtu,
        cli_sai_port_set_port_attr_mtu_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) (mtu VALUE)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "MTU (default to 1514 bytes)",
        "MTU size")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api    = NULL;
    sai_object_id_t     port_id     = 0;
    sai_attribute_t     attr;
    uint32_t            index;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_MTU;

    index = CTC_CLI_GET_ARGC_INDEX("mtu");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("mtu-size", attr.value.u32, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id ,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:%-10d\n","Mtu",attr.value.u32);

    return ret;
}


CTC_CLI(cli_sai_port_set_port_storm_control_enable,
        cli_sai_port_set_port_storm_control_enable_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) (flood|broadcast|multicast) storm_control mode(pps|kbps) threshold THRESHOLD_NUM",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "flood",
        "broadcast",
        "multicast",
        "storm_control",
        "The mode of storm control",
        "Packet per second",
        "1000 Bytes per second",
        "threshold",
        "pps:must be in multiples of 1000,kbps:<0-PortMaxSpeed/8>")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api = NULL;
    sai_policer_api_t*  policer_api = NULL;
    sai_object_id_t     port_id = 0;
    sai_object_id_t     policer_oid = 0;
    sai_attribute_t     attr[5];
    sai_attribute_t     storm_stl_attr;
    uint32              attr_count = 0;
    uint32              threshold_num = 0;
    uint32              type = 0;

    sal_memset(attr, 0x0, sizeof(sai_attribute_t));
    sal_memset(&storm_stl_attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    if (0 == sal_strcmp(argv[1], "flood"))
    {
        type = SAI_PORT_ATTR_FLOOD_STORM_CONTROL_POLICER_ID;
    }
    else if (0 == sal_strcmp(argv[1], "broadcast"))
    {
        type = SAI_PORT_ATTR_BROADCAST_STORM_CONTROL_POLICER_ID;
    }
    else if (0 == sal_strcmp(argv[1], "multicast"))
    {
        type = SAI_PORT_ATTR_MULTICAST_STORM_CONTROL_POLICER_ID;
    }
    storm_stl_attr.id = type;
    
    if (0 == sal_strcmp(argv[2], "pps"))
    {
        attr[attr_count].id = SAI_POLICER_ATTR_METER_TYPE;
        attr[attr_count].value.s32 = SAI_METER_TYPE_PACKETS;
        attr_count ++;  
    }
    else if (0 == sal_strcmp(argv[2], "kbps"))
    {
        attr[attr_count].id = SAI_POLICER_ATTR_METER_TYPE;
        attr[attr_count].value.s32 = SAI_METER_TYPE_BYTES;
        attr_count ++;  
    }
    CTC_CLI_GET_UINT32_RANGE("threshold-num", threshold_num, argv[3], 0, CTC_MAX_UINT32_VALUE);
    
    attr[attr_count].id = SAI_POLICER_ATTR_CIR;
    attr[attr_count].value.u64 = threshold_num;
    attr_count ++; 
    attr[attr_count].id = SAI_POLICER_ATTR_MODE;
    attr[attr_count].value.s32 = SAI_POLICER_MODE_STORM_CONTROL;
    attr_count ++;
    attr[attr_count].id = SAI_POLICER_ATTR_GREEN_PACKET_ACTION;
    attr[attr_count].value.s32 = SAI_PACKET_ACTION_FORWARD;
    attr_count ++;
    attr[attr_count].id = SAI_POLICER_ATTR_RED_PACKET_ACTION;
    attr[attr_count].value.s32 = SAI_PACKET_ACTION_DROP; 
    
    ret = sai_api_query(SAI_API_POLICER,(void**)&policer_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = policer_api->create_policer(&policer_oid, attr_count, attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    
    storm_stl_attr.value.oid = policer_oid;
    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = port_api->set_port_attribute(port_id, &storm_stl_attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    
    return ret;
}

CTC_CLI(cli_sai_port_set_port_storm_control_disable,
        cli_sai_port_set_port_storm_control_disable_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) unset (flood|broadcast|multicast) storm_control",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "unset",
        "flood",
        "broadcast",
        "multicast",
        "storm_control")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api = NULL;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     storm_stl_attr;
    uint32              type = 0;
    
    sal_memset(&storm_stl_attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    if (0 == sal_strcmp(argv[1], "flood"))
    {
        type = SAI_PORT_ATTR_FLOOD_STORM_CONTROL_POLICER_ID;
    }
    else if (0 == sal_strcmp(argv[1], "broadcast"))
    {
        type = SAI_PORT_ATTR_BROADCAST_STORM_CONTROL_POLICER_ID;
    }
    else if (0 == sal_strcmp(argv[1], "multicast"))
    {
        type = SAI_PORT_ATTR_MULTICAST_STORM_CONTROL_POLICER_ID;
    }
    storm_stl_attr.id = type;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    
    storm_stl_attr.value.oid = SAI_NULL_OBJECT_ID;
    ret = port_api->set_port_attribute(port_id, &storm_stl_attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    
    return ret;
}

CTC_CLI(cli_sai_port_set_global_flow_control,
        cli_sai_port_set_port_global_flow_control_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) global-flow-control (tx|rx|both|dis)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "global flow control",
        "egress",
        "ingress",
        "both",
        "disable")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api = NULL;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr;
    
    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_GLOBAL_FLOW_CONTROL;

    if (0 == sal_strcmp(argv[1], "tx"))
    {
         attr.value.booldata = TRUE;
         attr.value.s32 = SAI_PORT_FLOW_CONTROL_TX_ONLY;
    }
    else if (0 == sal_strcmp(argv[1], "rx"))
    {
         attr.value.booldata = TRUE;
         attr.value.s32 = SAI_PORT_FLOW_CONTROL_RX_ONLY;
    }
    else if (0 == sal_strcmp(argv[1], "both"))
    {
        attr.value.booldata = TRUE;
        attr.value.s32 = SAI_PORT_FLOW_CONTROL_BOTH_ENABLE;
    }
    else if (0 == sal_strcmp(argv[1], "dis"))
    {
        attr.value.booldata = FALSE;
        attr.value.s32 = SAI_PORT_FLOW_CONTROL_DISABLE;
    }
    
    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_port_set_max_learned_address,
        cli_sai_port_set_port_max_learned_address_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) max-learned-address VALUE",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "max learned address",
        "max learned address max value")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr;
    uint32_t            value = 0;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    CTC_CLI_GET_UINT16_RANGE("max-value", value, argv[1], 0, CTC_MAX_UINT16_VALUE);
    attr.value.u32 = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,value);
    
    attr.id = SAI_PORT_ATTR_MAX_LEARNED_ADDRESSES;
    
    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_port_set_fdb_learning_limit_violation,
        cli_sai_port_set_port_fdb_learning_limit_violation_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) fdb-learning-limit-violation (drop|forward|trap)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "fdb learning limit violation",
        "drop",
        "forward",
        "trap")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);
    
    attr.id = SAI_PORT_ATTR_FDB_LEARNING_LIMIT_VIOLATION;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("drop"))
    {
        attr.value.s32 = SAI_PACKET_ACTION_DROP;
    }
    else if(0xFF != CTC_CLI_GET_ARGC_INDEX("forward"))
    {
        attr.value.s32 = SAI_PACKET_ACTION_FORWARD;
    }
    else if(0xFF != CTC_CLI_GET_ARGC_INDEX("trap"))
    {
        attr.value.s32 = SAI_PACKET_ACTION_TRAP;
    }
    else
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}
CTC_CLI(cli_sai_port_set_port_policer_en,
        cli_sai_port_set_port_policer_en_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) policer ((enable (policer-id POLICER-ID))|disable)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Policer",
        "Policer en",
        "Policer id",
        "Policer id value",
        "Policer disable")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api;
    uint32_t            policer_id = 0;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr;
    uint8 index = 0xFF;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    index = CTC_CLI_GET_ARGC_INDEX("policer-id");
    if(0xFF != index)
    {
        CTC_CLI_GET_UINT16_RANGE("policer-id", policer_id, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
        attr.id = SAI_PORT_ATTR_POLICER_ID;
        attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,policer_id);
    }
    else
    {
        policer_id = 0;
        attr.id = SAI_PORT_ATTR_POLICER_ID;
        attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,policer_id);
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    return ret;
}

CTC_CLI(cli_sai_port_set_port_egress_policer_en,
        cli_sai_port_set_port_egress_policer_en_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) egress-policer ((enable (policer-id POLICER-ID))|disable)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Egress policer",
        "Policer en",
        "Policer id",
        "Policer id value",
        "Policer disable")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api;
    uint32_t            policer_id = 0;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr;
    uint8 index = 0xFF;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    index = CTC_CLI_GET_ARGC_INDEX("policer-id");
    if(0xFF != index)
    {
        CTC_CLI_GET_UINT16_RANGE("policer-id", policer_id, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
        attr.id = SAI_PORT_ATTR_EGRESS_POLICER_ID;
        attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,policer_id);
    }
    else
    {
        policer_id = 0;
        //attr.id = SAI_PORT_ATTR_EGRESS_POLICER_ID;
        attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,policer_id);
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    return ret;
}

CTC_CLI(cli_sai_port_set_port_scheduler_en,
        cli_sai_port_set_port_scheduler_en_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) scheduler ((enable (scheduler-id SCHEDULER-ID))|disable)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Scheduler",
        "Scheduler en",
        "Scheduler id",
        "Scheduler id value",
        "Scheduler disable")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api;
    uint32_t            scheduler_id = 0;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr;
    uint8 index = 0xFF;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    index = CTC_CLI_GET_ARGC_INDEX("scheduler-id");
    if(0xFF != index)
    {
        CTC_CLI_GET_UINT16_RANGE("scheduler-id", scheduler_id, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
        attr.id = SAI_PORT_ATTR_QOS_SCHEDULER_PROFILE_ID;
        attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,scheduler_id);
    }
    else
    {
        scheduler_id = 0;
        attr.id = SAI_PORT_ATTR_QOS_SCHEDULER_PROFILE_ID;
        attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,scheduler_id);
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    return ret;
}

CTC_CLI(cli_sai_port_set_port_qos_map_en,
        cli_sai_port_set_port_qos_map_en_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) qos-map type (dot1p-to-tc-color|dscp-to-tc-color  |tc-color-to-dot1p |tc-color-to-dscp ) (enable (map-id MAP-ID)|disable)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Qos map",
        "Qos map type",
        "Dot1p-to-tc-color type",
        "Dscp-to-tc-color type",
        "Tc-color-to-dot1p type",
        "Tc-color-to-dscp type",
        "enable",
        "Map id",
        "Map id value",
        "disable")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api;
    uint32_t            qos_map_id = 0;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr;
    uint8 index = 0xFF;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    index = CTC_CLI_GET_ARGC_INDEX("enable");
    if(0xFF != index)
    {
        CTC_CLI_GET_UINT32_RANGE("qos_map_id", qos_map_id, argv[index + 2], 0, CTC_MAX_UINT32_VALUE);
    }
    else
    {
        qos_map_id = 0;
    }
    index = CTC_CLI_GET_ARGC_INDEX("dot1p-to-tc-color");
    if(0xFF != index)
    {
        attr.id = SAI_PORT_ATTR_QOS_DOT1P_TO_TC_AND_COLOR_MAP;
        attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,qos_map_id);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dscp-to-tc-color");
    if(0xFF != index)
    {
        attr.id = SAI_PORT_ATTR_QOS_DSCP_TO_TC_AND_COLOR_MAP;
        attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,qos_map_id);
    }

    index = CTC_CLI_GET_ARGC_INDEX("tc-color-to-dot1p");
    if(0xFF != index)
    {
        attr.id = SAI_PORT_ATTR_QOS_TC_AND_COLOR_TO_DOT1P_MAP;
        attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,qos_map_id);
    }

    index = CTC_CLI_GET_ARGC_INDEX("tc-color-to-dscp");
    if(0xFF != index)
    {
        attr.id = SAI_PORT_ATTR_QOS_TC_AND_COLOR_TO_DSCP_MAP;
        attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,qos_map_id);
    }

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    return ret;
}

CTC_CLI(cli_sai_port_set_port_qos_map_default,
        cli_sai_port_set_port_qos_map_default_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) qos-map default",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Qos map",
        "Default qos map configuration")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_QOS_DEFAULT_TC;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->set_port_attribute(port_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    return ret;
}

CTC_CLI(cli_sai_port_get_port_queue_list,
        cli_sai_port_get_port_queue_list_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) queue-list",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "queue list")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr;
    sai_object_id_t queue_oid[16];
    uint16_t index = 0;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));
    sal_memset(queue_oid, 0, (sizeof(sai_object_id_t))*16);

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_QOS_QUEUE_LIST;
    attr.value.objlist.list = queue_oid;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ctc_cli_out("%-15s %-15s %-15s\n","queue-id", "queue-type", "queue-offset");
    for(index = 0; index < 13; index ++)
    {
        if(index < 8)
        {
            ctc_cli_out("%-15llu %-15s %-15u\n",CTC_SAI_OBJECT_INDEX_GET(attr.value.objlist.list[index]), "unicast", index);
        }
        else if(index < 12)
        {
            ctc_cli_out("%-15llu %-15s %-15u\n",CTC_SAI_OBJECT_INDEX_GET(attr.value.objlist.list[index]), "multicast", index);
        }
        else
        {
            ctc_cli_out("%-15llu %-15s %-15u\n",CTC_SAI_OBJECT_INDEX_GET(attr.value.objlist.list[index]), "mirror", index);
        }
    }

    return ret;
}

CTC_CLI(cli_sai_port_get_port_policer_id,
        cli_sai_port_get_port_policer_id_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) policer-id",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "policer id")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_POLICER_ID;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ctc_cli_out("%s : %"PRIu64"\n","policer_id", CTC_SAI_OBJECT_INDEX_GET(attr.value.oid));

    return ret;
}

CTC_CLI(cli_sai_port_get_port_egress_policer_id,
        cli_sai_port_get_port_egress_policer_id_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) egress-policer-id",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "egress policer id")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    //attr.id = SAI_PORT_ATTR_EGRESS_POLICER_ID;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ctc_cli_out("%s : %"PRIu64"\n","egress-policer_id", CTC_SAI_OBJECT_INDEX_GET(attr.value.oid));

    return ret;
}

CTC_CLI(cli_sai_port_get_port_scheduler_id,
        cli_sai_port_get_port_scheduler_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) scheduler-id",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "scheduler id")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*     port_api;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_QOS_SCHEDULER_PROFILE_ID;

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ctc_cli_out("%s : %"PRIu64"\n","scheduler", CTC_SAI_OBJECT_INDEX_GET(attr.value.oid));

    return ret;
}
CTC_CLI(cli_sai_port_set_ingress_mirror_session,
        cli_sai_port_set_port_ingress_mirror_session_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) ingress-mirror-session (SESSION_ID|)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "ingress mirror session",
        "<0-3>")
        
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_port_api_t* port_api;
    sai_object_id_t port_id = 0;
    sai_attribute_t attr;
    uint32_t        session_id = 0;
    sai_object_id_t session_oid = 0;
    sai_object_id_t list[3];

    sal_memset(&attr, 0, sizeof(sai_attribute_t));
    sal_memset(list, 0, sizeof(sai_object_id_t)*3);

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_INGRESS_MIRROR_SESSION;
    if (2 == argc)
    {
        CTC_CLI_GET_UINT16_RANGE("session_id", session_id, argv[1], 0, 3);
        session_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_MIRROR, session_id);        
        attr.value.objlist.count = 1;
        attr.value.objlist.list = list;
        attr.value.objlist.list[0] = session_oid;
    }
    else
    {
        attr.value.objlist.count = 0;
        attr.value.objlist.list = NULL;
    }
    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = port_api->set_port_attribute(port_id, &attr);
    if (SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    return ret;
}

CTC_CLI(cli_sai_port_set_egress_mirror_session,
        cli_sai_port_set_port_egress_mirror_session_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) egress-mirror-session (SESSION_ID|)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "egress mirror session",
        "<0-3>")
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_port_api_t* port_api;
    sai_object_id_t port_id = 0;
    sai_attribute_t attr;
    uint32_t        session_id = 0;
    sai_object_id_t session_oid = 0;
    sai_object_id_t list[3];
    
    sal_memset(&attr, 0, sizeof(sai_attribute_t));
    sal_memset(list, 0, sizeof(sai_object_id_t)*3);

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);
    
    attr.id = SAI_PORT_ATTR_EGRESS_MIRROR_SESSION;
    if (2 == argc)
    {   
          CTC_CLI_GET_UINT16_RANGE("session_id", session_id, argv[1], 0, 3);
          session_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_MIRROR,session_id);
          attr.value.objlist.count = 1;
          attr.value.objlist.list = list;
          attr.value.objlist.list[0] = session_oid;
    }
    else
    {
          attr.value.objlist.count = 0;
          attr.value.objlist.list = NULL;
    }
    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = port_api->set_port_attribute(port_id, &attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    return ret;
}

CTC_CLI(cli_sai_port_set_port_isolation_direction,
        cli_sai_port_set_port_isolation_direction_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) isolation-direction (ingress|egress|both)",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "isolation direction",
        "direction")
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_port_api_t* port_api;
    sai_object_id_t port_id = 0;
    sai_attribute_t attr;
    uint32_t        direction = SAI_PORT_ISOLATION_DIRECTION_BOTH;

    sal_memset(&attr, 0, sizeof(attr));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_ISOLATION_DIRECTION;
    if (0 == sal_strcmp(argv[1], "ingress"))
    {
        direction = SAI_PORT_ISOLATION_DIRECTION_INGRESS;
    }
    else if (0 == sal_strcmp(argv[1], "egress"))
    {
        direction = SAI_PORT_ISOLATION_DIRECTION_EGRESS;
    }
    else if (0 == sal_strcmp(argv[1], "both"))
    {
        direction = SAI_PORT_ISOLATION_DIRECTION_BOTH;
    }
    
    attr.value.s32 = direction;
    
    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = port_api->set_port_attribute(port_id, &attr);
    if (SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_port_set_port_isolation_group,
        cli_sai_port_set_port_isolation_group_cmd,
        "port set-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) isolation-group ISOLATION_ID",
        "Port",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "isolation group",
        "isolation ID")
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_port_api_t* port_api;
    sai_object_id_t port_id = 0;
    sai_attribute_t attr;
    uint32_t        isolation_id = 0;
    sai_object_id_t isolation_oid = 0;

    sal_memset(&attr, 0, sizeof(attr));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr.id = SAI_PORT_ATTR_ISOLATION_GROUP;
    CTC_CLI_GET_UINT32_RANGE("isolation_id", isolation_id, argv[1], 0, 31);
    isolation_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ISOLATION_GROUP, isolation_id);
    attr.value.oid = isolation_oid;
    
    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = port_api->set_port_attribute(port_id, &attr);
    if (SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_port_get_port_isolation,
        cli_sai_port_get_port_isolation_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) isolation",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "isolation")
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_port_api_t* port_api;
    sai_object_id_t port_id = 0;
    sai_attribute_t attr_list[2];
    uint32_t        isolation_dir = 0;
    uint32_t        isolation_id = 0;
    sai_object_id_t isolation_oid = 0;
    char *isolation_dir_str[] = {"both", "inress", "egress"};
    char *str = "invalid";

    sal_memset(&attr_list, 0, sizeof(attr_list));

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_LAG_ID(port_id);

    attr_list[0].id = SAI_PORT_ATTR_ISOLATION_GROUP;
    attr_list[1].id = SAI_PORT_ATTR_ISOLATION_DIRECTION;
    
    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = port_api->get_port_attribute(port_id, 2, attr_list);
    if (SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    isolation_oid = attr_list[0].value.oid;
    isolation_id = CTC_SAI_OBJECT_INDEX_GET(isolation_oid);
    isolation_dir = attr_list[1].value.s32;

    ctc_cli_out("isolation group     %u \n", isolation_id);
    if (isolation_dir <= SAI_PORT_ISOLATION_DIRECTION_EGRESS)
    {
        str = isolation_dir_str[isolation_dir];
    }
    ctc_cli_out("isolation direction %u (%s) \n", isolation_dir, str);

    return ret;
}

    
#if 0
CTC_CLI(cli_sai_port_set_ingress_samplepacket_enable,
        cli_sai_port_set_ingress_samplepacket_enable_cmd,
        "port PORT_ID attribute set ingress samplepacket enable",
        "port","port id",
        "attribute",
        "get",
        "ingress",
        "samplepacket",
        "enable")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    uint32              index;
    sai_port_api_t*     port_api;
    uint32_t            port_id = 0;
    sai_object_id_t     port_oid = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    index = CTC_CLI_GET_ARGC_INDEX("port");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("src-port", port_id, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,port_id);
    }

    attr.id = SAI_PORT_ATTR_INGRESS_SAMPLEPACKET_ENABLE;

    port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,port_id);

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_oid,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_port_get_egress_samplepacket_enable,
        cli_sai_port_get_egress_samplepacket_enable_cmd,
        "port PORT_ID attribute get egress samplepacket enable",
        "port","port id",
        "attribute",
        "get",
        "egress",
        "samplepacket",
        "enable")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    uint32              index;
    sai_port_api_t*     port_api;
    uint32_t            port_id = 0;
    sai_object_id_t     port_oid = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    index = CTC_CLI_GET_ARGC_INDEX("port");
    if(index != 0xFF)
    {
        CTC_CLI_GET_UINT16_RANGE("src-port", port_id, argv[index + 1], 0, CTC_MAX_UINT16_VALUE);
        port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,port_id);
    }

    attr.id = SAI_PORT_ATTR_EGRESS_SAMPLEPACKET_ENABLE;

    port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,port_id);

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = port_api->get_port_attribute(port_oid,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}
#endif


CTC_CLI(cli_sai_port_stats_get_counter,
        cli_sai_port_stats_get_counter_cmd,
        "port get-attribute ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) get-port-stats",
        "Port",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "get port stats")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    sai_port_api_t*  port_api = NULL;
    sai_port_stat_counter_t counter_port_stats[SAI_PORT_STAT_IF_OUT_PAUSE_PKTS+1];
    uint64_t port_stats_rlt[SAI_PORT_STAT_IF_OUT_PAUSE_PKTS+1];
    uint32 gport_id = 0;
    uint32_t attr_count = 0;
    int i = 0;
    sai_object_id_t     port_oid = 0;

    sal_memset(port_stats_rlt, 0x0, sizeof(port_stats_rlt));
    sal_memset(counter_port_stats, 0x0, sizeof(counter_port_stats));

    CTC_CLI_GET_UINT16_RANGE("ctc_port_stats_port_id", gport_id, argv[0], 0, CTC_MAX_UINT16_VALUE);
    port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,gport_id);

    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    for (i = 0; i <= SAI_PORT_STAT_IF_OUT_PAUSE_PKTS; i++)
    {
        counter_port_stats[i] = i;
    }

    ret = port_api->get_port_stats(port_oid, counter_port_stats, 
                                SAI_PORT_STAT_IF_OUT_PAUSE_PKTS+1, port_stats_rlt);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    
    for (attr_count = 0; attr_count < SAI_PORT_STAT_IF_OUT_PAUSE_PKTS; attr_count++)
    {
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_OCTETS)
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_OCTETS %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_UCAST_PKTS)
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_UCAST_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_NON_UCAST_PKTS)
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_NON_UCAST_PKTS %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_DISCARDS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_DISCARDS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_ERRORS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_ERRORS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_UNKNOWN_PROTOS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_UNKNOWN_PROTOS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_BROADCAST_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_BROADCAST_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_MULTICAST_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_MULTICAST_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_OUT_OCTETS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_OUT_OCTETS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_OUT_UCAST_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_OCTETS %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_OUT_UCAST_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_OCTETS %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_OUT_NON_UCAST_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_OUT_NON_UCAST_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_OUT_DISCARDS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_OUT_DISCARDS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_OUT_ERRORS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_OUT_ERRORS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_OUT_BROADCAST_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_OUT_BROADCAST_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_OUT_MULTICAST_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_OUT_MULTICAST_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_DROP_EVENTS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_DROP_EVENTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_MULTICAST_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_MULTICAST_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_BROADCAST_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_BROADCAST_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_UNDERSIZE_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_UNDERSIZE_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_FRAGMENTS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_FRAGMENTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_PKTS_64_OCTETS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_PKTS_64_OCTETS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_PKTS_65_TO_127_OCTETS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_PKTS_65_TO_127_OCTETS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_PKTS_128_TO_255_OCTETS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_PKTS_128_TO_255_OCTETS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_PKTS_256_TO_511_OCTETS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_PKTS_256_TO_511_OCTETS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_PKTS_512_TO_1023_OCTETS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_PKTS_512_TO_1023_OCTETS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_PKTS_1024_TO_1518_OCTETS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_PKTS_1024_TO_1518_OCTETS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_OVERSIZE_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_OVERSIZE_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_RX_OVERSIZE_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_RX_OVERSIZE_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_TX_OVERSIZE_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_TX_OVERSIZE_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_JABBERS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_JABBERS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_OCTETS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_OCTETS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_COLLISIONS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_COLLISIONS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_CRC_ALIGN_ERRORS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_CRC_ALIGN_ERRORS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_TX_NO_ERRORS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_TX_NO_ERRORS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_ETHER_STATS_RX_NO_ERRORS )
        {
            ctc_cli_out("SAI_PORT_STAT_ETHER_STATS_RX_NO_ERRORS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_PKTS   )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_PKTS    %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_OAM_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_OAM_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_RUNTS_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_RUNTS_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_GIANTS_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_GIANTS_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_CRC_ERR_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_CRC_ERR_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_CRC_ERR_OCTETS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_CRC_ERR_OCTETS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_FRAME_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_FRAME_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_PAUSE_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_PAUSE_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_BAD_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_BAD_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_IN_BAD_OCTETS  )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_IN_BAD_OCTETS   %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }        
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_OUT_PKTS  )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_OUT_PKTS   %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }        
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_OUT_OAM_PKTS  )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_OUT_OAM_PKTS   %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_OUT_FCS_ERR_OCTETS  )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_OUT_FCS_ERR_OCTETS   %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        }        
        if (counter_port_stats[attr_count] == SAI_PORT_STAT_IF_OUT_PAUSE_PKTS )
        {
            ctc_cli_out("SAI_PORT_STAT_IF_OUT_PAUSE_PKTS  %"PRIu64"\n", port_stats_rlt[attr_count]);
            continue;
        } 
    }

    return ret;
}


CTC_CLI(cli_sai_port_show_global,
        cli_sai_port_show_global_cmd,
        "show sai port (PORTID|) (detail|)",
        "Show",
        "SAI",
        "Port information",
        "PORT ID"
        )
{
    int i = 0;
    int isdetail = 0;
    int status;
    int speed;
    int32_t            port_id = -1;
    const char          *opera_status[] = {"Unknown","Up","Down","Test Running","Not Present"};
    sai_port_api_t*     port_api;
    int            ret = 0;
    sai_object_id_t     port_oid = 0;
    sai_attribute_t     attr;
    //const char          *speedchar[] = {"10M","100M","1G","2.5G","10G","40G","100G"};


#ifdef GOLDENGATE
    sys_datapath_lport_attr_t*  port_attr = NULL;
    int32_t                     sdk_ret = 0;
#endif

    if(argc == 1 && sal_strcmp(argv[0],"detail"))
    {
        CTC_CLI_GET_UINT16_RANGE("src-port", port_id, argv[0], 0, CTC_MAX_LPORT);
    }
    else if(argc == 2)
    {
        CTC_CLI_GET_UINT16_RANGE("src-port", port_id, argv[0], 0, CTC_MAX_LPORT);
        isdetail = 1;
    }
    if(argc == 1 && (!sal_strcmp(argv[0],"detail")))
    {
        isdetail = 1;
    }

    if(argc == 0)
    {
        
        for (i = 0; i < CTC_MAX_LPORT; i++)
        {  
#ifdef GOLDENGATE
            sdk_ret = sys_goldengate_common_get_port_capability(0,i, &port_attr);
            if (sdk_ret < 0)
            {
                continue;
            }

            if (port_attr->port_type != SYS_DATAPATH_NETWORK_PORT)
            {
                continue;
            }
#endif
    
    ctc_cli_out("gport       oid    status     speed lag  flag\n");
    sal_memset(&attr, 0, sizeof(sai_attribute_t));
    port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,i);
    attr.id = SAI_PORT_ATTR_OPER_STATUS;
    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = port_api->get_port_attribute(port_oid,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    status = attr.value.s32;


    attr.id = SAI_PORT_ATTR_SPEED;
    port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,i);
    ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = port_api->get_port_attribute(port_oid,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    speed = attr.value.u32;


    ctc_cli_out("%5d%10llx%10s%10d%4d%6x\n",
        i,
        port_oid,
        opera_status[status],
        speed,
        CTC_SAI_OBJECT_INDEX_GET(g_sai_port_info.port_entries[i].lag_id),
        g_sai_port_info.port_entries[i].flag
        ); 

        }
    }
    else
    {
        if(port_id < 0)
        {
            return CLI_SUCCESS;
        }
        i =  port_id;
#ifdef GOLDENGATE
        sdk_ret = sys_goldengate_common_get_port_capability(0, i, &port_attr);
        if (sdk_ret < 0)
        {
            ctc_cli_out("Invalid port id");
        }

        if (port_attr->port_type != SYS_DATAPATH_NETWORK_PORT)
        {
            ctc_cli_out("Invalid port id");
        }
#endif

        sal_memset(&attr, 0, sizeof(sai_attribute_t));
        port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,i);
        attr.id = SAI_PORT_ATTR_OPER_STATUS;
        ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
        ret = port_api->get_port_attribute(port_oid,1,&attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
        status = attr.value.s32;
    
    
        attr.id = SAI_PORT_ATTR_SPEED;
        port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,i);
        ret = sai_api_query(SAI_API_PORT,(void**)&port_api);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
        ret = port_api->get_port_attribute(port_oid,1,&attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
    
        speed = attr.value.u32;
    

        if(!isdetail)
        {
            ctc_cli_out("gport       oid    status     speed lag  flag\n");

            ctc_cli_out("%5d%10llx%10s%10d%4d%6x\n",
                i,
                port_oid,
                opera_status[status],
                speed,
                CTC_SAI_OBJECT_INDEX_GET(g_sai_port_info.port_entries[i].lag_id),
                g_sai_port_info.port_entries[i].flag
                ); 
        }
        else
        {
                ctc_cli_out("%-10s:%-10d\n","gport", i);
                ctc_cli_out("%-10s:%-10llx\n","oid", port_oid);
                ctc_cli_out("%-10s:%-10s\n","Status", opera_status[status]);
                ctc_cli_out("%-10s:%-10d\n","Speed", speed);
                ctc_cli_out("%-10s:%-10d\n","Lagid", CTC_SAI_OBJECT_INDEX_GET(g_sai_port_info.port_entries[i].lag_id));
                ctc_cli_out("%-10s:%-10x\n","Flag", g_sai_port_info.port_entries[i].flag);
                ctc_cli_out("%-10s:%-10x\n","tagctl", g_sai_port_info.port_entries[i].status.tag_ctrl);
                ctc_cli_out("%-10s:%-10x\n","1qtype", g_sai_port_info.port_entries[i].status.dot1q_type);
                ctc_cli_out("%-10s:%-10x\n","trans_en", g_sai_port_info.port_entries[i].status.transmit_en);
                ctc_cli_out("%-10s:%-10x\n","receive_en", g_sai_port_info.port_entries[i].status.receive_en);
                ctc_cli_out("%-10s:%-10x\n","lag_bind", g_sai_port_info.port_entries[i].status.lag_bind_en);
                ctc_cli_out("%-10s:%-10x\n","f-ctl_en", g_sai_port_info.port_entries[i].enable);
                ctc_cli_out("%-10s:%-10x\n","f-ctl_dir", g_sai_port_info.port_entries[i].dir);

        }

    }

    return CLI_SUCCESS;
}

int32
ctc_sai_port_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_type_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_operational_status_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_hw_line_list_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_supported_breakout_mode_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_current_breakout_mode_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_speed_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_admin_state_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_media_type_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_default_vlan_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_default_vlan_priority_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_ingress_filtering_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_drop_untagged_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_drop_tagged_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_internal_loopback_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_fdb_learning_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_update_dscp_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_attr_mtu_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_storm_control_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_global_flow_control_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_max_learned_address_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_fdb_learning_limit_violation_cmd); 
    install_element(cli_tree_mode, &cli_sai_port_get_port_mirror_session_cmd);   
    install_element(cli_tree_mode, &cli_sai_port_get_ingress_samplepacket_enable_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_egress_samplepacket_enable_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_queue_list_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_policer_id_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_scheduler_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_egress_policer_id_cmd);
    
    
    
    install_element(cli_tree_mode, &cli_sai_port_set_port_attr_speed_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_attr_admin_state_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_attr_media_type_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_attr_default_vlan_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_attr_default_vlan_priority_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_attr_ingress_filtering_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_attr_drop_untagged_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_attr_drop_tagged_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_attr_internal_loopback_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_attr_fdb_learning_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_attr_update_dscp_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_attr_mtu_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_storm_control_enable_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_storm_control_disable_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_global_flow_control_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_max_learned_address_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_fdb_learning_limit_violation_cmd);

    install_element(cli_tree_mode, &cli_sai_port_set_port_policer_en_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_scheduler_en_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_qos_map_en_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_qos_map_default_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_egress_policer_en_cmd);

    install_element(cli_tree_mode, &cli_sai_port_set_port_ingress_mirror_session_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_egress_mirror_session_cmd);
/*
    install_element(cli_tree_mode, &cli_sai_port_set_ingress_samplepacket_enable_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_egress_samplepacket_enable_cmd);
*/
    install_element(cli_tree_mode, &cli_sai_port_stats_get_counter_cmd);
    install_element(cli_tree_mode, &cli_sai_port_show_global_cmd);

    install_element(cli_tree_mode, &cli_sai_port_set_port_isolation_direction_cmd);
    install_element(cli_tree_mode, &cli_sai_port_set_port_isolation_group_cmd);
    install_element(cli_tree_mode, &cli_sai_port_get_port_isolation_cmd);

    return CLI_SUCCESS;
}


#include "sal.h"
#include "ctc_cli.h"
#include "ctc_debug.h"
#include <sai.h>

#include "ctc_sai_debug.h"
#include "genlog.h"

uint32 g_sai_debug_flag = FALSE;
uint32 g_ctc_debug_flag;

CTC_CLI(cli_sai_debug,
        cli_sai_debug_cmd,
        "debug sai (function | parameter | packet) (disable | enable)",
        "Set debug configuration",
        "SAI",
        "SAI function",
        "SAI parameter"
        "SAI packet"
        "Disable",
        "Enable")
{
    uint32 flag = 0;

    if (sal_strncmp (argv[1], "f", 1) == 0)
    {
        flag = SAI_DEBUG_FLAG_FUNC;
    }
    else if (sal_strncmp (argv[1], "p", 1) == 0)
    {
        flag = SAI_DEBUG_FLAG_PACKET;
    }
    else
    {
        flag = SAI_DEBUG_FLAG_PARAM;
    }

    if (sal_strncmp (argv[1], "e", 1) == 0)
    {
        g_sai_debug_flag |= flag;
    }
    else
    {
        g_sai_debug_flag &= ~flag;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_ctc_debug,
        cli_ctc_debug_cmd,
        "debug ctc (disable | enable)",
        "Set debug configuration",
        "SDK function",
        "Disable",
        "Enable")
{
    if (sal_strncmp (argv[0], "e", 1) == 0)
    {
        g_ctc_debug_flag = TRUE;
    }
    else
    {
        g_ctc_debug_flag = FALSE;
    }

    return CLI_SUCCESS;
}

int32
ctc_sai_debug_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_debug_cmd);
    install_element(cli_tree_mode, &cli_ctc_debug_cmd);

    return CLI_SUCCESS;
}

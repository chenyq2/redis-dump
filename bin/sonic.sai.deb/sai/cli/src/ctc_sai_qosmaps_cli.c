#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include "ctc_const.h"
#include <ctc_sai_common.h>
#include "ctc_cli_common.h"

CTC_CLI(cli_sai_qos_map_create_qos_map,
        cli_sai_qos_map_create_qos_map_cmd,
        "qos-map create ((dot1p-to-tc-color) | (dscp-to-tc-color) | (tc-color-to-dot1p) |(tc-color-to-dscp))",
        "Qos map table",
        "Creat qos map table",
        "Dot1p-to-tc-color mode",
        "Dscp-to-tc-color mode",
        "Tc-color-to-dot1p mode",
        "Tc-color-to-dscp mode"
        )
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint8 index = 0xFF;
    sai_object_id_t qos_map_id;
    sai_qos_map_api_t*  qos_map_api;
    sai_attribute_t attr[2] = {{0}};
    uint32_t count;
    sai_qos_map_t qos_map_list[64];

    index = CTC_CLI_GET_ARGC_INDEX("dot1p-to-tc-color");
    if(0xFF != index)
    {
        attr[0].id = SAI_QOS_MAP_ATTR_TYPE;
        attr[0].value.s32 = SAI_QOS_MAP_DOT1P_TO_TC_AND_COLOR;

        attr[1].id = SAI_QOS_MAP_ATTR_MAP_TO_VALUE_LIST;
        for(count = 0; count < 8; count ++)
        {
            qos_map_list[count].key.dot1p = count;
            qos_map_list[count].value.tc = count;
            qos_map_list[count].value.color = SAI_PACKET_COLOR_GREEN;
        }
        attr[1].value.qosmap.list = qos_map_list;
        attr[1].value.qosmap.count = count;
        
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("dscp-to-tc-color");
    if(0xFF != index)
    {
        attr[0].id = SAI_QOS_MAP_ATTR_TYPE;
        attr[0].value.s32 = SAI_QOS_MAP_DSCP_TO_TC_AND_COLOR;

        attr[1].id = SAI_QOS_MAP_ATTR_MAP_TO_VALUE_LIST;
        for(count = 0; count < 64; count ++)
        {
            qos_map_list[count].key.dscp = count;
            qos_map_list[count].value.tc = count/8;
            qos_map_list[count].value.color = SAI_PACKET_COLOR_GREEN;
        }
        attr[1].value.qosmap.list = qos_map_list;
        attr[1].value.qosmap.count = count;
        
    }
    index = CTC_CLI_GET_ARGC_INDEX("tc-color-to-dot1p");
    if(0xFF != index)
    {
        attr[0].id = SAI_QOS_MAP_ATTR_TYPE;
        attr[0].value.s32 = SAI_QOS_MAP_TC_AND_COLOR_TO_DOT1P;

        attr[1].id = SAI_QOS_MAP_ATTR_MAP_TO_VALUE_LIST;
        for(count = 0; count < 8; count ++)
        {
            qos_map_list[count*3].key.tc = count;
            qos_map_list[count*3].key.color = SAI_PACKET_COLOR_GREEN;
            qos_map_list[count*3].value.dot1p = count;
            qos_map_list[count*3 + 1].key.tc = count;
            qos_map_list[count*3 + 1].key.color = SAI_PACKET_COLOR_YELLOW;
            qos_map_list[count*3 + 1].value.dot1p = count;
            qos_map_list[count*3 + 2].key.tc = count;
            qos_map_list[count*3 + 2].key.color = SAI_PACKET_COLOR_RED;
            qos_map_list[count*3 + 2].value.dot1p = count;
        }
        attr[1].value.qosmap.list = qos_map_list;
        attr[1].value.qosmap.count = count * 3;  
    }

    index = CTC_CLI_GET_ARGC_INDEX("tc-color-to-dscp");
    if(0xFF != index)
    {
        attr[0].id = SAI_QOS_MAP_ATTR_TYPE;
        attr[0].value.s32 = SAI_QOS_MAP_TC_AND_COLOR_TO_DSCP;

        attr[1].id = SAI_QOS_MAP_ATTR_MAP_TO_VALUE_LIST;
        for(count = 0; count < 8; count ++)
        {
            qos_map_list[count*3].key.tc = count;
            qos_map_list[count*3].key.color = SAI_PACKET_COLOR_GREEN;
            qos_map_list[count*3].value.dscp = count *8;
            qos_map_list[count*3 + 1].key.tc = count;
            qos_map_list[count*3 + 1].key.color = SAI_PACKET_COLOR_YELLOW;
            qos_map_list[count*3 + 1].value.dscp = count *8;
            qos_map_list[count*3 + 2].key.tc = count;
            qos_map_list[count*3 + 2].key.color = SAI_PACKET_COLOR_RED;
            qos_map_list[count*3 + 2].value.dscp = count *8;
        }
        attr[1].value.qosmap.list = qos_map_list;
        attr[1].value.qosmap.count = count * 3;  
    }

    ret = sai_api_query(SAI_API_QOS_MAPS,(void**)&qos_map_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = qos_map_api->create_qos_map(&qos_map_id, 2, attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:0x%-10llx\n","qos_map id",CTC_SAI_OBJECT_INDEX_GET(qos_map_id));

    return ret;
}


CTC_CLI(cli_sai_qos_map_delete_qos_map,
        cli_sai_qos_map_delete_qos_map_cmd,
        "qos-map remove QOS-MAP-ID",
        "Qos map",
        "Remove qos-map table",
        "Qos map table id value")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint32_t     qos_map_id = 0;
    sai_object_id_t qos_map_oid;
    sai_qos_map_api_t*  qos_map_api;


    CTC_CLI_GET_UINT32("qos_map_id", qos_map_id, argv[0]);

    qos_map_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_QOS_MAPS, qos_map_id);

    ret = sai_api_query(SAI_API_QOS_MAPS,(void**)&qos_map_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = qos_map_api->remove_qos_map(qos_map_oid);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}


CTC_CLI(cli_sai_qos_map_set_qos_map_attribute,
        cli_sai_qos_map_set_qos_map_attribute_cmd,
        "qos-map set-attribute map-id MAP-ID ((dot1p-to-tc-color (dot1p DOT1P tc TC color COLOR)) | (dscp-to-tc-color (dscp DSCP tc TC color COLOR)) | (tc-color-to-dot1p (tc TC color COLOR dot1p DOT1P)) |(tc-color-to-dscp (tc TC color COLOR dscp DSCP)))",
        "Qos map table",
        "Set attribute",
        "Map id",
        "Map id value",
        "Dot1p-to-tc-color mode",
        "Dot1p",
        "Dot1p value",
        "TC",
        "TC value",
        "Color",
        "Color value",
        "Dscp-to-tc-color mode",
        "Dscp",
        "Dscp value",
        "TC",
        "TC value",
        "Color",
        "Color value",
        "Tc-color-to-dot1p mode",
        "TC",
        "TC value",
        "Color",
        "Color value",
        "Dot1p",
        "Dot1p value",
        "Tc-color-to-dscp mode",
        "TC",
        "TC value",
        "Color",
        "Color value",
        "Dscp",
        "Dscp value")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint8 index = 0xFF;
    sai_object_id_t qos_map_id;
    uint32_t ctc_qos_map_id;
    sai_qos_map_api_t*  qos_map_api;
    sai_attribute_t attr = {0};
    sai_qos_map_t qos_map;

    sal_memset(&qos_map, 0x0, sizeof(sai_qos_map_t));

    CTC_CLI_GET_UINT32("ctc_qos_map_id", ctc_qos_map_id, argv[0]);
    qos_map_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_QOS_MAPS, ctc_qos_map_id);

    index = CTC_CLI_GET_ARGC_INDEX("dot1p-to-tc-color");
    if(0xFF != index)
    {
        attr.id = SAI_QOS_MAP_DOT1P_TO_TC_AND_COLOR;
        CTC_CLI_GET_UINT32_RANGE("dot1p", qos_map.key.dot1p, argv[index + 2],0, 7);
        CTC_CLI_GET_UINT32_RANGE("tc", qos_map.value.tc, argv[index + 4],0,7);
        CTC_CLI_GET_UINT32_RANGE("color", qos_map.value.color, argv[index + 6],0,2);
    }

    index = CTC_CLI_GET_ARGC_INDEX("dscp-to-tc-color");
    if(0xFF != index)
    {
        attr.id = SAI_QOS_MAP_DSCP_TO_TC_AND_COLOR;
        CTC_CLI_GET_UINT32_RANGE("dscp", qos_map.key.dscp, argv[index + 2], 0, 63);
        CTC_CLI_GET_UINT32_RANGE("tc", qos_map.value.tc, argv[index + 4],0,7);
        CTC_CLI_GET_UINT32_RANGE("color", qos_map.value.color, argv[index + 6],0, 2);
    }

    index = CTC_CLI_GET_ARGC_INDEX("tc-color-to-dot1p");
    if(0xFF != index)
    {
        attr.id = SAI_QOS_MAP_TC_AND_COLOR_TO_DOT1P;
        CTC_CLI_GET_UINT32_RANGE("tc", qos_map.key.tc, argv[index + 2],0, 7);
        CTC_CLI_GET_UINT32_RANGE("color", qos_map.key.color, argv[index + 4], 0, 2);
        CTC_CLI_GET_UINT32_RANGE("dot1p", qos_map.value.dot1p, argv[index + 6], 0, 7);
    }

    index = CTC_CLI_GET_ARGC_INDEX("tc-color-to-dscp");
    if(0xFF != index)
    {
        attr.id = SAI_QOS_MAP_TC_AND_COLOR_TO_DSCP;
        CTC_CLI_GET_UINT32_RANGE("tc", qos_map.key.tc, argv[index + 2], 0, 7);
        CTC_CLI_GET_UINT32_RANGE("color", qos_map.key.color, argv[index + 4], 0, 2);
        CTC_CLI_GET_UINT32_RANGE("dscp", qos_map.value.dscp, argv[index + 6], 0, 63);
    }
    attr.value.qosmap.count = 1;
    attr.value.qosmap.list = &qos_map;

    ret = sai_api_query(SAI_API_QOS_MAPS,(void**)&qos_map_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = qos_map_api->set_qos_map_attribute(qos_map_id, &attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_qos_map_get_qos_map_attribute,
        cli_sai_qos_map_get_qos_map_attribute_cmd,
        "qos-map get-attribute map-id MAP-ID (dot1p-to-tc-color|dscp-to-tc-color | tc-color-to-dot1p| tc-color-to-dscp) ",
        "Qos map table",
        "Set attribute",
        "Map id",
        "Map id value",
        "dot1p-to-tc-color",
        "dscp-to-tc-color",
        "tc-color-to-dot1p",
        "tc-color-to-dscp"
        )
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint8 index = 0xFF;
    sai_object_id_t qos_map_id;
    uint32_t ctc_qos_map_id;
    sai_qos_map_api_t*  qos_map_api;
    sai_attribute_t attr[1];
    uint32_t attr_count = 0;
    uint32_t key_index = 0;
    uint32_t color_index = 0;
    uint32_t qosmap_count = 0;
    sai_qos_map_t qos_map[64];

    sal_memset(&qos_map, 0x0, (sizeof(sai_qos_map_t)) *64);
    sal_memset(attr, 0x0, sizeof(sai_attribute_t));
    attr[attr_count].value.qosmap.list = qos_map;

    CTC_CLI_GET_UINT32("ctc_qos_map_id", ctc_qos_map_id, argv[0]);
    qos_map_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_QOS_MAPS, ctc_qos_map_id);

    index = CTC_CLI_GET_ARGC_INDEX("dot1p-to-tc-color");
    if(0xFF != index)
    {
        attr[attr_count].id = SAI_QOS_MAP_DOT1P_TO_TC_AND_COLOR;
        for(key_index =0; key_index < 8;key_index ++)
        {
            attr[attr_count].value.qosmap.list[qosmap_count].key.dot1p = key_index;
            attr[attr_count].value.qosmap.count ++;
            qosmap_count ++;
        }

    }
    
    index = CTC_CLI_GET_ARGC_INDEX("dscp-to-tc-color");
    if(0xFF != index)
    {
        attr[attr_count].id = SAI_QOS_MAP_DSCP_TO_TC_AND_COLOR;
        for(key_index =0; key_index < 64;key_index ++)
        {
            attr[attr_count].value.qosmap.list[qosmap_count].key.dscp = key_index;
            attr[attr_count].value.qosmap.count ++;
            qosmap_count ++;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("tc-color-to-dot1p");
    if(0xFF != index)
    {
        attr[attr_count].id = SAI_QOS_MAP_TC_AND_COLOR_TO_DOT1P;
        for(key_index =0; key_index < 8;key_index ++)
        {
            for(color_index = 0;color_index< 3; color_index ++)
            {
                attr[attr_count].value.qosmap.list[qosmap_count].key.tc = key_index;
                attr[attr_count].value.qosmap.list[qosmap_count].key.color = color_index;
                attr[attr_count].value.qosmap.count ++;
                qosmap_count ++;
            }
        }
    }
    index = CTC_CLI_GET_ARGC_INDEX("tc-color-to-dscp");
    if(0xFF != index)
    {
        attr[attr_count].id = SAI_QOS_MAP_TC_AND_COLOR_TO_DSCP;
        for(key_index =0; key_index < 8; key_index ++)
        {
            for(color_index = 0;color_index< 3; color_index ++)
            {
                attr[attr_count].value.qosmap.list[qosmap_count].key.tc = key_index;
                attr[attr_count].value.qosmap.list[qosmap_count].key.color = color_index;
                attr[attr_count].value.qosmap.count ++;
                qosmap_count ++;
            }
        }
    }
    ret = sai_api_query(SAI_API_QOS_MAPS,(void**)&qos_map_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = qos_map_api->get_qos_map_attribute(qos_map_id, attr_count, attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    attr_count = 0;
    qosmap_count = 0;
    switch(attr[attr_count].id)
    {
        case SAI_QOS_MAP_DOT1P_TO_TC_AND_COLOR:
            ctc_cli_out("%s\n", "dot1p-to-tc-color");
            ctc_cli_out("% -10s %-10s %-10s\n", "dot1p", "TC", "color");
            for(key_index = 0; key_index < 8; key_index ++)
            {
                ctc_cli_out("% -10d %-10d %-10d\n", attr[attr_count].value.qosmap.list[qosmap_count].key.dot1p, 
                    attr[attr_count].value.qosmap.list[qosmap_count].value.tc, attr[attr_count].value.qosmap.list[qosmap_count].value.color);

                qosmap_count ++;
            }
            break;
        case SAI_QOS_MAP_DSCP_TO_TC_AND_COLOR:
            ctc_cli_out("%s\n", "dscp-to-tc-color");
            ctc_cli_out("% -10s %-10s %-10s\n", "dscp", "TC", "color");
            for(key_index = 0; key_index < 64; key_index ++)
            {
                ctc_cli_out("% -10d %-10d %-10d\n", attr[attr_count].value.qosmap.list[qosmap_count].key.dscp, 
                    attr[attr_count].value.qosmap.list[qosmap_count].value.tc, attr[attr_count].value.qosmap.list[qosmap_count].value.color);
                
                qosmap_count ++;
            }
            break;
        case SAI_QOS_MAP_TC_AND_COLOR_TO_DOT1P:
            ctc_cli_out("%s\n", "tc-color-to-dot1p");
            ctc_cli_out("% -10s %-10s %-10s\n", "TC", "color", "dot1p");
            for(key_index = 0; key_index < 8; key_index ++)
            {
                for(color_index = 0; color_index < 3; color_index ++)
                {
                    ctc_cli_out("% -10d %-10d %-10d\n", key_index, color_index, attr[attr_count].value.qosmap.list[qosmap_count].value.dot1p);
                    qosmap_count ++;
                }
            }
            break;
        case SAI_QOS_MAP_TC_AND_COLOR_TO_DSCP:
            ctc_cli_out("%s\n", "tc-color-to-dscp");
            ctc_cli_out("% -10s %-10s %-10s\n", "TC", "color", "dscp");
            for(key_index = 0; key_index < 8; key_index ++)
            {
                for(color_index = 0; color_index < 3; color_index ++)
                {
                    ctc_cli_out("% -10d %-10d %-10d\n", key_index, color_index, attr[attr_count].value.qosmap.list[qosmap_count].value.dscp);
                    qosmap_count ++;
                }
            }
            break;
        default:
            break;
    }

    return ret;
}

int32
ctc_sai_qos_map_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_qos_map_create_qos_map_cmd);
    install_element(cli_tree_mode, &cli_sai_qos_map_delete_qos_map_cmd);
    install_element(cli_tree_mode, &cli_sai_qos_map_set_qos_map_attribute_cmd);
    install_element(cli_tree_mode, &cli_sai_qos_map_get_qos_map_attribute_cmd);
    
    return CLI_SUCCESS;
}

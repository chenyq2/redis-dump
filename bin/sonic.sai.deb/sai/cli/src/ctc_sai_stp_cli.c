#include <sai.h>
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_sai_cli.h"
#include "ctc_vector.h"
#include "ctc_sai_stp.h"
#include <ctc_sai_common.h>

CTC_CLI(cli_sai_stp_create,
        cli_sai_stp_create_cmd,
        "stp create",
        "stp",
        "Create stp instance")
{
    sai_stp_api_t*   stp_api = NULL;
	sai_object_id_t  stpid;
    sai_status_t     ret 	 = SAI_STATUS_SUCCESS;

    ret = sai_api_query(SAI_API_STP,(void**)&stp_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = stp_api->create_stp(&stpid,0,NULL);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

	ctc_cli_out("%-10s:0x%-10llx\n","stp id",CTC_SAI_OBJECT_INDEX_GET(stpid));

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_stp_remove,
        cli_sai_stp_remove_cmd,
        "stp remove (stp-id SAI_OBJ_ID)",
        "stp",
        "Remove stp instance",
		"stp object id")
{
    sai_stp_api_t*   stp_api		= NULL;
	sai_object_id_t  stp_id = 0;
    sai_status_t     ret 	 		= SAI_STATUS_SUCCESS;

	SAI_CLI_GET_STP_ID(stp_id);

    ret = sai_api_query(SAI_API_STP,(void**)&stp_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = stp_api->remove_stp(stp_id);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_stp_set_port_state,
        cli_sai_stp_set_port_state_cmd,
        "stp set-port-state (stp-id SAI_OBJ_ID) (port-id SAI_OBJ_ID) (learning | forwarding | blocking)",
        "Stp",
        "Set-port-state",
		SAI_CLI_OBJ_STP_ID_DESC,
		SAI_CLI_OBJECT_VALUE,
		SAI_CLI_OBJ_PORT_ID_DESC,
		SAI_CLI_OBJECT_VALUE,
		"Port is in Learning mode",
		"Port is in Forwarding mode",
		"Port is in Blocking mode")
{
    sai_stp_api_t*   			stp_api		= NULL;
	sai_object_id_t  			stp_id = 0;
	sai_object_id_t  			port_id = 0;
	sai_port_stp_port_state_t	port_state 	= SAI_PORT_STP_STATE_LEARNING;
    sai_status_t     			ret 	 	= SAI_STATUS_SUCCESS;

	SAI_CLI_GET_STP_ID(stp_id);

	SAI_CLI_GET_PORT_ID(port_id);

	if(0xFF != CTC_CLI_GET_ARGC_INDEX("forwarding"))
	{
		port_state = SAI_PORT_STP_STATE_FORWARDING;
	}
	else if(0xFF != CTC_CLI_GET_ARGC_INDEX("blocking"))
	{
		port_state = SAI_PORT_STP_STATE_BLOCKING;
	}
	else
	{
		port_state 	= SAI_PORT_STP_STATE_LEARNING;
	}

    ret = sai_api_query(SAI_API_STP,(void**)&stp_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = stp_api->set_stp_port_state(stp_id,port_id,port_state);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_stp_get_port_state,
        cli_sai_stp_get_port_state_cmd,
        "stp get-port-state (stp-id SAI_OBJ_ID) (port-id SAI_OBJ_ID)",
        "Stp",
        "Get-port-state",
		SAI_CLI_OBJ_STP_ID_DESC,
		SAI_CLI_OBJECT_VALUE,
		SAI_CLI_OBJ_PORT_ID_DESC,
		SAI_CLI_OBJECT_VALUE)
{
    sai_stp_api_t   			*stp_api		= NULL;
	sai_object_id_t  			stp_id = 0;
	sai_object_id_t  			port_id = 0;
	sai_port_stp_port_state_t	port_state 		= SAI_PORT_STP_STATE_LEARNING;
    sai_status_t     			ret 	 		= SAI_STATUS_SUCCESS;
	const char                  *sz_state[]  	= {"learn","forward","block"};

	SAI_CLI_GET_STP_ID(stp_id);

	SAI_CLI_GET_PORT_ID(port_id);

    ret = sai_api_query(SAI_API_STP,(void**)&stp_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = stp_api->get_stp_port_state(stp_id,port_id,&port_state);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

	ctc_cli_out("%-10s:%-10s\n","stp port state",sz_state[port_state]);

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_stp_attr_get_vlans,
        cli_sai_stp_attr_get_vlans_cmd,
        "stp get-attribute (stp-id SAI_OBJ_ID) vlan",
        "Stp",
        SAI_CLI_GET_ATTRIBUTE_DESC,
		SAI_CLI_OBJ_STP_ID_DESC,
		SAI_CLI_OBJECT_VALUE,
		"Vlans attached to STP instance")
{
    sai_stp_api_t*   			stp_api			= NULL;
	sai_object_id_t  			stp_id = 0;
	sai_attribute_t				attr;
	uint32_t					vlan_idx 		= 0;
	sai_vlan_id_t*				attr_vlan_list 	= NULL;
    sai_status_t     			ret 	 		= SAI_STATUS_SUCCESS;

	sal_memset(&attr,0,sizeof(sai_attribute_t));

	SAI_CLI_GET_STP_ID(stp_id);

	attr.id = SAI_STP_ATTR_VLAN_LIST;

	attr_vlan_list = mem_malloc(MEM_APP_STP_MODULE,sizeof(sai_vlan_id_t) * 4096);
	if(!attr_vlan_list)
	{
		ret = SAI_STATUS_NO_MEMORY;
		ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
		return CLI_SUCCESS;
	}

	sal_memset(attr_vlan_list,0,sizeof(sai_vlan_id_t) * 4096);
	attr.value.vlanlist.vlan_count = 4096;
	attr.value.vlanlist.vlan_list  = attr_vlan_list;

    ret = sai_api_query(SAI_API_STP,(void**)&stp_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
		mem_free(attr_vlan_list);
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = stp_api->get_stp_attribute(stp_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
		mem_free(attr_vlan_list);
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

	ctc_cli_out("%-10s:","vlans");
	for(vlan_idx = 0; vlan_idx < attr.value.vlanlist.vlan_count; vlan_idx++)
	{
		if(vlan_idx % 16 == 0)
		{
			ctc_cli_out("\n%-10s:"," ");
		}
		ctc_cli_out("%-6d,",attr.value.vlanlist.vlan_list[vlan_idx]);
	}
	ctc_cli_out("\n");

	mem_free(attr_vlan_list);
    return CLI_SUCCESS;
}

extern struct ctc_sai_stp_info_s   g_ctc_sai_stp_info;

static int32
_ctc_sai_show_stp_entry(ctc_sai_stp_entry_t* pst_stp_entry, void* data)
{
    uint32    vlan_idx = 1;

    if(NULL == pst_stp_entry)
        return 0;

    ctc_cli_out("stpid:%d, ref: %d \n", (uint32)pst_stp_entry->stp_id, pst_stp_entry->ref);
    ctc_cli_out("VLAN list: ");

    for (vlan_idx = 1; vlan_idx < CTC_SAI_VLAN_ID_MAX; vlan_idx++)
    {
        if(IS_BIT_SET(pst_stp_entry->vlan_bitmap[(vlan_idx >> 5)], (vlan_idx & 0x1F)))
        {
            ctc_cli_out("%10d", vlan_idx);
        }
    }

    ctc_cli_out("\n\n");
    

    return 0;
}

CTC_CLI(cli_sai_stp_show,
        cli_sai_stp_show_cmd,
        "show sai stp",
        "show information",
        "SAI",
        "stp modoule")
{
    ctc_cli_out("STP instance entry list:\n");
    ctc_vector_traverse(g_ctc_sai_stp_info.pvector, (vector_traversal_fn)_ctc_sai_show_stp_entry, NULL);
    ctc_cli_out("\n");

    return CLI_SUCCESS;
}


int32
ctc_sai_stp_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_stp_create_cmd);
	install_element(cli_tree_mode, &cli_sai_stp_remove_cmd);
	install_element(cli_tree_mode, &cli_sai_stp_set_port_state_cmd);
	install_element(cli_tree_mode, &cli_sai_stp_get_port_state_cmd);
	install_element(cli_tree_mode, &cli_sai_stp_attr_get_vlans_cmd);
    install_element(cli_tree_mode, &cli_sai_stp_show_cmd);
    
    return CLI_SUCCESS;
}

int32
test_stp_create(uint32 vlan1, uint32 vlan2, uint32 vlan3)
{
    sai_vlan_id_t vlan_list[4096];
    sai_attribute_t attr[1];
    sai_stp_api_t *stp_api = NULL;
    sai_object_id_t stp_id = 0;
    uint32 attr_count = 0;
    uint32 i = 0;

    /* 1. query SAI API */
    (sai_api_query(SAI_API_STP, (void**)&stp_api));

    /* 2. convert thrift format to SAI format */
    attr[0].value.vlanlist.vlan_list = vlan_list;
    
    attr[0].id = SAI_STP_ATTR_VLAN_LIST;
    if (vlan1)
    {
        attr[0].value.vlanlist.vlan_list[i] = vlan1;
        i++;
    }
    if (vlan2)
    {
        attr[0].value.vlanlist.vlan_list[i] = vlan2;
        i++;
    }
    if (vlan3)
    {
        attr[0].value.vlanlist.vlan_list[i] = vlan3;
        i++;
    }
    attr[0].value.vlanlist.vlan_count = i;
    attr_count = 1;
    
    /* 4. call SAI API */
    if (stp_api)
    {
        (stp_api->create_stp(&stp_id, attr_count, attr));
    }
    else
    {
        stp_id = 10;
    }

    return 0;
}

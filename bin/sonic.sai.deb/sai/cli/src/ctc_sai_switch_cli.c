#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"

CTC_CLI(cli_sai_switch_initialize,
        cli_sai_switch_initialize_cmd,
        "switch initialize",
        "Switch",
        "SDK initialization")
{
    sai_status_t       ret          = SAI_STATUS_SUCCESS;
    sai_switch_api_t*  switch_api   = NULL;

    ret = sai_api_query(SAI_API_SWITCH,(void**)&switch_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = switch_api->initialize_switch(0,NULL,NULL,NULL);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_switch_lag_hash_algo,
        cli_sai_switch_lag_hash_algo_cmd,
        "switch set-attribute (lag-hash-algo (xor | crc | random))",
        "Switch",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        "Hash algorithm for all LAG in the switch (default to SAI_HASH_CRC)",
        "SAI_HASH_XOR",
        "SAI_HASH_CRC",
        "SAI_HASH_RANDOM")
{
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_switch_api_t*   switch_api  = NULL;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    attr.id = SAI_SWITCH_ATTR_LAG_DEFAULT_HASH_ALGORITHM;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("xor"))
    {
        attr.value.s32 = SAI_HASH_ALGORITHM_XOR;
    }
    else if(0xFF != CTC_CLI_GET_ARGC_INDEX("crc"))
    {
        attr.value.s32 = SAI_HASH_ALGORITHM_CRC;
    }
    else if(0xFF != CTC_CLI_GET_ARGC_INDEX("random"))
    {
        attr.value.s32 = SAI_HASH_RANDOM;
    }

    ret = sai_api_query(SAI_API_SWITCH,(void**)&switch_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = switch_api->set_switch_attribute(&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}



int32
ctc_sai_switch_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_switch_initialize_cmd);
    install_element(cli_tree_mode, &cli_sai_switch_lag_hash_algo_cmd);
    return CLI_SUCCESS;
}

#include <sai.h>
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_sai_cli.h"
#include "ctc_sai_vlan.h"
#include <ctc_sai_common.h>

#include "ctc_api.h"


CTC_CLI(cli_sai_vlan_create,
        cli_sai_vlan_create_cmd,
        "vlan create (vlan VLAN)",
        "Vlan",
        "Create a vlan",
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC)
{
    uint16_t         vlan_id = 0;
    sai_vlan_api_t*  vlan_api;
    sai_status_t     ret = SAI_STATUS_SUCCESS;

    CTC_CLI_GET_UINT16_RANGE("vlan-id", vlan_id, argv[0], 0, CTC_MAX_UINT16_VALUE);

    ret = sai_api_query(SAI_API_VLAN,(void**)&vlan_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vlan_api->create_vlan(vlan_id);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_vlan_remove,
        cli_sai_vlan_remove_cmd,
        "vlan remove (vlan VLAN)",
        "Vlan",
        "Remove a vlan",
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC)
{
    uint16_t         vlan_id = 0;
    sai_vlan_api_t*  vlan_api;
    sai_status_t     ret = SAI_STATUS_SUCCESS;

    CTC_CLI_GET_UINT16_RANGE("vlan-id", vlan_id, argv[0], 0, CTC_MAX_UINT16_VALUE);

    ret = sai_api_query(SAI_API_VLAN,(void**)&vlan_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vlan_api->remove_vlan(vlan_id);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_vlan_add_port,
        cli_sai_vlan_add_port_cmd,
        "vlan add ports (vlan VLAN) ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) (tagged|)",
        "Vlan",
        "Add",
        "Add Port to VLAN",
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Vlan tagged on this port")
{
    uint8              index = 0xFF;
    uint16_t         vlan_id = 0;
    uint32_t         port_id = 0;
    sai_vlan_port_t     vlan_port;
    sai_object_id_t     port_oid = 0;
    sai_vlan_api_t*  vlan_api;
    sai_status_t     ret = SAI_STATUS_SUCCESS;

    sal_memset(&vlan_port,0,sizeof(vlan_port));

    vlan_port.tagging_mode = SAI_VLAN_PORT_UNTAGGED;

    CTC_CLI_GET_UINT16_RANGE("src-port", port_id, argv[0], 0, CTC_MAX_UINT16_VALUE);
    CTC_CLI_GET_UINT16_RANGE("vlan-id",  vlan_id, argv[1], 0, CTC_MAX_UINT16_VALUE);

    port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,port_id);
    vlan_port.port_id = port_oid;

    index = CTC_CLI_GET_ARGC_INDEX("tagged");
    if (0xFF != index)
    {
        vlan_port.tagging_mode = SAI_VLAN_PORT_TAGGED;
    }

    ret = sai_api_query(SAI_API_VLAN,(void**)&vlan_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vlan_api->add_ports_to_vlan(vlan_id,1,&vlan_port);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_vlan_remove_port,
        cli_sai_vlan_remove_port_cmd,
        "vlan remove ports (vlan VLAN) ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID))",
        "Vlan",
        "Remove",
        "Remove Port from VLAN",
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Vlan tagged on this port")
{
    uint16_t         vlan_id = 0;
    uint32_t         port_id = 0;
    sai_vlan_port_t     vlan_port;
    sai_object_id_t     port_oid = 0;
    sai_vlan_api_t*  vlan_api;
    sai_status_t     ret = SAI_STATUS_SUCCESS;

    sal_memset(&vlan_port,0,sizeof(vlan_port));

    vlan_port.tagging_mode = SAI_VLAN_PORT_UNTAGGED;

    CTC_CLI_GET_UINT16_RANGE("src-port", port_id, argv[0], 0, CTC_MAX_UINT16_VALUE);
    CTC_CLI_GET_UINT16_RANGE("vlan-id",  vlan_id, argv[1], 0, CTC_MAX_UINT16_VALUE);

    port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,port_id);
    vlan_port.port_id = port_oid;

    ret = sai_api_query(SAI_API_VLAN,(void**)&vlan_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vlan_api->remove_ports_from_vlan(vlan_id,1,&vlan_port);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_vlan_remove_all,
        cli_sai_vlan_remove_all_cmd,
        "vlan remove all",
        "Vlan",
        "Remove",
        "Remove VLAN configuration (remove all VLANs).")
{
    sai_vlan_api_t*  vlan_api;
    sai_status_t     ret = SAI_STATUS_SUCCESS;

    ret = sai_api_query(SAI_API_VLAN,(void**)&vlan_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }


    ret = vlan_api->remove_all_vlans();
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_vlan_attr_set_stp,
        cli_sai_vlan_attr_set_stp_cmd,
        "vlan set-attribute (vlan VLAN) stp-instance (stp-id SAI_OBJ_ID)",
        "Vlan",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC,
        "STP Instance that the VLAN is associated to sai_object_id_t. (default to default stp instance id)",
        SAI_CLI_OBJ_STP_ID_DESC,
        SAI_CLI_OBJECT_VALUE)
{
    sai_vlan_api_t*      vlan_api;
    sai_object_id_t     stpid;
	sai_attribute_t     attr;
    uint16_t            vlan_id = 0;

    sai_status_t     ret = SAI_STATUS_SUCCESS;

	sal_memset(&attr, 0, sizeof(attr));

	CTC_CLI_GET_UINT16_RANGE("vlan-id",  vlan_id, argv[0], 0, CTC_MAX_UINT16_VALUE);

    CTC_CLI_GET_UINT16_RANGE("stp-id", stpid, argv[1], 0, CTC_MAX_UINT16_VALUE);
    stpid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_STP_INSTANCE,stpid);

    attr.id 		  = SAI_VLAN_ATTR_STP_INSTANCE;
    attr.value.oid    = stpid;

    ret = sai_api_query(SAI_API_VLAN,(void**)&vlan_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vlan_api->set_vlan_attribute(vlan_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_vlan_attr_get_stp,
        cli_sai_vlan_attr_get_stp_cmd,
        "vlan get-attribute (vlan VLAN) stp-instance",
        "Vlan",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC,
        "STP Instance that the VLAN is associated to sai_object_id_t. (default to default stp instance id)")
{
    sai_vlan_api_t*      vlan_api;
	sai_attribute_t     attr;
    uint16_t            vlan_id = 0;

    sai_status_t     ret = SAI_STATUS_SUCCESS;

	sal_memset(&attr, 0, sizeof(attr));

	CTC_CLI_GET_UINT16_RANGE("vlan-id",  vlan_id, argv[0], 0, CTC_MAX_UINT16_VALUE);

    attr.id 		  = SAI_VLAN_ATTR_STP_INSTANCE;

    ret = sai_api_query(SAI_API_VLAN,(void**)&vlan_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vlan_api->get_vlan_attribute(vlan_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:0x%-10llx\n","stp id",CTC_SAI_OBJECT_INDEX_GET(attr.value.oid));

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_vlan_attr_set_learnlimit,
        cli_sai_vlan_attr_set_learnlimit_cmd,
        "vlan set-attribute (vlan VLAN) (learned-addresses VALUE)",
        "Vlan",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC,
        "Maximum number of learned MAC addresses.(default to zero)",
        "<0-0x3FFFF>")
{
    sai_vlan_api_t*         vlan_api;
    uint32_t                limit_value;
    sai_attribute_t         attr;
    uint16_t                vlan_id = 0;

    sai_status_t     ret = SAI_STATUS_SUCCESS;

    sal_memset(&attr, 0, sizeof(attr));

    CTC_CLI_GET_UINT16_RANGE("vlan-id",  vlan_id, argv[0], 0, CTC_MAX_UINT16_VALUE);

    CTC_CLI_GET_UINT16_RANGE("limit-value", limit_value, argv[1], 0, CTC_MAX_UINT16_VALUE);

    attr.id             = SAI_VLAN_ATTR_MAX_LEARNED_ADDRESSES;
    attr.value.u32      = limit_value;

    ret = sai_api_query(SAI_API_VLAN,(void**)&vlan_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vlan_api->set_vlan_attribute(vlan_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_vlan_attr_get_learnlimit,
        cli_sai_vlan_attr_get_learnlimit_cmd,
        "vlan get-attribute (vlan VLAN) (learned-addresses)",
        "Vlan",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC,
        "Maximum number of learned MAC addresses.(default to zero)")
{
    sai_vlan_api_t*     vlan_api;
    sai_attribute_t     attr;
    uint16_t            vlan_id = 0;
    sai_status_t        ret     = SAI_STATUS_SUCCESS;

    sal_memset(&attr, 0, sizeof(attr));

    CTC_CLI_GET_UINT16_RANGE("vlan-id",  vlan_id, argv[0], 0, CTC_MAX_UINT16_VALUE);

    attr.id     = SAI_VLAN_ATTR_MAX_LEARNED_ADDRESSES;

    ret = sai_api_query(SAI_API_VLAN,(void**)&vlan_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vlan_api->get_vlan_attribute(vlan_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:%-10d\n","max learn limit",attr.value.u32);

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_vlan_attr_get_port_list,
        cli_sai_vlan_attr_get_port_list_cmd,
        "vlan get-attribute (vlan VLAN) port-list",
        "Vlan",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC,
        "port-list")
{
    sai_vlan_id_t           *p_vlan_id = NULL;
    sai_vlan_api_t*         vlan_api;
    sai_vlan_port_t         vlan_port;    
    sai_attribute_t         attr[2];
    uint16_t                vlan_id = 0;
    sai_status_t            ret     = SAI_STATUS_SUCCESS;
    uint32_t                i       = 0;

    sal_memset(attr, 0, sizeof(attr));
    sal_memset(&vlan_port, 0, sizeof(vlan_port));

    CTC_CLI_GET_UINT16_RANGE("vlan-id",  vlan_id, argv[0], 0, CTC_MAX_UINT16_VALUE);

    p_vlan_id = ctc_sai_vlan_get_vlan_id_global();    
    if (0 == p_vlan_id[vlan_id])
    {
        ctc_cli_out("%-10s%-10d: %-10s\n","VLAN", vlan_id, "not exist!");
        return CLI_SUCCESS;
    }
    
    attr[0].id = SAI_VLAN_ATTR_PORT_LIST;

    ret = sai_api_query(SAI_API_VLAN, (void**)&vlan_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vlan_api->get_vlan_attribute(vlan_id, 1, attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%s%d\nPort count: %d\n", "VLAN", vlan_id, attr[0].value.objlist.count);

    for(i = 0; i < attr[0].value.objlist.count; i++)
    {
        ctc_cli_out("%-10s %-10d ", "port-id:",attr[0].value.objlist.list[i]);
        if (0 == attr[1].value.u8list.list[i])
        {
            ctc_cli_out("UN-TAG\n");
        }
        else if (1 == attr[1].value.u8list.list[i])
        {
            ctc_cli_out("TAG\n");
        }
        else if (2 == attr[1].value.u8list.list[i])
        {
            ctc_cli_out("Priority-TAG\n");
        }
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_vlan_attr_set_learning_disable,
        cli_sai_vlan_attr_set_learning_disable_cmd,
        "vlan set-attribute (vlan VLAN) learn-disable",
        "vlan",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC, 
        "learn-disable")
{
    sai_vlan_id_t       *p_vlan_id  = NULL;    
    sai_vlan_api_t      *vlan_api   = NULL;
    sai_attribute_t     attr;
    uint16_t            vlan_id = 0;
    sai_status_t        ret     = SAI_STATUS_SUCCESS;

    sal_memset(&attr, 0, sizeof(attr));

    CTC_CLI_GET_UINT16_RANGE("vlan-id",  vlan_id, argv[0], 0, CTC_MAX_UINT16_VALUE);
    
    p_vlan_id = (sai_vlan_id_t*)ctc_sai_vlan_get_vlan_id_global();    
    if (0 == p_vlan_id[vlan_id])
    {
        ctc_cli_out("%-10s%-10d: %-10s\n","VLAN", vlan_id, "not exist!");
        return CLI_SUCCESS;
    }
    
    attr.id     = SAI_VLAN_ATTR_LEARN_DISABLE;

    ret = sai_api_query(SAI_API_VLAN,(void**)&vlan_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    
    attr.value.booldata = TRUE;
    
    ret = vlan_api->set_vlan_attribute(vlan_id, &attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_vlan_attr_get_learning_disable,
        cli_sai_vlan_attr_get_learning_disable_cmd,
        "vlan get-attribute (vlan VLAN) learn-disable",
        "vlan",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC,
        "learn-disable")
{
    sai_vlan_id_t       *p_vlan_id = NULL;
    sai_vlan_api_t*     vlan_api;
    sai_attribute_t     attr;
    uint16_t            vlan_id = 0;
    sai_status_t        ret     = SAI_STATUS_SUCCESS;

    sal_memset(&attr, 0, sizeof(attr));

    CTC_CLI_GET_UINT16_RANGE("vlan-id",  vlan_id, argv[0], 0, CTC_MAX_UINT16_VALUE);

    p_vlan_id = ctc_sai_vlan_get_vlan_id_global();

    if (0 == p_vlan_id[vlan_id])
    {
        ctc_cli_out("%-10s%-10d: %-10s\n","VLAN", vlan_id, "not exist!");
        return CLI_SUCCESS;
    }
        
    attr.id     = SAI_VLAN_ATTR_LEARN_DISABLE;

    ret = sai_api_query(SAI_API_VLAN,(void**)&vlan_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vlan_api->get_vlan_attribute(vlan_id, 1, &attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s%-10d\n","VLAN", vlan_id);

    if (FALSE == attr.value.booldata)
    {
        ctc_cli_out("learn enable\n");

    }
    else if (TRUE == attr.value.booldata)
    {
        ctc_cli_out("learn disable\n");
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_vlan_show_vlan,
        cli_sai_vlan_show_vlan_cmd,
        "show sai vlan (VLAN_ID|)",
        "show information",
        "SAI"
        "vlan",
        SAI_CLI_VLAN_RANGE_DESC)
{
    sai_vlan_id_t           *p_vlan_id = NULL;
    sai_vlan_api_t*         vlan_api;  
    sai_attribute_t         attr[3];
    uint16_t                vlan_id = 0;
    sai_status_t            ret     = SAI_STATUS_SUCCESS;
    uint32_t                i       = 0;

    sal_memset(attr, 0, sizeof(attr));

    p_vlan_id = ctc_sai_vlan_get_vlan_id_global(); 
    ret = sai_api_query(SAI_API_VLAN, (void**)&vlan_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    if(argc == 1)
    {

        CTC_CLI_GET_UINT16_RANGE("vlan-id",  vlan_id, argv[0], 0, CTC_MAX_UINT16_VALUE);

        if (0 == p_vlan_id[vlan_id])
        {
            ctc_cli_out("%-10s%-10d: %-10s\n","VLAN", vlan_id, "not exist!");
            return CLI_SUCCESS;
        }

        attr[0].id 		  = SAI_VLAN_ATTR_STP_INSTANCE;
        attr[1].id 		  = SAI_VLAN_ATTR_LEARN_DISABLE;
        attr[2].id 		  = SAI_VLAN_ATTR_MAX_LEARNED_ADDRESSES;
        
        ret = vlan_api->get_vlan_attribute(vlan_id, 3, attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
        ctc_cli_out("%s%d\n","VLAN",vlan_id);

        ctc_cli_out("%-10s:0x%-10llx\n","stp id",CTC_SAI_OBJECT_INDEX_GET(attr[0].value.oid));
        
        if (FALSE == attr[1].value.booldata)
        {
            ctc_cli_out("learn enable\n");

        }
        else if (TRUE == attr[1].value.booldata)
        {
            ctc_cli_out("learn disable\n");
        }
        
        ctc_cli_out("%-10s:%-10d\n","max learn limit",attr[2].value.u32);

        sal_memset(attr, 0, sizeof(attr));
        attr[0].id 		  = SAI_VLAN_ATTR_PORT_LIST;
        
        ret = vlan_api->get_vlan_attribute(vlan_id, 1, attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        ctc_cli_out("Port count: %d\n", attr[0].value.objlist.count);
        for(i = 0; i < attr[1].value.objlist.count; i++)
        {
            ctc_cli_out("%-10s %-10d ", "port-id:",attr[0].value.objlist.list[i]);
            if (0 == attr[1].value.u8list.list[i])
            {
                ctc_cli_out("UN-TAG\n");
            }
            else if (1 == attr[1].value.u8list.list[i])
            {
                ctc_cli_out("TAG\n");
            }
            else if (2 == attr[1].value.u8list.list[i])
            {
                ctc_cli_out("Priority-TAG\n");
            }
        }

    }
    else
    {
        for (vlan_id = 1; 0 != p_vlan_id[vlan_id] && vlan_id < 4096; vlan_id++)
        {
            attr[0].id 		  = SAI_VLAN_ATTR_STP_INSTANCE;
            attr[1].id 		  = SAI_VLAN_ATTR_LEARN_DISABLE;
            attr[2].id 		  = SAI_VLAN_ATTR_MAX_LEARNED_ADDRESSES;
            
            ret = vlan_api->get_vlan_attribute(vlan_id, 3, attr);
            if(SAI_STATUS_SUCCESS != ret)
            {
                ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
                return CLI_SUCCESS;
            }
            ctc_cli_out("%s%d\n","VLAN",vlan_id);

            ctc_cli_out("%-10s:0x%-10llx\n","stp id",CTC_SAI_OBJECT_INDEX_GET(attr[0].value.oid));
            
            if (FALSE == attr[1].value.booldata)
            {
                ctc_cli_out("learn enable\n");

            }
            else if (TRUE == attr[1].value.booldata)
            {
                ctc_cli_out("learn disable\n");
            }
            
            ctc_cli_out("%-10s:%-10d\n","max learn limit",attr[2].value.u32);

            sal_memset(attr, 0, sizeof(attr));
            attr[0].id 		  = SAI_VLAN_ATTR_PORT_LIST;
            
            ret = vlan_api->get_vlan_attribute(vlan_id, 1, attr);
            if(SAI_STATUS_SUCCESS != ret)
            {
                ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
                return CLI_SUCCESS;
            }

            ctc_cli_out("Port count: %d\n", attr[0].value.objlist.count);
            for(i = 0; i < attr[1].value.objlist.count; i++)
            {
                ctc_cli_out("%-10s %-10d ", "port-id:",attr[0].value.objlist.list[i]);
                if (0 == attr[1].value.u8list.list[i])
                {
                    ctc_cli_out("UN-TAG\n");
                }
                else if (1 == attr[1].value.u8list.list[i])
                {
                    ctc_cli_out("TAG\n");
                }
                else if (2 == attr[1].value.u8list.list[i])
                {
                    ctc_cli_out("Priority-TAG\n");
                }
            }
        }
    }

    return CLI_SUCCESS;
}

int32
ctc_sai_vlan_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_vlan_create_cmd);
    install_element(cli_tree_mode, &cli_sai_vlan_remove_cmd);
    install_element(cli_tree_mode, &cli_sai_vlan_add_port_cmd);
    install_element(cli_tree_mode, &cli_sai_vlan_remove_port_cmd);
    install_element(cli_tree_mode, &cli_sai_vlan_remove_all_cmd);
    install_element(cli_tree_mode, &cli_sai_vlan_attr_set_stp_cmd);
    install_element(cli_tree_mode, &cli_sai_vlan_attr_get_stp_cmd);
    install_element(cli_tree_mode, &cli_sai_vlan_attr_set_learnlimit_cmd);
    install_element(cli_tree_mode, &cli_sai_vlan_attr_get_learnlimit_cmd);
    install_element(cli_tree_mode, &cli_sai_vlan_attr_get_port_list_cmd);
    install_element(cli_tree_mode, &cli_sai_vlan_attr_set_learning_disable_cmd);
    install_element(cli_tree_mode, &cli_sai_vlan_attr_get_learning_disable_cmd);
    install_element(cli_tree_mode, &cli_sai_vlan_show_vlan_cmd);

    return CLI_SUCCESS;
}

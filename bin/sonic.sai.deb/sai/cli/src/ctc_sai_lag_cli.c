#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include <ctc_sai_common.h>

CTC_CLI(cli_sai_lag_create,
        cli_sai_lag_create_cmd,
        "lag create lag",
        "lag",
        "Create LAG")
{
    sai_lag_api_t*   lag_api = NULL;
    sai_object_id_t  lagid = 0;
    sai_status_t     ret = SAI_STATUS_SUCCESS;
    ret = sai_api_query(SAI_API_LAG,(void**)&lag_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = lag_api->create_lag(&lagid, 0, NULL);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:%u\n", "lag_ID", CTC_SAI_OBJECT_INDEX_GET(lagid));
    
    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_lag_remove,
        cli_sai_lag_remove_cmd,
        "lag remove (lag-id SAI_OBJ_ID)",
        "Lag",
        "Remove LAG",
		SAI_CLI_OBJ_LAG_ID_DESC,
		SAI_CLI_OBJECT_VALUE)
{
    sai_lag_api_t*   		lag_api 	= NULL;
	sai_object_id_t  		lag_id = 0;
    sai_status_t     		ret 	 	= SAI_STATUS_SUCCESS;

	SAI_CLI_GET_LAG_ID(lag_id);

    ret = sai_api_query(SAI_API_LAG,(void**)&lag_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = lag_api->remove_lag(lag_id);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_lagmember_create,
        cli_sai_lagmember_create_cmd,
        "lag create lagmember (lag-id SAI_OBJ_ID) (port-id SAI_OBJ_ID)",
        "Lag",
        "Create",
        "Lagmember",
		SAI_CLI_OBJ_LAG_ID_DESC,
		SAI_CLI_OBJECT_VALUE,
		SAI_CLI_OBJ_PORT_ID_DESC,
		SAI_CLI_OBJECT_VALUE)
{
    sai_lag_api_t*   lag_api = NULL;
    sai_object_id_t  lag_id = 0;;
    sai_object_id_t  port_id = 0;
    sai_object_id_t  lagmember = 0;
    sai_attribute_t  attr[2];
    sai_status_t     ret = SAI_STATUS_SUCCESS;

	SAI_CLI_GET_LAG_ID(lag_id);
	SAI_CLI_GET_PORT_ID(port_id);

    ret = sai_api_query(SAI_API_LAG,(void**)&lag_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    attr[0].id = SAI_LAG_MEMBER_ATTR_LAG_ID;
    attr[0].value.oid = lag_id;
    attr[1].id = SAI_LAG_MEMBER_ATTR_PORT_ID;
    attr[1].value.oid = port_id;
    ret = lag_api->create_lag_member(&lagmember, 2, (sai_attribute_t *)&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:0x%-10llx\n","lagmember_id", CTC_SAI_OBJECT_INDEX_GET(lagmember));

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_lagmember_remove,
        cli_sai_lagmember_remove_cmd,
        "lag remove lagmember LAGMEMBER_ID",
        "lag",
        "Remove LAG",
        "LAGID")
{
    uint32             lagmember_id = 0;
    sai_lag_api_t*     lag_api = NULL;
    sai_object_id_t    lagmember = 0;
    sai_status_t       ret   = SAI_STATUS_SUCCESS;
    
    CTC_CLI_GET_UINT16_RANGE("lagmember-id", lagmember_id, argv[0], 0, CTC_MAX_UINT16_VALUE);
    lagmember = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_LAG_MEMBER,lagmember_id);

    ret = sai_api_query(SAI_API_LAG,(void**)&lag_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = lag_api->remove_lag_member(lagmember);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}
CTC_CLI(cli_sai_lagmember_get,
        cli_sai_lagmember_get_cmd,
        "lag get-attribute lagmember LAGMEMBER_ID (lag|port)",
        "lag",
        "get attribute",
        "lagmember",
        "LAGMEMBER_ID",
        "lag or port id")
{
    uint32             lagmember_id = 0;
    sai_object_id_t    lagmember = 0;
    sai_lag_api_t*     lag_api = NULL;
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    sai_attribute_t    attr;
   
    CTC_CLI_GET_UINT16_RANGE("lagmember-id", lagmember_id, argv[0], 0, CTC_MAX_UINT16_VALUE);
    lagmember = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_LAG_MEMBER, lagmember_id);
  
    if (0 == sal_strcmp(argv[1], "lag"))
    {
         attr.id= SAI_LAG_MEMBER_ATTR_LAG_ID;
    }
    else if (0 == sal_strcmp(argv[1], "port"))
    {
         attr.id = SAI_LAG_MEMBER_ATTR_PORT_ID;
    }
    ret = sai_api_query(SAI_API_LAG,(void**)&lag_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = lag_api->get_lag_member_attribute(lagmember, 1, &attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    
    switch(attr.id)
    {
    case SAI_LAG_MEMBER_ATTR_LAG_ID:
        ctc_cli_out("%-10s:%u\n", "lag_ID", CTC_SAI_OBJECT_INDEX_GET(attr.value.oid));
        break;
        
    case SAI_LAG_MEMBER_ATTR_PORT_ID:
        ctc_cli_out("%-10s:%u\n", "port_ID", CTC_SAI_OBJECT_INDEX_GET(attr.value.oid));
        break;
        
    default:
        break;
    }
    return CLI_SUCCESS;
}
CTC_CLI(cli_sai_lag_attr_get_ports,
        cli_sai_lag_attr_get_ports_cmd,
        "lag get-attribute lag LAGID ports",
        "lag",
        "get attribute",
        "lag",
        "lag object id",
        "ports")
{
       sai_lag_api_t*   			lag_api			= NULL;
	sai_object_id_t  			lagid;
	sai_object_list_t 			portlist;
	sai_attribute_t				attr;
	uint32_t					port_idx 	    = 0;
       sai_status_t     			ret 	 		= SAI_STATUS_SUCCESS;

	sal_memset(&attr,0,sizeof(sai_attribute_t));

	CTC_CLI_GET_UINT16_RANGE("lag-id", lagid, argv[0], 0, CTC_MAX_UINT16_VALUE);
       lagid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_LAG,lagid);

	attr.id = SAI_LAG_ATTR_PORT_LIST;

	portlist.list = mem_malloc(MEM_APP_LINKAGG_MODULE,sizeof(sai_object_id_t) * 256);
	if(!portlist.list)
	{
		ret = SAI_STATUS_NO_MEMORY;
		ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
		return CLI_SUCCESS;
	}

	sal_memset(portlist.list,0,sizeof(sai_object_id_t) * 256);
	portlist.count 		= 256;
	attr.value.objlist  = portlist;

    ret = sai_api_query(SAI_API_LAG,(void**)&lag_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
		mem_free(portlist.list);
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = lag_api->get_lag_attribute(lagid,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
		mem_free(portlist.list);
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

	ctc_cli_out("%-10s:","ports");
	for(port_idx = 0; port_idx < attr.value.objlist.count; port_idx++)
	{
		if(port_idx % 16 == 0)
		{
			ctc_cli_out("\n%-10s:"," ");
		}
		ctc_cli_out("%-6d,",attr.value.objlist.list[port_idx]);
	}
	ctc_cli_out("\n");

	mem_free(portlist.list);
    return CLI_SUCCESS;
}

int32
ctc_sai_lag_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_lag_create_cmd);
	install_element(cli_tree_mode, &cli_sai_lag_remove_cmd);
	install_element(cli_tree_mode, &cli_sai_lagmember_create_cmd);
	install_element(cli_tree_mode, &cli_sai_lagmember_remove_cmd);
    install_element(cli_tree_mode, &cli_sai_lagmember_get_cmd);
	install_element(cli_tree_mode, &cli_sai_lag_attr_get_ports_cmd);

    return CLI_SUCCESS;
}

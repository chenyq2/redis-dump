#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include "ctc_const.h"
#include <saineighbor.h>
#include <ctc_sai_common.h>

CTC_CLI(cli_sai_nexthop_group_create,
        cli_sai_nexthop_group_create_cmd,
        "nexthop group create set-attribute (type ecmp) next-hop-list (next-hop-id SAI_OBJ_ID)",
        "Nexthop",
		"Group",
        "Create next hop group",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        "Next hop group type",
        "Next hop group is ECMP",
        "Next hop list",
        SAI_CLI_OBJ_NEXTHOP_ID_DESC,
        SAI_CLI_OBJECT_VALUE)
{
	sai_next_hop_group_api_t	*nhg_api    = NULL;
	sai_object_id_t     		nhg_id;
    sai_object_id_t     		nh_id;
	sai_attribute_t     		attr[3];
	sai_object_list_t			obj_list;
    sai_status_t     			ret = SAI_STATUS_SUCCESS;

	sal_memset(attr, 0, sizeof(attr));
	sal_memset(&obj_list,0,sizeof(sai_object_list_t));

	obj_list.count = 1;
	obj_list.list  = &nh_id;

    SAI_CLI_GET_NEXTHOP_ID(nh_id);

	attr[0].id 		  = SAI_NEXT_HOP_GROUP_ATTR_TYPE;
    attr[0].value.s32 = SAI_NEXT_HOP_GROUP_ECMP;

    attr[1].id 		  = SAI_NEXT_HOP_GROUP_ATTR_NEXT_HOP_LIST;
	attr[1].value.objlist = obj_list;

    ret = sai_api_query(SAI_API_NEXT_HOP_GROUP,(void**)&nhg_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nhg_api->create_next_hop_group(&nhg_id,2,attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%llx\n","next-hop-group-id",CTC_SAI_OBJECT_INDEX_GET(nhg_id));

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_nexthop_group_remove,
        cli_sai_nexthop_group_remove_cmd,
        "nexthop group remove (next-hop-group-id SAI_OBJ_ID)",
        "Nexthop",
		"Group",
        "Remove next hop group",
        SAI_CLI_OBJ_NEXTHOP_GROUP_ID_DESC,
        SAI_CLI_OBJECT_VALUE)
{
	sai_next_hop_group_api_t	*nhg_api    = NULL;
    sai_object_id_t     		nhg_id      = 0;
    sai_status_t     			ret         = SAI_STATUS_SUCCESS;

    SAI_CLI_GET_NEXTHOP_GROUP_ID(nhg_id);

    ret = sai_api_query(SAI_API_NEXT_HOP_GROUP,(void**)&nhg_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nhg_api->remove_next_hop_group(nhg_id);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_nexthop_group_attribute_get_type,
        cli_sai_nexthop_group_attribute_get_type_cmd,
        "nexthop group get-attribute (next-hop-group-id SAI_OBJ_ID) type",
        "Nexthop",
        "Group",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_NEXTHOP_GROUP_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Next hop group entry type")
{
    sai_next_hop_group_api_t	*nhg_api    = NULL;
    sai_object_id_t     		nhg_id      = 0;
    sai_status_t     			ret         = SAI_STATUS_SUCCESS;
    sai_attribute_t     		attr;
    const char*             	sz_nexthop_type[] = {"SAI_NEXT_HOP_GROUP_ECMP"};

	sal_memset(&attr, 0, sizeof(sai_attribute_t));

	attr.id 		  = SAI_NEXT_HOP_GROUP_ATTR_TYPE;

    SAI_CLI_GET_NEXTHOP_GROUP_ID(nhg_id);

    ret = sai_api_query(SAI_API_NEXT_HOP_GROUP,(void**)&nhg_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nhg_api->get_next_hop_group_attribute(nhg_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","type",sz_nexthop_type[attr.value.s32]);

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_nexthop_group_attribute_get_group_count,
        cli_sai_nexthop_group_attribute_get_group_count_cmd,
        "nexthop group get-attribute (next-hop-group-id SAI_OBJ_ID) next-hop-count",
        "Nexthop",
        "Group",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_NEXTHOP_GROUP_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Number of next hops in the group")
{
    sai_next_hop_group_api_t	*nhg_api    = NULL;
    sai_object_id_t     		nhg_id      = 0;
    sai_status_t     			ret         = SAI_STATUS_SUCCESS;
    sai_attribute_t     		attr;

	sal_memset(&attr, 0, sizeof(sai_attribute_t));

	attr.id 		  = SAI_NEXT_HOP_GROUP_ATTR_NEXT_HOP_COUNT;

    SAI_CLI_GET_NEXTHOP_GROUP_ID(nhg_id);

    ret = sai_api_query(SAI_API_NEXT_HOP_GROUP,(void**)&nhg_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nhg_api->get_next_hop_group_attribute(nhg_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10d\n","next-hop-count",attr.value.s32);

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_nexthop_group_attribute_get_nexthop_list,
        cli_sai_nexthop_group_attribute_get_nexthop_list_cmd,
        "nexthop group get-attribute (next-hop-group-id SAI_OBJ_ID) next-hop-list",
        "Nexthop",
        "Group",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_NEXTHOP_GROUP_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Next hop list")
{
    sai_next_hop_group_api_t	*nhg_api    = NULL;
    sai_object_id_t     		nhg_id      = 0;
    sai_status_t     			ret         = SAI_STATUS_SUCCESS;
    sai_attribute_t     		attr;
	uint32_t					i           = 0;

	sal_memset(&attr, 0, sizeof(sai_attribute_t));

	attr.id 		  = SAI_NEXT_HOP_GROUP_ATTR_NEXT_HOP_LIST;

    SAI_CLI_GET_NEXTHOP_GROUP_ID(nhg_id);

    ret = sai_api_query(SAI_API_NEXT_HOP_GROUP,(void**)&nhg_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nhg_api->get_next_hop_group_attribute(nhg_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

	for(i = 0; i < attr.value.objlist.count; i++)
	{
		ctc_cli_out("%-10s:%llx\n","next-hop-id",attr.value.objlist.list[i]);
	}

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_nexthop_group_add_nexthop,
        cli_sai_nexthop_group_add_nexthop_cmd,
        "nexthop group add (next-hop-group-id SAI_OBJ_ID) (next-hop-id SAI_OBJ_ID)",
        "Nexthop",
        "Group",
        "Add next hop to a group",
        SAI_CLI_OBJ_NEXTHOP_GROUP_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_NEXTHOP_ID_DESC,
        SAI_CLI_OBJECT_VALUE)
{
	sai_next_hop_group_api_t	*nhg_api    = NULL;
	sai_object_id_t     		nhg_id      = 0;
    sai_object_id_t     		nh_id       = 0;
    sai_status_t     			ret         = SAI_STATUS_SUCCESS;

    SAI_CLI_GET_NEXTHOP_GROUP_ID(nhg_id);

    SAI_CLI_GET_NEXTHOP_ID(nh_id);

    ret = sai_api_query(SAI_API_NEXT_HOP_GROUP,(void**)&nhg_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nhg_api->add_next_hop_to_group(nhg_id,1,&nh_id);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_nexthop_group_remove_nexthop,
        cli_sai_nexthop_group_remove_nexthop_cmd,
        "nexthop group remove (next-hop-group-id SAI_OBJ_ID) (next-hop-id SAI_OBJ_ID)",
        "Nexthop",
        "Group",
        "Remove next hop from a group",
        SAI_CLI_OBJ_NEXTHOP_GROUP_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_NEXTHOP_ID_DESC,
        SAI_CLI_OBJECT_VALUE)
{
	sai_next_hop_group_api_t	*nhg_api;
	sai_object_id_t     		nhg_id = 0;
    sai_object_id_t     		nh_id;
    sai_status_t     			ret = SAI_STATUS_SUCCESS;

    SAI_CLI_GET_NEXTHOP_GROUP_ID(nhg_id);

    SAI_CLI_GET_NEXTHOP_ID(nh_id);

    ret = sai_api_query(SAI_API_NEXT_HOP_GROUP,(void**)&nhg_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nhg_api->remove_next_hop_from_group(nhg_id,1,&nh_id);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}


int32
ctc_sai_nexthop_group_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_nexthop_group_create_cmd);
	install_element(cli_tree_mode, &cli_sai_nexthop_group_remove_cmd);
    install_element(cli_tree_mode, &cli_sai_nexthop_group_attribute_get_type_cmd);
	install_element(cli_tree_mode, &cli_sai_nexthop_group_attribute_get_group_count_cmd);
    install_element(cli_tree_mode, &cli_sai_nexthop_group_attribute_get_nexthop_list_cmd);
    install_element(cli_tree_mode, &cli_sai_nexthop_group_add_nexthop_cmd);
    install_element(cli_tree_mode, &cli_sai_nexthop_group_remove_nexthop_cmd);

    return CLI_SUCCESS;
}

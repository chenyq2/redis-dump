#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include "ctc_const.h"
#include "ctc_sai_wred.h"
#include <ctc_sai_common.h>
#include "ctc_cli_common.h"
#include "../../ptf_agent/ptf_agent.h"

static int32 ptf_server_port = 0;
static sal_task_t* g_ptf_agent_task = NULL;

extern void
log_sys(int eModule, int eSeverity, const char *fmt, ...);

uint32 g_ptf_debug_enable = FALSE;

int32
sai_hadler_out_syslog(const char* fmt, ...)
{
    char log_buf[1024];
    va_list ap;

    if (!g_ptf_debug_enable)
    {
        return 0;
    }

    va_start(ap, fmt);
    vsnprintf(log_buf, 1023, fmt, ap);
    va_end(ap);

    log_sys(1, 3, log_buf);

    return 0;
}

extern void
ptf_agent_init(void* user_param);
extern void
ptf_agent_deinit();

int32
ptf_agent_enable(int32 port)
{
#ifndef _GLB_UML_SYSTEM_
    sai_set_out_func(sai_hadler_out_syslog);

    if (0 == ptf_server_port)
    {
        ptf_agent_set_default();
        ptf_server_port = port;
        if (0 != sal_task_create(&g_ptf_agent_task,
                                 "ptfAgent",
                                 1024 * 1024, SAL_TASK_PRIO_DEF, ptf_agent_init, &ptf_server_port))
        {
            sal_task_destroy(g_ptf_agent_task);
            g_ptf_agent_task = NULL;
            return SAI_STATUS_FAILURE;
        }
    }
#endif /*!_GLB_UML_SYSTEM_*/
    return SAI_STATUS_SUCCESS;
}

int32
ptf_agent_disable()
{
    if (g_ptf_agent_task)
    {
        sal_task_destroy(g_ptf_agent_task);
    }
    
    g_ptf_agent_task = NULL;
    return SAI_STATUS_SUCCESS;
}

CTC_CLI(cli_sai_ptf_enable,
        cli_sai_ptf_enable_cmd,
        "ptf enable port <0-65535>",
        "Python Test Framework",
        "Enable",
        "PTF server port",
        "Port number")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    int32 port = 0;
    
    CTC_CLI_GET_UINT32_RANGE("port", port, argv[0], 0, 65535);
    
    ret = ptf_agent_enable(port);
    
    return ret;
}

CTC_CLI(cli_sai_ptf_disable,
        cli_sai_ptf_disable_cmd,
        "ptf disable",
        "Python Test Framework",
        "Disable")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;

    ret = ptf_agent_disable();
    
    return ret;
}

CTC_CLI(cli_sai_ptf_show,
        cli_sai_ptf_show_cmd,
        "show ptf",
        "Show"
        "Python Test Framework")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;

    if (g_ptf_agent_task)
    {
        ctc_cli_out("PTF agent is running at port %u\n", ptf_server_port);
    }
    else
    {
        ctc_cli_out("PTF agent is not running\n");
    }
    
    return ret;
}

int32
ctc_sai_ptf_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_ptf_enable_cmd);
    install_element(cli_tree_mode, &cli_sai_ptf_disable_cmd);
    install_element(cli_tree_mode, &cli_sai_ptf_show_cmd);

    return CLI_SUCCESS;
}

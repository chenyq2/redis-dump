#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include "ctc_const.h"
#include <saineighbor.h>
#include <ctc_sai_common.h>

CTC_CLI(cli_sai_nexthop_create,
        cli_sai_nexthop_create_cmd,
        "nexthop create set-attribute (type next-hop-ip) (ip ((ipv4 A.B.C.D) | (ipv6 X:X::X:X))) "
        "(router-interface-id SAI_OBJ_ID) ",
        "Nexthop",
        "Create next hop",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        "Next hop entry type",
        "SAI_NEXT_HOP_IP",
        "Next hop entry ipv4 address",
        SAI_CLI_IPV4_DESC,
        SAI_CLI_IPV4_FORMAT,
        SAI_CLI_IPV6_DESC,
        SAI_CLI_IPV6_FORMAT,
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE)
{
	sai_next_hop_api_t		*nh_api = NULL;
    sai_object_id_t     	intf_id = 0;
    sai_object_id_t     	nh_id   = 0;
	sai_attribute_t     	attr[3];
    sai_status_t     		ret     = SAI_STATUS_SUCCESS;

	sal_memset(attr, 0, sizeof(attr));

    SAI_CLI_GET_ROUTER_INTERFACE_ID(intf_id);

	attr[0].id 		  = SAI_NEXT_HOP_ATTR_TYPE;
    attr[0].value.s32 = SAI_NEXT_HOP_IP;

    attr[2].id 		  = SAI_NEXT_HOP_ATTR_ROUTER_INTERFACE_ID;
	attr[2].value.oid = intf_id;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("next-hop-ip"))
    {
        attr[1].id 		                    = SAI_NEXT_HOP_ATTR_IP;
        SAI_CLI_GET_SAI_IP_ADDRESS_T(&attr[1].value.ipaddr);
    }

    ret = sai_api_query(SAI_API_NEXT_HOP,(void**)&nh_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nh_api->create_next_hop(&nh_id,3,attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%llx\n","next-hop-id",CTC_SAI_OBJECT_INDEX_GET(nh_id));

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_nexthop_remove,
        cli_sai_nexthop_remove_cmd,
        "nexthop remove (next-hop-id SAI_OBJ_ID)",
        "Nexthop",
        "Remove next hop",
        SAI_CLI_OBJ_NEXTHOP_ID_DESC,
        SAI_CLI_OBJECT_VALUE)
{
	sai_next_hop_api_t		*nh_api = NULL;
    sai_object_id_t     	nh_id   = 0;
    sai_status_t     		ret     = SAI_STATUS_SUCCESS;

    SAI_CLI_GET_NEXTHOP_ID(nh_id);

    ret = sai_api_query(SAI_API_NEXT_HOP,(void**)&nh_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nh_api->remove_next_hop(nh_id);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_nexthop_attribute_get_type,
        cli_sai_nexthop_attribute_get_type_cmd,
        "nexthop get-attribute (next-hop-id SAI_OBJ_ID) type",
        "Nexthop",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_NEXTHOP_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Next hop entry type")
{
    sai_next_hop_api_t		*nh_api = NULL;
    sai_object_id_t     	nh_id   = 0;
    sai_status_t     		ret     = SAI_STATUS_SUCCESS;
    sai_attribute_t     	attr;
    const char*             sz_nexthop_type[] = {"SAI_NEXT_HOP_IP"};

	sal_memset(&attr, 0, sizeof(sai_attribute_t));

	attr.id 		  = SAI_NEXT_HOP_ATTR_TYPE;

    SAI_CLI_GET_NEXTHOP_ID(nh_id);

    ret = sai_api_query(SAI_API_NEXT_HOP,(void**)&nh_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nh_api->get_next_hop_attribute(nh_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","type",sz_nexthop_type[attr.value.s32]);

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_nexthop_attribute_get_ip,
        cli_sai_nexthop_attribute_get_ip_cmd,
        "nexthop get-attribute (next-hop-id SAI_OBJ_ID) ip",
        "Nexthop",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_NEXTHOP_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Next hop entry ipv4 address")
{
    sai_next_hop_api_t		*nh_api = NULL;
    sai_object_id_t     	nh_id   = 0;
    sai_status_t     		ret     = SAI_STATUS_SUCCESS;
    sai_attribute_t     	attr;
    char                    buf[CTC_IPV6_ADDR_STR_LEN] = "";

	sal_memset(&attr, 0, sizeof(sai_attribute_t));

	attr.id 		  = SAI_NEXT_HOP_ATTR_IP;

    SAI_CLI_GET_NEXTHOP_ID(nh_id);

    ret = sai_api_query(SAI_API_NEXT_HOP,(void**)&nh_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nh_api->get_next_hop_attribute(nh_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    if(SAI_IP_ADDR_FAMILY_IPV4 == attr.value.ipaddr.addr_family)
    {
        uint32_t tempip = sal_ntohl(attr.value.ipaddr.addr.ip4);
        sal_inet_ntop(AF_INET, &tempip, buf, CTC_IPV6_ADDR_STR_LEN);
        ctc_cli_out("%-20s:%-10s\n","ipv4",buf);
    }else{
        sal_inet_ntop(AF_INET6, attr.value.ipaddr.addr.ip6, buf, CTC_IPV6_ADDR_STR_LEN);
        ctc_cli_out("%-20s:%-10s\n","ipv6",buf);
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_nexthop_attribute_get_router_intf,
        cli_sai_nexthop_attribute_get_router_intf_cmd,
        "nexthop get-attribute (next-hop-id SAI_OBJ_ID) router-interface-id",
        "Nexthop",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_NEXTHOP_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Next hop entry router interface id")
{
    sai_next_hop_api_t		*nh_api = NULL;
    sai_object_id_t     	nh_id   = 0;
    sai_status_t     		ret     = SAI_STATUS_SUCCESS;
    sai_attribute_t     	attr;

	sal_memset(&attr, 0, sizeof(sai_attribute_t));

	attr.id 		  = SAI_NEXT_HOP_ATTR_ROUTER_INTERFACE_ID;

    SAI_CLI_GET_NEXTHOP_ID(nh_id);

    ret = sai_api_query(SAI_API_NEXT_HOP,(void**)&nh_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nh_api->get_next_hop_attribute(nh_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%llx\n","router-interface-id",CTC_SAI_OBJECT_INDEX_GET(attr.value.oid));

    return CLI_SUCCESS;
}

int32
ctc_sai_nexthop_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_nexthop_create_cmd);
	install_element(cli_tree_mode, &cli_sai_nexthop_remove_cmd);
    install_element(cli_tree_mode, &cli_sai_nexthop_attribute_get_type_cmd);
	install_element(cli_tree_mode, &cli_sai_nexthop_attribute_get_ip_cmd);
    install_element(cli_tree_mode, &cli_sai_nexthop_attribute_get_router_intf_cmd);

    return CLI_SUCCESS;
}

#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include <saineighbor.h>
#include <ctc_sai_common.h>

CTC_CLI(cli_sai_neighbor_create,
        cli_sai_neighbor_create_cmd,
        "neighbor create entry (router-interface-id SAI_OBJ_ID) "
        "(ip ((ipv4 A.B.C.D) | (ipv6 X:X::X:X))) set-attribute "
        "dst-mac-address (mac MAC) "
        "(packet-action (drop | forward | trap | log))",
        "Neighbor",
        "Create",
        "Neighbor entry",
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Ip address",
        SAI_CLI_IPV4_DESC,
        SAI_CLI_IPV4_FORMAT,
        SAI_CLI_IPV6_DESC,
        SAI_CLI_IPV6_FORMAT,
        SAI_CLI_SET_ATTRIBUTE_DESC,
        "Destination mac address for the neighbor",
        SAI_CLI_MAC_DESC,
        SAI_CLI_MAC_FORMAT,
        "L3 forwarding action for this neighbor",
        "Drop Packet",
        "Forward Packet",
        "Trap Packet to CPU",
        "Log (Trap + Forward) Packet")
{
	sai_neighbor_api_t		*nb_api;
	sai_neighbor_entry_t	nbentry;
	sai_attribute_t     	attr[2];
    sai_status_t     		ret = SAI_STATUS_SUCCESS;

	sal_memset(&nbentry,0,sizeof(nbentry));
	sal_memset(attr, 0, sizeof(attr));

    SAI_CLI_GET_ROUTER_INTERFACE_ID(nbentry.rif_id);
    SAI_CLI_GET_SAI_IP_ADDRESS_T(&nbentry.ip_address);

    attr[0].id = SAI_NEIGHBOR_ATTR_DST_MAC_ADDRESS;
    SAI_CLI_GET_MAC_ADDRESS(&attr[0].value.mac);

	attr[1].id = SAI_NEIGHBOR_ATTR_PACKET_ACTION;
    attr[1].value.s32 = SAI_PACKET_ACTION_DROP;

    SAI_CLI_GET_PACKET_ACTION(attr[1].value.s32);

    ret = sai_api_query(SAI_API_NEIGHBOR,(void**)&nb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nb_api->create_neighbor_entry(&nbentry,2,attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_neighbor_remove,
        cli_sai_neighbor_remove_cmd,
        "neighbor remove entry (router-interface-id SAI_OBJ_ID) "
        "(ip ((ipv4 A.B.C.D) | (ipv6 X:X::X:X)))",
        "neighbor",
        "Remove",
        "Neighbor entry"
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Ip address",
        SAI_CLI_IPV4_DESC,
        SAI_CLI_IPV4_FORMAT,
        SAI_CLI_IPV6_DESC,
        SAI_CLI_IPV6_FORMAT)
{
	sai_neighbor_api_t		*nb_api;
	sai_neighbor_entry_t	nbentry;
    sai_status_t     		ret = SAI_STATUS_SUCCESS;

	sal_memset(&nbentry,0,sizeof(nbentry));

    SAI_CLI_GET_ROUTER_INTERFACE_ID(nbentry.rif_id);

    SAI_CLI_GET_SAI_IP_ADDRESS_T(&nbentry.ip_address);

    ret = sai_api_query(SAI_API_NEIGHBOR,(void**)&nb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nb_api->remove_neighbor_entry(&nbentry);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_neighbor_remove_all,
        cli_sai_neighbor_remove_all_cmd,
        "neighbor remove entry all",
        "Neighbor",
        "Remove",
        "Neighbor entry",
        "Remove all neighbor entries")
{
    sai_neighbor_api_t      *nb_api;
    sai_status_t            ret = SAI_STATUS_SUCCESS;

    ret = sai_api_query(SAI_API_NEIGHBOR,(void**)&nb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nb_api->remove_all_neighbor_entries();
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_neighbor_attribute_set_mac,
        cli_sai_neighbor_attribute_set_mac_cmd,
        "neighbor set-attribute entry (router-interface-id SAI_OBJ_ID) "
        "(ip ((ipv4 A.B.C.D) | (ipv6 X:X::X:X))) "
        "dst-mac-address (mac MAC) ",
        "neighbor",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        "Neighbor entry",
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Ip address",
        SAI_CLI_IPV4_DESC,
        SAI_CLI_IPV4_FORMAT,
        SAI_CLI_IPV6_DESC,
        SAI_CLI_IPV6_FORMAT,
        "Destination mac address for the neighbor",
        SAI_CLI_MAC_DESC,
        SAI_CLI_MAC_FORMAT)
{
    sai_neighbor_api_t      *nb_api;
    sai_neighbor_entry_t    nbentry;
    sai_attribute_t         attr;
    sai_status_t            ret = SAI_STATUS_SUCCESS;

    sal_memset(&nbentry,0,sizeof(nbentry));
    sal_memset(&attr, 0, sizeof(attr));

    SAI_CLI_GET_ROUTER_INTERFACE_ID(nbentry.rif_id);

    SAI_CLI_GET_SAI_IP_ADDRESS_T(&nbentry.ip_address);

    attr.id = SAI_NEIGHBOR_ATTR_DST_MAC_ADDRESS;
    SAI_CLI_GET_MAC_ADDRESS(&attr.value.mac);

    ret = sai_api_query(SAI_API_NEIGHBOR,(void**)&nb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nb_api->set_neighbor_attribute(&nbentry,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_neighbor_attribute_get_mac,
        cli_sai_neighbor_attribute_get_mac_cmd,
        "neighbor get-attribute entry (router-interface-id SAI_OBJ_ID) "
        "(ip ((ipv4 A.B.C.D) | (ipv6 X:X::X:X))) "
        "dst-mac-address (mac MAC) ",
        "neighbor",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        "Neighbor entry",
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Ip address",
        SAI_CLI_IPV4_DESC,
        SAI_CLI_IPV4_FORMAT,
        SAI_CLI_IPV6_DESC,
        SAI_CLI_IPV6_FORMAT,
        "Destination mac address for the neighbor")
{
    sai_neighbor_api_t		*nb_api;
	sai_neighbor_entry_t	nbentry;
	sai_attribute_t     	attr;
    sai_status_t     		ret = SAI_STATUS_SUCCESS;

	sal_memset(&nbentry,0,sizeof(nbentry));
	sal_memset(&attr, 0, sizeof(attr));

    SAI_CLI_GET_ROUTER_INTERFACE_ID(nbentry.rif_id);

    SAI_CLI_GET_SAI_IP_ADDRESS_T(&nbentry.ip_address);

	attr.id = SAI_NEIGHBOR_ATTR_DST_MAC_ADDRESS;

    ret = sai_api_query(SAI_API_NEIGHBOR,(void**)&nb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nb_api->get_neighbor_attribute(&nbentry,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

	ctc_cli_out("%-20s:%02x:%02x:%02x:%02x:%02x:%02x\n",
        "dst-mac-address",
        attr.value.mac[0],
        attr.value.mac[1],
        attr.value.mac[2],
        attr.value.mac[3],
        attr.value.mac[4],
        attr.value.mac[5]);

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_neighbor_attribute_set_action,
        cli_sai_neighbor_attribute_set_action_cmd,
        "neighbor set-attribute entry (router-interface-id SAI_OBJ_ID) "
        "(ip ((ipv4 A.B.C.D) | (ipv6 X:X::X:X))) "
        "(packet-action (drop | forward | trap | log)) ",
        "neighbor",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        "Neighbor entry",
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Ip address",
        SAI_CLI_IPV4_DESC,
        SAI_CLI_IPV4_FORMAT,
        SAI_CLI_IPV6_DESC,
        SAI_CLI_IPV6_FORMAT,
        "L3 forwarding action for this neighbor",
        "Drop Packet",
        "Forward Packet",
        "Trap Packet to CPU",
        "Log (Trap + Forward) Packet")
{
    sai_neighbor_api_t      *nb_api;
    sai_neighbor_entry_t    nbentry;
    sai_attribute_t         attr;
    sai_status_t            ret = SAI_STATUS_SUCCESS;

    sal_memset(&nbentry,0,sizeof(nbentry));
    sal_memset(&attr, 0, sizeof(attr));

    SAI_CLI_GET_ROUTER_INTERFACE_ID(nbentry.rif_id);

    SAI_CLI_GET_SAI_IP_ADDRESS_T(&nbentry.ip_address);

    attr.id = SAI_NEIGHBOR_ATTR_PACKET_ACTION;
    SAI_CLI_GET_PACKET_ACTION(attr.value.s32);

    ret = sai_api_query(SAI_API_NEIGHBOR,(void**)&nb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nb_api->set_neighbor_attribute(&nbentry,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_neighbor_attribute_get_action,
        cli_sai_neighbor_attribute_get_action_cmd,
        "neighbor get-attribute entry (router-interface-id SAI_OBJ_ID) "
        "(ip ((ipv4 A.B.C.D) | (ipv6 X:X::X:X))) ",
        "neighbor",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        "Neighbor entry",
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Ip address",
        SAI_CLI_IPV4_DESC,
        SAI_CLI_IPV4_FORMAT,
        SAI_CLI_IPV6_DESC,
        SAI_CLI_IPV6_FORMAT,
        "L3 forwarding action for this neighbor")
{
    sai_neighbor_api_t      *nb_api;
    sai_neighbor_entry_t    nbentry;
    sai_attribute_t         attr;
    sai_status_t            ret = SAI_STATUS_SUCCESS;
    const char*             sz_action[] = {"Drop","Forward","Trap","Log"};

    sal_memset(&nbentry,0,sizeof(nbentry));
    sal_memset(&attr, 0, sizeof(attr));

    SAI_CLI_GET_ROUTER_INTERFACE_ID(nbentry.rif_id);

    SAI_CLI_GET_SAI_IP_ADDRESS_T(&nbentry.ip_address);

    attr.id = SAI_NEIGHBOR_ATTR_PACKET_ACTION;

    ret = sai_api_query(SAI_API_NEIGHBOR,(void**)&nb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = nb_api->get_neighbor_attribute(&nbentry,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","type",sz_action[attr.value.s32 % 4]);

    return CLI_SUCCESS;
}

int32
ctc_sai_neighbor_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_neighbor_create_cmd);
    install_element(cli_tree_mode, &cli_sai_neighbor_remove_cmd);
    install_element(cli_tree_mode, &cli_sai_neighbor_attribute_set_mac_cmd);
    install_element(cli_tree_mode, &cli_sai_neighbor_attribute_get_mac_cmd);
    install_element(cli_tree_mode, &cli_sai_neighbor_attribute_set_action_cmd);
    install_element(cli_tree_mode, &cli_sai_neighbor_attribute_get_action_cmd);
    install_element(cli_tree_mode, &cli_sai_neighbor_remove_all_cmd);

    return CLI_SUCCESS;
}

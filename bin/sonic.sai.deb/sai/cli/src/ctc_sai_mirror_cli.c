/**********************************************
*
*Header Files
*
**********************************************/

#include <sai.h>
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_sai_cli.h"
#include "ctc_sai_mirror.h"
#include <ctc_sai_common.h>

sai_object_id_t ctc_sai_multi_dest_mirror_session;
    
CTC_CLI(cli_sai_mirror_create,
        cli_sai_mirror_create_cmd,
        "mirror create type (local (dport PORT_ID|dlag LAG_ID)|remote vlan VLAN_ID dport PORT_ID|eremote)",
        "mirror",
        "Create one mirror session",
        "TYPE",
        "local mirror",
        "dest port",
        "",
        "dest lag",
        "",
        "remote mirror",
        "remote vlan",
        "<2-4094>",
        "dest port",
        "",
        "eremote mirror")
{
    uint8_t  type  = 0;
    uint32_t port_id = 0;
    uint16   vlan_id = 0;
    uint16_t lag_id = 0;
    sai_object_id_t port_oid = 0;
    sai_object_id_t lag_oid = 0;
    
    sai_status_t    ret = SAI_STATUS_SUCCESS;  
    uint32          session_id = 0;
    sai_object_id_t session_oid = 0;
    uint32_t        count = 0;
    sai_attribute_t attr[3];
    sai_mirror_api_t* mirror_api;
    sai_object_list_t  obj_list; 
    sai_object_id_t    port_sid[1];

    sal_memset(&mirror_api, 0, sizeof(mirror_api));
    sal_memset(&obj_list, 0, sizeof(obj_list));
    sal_memset(&attr, 0, sizeof(sai_attribute_t));
    
    if (0 == sal_strcmp(argv[0], "local"))
    {
        type = SAI_MIRROR_TYPE_LOCAL;
        if (0 == sal_strcmp(argv[1], "dport"))
        {
            CTC_CLI_GET_UINT16_RANGE("port-id", port_id, argv[2], 0, CTC_MAX_UINT16_VALUE);
            port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT, port_id);
            port_sid[0] = port_oid;
            obj_list.list = port_sid;
            obj_list.count = 1;
            attr[1].id = SAI_MIRROR_SESSION_ATTR_MONITOR_PORT;
            sal_memcpy(&attr[1].value.objlist, &obj_list, sizeof(sai_object_list_t));
        }
        else if (0 == sal_strcmp(argv[1], "dlag"))
        {
            CTC_CLI_GET_UINT16_RANGE("lag-id", lag_id, argv[2], 0, CTC_MAX_UINT16_VALUE);
            lag_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_LAG, lag_id);
            port_sid[0] = lag_oid;
            obj_list.list = port_sid;
            obj_list.count = 1;
            attr[1].id = SAI_MIRROR_SESSION_ATTR_MONITOR_PORT;
            sal_memcpy(&attr[1].value.objlist, &obj_list, sizeof(sai_object_list_t));
        }
        count = 2;
    }
    else if (0 == sal_strcmp(argv[0], "remote"))
    {
        type = SAI_MIRROR_TYPE_REMOTE;
        
        CTC_CLI_GET_UINT16_RANGE("vlan-id", vlan_id, argv[2], 0, CTC_MAX_UINT16_VALUE);
        attr[1].id = SAI_MIRROR_SESSION_ATTR_VLAN_ID;
        attr[1].value.s16 = vlan_id;
        
        CTC_CLI_GET_UINT16_RANGE("port-id", port_id, argv[4], 0, CTC_MAX_UINT16_VALUE);
        port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT, port_id);
        port_sid[0] = port_oid;
        obj_list.list = port_sid;
        obj_list.count = 1;
        attr[2].id = SAI_MIRROR_SESSION_ATTR_MONITOR_PORT;
        sal_memcpy(&attr[2].value.objlist, &obj_list, sizeof(sai_object_list_t));
        count = 3;
    }
    else if (0 == sal_strcmp(argv[0], "eremote"))
    {
        type = SAI_MIRROR_TYPE_ENHANCED_REMOTE;
        ctc_cli_out("%% Not support \n", argv[0]);
    }
    attr[0].id = SAI_MIRROR_SESSION_ATTR_TYPE;
    attr[0].value.s32 = type;
    
    ret = sai_api_query(SAI_API_MIRROR,(void**)&mirror_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = mirror_api->create_mirror_session(&session_oid, count, attr);  
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    session_id = CTC_SAI_OBJECT_INDEX_GET(session_oid);
    ctc_cli_out("session_id= %u \n", session_id);
    
    return CLI_SUCCESS;    
}

CTC_CLI(cli_sai_mirror_add_multi_dest,
        cli_sai_mirror_add_multi_dest_cmd,
        "mirror add multi-dest group dport PORT_ID",
        "mirror",
        "Add multi-dest session",
        "Multi-dest",
        "Group",
        "dest port",
        "")
{
    uint32_t port_id = 0;
    sai_object_id_t port_oid = 0;
    
    sai_status_t    ret = SAI_STATUS_SUCCESS;  
    uint32          session_id = 0;
    sai_object_id_t session_oid = 0;
    sai_attribute_t attr[3];
    sai_object_list_t  obj_list; 
    sai_object_id_t    port_sid[1];
    sai_mirror_api_t* mirror_api;
    
    sal_memset(&mirror_api, 0, sizeof(mirror_api));
    sal_memset(&obj_list, 0, sizeof(obj_list));
    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    ret = sai_api_query(SAI_API_MIRROR,(void**)&mirror_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    
    if (0 == ctc_sai_multi_dest_mirror_session)
    {
        attr[0].id = SAI_MIRROR_SESSION_ATTR_TYPE;
        attr[0].value.s32 = SAI_MIRROR_TYPE_LOCAL;

        CTC_CLI_GET_UINT16_RANGE("port-id", port_id, argv[0], 0, CTC_MAX_UINT16_VALUE);
        port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT, port_id);
        port_sid[0] = port_oid;
        obj_list.list = port_sid;
        obj_list.count = 1;
        attr[1].id = SAI_MIRROR_SESSION_ATTR_MONITOR_PORT;
        sal_memcpy(&attr[1].value.objlist, &obj_list, sizeof(sai_object_list_t));

        attr[2].id = SAI_MIRROR_SESSION_ATTR_MULTI_DEST_MEMBER_ADD;
        attr[2].value.booldata = TRUE;

        ret = mirror_api->create_mirror_session(&session_oid, 3, attr);  
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
        session_id = CTC_SAI_OBJECT_INDEX_GET(session_oid);
        ctc_cli_out("session_id= %u \n", session_id);
        ctc_sai_multi_dest_mirror_session = session_oid;
    }
    else
    {
        session_oid = ctc_sai_multi_dest_mirror_session;
        attr[0].id = SAI_MIRROR_SESSION_ATTR_MULTI_DEST_MEMBER_ADD;
        attr[0].value.booldata = TRUE;
        ret = mirror_api->set_mirror_session_attribute(session_oid, attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
        
        CTC_CLI_GET_UINT16_RANGE("port-id", port_id, argv[0], 0, CTC_MAX_UINT16_VALUE);
        port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT, port_id);
        port_sid[0] = port_oid;
        obj_list.list = port_sid;
        obj_list.count = 1;
        attr[0].id = SAI_MIRROR_SESSION_ATTR_MONITOR_PORT;
        sal_memcpy(&attr[0].value.objlist, &obj_list, sizeof(sai_object_list_t));
        ret = mirror_api->set_mirror_session_attribute(session_oid, attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
    }

    return CLI_SUCCESS;    
}

CTC_CLI(cli_sai_mirror_del_multi_dest,
        cli_sai_mirror_del_multi_dest_cmd,
        "mirror del multi-dest group dport PORT_ID",
        "mirror",
        "Del multi-dest session",
        "Multi-dest",
        "Group",
        "dest port",
        "")
{
    uint32_t port_id = 0;
    sai_object_id_t port_oid = 0;
    
    sai_status_t    ret = SAI_STATUS_SUCCESS;  
    sai_object_id_t session_oid = 0;
    sai_attribute_t attr[3];
    sai_object_list_t  obj_list; 
    sai_object_id_t    port_sid[1];
    sai_mirror_api_t* mirror_api;
    ctc_sai_mirror_entry_t* pst_mirror_entry = NULL;
    
    sal_memset(&mirror_api, 0, sizeof(mirror_api));
    ret = sai_api_query(SAI_API_MIRROR,(void**)&mirror_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    if (0 == ctc_sai_multi_dest_mirror_session)
    {
         ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
         return CLI_SUCCESS;
    }
    session_oid = ctc_sai_multi_dest_mirror_session;
    pst_mirror_entry = ctc_sai_mirror_session_id_entry_get(session_oid);
    if (pst_mirror_entry == NULL)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    if (pst_mirror_entry->monitor_port_count == 0)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    else if (pst_mirror_entry->monitor_port_count == 1)
    {
        ret = mirror_api->remove_mirror_session(session_oid);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
    }
    else if (pst_mirror_entry->monitor_port_count > 1)
    {
        sal_memset(&obj_list, 0, sizeof(obj_list));
        sal_memset(&attr, 0, sizeof(sai_attribute_t));
    
        attr[0].id = SAI_MIRROR_SESSION_ATTR_MULTI_DEST_MEMBER_ADD;
        attr[0].value.booldata = FALSE;
        ret = mirror_api->set_mirror_session_attribute(session_oid, attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
        
        CTC_CLI_GET_UINT16_RANGE("port-id", port_id, argv[0], 0, CTC_MAX_UINT16_VALUE);
        port_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT, port_id);
        port_sid[0] = port_oid;
        obj_list.list = port_sid;
        obj_list.count = 1;
        attr[0].id = SAI_MIRROR_SESSION_ATTR_MONITOR_PORT;
        sal_memcpy(&attr[0].value.objlist, &obj_list, sizeof(sai_object_list_t));
        ret = mirror_api->set_mirror_session_attribute(session_oid, attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
    }
    return CLI_SUCCESS;    
}


CTC_CLI(cli_sai_mirror_session_delete,
        cli_sai_mirror_delete_cmd,
        "mirror remove mirror session SESSION_ID",
        "mirror",
        "Remove one session_id",
        "MIRROR",
        "session",
        "<0-3>")
{
    uint32_t session_id = 0;
    sai_object_id_t session_oid = 0;
    sai_mirror_api_t* mirror_api;
    sai_status_t ret = SAI_STATUS_SUCCESS;

    sal_memset(&mirror_api, 0, sizeof(mirror_api));
    CTC_CLI_GET_UINT16_RANGE("session-id", session_id, argv[0], 0, 3);
    session_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_MIRROR, session_id);

    ret = sai_api_query(SAI_API_MIRROR,(void**)&mirror_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }  
    ret = mirror_api->remove_mirror_session(session_oid);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    return CLI_SUCCESS;
}


char *mirror_session_type_val2str(uint32 type)
{
    switch (type)
    {
    case SAI_MIRROR_TYPE_LOCAL:
        return "Local";
    case SAI_MIRROR_TYPE_REMOTE:
        return "Remote";
    case SAI_MIRROR_TYPE_ENHANCED_REMOTE:
        return "Enhanced_remote";
    default:
        return "invalid";
    }
}

CTC_CLI(cli_sai_mirror_session_get,
        cli_sai_mirror_session_get_cmd,
        "mirror get-attribute session SESSION_ID (type|port|vlan)",
        "mirror",
        "get attribute",
        "session",
        "<0-3>",
        "mirror type",
        "port id")
{
    uint32_t session_id = 0;
    sai_object_id_t session_oid = 0;
    sai_mirror_api_t* mirror_api;
    sai_status_t ret = SAI_STATUS_SUCCESS;
    sai_attribute_t attr;
    uint32 port_id = 0;
    
    CTC_CLI_GET_UINT16_RANGE("session-id", session_id, argv[0], 0, 3);
    session_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_MIRROR, session_id);
  
    if (0 == sal_strcmp(argv[1], "type"))
    {
        attr.id= SAI_MIRROR_SESSION_ATTR_TYPE;
    }
    else if (0 == sal_strcmp(argv[1], "port"))
    {
        attr.id = SAI_MIRROR_SESSION_ATTR_MONITOR_PORT;
    }
    ret = sai_api_query(SAI_API_MIRROR,(void**)&mirror_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = mirror_api->get_mirror_session_attribute(session_oid, 1, &attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    
    switch(attr.id)
    {
    case SAI_MIRROR_SESSION_ATTR_TYPE:
        ctc_cli_out("%-10s:%-10s\n", "type", mirror_session_type_val2str(attr.value.s32));
        break;
    case SAI_MIRROR_SESSION_ATTR_MONITOR_PORT:
        if (SAI_OBJECT_TYPE_PORT == CTC_SAI_OBJECT_TYPE_GET(attr.value.oid))
        {
            port_id = CTC_SAI_OBJECT_INDEX_GET(attr.value.oid);
            ctc_cli_out("%-10s:%u\n","port ID", port_id);
            break;
        }
        else if (SAI_OBJECT_TYPE_LAG == CTC_SAI_OBJECT_TYPE_GET(attr.value.oid))
        {
            port_id = CTC_SAI_OBJECT_INDEX_GET(attr.value.oid);
            ctc_cli_out("%-10s:%u\n","lag ID", port_id);
            break;
        }       
    default:
        break;
    }
    return CLI_SUCCESS;
}


static int32
_ctc_sai_show_mirror_entry(ctc_sai_mirror_entry_t* pst_mirror_entry)
{
    uint32 sessionid = 0;
    uint32 portid = 0;
    bool is_multi_dest_mirror = FALSE;
    sai_object_id_t port_oid = 0;
    uint8  tid  = 0;
    uint32  i = 0;
    sessionid = CTC_SAI_OBJECT_INDEX_GET(pst_mirror_entry->sid);
    ctc_cli_out("%-20s:%10u\n","minotor session_id", sessionid);
    
    is_multi_dest_mirror = pst_mirror_entry->is_multi_dest_mirror;
    if (is_multi_dest_mirror)
    {
        ctc_cli_out("%-20s:%10s\n","minotor type", "multi-dest mirror");
        ctc_cli_out("%-20s:%10s","minotor port_id", "");
        for (i = 0; i< CTC_SAI_MIRROR_MULTI_DEST_PORT_NUM; i++)
        {
            if (0 != pst_mirror_entry->monitor_port[i])
            {
                portid = CTC_SAI_OBJECT_INDEX_GET(pst_mirror_entry->monitor_port[i]);
                ctc_cli_out("%d ", portid);
            }
        }
    }
    else
    {
        ctc_cli_out("%-20s:%10s\n","minotor type", mirror_session_type_val2str(pst_mirror_entry->monitor_type));
        port_oid = pst_mirror_entry->monitor_port[0];
        if (SAI_OBJECT_TYPE_PORT == CTC_SAI_OBJECT_TYPE_GET(port_oid))
        {
            ctc_cli_out("%-20s:%10s\n","minotor port_type","port");
        }
        else if (SAI_OBJECT_TYPE_LAG == CTC_SAI_OBJECT_TYPE_GET(port_oid))
        {
            tid = CTC_SAI_OBJECT_INDEX_GET(port_oid);
            ctc_cli_out("%-20s:%10s\n","minotor port_type","agg");
            ctc_cli_out("%-20s:%10d\n","tid", tid);
        }
        portid = CTC_SAI_OBJECT_INDEX_GET(pst_mirror_entry->monitor_port[0]);
        ctc_cli_out("%-20s:%10u\n","minotor port_id", portid);
    }
    
    ctc_cli_out("\n");
    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_mirror_show,
        cli_sai_mirror_show_cmd,
        "show sai mirror session (SESSION_ID|)",
        "show",
        "SAI",
        "mirror session",
        "SESSION_ID")
{
    uint32    i =0 ;
    uint32    session_id = 0;
    uint32    count = 0;
    sai_object_id_t session_oid = 0;
    ctc_sai_mirror_entry_t* pst_mirror_entry = NULL;
    if(argc == 1)
    {
        CTC_CLI_GET_UINT16_RANGE("session-id", session_id, argv[0], 0, 3);
        session_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_MIRROR, session_id);

        pst_mirror_entry =  ctc_sai_mirror_entry_get(session_oid);
        if (NULL != pst_mirror_entry)
        {
            ctc_cli_out("Mirror dest entry list:\n");
            _ctc_sai_show_mirror_entry(pst_mirror_entry);
        }
        else
        {
             ctc_cli_out("Mirror %d dest entry list is NULL\n", session_id);
        }
    }
    else if (argc == 0)
    {
         for (i = 0; i < CTC_SAI_MIRROR_SESSION_MAX; i++)
         {
             pst_mirror_entry = ctc_sai_mirror_session_id_entry_get(i);
             if (NULL != pst_mirror_entry)
             {
                if (pst_mirror_entry->sid != 0)
                {
                     ctc_cli_out("Mirror dest entry list:\n");
                     _ctc_sai_show_mirror_entry(pst_mirror_entry);
                     count++;
                }
             }
         } 
         if (!count)
         {
            ctc_cli_out("Mirror dest entry list is NULL\n");
         }
    }
    ctc_cli_out("\n");

    return CLI_SUCCESS;
}

int32
ctc_sai_mirror_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_mirror_create_cmd);
    install_element(cli_tree_mode, &cli_sai_mirror_add_multi_dest_cmd);
    install_element(cli_tree_mode, &cli_sai_mirror_del_multi_dest_cmd);
    install_element(cli_tree_mode, &cli_sai_mirror_delete_cmd);
    install_element(cli_tree_mode, &cli_sai_mirror_session_get_cmd);
    install_element(cli_tree_mode, &cli_sai_mirror_show_cmd);
    return CLI_SUCCESS;
}







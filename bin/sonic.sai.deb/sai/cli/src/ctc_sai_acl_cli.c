#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include "ctc_const.h"
#include "ctc_sai_acl.h"
#include <ctc_sai_common.h>
#include "ctc_cli_common.h"

#define CTC_CLI_ACL_FIELD_STR           \
    "{src-ipv6|dst-ipv6|ipv6-flow-label|src-mac|dst-mac|src-ipv4|dst-ipv4|in-ports|port|out-vlan-id|out-vlan-pri|out-vlan-cfi  \
       |inner-vlan-id|inner-vlan-pri|inner-vlan-cfi|l4-src-port|l4-dst-port|ether-type|ip-protocol|dscp|tcp-flags|ip-type|ip-frag}"

#define CTC_CLI_ACL_FIELD_DESC        \
    "IPv6 source address",        \
    "IPv6 destination address",   \
    "IPv6 flow label",           \
    "MAC source address",         \
    "MAC destination address",    \
    "IPv4 source address",          \
    "IPv4 destination address",     \
    "In ports",     \
    "In port",     \
    "Service VLAN",               \
    "Service VLAN CoS",           \
    "Service VLAN CFI",           \
    "Customer VLAN",              \
    "Customer VLAN CoS",          \
    "Customer VLAN CFI",          \
    "Layer4 source port",          \
    "Layer4 destination port",         \
    "Ether type",                 \
    "L4 protocol ",              \
    "Dscp",                         \
    "Tcp flags",                         \
    "Ip type",                              \
    "Ip fragment information"

#define CTC_CLI_ACL_FIELD_SET()                                                  \
    index = CTC_CLI_GET_ARGC_INDEX("src-ipv6");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[2].value.booldata = TRUE;    \
        attr[2].id = SAI_ACL_TABLE_ATTR_FIELD_SRC_IPv6;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("dst-ipv6");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[3].value.booldata = TRUE;    \
        attr[3].id = SAI_ACL_TABLE_ATTR_FIELD_DST_IPv6;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("ipv6-flow-label");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[4].value.booldata = TRUE;    \
        attr[4].id = SAI_ACL_TABLE_ATTR_FIELD_IPv6_FLOW_LABEL;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("src-mac");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[5].value.booldata = TRUE;    \
        attr[5].id = SAI_ACL_TABLE_ATTR_FIELD_SRC_MAC;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("dst-mac");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[6].value.booldata = TRUE;    \
        attr[6].id = SAI_ACL_TABLE_ATTR_FIELD_DST_MAC;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("src-ipv4");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[7].value.booldata = TRUE;    \
        attr[7].id = SAI_ACL_TABLE_ATTR_FIELD_SRC_IP;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("dst-ipv4");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[8].value.booldata = TRUE;    \
        attr[8].id = SAI_ACL_TABLE_ATTR_FIELD_DST_IP;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("in-ports");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[9].value.booldata = TRUE;    \
        attr[9].id = SAI_ACL_TABLE_ATTR_FIELD_IN_PORTS;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("port");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[10].value.booldata = TRUE;    \
        attr[10].id = SAI_ACL_TABLE_ATTR_FIELD_IN_PORT;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("out-vlan-id");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[11].value.booldata = TRUE;    \
        attr[11].id = SAI_ACL_TABLE_ATTR_FIELD_OUTER_VLAN_ID;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("out-vlan-pri");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[12].value.booldata = TRUE;    \
        attr[12].id = SAI_ACL_TABLE_ATTR_FIELD_OUTER_VLAN_PRI;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("out-vlan-cfi");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[13].value.booldata = TRUE;    \
        attr[13].id = SAI_ACL_TABLE_ATTR_FIELD_OUTER_VLAN_CFI;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("inner-vlan-id");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[14].value.booldata = TRUE;    \
        attr[14].id = SAI_ACL_TABLE_ATTR_FIELD_INNER_VLAN_ID;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("inner-vlan-pri");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[15].value.booldata = TRUE;    \
        attr[15].id = SAI_ACL_TABLE_ATTR_FIELD_INNER_VLAN_PRI;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("inner-vlan-cfi");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[16].value.booldata = TRUE;    \
        attr[16].id = SAI_ACL_TABLE_ATTR_FIELD_INNER_VLAN_CFI;    \
    }\
    index = CTC_CLI_GET_ARGC_INDEX("l4-src-port");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[17].value.booldata = TRUE;    \
        attr[17].id = SAI_ACL_TABLE_ATTR_FIELD_L4_SRC_PORT;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("l4-dst-port");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[18].value.booldata = TRUE;    \
        attr[18].id = SAI_ACL_TABLE_ATTR_FIELD_L4_DST_PORT;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("ether-type");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[19].value.booldata = TRUE;    \
        attr[19].id = SAI_ACL_TABLE_ATTR_FIELD_ETHER_TYPE;    \
    }\
    index = CTC_CLI_GET_ARGC_INDEX("ip-protocol");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[20].value.booldata = TRUE;    \
        attr[20].id = SAI_ACL_TABLE_ATTR_FIELD_IP_PROTOCOL;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("dscp");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[21].value.booldata = TRUE;    \
        attr[21].id = SAI_ACL_TABLE_ATTR_FIELD_DSCP;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("tcp-flags");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[22].value.booldata = TRUE;    \
        attr[22].id = SAI_ACL_TABLE_ATTR_FIELD_TCP_FLAGS;    \
    }\
    index = CTC_CLI_GET_ARGC_INDEX("ip-type");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[23].value.booldata = TRUE;    \
        attr[23].id = SAI_ACL_TABLE_ATTR_FIELD_IP_TYPE;    \
    }                                                                              \
    index = CTC_CLI_GET_ARGC_INDEX("ip-frag");                                 \
    if (0xFF != index)                                                     \
    {                                                                              \
        attr[24].value.booldata = TRUE;    \
        attr[24].id = SAI_ACL_TABLE_ATTR_FIELD_IP_FRAG;    \
    }

#define CTC_CLI_ACL_KEY_STR  \
    " port PORT | in-ports PORT1 PORT2 PORT3 |mac-sa MAC MASK | mac-da MAC MASK |          \
             | cvlan VLAN_ID MASK | ctag-cos COS MASK | ctag-cfi CFI       \
             | svlan VLAN_ID MASK | stag-cos COS MASK | stag-cfi CFI      \
             | ip-type IP_TYPE MASK | ip-sa A.B.C.D A.B.C.D | ip-da A.B.C.D A.B.C.D "

#define CTC_CLI_ACL_KEY_DESC \
    "In port",                        \
    "In PORT ID",                        \
    "In ports",                         \
    "In PORT ID1",                        \
    "In PORT ID2",                        \
    "In PORT ID3",                        \
    "MAC source address",         \
    CTC_CLI_MAC_FORMAT,           \
    CTC_CLI_MAC_FORMAT,           \
    "MAC destination address",    \
    CTC_CLI_MAC_FORMAT,           \
    CTC_CLI_MAC_FORMAT,           \
    "Customer VLAN",              \
    CTC_CLI_VLAN_RANGE_DESC,      \
    CTC_CLI_VLAN_RANGE_MASK,      \
    "Customer VLAN CoS",          \
    CTC_CLI_COS_RANGE_DESC,       \
    CTC_CLI_COS_RANGE_MASK,       \
    "Customer VLAN CFI",          \
    CTC_CLI_CFI_RANGE_DESC,       \
    "Service VLAN",               \
    CTC_CLI_VLAN_RANGE_DESC,      \
    CTC_CLI_VLAN_RANGE_MASK,      \
    "Service VLAN CoS",           \
    CTC_CLI_COS_RANGE_DESC,       \
    CTC_CLI_COS_RANGE_MASK,       \
    "Service VLAN CFI",           \
    CTC_CLI_CFI_RANGE_DESC,       \
    "IP Type",                       \
    "3:ipv4,5:ipv6",                          \
    "0-0xF",                                        \
    "IPv4 source address",          \
    CTC_CLI_IPV4_FORMAT,            \
    CTC_CLI_IPV4_MASK_FORMAT,       \
    "IPv4 destination address",     \
    CTC_CLI_IPV4_FORMAT,            \
    CTC_CLI_IPV4_MASK_FORMAT

#define CTC_CLI_ACL_KEY_SET()                                                 \
    index = CTC_CLI_GET_ARGC_INDEX("port");                                           \
    if (INDEX_VALID(index))                                                             \
    {                                                                                   \
        CTC_CLI_GET_UINT16("gport", attr[3].value.oid, argv[index + 1]);        \
        attr[3].value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,attr[3].value.oid);    \
        attr[3].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;    \
    }                                                                                   \
    index = CTC_CLI_GET_ARGC_INDEX("in-ports");                                           \
    if (INDEX_VALID(index))                                                             \
    {                                                                                   \
        CTC_CLI_GET_UINT16("gport", attr[4].value.objlist.list[0], argv[index + 1]);        \
        attr[4].value.objlist.list[0] = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,attr[4].value.objlist.list[0]);    \
        CTC_CLI_GET_UINT16("gport", attr[4].value.objlist.list[1], argv[index + 2]);        \
        attr[4].value.objlist.list[1] = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,attr[4].value.objlist.list[1]);    \
        CTC_CLI_GET_UINT16("gport", attr[4].value.objlist.list[2], argv[index + 3]);        \
        attr[4].value.objlist.list[2] = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,attr[4].value.objlist.list[2]);    \
        attr[4].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORTS;    \
    }                                                                                   \
    index = CTC_CLI_GET_ARGC_INDEX("mac-sa");                                           \
    if (INDEX_VALID(index))                                                             \
    {                                                                                   \
        CTC_CLI_GET_MAC_ADDRESS("mac-sa", ((uint8_t*)&attr[5].value.aclfield.data.mac), argv[index + 1]);                \
        CTC_CLI_GET_MAC_ADDRESS("mac-sa-mask", ((uint8_t*)&attr[5].value.aclfield.mask.mac), argv[index + 2]);      \
        attr[5].value.aclfield.enable = TRUE;                       \
        attr[5].id = SAI_ACL_ENTRY_ATTR_FIELD_SRC_MAC;    \
    }                                                                                   \
    index = CTC_CLI_GET_ARGC_INDEX("mac-da");                                           \
    if (INDEX_VALID(index))                                                             \
    {                                                                                   \
        CTC_CLI_GET_MAC_ADDRESS("mac-da", ((uint8_t*)&attr[6].value.aclfield.data.mac), argv[index + 1]);                \
        CTC_CLI_GET_MAC_ADDRESS("mac-da-mask", ((uint8_t*)&attr[6].value.aclfield.mask.mac), argv[index + 2]);      \
        attr[6].value.aclfield.enable = TRUE;                       \
        attr[6].id = SAI_ACL_ENTRY_ATTR_FIELD_DST_MAC;    \
    }  \
    index = CTC_CLI_GET_ARGC_INDEX("svlan");                                            \
    if (INDEX_VALID(index))                                                             \
    {                                                                                   \
        CTC_CLI_GET_UINT16("svlan", attr[7].value.aclfield.data.u16, argv[index + 1]);                       \
        CTC_CLI_GET_UINT16("svlan mask", attr[7].value.aclfield.mask.u16, argv[index + 2]);             \
        attr[7].value.aclfield.enable = TRUE;                       \
        attr[7].id = SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_ID;    \
    }                                                                                   \
    index = CTC_CLI_GET_ARGC_INDEX("stag-cos");                                         \
    if (INDEX_VALID(index))                                                             \
    {                                                                                   \
        CTC_CLI_GET_UINT8("stag-cos", attr[8].value.aclfield.data.u16, argv[index + 1]);                \
        CTC_CLI_GET_UINT8("stag-cos mask", attr[8].value.aclfield.mask.u16, argv[index + 2]);      \
        attr[8].value.aclfield.enable = TRUE;                       \
        attr[8].id = SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_PRI;    \
    }                                                                                   \
    index = CTC_CLI_GET_ARGC_INDEX("stag-cfi");                                         \
    if (INDEX_VALID(index))                                                             \
    {                                                                                   \
        CTC_CLI_GET_UINT8("stag-cfi", attr[9].value.aclfield.data.u16, argv[index + 1]);                \
        attr[9].value.aclfield.enable = TRUE;                       \
        attr[9].id = SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_CFI;    \
    }                                                                                   \
    index = CTC_CLI_GET_ARGC_INDEX("ip-type");                                      \
    if (INDEX_VALID(index))                                                             \
    {                                                                                   \
        CTC_CLI_GET_UINT8("ip-type", attr[10].value.aclfield.data.u16, argv[index + 1]);              \
        CTC_CLI_GET_UINT8("ip-type mask", attr[10].value.aclfield.mask.u16, argv[index + 2]);    \
        attr[10].value.aclfield.enable = TRUE;                       \
        attr[10].id = SAI_ACL_ENTRY_ATTR_FIELD_IP_TYPE;    \
    }                                                                                  \
    index = CTC_CLI_GET_ARGC_INDEX("ip-sa");                                                             \
    if (INDEX_VALID(index))                                                                              \
    {                                                                                                    \
        CTC_CLI_GET_IPV4_ADDRESS("ip-sa", attr[11].value.aclfield.data.ip4, argv[index + 1]);                                \
        CTC_CLI_GET_IPV4_ADDRESS("ip-sa-mask", attr[11].value.aclfield.mask.ip4, argv[index + 2]);                      \
        attr[11].value.aclfield.enable = TRUE;                       \
        attr[11].id = SAI_ACL_ENTRY_ATTR_FIELD_SRC_IP;    \
    }                                                                                                    \
    index = CTC_CLI_GET_ARGC_INDEX("ip-da");                                                             \
    if (INDEX_VALID(index))                                                                              \
    {                                                                                                    \
        CTC_CLI_GET_IPV4_ADDRESS("ip-da", attr[12].value.aclfield.data.ip4, argv[index + 1]);                                \
        CTC_CLI_GET_IPV4_ADDRESS("ip-da-mask", attr[12].value.aclfield.mask.ip4, argv[index + 2]);                      \
        attr[12].value.aclfield.enable = TRUE;                       \
        attr[12].id = SAI_ACL_ENTRY_ATTR_FIELD_DST_IP;    \
    }                                                                                                    \


CTC_CLI(cli_sai_acl_create_table,
        cli_sai_acl_create_table_cmd,
        "acl create table stage (ingress |egress) priority PRIORITY" CTC_CLI_ACL_FIELD_STR,
        "ACL",
        "Create",
        "ACL table",
        "Stage",
        "Ingress",
        "Egress",
        "Priority",
        "PRIORITY",
       CTC_CLI_ACL_FIELD_DESC)
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint8 index = 0xFF;
    sai_object_id_t table_id;
    sai_acl_api_t*  acl_api;
    sai_attribute_t attr[25] = {{0}};

    attr[0].id = SAI_ACL_TABLE_ATTR_STAGE;
    attr[1].id = SAI_ACL_TABLE_ATTR_PRIORITY;

    CTC_CLI_GET_UINT16_RANGE("priority", attr[1].value.u32, argv[1], 0, CTC_MAX_UINT16_VALUE);

    index = CTC_CLI_GET_ARGC_INDEX("ingress");
    if (0xFF != index)
    {
        attr[0].value.s32 = SAI_ACL_STAGE_INGRESS;
    }

    index = CTC_CLI_GET_ARGC_INDEX("egress");
    if (0xFF != index)
    {
        attr[0].value.s32 = SAI_ACL_STAGE_EGRESS;
    }

    CTC_CLI_ACL_FIELD_SET()

    ret = sai_api_query(SAI_API_ACL,(void**)&acl_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = acl_api->create_acl_table(&table_id,sizeof(attr)/sizeof(attr[0]),attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:0x%-10llx\n","table id",CTC_SAI_OBJECT_INDEX_GET(table_id));

    return ret;
}

CTC_CLI(cli_sai_acl_delete_table,
        cli_sai_acl_delete_table_cmd,
        "acl delete table TABLE_ID",
        "ACL",
        "Delete",
        "ACL table",
        "TABLE ID")
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_acl_api_t*  acl_api;
    sai_object_id_t table_id;

    CTC_CLI_GET_UINT32_RANGE("table-id", table_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    table_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_TABLE,table_id);

    ret = sai_api_query(SAI_API_ACL,(void**)&acl_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = acl_api->delete_acl_table(table_id);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}


CTC_CLI(cli_sai_acl_get_table_attribute,
        cli_sai_acl_get_table_attribute_cmd,
        "acl get-attribute table TABLE_ID (stage|priority|match-field)",
        "ACL",
        "Get Attribute",
        "ACL table",
        "TABLE ID",
        "Stage",
        "Priority",
        "Match field")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_acl_api_t*  acl_api;
    sai_object_id_t table_id;
    uint32              index;
    sai_attribute_t     attr;
    const char*         field[] = {"SRC_IPv6","DST_IPv6","SRC_MAC","DST_MAC",  \
                                                "SRC_IP","DST_IP","IN_PORTS","OUT_PORTS",  \
                                                "IN_PORT","OUT_PORT","OUTER_VLAN_ID","OUTER_VLAN_PRI",  \
                                                "OUTER_VLAN_CFI","INNER_VLAN_ID","INNER_VLAN_PRI","INNER_VLAN_CFI",  \
                                                "L4_SRC_PORT","L4_DST_PORT","ETHER_TYPE","IP_PROTOCOL",  \
                                                "DSCP","TTL","TOS","IP_FLAGS",  \
                                                "TCP_FLAGS","IP_TYPE","IP_FRAG","IPv6_FLOW_LABEL",  \
                                                "COS"};

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    CTC_CLI_GET_UINT16_RANGE("table-id", table_id, argv[0], 0, CTC_MAX_UINT16_VALUE);
    table_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_TABLE,table_id);

    ret = sai_api_query(SAI_API_ACL,(void**)&acl_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    index = CTC_CLI_GET_ARGC_INDEX("stage");
    if(index != 0xFF)
    {
        attr.id = SAI_ACL_TABLE_ATTR_STAGE;
        ret = acl_api->get_acl_table_attribute(table_id,1,&attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        ctc_cli_out("%-10s:%-10s\n","stage",attr.value.s32 == SAI_ACL_STAGE_INGRESS ? "Ingress" : "Egress");
    }

    index = CTC_CLI_GET_ARGC_INDEX("priority");
    if(index != 0xFF)
    {
        attr.id = SAI_ACL_TABLE_ATTR_PRIORITY;
        ret = acl_api->get_acl_table_attribute(table_id,1,&attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
        ctc_cli_out("%-10s:%-10u\n","priority",attr.value.u32);
    }

    index = CTC_CLI_GET_ARGC_INDEX("match-field");
    if(index != 0xFF)
    {
        ctc_cli_out("%-10s:\n","match field");
        for ((attr.id) = SAI_ACL_TABLE_ATTR_FIELD_START; (attr.id) <= SAI_ACL_TABLE_ATTR_FIELD_END; (attr.id)++)
        {
            ret = acl_api->get_acl_table_attribute(table_id,1,&attr);
            if(SAI_STATUS_SUCCESS != ret)
            {
                ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
                return CLI_SUCCESS;
            }

            if (attr.value.booldata)
            {
                ctc_cli_out("  %-10s\n",field[attr.id-SAI_ACL_TABLE_ATTR_FIELD_START]);
            }
        }
    }

    return ret;
}


CTC_CLI(cli_sai_acl_create_entry,
        cli_sai_acl_create_entry_cmd,
        "acl create table TABLE_ID entry (state (enable |disable)|) (priority PRIORITY |) {"CTC_CLI_ACL_KEY_STR"}   \
        (permit|deny) ({counter COUNTER_ID |redirect NH_ID}|) (policer POLICER |)",
        "ACL",
        "Add entry",
        "ACL table",
        "Group ID",
        "Entry",
        "Stage, enable or disable",
        "Enable entry",
        "Disable entry",
        "Priority",
        "PRIORITY",
        CTC_CLI_ACL_KEY_DESC,
        "Permit",
        "Deny",
        "Counter",
        "Counter ID",
        "POLICER",
        "POLICER ID")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint8 index = 0xFF;
    sai_object_id_t entry_id;
    sai_acl_api_t*  acl_api;
    sai_attribute_t attr[25] = {{0}};

    attr[0].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr[1].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr[2].id = SAI_ACL_ENTRY_ATTR_ADMIN_STATE;
    attr[2].value.booldata = TRUE;
    attr[4].value.objlist.count = 3;
    attr[4].value.objlist.list = mem_malloc(MEM_APP_ACL_MODULE,sizeof(sai_object_id_t) * 3);

    CTC_CLI_GET_UINT32_RANGE("table-id", attr[0].value.oid, argv[0], 0, CTC_MAX_UINT32_VALUE);
    attr[0].value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_TABLE,attr[0].value.oid);

    index = CTC_CLI_GET_ARGC_INDEX("state");
    if (0xFF != index)
    {
        if (CLI_CLI_STR_EQUAL("enable", (index+1)))
        {
            attr[2].value.booldata = TRUE;
        }
        else if (CLI_CLI_STR_EQUAL("disable", (index+1)))
        {
            attr[2].value.booldata = FALSE;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("priority");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT32("entry priority", attr[1].value.u32, argv[index + 1]);
    }

    CTC_CLI_ACL_KEY_SET()

    index = CTC_CLI_GET_ARGC_INDEX("permit");
    if (0xFF != index)
    {
        attr[20].value.aclaction.enable = TRUE;
        attr[20].id = SAI_ACL_ENTRY_ATTR_PACKET_ACTION;
        attr[20].value.aclaction.parameter.s32 = SAI_PACKET_ACTION_FORWARD;
    }

    index = CTC_CLI_GET_ARGC_INDEX("deny");
    if (0xFF != index)
    {
        attr[20].id = SAI_ACL_ENTRY_ATTR_PACKET_ACTION;
        attr[20].value.aclaction.parameter.s32 = SAI_PACKET_ACTION_DROP;
    }

    index = CTC_CLI_GET_ARGC_INDEX("counter");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT32("counter id", attr[22].value.aclaction.parameter.oid, argv[index + 1]);
        attr[22].value.aclaction.parameter.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_COUNTER,attr[22].value.aclaction.parameter.oid);
        attr[22].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
        attr[22].value.aclaction.enable = TRUE;
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("policer");
    if (0xFF != index)
    {
        CTC_CLI_GET_UINT32("policer id", attr[23].value.oid, argv[index + 1]);
        attr[23].value.aclaction.enable = TRUE;
        attr[23].value.aclaction.parameter.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_POLICER,attr[23].value.oid);;
        attr[23].id = SAI_ACL_ENTRY_ATTR_ACTION_SET_POLICER;
    }

    ret = sai_api_query(SAI_API_ACL,(void**)&acl_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = acl_api->create_acl_entry(&entry_id,sizeof(attr)/sizeof(attr[0]),attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:0x%-10llx\n","entry id",CTC_SAI_OBJECT_INDEX_GET(entry_id));
    mem_free(attr[4].value.objlist.list);

    return ret;
}


CTC_CLI(cli_sai_acl_delete_entry,
        cli_sai_acl_delete_entry_cmd,
        "acl delete entry ENTRY_ID",
        "ACL",
        "Delete",
        "ACL entry",
        "ENTRY ID")
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_acl_api_t*  acl_api;
    sai_object_id_t entry_id;

    CTC_CLI_GET_UINT32_RANGE("entry-id", entry_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    entry_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_ENTRY,entry_id);

    ret = sai_api_query(SAI_API_ACL,(void**)&acl_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = acl_api->delete_acl_entry(entry_id);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}


CTC_CLI(cli_sai_acl_set_entry_attribute,
        cli_sai_acl_set_entry_attribute_cmd,
        "acl set-attribute entry ENTRY_ID (state (enable |disable) |priority PRIORITY |"CTC_CLI_ACL_KEY_STR" )",
        "ACL",
        "Set Attribute",
        "ACL entry",
        "ENTRY ID",
        "Stage",
        "Enable",
        "Disable",
        "Priority",
        "PRIORITY",
        CTC_CLI_ACL_KEY_DESC)
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_acl_api_t*  acl_api;
    sai_object_id_t entry_id;
    uint32              index;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    CTC_CLI_GET_UINT32_RANGE("entry-id", entry_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    entry_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_ENTRY,entry_id);

    index = CTC_CLI_GET_ARGC_INDEX("state");
    if (0xFF != index)
    {
        attr.id = SAI_ACL_ENTRY_ATTR_ADMIN_STATE;
        if (CLI_CLI_STR_EQUAL("enable", (index+1)))
        {
            attr.value.booldata = TRUE;
        }
        else if (CLI_CLI_STR_EQUAL("disable", (index+1)))
        {
            attr.value.booldata = FALSE;
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("priority");
    if (0xFF != index)
    {
        attr.id = SAI_ACL_ENTRY_ATTR_PRIORITY;
        CTC_CLI_GET_UINT32("entry priority", attr.value.u32, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("port");
    if (INDEX_VALID(index))
    {
        CTC_CLI_GET_UINT16("gport", attr.value.oid, argv[index + 1]);
        attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,attr.value.oid);
        attr.id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    }

    index = CTC_CLI_GET_ARGC_INDEX("mac-sa");
    if (INDEX_VALID(index))
    {
        CTC_CLI_GET_MAC_ADDRESS("mac-sa", ((uint8_t*)&attr.value.aclfield.data.mac), argv[index + 1]);
        CTC_CLI_GET_MAC_ADDRESS("mac-sa-mask", ((uint8_t*)&attr.value.aclfield.mask.mac), argv[index + 2]);
        attr.value.aclfield.enable = TRUE;
        attr.id = SAI_ACL_ENTRY_ATTR_FIELD_SRC_MAC;
    }

    index = CTC_CLI_GET_ARGC_INDEX("in-ports");
    if (INDEX_VALID(index))
    {
        attr.value.objlist.count = 3;
        attr.value.objlist.list = mem_malloc(MEM_APP_ACL_MODULE,sizeof(sai_object_id_t) * 3);
        CTC_CLI_GET_UINT16("gport", attr.value.objlist.list[0], argv[index + 1]);
        attr.value.objlist.list[0] = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,attr.value.objlist.list[0]);
        CTC_CLI_GET_UINT16("gport", attr.value.objlist.list[1], argv[index + 2]);
        attr.value.objlist.list[1] = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,attr.value.objlist.list[1]);
        CTC_CLI_GET_UINT16("gport", attr.value.objlist.list[2], argv[index + 3]);
        attr.value.objlist.list[2] = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,attr.value.objlist.list[2]);
        attr.id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORTS;
    }

    index = CTC_CLI_GET_ARGC_INDEX("ip-sa");
    if (INDEX_VALID(index))
    {
        CTC_CLI_GET_IPV4_ADDRESS("ip-sa", attr.value.aclfield.data.ip4, argv[index + 1]);
        CTC_CLI_GET_IPV4_ADDRESS("ip-sa-mask", attr.value.aclfield.mask.ip4, argv[index + 2]);
        attr.value.aclfield.enable = TRUE;
        attr.id = SAI_ACL_ENTRY_ATTR_FIELD_SRC_IP;
    }


    ret = sai_api_query(SAI_API_ACL,(void**)&acl_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = acl_api->set_acl_entry_attribute(entry_id, &attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    if (attr.id == SAI_ACL_ENTRY_ATTR_FIELD_IN_PORTS)
    {
        mem_free(attr.value.objlist.list);
    }

    return ret;
}


CTC_CLI(cli_sai_acl_get_entry_attribute,
        cli_sai_acl_get_entry_attribute_cmd,
        "acl get-attribute entry ENTRY_ID (state|priority|port|ipsa|policer)",
        "ACL",
        "Get Attribute",
        "ACL entry",
        "ENTRY ID",
        "State",
        "Priority",
        "Port field",
        "Ipsa field",
        "policer")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_acl_api_t*  acl_api;
    sai_object_id_t entry_id;
    uint32              index;
    sai_attribute_t     attr;
    char                    buf[CTC_IPV6_ADDR_STR_LEN] = "";
    char                    buf_mask[CTC_IPV6_ADDR_STR_LEN] = "";

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    CTC_CLI_GET_UINT16_RANGE("entry-id", entry_id, argv[0], 0, CTC_MAX_UINT16_VALUE);
    entry_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_ENTRY,entry_id);

    ret = sai_api_query(SAI_API_ACL,(void**)&acl_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    index = CTC_CLI_GET_ARGC_INDEX("state");
    if(index != 0xFF)
    {
        attr.id = SAI_ACL_ENTRY_ATTR_ADMIN_STATE;
        ret = acl_api->get_acl_entry_attribute(entry_id,1,&attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        ctc_cli_out("%-10s:%-10s\n","state",attr.value.booldata  ? "enable" : "disable");
    }

    index = CTC_CLI_GET_ARGC_INDEX("priority");
    if(index != 0xFF)
    {
        attr.id = SAI_ACL_ENTRY_ATTR_PRIORITY;
        ret = acl_api->get_acl_entry_attribute(entry_id,1,&attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
        ctc_cli_out("%-10s:%-10u\n","priority",attr.value.u32);
    }

    index = CTC_CLI_GET_ARGC_INDEX("port");
    if(index != 0xFF)
    {
        attr.id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
        ret = acl_api->get_acl_entry_attribute(entry_id,1,&attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
        ctc_cli_out("%-10s:0x%-10llx\n","in-port", CTC_SAI_OBJECT_INDEX_GET(attr.value.oid));
    }

    index = CTC_CLI_GET_ARGC_INDEX("ipsa");
    if(index != 0xFF)
    {
        attr.id = SAI_ACL_ENTRY_ATTR_FIELD_SRC_IP;
        ret = acl_api->get_acl_entry_attribute(entry_id,1,&attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        uint32_t tempip = sal_ntohl(attr.value.aclfield.data.ip4 & 0xffffffff);
        uint32_t tempip_mask = sal_ntohl(attr.value.aclfield.mask.ip4 & 0xffffffff);
        sal_inet_ntop(AF_INET, &tempip, buf, CTC_IPV6_ADDR_STR_LEN);
        sal_inet_ntop(AF_INET, &tempip_mask, buf_mask, CTC_IPV6_ADDR_STR_LEN);
        ctc_cli_out("%-20s:%-20s\n","ipv4sa",buf);
        ctc_cli_out("%-20s:%-20s\n","ipv4sa mask",buf_mask);
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("policer");
    if(index != 0xFF)
    {
        attr.id = SAI_ACL_ENTRY_ATTR_ACTION_SET_POLICER;
        ret = acl_api->get_acl_entry_attribute(entry_id,1,&attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
        ctc_cli_out("%-10s:0x%-10llx\n","policer-id", CTC_SAI_OBJECT_INDEX_GET(attr.value.oid));
    }

    return ret;
}

CTC_CLI(cli_sai_acl_create_counter,
        cli_sai_acl_create_counter_cmd,
        "acl create counter table TABLE_ID",
        "ACL",
        "Create",
        "ACL counter",
        "ACL table",
        "TABLE ID")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    sai_object_id_t counter_id;
    sai_acl_api_t*  acl_api;
    sai_attribute_t attr ;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    attr.id = SAI_ACL_COUNTER_ATTR_TABLE_ID;

    CTC_CLI_GET_UINT32_RANGE("table-id", attr.value.oid, argv[0], 0, CTC_MAX_UINT32_VALUE);
    attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_TABLE,attr.value.oid);


    ret = sai_api_query(SAI_API_ACL,(void**)&acl_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = acl_api->create_acl_counter(&counter_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:0x%-10llx\n","counter id",CTC_SAI_OBJECT_INDEX_GET(counter_id));

    return ret;
}

CTC_CLI(cli_sai_acl_delete_counter,
        cli_sai_acl_delete_counter_cmd,
        "acl delete counter COUNTER_ID",
        "ACL",
        "Delete",
        "ACL counter",
        "COUNTER ID")
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_acl_api_t*  acl_api;
    sai_object_id_t counter_id;

    CTC_CLI_GET_UINT32_RANGE("counter-id", counter_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    counter_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_TABLE,counter_id);

    ret = sai_api_query(SAI_API_ACL,(void**)&acl_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = acl_api->delete_acl_counter(counter_id);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}


extern ctc_sai_acl_info_t g_sai_acl_info;

static int32
_ctc_sai_show_acl_table(ctc_sai_acl_table_t* pst_acl_tbl, void* data)
{
    sai_status_t       ret = SAI_STATUS_SUCCESS; 
    sai_object_id_t    table_id;
    sai_acl_api_t*     acl_api;
    uint32_t           attr_count = 0;
    sai_attribute_t    attr[32];
    const char*        field[] = {"SRC_IPv6","DST_IPv6","SRC_MAC","DST_MAC",  \
                                                "SRC_IP","DST_IP","IN_PORTS","OUT_PORTS",  \
                                                "IN_PORT","OUT_PORT","OUTER_VLAN_ID","OUTER_VLAN_PRI",  \
                                                "OUTER_VLAN_CFI","INNER_VLAN_ID","INNER_VLAN_PRI","INNER_VLAN_CFI",  \
                                                "L4_SRC_PORT","L4_DST_PORT","ETHER_TYPE","IP_PROTOCOL",  \
                                                "DSCP","ECN","TTL","TOS","IP_FLAGS",  \
                                                "TCP_FLAGS","IP_TYPE","IP_FRAG","IPv6_FLOW_LABEL",  \
                                                "COS","ICMP_TYPE","ICMP_CODE"};
    

    if(NULL == pst_acl_tbl)
        return 0;

    table_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_TABLE, pst_acl_tbl->table_id);

    sal_memset(attr, 0x0, (sizeof(sai_attribute_t))*32);

    ret = sai_api_query(SAI_API_ACL,(void**)&acl_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    attr[attr_count].id = SAI_ACL_TABLE_ATTR_STAGE;
    attr_count++;
    attr[attr_count].id = SAI_ACL_TABLE_ATTR_PRIORITY;
    for (attr_count = 0; attr_count < 30; attr_count++)
    {
        attr[attr_count+2].id = SAI_ACL_TABLE_ATTR_FIELD_START + attr_count;
    }

    ret = acl_api->get_acl_table_attribute(table_id ,32 ,attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:0x%-10llx\n","table id",CTC_SAI_OBJECT_INDEX_GET(table_id));
    ctc_cli_out("%-10s:%-10s\n","stage",attr[0].value.s32 == SAI_ACL_STAGE_INGRESS ? "Ingress" : "Egress");
    ctc_cli_out("%-10s:%-10u\n","priority",attr[1].value.u32);
    ctc_cli_out("%-10s:\n","match field");

    for (attr_count = 0; attr_count < 30; attr_count++)
    {
        if (attr[attr_count+2].value.booldata)
        {
            ctc_cli_out("  %-10s\n",field[attr_count]);
        }
    }

    return 0;
}


CTC_CLI(cli_sai_acl_show_acl_table,
        cli_sai_acl_show_acl_table_cmd,
        "show sai acl table (TABLE_ID|)",
        "show information",
        "SAI"
        "acl module",
        "table",
        "TABLE_ID")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_acl_api_t*      acl_api;
    sai_object_id_t     table_id;
    uint32_t            tmp;
    sai_attribute_t     attr[32];
    const char*         field[] = {"SRC_IPv6","DST_IPv6","SRC_MAC","DST_MAC",  \
                                                "SRC_IP","DST_IP","IN_PORTS","OUT_PORTS",  \
                                                "IN_PORT","OUT_PORT","OUTER_VLAN_ID","OUTER_VLAN_PRI",  \
                                                "OUTER_VLAN_CFI","INNER_VLAN_ID","INNER_VLAN_PRI","INNER_VLAN_CFI",  \
                                                "L4_SRC_PORT","L4_DST_PORT","ETHER_TYPE","IP_PROTOCOL",  \
                                                "DSCP","ECN","TTL","TOS","IP_FLAGS",  \
                                                "TCP_FLAGS","IP_TYPE","IP_FRAG","IPv6_FLOW_LABEL",  \
                                                "COS","ICMP_TYPE","ICMP_CODE"};

    sal_memset(attr, 0x0, (sizeof(sai_attribute_t))*32);

    ret = sai_api_query(SAI_API_ACL,(void**)&acl_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    if (argc == 1)
    {

        CTC_CLI_GET_UINT16_RANGE("table-id", table_id, argv[0], 0, CTC_MAX_UINT16_VALUE);
        table_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_TABLE,table_id);

        attr[0].id = SAI_ACL_TABLE_ATTR_STAGE;
        attr[1].id = SAI_ACL_TABLE_ATTR_PRIORITY;
        for (tmp = 0; tmp < 30; tmp++)
        {
            attr[tmp+2].id = SAI_ACL_TABLE_ATTR_FIELD_START + tmp;
        }

        ret = acl_api->get_acl_table_attribute(table_id ,32 ,attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        ctc_cli_out("%-10s:0x%-10llx\n","table id",CTC_SAI_OBJECT_INDEX_GET(table_id));
        ctc_cli_out("%-10s:%-10s\n","stage",attr[0].value.s32 == SAI_ACL_STAGE_INGRESS ? "Ingress" : "Egress");
        ctc_cli_out("%-10s:%-10u\n","priority",attr[1].value.u32);
        ctc_cli_out("%-10s:\n","match field");

        for (tmp = 0; tmp < 30; tmp++)
        {
            if (attr[tmp+2].value.booldata)
            {
                ctc_cli_out("  %-10s\n",field[tmp]);
            }
        }
    }
    else
    {
        ctc_vector_traverse(g_sai_acl_info.pvector[0], (vector_traversal_fn)_ctc_sai_show_acl_table, NULL);
    }
    return ret;
}

static int32
_ctc_sai_show_acl_entry(ctc_sai_acl_entry_t* pst_acl_entry, void* data)
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_acl_api_t*      acl_api;
    sai_object_id_t     entry_id;
    sai_attribute_t     attr[5];
    char                buf[CTC_IPV6_ADDR_STR_LEN] = "";
    char                buf_mask[CTC_IPV6_ADDR_STR_LEN] = "";
    
    if(NULL == pst_acl_entry)
        return 0;

    entry_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_TABLE, pst_acl_entry->entry_id);

    sal_memset(attr, 0x0, (sizeof(sai_attribute_t))*5);

    ret = sai_api_query(SAI_API_ACL,(void**)&acl_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    attr[0].id = SAI_ACL_ENTRY_ATTR_ADMIN_STATE;
    attr[1].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr[2].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr[3].id = SAI_ACL_ENTRY_ATTR_FIELD_SRC_IP;
    attr[4].id = SAI_ACL_ENTRY_ATTR_ACTION_SET_POLICER;

    ret = acl_api->get_acl_entry_attribute(entry_id, 5, attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:0x%-10llx\n","entry id",CTC_SAI_OBJECT_INDEX_GET(entry_id));
    ctc_cli_out("%-10s:%-10s\n","state",attr[0].value.booldata  ? "enable" : "disable");
    ctc_cli_out("%-10s:%-10u\n","priority",attr[1].value.u32);
    ctc_cli_out("%-10s:0x%-10llx\n","in-port", CTC_SAI_OBJECT_INDEX_GET(attr[2].value.oid));
    uint32_t tempip = sal_ntohl(attr[3].value.aclfield.data.ip4 & 0xffffffff);
    uint32_t tempip_mask = sal_ntohl(attr[3].value.aclfield.mask.ip4 & 0xffffffff);
    sal_inet_ntop(AF_INET, &tempip, buf, CTC_IPV6_ADDR_STR_LEN);
    sal_inet_ntop(AF_INET, &tempip_mask, buf_mask, CTC_IPV6_ADDR_STR_LEN);
    ctc_cli_out("%-20s:%-20s\n","ipv4sa",buf);
    ctc_cli_out("%-20s:%-20s\n","ipv4sa mask",buf_mask);
    ctc_cli_out("%-10s:0x%-10llx\n","policer-id", CTC_SAI_OBJECT_INDEX_GET(attr[4].value.oid));

    return 0;
}


CTC_CLI(cli_sai_acl_show_acl_entry,
        cli_sai_acl_show_acl_entry_cmd,
        "show sai acl entry (ENTRY_ID|)",
        "show information",
        "SAI"
        "acl module",
        "entry",
        "ENTRY_ID")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_acl_api_t*      acl_api;
    sai_object_id_t     entry_id;
    sai_attribute_t     attr[5];
    char                buf[CTC_IPV6_ADDR_STR_LEN] = "";
    char                buf_mask[CTC_IPV6_ADDR_STR_LEN] = "";

    sal_memset(attr, 0x0, (sizeof(sai_attribute_t))*5);

    ret = sai_api_query(SAI_API_ACL,(void**)&acl_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    if (argc == 1)
    {
        CTC_CLI_GET_UINT16_RANGE("entry-id", entry_id, argv[0], 0, CTC_MAX_UINT16_VALUE);
        entry_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_ENTRY, entry_id);

        attr[0].id = SAI_ACL_ENTRY_ATTR_ADMIN_STATE;
        attr[1].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
        attr[2].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
        attr[3].id = SAI_ACL_ENTRY_ATTR_FIELD_SRC_IP;
        attr[4].id = SAI_ACL_ENTRY_ATTR_ACTION_SET_POLICER;

        ret = acl_api->get_acl_entry_attribute(entry_id, 5, attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
 
        ctc_cli_out("%-10s:0x%-10llx\n","entry id",CTC_SAI_OBJECT_INDEX_GET(entry_id));
        ctc_cli_out("%-10s:%-10s\n","state",attr[0].value.booldata  ? "enable" : "disable");
        ctc_cli_out("%-10s:%-10u\n","priority",attr[1].value.u32);
        ctc_cli_out("%-10s:0x%-10llx\n","in-port", CTC_SAI_OBJECT_INDEX_GET(attr[2].value.oid));
        uint32_t tempip = sal_ntohl(attr[3].value.aclfield.data.ip4 & 0xffffffff);
        uint32_t tempip_mask = sal_ntohl(attr[3].value.aclfield.mask.ip4 & 0xffffffff);
        sal_inet_ntop(AF_INET, &tempip, buf, CTC_IPV6_ADDR_STR_LEN);
        sal_inet_ntop(AF_INET, &tempip_mask, buf_mask, CTC_IPV6_ADDR_STR_LEN);
        ctc_cli_out("%-20s:%-20s\n","ipv4sa",buf);
        ctc_cli_out("%-20s:%-20s\n","ipv4sa mask",buf_mask);
        ctc_cli_out("%-10s:0x%-10llx\n","policer-id", CTC_SAI_OBJECT_INDEX_GET(attr[4].value.oid));
    }
    else
    {
        ctc_vector_traverse(g_sai_acl_info.pvector[1], (vector_traversal_fn)_ctc_sai_show_acl_entry, NULL);
    }
    return ret;
}

CTC_CLI(cli_sai_acl_show_counter,
        cli_sai_acl_show_counter_cmd,
        "show sai acl counter COUNTER_ID",
        "show command",
        "SAI",
        "ACL",
        "ACL counter",
        "COUNTER ID")
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_acl_api_t*  acl_api;
    sai_object_id_t counter_id;
    sai_attribute_t attr[2];

    CTC_CLI_GET_UINT32_RANGE("counter-id", counter_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    counter_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_TABLE,counter_id);

    ret = sai_api_query(SAI_API_ACL,(void**)&acl_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    sal_memset(attr, 0, sizeof(attr));
    attr[0].id = SAI_ACL_COUNTER_ATTR_BYTES;
    attr[1].id = SAI_ACL_COUNTER_ATTR_PACKETS;

    ret = acl_api->get_acl_counter_attribute(counter_id, 2, attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:0x%-10llx\n","counter-id", counter_id);
    ctc_cli_out( "( bytes %lld packets %lld )\n", attr[0].value.u64, attr[1].value.u64);

    return ret;
}


int32
ctc_sai_acl_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_acl_create_table_cmd);
    install_element(cli_tree_mode, &cli_sai_acl_delete_table_cmd);
    install_element(cli_tree_mode, &cli_sai_acl_get_table_attribute_cmd);

    install_element(cli_tree_mode, &cli_sai_acl_create_entry_cmd);
    install_element(cli_tree_mode, &cli_sai_acl_delete_entry_cmd);
    install_element(cli_tree_mode, &cli_sai_acl_set_entry_attribute_cmd);
    install_element(cli_tree_mode, &cli_sai_acl_get_entry_attribute_cmd);

    install_element(cli_tree_mode, &cli_sai_acl_create_counter_cmd);
    install_element(cli_tree_mode, &cli_sai_acl_delete_counter_cmd);

    install_element(cli_tree_mode, &cli_sai_acl_show_acl_table_cmd);
    install_element(cli_tree_mode, &cli_sai_acl_show_acl_entry_cmd);
    install_element(cli_tree_mode, &cli_sai_acl_show_counter_cmd);

    return CLI_SUCCESS;
}


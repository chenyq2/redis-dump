#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include "ctc_api.h"
#include "ctc_l2.h"
#include <ctc_sai_common.h>

CTC_CLI(cli_sai_fdb_create_entry,
        cli_sai_fdb_create_entry_cmd,
        "fdb create entry (mac MAC) (vlan VLAN) set-attribute " \
        "(type (dynamic | static)) " \
        "((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) " \
        "(packet-action (drop | forward | trap | log))",
        "FDB",
        "Create",
        "FDB entry",
        SAI_CLI_MAC_DESC,
        SAI_CLI_MAC_FORMAT,
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC,
        SAI_CLI_SET_ATTRIBUTE_DESC,
        "FDB entry type",
        "Dynamic FDB Entry",
        "Static FDB Entry",
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "FDB entry packet action",
        "Drop Packet",
        "Forward Packet",
        "Trap Packet to CPU",
        "Log (Trap + Forward) Packet")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint8_t           index   = 0xFF;
    sai_fdb_entry_t l2_addr;
    sai_fdb_api_t*  fdb_api;
    sai_attribute_t attr[] = {
        [0] = {
           .id = SAI_FDB_ENTRY_ATTR_TYPE,
           .value.s32 = SAI_FDB_ENTRY_DYNAMIC,
        },
        [1] = {
           .id = SAI_FDB_ENTRY_ATTR_PORT_ID,
        },
        [2] = {
           .id = SAI_FDB_ENTRY_ATTR_PACKET_ACTION,
           .value.s32 = SAI_PACKET_ACTION_FORWARD,
        },
    };

    sal_memset(&l2_addr, 0, sizeof(sai_fdb_entry_t));

    SAI_CLI_GET_MAC_ADDRESS(&l2_addr.mac_address);
    SAI_CLI_GET_VLAN(l2_addr.vlan_id);

    index = CTC_CLI_GET_ARGC_INDEX("static");
    if (0xFF != index)
    {
        attr[0].value.s32 = SAI_FDB_ENTRY_STATIC;
    }

    index = CTC_CLI_GET_ARGC_INDEX("dynamic");
    if (0xFF != index)
    {
        attr[0].value.s32 = SAI_FDB_ENTRY_DYNAMIC;
    }

    SAI_CLI_GET_LAG_ID(attr[1].value.oid);
    SAI_CLI_GET_PORT_ID(attr[1].value.oid);
    SAI_CLI_GET_PACKET_ACTION(attr[2].value.s32);

    ret = sai_api_query(SAI_API_FDB,(void**)&fdb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = fdb_api->create_fdb_entry(&l2_addr,sizeof(attr)/sizeof(attr[0]),attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_fdb_remove_entry,
        cli_sai_fdb_remove_entry_cmd,
        "fdb remove entry (mac MAC) (vlan VLAN)",
        "FDB",
        "Remove",
        "FDB entry",
        SAI_CLI_MAC_DESC,
        SAI_CLI_MAC_FORMAT,
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC)
{
    sai_status_t    ret     = SAI_STATUS_SUCCESS;
    sai_fdb_entry_t l2_addr;
    sai_fdb_api_t*  fdb_api;

    sal_memset(&l2_addr, 0, sizeof(sai_fdb_entry_t));

    SAI_CLI_GET_MAC_ADDRESS(&l2_addr.mac_address);
    SAI_CLI_GET_VLAN(l2_addr.vlan_id);

    ret = sai_api_query(SAI_API_FDB,(void**)&fdb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = fdb_api->remove_fdb_entry(&l2_addr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_fdb_flush_all_entry,
        cli_sai_fdb_flush_all_entry_cmd,
        "fdb flush all entry",
        "Fdb",
        "Flush",
        "Initiate deletion of all FDB entries",
        "FDB entries")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_fdb_api_t*      fdb_api;

    ret = sai_api_query(SAI_API_FDB,(void**)&fdb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = fdb_api->flush_fdb_entries(0, NULL);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}
CTC_CLI(cli_sai_fdb_flush_all_type_entry,
        cli_sai_fdb_flush_all_type_entry_cmd,
        "fdb flush all entry by type (dynamic|static)",
        "Fdb",
        "Flush fdb",
        "Initiate deletion of all FDB entries",
        "FDB entries",
        "Query condition",
        "All condition")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_fdb_api_t*      fdb_api;
    sai_attribute_t     attr[1];
    ret = sai_api_query(SAI_API_FDB,(void**)&fdb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    if (0 == sal_strcmp(argv[0], "dynamic"))
    {
        attr[0].id  = SAI_FDB_FLUSH_ATTR_ENTRY_TYPE;
        attr[0].value.s32 = SAI_FDB_FLUSH_ENTRY_DYNAMIC;
    }
    else if (0 == sal_strcmp(argv[0], "static"))
    {
        attr[0].id  = SAI_FDB_FLUSH_ATTR_ENTRY_TYPE;
        attr[0].value.s32 = SAI_FDB_FLUSH_ENTRY_STATIC;
    }
    else 
    {
        ctc_cli_out("%% Not support \n", argv[0]);
    }
    ret = fdb_api->flush_fdb_entries(1, (sai_attribute_t*)&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}


CTC_CLI(cli_sai_fdb_flush_all_entry_by_port,
        cli_sai_fdb_flush_all_entry_by_port_cmd,
        "fdb flush all entry by ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID))",
        "Fdb",
        "Flush",
        "Initiate deletion of all FDB entries",
        "FDB entries",
        "By",
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE)
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_fdb_api_t*      fdb_api;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr[1];

    SAI_CLI_GET_LAG_ID(port_id);
    SAI_CLI_GET_PORT_ID(port_id);

    ret = sai_api_query(SAI_API_FDB,(void**)&fdb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    attr[0].id = SAI_FDB_FLUSH_ATTR_PORT_ID;
    attr[0].value.oid = port_id;
    ret = fdb_api->flush_fdb_entries(1, (sai_attribute_t*)&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    return ret;
}

CTC_CLI(cli_sai_fdb_flush_all_entry_by_vlan,
        cli_sai_fdb_flush_all_entry_by_vlan_cmd,
        "fdb flush all entry by (vlan VLAN)",
        "Fdb",
        "Flush",
        "Initiate deletion of all FDB entries",
        "FDB entries",
        "By",
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC)
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_fdb_api_t*      fdb_api;
    sai_vlan_id_t       vlan_id = 0;
    sai_attribute_t     attr[1];

    SAI_CLI_GET_VLAN(vlan_id);

    ret = sai_api_query(SAI_API_FDB,(void**)&fdb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    attr[0].id = SAI_FDB_FLUSH_ATTR_PORT_ID;
    attr[0].value.u16 = vlan_id;
    ret = fdb_api->flush_fdb_entries(1, attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }


    return ret;
}

CTC_CLI(cli_sai_fdb_flush_all_entry_by_port_vlan,
        cli_sai_fdb_flush_all_entry_by_port_vlan_cmd,
        "fdb flush all entry by ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) (vlan VLAN)",
        "Fdb",
        "Flush",
        "Initiate deletion of all FDB entries",
        "FDB entries",
        "By",
        "FDB entry port id",
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC)
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_fdb_api_t*      fdb_api;
    sai_vlan_id_t       vlan_id = 0;
    sai_object_id_t     port_id = 0;
    sai_attribute_t     attr[2];

    SAI_CLI_GET_LAG_ID(port_id);
    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_VLAN(vlan_id);

    ret = sai_api_query(SAI_API_FDB,(void**)&fdb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    attr[0].id = SAI_FDB_FLUSH_ATTR_PORT_ID;
    attr[0].value.oid = port_id;
    attr[1].id = SAI_FDB_FLUSH_ATTR_VLAN_ID;
    attr[1].value.u16 = vlan_id;

    ret = fdb_api->flush_fdb_entries(2, attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }


    return ret;
}

CTC_CLI(cli_sai_fdb_flush_all_entry_by_mac,
        cli_sai_fdb_flush_all_entry_by_mac_cmd,
        "fdb flush all entry by (address MAC)",
        "Fdb",
        "Flush",
        "Initiate deletion of all FDB entries",
        "FDB entries",
        "By",
        SAI_CLI_MAC_DESC,
        SAI_CLI_MAC_FORMAT)
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_fdb_api_t*      fdb_api;
    sai_mac_t           mac;
    sai_attribute_t     attr[1];

    sal_memset(mac, 0, sizeof(mac_addr_t));
    
    SAI_CLI_GET_MAC_ADDRESS(mac);

    ret = sai_api_query(SAI_API_FDB,(void**)&fdb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    attr[0].id = SAI_FDB_FLUSH_ATTR_MAC;
    sal_memcpy(attr[0].value.mac, mac, sizeof(mac_addr_t));
    ret = fdb_api->flush_fdb_entries(1, attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }


    return ret;
}

CTC_CLI(cli_sai_fdb_set_fdb_entry_attribute_packet_action,
        cli_sai_fdb_set_fdb_entry_attribute_packet_action_cmd,
        "fdb set-attribute entry (mac MAC) (vlan VLAN) (packet-action (drop | forward | trap | log))",
        "Fdb",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        "FDB entry",
        SAI_CLI_MAC_DESC,
        SAI_CLI_MAC_FORMAT,
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC,
        "FDB entry packet action",
        "Drop Packet",
        "Forward Packet",
        "Trap Packet to CPU",
        "Log (Trap + Forward) Packet")
{
    sai_status_t        ret       = SAI_STATUS_SUCCESS;
    sai_fdb_api_t*      fdb_api;
    sai_fdb_entry_t     l2_addr;
    sai_attribute_t     attr;

    sal_memset(&l2_addr, 0, sizeof(sai_fdb_entry_t));
    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_MAC_ADDRESS(&l2_addr.mac_address);
    SAI_CLI_GET_VLAN(l2_addr.vlan_id);
    SAI_CLI_GET_PACKET_ACTION(attr.value.s32);

    attr.id = SAI_FDB_ENTRY_ATTR_PACKET_ACTION;

    ret = sai_api_query(SAI_API_FDB,(void**)&fdb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = fdb_api->set_fdb_entry_attribute(&l2_addr,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }


    return ret;
}

CTC_CLI(cli_sai_fdb_set_fdb_entry_attribute_type,
        cli_sai_fdb_set_fdb_entry_attribute_type_cmd,
        "fdb set-attribute entry (mac MAC) (vlan VLAN) (type (dynamic | static))",
        "Fdb",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        "FDB entry",
        SAI_CLI_MAC_DESC,
        SAI_CLI_MAC_FORMAT,
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC,
        "FDB entry type",
        "Dynamic FDB Entry",
        "Static FDB Entry")
{
    sai_status_t        ret       = SAI_STATUS_SUCCESS;
    sai_fdb_api_t*      fdb_api;
    sai_fdb_entry_t     l2_addr;
    uint8_t             index     = 0xFF;
    sai_attribute_t     attr;

    sal_memset(&l2_addr, 0, sizeof(sai_fdb_entry_t));
    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_MAC_ADDRESS(&l2_addr.mac_address);
    SAI_CLI_GET_VLAN(l2_addr.vlan_id);

    index = CTC_CLI_GET_ARGC_INDEX("static");
    if (0xFF != index)
    {
        attr.value.s32 = SAI_FDB_ENTRY_STATIC;
    }

    index = CTC_CLI_GET_ARGC_INDEX("dynamic");
    if (0xFF != index)
    {
        attr.value.s32 = SAI_FDB_ENTRY_DYNAMIC;
    }

    attr.id = SAI_FDB_ENTRY_ATTR_TYPE;

    ret = sai_api_query(SAI_API_FDB,(void**)&fdb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = fdb_api->set_fdb_entry_attribute(&l2_addr,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }


    return ret;
}

CTC_CLI(cli_sai_fdb_set_fdb_entry_attribute_port_id,
        cli_sai_fdb_set_fdb_entry_attribute_port_id_cmd,
        "fdb set-attribute entry (mac MAC) (vlan VLAN) ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) SAI_OBJ_ID)",
        "Fdb",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        "FDB entry",
        SAI_CLI_MAC_DESC,
        SAI_CLI_MAC_FORMAT,
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC,
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE)
{
    sai_status_t        ret       = SAI_STATUS_SUCCESS;
    sai_fdb_api_t*      fdb_api;
    sai_fdb_entry_t     l2_addr;
    sai_attribute_t     attr;

    sal_memset(&l2_addr, 0, sizeof(sai_fdb_entry_t));
    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_MAC_ADDRESS(&l2_addr.mac_address);
    SAI_CLI_GET_VLAN(l2_addr.vlan_id);
    SAI_CLI_GET_LAG_ID(attr.value.oid);
    SAI_CLI_GET_PORT_ID(attr.value.oid);

    attr.id = SAI_FDB_ENTRY_ATTR_PORT_ID;

    ret = sai_api_query(SAI_API_FDB,(void**)&fdb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = fdb_api->set_fdb_entry_attribute(&l2_addr,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }


    return ret;
}


CTC_CLI(cli_sai_fdb_get_fdb_entry_attribute,
        cli_sai_fdb_get_fdb_entry_attribute_cmd,
        "fdb get-attribute entry (mac MAC) (vlan VLAN) (type| port-id| packet-action)",
        "Fdb",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        "FDB entry",
        SAI_CLI_MAC_DESC,
        SAI_CLI_MAC_FORMAT,
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC,
        "FDB entry type",
        "FDB entry port id",
        "FDB entry packet action")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_fdb_api_t*      fdb_api;
    sai_fdb_entry_t     l2_addr;
    uint32              index;
    sai_attribute_t     attr;
    const char*         sz_action[] = {"Drop","Forward","Trap","Log"};

    sal_memset(&l2_addr, 0, sizeof(sai_fdb_entry_t));
    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    SAI_CLI_GET_MAC_ADDRESS(&l2_addr.mac_address);
    SAI_CLI_GET_VLAN(l2_addr.vlan_id);

    index = CTC_CLI_GET_ARGC_INDEX("type");
    if(index != 0xFF)
    {
        attr.id = SAI_FDB_ENTRY_ATTR_TYPE;
    }

    index = CTC_CLI_GET_ARGC_INDEX("port-id");
    if(index != 0xFF)
    {
        attr.id = SAI_FDB_ENTRY_ATTR_PORT_ID;
    }

    index = CTC_CLI_GET_ARGC_INDEX("packet-action");
    if(index != 0xFF)
    {
        attr.id = SAI_FDB_ENTRY_ATTR_PACKET_ACTION;
    }

    ret = sai_api_query(SAI_API_FDB,(void**)&fdb_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = fdb_api->get_fdb_entry_attribute(&l2_addr,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    switch(attr.id)
    {
        case SAI_FDB_ENTRY_ATTR_TYPE:
            ctc_cli_out("%-20s:%-10s\n","type",attr.value.s32 == SAI_FDB_ENTRY_DYNAMIC ? "dynamic" : "static");
            break;
        case SAI_FDB_ENTRY_ATTR_PORT_ID:
            ctc_cli_out("%-20s:0x%llx\n","port-id",CTC_SAI_OBJECT_INDEX_GET(attr.value.oid));
            break;
        case SAI_FDB_ENTRY_ATTR_PACKET_ACTION:
            ctc_cli_out("%-20s:%-10s\n","packet-action",sz_action[attr.value.s32 % 4]);
            break;
    }


    return ret;
}

extern uint16
ctc_get_port_from_port_unmapping(uint16 gport);

CTC_CLI(cli_sai_fdb_show_fdb_entry,
        cli_sai_fdb_show_fdb_entry_cmd,
        "show sai fdb entry",
        "show command",
        "SAI",
        "fdb",
        "entry")
{
    int32 ret  = CLI_SUCCESS;
    uint32 index = 0;
    ctc_l2_fdb_query_rst_t query_rst;
    uint32 total_count = 0;
    ctc_l2_fdb_query_t Query;
    ctc_l2dflt_addr_t  l2dflt;
    uint16 entry_cnt = 0;
    
    sal_memset(&query_rst, 0, sizeof(ctc_l2_fdb_query_rst_t));
    sal_memset(&Query, 0, sizeof(ctc_l2_fdb_query_t));
    sal_memset(&l2dflt, 0, sizeof(l2dflt));

    Query.query_type = CTC_L2_FDB_ENTRY_OP_ALL;
    Query.query_flag = CTC_L2_FDB_ENTRY_ALL;

    entry_cnt = 100;

    query_rst.buffer_len = sizeof(ctc_l2_addr_t) * entry_cnt;
    query_rst.buffer = (ctc_l2_addr_t*)mem_malloc(MEM_CLI_MODULE, query_rst.buffer_len);
    if (NULL == query_rst.buffer)
    {
        ctc_cli_out("%% Alloc  memory  failed \n");
        return CLI_ERROR;
    }

    sal_memset(query_rst.buffer, 0, query_rst.buffer_len);

    ctc_cli_out("%8s  %14s  %4s %6s\n", "MAC", "FID", "GPORT", "Static");
    ctc_cli_out("-------------------------------------------\n");

    do
    {
        query_rst.start_index = query_rst.next_query_index;

        ret = ctc_l2_get_fdb_entry(&Query, &query_rst);
        if (ret < 0)
        {
            ctc_cli_out("%% %s \n", ctc_get_error_desc(ret));
            mem_free(query_rst.buffer);
            query_rst.buffer = NULL;
            return CLI_ERROR;
        }

        for (index = 0; index < Query.count; index++)
        {
            ctc_cli_out("%.4x.%.4x.%.4x%4s  ", sal_ntohs(*(unsigned short*)&query_rst.buffer[index].mac[0]),
                        sal_ntohs(*(unsigned short*)&query_rst.buffer[index].mac[2]),
                        sal_ntohs(*(unsigned short*)&query_rst.buffer[index].mac[4]),
                        " ");

            ctc_cli_out("%.4d  ", query_rst.buffer[index].fid);
            l2dflt.fid = query_rst.buffer[index].fid;
            ctc_l2_get_default_entry_features(&l2dflt);
            ctc_cli_out("0x%.4x  ", query_rst.buffer[index].gport);
            ctc_cli_out("%s\n", (query_rst.buffer[index].flag & CTC_L2_FLAG_IS_STATIC) ? "Yes" : "No");

            sal_memset(&query_rst.buffer[index], 0, sizeof(ctc_l2_addr_t));
        }

        total_count += Query.count;
        sal_task_sleep(100);

    }
    while (query_rst.is_end == 0);

    ctc_cli_out("-------------------------------------------\n");
    ctc_cli_out("Total Entry Num: %d\n", total_count);

    mem_free(query_rst.buffer);
    query_rst.buffer = NULL;

    return ret;
}


int32
ctc_sai_fdb_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_fdb_create_entry_cmd);
    install_element(cli_tree_mode, &cli_sai_fdb_remove_entry_cmd);
    install_element(cli_tree_mode, &cli_sai_fdb_set_fdb_entry_attribute_type_cmd);
    install_element(cli_tree_mode, &cli_sai_fdb_set_fdb_entry_attribute_port_id_cmd);
    install_element(cli_tree_mode, &cli_sai_fdb_set_fdb_entry_attribute_packet_action_cmd);
    install_element(cli_tree_mode, &cli_sai_fdb_get_fdb_entry_attribute_cmd);
    install_element(cli_tree_mode, &cli_sai_fdb_flush_all_entry_cmd);
    install_element(cli_tree_mode, &cli_sai_fdb_flush_all_entry_by_port_cmd);
    install_element(cli_tree_mode, &cli_sai_fdb_flush_all_entry_by_vlan_cmd);
    install_element(cli_tree_mode, &cli_sai_fdb_flush_all_entry_by_port_vlan_cmd);
    install_element(cli_tree_mode, &cli_sai_fdb_flush_all_entry_by_mac_cmd);
    install_element(cli_tree_mode, &cli_sai_fdb_show_fdb_entry_cmd);

    return CLI_SUCCESS;
}


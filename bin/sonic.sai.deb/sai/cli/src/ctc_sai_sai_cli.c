#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>

CTC_CLI(cli_sai_api_initialize,
        cli_sai_api_initialize_cmd,
        "api initialize",
        "api",
        "initialize")
{
    sai_api_initialize(0,NULL);
    return CLI_SUCCESS;
}

int32
ctc_sai_sai_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_api_initialize_cmd);

    return CLI_SUCCESS;
}

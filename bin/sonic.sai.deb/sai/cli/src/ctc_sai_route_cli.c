#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include <ctc_sai_common.h>

CTC_CLI(cli_sai_route_create,
        cli_sai_route_create_cmd,
        "route create entry (router-id SAI_OBJ_ID) (ip-prefix ((ipv4 A.B.C.D A.B.C.D) | (ipv6 X:X::X:X X:X::X:X)))"
        "set-attribute "
        "(packet-action (drop | forward | trap | log)) "
        "(((next-hop-id | next-hop-group-id) SAI_OBJ_ID)|)",
        "Route",
        "Create",
        "Route entry",
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Ip address prefix",
        SAI_CLI_IPV4_DESC,
        SAI_CLI_IPV4_FORMAT,
        SAI_CLI_IPV4_MASK_FORMAT,
        SAI_CLI_IPV6_DESC,
        SAI_CLI_IPV6_FORMAT,
        SAI_CLI_IPV6_MASK_FORMAT,
        SAI_CLI_SET_ATTRIBUTE_DESC,
        "Packet action (default to SAI_PACKET_ACTION_FORWARD)",
        "Drop Packet",
        "Forward Packet",
        "Trap Packet to CPU",
        "Log (Trap + Forward) Packet",
        SAI_CLI_OBJ_NEXTHOP_ID_DESC,
        SAI_CLI_OBJ_NEXTHOP_GROUP_ID_DESC,
        SAI_CLI_OBJECT_VALUE)
{
    sai_route_api_t* route_api  = NULL;
	sai_object_id_t  nhid = 0;
	sai_attribute_t  attr[2];
    uint32_t         attr_idx = 1;
	sai_unicast_route_entry_t	ukey;
    sai_status_t     ret      = SAI_STATUS_SUCCESS;

	sal_memset(&ukey,0,sizeof(ukey));
	sal_memset(attr, 0, sizeof(attr));

    SAI_CLI_GET_ROUTER_ID(ukey.vr_id);
    SAI_CLI_GET_NEXTHOP_ID(nhid);
    SAI_CLI_GET_NEXTHOP_GROUP_ID(nhid);

	attr[0].id 		  = SAI_ROUTE_ATTR_PACKET_ACTION;

    SAI_CLI_GET_PACKET_ACTION(attr[0].value.s32);

    if(SAI_PACKET_ACTION_FORWARD == attr[0].value.s32
       || SAI_PACKET_ACTION_LOG == attr[0].value.s32)
    {
        attr[1].id 		  = SAI_ROUTE_ATTR_NEXT_HOP_ID;
        attr[1].value.oid = nhid;
        attr_idx++;
    }

    SAI_CLI_GET_SAI_IP_PREFIX_T(&ukey.destination);

    ret = sai_api_query(SAI_API_ROUTE,(void**)&route_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = route_api->create_route(&ukey,attr_idx,attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_route_remove,
        cli_sai_route_remove_cmd,
        "route remove entry (router-id SAI_OBJ_ID) (ip-prefix ((ipv4 A.B.C.D A.B.C.D) | (ipv6 X:X::X:X X:X::X:X))) ",
        "Route",
        "Remove",
        "Route entry",
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Ip address prefix",
        SAI_CLI_IPV4_DESC,
        SAI_CLI_IPV4_FORMAT,
        SAI_CLI_IPV4_MASK_FORMAT,
        SAI_CLI_IPV6_DESC,
        SAI_CLI_IPV6_FORMAT,
        SAI_CLI_IPV6_MASK_FORMAT)
{
    sai_route_api_t*            route_api  = NULL;
	sai_unicast_route_entry_t	ukey;
    sai_status_t                ret   = SAI_STATUS_SUCCESS;

	sal_memset(&ukey,0,sizeof(ukey));

	SAI_CLI_GET_ROUTER_ID(ukey.vr_id);

    SAI_CLI_GET_SAI_IP_PREFIX_T(&ukey.destination);

    ret = sai_api_query(SAI_API_ROUTE,(void**)&route_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = route_api->remove_route(&ukey);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_route_set_attr_action,
        cli_sai_route_set_attr_action_cmd,
        "route set-attribute entry (router-id SAI_OBJ_ID) (ip-prefix ((ipv4 A.B.C.D A.B.C.D) | (ipv6 X:X::X:X X:X::X:X))) "
        "(packet-action (drop | forward | trap | log))",
        "Route",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        "Route entry",
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Ip address prefix",
        SAI_CLI_IPV4_DESC,
        SAI_CLI_IPV4_FORMAT,
        SAI_CLI_IPV4_MASK_FORMAT,
        SAI_CLI_IPV6_DESC,
        SAI_CLI_IPV6_FORMAT,
        SAI_CLI_IPV6_MASK_FORMAT,
        "Packet action (default to SAI_PACKET_ACTION_FORWARD)",
        "Drop Packet",
        "Forward Packet",
        "Trap Packet to CPU",
        "Log (Trap + Forward) Packet")
{
    sai_route_api_t* route_api  = NULL;
	sai_attribute_t  attr;
	sai_unicast_route_entry_t	ukey;
    sai_status_t     ret = SAI_STATUS_SUCCESS;

	sal_memset(&ukey,0,sizeof(ukey));
	sal_memset(&attr, 0, sizeof(attr));

	SAI_CLI_GET_ROUTER_ID(ukey.vr_id);

    SAI_CLI_GET_SAI_IP_PREFIX_T(&ukey.destination);

	attr.id 		  = SAI_ROUTE_ATTR_PACKET_ACTION;
	SAI_CLI_GET_PACKET_ACTION(attr.value.s32);

    ret = sai_api_query(SAI_API_ROUTE,(void**)&route_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = route_api->set_route_attribute(&ukey,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_route_get_attr_action,
        cli_sai_route_get_attr_action_cmd,
        "route get-attribute entry (router-id SAI_OBJ_ID) (ip-prefix ((ipv4 A.B.C.D A.B.C.D) | (ipv6 X:X::X:X X:X::X:X))) packet-action",
        "Route",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        "Route entry",
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Ip address prefix",
        SAI_CLI_IPV4_DESC,
        SAI_CLI_IPV4_FORMAT,
        SAI_CLI_IPV4_MASK_FORMAT,
        SAI_CLI_IPV6_DESC,
        SAI_CLI_IPV6_FORMAT,
        SAI_CLI_IPV6_MASK_FORMAT,
        "Packet action")
{
    sai_route_api_t* route_api  = NULL;
	sai_attribute_t  attr;
	sai_unicast_route_entry_t	ukey;
    sai_status_t     ret = SAI_STATUS_SUCCESS;
    const char*      sz_action[] = {"Drop","Forward","Trap","Log"};

	sal_memset(&ukey,0,sizeof(ukey));
	sal_memset(&attr, 0, sizeof(attr));

	SAI_CLI_GET_ROUTER_ID(ukey.vr_id);

    SAI_CLI_GET_SAI_IP_PREFIX_T(&ukey.destination);

    attr.id = SAI_ROUTE_ATTR_PACKET_ACTION;

    ret = sai_api_query(SAI_API_ROUTE,(void**)&route_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = route_api->get_route_attribute(&ukey,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","packet-action",sz_action[attr.value.s32 % 4]);

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_route_set_attr_nexthop,
        cli_sai_route_set_attr_nexthop_cmd,
        "route set-attribute entry (router-id SAI_OBJ_ID) (ip-prefix ((ipv4 A.B.C.D A.B.C.D) | (ipv6 X:X::X:X X:X::X:X))) "
        "(((next-hop-id | next-hop-group-id) SAI_OBJ_ID)|)",
        "Route",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        "Route entry",
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Ip address prefix",
        SAI_CLI_IPV4_DESC,
        SAI_CLI_IPV4_FORMAT,
        SAI_CLI_IPV4_MASK_FORMAT,
        SAI_CLI_IPV6_DESC,
        SAI_CLI_IPV6_FORMAT,
        SAI_CLI_IPV6_MASK_FORMAT,
        SAI_CLI_OBJ_NEXTHOP_ID_DESC,
        SAI_CLI_OBJ_NEXTHOP_GROUP_ID_DESC,
        SAI_CLI_OBJECT_VALUE)
{
    sai_route_api_t* route_api  = NULL;
	sai_object_id_t  nhid       = 0;
	sai_attribute_t  attr;
	sai_unicast_route_entry_t	ukey;
    sai_status_t     ret = SAI_STATUS_SUCCESS;

	sal_memset(&ukey,0,sizeof(ukey));
	sal_memset(&attr, 0, sizeof(attr));

	SAI_CLI_GET_ROUTER_ID(ukey.vr_id);

    SAI_CLI_GET_SAI_IP_PREFIX_T(&ukey.destination);

    SAI_CLI_GET_NEXTHOP_ID(nhid);
    SAI_CLI_GET_NEXTHOP_GROUP_ID(nhid);

    attr.id 		  = SAI_ROUTE_ATTR_NEXT_HOP_ID;
    attr.value.oid    = nhid;

    ret = sai_api_query(SAI_API_ROUTE,(void**)&route_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = route_api->set_route_attribute(&ukey,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}


int32
ctc_sai_route_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_route_create_cmd);
    install_element(cli_tree_mode, &cli_sai_route_remove_cmd);
    install_element(cli_tree_mode, &cli_sai_route_set_attr_action_cmd);
    install_element(cli_tree_mode, &cli_sai_route_get_attr_action_cmd);
    install_element(cli_tree_mode, &cli_sai_route_set_attr_nexthop_cmd);

    return CLI_SUCCESS;
}

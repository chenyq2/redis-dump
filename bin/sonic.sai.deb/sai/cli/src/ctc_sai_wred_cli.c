#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include "ctc_const.h"
#include "ctc_sai_wred.h"
#include <ctc_sai_common.h>
#include "ctc_cli_common.h"



CTC_CLI(cli_sai_wred_create_wred,
        cli_sai_wred_create_wred_cmd,
        "wred create-profile ((green-enable (green-max-threshold GREEN-MAX  green-drop-probability DROP-PROB))|) ((yellow-enable (yellow-max-threshold YELLOW-MAX  yellow-drop-probability DROP-PROB))|) ((red-enable (red-max-threshold RED-MAX  red-drop-probability DROP-PROB))|)",
        "WRED",
        "Creat profile",
        "Green enable",
        "Green max threshold",
        "Green max threshold value <0 -32767>",
        "Green drop probability",
        "Green drop probability value <0 - 100>",
        "Yellow enable",
        "Yellow max threshold",
        "Yellow max threshold value <0 -32767>",
        "Yellow drop probability",
        "Yellow drop probability value <0 - 100>",
        "Red enable",
        "Red max threshold",
        "Red max threshold value <0 -32767>",
        "Red drop probability",
        "Red drop probability value <0 - 100>")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint8 index = 0xFF;
    sai_object_id_t wred_id;
    sai_wred_api_t*  wred_api;
    sai_attribute_t attr[15] = {{0}};
    uint32_t attr_count = 0;

    index = CTC_CLI_GET_ARGC_INDEX("green-enable");
    if(0xFF != index)
    {
        attr[attr_count].id = SAI_WRED_ATTR_GREEN_ENABLE;
        attr[attr_count].value.booldata = TRUE;
        attr_count ++;

        attr[attr_count].id = SAI_WRED_ATTR_GREEN_MAX_THRESHOLD;
        CTC_CLI_GET_UINT32_RANGE("green-max-threshold", attr[attr_count].value.s32, argv[index + 2], 0, 32767);
        attr_count ++;

        attr[attr_count].id = SAI_WRED_ATTR_GREEN_DROP_PROBABILITY;
        CTC_CLI_GET_UINT32_RANGE("green-drop-probability", attr[attr_count].value.s32, argv[index + 4], 0, 100);
        attr_count ++;
    }

    index = CTC_CLI_GET_ARGC_INDEX("yellow-enable");
    if(0xFF != index)
    {
        attr[attr_count].id = SAI_WRED_ATTR_YELLOW_ENABLE;
        attr[attr_count].value.booldata = TRUE;
        attr_count ++;

        attr[attr_count].id = SAI_WRED_ATTR_YELLOW_MAX_THRESHOLD;
        CTC_CLI_GET_UINT32_RANGE("yellow-max-threshold", attr[attr_count].value.s32, argv[index + 2], 0, 32767);
        attr_count ++;

        attr[attr_count].id = SAI_WRED_ATTR_YELLOW_DROP_PROBABILITY;
        CTC_CLI_GET_UINT32_RANGE("yellow-drop-probability", attr[attr_count].value.s32, argv[index + 4],0,100);
        attr_count ++;
    }

    index = CTC_CLI_GET_ARGC_INDEX("red-enable");
    if(0xFF != index)
    {
        attr[attr_count].id = SAI_WRED_ATTR_RED_ENABLE;
        attr[attr_count].value.booldata = TRUE;
        attr_count ++;

        attr[attr_count].id = SAI_WRED_ATTR_RED_MAX_THRESHOLD;
        CTC_CLI_GET_UINT32_RANGE("red-max-threshold", attr[attr_count].value.s32, argv[index + 2], 0, 32767);
        attr_count ++;

        attr[attr_count].id = SAI_WRED_ATTR_RED_DROP_PROBABILITY;
        CTC_CLI_GET_UINT32_RANGE("red-drop-prob-probability", attr[attr_count].value.s32, argv[index + 4],0,100);
        attr_count ++;
    }
    if(0 ==attr_count)
    {
        return CLI_SUCCESS;
    }
    ret = sai_api_query(SAI_API_WRED,(void**)&wred_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = wred_api->create_wred_profile(&wred_id,attr_count,attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:0x%-10llx\n","wred id",CTC_SAI_OBJECT_INDEX_GET(wred_id));

    return ret;
}

CTC_CLI(cli_sai_wred_remove_wred,
        cli_sai_wred_remove_wred_cmd,
        "wred remove-profile WRED-ID",
        "Wred",
        "Remove profile",
        "Wred id value")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint32_t     wred_id = 0;
    sai_object_id_t wred_oid;
    sai_wred_api_t*  wred_api;


    CTC_CLI_GET_UINT32("wred_id", wred_id, argv[0]);

    wred_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_WRED, wred_id);

    ret = sai_api_query(SAI_API_WRED,(void**)&wred_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = wred_api->remove_wred_profile(wred_oid);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_wred_set_wred_attribute,
        cli_sai_wred_set_wred_attribute_cmd,
        "wred set-attribute wred-id WRED-ID ((green-enable|green-disable) | (green-max-threshold GREEN-MAX ) | (green-drop-probability DROP-PROB)|(yellow-enable|yellow-disable) | (yellow-max-threshold GREEN-MAX ) | (yellow-drop-probability DROP-PROB)|(red-enable|red-disable) | (red-max-threshold GREEN-MAX ) | (red-drop-probability DROP-PROB))",
        "WRED",
        "Update wred attribute",
        "Wred id",
        "Wred id value",
        "Green enable",
        "Green disable",
        "Green max threshold",
        "Green max threshold value <0 -32767>",
        "Green drop probability",
        "Green drop probability value <0 - 100>",
        "Yellow enable",
        "Yellow disable",
        "Yellow max threshold",
        "Yellow max threshold value <0 -32767>",
        "Yellow drop probability",
        "Yellow drop probability value <0 - 100>",
        "Red enable",
        "Red disable",
        "Red max threshold",
        "Red max threshold value <0 -32767>",
        "Red drop probability",
        "Red drop probability value <0 - 100>")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint8 index = 0xFF;
    uint32_t ctc_wred_id;
    sai_object_id_t wred_id;
    sai_wred_api_t*  wred_api;
    sai_attribute_t attr = {0};

    CTC_CLI_GET_UINT32("wred_id", ctc_wred_id, argv[0]);
    wred_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_WRED, ctc_wred_id);


    index = CTC_CLI_GET_ARGC_INDEX("green-enable");
    if(0xFF != index)
    {
        attr.id = SAI_WRED_ATTR_GREEN_ENABLE;
        attr.value.booldata = TRUE;
    }

    index = CTC_CLI_GET_ARGC_INDEX("green-disable");
    if(0xFF != index)
    {
        attr.id = SAI_WRED_ATTR_GREEN_ENABLE;
        attr.value.booldata = FALSE;
    }

    index = CTC_CLI_GET_ARGC_INDEX("green-max-threshold");
    if(0xFF != index)
    {
        attr.id = SAI_WRED_ATTR_GREEN_MAX_THRESHOLD;
        CTC_CLI_GET_UINT32_RANGE("green-max-threshold", attr.value.s32, argv[index + 1], 0, 32767);
    }

    index = CTC_CLI_GET_ARGC_INDEX("green-drop-probability");
    if(0xFF != index)
    {
        attr.id = SAI_WRED_ATTR_GREEN_DROP_PROBABILITY;
        CTC_CLI_GET_UINT32_RANGE("green-drop-probability", attr.value.s32, argv[index + 1],0,100);
    }

    index = CTC_CLI_GET_ARGC_INDEX("yellow-enable");
    if(0xFF != index)
    {
        attr.id = SAI_WRED_ATTR_YELLOW_ENABLE;
        attr.value.booldata = TRUE;
    }

    index = CTC_CLI_GET_ARGC_INDEX("yellow-disable");
    if(0xFF != index)
    {
        attr.id = SAI_WRED_ATTR_YELLOW_ENABLE;
        attr.value.booldata = FALSE;
    }

    index = CTC_CLI_GET_ARGC_INDEX("yellow-max-threshold");
    if(0xFF != index)
    {
        attr.id = SAI_WRED_ATTR_YELLOW_MAX_THRESHOLD;
        CTC_CLI_GET_UINT32_RANGE("yellow-max-threshold", attr.value.s32, argv[index + 1], 0, 32767);
    }

    index = CTC_CLI_GET_ARGC_INDEX("yellow-drop-probability");
    if(0xFF != index)
    {
        attr.id = SAI_WRED_ATTR_YELLOW_DROP_PROBABILITY;
        CTC_CLI_GET_UINT32_RANGE("yellow-drop-probability", attr.value.s32, argv[index + 1],0,100);
    }
    

    index = CTC_CLI_GET_ARGC_INDEX("red-enable");
    if(0xFF != index)
    {
        attr.id = SAI_WRED_ATTR_RED_ENABLE;
        attr.value.booldata = TRUE;
    }

    index = CTC_CLI_GET_ARGC_INDEX("red-disable");
    if(0xFF != index)
    {
        attr.id = SAI_WRED_ATTR_RED_ENABLE;
        attr.value.booldata = FALSE;
    }

    index = CTC_CLI_GET_ARGC_INDEX("red-max-threshold");
    if(0xFF != index)
    {
        attr.id = SAI_WRED_ATTR_RED_MAX_THRESHOLD;
        CTC_CLI_GET_UINT32_RANGE("red-max-threshold", attr.value.s32, argv[index + 1], 0, 32767);
    }

    index = CTC_CLI_GET_ARGC_INDEX("red-drop-probability");
    if(0xFF != index)
    {
        attr.id = SAI_WRED_ATTR_RED_DROP_PROBABILITY;
        CTC_CLI_GET_UINT32_RANGE("red-drop-probability", attr.value.s32, argv[index + 1],0,100);
    }
    
    ret = sai_api_query(SAI_API_WRED,(void**)&wred_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }


    ret = wred_api->set_wred_attribute(wred_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_wred_get_wred_attribute,
        cli_sai_wred_get_wred_attribute_cmd,
        "wred get-attribute wred-id WRED-ID ((green-enable) | (green-max-threshold) | (green-drop-probability)|(yellow-enable) | (yellow-max-threshold) | (yellow-drop-probability)|(red-enable) | (red-max-threshold) | (red-drop-probability) |)",
        "WRED",
        "Get wred attribute",
        "Wred id",
        "Wred id value",
        "Green enable",
        "Green disable",
        "Green max threshold",
        "Green drop probability",
        "Yellow enable",
        "Yellow max threshold",
        "Yellow drop probability",
        "Red enable",
        "Red max threshold",
        "Red drop probability"
        )
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint8 index = 0xFF;
    uint32_t ctc_wred_id;
    sai_object_id_t wred_id;
    sai_wred_api_t*  wred_api;
    uint32_t attr_count = 0;
    sai_attribute_t attr[15];
    char *enable[2] = {"disable", "enable"};

    sal_memset(attr, 0x0, (sizeof(sai_attribute_t))*15);
    CTC_CLI_GET_UINT32("wred_id", ctc_wred_id, argv[0]);
    wred_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_WRED, ctc_wred_id);

    if(argc > 1)
    {
        index = CTC_CLI_GET_ARGC_INDEX("green-enable");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_WRED_ATTR_GREEN_ENABLE;
        }
        index = CTC_CLI_GET_ARGC_INDEX("green-max-threshold");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_WRED_ATTR_GREEN_MAX_THRESHOLD;
        }
        index = CTC_CLI_GET_ARGC_INDEX("green-drop-probability");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_WRED_ATTR_GREEN_DROP_PROBABILITY;
        }
        index = CTC_CLI_GET_ARGC_INDEX("yellow-enable");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_WRED_ATTR_YELLOW_ENABLE;
        }
        index = CTC_CLI_GET_ARGC_INDEX("yellow-max-threshold");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_WRED_ATTR_YELLOW_MAX_THRESHOLD;
        }
        index = CTC_CLI_GET_ARGC_INDEX("yellow-drop-probability");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_WRED_ATTR_YELLOW_DROP_PROBABILITY;
        }
        index = CTC_CLI_GET_ARGC_INDEX("red-enable");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_WRED_ATTR_RED_ENABLE;
        }
        index = CTC_CLI_GET_ARGC_INDEX("red-max-threshold");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_WRED_ATTR_RED_MAX_THRESHOLD;
        }
        index = CTC_CLI_GET_ARGC_INDEX("red-drop-probability");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_WRED_ATTR_RED_DROP_PROBABILITY;
        }
        attr_count ++;
        
        ret = sai_api_query(SAI_API_WRED,(void**)&wred_api);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        ret = wred_api->get_wred_attribute(wred_id, attr_count, attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
        
        switch(attr[0].id)
        {
            case SAI_WRED_ATTR_GREEN_ENABLE:
                ctc_cli_out("%s: %s \n", "green", enable[attr[0].value.booldata]);
                break;
            case SAI_WRED_ATTR_GREEN_MIN_THRESHOLD:
                ctc_cli_out("%s: %d \n", "green-min-threshold", attr[0].value.s32);
                break;
            case SAI_WRED_ATTR_GREEN_MAX_THRESHOLD:
                ctc_cli_out("%s: %d \n", "green-max-threshold", attr[0].value.s32);
                break;
            case SAI_WRED_ATTR_GREEN_DROP_PROBABILITY:
                ctc_cli_out("%s: %d \n", "green-drop-probability", attr[0].value.s32);
                break;
            case SAI_WRED_ATTR_YELLOW_ENABLE:
                ctc_cli_out("%s: %s \n", "yellow", enable[attr[0].value.booldata]);
                break;
            case SAI_WRED_ATTR_YELLOW_MIN_THRESHOLD:
                ctc_cli_out("%s: %d \n", "yellow-min-threshold", attr[0].value.s32);
                break;
            case SAI_WRED_ATTR_YELLOW_MAX_THRESHOLD:
                ctc_cli_out("%s: %d \n", "yellow-max-threshold", attr[0].value.s32);
                break;
            case SAI_WRED_ATTR_YELLOW_DROP_PROBABILITY:
                ctc_cli_out("%s: %d \n", "yellow-drop-probability", attr[0].value.s32);
                break;
            case SAI_WRED_ATTR_RED_ENABLE:
                ctc_cli_out("%s: %s \n", "red", enable[attr[0].value.booldata]);
                break;
            case SAI_WRED_ATTR_RED_MIN_THRESHOLD:
                ctc_cli_out("%s: %d \n", "red-min-threshold", attr[0].value.s32);
                break;
            case SAI_WRED_ATTR_RED_MAX_THRESHOLD:
                ctc_cli_out("%s: %d \n", "red-max-threshold", attr[0].value.s32);
                break;
            case SAI_WRED_ATTR_RED_DROP_PROBABILITY:
                ctc_cli_out("%s: %d \n", "red-drop-probability", attr[0].value.s32);
                break;
            default:
                break;
        }
    }
    else
    {
        attr[attr_count].id = SAI_WRED_ATTR_GREEN_ENABLE;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_GREEN_MIN_THRESHOLD;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_GREEN_MAX_THRESHOLD;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_GREEN_DROP_PROBABILITY;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_YELLOW_ENABLE;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_YELLOW_MIN_THRESHOLD;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_YELLOW_MAX_THRESHOLD;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_YELLOW_DROP_PROBABILITY;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_RED_ENABLE;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_RED_MIN_THRESHOLD;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_RED_MAX_THRESHOLD;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_RED_DROP_PROBABILITY;
        attr_count++;
        
        ret = sai_api_query(SAI_API_WRED,(void**)&wred_api);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        ret = wred_api->get_wred_attribute(wred_id, attr_count, attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        ctc_cli_out("%-16s %-15s %-15s %-15s\n","color-enable", "min-threshold", "max-threshold", "drop-probability");
        ctc_cli_out("%-6s %-10s %-15d %-15d %-15d\n","green",enable[attr[0].value.booldata], attr[2].value.s32/8, attr[2].value.s32, attr[3].value.s32);
        ctc_cli_out("%-6s %-10s %-15d %-15d %-15d\n","yellow",enable[attr[4].value.booldata], attr[6].value.s32/8, attr[6].value.s32, attr[7].value.s32);
        ctc_cli_out("%-6s %-10s %-15d %-15d %-15d\n","red",enable[attr[8].value.booldata], attr[10].value.s32/8, attr[10].value.s32, attr[11].value.s32);
    }
    return ret;
}


extern ctc_sai_wred_info_t g_sai_wred_info;

static int32
_ctc_sai_show_wred_profile(ctc_sai_wred_t* pst_wred, void* data)
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint32_t           ctc_wred_id = 0; 
    sai_object_id_t    wred_id;
    sai_wred_api_t*    wred_api;
    uint32_t           attr_count = 0;
    sai_attribute_t    attr[15];
    char *enable[2] = {"disable", "enable"};

    if(NULL == pst_wred)
        return 0;

    ctc_wred_id = pst_wred->wred_id;
    wred_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_WRED, ctc_wred_id);
    sal_memset(attr, 0x0, (sizeof(sai_attribute_t))*15);

    ret = sai_api_query(SAI_API_WRED,(void**)&wred_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    attr[attr_count].id = SAI_WRED_ATTR_GREEN_ENABLE;
    attr_count++;
    attr[attr_count].id = SAI_WRED_ATTR_GREEN_MIN_THRESHOLD;
    attr_count++;
    attr[attr_count].id = SAI_WRED_ATTR_GREEN_MAX_THRESHOLD;
    attr_count++;
    attr[attr_count].id = SAI_WRED_ATTR_GREEN_DROP_PROBABILITY;
    attr_count++;
    attr[attr_count].id = SAI_WRED_ATTR_YELLOW_ENABLE;
    attr_count++;
    attr[attr_count].id = SAI_WRED_ATTR_YELLOW_MIN_THRESHOLD;
    attr_count++;
    attr[attr_count].id = SAI_WRED_ATTR_YELLOW_MAX_THRESHOLD;
    attr_count++;
    attr[attr_count].id = SAI_WRED_ATTR_YELLOW_DROP_PROBABILITY;
    attr_count++;
    attr[attr_count].id = SAI_WRED_ATTR_RED_ENABLE;
    attr_count++;
    attr[attr_count].id = SAI_WRED_ATTR_RED_MIN_THRESHOLD;
    attr_count++;
    attr[attr_count].id = SAI_WRED_ATTR_RED_MAX_THRESHOLD;
    attr_count++;
    attr[attr_count].id = SAI_WRED_ATTR_RED_DROP_PROBABILITY;
    attr_count++;

    ret = wred_api->get_wred_attribute(wred_id, attr_count, attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s%d \n", "Can't get profile imform of wred id: ",ctc_wred_id);
        return CLI_SUCCESS;
    }

    ctc_cli_out("%s: %d\n", "Ctc Wred-id", ctc_wred_id);
    ctc_cli_out("%-16s %-15s %-15s %-15s\n","color-enable", "min-threshold", "max-threshold", "drop-probability");
    ctc_cli_out("%-6s %-10s %-15d %-15d %-15d\n","green",enable[attr[0].value.booldata], attr[2].value.s32/8, attr[2].value.s32, attr[3].value.s32);
    ctc_cli_out("%-6s %-10s %-15d %-15d %-15d\n","yellow",enable[attr[4].value.booldata], attr[6].value.s32/8, attr[6].value.s32, attr[7].value.s32);
    ctc_cli_out("%-6s %-10s %-15d %-15d %-15d\n","red",enable[attr[8].value.booldata], attr[10].value.s32/8, attr[10].value.s32, attr[11].value.s32);
    
    return 0;
}

CTC_CLI(cli_sai_wred_show_wred,
        cli_sai_wred_show_wred_cmd,
        "show sai wred profile (WRED-ID|)",
        "show command",
        "SAI",
        "WRED",
        "Profile",
        "Wred id value"
        )
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint32_t ctc_wred_id;
    sai_object_id_t wred_id;
    sai_wred_api_t*  wred_api;
    uint32_t attr_count = 0;
    sai_attribute_t attr[15];
    char *enable[2] = {"disable", "enable"};

    sal_memset(attr, 0x0, (sizeof(sai_attribute_t))*15);

    ret = sai_api_query(SAI_API_WRED,(void**)&wred_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    if(argc == 1)
    {
        CTC_CLI_GET_UINT32("wred_id", ctc_wred_id, argv[0]);
        wred_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_WRED, ctc_wred_id);
        attr[attr_count].id = SAI_WRED_ATTR_GREEN_ENABLE;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_GREEN_MIN_THRESHOLD;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_GREEN_MAX_THRESHOLD;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_GREEN_DROP_PROBABILITY;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_YELLOW_ENABLE;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_YELLOW_MIN_THRESHOLD;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_YELLOW_MAX_THRESHOLD;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_YELLOW_DROP_PROBABILITY;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_RED_ENABLE;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_RED_MIN_THRESHOLD;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_RED_MAX_THRESHOLD;
        attr_count++;
        attr[attr_count].id = SAI_WRED_ATTR_RED_DROP_PROBABILITY;
        attr_count++;

        ret = wred_api->get_wred_attribute(wred_id, attr_count, attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s%d \n", "Can't get profile imform of wred id: ",ctc_wred_id);
            return CLI_SUCCESS;
        }

        ctc_cli_out("%s: %d\n", "Ctc Wred-id", ctc_wred_id);
        ctc_cli_out("%-16s %-15s %-15s %-15s\n","color-enable", "min-threshold", "max-threshold", "drop-probability");
        ctc_cli_out("%-6s %-10s %-15d %-15d %-15d\n","green",enable[attr[0].value.booldata], attr[2].value.s32/8, attr[2].value.s32, attr[3].value.s32);
        ctc_cli_out("%-6s %-10s %-15d %-15d %-15d\n","yellow",enable[attr[4].value.booldata], attr[6].value.s32/8, attr[6].value.s32, attr[7].value.s32);
        ctc_cli_out("%-6s %-10s %-15d %-15d %-15d\n","red",enable[attr[8].value.booldata], attr[10].value.s32/8, attr[10].value.s32, attr[11].value.s32);

    }
    else
    {
        ctc_vector_traverse(g_sai_wred_info.pvector, (vector_traversal_fn)_ctc_sai_show_wred_profile, NULL);
    }

    return CLI_SUCCESS;
}


int32
ctc_sai_wred_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_wred_create_wred_cmd);
    install_element(cli_tree_mode, &cli_sai_wred_remove_wred_cmd);
    install_element(cli_tree_mode, &cli_sai_wred_set_wred_attribute_cmd);
    install_element(cli_tree_mode, &cli_sai_wred_get_wred_attribute_cmd);
    install_element(cli_tree_mode, &cli_sai_wred_show_wred_cmd);

    return CLI_SUCCESS;
}

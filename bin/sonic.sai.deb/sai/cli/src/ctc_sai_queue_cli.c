#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include "ctc_const.h"
#include <ctc_sai_common.h>
#include "ctc_cli_common.h"



CTC_CLI(cli_sai_queue_set_queue_wred_profile,
        cli_sai_queue_set_queue_wred_profile_cmd,
        "queue QUEUE_ID wred ((enable (wred-id WRED-ID))|disable)",
        "queue",
        "queue id",
        "Wred",
        "Wred en",
        "Wred id",
        "Wred id value",
        "Wred disable")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_queue_api_t*     queue_api;
    uint32_t            queue_id = 0;
    uint32_t            wred_id = 0;
    sai_object_id_t     queue_oid = 0;
    sai_attribute_t     attr;
    uint8 index = 0xFF;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    CTC_CLI_GET_UINT32_RANGE("queue-id", queue_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    queue_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_QUEUE, queue_id);

    index = CTC_CLI_GET_ARGC_INDEX("wred-id");
    if(0xFF != index)
    {
        CTC_CLI_GET_UINT32_RANGE("wred-id", wred_id, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
        attr.id = SAI_QUEUE_ATTR_WRED_PROFILE_ID;
        attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_QUEUE,wred_id);
    }
    else
    {
        wred_id = 0;
        attr.id = SAI_QUEUE_ATTR_WRED_PROFILE_ID;
        attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_QUEUE,wred_id);
    }

    ret = sai_api_query(SAI_API_QUEUE,(void**)&queue_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = queue_api->set_queue_attribute(queue_oid,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    return ret;
}

CTC_CLI(cli_sai_queue_set_queue_wred_mode,
        cli_sai_queue_set_queue_wred_mode_cmd,
        "queue QUEUE_ID wred-mode (WTD|WRED)",
        "queue",
        "queue id",
        "Wred mode",
        "WTD",
        "WRED")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_queue_api_t*     queue_api;
    uint32_t            queue_id = 0;
    sai_object_id_t     queue_oid = 0;
    sai_attribute_t     attr;
//    uint8 index = 0xFF;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    CTC_CLI_GET_UINT32_RANGE("queue-id", queue_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    queue_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_QUEUE, queue_id);

//    index = CTC_CLI_GET_ARGC_INDEX("WTD");
    attr.id = SAI_QUEUE_ATTR_WRED_PROFILE_ID;

    ret = sai_api_query(SAI_API_QUEUE, (void**)&queue_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = queue_api->set_queue_attribute(queue_oid, &attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    return ret;
}

CTC_CLI(cli_sai_queue_set_queue_scheduler_profile,
        cli_sai_queue_set_queue_scheduler_profile_cmd,
        "queue QUEUE_ID scheduler ((enable (scheduler-id SCHEDULER-ID))|disable)",
        "queue",
        "queue id",
        "Scheduler",
        "Scheduler en",
        "Scheduler id",
        "Scheduler id value",
        "Scheduler disable")
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_queue_api_t*     queue_api;
    uint32_t            queue_id = 0;
    uint32_t            scheduler_id = 0;
    sai_object_id_t     queue_oid = 0;
    sai_attribute_t     attr;
    uint8 index = 0xFF;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    CTC_CLI_GET_UINT32_RANGE("queue-id", queue_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    queue_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_QUEUE, queue_id);

    index = CTC_CLI_GET_ARGC_INDEX("scheduler-id");
    if(0xFF != index)
    {
        CTC_CLI_GET_UINT32_RANGE("wred-id", scheduler_id, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
        attr.id = SAI_QUEUE_ATTR_SCHEDULER_PROFILE_ID;
        attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_QUEUE,scheduler_id);
    }
    else
    {
        scheduler_id = 0;
        attr.id = SAI_QUEUE_ATTR_SCHEDULER_PROFILE_ID;
        attr.value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_QUEUE,scheduler_id);
    }

    ret = sai_api_query(SAI_API_QUEUE,(void**)&queue_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = queue_api->set_queue_attribute(queue_oid,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    return ret;
}

CTC_CLI(cli_sai_queue_get_queue_wred_profile,
        cli_sai_queue_get_queue_wred_profile_cmd,
        "queue QUEUE_ID get wred-profile-id",
        "queue",
        "queue id",
        "Get",
        "wred-profile-id"
        )
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_queue_api_t*     queue_api;
    uint32_t            queue_id = 0;
    sai_object_id_t     queue_oid = 0;
    sai_attribute_t     attr;

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    CTC_CLI_GET_UINT32_RANGE("queue-id", queue_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    queue_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_QUEUE, queue_id);

    attr.id = SAI_QUEUE_ATTR_WRED_PROFILE_ID;
   
    ret = sai_api_query(SAI_API_QUEUE,(void**)&queue_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = queue_api->get_queue_attribute(queue_oid,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%s : %"PRIu64"\n", "wred-profile-id", CTC_SAI_OBJECT_INDEX_GET(attr.value.oid));
    return ret;
}

CTC_CLI(cli_sai_queue_get_queue_wred_type,
        cli_sai_queue_get_queue_wred_type_cmd,
        "queue QUEUE_ID get wred-drop-type",
        "queue",
        "queue id",
        "Get",
        "wred-profile-type"
        )
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_queue_api_t*     queue_api;
    uint32_t            queue_id = 0;
    sai_object_id_t     queue_oid = 0;
    sai_attribute_t     attr;
    char* drop_type[2] = {"Tail", "Wred"};

    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    CTC_CLI_GET_UINT32_RANGE("queue-id", queue_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    queue_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_QUEUE, queue_id);

    attr.id = SAI_QUEUE_ATTR_DROP_TYPE;
   
    ret = sai_api_query(SAI_API_QUEUE,(void**)&queue_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = queue_api->get_queue_attribute(queue_oid,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%s : %s\n", "wred-drop-type", drop_type[attr.value.s32]);
    return ret;
}

CTC_CLI(cli_sai_queue_get_queue_scheduler_profile_id,
        cli_sai_queue_get_queue_scheduler_profile_id_cmd,
        "queue QUEUE_ID get scheduler-profile-id",
        "queue",
        "queue id",
        "Get",
        "scheduler-profile-id"
        )
{
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_queue_api_t*     queue_api;
    uint32_t            queue_id = 0;
    sai_object_id_t     queue_oid = 0;
    sai_attribute_t     attr;
    sal_memset(&attr, 0, sizeof(sai_attribute_t));

    CTC_CLI_GET_UINT32_RANGE("queue-id", queue_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    queue_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_QUEUE, queue_id);

    attr.id = SAI_QUEUE_ATTR_SCHEDULER_PROFILE_ID;
   
    ret = sai_api_query(SAI_API_QUEUE,(void**)&queue_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = queue_api->get_queue_attribute(queue_oid,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%s : %"PRIu64"\n", "scheduler_profile_id", CTC_SAI_OBJECT_INDEX_GET(attr.value.oid));
    return ret;
}

CTC_CLI(cli_sai_policer_get_queue_statistics,
        cli_sai_policer_get_queue_statistics_cmd,
        "queue get-statistics queue-id QUEUE-ID",
        "QUEUE",
        "Get queue statistics",
        "queue-id",
        "queue-id value"
        )
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    //uint8 index = 0xFF;
    sai_object_id_t queue_id;
    uint32_t ctc_queue_id = 0;
    sai_queue_api_t*  queue_api;
    sai_queue_stat_counter_t counter_ids[4];
    uint32_t number_of_counters = 0;;
    uint64_t counters[4];

    sal_memset(&counters, 0x0,(sizeof(uint64_t))*4);
    sal_memset(&counter_ids, 0x0,(sizeof(sai_policer_stat_counter_t))*4);
    CTC_CLI_GET_UINT32("queue_id", ctc_queue_id, argv[0]);
    queue_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_QUEUE, ctc_queue_id);

    counter_ids[number_of_counters] = SAI_QUEUE_STAT_PACKETS;
    number_of_counters ++;
    counter_ids[number_of_counters] = SAI_QUEUE_STAT_BYTES;
    number_of_counters ++;
    counter_ids[number_of_counters] = SAI_QUEUE_STAT_DROPPED_PACKETS;
    number_of_counters ++;
    counter_ids[number_of_counters] = SAI_QUEUE_STAT_DROPPED_BYTES;
    number_of_counters ++;

    ret = sai_api_query(SAI_API_QUEUE,(void**)&queue_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = queue_api->get_queue_stats(queue_id, counter_ids, number_of_counters, counters);

    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ctc_cli_out("%-20s: %-15llu\n","queue-stat-packet", counters[0]);
    ctc_cli_out("%-20s: %-15llu\n","queue-stat-bytes", counters[1]);
    ctc_cli_out("%-30s: %-15llu\n","queue-stat-dropped-packets", counters[2]);
    ctc_cli_out("%-30s: %-15llu\n","queue-stat-dropped-bytes", counters[3]);
    return ret;
}

int32
ctc_sai_queue_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_queue_set_queue_wred_profile_cmd);
    install_element(cli_tree_mode, &cli_sai_queue_set_queue_wred_mode_cmd);
    install_element(cli_tree_mode, &cli_sai_queue_set_queue_scheduler_profile_cmd);

    install_element(cli_tree_mode, &cli_sai_queue_get_queue_wred_profile_cmd);
    install_element(cli_tree_mode, &cli_sai_queue_get_queue_wred_type_cmd);
    install_element(cli_tree_mode, &cli_sai_queue_get_queue_scheduler_profile_id_cmd);
    install_element(cli_tree_mode, &cli_sai_policer_get_queue_statistics_cmd);
    
    return CLI_SUCCESS;
}

#include <sai.h>
#include "sal.h"
#include "ctc_cli.h"
#include "ctc_sai_cli.h"
#include "ctc_sai_isolation.h"
#include "ctc_sai_common.h"
#include "ctc_api.h"

CTC_CLI(cli_sai_isolation_create,
        cli_sai_isolation_create_cmd,
        "isolation create group",
        "Isolation",
        "Create one isolation group",
        "Isolation group")
{
    uint32_t            isolation_id = 0;
    sai_object_id_t     isolation_oid = 0;
    sai_isolation_api_t *api = NULL;
    sai_attribute_t     *attr_list = NULL;
    uint32_t            attr_count = 0;
    sai_status_t     ret = SAI_STATUS_SUCCESS;

    ret = sai_api_query(SAI_API_ISOLATION,(void**)&api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = api->create_isolation_group(&isolation_oid, attr_count, attr_list);
    if (SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    isolation_id = CTC_SAI_OBJECT_INDEX_GET(isolation_oid);
    ctc_cli_out("isolation_id = %u \n", isolation_id);

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_isolation_remove,
        cli_sai_isolation_remove_cmd,
        "isolation remove group ISOLATION_ID",
        "Isolation",
        "Remove one isolation group",
        "Isolation group",
        "Isolation group ID")
{
    uint32_t            isolation_id = 0;
    sai_object_id_t     isolation_oid = 0;
    sai_isolation_api_t* api = NULL;
    sai_status_t     ret = SAI_STATUS_SUCCESS;

    ret = sai_api_query(SAI_API_ISOLATION,(void**)&api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    CTC_CLI_GET_UINT32_RANGE("isolation-id", isolation_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
    isolation_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ISOLATION_GROUP, isolation_id);
    
    ret = sai_api_query(SAI_API_ISOLATION,(void**)&api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = api->remove_isolation_group(isolation_oid);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

int32
cli_sai_isolation_get_show(sai_object_id_t isolation_oid, uint32 attr_count, sai_attribute_t *attr_list)
{
    sai_attribute_t *attr_drop_type = &attr_list[0];
    sai_attribute_t *attr_mode = &attr_list[1];
    sai_attribute_t *attr_ingress = &attr_list[2];
    sai_attribute_t *attr_egress = &attr_list[3];
    sai_object_id_t port_oid = 0;
    int32 i = 0;
    
    ctc_cli_out("Isolation ID: %u\n", CTC_SAI_OBJECT_INDEX_GET(isolation_oid));

    ctc_cli_out("Drop Type: %d\n", attr_drop_type->value.s32);
    ctc_cli_out("Mode: %d\n", attr_mode->value.s32);
    ctc_cli_out("Ingress Ports:  ");
    for (i = 0; i < attr_ingress->value.objlist.count; i++)
    {
        port_oid = attr_ingress->value.objlist.list[i];
        ctc_cli_out("%u, ", CTC_SAI_OBJECT_INDEX_GET(port_oid));
    }
    ctc_cli_out("\n");
    
    ctc_cli_out("Egress Ports:  ");
    for (i = 0; i < attr_egress->value.objlist.count; i++)
    {
        port_oid = attr_egress->value.objlist.list[i];
        ctc_cli_out("%u, ", CTC_SAI_OBJECT_INDEX_GET(port_oid));
    }
    ctc_cli_out("\n");

    ctc_cli_out("\n");
    
    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_isolation_get,
        cli_sai_isolation_get_cmd,
        "isolation get-attribute group (ISOLATION_ID|)",
        "Isolation",
        "get attribute",
        "Isolation group",
        "Isolation group ID")
{
    uint32_t            isolation_id = 0;
    sai_object_id_t     isolation_oid = 0;
    sai_isolation_api_t* api = NULL;
    sai_attribute_t     attr[4];
    sai_object_id_t   ingress_oid_list[256];
    sai_object_id_t   eggress_oid_list[256];
    uint32_t            attr_count = 4;
    sai_status_t     ret = SAI_STATUS_SUCCESS;

    ret = sai_api_query(SAI_API_ISOLATION,(void**)&api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    attr[0].id = SAI_ISOLATION_ATTR_DROP_PACKET_TYPE;
    attr[1].id = SAI_ISOLATION_ATTR_MODE;
    attr[2].id = SAI_ISOLATION_ATTR_INRESS_BLOCK_PORT_LIST;
    attr[3].id = SAI_ISOLATION_ATTR_EGRESS_BLOCK_PORT_LIST;
    attr[2].value.objlist.list = ingress_oid_list;
    attr[3].value.objlist.list = eggress_oid_list;
    
    if (argc != 0)
    {
        CTC_CLI_GET_UINT32_RANGE("isolation-id", isolation_id, argv[0], 0, CTC_MAX_UINT32_VALUE);
        isolation_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ISOLATION_GROUP, isolation_id);
        
        ret = api->get_isolation_group_attribute(isolation_oid, attr_count, attr);
        if (SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }
        cli_sai_isolation_get_show(isolation_oid, attr_count, attr);
    }
    else
    {
        for (isolation_id = 0; isolation_id <= CTC_SAI_ISOLATION_MAX; isolation_id++)
        {        
            isolation_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ISOLATION_GROUP, isolation_id);
            ret = api->get_isolation_group_attribute(isolation_oid, attr_count, attr);
            if (SAI_STATUS_SUCCESS != ret)
            {
                continue;
            }
            cli_sai_isolation_get_show(isolation_oid, attr_count, attr);
        }
    }
    
    return CLI_SUCCESS;
}

int32
ctc_sai_isolation_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_isolation_create_cmd);
    install_element(cli_tree_mode, &cli_sai_isolation_remove_cmd);
    install_element(cli_tree_mode, &cli_sai_isolation_get_cmd);

    return CLI_SUCCESS;
}


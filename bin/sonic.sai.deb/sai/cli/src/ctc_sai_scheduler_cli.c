#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include "ctc_const.h"
#include <ctc_sai_common.h>
#include "ctc_cli_common.h"

#define MAX_SHAPE_RATE_IN_SAI   12500000000

CTC_CLI(cli_sai_scheduler_create_scheduler,
        cli_sai_scheduler_create_scheduler_cmd,
        "scheduler creat-profile (scheduler-algorithm (sp|dwrr (weight WEIGHT|)) |) (shape ((shape-type (type-packets| type-bytes) |) (min-bandwidth-rate CIR|) (min-bandwidth-burst-rate CBS |) (max-bandwidth-rate PIR |) (max-bandwidth-burst-rate PBS|))|)",
        "Scheduler",
        "Creat-profile"
        "Algorithm mode",
        "Sp mode",
        "Dwrr mode",
        "Dwrr weight",
        "Dwrr weight value <1-20000>",
        "Shape",
        "Shape type",
        "packet type",
        "byte type",
        "Shape cir",
        "Shape cir value, unit is Byte, <0-12500000000>",
        "Shape cbs",
        "Shape cbs value Byte, now is not supported in sdk",
        "Shape pir",
        "Shape pir value, unit is Byte, <0-12500000000>",
        "Shape pbs",
        "Shape pbs value Byte, now is not supported in sdk")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint8 index = 0xFF;
    sai_object_id_t scheduler_id;
    sai_scheduler_api_t*  scheduler_api;
    sai_attribute_t attr[15] = {{0}};
    uint32_t attr_count = 0;

    index = CTC_CLI_GET_ARGC_INDEX("scheduler-algorithm");
    if(0xFF != index)
    {
        attr[attr_count].id = SAI_SCHEDULER_ATTR_SCHEDULING_ALGORITHM;
        if(CLI_CLI_STR_EQUAL("sp", index + 1))
        {
            attr[attr_count].value.s32 = SAI_SCHEDULING_STRICT;
            attr_count ++;

            attr[attr_count].id = SAI_SCHEDULER_ATTR_SCHEDULING_WEIGHT;
            attr[attr_count].value.s32 = 1;
        }
        if(CLI_CLI_STR_EQUAL("dwrr", index + 1))
        {
            attr[attr_count].value.s32 = SAI_SCHEDULING_DWRR;
            attr_count ++;
            if(CLI_CLI_STR_EQUAL("weight", index + 2))
            {
                attr[attr_count].id = SAI_SCHEDULER_ATTR_SCHEDULING_WEIGHT;
                CTC_CLI_GET_UINT32_RANGE("weight", attr[attr_count].value.s32, argv[index + 3], 1, 20000);
            }
            else
            {
                attr[attr_count].id = SAI_SCHEDULER_ATTR_SCHEDULING_WEIGHT;
                attr[attr_count].value.s32 = 1;
            }
        }
        attr_count ++;
    }
    else
    {
        attr[attr_count].id = SAI_SCHEDULER_ATTR_SCHEDULING_WEIGHT;
        attr[attr_count].value.s32 = 1;
        attr_count ++;
    }
    index = CTC_CLI_GET_ARGC_INDEX("shape-type");
    if(0xFF != index)
    {
        attr[attr_count].id = SAI_SCHEDULER_ATTR_SHAPER_TYPE;
        if(CLI_CLI_STR_EQUAL("type-packets", index + 1))
            attr[attr_count].value.s32 = SAI_METER_TYPE_PACKETS;
        else
            attr[attr_count].value.s32 = SAI_METER_TYPE_BYTES;

        attr_count ++;
    }
    index = CTC_CLI_GET_ARGC_INDEX("min-bandwidth-rate");
    if(0xFF != index)
    {
        attr[attr_count].id = SAI_SCHEDULER_ATTR_MIN_BANDWIDTH_RATE;
        CTC_CLI_GET_UINT64("min-bandwidth-rate", attr[attr_count].value.u64, argv[index + 1]);
        attr_count ++;
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("min-bandwidth-burst-rate");
    if(0xFF != index)
    {
        attr[attr_count].id = SAI_SCHEDULER_ATTR_MIN_BANDWIDTH_BURST_RATE;
        CTC_CLI_GET_UINT64("min-bandwidth-burst-rate", attr[attr_count].value.u64, argv[index + 1]);
        attr_count ++;
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("max-bandwidth-rate");
    if(0xFF != index)
    {
        attr[attr_count].id = SAI_SCHEDULER_ATTR_MAX_BANDWIDTH_RATE;
        CTC_CLI_GET_UINT64("max-bandwidth-rate", attr[attr_count].value.u64, argv[index + 1]);
        attr_count ++;
    }
    else
    {
        attr[attr_count].id = SAI_SCHEDULER_ATTR_MAX_BANDWIDTH_RATE;
        attr[attr_count].value.u64 = 0;
        attr_count ++;
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("max-bandwidth-burst-rate");
    if(0xFF != index)
    {
        attr[attr_count].id = SAI_SCHEDULER_ATTR_MAX_BANDWIDTH_BURST_RATE;
        CTC_CLI_GET_UINT64("max-bandwidth-burst-rate", attr[attr_count].value.u64, argv[index + 1]);
        attr_count ++;
    }

    if(0 ==attr_count)
    {
        return CLI_SUCCESS;
    }
    ret = sai_api_query(SAI_API_SCHEDULER,(void**)&scheduler_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = scheduler_api->create_scheduler_profile(&scheduler_id,attr_count,attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:0x%-10llx\n","scheduler id",CTC_SAI_OBJECT_INDEX_GET(scheduler_id));

    return ret;
}

CTC_CLI(cli_sai_scheduler_delete_scheduler,
        cli_sai_scheduler_delete_scheduler_cmd,
        "scheduler remove-profile SCHEDULER-ID",
        "Scheduler",
        "Remove profile",
        "Scheduler id value")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint32_t     scheduler_id = 0;
    sai_object_id_t scheduler_oid;
    sai_scheduler_api_t*  scheduler_api;


    CTC_CLI_GET_UINT32("scheduler_id", scheduler_id, argv[0]);

    scheduler_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_SCHEDULER, scheduler_id);

    ret = sai_api_query(SAI_API_SCHEDULER,(void**)&scheduler_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = scheduler_api->remove_scheduler_profile(scheduler_oid);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_scheduler_set_scheduler_attribute,
        cli_sai_scheduler_set_scheduler_attribute_cmd,
        "scheduler set-attribute scheduler-id SCHEDULER-ID ((scheduler-algorithm(sp|dwrr)) |(weight WEIGHT)|(shape-type (type-packets| type-bytes))| (min-bandwidth-rate CIR)| (min-bandwidth-burst-rate CBS) |(max-bandwidth-rate PIR) |(max-bandwidth-burst-rate PBS))",
        "Scheduler",
        "Scheduler update",
        "Scheduler id",
        "Scheduler id value",
        "Algorithm-mode",
        "Sp mode",
        "Dwrr mode",
        "Dwrr weight",
        "Dwrr weight value <1-20000>",
        "Shape type",
        "packet type",
        "byte type",
        "Shape cir",
        "Shape cir value, unit is Byte, <0-12500000000>",
        "Shape cbs",
        "Shape cbs value Byte, now is not supported in sdk",
        "Shape pir",
        "Shape pir value, unit is Byte, <0-12500000000>",
        "Shape pbs",
        "Shape pbs value Byte, now is not supported in sdk")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint8 index = 0xFF;
    uint32_t ctc_scheduler_id;
    sai_object_id_t scheduler_id;
    sai_scheduler_api_t*  scheduler_api;
    sai_attribute_t attr = {0};

    CTC_CLI_GET_UINT32("ctc_scheduler_id", ctc_scheduler_id, argv[0]);
    scheduler_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_SCHEDULER, ctc_scheduler_id);
    
    index = CTC_CLI_GET_ARGC_INDEX("scheduler-algorithm");
    if(0xFF != index)
    {
        attr.id = SAI_SCHEDULER_ATTR_SCHEDULING_ALGORITHM;
        if(CLI_CLI_STR_EQUAL("sp", index + 1))
            attr.value.s32 = SAI_SCHEDULING_STRICT;
        if(CLI_CLI_STR_EQUAL("wrr", index + 1))
            attr.value.s32 = SAI_SCHEDULING_WRR;
        if(CLI_CLI_STR_EQUAL("dwrr", index + 1))
            attr.value.s32 = SAI_SCHEDULING_DWRR;
    }
    index = CTC_CLI_GET_ARGC_INDEX("weight");
    if(0xFF != index)
    {
        attr.id = SAI_SCHEDULER_ATTR_SCHEDULING_WEIGHT;
        CTC_CLI_GET_UINT32_RANGE("weight", attr.value.s32, argv[index + 1], 1, 20000);
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("shape-type");
    if(0xFF != index)
    {
        attr.id = SAI_SCHEDULER_ATTR_SHAPER_TYPE;
        if(CLI_CLI_STR_EQUAL("type-packets", index + 1))
            attr.value.s32 = SAI_METER_TYPE_PACKETS;
        else
            attr.value.s32 = SAI_METER_TYPE_BYTES;
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("min-bandwidth-rate");
    if(0xFF != index)
    {
        attr.id = SAI_SCHEDULER_ATTR_MIN_BANDWIDTH_RATE;
        CTC_CLI_GET_UINT64("min-bandwidth-rate", attr.value.u64, argv[index + 1]);
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("min-bandwidth-burst-rate");
    if(0xFF != index)
    {
        attr.id = SAI_SCHEDULER_ATTR_MIN_BANDWIDTH_BURST_RATE;
        CTC_CLI_GET_UINT64("min-bandwidth-burst-rate", attr.value.u64, argv[index + 1]);
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("max-bandwidth-rate");
    if(0xFF != index)
    {
        attr.id = SAI_SCHEDULER_ATTR_MAX_BANDWIDTH_RATE;
        CTC_CLI_GET_UINT64("max-bandwidth-rate", attr.value.u64, argv[index + 1]);
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("max-bandwidth-burst-rate");
    if(0xFF != index)
    {
        attr.id = SAI_SCHEDULER_ATTR_MAX_BANDWIDTH_BURST_RATE;
        CTC_CLI_GET_UINT64("max-bandwidth-burst-rate", attr.value.u64, argv[index + 1]);
    }
    ret = sai_api_query(SAI_API_SCHEDULER,(void**)&scheduler_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = scheduler_api->set_scheduler_attribute(scheduler_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_scheduler_get_scheduler_attribute,
        cli_sai_scheduler_get_scheduler_attribute_cmd,
        "scheduler get-attribute scheduler-id SCHEDULER-ID (scheduler-algorithm |weight|shape-type|min-bandwidth-rate|min-bandwidth-burst-rate|max-bandwidth-rate |max-bandwidth-burst-rate|)",
        "Scheduler",
        "Scheduler get attribute",
        "Scheduler id",
        "Scheduler id value",
        "Algorithm-mode",
        "Dwrr weight",
        "Shape type",
        "Shape cir",
        "Shape cbs",
        "Shape pir",
        "Shape pbs"
        )
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint8 index = 0xFF;
    uint32_t ctc_scheduler_id;
    sai_object_id_t scheduler_id;
    sai_scheduler_api_t*  scheduler_api;
    sai_attribute_t attr[8];
    uint32_t attr_count = 0;
    char *schdeuler_mode[3] = {"sp", "drr", "wdrr"};
    char* shape_type[2] = {"type-packets", "type-bytes"};
    sal_memset(attr, 0x0, (sizeof(sai_attribute_t))*8);
    CTC_CLI_GET_UINT32("ctc_scheduler_id", ctc_scheduler_id, argv[0]);
    scheduler_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_SCHEDULER, ctc_scheduler_id);

    if(argc > 1)
    {
        index = CTC_CLI_GET_ARGC_INDEX("scheduler-algorithm");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_SCHEDULER_ATTR_SCHEDULING_ALGORITHM;
        }
        index = CTC_CLI_GET_ARGC_INDEX("weight");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_SCHEDULER_ATTR_SCHEDULING_WEIGHT;
        }
        index = CTC_CLI_GET_ARGC_INDEX("shape-type");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_SCHEDULER_ATTR_SHAPER_TYPE;
        }
        index = CTC_CLI_GET_ARGC_INDEX("min-bandwidth-rate");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_SCHEDULER_ATTR_MIN_BANDWIDTH_RATE;
        }
        index = CTC_CLI_GET_ARGC_INDEX("min-bandwidth-burst-rate");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_SCHEDULER_ATTR_MIN_BANDWIDTH_BURST_RATE;
        }
        index = CTC_CLI_GET_ARGC_INDEX("max-bandwidth-rate");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_SCHEDULER_ATTR_MAX_BANDWIDTH_RATE;
        }
        index = CTC_CLI_GET_ARGC_INDEX("max-bandwidth-burst-rate");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_SCHEDULER_ATTR_MAX_BANDWIDTH_BURST_RATE;
        }
        attr_count ++;

        ret = sai_api_query(SAI_API_SCHEDULER,(void**)&scheduler_api);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        ret = scheduler_api->get_scheduler_attribute(scheduler_id, attr_count, attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        switch(attr[0].id)
        {
            case SAI_SCHEDULER_ATTR_SCHEDULING_ALGORITHM:
                ctc_cli_out("%s %s \n", "scheduler-algorithm", schdeuler_mode[attr[0].value.s32]);
                break;
            case SAI_SCHEDULER_ATTR_SCHEDULING_WEIGHT:
                ctc_cli_out("%s %d \n", "weight", attr[0].value.s32);
                break;
            case SAI_SCHEDULER_ATTR_SHAPER_TYPE:
                ctc_cli_out("%s %s \n", "shape-type", shape_type[attr[0].value.s32]);
                break;
            case SAI_SCHEDULER_ATTR_MIN_BANDWIDTH_RATE:
                ctc_cli_out("%s %"PRIu64" \n", "min-bandwidth-rate", attr[0].value.u64);
                break;
            case SAI_SCHEDULER_ATTR_MIN_BANDWIDTH_BURST_RATE:
                ctc_cli_out("%s %"PRIu64" \n", "min-bandwidth-burst-rate", attr[0].value.u64);
                break;
            case SAI_SCHEDULER_ATTR_MAX_BANDWIDTH_RATE:
                ctc_cli_out("%s %"PRIu64" \n", "max-bandwidth-rate", attr[0].value.u64);
                break;
            case SAI_SCHEDULER_ATTR_MAX_BANDWIDTH_BURST_RATE:
                ctc_cli_out("%s %"PRIu64" \n", "max-bandwidth-burst-rate", attr[0].value.u64);
                break;
            default:
                break;
        }

    }
    else
    {
        attr[attr_count].id = SAI_SCHEDULER_ATTR_SCHEDULING_ALGORITHM;
        attr_count++;
                attr[attr_count].id = SAI_SCHEDULER_ATTR_SCHEDULING_WEIGHT;
        attr_count++;
                attr[attr_count].id = SAI_SCHEDULER_ATTR_SHAPER_TYPE;
        attr_count++;
                attr[attr_count].id = SAI_SCHEDULER_ATTR_MIN_BANDWIDTH_RATE;
        attr_count++;
                attr[attr_count].id = SAI_SCHEDULER_ATTR_MIN_BANDWIDTH_BURST_RATE;
        attr_count++;
                attr[attr_count].id = SAI_SCHEDULER_ATTR_MAX_BANDWIDTH_RATE;
        attr_count++;
                attr[attr_count].id = SAI_SCHEDULER_ATTR_MAX_BANDWIDTH_BURST_RATE;
        attr_count++;
        
        ret = sai_api_query(SAI_API_SCHEDULER,(void**)&scheduler_api);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        ret = scheduler_api->get_scheduler_attribute(scheduler_id, attr_count, attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        ctc_cli_out("%-15s %-15d\n", "scheduler-id", ctc_scheduler_id);
        ctc_cli_out("%-20s %-20s\n", "scheduler-algorithm", schdeuler_mode[attr[0].value.s32]);
        ctc_cli_out("%-10s %-10d\n", "weight", attr[1].value.s32);
        ctc_cli_out("%-15s %-15s\n", "shape-type", shape_type[attr[2].value.s32]);
        ctc_cli_out("%-20s %-20llu\n", "min-bandwidth-rate", attr[3].value.u64);
        ctc_cli_out("%-24s %-24llu\n", "min-bandwidth-burst-rate", attr[4].value.u64);
        ctc_cli_out("%-20s %-20llu\n", "max-bandwidth-rate", attr[5].value.u64);
        ctc_cli_out("%-24s %-24llu\n", "max-bandwidth-burst-rate", attr[6].value.u64);
    }
    return ret;
}

int32
ctc_sai_scheduler_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_scheduler_create_scheduler_cmd);
    install_element(cli_tree_mode, &cli_sai_scheduler_delete_scheduler_cmd);
    install_element(cli_tree_mode, &cli_sai_scheduler_set_scheduler_attribute_cmd);
    install_element(cli_tree_mode, &cli_sai_scheduler_get_scheduler_attribute_cmd);

    return CLI_SUCCESS;
}


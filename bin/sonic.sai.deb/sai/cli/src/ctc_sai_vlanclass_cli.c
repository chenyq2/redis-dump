#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include "ctc_const.h"
#include <ctc_sai_common.h>

CTC_CLI(cli_sai_create_vlanclass_group,
        cli_sai_create_vlanclass_group_cmd,
        "vlanclass create vlanclass group",
        "vlanclass",
        "Create vlanclass",
        "vlanclass",
        "group")
{
    sai_vlanclass_api_t*   vlanclass_api = NULL;
    sai_object_id_t        group_oid = 0;
    sai_status_t           ret = SAI_STATUS_SUCCESS;
    
    ret = sai_api_query(SAI_API_VLAN_CLASS,(void**)&vlanclass_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vlanclass_api->create_vlanclass_group(&group_oid, 0, NULL);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ctc_cli_out("%-10s: %u\n", "vlanclass_group_ID", CTC_SAI_OBJECT_INDEX_GET(group_oid));
    
    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_delete_vlanclass_group,
        cli_sai_delete_vlanclass_group_cmd,
        "vlanclass delete vlanclass group GROUP_ID",
        "vlanclass",
        "Delete vlanclass",
        "vlanclass",
        "group",
        "<0-31>")
{
    sai_vlanclass_api_t*   vlanclass_api = NULL;
    sai_object_id_t        group_oid = 0;
    uint32                 group_id = 0;
    sai_status_t           ret = SAI_STATUS_SUCCESS;
    
    CTC_CLI_GET_UINT16_RANGE("group-id", group_id, argv[0], 0, 31);
    group_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_VLAN_CLASS_GROUP, group_id);
    
    ret = sai_api_query(SAI_API_VLAN_CLASS,(void**)&vlanclass_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = vlanclass_api->delete_vlanclass_group(group_oid);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_sai_create_vlanclass_groupmember,
        cli_sai_create_vlanclass_groupmember_cmd,
        "vlanclass create vlanclass groupmember (group-id GROUP_ID) (rule-id RULE_ID)" 
        "(mac MAC_ADDR| ip IPV4_ADDR| ipv6 IPV6_ADDR| protocol (ip| ipv6| mpls| mpls-mcast| arp| rarp| pppoe)) (vlan VLAN_ID)",
        "Vlanclass",
        "Create vlanclass",
        "Vlanclass",
        "Groupmember",
        "Group id",
        "<0-31>",
        "Rule id",
        "<0-4095>",
        SAI_CLI_MAC_DESC,
        SAI_CLI_MAC_FORMAT,
        SAI_CLI_IPV4_DESC,
        SAI_CLI_IPV4_FORMAT,
        SAI_CLI_IPV6_DESC,
        SAI_CLI_IPV6_FORMAT,
        "Protocol",
        "Ipv4",
        "Ipv6",
        "Mpls",
        "Mpls-mcast",
        "Arp",
        "Rarp",
        "pppoe",
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC)
{
    sai_vlanclass_api_t*   vlanclass_api = NULL;
    sai_object_id_t        group_oid = 0;;
    sai_object_id_t        groupmember_oid = 0;
    sai_attribute_t        attr[5];
    uint32                 group_id = 0;
    uint32                 rule_id = 0;
    uint16                 vlan_id = 0;
    sai_status_t           ret = SAI_STATUS_SUCCESS;

    if (0 == sal_strcmp(argv[0], "group-oid"))
    {
        CTC_CLI_GET_UINT16_RANGE("group-id", group_id, argv[1], 0, 31);
        group_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_VLAN_CLASS_GROUP, group_id);
    }
    if (0 == sal_strcmp(argv[2], "rule-id"))
    {
        CTC_CLI_GET_UINT16_RANGE("rule-id", rule_id, argv[3], 0, 4095);
    }

    if (0 == sal_strcmp(argv[4], "mac"))
    {
        attr[3].id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_ENTRY_TYPE;
        attr[3].value.s32 = SAI_VLAN_CLASS_ENTRY_TYPE_MAC;
        attr[4].id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_MAC_ADDRESS;
        SAI_CLI_GET_MAC_ADDRESS(&attr[4].value.mac);
    }
    else if (0 == sal_strcmp(argv[4], "ip"))
    {
        attr[3].id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_ENTRY_TYPE;
        attr[3].value.s32 = SAI_VLAN_CLASS_ENTRY_TYPE_IPV4;
        attr[4].id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_IPV4_ADDRESS;
        SAI_CLI_GET_SAI_IP_ADDRESS_T(&attr[4].value.ipaddr);
    }
    else if (0 == sal_strcmp(argv[4], "ipv6"))
    {
        attr[3].id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_ENTRY_TYPE;
        attr[3].value.s32 = SAI_VLAN_CLASS_ENTRY_TYPE_IPV6;
        attr[4].id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_IPV6_ADDRESS;
        SAI_CLI_GET_SAI_IP_ADDRESS_T(&attr[4].value.ipaddr);
    }
    else if (0 == sal_strcmp(argv[4], "protocol"))
    {
        attr[3].id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_ENTRY_TYPE;
        attr[3].value.s32 = SAI_VLAN_CLASS_ENTRY_TYPE_PROTOCOL;
        attr[4].id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_PROTOCOL_TYPE;
        if (0 == sal_strcmp(argv[5], "ip"))
        {
            attr[4].value.s32 = SAI_VLAN_CLASS_PROTOCOL_TYPE_IPV4;
        }
        else if (0 == sal_strcmp(argv[5], "ipv6"))
        {
            attr[4].value.s32 = SAI_VLAN_CLASS_PROTOCOL_TYPE_IPV6;
        }
        else if (0 == sal_strcmp(argv[5], "mpls"))
        {
            attr[4].value.s32 = SAI_VLAN_CLASS_PROTOCOL_TYPE_MPLS;
        }
        else if (0 == sal_strcmp(argv[5], "mpls-mcast"))
        {
            attr[4].value.s32 = SAI_VLAN_CLASS_PROTOCOL_TYPE_MPLS_MCAST;
        }
        else if (0 == sal_strcmp(argv[5], "arp"))
        {
            attr[4].value.s32 = SAI_VLAN_CLASS_PROTOCOL_TYPE_ARP;
        }
        else if (0 == sal_strcmp(argv[5], "rarp"))
        {
            attr[4].value.s32 = SAI_VLAN_CLASS_PROTOCOL_TYPE_RARP;
        }
        else if (0 == sal_strcmp(argv[5], "pppoe"))
        {
            attr[4].value.s32 = SAI_VLAN_CLASS_PROTOCOL_TYPE_PPPOE;
        }
        else
        {   
            ctc_cli_out("%% Not support \n", argv[5]);
            return CLI_SUCCESS;
        }
    }
    if (0 == sal_strcmp(argv[6], "vlan"))
    {
        CTC_CLI_GET_UINT16_RANGE("vlan-id", vlan_id, argv[7], 1, 4094);
    }

    attr[0].id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_GROUP_ID;
    attr[0].value.oid = group_oid;
    attr[1].id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_RULE_ID;
    attr[1].value.s32 = rule_id;    
    attr[2].id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_VLAN_ID;
    attr[2].value.s16 = vlan_id;
    
    ret = sai_api_query(SAI_API_VLAN_CLASS,(void**)&vlanclass_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = vlanclass_api->create_vlanclass_group_member(&groupmember_oid, 5, attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s: %u\n","lagmember_id", CTC_SAI_OBJECT_INDEX_GET(groupmember_oid));

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_delete_vlanclass_groupmember,
        cli_sai_delete_vlanclass_groupmember_cmd,
        "vlanclass delete vlanclass groupmember GROUPMEMBER_ID",
        "vlanclass",
        "delete vlanclass",
        "vlanclass",
        "Groupmember",
        "<0-4095>")
{
    uint32                   groupmember_id = 0;
    sai_vlanclass_api_t*     vlanclass_api = NULL;
    sai_object_id_t          groupmember_oid = 0;
    sai_status_t             ret   = SAI_STATUS_SUCCESS;
    
    CTC_CLI_GET_UINT16_RANGE("groupmember-id", groupmember_id, argv[0], 0, 4095);
    groupmember_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_VLAN_CLASS_GROUP_MEMBER, groupmember_id);

    ret = sai_api_query(SAI_API_VLAN_CLASS,(void**)&vlanclass_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = vlanclass_api->delete_vlanclass_group_member(groupmember_oid);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

char *vlanclass_entry_type_val2str(uint32 type)
{
    switch (type)
    {
    case SAI_VLAN_CLASS_ENTRY_TYPE_MAC:
        return "MAC";
    case SAI_VLAN_CLASS_ENTRY_TYPE_IPV4:
        return "IPV4";
    case SAI_VLAN_CLASS_ENTRY_TYPE_IPV6:
        return "IpV6";
    case SAI_VLAN_CLASS_ENTRY_TYPE_PROTOCOL:
        return "Protocol";
    default:
        return "invalid";
    }
}

char *vlanclass_entry_protocol_type_val2str(uint32 proto_type)
{
    switch (proto_type)
    {
    case SAI_VLAN_CLASS_PROTOCOL_TYPE_IPV4:
        return "ipv4";
    case SAI_VLAN_CLASS_PROTOCOL_TYPE_IPV6:
        return "ipv6";
    case SAI_VLAN_CLASS_PROTOCOL_TYPE_MPLS:
        return "mpls";
    case SAI_VLAN_CLASS_PROTOCOL_TYPE_MPLS_MCAST:
        return "mpls-mcast";
    case SAI_VLAN_CLASS_PROTOCOL_TYPE_ARP:
        return "arp";
    case SAI_VLAN_CLASS_PROTOCOL_TYPE_RARP:
        return "rarp";
    case SAI_VLAN_CLASS_PROTOCOL_TYPE_PPPOE:
        return "pppoe";
    default:
        return "invalid";
    }
}

CTC_CLI(cli_sai_vlanclass_groupmember_get,
        cli_sai_vlanclass_groupmember_get_cmd,
        "vlanclass get-attribute groupmember GROUPMEMBER_ID (group|rule|entry-type|mac|ipv4|ipv6|protocol|vlan)",
        "vlanclass",
        "Get attribute",
        "groupmember",
        "<0-4095>",
        "rule-id",
        "MAC Address",
        "Ipv4 Address",
        "Ipv6 Address",
        "Protocol",
        "Vlan")
{
    uint32                   groupmember_id = 0;
    sai_vlanclass_api_t*     vlanclass_api = NULL;
    sai_object_id_t          groupmember_oid = 0;
    sai_status_t             ret   = SAI_STATUS_SUCCESS;
    char                     buf[CTC_IPV6_ADDR_STR_LEN] = ""; 
    uint32_t                 tempip = 0;
    sai_attribute_t          attr;
   
    CTC_CLI_GET_UINT16_RANGE("lagmember-id", groupmember_id, argv[0], 0, 4095);
    groupmember_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_VLAN_CLASS_GROUP_MEMBER, groupmember_id);

    if (0 == sal_strcmp(argv[1], "group"))
    {
         attr.id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_GROUP_ID;
    }
    if (0 == sal_strcmp(argv[1], "rule"))
    {
         attr.id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_RULE_ID;
    }
    if (0 == sal_strcmp(argv[1], "entry-type"))
    {
         attr.id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_ENTRY_TYPE;
    }
    else if (0 == sal_strcmp(argv[1], "mac"))
    {
         attr.id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_MAC_ADDRESS;
    }
    else if (0 == sal_strcmp(argv[1], "ipv4"))
    {
         attr.id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_IPV4_ADDRESS;
    }
    else if (0 == sal_strcmp(argv[1], "ipv6"))
    {
         attr.id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_IPV6_ADDRESS;
    }
    else if (0 == sal_strcmp(argv[1], "protocol"))
    {
         attr.id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_PROTOCOL_TYPE;
    }
    else if (0 == sal_strcmp(argv[1], "vlan"))
    {
         attr.id = SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_VLAN_ID;
    }

    ret = sai_api_query(SAI_API_VLAN_CLASS,(void**)&vlanclass_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ret = vlanclass_api->get_vlanclass_group_member_attribute(groupmember_oid, 1, &attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    
    switch(attr.id)
    {
    case SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_GROUP_ID:
        ctc_cli_out("%-10s: %u\n", "group_ID", CTC_SAI_OBJECT_INDEX_GET(attr.value.oid));
        break;
        
    case SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_RULE_ID:
        ctc_cli_out("%-10s: %u\n", "rule_ID", attr.value.s32);
        break;
        
    case SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_ENTRY_TYPE:
        ctc_cli_out("%-10s: %s\n", "entry_type", vlanclass_entry_type_val2str(attr.value.s32));
        break;
        
    case SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_VLAN_ID:
        ctc_cli_out("%-10s: %u\n", "Vlan_ID", attr.value.s16);
        break;

    case SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_MAC_ADDRESS:
        ctc_cli_out("%-10s: %02X:%02X:%02X:%02X:%02X:%02X\n", "Mac addr", 
                attr.value.mac[0], attr.value.mac[1], attr.value.mac[2],
                attr.value.mac[3], attr.value.mac[4], attr.value.mac[5]);
        break;

    case SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_IPV4_ADDRESS:
        tempip = sal_ntohl(attr.value.ipaddr.addr.ip4);
        sal_inet_ntop(AF_INET, &tempip, buf, CTC_IPV6_ADDR_STR_LEN);
        ctc_cli_out("%-10s: %s\n", "ipv4_addr", buf);
        break;

    case SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_IPV6_ADDRESS:
        sal_inet_ntop(AF_INET6, attr.value.ipaddr.addr.ip6, buf, CTC_IPV6_ADDR_STR_LEN);
        ctc_cli_out("%-10s: %s\n", "ipv6_addr", buf);
        break;

    case SAI_VLAN_CLASS_GROUP_MEMBER_ATTR_PROTOCOL_TYPE:
        ctc_cli_out("%-10s: %s\n", "protocol_type", vlanclass_entry_protocol_type_val2str(attr.value.s32));        
        break;
    default:
        break;
    }
    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_vlanclass_group_attr_get_rules,
        cli_sai_vlanclass_group_attr_get_rules_cmd,
        "vlanclass get-attribute group GROUPID rules",
        "vlanclass",
        "get attribute",
        "Group",
        "<0-31>",
        "rules")
{
    uint32                   group_id = 0;
    sai_vlanclass_api_t*     vlanclass_api = NULL;
    sai_object_id_t          group_oid = 0;
    sai_object_list_t        rulelist;
    sai_attribute_t          attr;
    uint32                   rule_idx = 0;
    sai_status_t             ret = SAI_STATUS_SUCCESS;

    sal_memset(&attr,0,sizeof(sai_attribute_t));

    CTC_CLI_GET_UINT16_RANGE("group-id", group_id, argv[0], 0, 31);
    group_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_VLAN_CLASS_GROUP, group_id);

    attr.id = SAI_VLANCLASS_GROUP_ATTR_RULE_LIST;

    rulelist.list = mem_malloc(MEM_APP_VLAN_CLASS_MODULE,sizeof(sai_object_id_t) * 4096);
    if(!rulelist.list)
    {
        ret = SAI_STATUS_NO_MEMORY;
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    sal_memset(rulelist.list,0,sizeof(sai_object_id_t) * 4096);
    rulelist.count = 4096;
    attr.value.objlist  = rulelist;

    ret = sai_api_query(SAI_API_VLAN_CLASS,(void**)&vlanclass_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        mem_free(rulelist.list);
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = vlanclass_api->get_vlanclass_group_attribute(group_oid,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        mem_free(rulelist.list);
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:","rules");
    for(rule_idx = 0; rule_idx < attr.value.objlist.count; rule_idx++)
    {
        if(rule_idx % 16 == 0)
        {
            ctc_cli_out("\n%-10s:"," ");
        }
        ctc_cli_out("%-6d,", attr.value.objlist.list[rule_idx]);
    }
    ctc_cli_out("\n");

    mem_free(rulelist.list);
    return CLI_SUCCESS;
}

int32
ctc_sai_vlanclass_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_create_vlanclass_group_cmd);
    install_element(cli_tree_mode, &cli_sai_delete_vlanclass_group_cmd);
    install_element(cli_tree_mode, &cli_sai_create_vlanclass_groupmember_cmd);
    install_element(cli_tree_mode, &cli_sai_delete_vlanclass_groupmember_cmd);
    install_element(cli_tree_mode, &cli_sai_vlanclass_groupmember_get_cmd);
    install_element(cli_tree_mode, &cli_sai_vlanclass_group_attr_get_rules_cmd);
    return CLI_SUCCESS;
}


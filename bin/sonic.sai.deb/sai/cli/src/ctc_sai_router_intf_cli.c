#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include <ctc_sai_common.h>

CTC_CLI(cli_sai_router_intf_create_port,
        cli_sai_router_intf_create_port_cmd,
        "router interface create set-attribute virtual-router-id (router-id SAI_OBJ_ID) "
        "(type (port ((port-id SAI_OBJ_ID) | (lag-id SAI_OBJ_ID)) | (vlan-id (vlan VLAN))))",
        "router",
        "Interface",
        "Create",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        "Virtual router id",
        SAI_CLI_OBJ_ROUTER_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Type",
        "Port or Lag Router Interface Type",
        SAI_CLI_OBJ_PORT_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        SAI_CLI_OBJ_LAG_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "VLAN Router Interface Type",
        SAI_CLI_VLAN_DESC,
        SAI_CLI_VLAN_RANGE_DESC)
{
    sai_router_interface_api_t*  intf_api;
    sai_object_id_t     intf_id = 0;
    sai_object_id_t     port_id     = 0;
    uint16_t            vlan_id     = 0;
    sai_object_id_t     vr_id       = 0;
    sai_status_t        ret         = SAI_STATUS_SUCCESS;
    sai_attribute_t     attr[3]     = {};

    SAI_CLI_GET_PORT_ID(port_id);
    SAI_CLI_GET_ROUTER_ID(vr_id);

    SAI_CLI_GET_VLAN(vlan_id);

    attr[0].id = SAI_ROUTER_INTERFACE_ATTR_VIRTUAL_ROUTER_ID;
    attr[0].value.oid = vr_id;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("port"))
    {
        attr[1].id = SAI_ROUTER_INTERFACE_ATTR_TYPE;
        attr[1].value.s32 = SAI_ROUTER_INTERFACE_TYPE_PORT;

        attr[2].id = SAI_ROUTER_INTERFACE_ATTR_PORT_ID;
        attr[2].value.oid = port_id;
    }

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("vlan-id"))
    {
        attr[1].id = SAI_ROUTER_INTERFACE_ATTR_TYPE;
        attr[1].value.s32 = SAI_ROUTER_INTERFACE_TYPE_VLAN;

        attr[2].id = SAI_ROUTER_INTERFACE_ATTR_VLAN_ID;
        attr[2].value.u16 = vlan_id;
    }

    ret = sai_api_query(SAI_API_ROUTER_INTERFACE,(void**)&intf_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = intf_api->create_router_interface(&intf_id,3,attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%llx\n","router-interface-id",CTC_SAI_OBJECT_INDEX_GET(intf_id));

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_intf_remove,
        cli_sai_router_intf_remove_cmd,
        "router interface remove (router-interface-id SAI_OBJ_ID)",
        "router",
        "Interface",
        "Remove",
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE)
{
    sai_router_interface_api_t*  intf_api;
    sai_object_id_t     intf_id = 0;
    sai_status_t        ret = SAI_STATUS_SUCCESS;

    SAI_CLI_GET_ROUTER_INTERFACE_ID(intf_id);

    ret = sai_api_query(SAI_API_ROUTER_INTERFACE,(void**)&intf_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = intf_api->remove_router_interface(intf_id);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_intf_set_router_attr_admin_ipv4_state,
        cli_sai_router_intf_set_router_attr_admin_ipv4_state_cmd,
        "router interface set-attribute (router-interface-id SAI_OBJ_ID) admin-v4-state (true | false)",
        "router",
        "Interface",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Admin V4 state (default to TRUE)",
        "true",
        "false")
{
    sai_router_interface_api_t*  intf_api = NULL;
    sai_object_id_t     intf_id = 0;
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_attribute_t     attr;

    SAI_CLI_GET_ROUTER_INTERFACE_ID(intf_id);

    attr.id = SAI_ROUTER_INTERFACE_ATTR_ADMIN_V4_STATE;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("true"))
    {
        attr.value.booldata = true;
    }
    else
    {
        attr.value.booldata = false;
    }

    ret = sai_api_query(SAI_API_ROUTER_INTERFACE,(void**)&intf_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = intf_api->set_router_interface_attribute(intf_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_intf_set_router_attr_admin_ipv6_state,
        cli_sai_router_intf_set_router_attr_admin_ipv6_state_cmd,
        "router interface set-attribute (router-interface-id SAI_OBJ_ID) admin-v6-state (true | false)",
        "router",
        "Interface",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Admin V6 state (default to TRUE)",
        "true",
        "false")
{
    sai_router_interface_api_t*  intf_api = NULL;
    sai_object_id_t     intf_id = 0;
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_attribute_t     attr;

    SAI_CLI_GET_ROUTER_INTERFACE_ID(intf_id);

    attr.id = SAI_ROUTER_INTERFACE_ATTR_ADMIN_V6_STATE;

    if(0xFF != CTC_CLI_GET_ARGC_INDEX("true"))
    {
        attr.value.booldata = true;
    }
    else
    {
        attr.value.booldata = false;
    }

    ret = sai_api_query(SAI_API_ROUTER_INTERFACE,(void**)&intf_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = intf_api->set_router_interface_attribute(intf_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_intf_set_router_attr_mtu,
        cli_sai_router_intf_set_router_attr_mtu_cmd,
        "router interface set-attribute (router-interface-id SAI_OBJ_ID) (mtu VALUE)",
        "router",
        "Interface",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "MTU (default to 1514 bytes)",
        "mtu-size")
{
    sai_router_interface_api_t*  intf_api = NULL;
    sai_object_id_t     intf_id = 0;
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_attribute_t     attr;
    uint8_t             index = 0xFF;

    SAI_CLI_GET_ROUTER_INTERFACE_ID(intf_id);

    attr.id = SAI_ROUTER_INTERFACE_ATTR_MTU;

    index = CTC_CLI_GET_ARGC_INDEX("mtu");
    if(0xFF != index)
    {
        CTC_CLI_GET_UINT32_RANGE("mtu-size", attr.value.u32, argv[index + 1], 0, CTC_MAX_UINT32_VALUE);
    }

    ret = sai_api_query(SAI_API_ROUTER_INTERFACE,(void**)&intf_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = intf_api->set_router_interface_attribute(intf_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_intf_get_router_attr_admin_ipv4_state,
        cli_sai_router_intf_get_router_attr_admin_ipv4_state_cmd,
        "router interface get-attribute (router-interface-id SAI_OBJ_ID) admin-v4-state",
        "router",
        "Interface",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Admin V6 state (default to TRUE)")
{
    sai_router_interface_api_t*  intf_api = NULL;
    sai_object_id_t     intf_id = 0;
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_attribute_t     attr;

    SAI_CLI_GET_ROUTER_INTERFACE_ID(intf_id);

    sal_memset(&attr,0,sizeof(sai_attribute_t));

    attr.id = SAI_ROUTER_INTERFACE_ATTR_ADMIN_V4_STATE;

    ret = sai_api_query(SAI_API_ROUTER_INTERFACE,(void**)&intf_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = intf_api->get_router_interface_attribute(intf_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","admin-v4-state",attr.value.booldata ? "TRUE" : "FALSE");

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_intf_get_router_attr_admin_ipv6_state,
        cli_sai_router_intf_get_router_attr_admin_ipv6_state_cmd,
        "router interface get-attribute (router-interface-id SAI_OBJ_ID) admin-v6-state",
        "router",
        "Interface",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "Admin V6 state (default to TRUE)")
{
    sai_router_interface_api_t*  intf_api = NULL;
    sai_object_id_t     intf_id = 0;
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_attribute_t     attr;

    SAI_CLI_GET_ROUTER_INTERFACE_ID(intf_id);

    sal_memset(&attr,0,sizeof(sai_attribute_t));

    attr.id = SAI_ROUTER_INTERFACE_ATTR_ADMIN_V4_STATE;

    ret = sai_api_query(SAI_API_ROUTER_INTERFACE,(void**)&intf_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = intf_api->get_router_interface_attribute(intf_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10s\n","admin-v6-state",attr.value.booldata ? "TRUE" : "FALSE");

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_intf_get_router_attr_mtu,
        cli_sai_router_intf_get_router_attr_mtu_cmd,
        "router interface get-attribute (router-interface-id SAI_OBJ_ID) mtu",
        "router",
        "Interface",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "MTU (default to 1514 bytes)")
{
    sai_router_interface_api_t*  intf_api = NULL;
    sai_object_id_t     intf_id = 0;
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_attribute_t     attr;

    SAI_CLI_GET_ROUTER_INTERFACE_ID(intf_id);

    sal_memset(&attr,0,sizeof(sai_attribute_t));

    attr.id = SAI_ROUTER_INTERFACE_ATTR_MTU;

    ret = sai_api_query(SAI_API_ROUTER_INTERFACE,(void**)&intf_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = intf_api->get_router_interface_attribute(intf_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%-10d\n","MTU",attr.value.u32);

    return CLI_SUCCESS;
}

CTC_CLI(cli_sai_router_intf_set_smac,
        cli_sai_router_intf_set_smac_cmd,
        "router interface set-attribute (router-interface-id SAI_OBJ_ID) src-mac-address (mac MAC)",
        "router",
        "Interface",
        SAI_CLI_SET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "MAC Address (default to SAI_VIRTUAL_ROUTER_ATTR_SRC_MAC_ADDRESS if not set on create)",
        SAI_CLI_MAC_DESC,
        SAI_CLI_MAC_FORMAT)
{
    sai_router_interface_api_t*  intf_api = NULL;
    sai_object_id_t     intf_id = 0;
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_attribute_t     attr;

    SAI_CLI_GET_ROUTER_INTERFACE_ID(intf_id);

    SAI_CLI_GET_MAC_ADDRESS(&attr.value.mac);

    attr.id = SAI_ROUTER_INTERFACE_ATTR_SRC_MAC_ADDRESS;

    ret = sai_api_query(SAI_API_ROUTER_INTERFACE,(void**)&intf_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = intf_api->set_router_interface_attribute(intf_id,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return CLI_SUCCESS;
}


CTC_CLI(cli_sai_router_intf_get_smac,
        cli_sai_router_intf_get_smac_cmd,
        "router interface get-attribute (router-interface-id SAI_OBJ_ID) src-mac-address (mac MAC)",
        "router",
        "Interface",
        SAI_CLI_GET_ATTRIBUTE_DESC,
        SAI_CLI_OBJ_ROUTER_INERFACE_ID_DESC,
        SAI_CLI_OBJECT_VALUE,
        "MAC Address (default to SAI_VIRTUAL_ROUTER_ATTR_SRC_MAC_ADDRESS if not set on create)")
{
    sai_router_interface_api_t*  intf_api = NULL;
    sai_object_id_t     intf_id = 0;
    sai_status_t        ret = SAI_STATUS_SUCCESS;
    sai_attribute_t     attr;

    SAI_CLI_GET_ROUTER_INTERFACE_ID(intf_id);

    sal_memset(&attr,0,sizeof(sai_attribute_t));

    attr.id = SAI_ROUTER_INTERFACE_ATTR_SRC_MAC_ADDRESS;

    ret = sai_api_query(SAI_API_ROUTER_INTERFACE,(void**)&intf_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = intf_api->get_router_interface_attribute(intf_id,1,&attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-20s:%02x:%02x:%02x:%02x:%02x:%02x\n",
        "src-mac-address",
        attr.value.mac[0],
        attr.value.mac[1],
        attr.value.mac[2],
        attr.value.mac[3],
        attr.value.mac[4],
        attr.value.mac[5]);

    return CLI_SUCCESS;
}


int32
ctc_sai_router_intf_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_router_intf_create_port_cmd);
    install_element(cli_tree_mode, &cli_sai_router_intf_remove_cmd);
    install_element(cli_tree_mode, &cli_sai_router_intf_set_router_attr_admin_ipv4_state_cmd);
    install_element(cli_tree_mode, &cli_sai_router_intf_set_router_attr_admin_ipv6_state_cmd);
    install_element(cli_tree_mode, &cli_sai_router_intf_set_router_attr_mtu_cmd);
    install_element(cli_tree_mode, &cli_sai_router_intf_get_router_attr_admin_ipv4_state_cmd);
    install_element(cli_tree_mode, &cli_sai_router_intf_get_router_attr_admin_ipv6_state_cmd);
    install_element(cli_tree_mode, &cli_sai_router_intf_get_router_attr_mtu_cmd);
    install_element(cli_tree_mode, &cli_sai_router_intf_set_smac_cmd);
    install_element(cli_tree_mode, &cli_sai_router_intf_get_smac_cmd);

    return CLI_SUCCESS;
}

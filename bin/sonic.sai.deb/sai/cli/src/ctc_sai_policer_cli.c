#include "sal.h"
#include "ctc_cli.h"
#include <sai.h>
#include "ctc_sai_cli.h"
#include "ctc_const.h"
#include <ctc_sai_common.h>
#include "ctc_cli_common.h"

#define MAX_RATE_IN_SAI   12500000000
#define MAX_CBS_IN_SAI    640000

CTC_CLI(cli_sai_policer_create_policer,
        cli_sai_policer_create_policer_cmd,
        "policer create ((type-packet | type-bytes)|) (mode (sr-tcm|tr-tcm)) ((color-source-blind|color-source-aware)|) (cir CIR) (cbs CBS |) (pir PIR|) (pbs PBS|) (enable-counter-list|)",
        "POLICER",
        "Create",
        "Policer packet type",
        "Policer byte type",
        "Policer mode",
        "Single rate mode",
        "Two rate mode",
        "Color-bind mode",
        "Color-aware mode",
        "Config CIR (Commit Information Rate)",
        "<0-12500000000>, unit is Bytes",
        "Config CBS (Commit Burst Size)",
        "<0-640000>, unit is Bytes, default is 8000",
        "Config PIR (Peak Information Rate), PIR(RFC2698) or EIR(RFC4115,BWP)",
        "<0-12500000000>, unit is Bytes",
        "Config PBS (Peak Burst Size), PBS(RFC2698,)or EBS (RFC2697, RFC4115,BWP)",
        "<0-640000>, unit is Bytes, default is 8000",
        "Policer stats enable")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint8 index = 0xFF;
    sai_object_id_t policer_id;
    sai_policer_api_t*  policer_api;
    sai_attribute_t attr[8] = {{0}};
    uint32_t attr_count = 0;

    index = CTC_CLI_GET_ARGC_INDEX("type-packet");
    if(0xFF != index)
    {
        ctc_cli_out("packet mode is not support!\n");
    }
    attr[attr_count].id = SAI_POLICER_ATTR_METER_TYPE;
    attr[attr_count].value.s32 = SAI_METER_TYPE_BYTES;
    attr_count ++;
    index = CTC_CLI_GET_ARGC_INDEX("mode");
    if(0xFF != index)
    {
        attr[attr_count].id = SAI_POLICER_ATTR_MODE;
        if (CLI_CLI_STR_EQUAL("sr-tcm", index + 1))
        {
            attr[attr_count].value.s32 = SAI_POLICER_MODE_Sr_TCM;
        }
        else if(CLI_CLI_STR_EQUAL("tr-tcm", index + 1))
        {
            attr[attr_count].value.s32 = SAI_POLICER_MODE_Tr_TCM;
        }
        attr_count ++;
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("color-source-blind");
    if (0xFF != index)
    {
        attr[attr_count].id = SAI_POLICER_ATTR_COLOR_SOURCE;
        attr[attr_count].value.s32 = SAI_POLICER_COLOR_SOURCE_BLIND;
        attr_count ++;
    }
    index = CTC_CLI_GET_ARGC_INDEX("color-source-aware");
    if (0xFF != index)
    {
        attr[attr_count].id = SAI_POLICER_ATTR_COLOR_SOURCE;
        attr[attr_count].value.s32 = SAI_POLICER_COLOR_SOURCE_AWARE;
        attr_count ++;
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("cir");
    if(0xFF != index)
    {  
        attr[attr_count].id = SAI_POLICER_ATTR_CIR;
        CTC_CLI_GET_UINT64("cir", attr[attr_count].value.u64, argv[index + 1]);
        attr_count ++;
    }

    index = CTC_CLI_GET_ARGC_INDEX("cbs");
    if(0xFF != index)
    {  
        attr[attr_count].id = SAI_POLICER_ATTR_CBS;
        CTC_CLI_GET_UINT64("cbs", attr[attr_count].value.u64, argv[index + 1]);
        if(attr[attr_count].value.u64 > MAX_CBS_IN_SAI)
        {
            ctc_cli_out("%% Invalid cbs value\n"); \
            return CLI_ERROR; 
        }
        attr_count ++;
    }
    else
    {
        attr[attr_count].id = SAI_POLICER_ATTR_CBS;
        attr[attr_count].value.u64 = 8000;
        attr_count ++;
    }

    index = CTC_CLI_GET_ARGC_INDEX("pir");
    if(0xFF != index)
    {  
        attr[attr_count].id = SAI_POLICER_ATTR_PIR;
        CTC_CLI_GET_UINT64("pir", attr[attr_count].value.u64, argv[index + 1]);
        attr_count ++;
    }

    index = CTC_CLI_GET_ARGC_INDEX("pbs");
    if(0xFF != index)
    {  
        attr[attr_count].id = SAI_POLICER_ATTR_PBS;
        CTC_CLI_GET_UINT64("pbs", attr[attr_count].value.u64, argv[index + 1]);
        if(attr[attr_count].value.u64 > MAX_CBS_IN_SAI)
        {
            ctc_cli_out("%% Invalid pbs value\n"); \
            return CLI_ERROR; 
        }
        attr_count ++;
    }
    else
    {
        attr[attr_count].id = SAI_POLICER_ATTR_PBS;
        attr[attr_count].value.u64 = 8000;
        attr_count ++;
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("enable-counter-list");
    if(0xFF != index)
    {  
        attr[attr_count].id = SAI_POLICER_ATTR_ENABLE_COUNTER_LIST;
        attr[attr_count].value.s32 = 1;
        attr_count ++;
    }

    ret = sai_api_query(SAI_API_POLICER,(void**)&policer_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = policer_api->create_policer(&policer_id,attr_count,attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ctc_cli_out("%-10s:0x%-10llx\n","policer id",CTC_SAI_OBJECT_INDEX_GET(policer_id));

    return ret;
}

CTC_CLI(cli_sai_policer_delete_policer,
        cli_sai_policer_delete_policer_cmd,
        "policer remove POLICER-ID",
        "Policer",
        "Delete",
        "Policer id value")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint32_t     policer_id = 0;
    sai_object_id_t policer_oid;
    sai_policer_api_t*  policer_api;


    CTC_CLI_GET_UINT32("policer_id", policer_id, argv[0]);

    policer_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_POLICER, policer_id);

    ret = sai_api_query(SAI_API_POLICER,(void**)&policer_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = policer_api->remove_policer(policer_oid);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_policer_set_policer_attribute,
        cli_sai_policer_set_policer_attribute_cmd,
        "policer set-attribute policer-id POLICER-ID ((type-packet | type-bytes)|(mode (sr-tcm|tr-tcm)) |(color-source-blind|color-source-aware) |(cir CIR) |(cbs CBS ) |(pir PIR)| (pbs PBS) |(enable-counter-list|disable-counter-list))",
        "POLICER",
        "Update policer attribute",
        "Policer-id",
        "Policer-id value",
        "Policer packet type",
        "Policer byte type",
        "Policer mode",
        "Single rate mode",
        "Two rate mode",
        "Color-bind mode",
        "Color-aware mode",
        "Config CIR (Commit Information Rate)",
        "<0-12500000000>, unit is Bytes",
        "Config CBS (Commit Burst Size)",
        "<0-640000>, unit is Bytes",
        "Config PIR (Peak Information Rate), PIR(RFC2698) or EIR(RFC4115,BWP)",
        "<0-12500000000>, unit is Bytes",
        "Config PBS (Peak Burst Size), PBS(RFC2698,)or EBS (RFC2697, RFC4115,BWP)",
        "<0-640000>, unit is Bytes",
        "Policer stats enable",
        "Policer stats disable")
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint8 index = 0xFF;
    sai_object_id_t policer_id;
    uint32_t ctc_policer_id = 0;
    sai_policer_api_t*  policer_api;
    sai_attribute_t attr = {0};

    CTC_CLI_GET_UINT32("policer_id", ctc_policer_id, argv[0]);
    policer_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_POLICER, ctc_policer_id);
    
    index = CTC_CLI_GET_ARGC_INDEX("type-packet");
    if(0xFF != index)
    {
        ctc_cli_out("packet mode is not support!\n");
    }
    index = CTC_CLI_GET_ARGC_INDEX("type-bytes");
    if(0xFF != index)
    {
        attr.id = SAI_POLICER_ATTR_METER_TYPE;
        attr.value.s32 = SAI_METER_TYPE_BYTES;
    }

    index = CTC_CLI_GET_ARGC_INDEX("mode");
    if(0xFF != index)
    {
        attr.id = SAI_POLICER_ATTR_MODE;
        if (CLI_CLI_STR_EQUAL("sr-tcm", index + 1))
        {
            attr.value.s32 = SAI_POLICER_MODE_Sr_TCM;
        }
        else if(CLI_CLI_STR_EQUAL("tr-tcm", index + 1))
        {
            attr.value.s32 = SAI_POLICER_MODE_Tr_TCM;
        }
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("color-source-blind");
    if (0xFF != index)
    {
        attr.id = SAI_POLICER_ATTR_COLOR_SOURCE;
        attr.value.s32 = SAI_POLICER_COLOR_SOURCE_BLIND;
    }
    index = CTC_CLI_GET_ARGC_INDEX("color-source-aware");
    if (0xFF != index)
    {
        attr.id = SAI_POLICER_ATTR_COLOR_SOURCE;
        attr.value.s32 = SAI_POLICER_COLOR_SOURCE_AWARE;
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("cir");
    if(0xFF != index)
    {  
        attr.id = SAI_POLICER_ATTR_CIR;
        CTC_CLI_GET_UINT64("cir", attr.value.u64, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("cbs");
    if(0xFF != index)
    {  
        attr.id = SAI_POLICER_ATTR_CBS;
        CTC_CLI_GET_UINT64("cbs", attr.value.u64, argv[index + 1]);
        if(attr.value.u64 > MAX_CBS_IN_SAI)
        {
            ctc_cli_out("%% Invalid cbs value\n"); \
            return CLI_ERROR; 
        }
    }

    index = CTC_CLI_GET_ARGC_INDEX("pir");
    if(0xFF != index)
    {  
        attr.id = SAI_POLICER_ATTR_PIR;
        CTC_CLI_GET_UINT64("pir", attr.value.u64, argv[index + 1]);
    }

    index = CTC_CLI_GET_ARGC_INDEX("pbs");
    if(0xFF != index)
    {  
        attr.id = SAI_POLICER_ATTR_PBS;
        CTC_CLI_GET_UINT64("pbs", attr.value.u64, argv[index + 1]);
        if(attr.value.u64 > MAX_CBS_IN_SAI)
        {
            ctc_cli_out("%% Invalid pbs value\n"); \
            return CLI_ERROR; 
        }
    }
    
    index = CTC_CLI_GET_ARGC_INDEX("enable-counter-list");
    if(0xFF != index)
    {  
        attr.id = SAI_POLICER_ATTR_ENABLE_COUNTER_LIST;
        attr.value.s32 = 1;
    }
    index = CTC_CLI_GET_ARGC_INDEX("disable-counter-list");
    if(0xFF != index)
    {  
        attr.id = SAI_POLICER_ATTR_ENABLE_COUNTER_LIST;
        attr.value.s32 = 1;
    }

    ret = sai_api_query(SAI_API_POLICER,(void**)&policer_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = policer_api->set_policer_attribute(policer_id, &attr);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    return ret;
}

CTC_CLI(cli_sai_policer_get_policer_attribute,
        cli_sai_policer_get_policer_attribute_cmd,
        "policer get-attribute policer-id POLICER-ID (meter-type|mode|color-source|cir|cbs|pir |pbs |enable-counter-list|)",
        "POLICER",
        "Get policer attribute",
        "Policer-id",
        "Policer-id value",
        "meter-type",
        "Policer mode",
        "Color-source",
        "Config CIR (Commit Information Rate)",
        "Config CBS (Commit Burst Size)",
        "Config PIR (Peak Information Rate), PIR(RFC2698) or EIR(RFC4115,BWP)",
        "Config PBS (Peak Burst Size), PBS(RFC2698,)or EBS (RFC2697, RFC4115,BWP)",
        "Policer stats enable"
        )
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    uint8 index = 0xFF;
    sai_object_id_t policer_id;
    uint32_t ctc_policer_id = 0;
    sai_policer_api_t*  policer_api;
    sai_attribute_t attr[8];
    int attr_count = 0;
    char *meter_type[2] = {"type-packet", "type-bytes"};
    char *mode[2] = {"sr-tcm", "tr-tcm"};
    char * color_source[2] = {"color-blind","color-aware"};
    char * counter_enable[2] = {"counter_disbale", "counter_enable"};

   
    sal_memset(attr, 0x0, (sizeof(sai_attribute_t))*8);
    CTC_CLI_GET_UINT32("policer_id", ctc_policer_id, argv[0]);
    policer_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_POLICER, ctc_policer_id);
    if(argc > 1)
    {
        index = CTC_CLI_GET_ARGC_INDEX("meter-type");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_POLICER_ATTR_METER_TYPE;
        }
        index = CTC_CLI_GET_ARGC_INDEX("mode");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_POLICER_ATTR_MODE;
        }
        index = CTC_CLI_GET_ARGC_INDEX("color-source");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_POLICER_ATTR_COLOR_SOURCE;
        }
        index = CTC_CLI_GET_ARGC_INDEX("cbs");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_POLICER_ATTR_CBS;
        }
        index = CTC_CLI_GET_ARGC_INDEX("cir");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_POLICER_ATTR_CIR;
        }
        index = CTC_CLI_GET_ARGC_INDEX("pbs");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_POLICER_ATTR_PBS;
        }
        index = CTC_CLI_GET_ARGC_INDEX("pir");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_POLICER_ATTR_PIR;
        }
        index = CTC_CLI_GET_ARGC_INDEX("enable-counter-list");
        if(0xFF != index)
        {
            attr[attr_count].id = SAI_POLICER_ATTR_ENABLE_COUNTER_LIST;
        }
        attr_count ++;
        ret = sai_api_query(SAI_API_POLICER,(void**)&policer_api);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        ret = policer_api->get_policer_attribute(policer_id, attr_count, attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        switch(attr[0].id)
        {
            case SAI_POLICER_ATTR_METER_TYPE:
                ctc_cli_out("%s: %s \n", "meter-type", meter_type[attr[0].value.s32]);
                break;
            case SAI_POLICER_ATTR_MODE:
                ctc_cli_out("%s: %s \n", "mode", mode[attr[0].value.s32]);
                break;
            case SAI_POLICER_ATTR_COLOR_SOURCE:
                ctc_cli_out("%s: %s \n", "color-source", color_source[attr[0].value.s32]);
                break;
            case SAI_POLICER_ATTR_CBS:
                ctc_cli_out("%s: %lld \n", "cbs", attr[0].value.u64);
                break;
            case SAI_POLICER_ATTR_CIR:
                ctc_cli_out("%s: %lld \n", "cir", attr[0].value.u64);
                break;
            case SAI_POLICER_ATTR_PBS:
                ctc_cli_out("%s: %lld \n", "pbs", attr[0].value.u64);
                break;
            case SAI_POLICER_ATTR_PIR:
                ctc_cli_out("%s: %lld \n", "pir", attr[0].value.u64);
                break;
            case SAI_POLICER_ATTR_ENABLE_COUNTER_LIST:
                ctc_cli_out("%s: %s \n", "enable-counter-list", counter_enable[attr[0].value.s32]);
                break;
            default:
                break;
        }
    }
    else
    {
        attr[attr_count].id = SAI_POLICER_ATTR_METER_TYPE;
        attr_count ++;
        attr[attr_count].id = SAI_POLICER_ATTR_MODE;
        attr_count ++;
        attr[attr_count].id = SAI_POLICER_ATTR_COLOR_SOURCE;
        attr_count ++;
        attr[attr_count].id = SAI_POLICER_ATTR_CBS;
        attr_count ++;
        attr[attr_count].id = SAI_POLICER_ATTR_CIR;
        attr_count ++;
        attr[attr_count].id = SAI_POLICER_ATTR_PBS;
        attr_count ++;
        attr[attr_count].id = SAI_POLICER_ATTR_PIR;
        attr_count ++;
        attr[attr_count].id = SAI_POLICER_ATTR_ENABLE_COUNTER_LIST;
        attr_count ++;
        ret = sai_api_query(SAI_API_POLICER,(void**)&policer_api);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        ret = policer_api->get_policer_attribute(policer_id, attr_count, attr);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
            return CLI_SUCCESS;
        }

        ctc_cli_out("%-15s %-15s %-10s %-15s %-8s %-8s %-8s %-8s %-15s\n","policer-id", "meter-type", "mode", "color-source", "cbs", "cir", "pbs", "pir", "counter-enable");
        ctc_cli_out("%-15d %-15s %-10s %-15s %-8lld %-8lld %-8lld %-8lld %-15s\n",ctc_policer_id, meter_type[attr[0].value.s32], 
                     mode[attr[1].value.s32], color_source[attr[2].value.s32], attr[3].value.u64, attr[4].value.u64, attr[5].value.u64, attr[6].value.u64, counter_enable[attr[7].value.s32]);
    }

    return ret;
}

CTC_CLI(cli_sai_policer_get_policer_statistics,
        cli_sai_policer_get_policer_statistics_cmd,
        "policer get-statistics policer-id POLICER-ID",
        "POLICER",
        "Get policer statistics",
        "Policer-id",
        "Policer-id value"
        )
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    sai_object_id_t policer_id;
    uint32_t ctc_policer_id = 0;
    sai_policer_api_t*  policer_api;
    sai_policer_stat_counter_t counter_ids[8];
    uint32_t number_of_counters = 0;;
    uint64_t counters[8];

    sal_memset(&counters, 0x0,(sizeof(uint64_t))*8);
    sal_memset(&counter_ids, 0x0,(sizeof(sai_policer_stat_counter_t))*8);
    CTC_CLI_GET_UINT32("policer_id", ctc_policer_id, argv[0]);
    policer_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_POLICER, ctc_policer_id);

    counter_ids[number_of_counters] = SAI_POLICER_STAT_PACKETS;
    number_of_counters ++;
    counter_ids[number_of_counters] = SAI_POLICER_STAT_ATTR_BYTES;
    number_of_counters ++;
    counter_ids[number_of_counters] = SAI_POLICER_STAT_GREEN_PACKETS;
    number_of_counters ++;
    counter_ids[number_of_counters] = SAI_POLICER_STAT_GREEN_BYTES;
    number_of_counters ++;
    counter_ids[number_of_counters] = SAI_POLICER_STAT_YELLOW_PACKETS;
    number_of_counters ++;
    counter_ids[number_of_counters] = SAI_POLICER_STAT_YELLOW_BYTES;
    number_of_counters ++;
    counter_ids[number_of_counters] = SAI_POLICER_STAT_RED_PACKETS;
    number_of_counters ++;
    counter_ids[number_of_counters] = SAI_POLICER_STAT_RED_BYTES;
    number_of_counters ++;

    ret = sai_api_query(SAI_API_POLICER,(void**)&policer_api);
    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }

    ret = policer_api->get_policer_statistics(policer_id, counter_ids, number_of_counters, counters);

    if(SAI_STATUS_SUCCESS != ret)
    {
        ctc_cli_out("%% %s \n", ctc_sai_get_error_desc(ret));
        return CLI_SUCCESS;
    }
    ctc_cli_out("%-20s: %-15llu\n","stat-packet", counters[0]);
    ctc_cli_out("%-20s: %-15llu\n","stat-attr-bytes", counters[1]);
    ctc_cli_out("%-20s: %-15llu\n","stat-green-packets", counters[2]);
    ctc_cli_out("%-20s: %-15llu\n","stat-green-bytes", counters[3]);
    ctc_cli_out("%-20s: %-15llu\n","stat-yellow-packets", counters[4]);
    ctc_cli_out("%-20s: %-15llu\n","stat-yellow-bytes", counters[5]);
    ctc_cli_out("%-20s: %-15llu\n","stat-red-packets", counters[6]);
    ctc_cli_out("%-20s: %-15llu\n","stat-red-bytes", counters[7]);

    return ret;
}

int32
ctc_sai_policer_cli_init(uint8 cli_tree_mode)
{
    install_element(cli_tree_mode, &cli_sai_policer_create_policer_cmd);
    install_element(cli_tree_mode, &cli_sai_policer_delete_policer_cmd);
    install_element(cli_tree_mode, &cli_sai_policer_set_policer_attribute_cmd);
    install_element(cli_tree_mode, &cli_sai_policer_get_policer_attribute_cmd);
    install_element(cli_tree_mode, &cli_sai_policer_get_policer_statistics_cmd);

    return CLI_SUCCESS;
}

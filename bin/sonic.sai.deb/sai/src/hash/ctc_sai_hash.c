#include <sal.h>
#include <sai.h>
#include "ctc_api.h"
#include <saitypes.h>
#include <saistatus.h>
#include <saihash.h>
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_sai.h>
#include <ctc_sai_hash.h>
#include <ctc_sai_debug.h>

static ctc_sai_check_u32_range_t g_range_type_limit =
{
    .min = SAI_NATIVE_HASH_FIELD_SRC_IP,
    .max = SAI_NATIVE_HASH_FIELD_MAX,
};

static ctc_sai_attr_entry_info_t g_sai_attr_entries[] = {
    {
        .id     = SAI_HASH_NATIVE_FIELD_LIST,
        .type   = SAI_ATTR_FALG_CREATE  | SAI_ATTR_FALG_READ,
        .check_fn = {
            .func_fn = ctc_sai_check_i32_range_fn,
            .func_parameter = &g_range_type_limit,
        }
    },
    {
        .id     = SAI_HASH_UDF_GROUP_LIST,
        .type   = SAI_ATTR_FALG_CREATE  | SAI_ATTR_FALG_READ,
    },
};

static struct ctc_sai_hash_info_s g_ctc_sai_hash_info;

ctc_sai_hash_entry_t*
ctc_sai_hash_entry_get(sai_object_id_t hash_id)
{
    uint32 i = 0;

    for (i = 0; i < HASH_ID_MAX_NUM; i++)
    {
        if (hash_id == g_ctc_sai_hash_info.hash[i].hash_id)
        {
            return &g_ctc_sai_hash_info.hash[i];
        }
    }   
    return NULL;
}

#define ________SAI_SAI_INNER_DEBUG_FUNC
sai_status_t
ctc_sai_create_hash_debug_param(
    _Out_ sai_object_id_t* hash_id,
    _In_ uint32_t attr_count,
    _In_ sai_attribute_t *attr_list)
{
    const sai_attribute_t *pattr_entry = NULL;
    uint32_t          attr_idx = 0; 
    uint32_t          list_idx = 0; 
    uint32            type = 0;

    for (attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        pattr_entry = attr_list + attr_idx;
        switch (pattr_entry->id)
        {
        case SAI_HASH_NATIVE_FIELD_LIST:
            for(list_idx = 0; list_idx < pattr_entry->value.u32list.count; list_idx++)
            {
                type = pattr_entry->value.u32list.list[list_idx];
                switch (type)
                {
                case SAI_NATIVE_HASH_FIELD_SRC_IP:
                    CTC_SAI_DEBUG("out:SAI_NATIVE_HASH_FIELD_SRC_IP");
                    break;
                case SAI_NATIVE_HASH_FIELD_DST_IP:
                    CTC_SAI_DEBUG("out:SAI_NATIVE_HASH_FIELD_DST_IP");
                    break;
                case SAI_NATIVE_HASH_FIELD_SRC_MAC:
                    CTC_SAI_DEBUG("out:SAI_NATIVE_HASH_FIELD_SRC_MAC");
                    break;
                case SAI_NATIVE_HASH_FIELD_DST_MAC:
                    CTC_SAI_DEBUG("out:SAI_NATIVE_HASH_FIELD_DST_MAC");
                    break;
                default:
                    CTC_SAI_DEBUG("in:NOT SUPPORT");
                    break;
                }
            }
            break;
         default:
            break;
        }
    }

    return SAI_STATUS_SUCCESS;
}
sai_status_t
ctc_sai_set_hash_attribute_debug_param(
    _In_ sai_object_id_t hash_id,
    _In_ const sai_attribute_t *attr)
{
    uint32       list_idx = 0;
    uint32       type = 0;

    switch (attr->id)
    {
        case SAI_HASH_NATIVE_FIELD_LIST:
            for(list_idx = 0; list_idx < attr->value.u32list.count; list_idx++)
            {
                type = attr->value.u32list.list[list_idx];
                switch (type)
                {
                case SAI_NATIVE_HASH_FIELD_SRC_IP:
                    CTC_SAI_DEBUG("in:SAI_NATIVE_HASH_FIELD_SRC_IP");
                    break;
                case SAI_NATIVE_HASH_FIELD_DST_IP:
                    CTC_SAI_DEBUG("in:SAI_NATIVE_HASH_FIELD_DST_IP");
                    break;
                case SAI_NATIVE_HASH_FIELD_VLAN_ID:
                    CTC_SAI_DEBUG("in:SAI_NATIVE_HASH_FIELD_VLAN_ID");
                    break;
                case SAI_NATIVE_HASH_FIELD_ETHERTYPE:
                    CTC_SAI_DEBUG("in:SAI_NATIVE_HASH_FIELD_ETHERTYPE");
                    break;
                case SAI_NATIVE_HASH_FIELD_L4_SRC_PORT:
                    CTC_SAI_DEBUG("in:SAI_NATIVE_HASH_FIELD_L4_SRC_PORT");
                    break;
                case SAI_NATIVE_HASH_FIELD_L4_DST_PORT:
                    CTC_SAI_DEBUG("in:SAI_NATIVE_HASH_FIELD_L4_DST_PORT");
                    break;
                case SAI_NATIVE_HASH_FIELD_IP_PROTOCOL:          
                    CTC_SAI_DEBUG("in:SAI_NATIVE_HASH_FIELD_IP_PROTOCOL");
                    break;
                case SAI_NATIVE_HASH_FIELD_SRC_MAC:
                    CTC_SAI_DEBUG("in:SAI_NATIVE_HASH_FIELD_SRC_MAC");
                    break;
                case SAI_NATIVE_HASH_FIELD_DST_MAC:
                    CTC_SAI_DEBUG("in:SAI_NATIVE_HASH_FIELD_DST_MAC");
                    break;
                case SAI_NATIVE_HASH_FIELD_INNER_SRC_MAC:
                    CTC_SAI_DEBUG("in:SAI_NATIVE_HASH_FIELD_INNER_SRC_MAC");
                    break;
                case SAI_NATIVE_HASH_FIELD_INNER_DST_MAC:
                    CTC_SAI_DEBUG("in:SAI_NATIVE_HASH_FIELD_INNER_DST_MAC");
                    break;
                case SAI_NATIVE_HASH_FIELD_VXLAN_VNI:
                    CTC_SAI_DEBUG("in:SAI_NATIVE_HASH_FIELD_VXLAN_VNI");
                    break;
                case SAI_NATIVE_HASH_FIELD_INNER_SRC_IP:
                    CTC_SAI_DEBUG("in:SAI_NATIVE_HASH_FIELD_INNER_SRC_IP");
                    break;
                case SAI_NATIVE_HASH_FIELD_INNER_DST_IP:
                    CTC_SAI_DEBUG("in:SAI_NATIVE_HASH_FIELD_INNER_DST_IP");
                    break;
                default:
                    CTC_SAI_DEBUG("in:NOT SUPPORT");
                    break;
                }
            }
        default:
            break;
    }

    return SAI_STATUS_SUCCESS;
}
#define ________SAI_SAI_INNER_API_FUNC
sai_status_t
ctc_sai_hash_db_init()
{
    g_ctc_sai_hash_info.max_count = HASH_ID_MAX_NUM;         /*  hash id*/

    if (0 != ctc_opf_init(CTC_OPF_SAI_HASH_ID,1))
    {
        return SAI_STATUS_NO_MEMORY;
    }
    g_ctc_sai_hash_info.opf.pool_type = CTC_OPF_SAI_HASH_ID;
    g_ctc_sai_hash_info.opf.pool_index= 0;

    if (0 != ctc_opf_init_offset(&g_ctc_sai_hash_info.opf,0,g_ctc_sai_hash_info.max_count))
    {
        return SAI_STATUS_NO_MEMORY;
    }
    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_hash_create_hash(
    _Out_ sai_object_id_t* hash_id,
    _In_ uint32_t attr_count,
    _In_ sai_attribute_t *attr_list)
{
    uint32_t          opf_index;
    uint32_t          list_idx = 0; 
    uint32_t          attr_idx = 0; 
    uint32            type = 0;
    sai_attribute_t*  attr = NULL;
    ctc_sai_hash_entry_t *p_entry = NULL;
   
    if (0 != ctc_opf_alloc_offset(&g_ctc_sai_hash_info.opf, 0, &opf_index))
    {
        return SAI_STATUS_INSUFFICIENT_RESOURCES;
    }

    p_entry = &g_ctc_sai_hash_info.hash[opf_index];
    *hash_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_HASH, opf_index);
    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        switch (attr->id)
        {
        case SAI_HASH_NATIVE_FIELD_LIST:
            for(list_idx = 0; list_idx < attr->value.u32list.count; list_idx++)
            {
                type = attr->value.u32list.list[list_idx];
                switch (type)
                {
                case SAI_NATIVE_HASH_FIELD_SRC_IP:
                case SAI_NATIVE_HASH_FIELD_DST_IP:
                case SAI_NATIVE_HASH_FIELD_VLAN_ID:
                case SAI_NATIVE_HASH_FIELD_ETHERTYPE:
                case SAI_NATIVE_HASH_FIELD_L4_SRC_PORT:
                case SAI_NATIVE_HASH_FIELD_L4_DST_PORT:
                case SAI_NATIVE_HASH_FIELD_IP_PROTOCOL:          
                case SAI_NATIVE_HASH_FIELD_SRC_MAC:
                case SAI_NATIVE_HASH_FIELD_DST_MAC:
                case SAI_NATIVE_HASH_FIELD_VXLAN_VNI:
                case SAI_NATIVE_HASH_FIELD_INNER_DST_MAC:
                case SAI_NATIVE_HASH_FIELD_INNER_SRC_MAC:
                case SAI_NATIVE_HASH_FIELD_INNER_SRC_IP:
                case SAI_NATIVE_HASH_FIELD_INNER_DST_IP:
                case SAI_NATIVE_HASH_FIELD_GRE_KEY:
                case SAI_NATIVE_HASH_FIELD_NVGRE_VNI:
                case SAI_NATIVE_HASH_FIELD_NVGRE_FLOWID:
                    CTC_BIT_SET(p_entry->flags, type);
                    break;
                default:
                    return SAI_STATUS_INVALID_PARAMETER;
                }
            }
        break;     
            
        default:
            break;
        }
    }  
    
    p_entry->hash_id = *hash_id;
    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_create_hash(
    _Out_ sai_object_id_t* hash_id,
    _In_ uint32_t attr_count,
    _In_ sai_attribute_t *attr_list)
{
    sai_status_t ret = SAI_STATUS_SUCCESS;
    ctc_sai_attr_entry_list_t* pattr_entry_list = NULL;
    
    CTC_SAI_DEBUG_FUNC();
    ctc_sai_create_hash_debug_param(hash_id, attr_count, attr_list);
    CTC_SAI_PTR_VALID_CHECK(attr_list);
    CTC_SAI_PTR_VALID_CHECK(hash_id);
    
    CTC_SAI_ERROR_GOTO(ctc_sai_attr_alloc_attr_entry_list(g_sai_attr_entries,
                            attr_list,
                            attr_count,
                            &pattr_entry_list),ret,out);

    ret = ctc_sai_hash_create_hash(hash_id, attr_count, attr_list);
    if (SAI_STATUS_SUCCESS != ret)
    {
        return ret;
    }
    CTC_SAI_DEBUG("out:hash_id 0x%llx", (*hash_id));
    
out:
    if(pattr_entry_list)
    {
        ctc_sai_attr_free_attr_entry_list(pattr_entry_list);
    }
    return ret;
}

sai_status_t
ctc_sai_remove_hash(
    _In_ sai_object_id_t hash_id)
{
    CTC_SAI_DEBUG_FUNC();
    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_set_hash_attribute(
    _In_ sai_object_id_t hash_id,
    _In_ const sai_attribute_t *attr)
{ 
    uint32       list_idx = 0;
    uint32       type = 0;
    ctc_sai_hash_entry_t *p_entry = NULL;
    
    CTC_SAI_DEBUG_FUNC();
    ctc_sai_set_hash_attribute_debug_param(hash_id, attr);
    CTC_SAI_PTR_VALID_CHECK(attr);
 
    if (SAI_OBJECT_TYPE_HASH != CTC_SAI_OBJECT_TYPE_GET(hash_id))
    {
         return SAI_STATUS_INVALID_PARAMETER;
    } 
    p_entry = ctc_sai_hash_entry_get(hash_id);
    if (NULL == p_entry)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }
    p_entry->flags = 0;
    switch (attr->id)
    {
        case SAI_HASH_NATIVE_FIELD_LIST:
            for(list_idx = 0; list_idx < attr->value.u32list.count; list_idx++)
            {
                type = attr->value.u32list.list[list_idx];
                switch (type)
                {
                case SAI_NATIVE_HASH_FIELD_SRC_IP:
                case SAI_NATIVE_HASH_FIELD_DST_IP:
                case SAI_NATIVE_HASH_FIELD_VLAN_ID:
                case SAI_NATIVE_HASH_FIELD_ETHERTYPE:
                case SAI_NATIVE_HASH_FIELD_L4_SRC_PORT:
                case SAI_NATIVE_HASH_FIELD_L4_DST_PORT:
                case SAI_NATIVE_HASH_FIELD_IP_PROTOCOL:          
                case SAI_NATIVE_HASH_FIELD_SRC_MAC:
                case SAI_NATIVE_HASH_FIELD_DST_MAC:
                case SAI_NATIVE_HASH_FIELD_VXLAN_VNI:
                case SAI_NATIVE_HASH_FIELD_INNER_DST_MAC:
                case SAI_NATIVE_HASH_FIELD_INNER_SRC_MAC:
                case SAI_NATIVE_HASH_FIELD_INNER_SRC_IP:
                case SAI_NATIVE_HASH_FIELD_INNER_DST_IP:
                case SAI_NATIVE_HASH_FIELD_INNER_IP_PROTOCOL:
                case SAI_NATIVE_HASH_FIELD_INNER_L4_SRC_PORT:
                case SAI_NATIVE_HASH_FIELD_INNER_L4_DST_PORT:
                case SAI_NATIVE_HASH_FIELD_GRE_KEY:
                case SAI_NATIVE_HASH_FIELD_NVGRE_VNI:
                case SAI_NATIVE_HASH_FIELD_NVGRE_FLOWID:
                    CTC_BIT_SET(p_entry->flags, type);
                    break;
                default:
                    return SAI_STATUS_INVALID_PARAMETER;
                }
            }
        break; 
        
        default:
            return SAI_STATUS_INVALID_PARAMETER;
    }
    p_entry->hash_id = hash_id;
    return SAI_STATUS_SUCCESS;
}
           

sai_status_t
ctc_sai_get_hash_attribute(
    _In_ sai_object_id_t hash_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr)
{
    CTC_SAI_DEBUG_FUNC();
    return SAI_STATUS_SUCCESS;
}

#define ________SAI_INNER_FUNC
static sai_status_t
__init_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    ret = ctc_sai_hash_db_init();
    if(SAI_STATUS_SUCCESS != ret)
    {
        return ret;
    }
    preg->init_status =  INITIALIZED;
    return ret;
}

static sai_status_t
__exit_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}

/* define sai 0.9.3 */
static sai_hash_api_t      g_sai_api_func = {
    .create_hash            = ctc_sai_create_hash,
    .remove_hash            = ctc_sai_remove_hash,
    .set_hash_attribute     = ctc_sai_set_hash_attribute,
    .get_hash_attribute     = ctc_sai_get_hash_attribute,
};
static ctc_sai_api_reg_info_t g_api_reg_info = {
        .id        = SAI_API_HASH,
        .init_func = __init_mode_fn,
        .exit_func = __exit_mode_fn,
        .api_method_table = &g_sai_api_func,
        .private_data     = NULL,
};

#define ________SAI_FDB_OUTER_FUNC
sai_status_t
ctc_sai_hash_init()
{
    api_reg_register_fn(&g_api_reg_info);

    return SAI_STATUS_SUCCESS;
}



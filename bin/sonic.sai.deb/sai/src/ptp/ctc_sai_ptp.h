#if !defined (__CTC_SAI_PTP_H_)
#define __CTC_SAI_PTP_H_

#include <sai.h>

sai_status_t
ctc_sai_ptp_init();

#endif

#include <sal.h>
#include "ctc_api.h"
#include "sal_error.h"
#include <sai.h>
#include <saitypes.h>
#include <saistatus.h>
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_sai.h>
#include <ctc_sai_port.h>
#include <ctc_sai_debug.h>


#define NS_PER_SEC (1000000000)

ctc_ptp_time_t
calc_ctc_ptp_time_offset(ctc_ptp_time_t *ts1, ctc_ptp_time_t *ts2)
{
    ctc_ptp_time_t ret_val;
    int64 offset_ns = 0;
    
    offset_ns = ((int64)ts1->seconds - (int64)ts2->seconds) * NS_PER_SEC + ((int64)ts1->nanoseconds - (int64)ts2->nanoseconds);

    if (offset_ns < 0)
    {
        ret_val.is_negative = 1;
        offset_ns = -offset_ns;
    }
    else
    {
        ret_val.is_negative = 0;
    }

    ret_val.seconds = offset_ns / NS_PER_SEC;
    ret_val.nanoseconds = offset_ns % NS_PER_SEC;

    return ret_val;
}

sai_status_t
ctc_sai_ptp_set_device_type(const sai_attribute_t *attr)
{
    ctc_ptp_device_type_t ctc_type = 0;
    uint32 sai_type = 0;
    int32 sdk_ret = 0;
    
    sai_type = attr->value.u32;
    switch (sai_type)
    {
    case SAI_PTP_DEVICE_NONE:
        ctc_type = CTC_PTP_DEVICE_NONE;
        break;

    case SAI_PTP_DEVICE_OC:
        ctc_type = CTC_PTP_DEVICE_OC;
        break;

    case SAI_PTP_DEVICE_BC:
        ctc_type = CTC_PTP_DEVICE_BC;
        break;
        
    case SAI_PTP_DEVICE_E2E_TC:
        ctc_type = CTC_PTP_DEVICE_E2E_TC;
        break;
        
    case SAI_PTP_DEVICE_P2P_TC:
        ctc_type = CTC_PTP_DEVICE_P2P_TC;
        break;

    default:
        return SAI_STATUS_INVALID_PARAMETER;
    }
    
    sdk_ret = ctc_ptp_set_device_type(ctc_type);
    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_sai_ptp_set_timestamp(const sai_attribute_t *attr)
{
    uint8 lchip_id = 0;
    struct timeval tv;
    ctc_ptp_time_t cpu_timestamp;
    ctc_ptp_time_t chip_timestamp;
    ctc_ptp_time_t offset;
    int32 sdk_ret = SAI_STATUS_SUCCESS;

    sal_memset(&cpu_timestamp, 0, sizeof(cpu_timestamp));
    sal_memset(&chip_timestamp, 0, sizeof(chip_timestamp));
    sal_memset(&offset, 0, sizeof(offset));

    /* 1. get chip timestamp */
    ctc_ptp_get_clock_timestamp(lchip_id, &chip_timestamp);

    /* 2. get CPU timestamp */
    if (0 == attr->value.s32list.count)
    {
        gettimeofday(&tv, NULL);
        cpu_timestamp.seconds = tv.tv_sec;
        cpu_timestamp.nanoseconds = tv.tv_usec * 1000;
    }
    else if (2 == attr->value.s32list.count)
    {
        cpu_timestamp.seconds = attr->value.s32list.list[0];
        cpu_timestamp.nanoseconds = attr->value.s32list.list[1];
    }
    else
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }

    /* 3. calcuate offset */
    offset = calc_ctc_ptp_time_offset(&cpu_timestamp, &chip_timestamp);

    CTC_SAI_DEBUG("cpu_ts: %u.%09u, chip_ts: %u.%09u, offset: %s%u.%09u", 
        cpu_timestamp.seconds, cpu_timestamp.nanoseconds, chip_timestamp.seconds, chip_timestamp.nanoseconds,
        offset.is_negative ? "-" : "", offset.seconds, offset.nanoseconds);


    /* 4. write to CHIP */
    sdk_ret = ctc_ptp_adjust_clock_offset(lchip_id, &offset);

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_sai_ptp_set_adjust_offset(const sai_attribute_t *attr)
{
    uint8 lchip_id = 0;
    ctc_ptp_time_t offset;
    int32 sdk_ret = SAI_STATUS_SUCCESS;

    sal_memset(&offset, 0, sizeof(offset));

    /* 1. get CPU timestamp */
    if (2 == attr->value.s32list.count)
    {
        offset.seconds = attr->value.s32list.list[0];
        offset.nanoseconds = attr->value.s32list.list[1];
    }
    else
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }

    /* 2. calcuate offset */
#if 0
extern void log_sys(int, int, const char *fmt, ...);
    log_sys(2, 7, "offset: %s%u.%09u", offset.is_negative ? "-" : "", offset.seconds, offset.nanoseconds);
#endif

    /* 3. write to CHIP */
    sdk_ret = ctc_ptp_adjust_clock_offset(lchip_id, &offset);

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_sai_set_ptp_attribute(
    _In_ const sai_attribute_t  *attr
    )
{
    int32 ret = SAI_STATUS_SUCCESS;

    switch(attr->id)
    {
    case SAI_PTP_ATTR_DEVICE_TYPE:
        ret = ctc_sai_ptp_set_device_type(attr);
        break;
    case SAI_PTP_ATTR_TIMESTAMP:
        ret = ctc_sai_ptp_set_timestamp(attr);
        break;
    case SAI_PTP_ATTR_ADJUST_OFFSET:
        ret = ctc_sai_ptp_set_adjust_offset(attr);
        break;
    }
    
    return ret;
}

sai_status_t
ctc_sai_get_ptp_attribute(
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list
    )
{
    
    return SAI_STATUS_SUCCESS;
}

#define ________SAI_PTP_INNER_FUNC

static sai_status_t
__init_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    preg->init_status = INITIALIZED;

out:
    return ret;

    goto out;
}

static sai_status_t
__exit_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}

static sai_ptp_api_t g_sai_api_func = {
        .set_ptp_attribute               = ctc_sai_set_ptp_attribute,
        .get_ptp_attribute               = ctc_sai_get_ptp_attribute,
};

static ctc_sai_api_reg_info_t g_api_reg_info = {
        .id         = SAI_API_PTP,
        .init_func  = __init_mode_fn,
        .exit_func  = __exit_mode_fn,
        .api_method_table = &g_sai_api_func,
        .private_data     = NULL,
};

#define ________SAI_PTP_OUTER_FUNC
sai_status_t
ctc_sai_ptp_init()
{
    api_reg_register_fn(&g_api_reg_info);

    return SAI_STATUS_SUCCESS;
}


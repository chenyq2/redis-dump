
#include <sal.h>
#include "ctc_api.h"
#include "sal_error.h"
#include <sai.h>
#include <saitypes.h>
#include <saistatus.h>
#include "ctc_hash.h"
#include <sys/socket.h>
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_sai.h>
#include <ctc_sai_vlan.h>
#include <ctc_sai_port.h>
#include <ctc_sai_neighbor.h>
#include <ctc_sai_nexthop.h>
#include <ctc_sai_stp.h>
#include <ctc_sai_routerintf.h>
#include <ctc_sai_hostif.h>
#include <ctc_sai_fdb.h>
#include <ctc_sai_debug.h>
#include <ctc_sai_copp.h>
#include <ctc_sai_router.h>
#include <ctc_sai_vrrp.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(2, 6, 32)
#define NLA_ALIGNTO           4
#define NLA_ALIGN(len)        (((len) + NLA_ALIGNTO - 1) & ~(NLA_ALIGNTO - 1))
#define NLA_HDRLEN            ((int) NLA_ALIGN(sizeof(struct nlattr)))

struct nlattr {
    __u16           nla_len;
    __u16           nla_type;
};
#endif /* LINUX_VERSION_CODE */

extern int32  memory_check_pktdiscard;

ctc_sai_hostif_info_t g_hostif_info;
uint32 trap_id_for_group[3] = {CTC_PKT_CPU_REASON_L2_PDU + CTC_L2PDU_ACTION_INDEX_EAPOL, CTC_PKT_CPU_REASON_L3_COPY_CPU, CTC_PKT_CPU_REASON_L3_MTU_FAIL};
extern uint64
ctc_sai_policer_get_pir_by_policer_id(uint32 policer_id);
#define ________SAI_SAI_INNER_API_FUNC
uint32_t sai_trap_action_to_ctc_action(sai_hostif_trap_id_t trapid, sai_packet_action_t action)
{
    if (trapid  < SAI_HOSTIF_TRAP_ID_SWITCH_CUSTOM_RANGE_BASE)
    {
        switch (action)
        {
        case SAI_PACKET_ACTION_DROP:
            return CTC_PDU_L2PDU_ACTION_TYPE_DISCARD;

        case SAI_PACKET_ACTION_FORWARD:
            return CTC_PDU_L2PDU_ACTION_TYPE_FWD;

        case SAI_PACKET_ACTION_TRAP:
            return CTC_PDU_L2PDU_ACTION_TYPE_REDIRECT_TO_CPU;

        case SAI_PACKET_ACTION_LOG:
            return CTC_PDU_L2PDU_ACTION_TYPE_COPY_TO_CPU;

        default:
            return CTC_E_NOT_SUPPORT;
        }
    }
    else
    {
        switch (action)
        {
        case SAI_PACKET_ACTION_DROP:
            return CTC_PDU_L3PDU_ACTION_TYPE_FWD;

        case SAI_PACKET_ACTION_FORWARD:
            return CTC_PDU_L3PDU_ACTION_TYPE_FWD;

        case SAI_PACKET_ACTION_TRAP:
            return CTC_PDU_L3PDU_ACTION_TYPE_FWD;

        case SAI_PACKET_ACTION_LOG:
            return CTC_PDU_L3PDU_ACTION_TYPE_COPY_TO_CPU;

        default:
            return CTC_E_NOT_SUPPORT;
        }
    }

    return SAI_STATUS_FAILURE;
}

uint32_t sai_trap_id_to_ctc_reason_id(sai_hostif_trap_id_t trapid)
{
    switch (trapid)
    {

    /*
    * switch trap 
    */

    case SAI_HOSTIF_TRAP_ID_STP:
        return CTC_PKT_CPU_REASON_L2_PDU + CTC_L2PDU_ACTION_INDEX_BPDU;

    case SAI_HOSTIF_TRAP_ID_LACP:
        return CTC_PKT_CPU_REASON_L2_PDU + CTC_L2PDU_ACTION_INDEX_SLOW_PROTO;

    case SAI_HOSTIF_TRAP_ID_EAPOL:
        return CTC_PKT_CPU_REASON_L2_PDU + CTC_L2PDU_ACTION_INDEX_EAPOL;

    case SAI_HOSTIF_TRAP_ID_LLDP:
        return CTC_PKT_CPU_REASON_L2_PDU + CTC_L2PDU_ACTION_INDEX_LLDP;

    case SAI_HOSTIF_TRAP_ID_ERPS:
         return CTC_PKT_CPU_REASON_L2_PDU + CTC_L2PDU_ACTION_INDEX_ERPS;

    case SAI_HOSTIF_TRAP_ID_PVRST:
        return CTC_PKT_CPU_REASON_CUSTOM_BASE;

    case SAI_HOSTIF_TRAP_ID_IGMP:
        return CTC_PKT_CPU_REASON_IGMP_SNOOPING;

    case SAI_HOSTIF_TRAP_ID_IGMP_TYPE_QUERY:
        return CTC_PKT_CPU_REASON_IGMP_SNOOPING;

    case SAI_HOSTIF_TRAP_ID_IGMP_TYPE_LEAVE:
        return CTC_PKT_CPU_REASON_IGMP_SNOOPING;

    case SAI_HOSTIF_TRAP_ID_IGMP_TYPE_V1_REPORT:
        return CTC_PKT_CPU_REASON_IGMP_SNOOPING;

    case SAI_HOSTIF_TRAP_ID_IGMP_TYPE_V2_REPORT:
        return CTC_PKT_CPU_REASON_IGMP_SNOOPING;

    case SAI_HOSTIF_TRAP_ID_IGMP_TYPE_V3_REPORT:
        return CTC_PKT_CPU_REASON_IGMP_SNOOPING;

    /*
    * router trap 
    */

    case SAI_HOSTIF_TRAP_ID_ARP_REQUEST:
#ifdef GREATBELT
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_ARP_V2;

    case SAI_HOSTIF_TRAP_ID_ARP_RESPONSE:
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_ARP_V2;

    case SAI_HOSTIF_TRAP_ID_DHCP:
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_DHCP_V2;
#else
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_ARP;

    case SAI_HOSTIF_TRAP_ID_ARP_RESPONSE:
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_ARP;

    case SAI_HOSTIF_TRAP_ID_DHCP:
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_DHCP;
#endif

    case SAI_HOSTIF_TRAP_ID_ARP:
#ifdef GREATBELT
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_ARP_V2;
#else
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_ARP;
#endif

    case SAI_HOSTIF_TRAP_ID_OSPF:  
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_OSPF;

    case SAI_HOSTIF_TRAP_ID_PIM:
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_PIM;

    case SAI_HOSTIF_TRAP_ID_VRRP:
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_VRRP;

    case SAI_HOSTIF_TRAP_ID_BGP:
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_BGP;

    case SAI_HOSTIF_TRAP_ID_DHCPV6:
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_DHCP;

    case SAI_HOSTIF_TRAP_ID_OSPFV6:  
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_OSPF;

    case SAI_HOSTIF_TRAP_ID_VRRPV6: 
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_VRRP;

    case SAI_HOSTIF_TRAP_ID_BGPV6:
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_BGP;

    case SAI_HOSTIF_TRAP_ID_IPV6_NEIGHBOR_DISCOVERY:
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_ICMPV6;

    case SAI_HOSTIF_TRAP_ID_IPV6_MLD_V1_V2:
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_PIM;

    case SAI_HOSTIF_TRAP_ID_IPV6_MLD_V1_REPORT:
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_PIM;

    case SAI_HOSTIF_TRAP_ID_IPV6_MLD_V1_DONE:
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_PIM;

    case SAI_HOSTIF_TRAP_ID_MLD_V2_REPORT:
        return CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_PIM;

    /* 
    * pipeline exceptions   
    */

    case SAI_HOSTIF_TRAP_ID_L3_MTU_ERROR:  
        return CTC_PKT_CPU_REASON_L3_MTU_FAIL;

    case SAI_HOSTIF_TRAP_ID_TTL_ERROR:
        return CTC_PKT_CPU_REASON_IP_TTL_CHECK_FAIL;

    case SAI_HOSTIF_TRAP_ID_L2_PORT_MAC_LIMIT:
        return CTC_PKT_CPU_REASON_L2_PORT_LEARN_LIMIT;

    case SAI_HOSTIF_TRAP_ID_L2_PORT_MAC_MISMATCH:
        return CTC_PKT_CPU_REASON_L2_MOVE;

    case SAI_HOSTIF_TRAP_ID_SCL_MATCH:
        return CTC_PKT_CPU_REASON_SCL_MATCH;

    /*
     * Centec extension, added by lixd, 2017-02-08 
     */
    case SAI_HOSTIF_TRAP_ID_CUSTOM_EXCEPTION_L3_COPY_CPU:
    case SAI_HOSTIF_TRAP_ID_FWD_TO_CPU:
        return CTC_PKT_CPU_REASON_L3_COPY_CPU;

    case SAI_HOSTIF_TRAP_ID_CUSTOM_EXCEPTION_OPENFLOW_TO_CONTROLLER:
        return CTC_PKT_CPU_REASON_CUSTOM_BASE + 1; /*GLB_PKT_CUSTOM_TOCPU_OPENFLOW_MIN*/

    default:
        return CTC_PKT_CPU_REASON_CUSTOM_BASE;
    }

    return CTC_PKT_CPU_REASON_CUSTOM_BASE;
}

inline void
ctc_sai_set_reason_channel(const uint32_t reason_id, const sai_hostif_trap_channel_t channel)
{
    g_hostif_info.ctc_reason[reason_id].channel = channel;
}


inline void
ctc_sai_set_reason_trap(const uint32_t reason_id, const sai_int32_t hostif_trap_id)
{
    g_hostif_info.ctc_reason[reason_id].hostif_trap_id = hostif_trap_id;
}

inline sai_hostif_trap_channel_t
ctc_sai_get_reason_channel(const uint32_t reason_id)
{
    return g_hostif_info.ctc_reason[reason_id].channel;
}

inline sai_int32_t
ctc_sai_get_reason_trap(const uint32_t reason_id)
{
    return g_hostif_info.ctc_reason[reason_id].hostif_trap_id;
}

static uint32_t
_hostif_hash_make(
    _In_  void* data)
{
    ctc_sai_hostif_t* p_hostif_key = (ctc_sai_hostif_t*)data;
    return ctc_hash_caculate(sizeof(sai_object_id_t), &p_hostif_key->hostif_id);
}

static bool
_hostif_hash_cmp(
    _In_ void *data,
    _In_ void *data1)
{
    ctc_sai_hostif_t* p_hostif_key = data;
    ctc_sai_hostif_t* p_hostif_key1 = data1;

    if (p_hostif_key->hostif_id == p_hostif_key1->hostif_id)
    {
        return TRUE;
    }

    return FALSE;
}

static uint32_t
_hostif_fd_hash_make(
    _In_  void* data)
{
    ctc_sai_hostif_t* p_hostif_key = (ctc_sai_hostif_t*)data;
    return ctc_hash_caculate(sizeof(uint32), &p_hostif_key->fd);
}

static bool
_hostif_fd_hash_cmp(
    _In_ void *data,
    _In_ void *data1)
{
    ctc_sai_hostif_t* p_hostif_key = data;
    ctc_sai_hostif_t* p_hostif_key1 = data1;

    if (p_hostif_key->fd == p_hostif_key1->fd)
    {
        return TRUE;
    }

    return FALSE;
}

static uint32_t
_hostif_port_hash_make(
    _In_  void* data)
{
    ctc_sai_hostif_t* p_hostif_key = (ctc_sai_hostif_t*)data;

    return ctc_hash_caculate(sizeof(sai_object_id_t), &p_hostif_key->port);
}

static bool
_hostif_port_hash_cmp(
    _In_ void *data,
    _In_ void *data1)
{
    ctc_sai_hostif_t* p_hostif_key = data;
    ctc_sai_hostif_t* p_hostif_key1 = data1;

    if (p_hostif_key->port == p_hostif_key1->port)
    {
        return TRUE;
    }

    return FALSE;
}

static uint32_t
_hostif_vlan_hash_make(
    _In_  void* data)
{
    ctc_sai_hostif_t* p_hostif_key = (ctc_sai_hostif_t*)data;
    uint32 vlanid = 0;
    vlanid = CTC_SAI_OBJECT_INDEX_GET(p_hostif_key->vlanid);
    return ctc_hash_caculate(sizeof(uint32), &vlanid);
}

static bool
_hostif_vlan_hash_cmp(
    _In_ void *data,
    _In_ void *data1)
{
    ctc_sai_hostif_t* p_hostif_key = data;
    ctc_sai_hostif_t* p_hostif_key1 = data1;

    if ((p_hostif_key->vlanid&0xffffffff) == (p_hostif_key1->vlanid&0xffffffff))
    {
        return TRUE;
    }

    return FALSE;
}

static uint32_t
_hostif_arp_fdb_hash_make(
    _In_  void* data)
{
    ctc_sai_arp_fdb_t* p_arp_fdb_key = (ctc_sai_arp_fdb_t*)data;

    return ctc_hash_caculate((sizeof(mac_addr_t)+sizeof(uint32)), p_arp_fdb_key);
}

static bool
_hostif_arp_fdb_hash_cmp(
    _In_ void *data,
    _In_ void *data1)
{
    ctc_sai_arp_fdb_t* p_arp_fdb_key  = data;
    ctc_sai_arp_fdb_t* p_arp_fdb_key1 = data1;

    if ((p_arp_fdb_key->vlanid == p_arp_fdb_key1->vlanid)
        && (0 == sal_memcmp(p_arp_fdb_key->mac_address, p_arp_fdb_key1->mac_address, sizeof(mac_addr_t))))
    {
        return TRUE;
    }

    return FALSE;
}

ctc_sai_hostif_group_t*
ctc_sai_hostif_group_db_oid(const sai_object_id_t hostif_group_id)
{
    ctc_sai_hostif_group_t *hostif_group = NULL;
    struct ctc_listnode* node            = NULL;

    for (node = g_hostif_info.hostif_group_list->head; node; CTC_NEXTNODE(node))
    {
        hostif_group = CTC_GETDATA(node);
        if (hostif_group && hostif_group->hostif_group_id == hostif_group_id)
        {
            return hostif_group;
        }

    }

    return NULL;
}

ctc_sai_hostif_group_t*
ctc_sai_hostif_group_db_alloc()
{
    ctc_sai_hostif_group_t *hostif_group = NULL;
    uint32_t index = 0;
    int ret = 0;

    hostif_group = mem_malloc(MEM_APP_HOSTIF_MODULE,sizeof(ctc_sai_hostif_group_t));
    if (NULL == hostif_group)
    {
        return NULL;
    }

    sal_memset(hostif_group, 0, sizeof(ctc_sai_hostif_group_t));
    ret = ctc_opf_alloc_offset(&g_hostif_info.opf, 0, &index);
    if (ret)
    {
        return NULL;
    }

    hostif_group->hostif_group_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_TRAP_GROUP, index);
    ctc_listnode_add(g_hostif_info.hostif_group_list, hostif_group);
    return hostif_group;
}

void
ctc_sai_hostif_group_db_release(ctc_sai_hostif_group_t *hostif_group)
{
    ctc_sai_hostif_group_t *hostif_group_db = NULL;
    if(NULL == hostif_group)
    {
        return;
    }

    hostif_group_db = ctc_sai_hostif_group_db_oid(hostif_group->hostif_group_id);
    if (NULL == hostif_group_db)
    {
        return;
    }

    ctc_listnode_delete(g_hostif_info.hostif_group_list, hostif_group);
    ctc_opf_free_offset(&g_hostif_info.opf, 0, CTC_SAI_OBJECT_INDEX_GET(hostif_group->hostif_group_id));
    mem_free(hostif_group);
}

ctc_sai_hostif_trap_t*
ctc_sai_hostif_trap_db_trap_id(const uint32_t hostif_trap_id)
{
    ctc_sai_hostif_trap_t *hostif_trap = NULL;
    struct ctc_listnode* node          = NULL;

    for (node = g_hostif_info.hostif_trap_list->head; node; CTC_NEXTNODE(node))
    {
        hostif_trap = CTC_GETDATA(node);
        if (NULL != hostif_trap)
        {
            if (hostif_trap->hostif_trap_id == hostif_trap_id)
            {
                return hostif_trap;
            }
        }
    }

    return NULL;
}

ctc_sai_hostif_trap_t*
ctc_sai_hostif_trap_db_alloc(sai_uint32_t hostif_trap_id)
{
    ctc_sai_hostif_trap_t *hostif_trap = NULL;

    hostif_trap = mem_malloc(MEM_APP_HOSTIF_MODULE,sizeof(ctc_sai_hostif_trap_t));

    sal_memset(hostif_trap, 0, sizeof(ctc_sai_hostif_group_t));
    hostif_trap->hostif_trap_id = hostif_trap_id;

    ctc_listnode_add(g_hostif_info.hostif_trap_list, hostif_trap);
    return hostif_trap;
}

void
ctc_sai_hostif_trap_db_release(ctc_sai_hostif_trap_t *hostif_trap)
{
    ctc_sai_hostif_trap_t *hostif_trap_db = NULL;
    if(NULL == hostif_trap_db)
    {
        return;
    }

    hostif_trap_db = ctc_sai_hostif_trap_db_trap_id(hostif_trap->hostif_trap_id);
    if (NULL == hostif_trap_db)
    {
        return;
    }

    ctc_listnode_delete(g_hostif_info.hostif_trap_list, hostif_trap);
    mem_free(hostif_trap);
}

ctc_sai_hostif_t*
ctc_sai_hostif_get_by_hostif_id(sai_object_id_t hif_id)
{
    ctc_sai_hostif_t hostif;

    sal_memset(&hostif, 0, sizeof(hostif));
    hostif.hostif_id = hif_id;
    return ctc_hash_lookup(g_hostif_info.hostif_hash, &hostif);
}

ctc_sai_hostif_t*
ctc_sai_hostif_get_by_fd(const int fd)
{
    ctc_sai_hostif_t hostif;

    sal_memset(&hostif, 0, sizeof(hostif));
    hostif.fd = fd;
    return ctc_hash_lookup(g_hostif_info.hostif_fd_hash, &hostif);
}

ctc_sai_hostif_t*
ctc_sai_hostif_get_by_port(sai_object_id_t portid)
{
    ctc_sai_hostif_t hostif;

    sal_memset(&hostif, 0, sizeof(hostif));
    hostif.port = portid;
    return ctc_hash_lookup(g_hostif_info.hostif_port_hash, &hostif);
}

ctc_sai_hostif_t*
ctc_sai_hostif_get_by_vlan(uint32 vlan)
{
    ctc_sai_hostif_t hostif;

    sal_memset(&hostif, 0, sizeof(hostif));
    hostif.vlanid = vlan;
    return ctc_hash_lookup(g_hostif_info.hostif_vlan_hash, &hostif);
}

ctc_sai_hostif_t*
ctc_sai_hostif_db_alloc(char *ifname, int fd, sai_object_id_t portid, uint32 vlanid)
{
    ctc_sai_hostif_t *hostif = NULL;
    ctc_nh_info_t nh_info;
    uint32 nhid = 0;
    uint32 gport = 0;
    uint32 index = 0;
    int ret = 0;

    ret = ctc_opf_alloc_offset(&g_hostif_info.hosif_id_opf, 0, &index);
    if (ret)
    {
        return NULL;
    }

    hostif = mem_malloc(MEM_APP_HOSTIF_MODULE,sizeof(ctc_sai_hostif_t));
    if (NULL == hostif)
    {
        return NULL;
    }

    sal_memset(hostif, 0, sizeof(ctc_sai_hostif_t));
    sal_strcpy(hostif->ifname, ifname);
    hostif->fd = fd;
    hostif->port = portid;
    hostif->vlanid = vlanid;
    hostif->hostif_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_HOST_INTERFACE, index);

    sal_memset(&nh_info, 0, sizeof(nh_info));
    if (vlanid)
    {
        /* for vlan interface, all ports basic dsnh_offset is same, use gport 0's dsnh_offset */
        gport = 0;
    }
    else
    {
        ctc_sai_port_objectid_to_gport(portid, &gport);
    }
    ctc_nh_get_l2uc(gport, CTC_NH_PARAM_BRGUC_SUB_TYPE_BASIC, &nhid);
    ctc_nh_get_nh_info(nhid, &nh_info);
    hostif->nexthop_ptr = nh_info.dsnh_offset[0];

    ctc_hash_insert(g_hostif_info.hostif_port_hash, hostif);
    ctc_hash_insert(g_hostif_info.hostif_fd_hash, hostif);
    ctc_listnode_add(g_hostif_info.hostif_port_list, hostif);
    if (0 != vlanid)
    {
        ctc_hash_insert(g_hostif_info.hostif_vlan_hash, hostif);
    }
    return ctc_hash_insert(g_hostif_info.hostif_hash, hostif);
}

void
ctc_sai_hostif_db_release(ctc_sai_hostif_t *hostif)
{
    if(NULL == hostif)
    {
        return;
    }

    ctc_opf_free_offset(&g_hostif_info.hosif_id_opf, 0, CTC_SAI_OBJECT_INDEX_GET(hostif->hostif_id));

    if (0 != hostif->vlanid)
    {
        ctc_hash_remove(g_hostif_info.hostif_vlan_hash, hostif);
    }

    ctc_hash_remove(g_hostif_info.hostif_port_hash, hostif);
    ctc_hash_remove(g_hostif_info.hostif_fd_hash, hostif);
    ctc_hash_remove(g_hostif_info.hostif_hash, hostif);
    ctc_listnode_delete(g_hostif_info.hostif_port_list, hostif);
    mem_free(hostif);
}

int32
ctc_sai_reason_pdu_enable(uint32_t reason_id, uint32_t gport, uint32_t action)
{
    switch (reason_id)
    {
    case (CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_ARP):
        ctc_port_set_property(gport, CTC_PORT_PROP_L3PDU_ARP_ACTION, action);
        break;

    case (CTC_PKT_CPU_REASON_L2_PDU + CTC_L2PDU_ACTION_INDEX_BPDU):
        ctc_l2pdu_set_port_action (gport, CTC_L2PDU_ACTION_INDEX_BPDU, action);
        break;

    case (CTC_PKT_CPU_REASON_L2_PDU + CTC_L2PDU_ACTION_INDEX_LLDP):
        ctc_l2pdu_set_port_action (gport, CTC_L2PDU_ACTION_INDEX_LLDP, action);
        break;

    case (CTC_PKT_CPU_REASON_L2_PDU + CTC_L2PDU_ACTION_INDEX_SLOW_PROTO):
        ctc_l2pdu_set_port_action (gport, CTC_L2PDU_ACTION_INDEX_SLOW_PROTO, action);
        break;
    }

    return SAI_STATUS_SUCCESS;
}

int ctc_sai_erps_init(void)
{
    ctc_pdu_global_l2pdu_action_t l2pdu_action;
    ctc_pdu_l2pdu_key_t l2pdu_key;
    int32 ret = 0;
    FILE *startup_config_fd = NULL;
    char buf[256];
    bool erps_mode_huawei = FALSE;

    startup_config_fd = sal_fopen("/mnt/flash/startup-config.conf", "r");
    if (startup_config_fd)
    {
        while (sal_fgets(buf, 128, startup_config_fd))
        {   
            if (!sal_strncmp(buf, "erps mode rrpp", sal_strlen("erps mode rrpp")))
            {
                erps_mode_huawei = TRUE;
                break;
            }
        }
        sal_fclose(startup_config_fd);
    }

    if (!erps_mode_huawei)
    {
        /* ERPS hello/link down/flush address */  
        l2pdu_key.l2hdr_proto = 0;
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac, 0x01, 0x80, 0x63, 0x07, 0x00, 0x00);
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac_mask, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff);
        ret = ctc_l2pdu_classify_l2pdu(
                CTC_PDU_L2PDU_TYPE_MACDA,
                SAI_L2PDU_KEY_INDEX_ERPS_COMMON,
                &l2pdu_key);
        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_classify_l2pdu common return %d\n", ret);
        }
        
        l2pdu_action.bypass_all   = 0;
        l2pdu_action.copy_to_cpu  = 1;
        l2pdu_action.entry_valid  = 1;
        l2pdu_action.action_index = CTC_L2PDU_ACTION_INDEX_ERPS;    
        ret = ctc_l2pdu_set_global_action(
                 CTC_PDU_L2PDU_TYPE_MACDA,
                 SAI_L2PDU_KEY_INDEX_ERPS_COMMON,
                 &l2pdu_action);
        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_set_global_action common return %d\n", ret);
        }
    
        /* ERPS edge hello/major fault address */  
        l2pdu_key.l2hdr_proto = 0;
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac, 0x00, 0x01, 0x7A, 0x4F, 0x48, 0x26);
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac_mask, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff);
        ret = ctc_l2pdu_classify_l2pdu(
                 CTC_PDU_L2PDU_TYPE_MACDA,
                 SAI_L2PDU_KEY_INDEX_ERPS_FLUSH,
                 &l2pdu_key);
        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_classify_l2pdu flush return %d\n", ret);
        }
    
        l2pdu_action.bypass_all   = 0;
        l2pdu_action.copy_to_cpu  = 1;
        l2pdu_action.entry_valid  = 1;
        l2pdu_action.action_index = CTC_L2PDU_ACTION_INDEX_ERPS;
        ret = ctc_l2pdu_set_global_action(
                 CTC_PDU_L2PDU_TYPE_MACDA,
                 SAI_L2PDU_KEY_INDEX_ERPS_FLUSH,
                 &l2pdu_action);
        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_set_global_action flush return %d\n", ret);
        }
    }
    else
    {
        /* modified by wangjj for fix erps bug 42041, 2016-12-14 */
        /* ERPS hello/link down/flush address */
        l2pdu_key.l2hdr_proto = 0;
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac, 0x00, 0x0f, 0xe2, 0x07, 0x82, 0x00);
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac_mask, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00);
        ret = ctc_l2pdu_classify_l2pdu(
                CTC_PDU_L2PDU_TYPE_MACDA,
                SAI_L2PDU_KEY_INDEX_ERPS_COMMON,
                &l2pdu_key);
        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_classify_l2pdu common return %d\n", ret);
        }

        l2pdu_action.bypass_all   = 0;
        l2pdu_action.copy_to_cpu  = 1;
        l2pdu_action.entry_valid  = 1;
        l2pdu_action.action_index = CTC_L2PDU_ACTION_INDEX_ERPS;
        ret = ctc_l2pdu_set_global_action(
                 CTC_PDU_L2PDU_TYPE_MACDA,
                 SAI_L2PDU_KEY_INDEX_ERPS_COMMON,
                 &l2pdu_action);
        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_set_global_action common return %d\n", ret);
        }

        /* ERPS edge hello/major fault address */
        l2pdu_key.l2hdr_proto = 0;
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac, 0x01, 0x80, 0x63, 0x07, 0x00, 0x00);
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac_mask, 0xff, 0xff, 0xff, 0xff, 0xff, 0xfd);
        ret = ctc_l2pdu_classify_l2pdu(
                 CTC_PDU_L2PDU_TYPE_MACDA,
                 SAI_L2PDU_KEY_INDEX_ERPS_FLUSH,
                 &l2pdu_key);
        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_classify_l2pdu flush return %d\n", ret);
        }

        l2pdu_action.bypass_all   = 0;
        l2pdu_action.copy_to_cpu  = 1;
        l2pdu_action.entry_valid  = 1;
        l2pdu_action.action_index = CTC_L2PDU_ACTION_INDEX_ERPS;
        ret = ctc_l2pdu_set_global_action(
                 CTC_PDU_L2PDU_TYPE_MACDA,
                 SAI_L2PDU_KEY_INDEX_ERPS_FLUSH,
                 &l2pdu_action);
        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_set_global_action flush return %d\n", ret);
        }

        #if 0
        /* erps addr1 for hw */
        l2pdu_key.l2hdr_proto = 0;
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac, 0x00, 0x0f, 0xE2, 0x07, 0x82, 0x17);
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac_mask, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff);
        ret = ctc_l2pdu_classify_l2pdu(
                 CTC_PDU_L2PDU_TYPE_MACDA,
                 SAI_L2PDU_KEY_INDEX_ERPS_HW_ADDR1,
                 &l2pdu_key);
        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_classify_l2pdu flush return %d\n", ret);
        }
    
        l2pdu_action.bypass_all   = 0;
        l2pdu_action.copy_to_cpu  = 1;
        l2pdu_action.entry_valid  = 1;
        l2pdu_action.action_index = CTC_L2PDU_ACTION_INDEX_ERPS;
        ret = ctc_l2pdu_set_global_action(
                 CTC_PDU_L2PDU_TYPE_MACDA,
                 SAI_L2PDU_KEY_INDEX_ERPS_HW_ADDR1,
                 &l2pdu_action);
        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_set_global_action flush return %d\n", ret);
        }
    
        /* erps addr2 for hw */
        l2pdu_key.l2hdr_proto = 0;
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac, 0x00, 0x0f, 0xE2, 0x07, 0x82, 0x57);
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac_mask, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff);
        ret = ctc_l2pdu_classify_l2pdu(
                 CTC_PDU_L2PDU_TYPE_MACDA,
                 SAI_L2PDU_KEY_INDEX_ERPS_HW_ADDR2,
                 &l2pdu_key);
        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_classify_l2pdu flush return %d\n", ret);
        }
    
        l2pdu_action.bypass_all   = 0;
        l2pdu_action.copy_to_cpu  = 1;
        l2pdu_action.entry_valid  = 1;
        l2pdu_action.action_index = CTC_L2PDU_ACTION_INDEX_ERPS;
        ret = ctc_l2pdu_set_global_action(
                 CTC_PDU_L2PDU_TYPE_MACDA,
                 SAI_L2PDU_KEY_INDEX_ERPS_HW_ADDR2,
                 &l2pdu_action);
        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_set_global_action flush return %d\n", ret);
        }

        /* erps addr3 for hw */
        l2pdu_key.l2hdr_proto = 0;
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac, 0x00, 0x0f, 0xE2, 0x07, 0x82, 0x97);
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac_mask, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff);
        ret = ctc_l2pdu_classify_l2pdu(
                 CTC_PDU_L2PDU_TYPE_MACDA,
                 SAI_L2PDU_KEY_INDEX_ERPS_HW_ADDR3,
                 &l2pdu_key);
        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_classify_l2pdu flush return %d\n", ret);
        }
    
        l2pdu_action.bypass_all   = 0;
        l2pdu_action.copy_to_cpu  = 1;
        l2pdu_action.entry_valid  = 1;
        l2pdu_action.action_index = CTC_L2PDU_ACTION_INDEX_ERPS;
        ret = ctc_l2pdu_set_global_action(
                 CTC_PDU_L2PDU_TYPE_MACDA,
                 SAI_L2PDU_KEY_INDEX_ERPS_HW_ADDR3,
                 &l2pdu_action);
        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_set_global_action flush return %d\n", ret);
        }
    
        /* erps addr4 for hw */
        l2pdu_key.l2hdr_proto = 0;
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac, 0x00, 0x0f, 0xE2, 0x07, 0x82, 0xd6);
        CTC_SAI_CPU_TRAFFIC_SET_MAC(l2pdu_key.l2pdu_by_mac.mac_mask, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff);
        ret = ctc_l2pdu_classify_l2pdu(
                 CTC_PDU_L2PDU_TYPE_MACDA,
                 SAI_L2PDU_KEY_INDEX_ERPS_HW_ADDR4,
                 &l2pdu_key);
        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_classify_l2pdu flush return %d\n", ret);
        }
    
        l2pdu_action.bypass_all   = 0;
        l2pdu_action.copy_to_cpu  = 1;
        l2pdu_action.entry_valid  = 1;
        l2pdu_action.action_index = CTC_L2PDU_ACTION_INDEX_ERPS;
        ret = ctc_l2pdu_set_global_action(
                 CTC_PDU_L2PDU_TYPE_MACDA,
                 SAI_L2PDU_KEY_INDEX_ERPS_HW_ADDR4,
                 &l2pdu_action);

        if (ret)
        {
            sal_printf("ctc_sai_erps_init ctc_l2pdu_set_global_action flush return %d\n", ret);
        }
        #endif
    }

    return ret;
}

int32 ctc_sai_cpu_traffic_init(void)
{
    ctc_qos_queue_cfg_t    qos_queue_cfg;
    uint32 cpu_reason_id = 0;
    int32 ret = 0;
    
    /*init all cpu reason to default queue*/
    for(cpu_reason_id = CTC_PKT_CPU_REASON_DROP; cpu_reason_id <= CTC_PKT_CPU_REASON_ARP_MISS; cpu_reason_id++)
    {
        /*set l3_copy_to_cpu (management traffic) trap to queue 6*/
        if(CTC_PKT_CPU_REASON_L3_COPY_CPU == cpu_reason_id)
        {
            sal_memset(&qos_queue_cfg, 0, sizeof(ctc_qos_queue_cfg_t));
            qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_REASON_MAP;

            qos_queue_cfg.value.reason_map.cpu_reason = cpu_reason_id + CTC_PKT_CPU_REASON_CUSTOM_BASE*2;
            qos_queue_cfg.value.reason_map.queue_id = 6;
            qos_queue_cfg.value.reason_map.reason_group = 0;
            ret += ctc_qos_set_queue(&qos_queue_cfg);

            sal_memset(&qos_queue_cfg, 0, sizeof(ctc_qos_queue_cfg_t));
            qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_STATS_EN;
            qos_queue_cfg.value.stats.queue.queue_type = CTC_QUEUE_TYPE_EXCP_CPU;  

            qos_queue_cfg.value.stats.queue.cpu_reason = cpu_reason_id + CTC_PKT_CPU_REASON_CUSTOM_BASE*2;
            qos_queue_cfg.value.stats.stats_en = 1;
            ret += ctc_qos_set_queue(&qos_queue_cfg);
        }   
        
        /*set copp protocol traffic mapping queue 5, these reasons is ilooped to cpu*/
        else if(CTC_PKT_CPU_REASON_L2_PDU + CTC_L2PDU_ACTION_INDEX_BPDU == cpu_reason_id 
           || CTC_PKT_CPU_REASON_L2_PDU + CTC_L2PDU_ACTION_INDEX_SLOW_PROTO== cpu_reason_id 
           || CTC_PKT_CPU_REASON_L2_PDU + CTC_L2PDU_ACTION_INDEX_LLDP== cpu_reason_id 
           || CTC_PKT_CPU_REASON_L2_PDU + CTC_L2PDU_ACTION_INDEX_EAPOL== cpu_reason_id 
           || CTC_PKT_CPU_REASON_L2_PDU + CTC_L2PDU_ACTION_INDEX_ERPS == cpu_reason_id 
           || CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_OSPF == cpu_reason_id 
           || CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_BGP == cpu_reason_id 
           || CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_VRRP == cpu_reason_id 
           || CTC_PKT_CPU_REASON_IGMP_SNOOPING == cpu_reason_id 
           || CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_PIM == cpu_reason_id 
           || CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_DHCP == cpu_reason_id)
        {
            sal_memset(&qos_queue_cfg, 0, sizeof(ctc_qos_queue_cfg_t));
            qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_REASON_MAP;

            qos_queue_cfg.value.reason_map.cpu_reason = cpu_reason_id + CTC_PKT_CPU_REASON_CUSTOM_BASE*2;
            qos_queue_cfg.value.reason_map.queue_id = 5;
            qos_queue_cfg.value.reason_map.reason_group = 0;
            ret += ctc_qos_set_queue(&qos_queue_cfg);

            sal_memset(&qos_queue_cfg, 0, sizeof(ctc_qos_queue_cfg_t));
            qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_STATS_EN;
            qos_queue_cfg.value.stats.queue.queue_type = CTC_QUEUE_TYPE_EXCP_CPU;  
            qos_queue_cfg.value.stats.queue.cpu_reason = cpu_reason_id + CTC_PKT_CPU_REASON_CUSTOM_BASE*2;
            qos_queue_cfg.value.stats.stats_en = 1;
            ret += ctc_qos_set_queue(&qos_queue_cfg);
        }

        /*set arp trap to queue 1*/
        else if(CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_ARP == cpu_reason_id)
        {
            sal_memset(&qos_queue_cfg, 0, sizeof(ctc_qos_queue_cfg_t));
            qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_REASON_MAP;

            qos_queue_cfg.value.reason_map.cpu_reason = cpu_reason_id + CTC_PKT_CPU_REASON_CUSTOM_BASE*2;
            qos_queue_cfg.value.reason_map.queue_id = 1;
            qos_queue_cfg.value.reason_map.reason_group = 0;
            ret += ctc_qos_set_queue(&qos_queue_cfg);

            sal_memset(&qos_queue_cfg, 0, sizeof(ctc_qos_queue_cfg_t));
            qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_STATS_EN;
            qos_queue_cfg.value.stats.queue.queue_type = CTC_QUEUE_TYPE_EXCP_CPU;  
            qos_queue_cfg.value.stats.queue.cpu_reason = cpu_reason_id + CTC_PKT_CPU_REASON_CUSTOM_BASE*2;

            qos_queue_cfg.value.stats.stats_en = 1;
            ret += ctc_qos_set_queue(&qos_queue_cfg);
        }        

        /*others to queue 0 */
        else
        {
            sal_memset(&qos_queue_cfg, 0, sizeof(ctc_qos_queue_cfg_t));
            qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_REASON_MAP;
            qos_queue_cfg.value.reason_map.cpu_reason = cpu_reason_id;
            qos_queue_cfg.value.reason_map.queue_id = 0;
            qos_queue_cfg.value.reason_map.reason_group = 0;
            ret += ctc_qos_set_queue(&qos_queue_cfg);
        }

        /*should discard the following reason packets, because we re-mapping 
        different reason to different queue, so the sdk inited reason is modified, must reinit here*/
        if (CTC_PKT_CPU_REASON_L3_MARTIAN_ADDR == cpu_reason_id
            || CTC_PKT_CPU_REASON_L3_URPF_FAIL == cpu_reason_id
            || CTC_PKT_CPU_REASON_IPMC_TTL_CHECK_FAIL == cpu_reason_id
            || CTC_PKT_CPU_REASON_MPLS_TTL_CHECK_FAIL == cpu_reason_id
            || CTC_PKT_CPU_REASON_GRE_UNKNOWN == cpu_reason_id
            || CTC_PKT_CPU_REASON_LABEL_MISS == cpu_reason_id
            || CTC_PKT_CPU_REASON_OAM_HASH_CONFLICT == cpu_reason_id)
        {
            /*drop reason*/
            qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_REASON_DEST;
            qos_queue_cfg.value.reason_dest.cpu_reason = cpu_reason_id;
            qos_queue_cfg.value.reason_dest.dest_type = CTC_PKT_CPU_REASON_TO_DROP;
            ret += ctc_qos_set_queue(&qos_queue_cfg);
        }
        
    }

    /*openflow tp controller to queue 1*/
    /*CTC_PKT_CPU_REASON_CUSTOM_BASE + GLB_PKT_CUSTOM_TOCPU_OPENFLOW_MIN*/
    cpu_reason_id = CTC_PKT_CPU_REASON_CUSTOM_BASE + 1;
    sal_memset(&qos_queue_cfg, 0, sizeof(ctc_qos_queue_cfg_t));
    qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_REASON_MAP;

    qos_queue_cfg.value.reason_map.cpu_reason = cpu_reason_id + CTC_PKT_CPU_REASON_CUSTOM_BASE*2;
    qos_queue_cfg.value.reason_map.queue_id = 1;
    qos_queue_cfg.value.reason_map.reason_group = 0;
    ret += ctc_qos_set_queue(&qos_queue_cfg);

    sal_memset(&qos_queue_cfg, 0, sizeof(ctc_qos_queue_cfg_t));
    qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_STATS_EN;
    qos_queue_cfg.value.stats.queue.queue_type = CTC_QUEUE_TYPE_EXCP_CPU;  
    qos_queue_cfg.value.stats.queue.cpu_reason = cpu_reason_id + CTC_PKT_CPU_REASON_CUSTOM_BASE*2;
    qos_queue_cfg.value.stats.stats_en = 1;
    ret += ctc_qos_set_queue(&qos_queue_cfg);
            
#ifdef GREATBELT
    qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_REASON_MODE;
    qos_queue_cfg.value.reason_mode.group_type = CTC_PKT_CPU_REASON_GROUP_FORWARD; 
    qos_queue_cfg.value.reason_mode.group_id = 0;
    qos_queue_cfg.value.reason_mode.mode = CTC_PKT_MODE_DMA;
    ret += ctc_qos_set_queue(&qos_queue_cfg);
#endif

    sal_memset(&qos_queue_cfg, 0, sizeof(ctc_qos_queue_cfg_t));
    qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_REASON_MAP;
    qos_queue_cfg.value.reason_map.cpu_reason = CTC_PKT_CPU_REASON_CUSTOM_BASE + 1;/*for hybrid packet in GLB_PKT_CUSTOM_TOCPU_OPENFLOW_MIN*/
    qos_queue_cfg.value.reason_map.queue_id = 1;
    qos_queue_cfg.value.reason_map.reason_group = 0;
    ret += ctc_qos_set_queue(&qos_queue_cfg);

    sal_memset(&qos_queue_cfg, 0, sizeof(ctc_qos_queue_cfg_t));
    qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_REASON_DEST;
    qos_queue_cfg.value.reason_dest.cpu_reason = CTC_PKT_CPU_REASON_CUSTOM_BASE + 1;
    qos_queue_cfg.value.reason_dest.dest_type = CTC_PKT_CPU_REASON_TO_LOCAL_CPU;
    ret += ctc_qos_set_queue(&qos_queue_cfg);
    
    ctc_sai_erps_init();

    return ret;
}

int32
ctc_sock_set_nonblocking (sal_sock_handle_t sock, int32 state)
{
    int val = 0;

    val = fcntl (sock, F_GETFL, 0);
    if (SAL_SOCK_ERROR != val)
    {
        fcntl (sock, F_SETFL, (state ? val | O_NONBLOCK : val & (~O_NONBLOCK)));
        return 0;
    }
    else
    {
        return errno;
    }
}

int32
ctc_netlink_talk(struct nlmsghdr *n)
{
    struct sockaddr_nl snl;
    struct iovec iov = { (void *) n, n->nlmsg_len };
    struct msghdr msg = { (void *) &snl, sizeof snl, &iov, 1, NULL, 0, 0 };
    int32 status = 0;
    int32 save_errno = 0;

    sal_memset (&snl, 0, sizeof snl);
    snl.nl_family = AF_NETLINK;

    n->nlmsg_seq = ++g_hostif_info.seq;
    status = sendmsg(g_hostif_info.sock, &msg, 0);
    save_errno = errno;

    if (status < 0)
    {
        printf("_lib_netlink_talk sendmsg() error: %s", sal_strerror(save_errno));
        return SAI_STATUS_FAILURE;
    }

    return SAI_STATUS_SUCCESS;
}

int32
ctc_get_ifindex(struct nlmsghdr *nhmsg, void *data)
{
    struct ifinfomsg *ifinfo = NULL;
    int *ifindex = data;

    ifinfo = (void *)NLMSG_DATA(nhmsg);

    *ifindex = ifinfo->ifi_index;
    return SAI_STATUS_SUCCESS;
}

static int32
ctc_netlink_parse(int32 (*dispatch)(struct nlmsghdr *, void *), void *data)
{
    int32 status = 0;
    int32 rc = SAI_STATUS_SUCCESS;

    while (1)
    {
        char buf[4096];
        struct iovec iov = {buf, sizeof buf};
        struct sockaddr_nl snl;
        struct msghdr msg = { (void*)&snl, sizeof snl, &iov, 1, NULL, 0, 0};
        struct nlmsghdr *h;

        status = recvmsg(g_hostif_info.sock, &msg, 0);
        if (status < 0)
        {
            if (EINTR == errno)
            {
                continue;
            }
            
            if (EWOULDBLOCK == errno || EAGAIN == errno)
            {
                break;
            }
            
            if (ESPIPE == errno)
            {
                printf("recvmsg overrun: %s", sal_strerror(errno));
                break;
            }
        }

        if (snl.nl_pid != 0)
        {
            continue;
        }

        if (status == 0)
        {
            return SAI_STATUS_FAILURE;
        }

        if (msg.msg_namelen != sizeof snl)
        {
            return SAI_STATUS_FAILURE;
        }

        for (h = (struct nlmsghdr *) buf; NLMSG_OK (h, status); h = NLMSG_NEXT (h, status))
        {
            /* Finish of reading. */
            if (h->nlmsg_type == NLMSG_DONE)
            {
                return rc;
            }

            /* Error handling. */
            if (h->nlmsg_type == NLMSG_ERROR)
            {
                struct nlmsgerr *err = (struct nlmsgerr *) NLMSG_DATA (h);

                /* Sometimes the nlmsg_type is NLMSG_ERROR but the err->error
                 *                  is 0. This is a success. */
                if (err->error == 0)
                {
                    /* return if not a multipart message, otherwise continue */
                    if (!(h->nlmsg_flags & NLM_F_MULTI))
                    {
                        return SAI_STATUS_SUCCESS;
                    }
                    continue;
                }

                if (h->nlmsg_len < NLMSG_LENGTH (sizeof (struct nlmsgerr)))
                {
                    return SAI_STATUS_FAILURE;
                }

                return SAI_STATUS_FAILURE;
            }
     
            rc = (*dispatch) (h, data);
            if (rc < 0)
            {
                return rc;
            }
        }

        /* After error care. */
        if (msg.msg_flags & MSG_TRUNC)
        {
            continue;
        }
        
        if (status)
        {
            return SAI_STATUS_FAILURE;
        }
    }

    return rc;
}

int32
ctc_netlink_get_link(int *ifindex, char *ifname)
{
    struct nlattr *pt_nlattr = NULL;
    uint8 *pt_buf            = NULL;
    char *pt_ifname          = NULL;

    struct netlink_link_msg {
        struct nlmsghdr header;
        struct ifinfomsg ifinfo;
        uint8 buffer[1024];
    }link_msg;

    sal_memset(&link_msg, 0, sizeof(struct netlink_link_msg));
    link_msg.header.nlmsg_len = 0;
    link_msg.header.nlmsg_type = RTM_GETLINK;
    link_msg.header.nlmsg_flags = NLM_F_REQUEST | NLM_F_ACK;
    link_msg.header.nlmsg_seq = 0;
    link_msg.header.nlmsg_pid = 0;

    link_msg.ifinfo.ifi_family = 0;
    link_msg.ifinfo.ifi_type   = 0;
    link_msg.ifinfo.ifi_index  = 0;
    link_msg.ifinfo.ifi_flags  = 0;
    link_msg.ifinfo.ifi_change = 0;

    link_msg.header.nlmsg_len = sizeof(struct nlmsghdr) + sizeof(struct ifinfomsg);

    pt_buf = link_msg.buffer;
    pt_nlattr = (void *)pt_buf;
    pt_nlattr->nla_type = IFLA_IFNAME;
    pt_nlattr->nla_len  = NLA_ALIGN(16 + sizeof(struct nlattr));
    pt_ifname = (void*)(pt_buf + NLA_ALIGN(sizeof(struct nlattr)));
    sal_strcpy(pt_ifname, ifname);
    pt_buf = pt_buf + NLA_ALIGN(16 + sizeof(struct nlattr));
    link_msg.header.nlmsg_len += NLA_ALIGN(16  + sizeof(struct nlattr));

    ctc_netlink_talk((void *)&link_msg);

    ctc_netlink_parse(ctc_get_ifindex, ifindex);    
    return SAI_STATUS_SUCCESS;
}

int32
ctc_create_net_device(char *dev)
{
    struct ifreq ifr;
    int fd, err;

    char *clonedev = "/dev/net/tun";

    /* Arguments taken by the function:
    *
    * char *dev: the name of an interface (or '\0'). MUST have enough
    * space to hold the interface name if '\0' is passed
    * int flags: interface flags (eg, IFF_TUN etc.)
    */
    /* open the clone device */

    if( (fd = sal_open(clonedev, O_RDWR)) < 0 ) 
    {
        return fd;
    }

    /* preparation of the struct ifr, of type "struct ifreq" */
    sal_memset(&ifr, 0, sizeof(ifr));
    ifr.ifr_flags = IFF_TAP | IFF_NO_PI; /* IFF_TUN or IFF_TAP, plus maybe IFF_NO_PI */
    if (*dev) 
    {
        /* if a device name was specified, put it in the structure; otherwise,
        * the kernel will try to allocate the "next" device of the
        * specified type */
        sal_strncpy(ifr.ifr_name, dev, IFNAMSIZ);
    }

    /* try to create the device */
    if( (err = ioctl(fd, TUNSETIFF, (void *) &ifr)) < 0 ) 
    {
        close(fd);
        return err;
    }

    return fd;
}

int32
ctc_remove_net_device(int32 fd)
{
    sal_close(fd);

    return SAI_STATUS_SUCCESS;
}

int32
ctc_lib_netlink_socket()
{
    struct sockaddr_nl snl;
    socklen_t namelen;
    int32 sock = -1;
    int32 rc = SAI_STATUS_SUCCESS;

    sock = sal_socket(AF_NETLINK, SOCK_RAW, NETLINK_ROUTE);
    if (sock < 0)
    {
        return SAI_STATUS_FAILURE;
    }

    ctc_sock_set_nonblocking(sock, TRUE);

    sal_memset(&snl, 0, sizeof snl);
    snl.nl_family = AF_NETLINK;
    snl.nl_groups = 0x1;
    /* Bind the socket to the netlink structure for anything. */
    rc = sal_bind(sock, (struct sal_sockaddr*)&snl, sizeof snl);
    if (rc < 0)
    {
        return SAI_STATUS_FAILURE;
    }

    namelen = sizeof snl;
    rc = getsockname(sock, (struct sal_sockaddr*)&snl, &namelen);
    if (rc < 0 || namelen != sizeof snl)
    {
        return SAI_STATUS_FAILURE;
    }

    g_hostif_info.snl = snl;
    g_hostif_info.sock = sock;
    return rc;
}

int32
ctc_packet_epool_init()
{
    g_hostif_info.epoll_sock = epoll_create(2048);
    if (g_hostif_info.epoll_sock < 0)
    {
        return SAI_STATUS_FAILURE;
    }

    ctc_sock_set_nonblocking(g_hostif_info.epoll_sock, TRUE);

    g_hostif_info.evl.data.fd = -1;
    g_hostif_info.evl.events = EPOLLIN;
    return SAI_STATUS_SUCCESS;
}

int32
ctc_packet_remove_vlan(ctc_pkt_rx_t* p_pkt_rx)
{
    uint8 *pst_vlan = NULL;

    pst_vlan = p_pkt_rx->pkt_buf->data + CTC_PKT_HEADER_LEN + 12;

    if (pst_vlan[0] != 0x81 || pst_vlan[1] != 0x00)
    {
        return SAI_STATUS_SUCCESS;
    }

    sal_memmove(pst_vlan, pst_vlan + 4, p_pkt_rx->pkt_buf->len - CTC_PKT_HEADER_LEN - 12 - 4);
    return SAI_STATUS_SUCCESS;
}

#define MAX_PKT_BUFFER  20000

ctc_sai_hostif_t*
ctc_sai_hostif_get_vlanif_for_mtu_excep(ctc_pkt_rx_t* p_pkt_rx)
{
    struct ctc_listnode *node = NULL;
    struct ctc_listnode *next = NULL;
    ctc_sai_hostif_t    *p_db_hostif = NULL;
    ctc_port_bitmap_t   port_bitmap = {0};
    int32               is_fdb_exist = 0;

    CTC_SAI_SLIST_LOOP_DEL(g_hostif_info.hostif_port_list, p_db_hostif, node, next)
    {
        if (NULL != p_db_hostif && (SAI_VLAN_DEFAULT_VID < p_db_hostif->vlanid && SAI_VLAN_MAX > p_db_hostif->vlanid))
        {
            ctc_vlan_get_ports(p_db_hostif->vlanid, 0, port_bitmap);
            if (CTC_BMP_ISSET(port_bitmap,  p_pkt_rx->rx_info.src_port))
            {
                is_fdb_exist = ctc_fdb_get_by_port_and_vlanid(p_db_hostif->vlanid, p_pkt_rx->rx_info.src_port);
                if (!is_fdb_exist)
                {
                    return p_db_hostif;
                }
            }
        }
    }

    return NULL;
}

int32
ctc_packet_update_l2_header(ctc_pkt_rx_t* p_pkt_rx, uint8 *pkt_buffer)
{
    uint8       *pst_l2hder = NULL;
    uint8       mac_sa[6] = {0x00, 0x00, 0x00, 0x00, 0x01, 0x02};
    mac_addr_t  mac_da;
    uint8       eth_type[2] = {0x08, 0x00};
    uint8       pkt_ttl = 0;
    uint16      hdr_check = 0;

    sal_memset(mac_da, 0, sizeof(mac_da));
    sal_memcpy(pkt_buffer, p_pkt_rx->pkt_buf->data, p_pkt_rx->pkt_buf->len);
    pst_l2hder = pkt_buffer + CTC_PKT_HEADER_LEN;
    if (pst_l2hder[0] != 0x45)
    {
        return SAI_STATUS_SUCCESS;
    }

    sal_memcpy(pkt_buffer, p_pkt_rx->pkt_buf->data, p_pkt_rx->pkt_buf->len);
    sal_memmove(pst_l2hder + 14, pst_l2hder, p_pkt_rx->pkt_buf->len - CTC_PKT_HEADER_LEN);

    ctc_l3if_get_router_mac(mac_da);
    sal_memset(pst_l2hder, 0x0, 14);
    sal_memcpy(pst_l2hder, mac_da, sizeof(mac_addr_t));
    sal_memcpy(pst_l2hder + 6, mac_sa, sizeof(mac_sa));
    sal_memcpy(pst_l2hder + 12, eth_type, sizeof(eth_type));
    /* modified by wangjj for fix bug 40953, the TTL was decreased in EPE process, so add it */
    pkt_ttl = *(uint8*)(pst_l2hder + 22);
    pkt_ttl += 1;
    sal_memcpy(pst_l2hder + 22, &pkt_ttl, 1);

    sal_memcpy(pst_l2hder + 24, &hdr_check, 2);
    hdr_check = ip_fast_csum((unsigned char *)(pst_l2hder + 14), 5);
    sal_memcpy(pst_l2hder + 24, &hdr_check, 2);

    p_pkt_rx->pkt_buf->len += 14;
    //sal_memmove(p_pkt_rx->pkt_buf->data + CTC_PKT_HEADER_LEN, pst_l2hder, p_pkt_rx->pkt_buf->len - CTC_PKT_HEADER_LEN + 14);
    return SAI_STATUS_SUCCESS;
}

int32
ctc_packet_add_l2_header(ctc_pkt_rx_t* p_pkt_rx)
{
    uint8       *pst_l2hder = NULL;
    uint8       mac_sa[6] = {0x00, 0x00, 0x00, 0x00, 0x01, 0x02};
    mac_addr_t  mac_da;
    uint8       eth_type[2] = {0x08, 0x00};
    uint8       pkt_ttl = 0;
    uint16      hdr_check = 0;

    sal_memset(mac_da, 0, sizeof(mac_da));
    pst_l2hder = p_pkt_rx->pkt_buf->data + CTC_PKT_HEADER_LEN;
    if (pst_l2hder[0] != 0x45)
    {
        return SAI_STATUS_SUCCESS;
    }

    sal_memmove(pst_l2hder + 14, pst_l2hder, p_pkt_rx->pkt_buf->len - CTC_PKT_HEADER_LEN);

    ctc_l3if_get_router_mac(mac_da);
    sal_memset(pst_l2hder, 0x0, 14);
    sal_memcpy(pst_l2hder, mac_da, sizeof(mac_addr_t));
    sal_memcpy(pst_l2hder + 6, mac_sa, sizeof(mac_sa));
    sal_memcpy(pst_l2hder + 12, eth_type, sizeof(eth_type));
    /* modified by wangjj for fix bug 40953, the TTL was decreased in EPE process, so add it */
    pkt_ttl = *(uint8*)(pst_l2hder + 22);
    pkt_ttl += 1;
    sal_memcpy(pst_l2hder + 22, &pkt_ttl, 1);

    sal_memcpy(pst_l2hder + 24, &hdr_check, 2);
    hdr_check = ip_fast_csum((unsigned char *)(pst_l2hder + 14), 5);
    sal_memcpy(pst_l2hder + 24, &hdr_check, 2);

    p_pkt_rx->pkt_buf->len += 14;
    sal_memmove(p_pkt_rx->pkt_buf->data + CTC_PKT_HEADER_LEN, pst_l2hder, p_pkt_rx->pkt_buf->len - CTC_PKT_HEADER_LEN + 14);
    return SAI_STATUS_SUCCESS;
}

#define ________SAI_SAI_ARP_FDB_LEARNING

int32
ctc_fdb_get_portid(uint8 *mac_address, uint32 vlanid, sai_object_id_t *portid)
{
    uint32 gport = 0;
    int ret = 0;

    if (NULL == portid)
    {
        return SAI_STATUS_FAILURE;
    }

    ret = ctc_fdb_get_gport(mac_address, vlanid, &gport);
    if (SAI_STATUS_SUCCESS != ret)
    {
        return ret;
    }

    ctc_sai_port_gport_to_objectid(gport, portid);
    return SAI_STATUS_SUCCESS;
}

int32
ctc_fdb_get_gport(uint8 *mac_address, uint32 vlanid, uint32 *gport)
{
    ctc_l2_addr_t           query_buffer[1];
    ctc_l2_fdb_query_t      fdb_query;
    ctc_l2_fdb_query_rst_t  query_rst;
    int                     ret = 0;

    if (NULL == gport)
    {
        return SAI_STATUS_FAILURE;
    }

    sal_memset(&fdb_query, 0, sizeof(fdb_query));
    sal_memcpy(fdb_query.mac, mac_address, sizeof(mac_addr_t));
    fdb_query.query_type = CTC_L2_FDB_ENTRY_OP_BY_MAC_VLAN;
    //fdb_query.query_flag = CTC_L2_FDB_ENTRY_STATIC;
    fdb_query.query_flag = CTC_L2_FDB_ENTRY_ALL;
    fdb_query.fid        = vlanid;
    fdb_query.query_hw   = FALSE;

    query_rst.buffer_len = sizeof(ctc_l2_addr_t);
    query_rst.buffer = query_buffer;
    sal_memset(query_rst.buffer, 0, query_rst.buffer_len);

    ret = ctc_l2_get_fdb_entry(&fdb_query, &query_rst);
    if ((0 == ret) && (fdb_query.count > 0))
    {
        *gport = query_rst.buffer->gport;
        return SAI_STATUS_SUCCESS;
    }

    return SAI_STATUS_FAILURE;
}

int32
ctc_arp_fdb_get_portid(uint8 *mac_address, uint32 vlanid, sai_object_id_t *portid)
{
    ctc_sai_arp_fdb_t *pst_arp_fdb = NULL;
    ctc_sai_arp_fdb_t arp_fdb;

    if (NULL == portid)
    {
        return SAI_STATUS_FAILURE;
    }

    sal_memset(&arp_fdb, 0, sizeof(arp_fdb));
    sal_memcpy(arp_fdb.mac_address, mac_address, sizeof(mac_addr_t));
    arp_fdb.vlanid = vlanid;

    pst_arp_fdb = ctc_hash_lookup(g_hostif_info.hostif_arp_fdb_hash, &arp_fdb);
    if (NULL == pst_arp_fdb)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    if (NULL != portid)
    {
        *portid = pst_arp_fdb->port;
    }

    return SAI_STATUS_SUCCESS;
}

int32
ctc_arp_fdb_get_gport(uint8 *mac_address, uint32 vlanid, uint32 *gport)
{
    ctc_sai_arp_fdb_t *pst_arp_fdb = NULL;
    ctc_sai_arp_fdb_t arp_fdb;

    if (NULL == gport)
    {
        return SAI_STATUS_FAILURE;
    }

    sal_memset(&arp_fdb, 0, sizeof(arp_fdb));
    sal_memcpy(arp_fdb.mac_address, mac_address, sizeof(mac_addr_t));
    arp_fdb.vlanid = vlanid;

    pst_arp_fdb = ctc_hash_lookup(g_hostif_info.hostif_arp_fdb_hash, &arp_fdb);
    if (NULL == pst_arp_fdb)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    if (NULL != gport)
    {
        ctc_sai_port_objectid_to_gport(pst_arp_fdb->port, gport);
    }

    return SAI_STATUS_SUCCESS;
}

int32
ctc_arp_fdb_learning(uint32 vlanid, sai_object_id_t portid, uint8 *mac_address)
{
    ctc_sai_arp_fdb_t *pst_arp_fdb = 0;
    ctc_sai_arp_fdb_t arp_fdb;

    sal_mutex_lock(g_hostif_info.arp_fdb_mutex);
    sal_memset(&arp_fdb, 0, sizeof(arp_fdb));
    sal_memcpy(arp_fdb.mac_address, mac_address, sizeof(mac_addr_t));
    arp_fdb.vlanid = vlanid;

    pst_arp_fdb = ctc_hash_lookup(g_hostif_info.hostif_arp_fdb_hash, &arp_fdb);
    if (NULL != pst_arp_fdb)
    {
        pst_arp_fdb->live_time = 0;
        if (0 && pst_arp_fdb->port == portid)
        {
            sal_mutex_unlock(g_hostif_info.arp_fdb_mutex);
            return SAI_STATUS_SUCCESS;
        }

        pst_arp_fdb->port = portid;
    }
    else
    {
        pst_arp_fdb = mem_malloc(MEM_APP_ARPFDB_MODULE,sizeof(ctc_sai_arp_fdb_t));
        if (NULL == pst_arp_fdb)
        {
            sal_mutex_unlock(g_hostif_info.arp_fdb_mutex);
            return SAI_STATUS_NO_MEMORY;
        }

        sal_memcpy(pst_arp_fdb->mac_address, mac_address, 6);
        pst_arp_fdb->vlanid = vlanid;
        pst_arp_fdb->port = portid;
        pst_arp_fdb->live_time = 0;

        ctc_hash_insert(g_hostif_info.hostif_arp_fdb_hash, pst_arp_fdb);
    }
    sal_mutex_unlock(g_hostif_info.arp_fdb_mutex);

    //ctc_arp_fdb_update_nexthop(pst_arp_fdb, SAI_ARP_FDB_EVENT_LEARNED);
    return SAI_STATUS_SUCCESS;
}

static uint32
ctc_arp_fdb_aging_entry(ctc_sai_arp_fdb_t *pst_arp_fdb, void *data)
{
    uint32 ret = 0;
    
    sal_mutex_lock(g_hostif_info.arp_fdb_mutex);
    pst_arp_fdb->live_time++;
    if (pst_arp_fdb->live_time >= 10)
    {
        //ctc_arp_fdb_update_nexthop(pst_arp_fdb, SAI_ARP_FDB_EVENT_AGED);
        //ctc_hash_remove(g_hostif_info.hostif_arp_fdb_hash, pst_arp_fdb);
        mem_free(pst_arp_fdb);
        ret = 1;
    }
    else
    {
        ret = 0;
    }

    sal_mutex_unlock(g_hostif_info.arp_fdb_mutex);
    return ret;
}

void
ctc_arp_fdb_aging(void *param)
{
    while (TRUE)
    {
        ctc_hash_traverse_remove(g_hostif_info.hostif_arp_fdb_hash,
            (hash_traversal_fn) ctc_arp_fdb_aging_entry,
            NULL);

        sal_task_sleep(60000);
    }

    return;
}

#define ________SAI_SAI_PACKET_
int32
ctc_packet_send_to_sdk(ctc_sai_hostif_t *pst_hostif, char *buffer, int buffer_size)
{
    sai_attribute_t attr[1];
    ctc_pkt_tx_t pkt_tx;
    ctc_pkt_skb_t *p_skb = NULL;
    uint32 gport = 0;
    int ret = 0;

    sal_memset(&pkt_tx, 0, sizeof(ctc_pkt_tx_t));
    p_skb = &(pkt_tx.skb);

    ctc_packet_skb_init(p_skb);

    /* vlan interface */
    if (0 != pst_hostif->vlanid)
    {
        ctc_packet_skb_put(p_skb, buffer_size);
        sal_memcpy(p_skb->data, buffer, buffer_size);
        pkt_tx.tx_info.flags |= CTC_PKT_FLAG_SRC_SVID_VALID;

        /* first get port from static fdb */
        ret = ctc_fdb_get_gport(p_skb->data, pst_hostif->vlanid, &gport);
        /* not found static fdb get port from arp fdb */
        if (SAI_STATUS_SUCCESS != ret)
        {
            ret = ctc_arp_fdb_get_gport(p_skb->data, pst_hostif->vlanid, &gport);
            //ret = ctc_fdb_get_gport(p_skb->data, pst_hostif->vlanid, &gport);
        }

        /* flooding in vlan */
        if (SAI_STATUS_SUCCESS != ret)
        {
            pkt_tx.tx_info.flags |= CTC_PKT_FLAG_MCAST;
            pkt_tx.tx_info.src_svid = pst_hostif->vlanid;
            pkt_tx.tx_info.dest_group_id = pst_hostif->vlanid;
        }
        /* unicat to port */
        else
        {
            pkt_tx.tx_info.flags |= CTC_PKT_FLAG_NH_OFFSET_VALID;
            pkt_tx.tx_info.src_svid = pst_hostif->vlanid;
            pkt_tx.tx_info.nh_offset = pst_hostif->nexthop_ptr;
            pkt_tx.tx_info.dest_gport = gport;
        }
    }
    /* port interface or linkagg interface */
    else
    {
        ctc_packet_skb_put(p_skb, buffer_size);
        sal_memcpy(p_skb->data, buffer, buffer_size);
        ctc_sai_port_objectid_to_gport(pst_hostif->port, &pkt_tx.tx_info.dest_gport);
        pkt_tx.tx_info.flags |= CTC_PKT_FLAG_NH_OFFSET_BYPASS;
    }

    pkt_tx.mode = CTC_PKT_MODE_DMA;
    pkt_tx.lchip = 0;
    pkt_tx.tx_info.oper_type = CTC_PKT_OPER_NORMAL;
    pkt_tx.tx_info.is_critical = TRUE;

    attr[0].value.u32 = 0; /* GLB_PKT_UNKNOWN */
    ctc_sai_get_sys_info()->sai_switch_notification_table.on_cpu_packet_debug(p_skb->data, p_skb->tail - p_skb->data + 1, 1, attr);
    return ctc_packet_tx(&pkt_tx);
}

uint16
_ctc_get_copp_vid(ctc_pkt_rx_t* p_pkt_rx)
{
    uint16 vid;
    uint8 tid;
    uint8 cnt;
    uint16 port;
    
    vid = (0 == p_pkt_rx->rx_info.fid) ? p_pkt_rx->rx_info.src_svid : p_pkt_rx->rx_info.fid;
    if ((vid == 0) && (CTC_PKT_CPU_REASON_L2_PDU+CTC_L2PDU_ACTION_INDEX_LLDP == p_pkt_rx->rx_info.reason 
        ||CTC_PKT_CPU_REASON_L2_PDU+CTC_L2PDU_ACTION_INDEX_BPDU == p_pkt_rx->rx_info.reason
        ||CTC_PKT_CPU_REASON_L2_PDU+CTC_L2PDU_ACTION_INDEX_SLOW_PROTO == p_pkt_rx->rx_info.reason
        ||CTC_PKT_CPU_REASON_L2_PDU+CTC_L2PDU_ACTION_INDEX_EAPOL == p_pkt_rx->rx_info.reason
        ||CTC_PKT_CPU_REASON_L2_PDU+CTC_L2PDU_ACTION_INDEX_ERPS == p_pkt_rx->rx_info.reason
        ||CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_OSPF == p_pkt_rx->rx_info.reason
        ||CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_BGP == p_pkt_rx->rx_info.reason
        ||CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_VRRP == p_pkt_rx->rx_info.reason
        ||CTC_PKT_CPU_REASON_IGMP_SNOOPING == p_pkt_rx->rx_info.reason
#ifdef GREATBELT 
        ||CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_ARP_V2== p_pkt_rx->rx_info.reason
        ||CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_DHCP_V2== p_pkt_rx->rx_info.reason
#else
        ||CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_ARP == p_pkt_rx->rx_info.reason
        ||CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_DHCP == p_pkt_rx->rx_info.reason
#endif
        ||CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_PIM == p_pkt_rx->rx_info.reason
        ||CTC_PKT_CPU_REASON_L3_COPY_CPU == p_pkt_rx->rx_info.reason))
    {
        tid = ctc_sai_port_get_lag_id(p_pkt_rx->rx_info.src_port);
        if(tid)
        {
            CTC_ERROR_RETURN(ctc_linkagg_get_1st_local_port(0, tid, &port, &cnt));
            CTC_ERROR_RETURN(ctc_port_get_default_vlan(port, &vid));
        }
        else
        {
            CTC_ERROR_RETURN(ctc_port_get_default_vlan(p_pkt_rx->rx_info.src_port, &vid));
        }
    }
    else 
    {
        vid = (0 == p_pkt_rx->rx_info.fid) ? p_pkt_rx->rx_info.src_svid : p_pkt_rx->rx_info.fid;
    }

    return vid;
}

int32 g_crc_length = 4;

int32
ctc_packet_receive_from_sdk_process_dhcp(ctc_pkt_rx_t* p_pkt_rx)
{
    sai_attribute_t attr_list[4];
    sai_object_id_t portid = 0;
    uint32 tid             = 0;
    uint32 count           = 0;

    sal_memset(attr_list, 0, sizeof(attr_list));    
    attr_list[0].id = SAI_HOSTIF_PACKET_TRAP_ID;
    if (p_pkt_rx->rx_info.reason > CTC_PKT_CPU_REASON_CUSTOM_BASE*2
        && p_pkt_rx->rx_info.reason <= CTC_PKT_CPU_REASON_L3_COPY_CPU+CTC_PKT_CPU_REASON_CUSTOM_BASE*2)
    {
        p_pkt_rx->rx_info.reason -= CTC_PKT_CPU_REASON_CUSTOM_BASE*2;
    }
    attr_list[0].value.s32 = ctc_sai_get_reason_trap(p_pkt_rx->rx_info.reason);

    attr_list[1].id = SAI_HOSTIF_PACKET_INGRESS_PORT;
    attr_list[1].value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT, p_pkt_rx->rx_info.src_port);
    count = 2;

    attr_list[2].id = SAI_HOSTIF_PACKET_VLAN_ID;
    attr_list[2].value.u16 = _ctc_get_copp_vid(p_pkt_rx);
    count = 3;

    tid = ctc_sai_port_get_lag_id(p_pkt_rx->rx_info.src_port);
    if(0 != tid)
    {
        attr_list[3].id = SAI_HOSTIF_PACKET_INGRESS_LAG;
        portid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_LAG, tid);            
        attr_list[3].value.oid = portid;
        count = 4;
    }

    /* remove vlan in the packet */
    ctc_packet_remove_vlan(p_pkt_rx);

/* modified by liwh for bug 39968, 2016-08-11 
   GB packet length include the inserted vlan tag */
#ifdef _GLB_UML_SYSTEM_
#ifdef GREATBELT
    p_pkt_rx->pkt_buf->len = p_pkt_rx->pkt_buf->len - 4;
#endif
#endif
/* liwh end */

#ifdef _GLB_UML_SYSTEM_
    ctc_sai_get_sys_info()->sai_switch_notification_table.on_packet_event(
        p_pkt_rx->pkt_buf->data + CTC_PKT_HEADER_LEN,
        p_pkt_rx->pkt_buf->len  - CTC_PKT_HEADER_LEN,
        count,
        attr_list);   
#else
    ctc_sai_get_sys_info()->sai_switch_notification_table.on_packet_event(
        p_pkt_rx->pkt_buf->data + CTC_PKT_HEADER_LEN,
        p_pkt_rx->pkt_buf->len  - CTC_PKT_HEADER_LEN - g_crc_length,
        count,
        attr_list); 
#endif

    return SAI_STATUS_SUCCESS;
}

int32
ctc_packet_receive_from_sdk_process_arp(ctc_pkt_rx_t* p_pkt_rx)
{
    sai_attribute_t attr_list[4];
    sai_object_id_t portid = 0;
    uint32 tid             = 0;
    uint32 count           = 0;

    sal_memset(attr_list, 0, sizeof(attr_list));    
    attr_list[0].id = SAI_HOSTIF_PACKET_TRAP_ID;
    if (p_pkt_rx->rx_info.reason > CTC_PKT_CPU_REASON_CUSTOM_BASE*2
        && p_pkt_rx->rx_info.reason <= CTC_PKT_CPU_REASON_L3_COPY_CPU+CTC_PKT_CPU_REASON_CUSTOM_BASE*2)
    {
        p_pkt_rx->rx_info.reason -= CTC_PKT_CPU_REASON_CUSTOM_BASE*2;
    }
    attr_list[0].value.s32 = ctc_sai_get_reason_trap(p_pkt_rx->rx_info.reason);

    attr_list[1].id = SAI_HOSTIF_PACKET_INGRESS_PORT;
    attr_list[1].value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT, p_pkt_rx->rx_info.src_port);
    count = 2;

    attr_list[2].id = SAI_HOSTIF_PACKET_VLAN_ID;
    attr_list[2].value.u16 = _ctc_get_copp_vid(p_pkt_rx);
    count = 3;

    tid = ctc_sai_port_get_lag_id(p_pkt_rx->rx_info.src_port);
    if(0 != tid)
    {
        attr_list[3].id = SAI_HOSTIF_PACKET_INGRESS_LAG;
        attr_list[3].value.oid = portid;
        count = 4;
    }

    /* remove vlan in the packet */
    ctc_packet_remove_vlan(p_pkt_rx);

    ctc_sai_get_sys_info()->sai_switch_notification_table.on_packet_event(
        p_pkt_rx->pkt_buf->data + 40,
        p_pkt_rx->pkt_buf->len  - 40,
        count,
        attr_list);    

    return SAI_STATUS_SUCCESS;
}

/* support vrrp modified by liwh for bug 45215, 2017-09-17 
   find vmac according to dest ip address, then replace dest mac to if route mac */
void 
vrrp_replace_mac_da_for_icmp_request(uint8 *pkt, uint16 pkt_len)
{
    ctc_icmp_message_header_t    *p_icmp_header = NULL;  
    ctc_icmp_ip_header_t         *p_icmp_ip_header = NULL;
    ctc_sai_vrrp_vip_entry_t     *pst_vrrp_vip_entry = NULL;
    sai_vrrp_vip_entry_t         vrrp_vip_entry;
    uint16                       eth_type = 0; 

    sal_memset(&vrrp_vip_entry, 0, sizeof(ctc_sai_vrrp_vip_entry_t));

    p_icmp_header = (ctc_icmp_message_header_t*)pkt;

    eth_type = sal_ntohs(p_icmp_header->eth_type);

    if (GLB_DEFAULT_TPID == eth_type)
    {
        p_icmp_ip_header = (ctc_icmp_ip_header_t*)(pkt + ETH_HEADER_LEN + VLAN_TAG_LEN);
    }
    else if (ETH_P_IPV4 == eth_type)
    {
        p_icmp_ip_header = (ctc_icmp_ip_header_t*)(pkt + ETH_HEADER_LEN);
    }
    else
    {
        return;    
    }
    
    if (PROTO_ICMP != p_icmp_ip_header->protocol)
    {
        return;    
    }

    vrrp_vip_entry.ip_address.addr_family = SAI_IP_ADDR_FAMILY_IPV4;
    sal_memcpy(&vrrp_vip_entry.ip_address.addr, &p_icmp_ip_header->dest_ip_addr, sizeof(uint32));

    pst_vrrp_vip_entry = ctc_vrrp_vip_get_by_key(&vrrp_vip_entry);
    if (!pst_vrrp_vip_entry)
    {
        return;
    }

    if (0 == sal_memcmp(pkt, pst_vrrp_vip_entry->vmac, MAC_ADDR_LEN))
    {
        sal_memcpy(pkt, pst_vrrp_vip_entry->if_mac, MAC_ADDR_LEN);
    }
    
    return;
}
/* liwh end */

/* support vrrp modified by liwh for bug 45215, 2017-09-17 
   find vmac according to src ip address, then replace src mac by vmac */
void 
vrrp_replace_mac_da_for_icmp_reply(char *pkt, int pkt_len)
{
    ctc_icmp_message_header_t    *p_icmp_header = NULL;  
    ctc_icmp_ip_header_t         *p_icmp_ip_header = NULL;
    ctc_sai_vrrp_vip_entry_t     *pst_vrrp_vip_entry = NULL;
    sai_vrrp_vip_entry_t         vrrp_vip_entry;
    uint16                       eth_type = 0; 

    sal_memset(&vrrp_vip_entry, 0, sizeof(ctc_sai_vrrp_vip_entry_t));

    p_icmp_header = (ctc_icmp_message_header_t*)pkt;

    eth_type = sal_ntohs(p_icmp_header->eth_type);

    if (GLB_DEFAULT_TPID == eth_type)
    {
        p_icmp_ip_header = (ctc_icmp_ip_header_t*)(pkt + ETH_HEADER_LEN + VLAN_TAG_LEN);
     }
    else if (ETH_P_IPV4 == eth_type)
    {
        p_icmp_ip_header = (ctc_icmp_ip_header_t*)(pkt + ETH_HEADER_LEN);
    }
    else
    {
        return;
    }

    if (PROTO_ICMP != p_icmp_ip_header->protocol)
    {
        return;    
    }

    vrrp_vip_entry.ip_address.addr_family = SAI_IP_ADDR_FAMILY_IPV4;
    sal_memcpy(&vrrp_vip_entry.ip_address.addr, &p_icmp_ip_header->src_ip_addr, sizeof(uint32));

    pst_vrrp_vip_entry = ctc_vrrp_vip_get_by_key(&vrrp_vip_entry);
    if (!pst_vrrp_vip_entry)
    {
        return;
    }

    if (0 == sal_memcmp((pkt + MAC_ADDR_LEN), pst_vrrp_vip_entry->if_mac, MAC_ADDR_LEN))
    {
        sal_memcpy((pkt + MAC_ADDR_LEN), pst_vrrp_vip_entry->vmac, MAC_ADDR_LEN);
    }
    
    return;
}
/* liwh end */

int32
ctc_packet_receive_from_sdk(ctc_pkt_rx_t* p_pkt_rx)
{
    ctc_sai_hostif_t *pst_hostif = NULL;
    sai_attribute_t attr_list[6];
    sai_hostif_trap_channel_t channel;
    sai_object_id_t portid = 0;
    uint32 tid             = 0;
    uint32 count           = 0;
    uint8           vrrp_mac[6] = {0, 0, 0x5e, 0, 1, 0};

    if ((p_pkt_rx->rx_info.reason > CTC_PKT_CPU_REASON_CUSTOM_BASE*2
        && p_pkt_rx->rx_info.reason <= CTC_PKT_CPU_REASON_L3_COPY_CPU+CTC_PKT_CPU_REASON_CUSTOM_BASE*2) ||
        (p_pkt_rx->rx_info.reason == CTC_PKT_CPU_REASON_CUSTOM_BASE*2 + CTC_PKT_CPU_REASON_CUSTOM_BASE + 1))
    {
        p_pkt_rx->rx_info.reason -= CTC_PKT_CPU_REASON_CUSTOM_BASE*2;
        #ifdef GREATBELT 
        p_pkt_rx->rx_info.src_port = p_pkt_rx->rx_info.logic_src_port;
        #endif
    }

    channel = ctc_sai_get_reason_channel(p_pkt_rx->rx_info.reason);
    sal_memset(attr_list, 0, sizeof(attr_list));

#if defined(OFDPAPRODUCT)
    /* Forward to OF-DPA */
extern int ctc_ofdpa_packet_receive_from_sdk(ctc_pkt_rx_t* p_pkt_rx);

    ctc_ofdpa_packet_receive_from_sdk(p_pkt_rx);
#endif
    
    sal_memset(attr_list, 0, sizeof attr_list);

    {
        /*
         * Packet debug 
         */
        attr_list[0].id = SAI_HOSTIF_PACKET_TRAP_ID;
        attr_list[0].value.s32 = ctc_sai_get_reason_trap(p_pkt_rx->rx_info.reason);

        attr_list[1].id = SAI_HOSTIF_PACKET_INGRESS_PORT;
        attr_list[1].value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT, p_pkt_rx->rx_info.src_port);

        attr_list[2].id = SAI_HOSTIF_PACKET_VLAN_ID;

        attr_list[2].value.u16 = _ctc_get_copp_vid(p_pkt_rx);

        count = 3;

        ctc_sai_get_sys_info()->sai_switch_notification_table.on_cpu_packet_debug(
            p_pkt_rx->pkt_buf->data + CTC_PKT_HEADER_LEN,
            p_pkt_rx->pkt_buf->len  - CTC_PKT_HEADER_LEN,
            count,
            attr_list);
    }
    
    if (SAI_HOSTIF_TRAP_CHANNEL_CB == channel)
    {
        attr_list[0].id = SAI_HOSTIF_PACKET_TRAP_ID;
        attr_list[0].value.s32 = ctc_sai_get_reason_trap(p_pkt_rx->rx_info.reason);
    
        attr_list[1].id = SAI_HOSTIF_PACKET_INGRESS_PORT;
        attr_list[1].value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT, p_pkt_rx->rx_info.src_port);

        attr_list[2].id = SAI_HOSTIF_PACKET_VLAN_ID;

        attr_list[2].value.u16 = _ctc_get_copp_vid(p_pkt_rx);

        count = 3;

        tid = ctc_sai_port_get_lag_id(p_pkt_rx->rx_info.src_port);
        if(0 != tid)
        {
            attr_list[3].id = SAI_HOSTIF_PACKET_INGRESS_LAG;
            attr_list[3].value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_LAG, tid);
            count = 4;
        }
        if(attr_list[0].value.s32 == SAI_HOSTIF_TRAP_ID_CUSTOM_EXCEPTION_OPENFLOW_TO_CONTROLLER)
        {
            attr_list[4].id = SAI_HOSTIF_PACKET_TUNNEL_PAYLOAD_OFFSET;
            attr_list[4].value.u8 = p_pkt_rx->rx_info.payload_offset;
            count ++;

            attr_list[5].id = SAI_HOSTIF_PACKET_METADATA;
            attr_list[5].value.u16 = p_pkt_rx->rx_info.meta_data;
        }
        ctc_sai_get_sys_info()->sai_switch_notification_table.on_packet_event(
            p_pkt_rx->pkt_buf->data + CTC_PKT_HEADER_LEN,
            p_pkt_rx->pkt_buf->len  - CTC_PKT_HEADER_LEN,
            count,
            attr_list);
    }
    else if (SAI_HOSTIF_TRAP_CHANNEL_NETDEV == channel)
    {
#ifdef GREATBELT
        if ((CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_DHCP_V2) == p_pkt_rx->rx_info.reason)   
#else
        if ((CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_DHCP) == p_pkt_rx->rx_info.reason)   
#endif
        {
            ctc_packet_receive_from_sdk_process_dhcp(p_pkt_rx);
            return SAI_STATUS_SUCCESS;
        }
        
        /* get link agg id */
        tid = ctc_sai_port_get_lag_id(p_pkt_rx->rx_info.src_port);
        if (0 != tid)
        {
            portid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_LAG, tid);
        }
        /* get phy port id */
        else
        {
            portid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT, p_pkt_rx->rx_info.src_port);
        }

        /* get vlan interface */
        pst_hostif = ctc_sai_hostif_get_by_vlan(_ctc_get_copp_vid(p_pkt_rx));
        if (NULL != pst_hostif)
        {
#ifdef GREATBELT
            if ((CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_ARP_V2) == p_pkt_rx->rx_info.reason)
#else
            if ((CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_ARP) == p_pkt_rx->rx_info.reason)
#endif
            {
                ctc_arp_fdb_learning(_ctc_get_copp_vid(p_pkt_rx), portid, p_pkt_rx->pkt_buf->data + 46);
            }
        }
        else
        {
            pst_hostif = ctc_sai_hostif_get_by_port(portid);
        }

        if (NULL == pst_hostif)
        {
            if (CTC_PKT_CPU_REASON_L3_MTU_FAIL == p_pkt_rx->rx_info.reason)
            {
                pst_hostif = ctc_sai_hostif_get_vlanif_for_mtu_excep(p_pkt_rx);
            }
        }

        if ((CTC_PKT_CPU_REASON_SFLOW_SOURCE == p_pkt_rx->rx_info.reason)
            || (CTC_PKT_CPU_REASON_SFLOW_DEST == p_pkt_rx->rx_info.reason))
        {
            sal_memset(attr_list, 0, sizeof(attr_list));
            count = 0;

            attr_list[count].id = SAI_HOSTIF_PACKET_TRAP_ID;
            attr_list[count].value.s32 = SAI_HOSTIF_TRAP_ID_SAMPLEPACKET;
            count++;

            
            attr_list[count].id = SAI_HOSTIF_PACKET_INGRESS_PORT;
            attr_list[count].value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT, p_pkt_rx->rx_info.src_port);
            count++;

            attr_list[count].id = SAI_HOSTIF_PACKET_VLAN_ID;
            attr_list[count].value.u16 = (p_pkt_rx->rx_info.src_cos << 13) | p_pkt_rx->rx_info.fid;
            count++;
            
            tid = ctc_sai_port_get_lag_id(p_pkt_rx->rx_info.src_port);
            if(0 != tid)
            {
                attr_list[count].id = SAI_HOSTIF_PACKET_INGRESS_LAG;
                attr_list[count].value.oid = portid;
                count++;
            }
            
            attr_list[count].id = SAI_HOSTIF_PACKET_SUB_TYPE;

            if (CTC_PKT_CPU_REASON_SFLOW_SOURCE == p_pkt_rx->rx_info.reason)
            {
                attr_list[count].value.u16 = GLB_SFLOW_INGRESS_PACKET;
            }
            else
            {
                attr_list[count].value.u16 = GLB_SFLOW_EGRESS_PACKET;    
            }
            count++;

            ctc_sai_get_sys_info()->sai_switch_notification_table.on_packet_event(
                p_pkt_rx->pkt_buf->data + CTC_PKT_HEADER_LEN,
                p_pkt_rx->pkt_buf->len  - CTC_PKT_HEADER_LEN,
                count,
                attr_list);    
            return SAI_STATUS_SUCCESS;    
        }

        if (NULL == pst_hostif)
        {
            return SAI_STATUS_FAILURE;
        }

#ifdef GREATBELT
            if ((CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_ARP_V2) == p_pkt_rx->rx_info.reason)
#else
            if ((CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_ARP) == p_pkt_rx->rx_info.reason)
#endif
        {
            sal_memset(attr_list, 0, sizeof(attr_list));    
            attr_list[0].id = SAI_HOSTIF_PACKET_TRAP_ID;
            attr_list[0].value.s32 = ctc_sai_get_reason_trap(p_pkt_rx->rx_info.reason);

            attr_list[1].id = SAI_HOSTIF_PACKET_INGRESS_PORT;
            attr_list[1].value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT, p_pkt_rx->rx_info.src_port);
            count = 2;

            attr_list[2].id = SAI_HOSTIF_PACKET_VLAN_ID;
            attr_list[2].value.u16 = _ctc_get_copp_vid(p_pkt_rx);
            count = 3;

            tid = ctc_sai_port_get_lag_id(p_pkt_rx->rx_info.src_port);
            if(0 != tid)
            {
                attr_list[3].id = SAI_HOSTIF_PACKET_INGRESS_LAG;
                attr_list[3].value.oid = portid;
                count = 4;
            }

            /* remove vlan in the packet */
            ctc_packet_remove_vlan(p_pkt_rx);

            ctc_sai_get_sys_info()->sai_switch_notification_table.on_packet_event(
                p_pkt_rx->pkt_buf->data + CTC_PKT_HEADER_LEN,
                p_pkt_rx->pkt_buf->len  - CTC_PKT_HEADER_LEN,
                count,
                attr_list);    
            return SAI_STATUS_SUCCESS;
            //return ctc_packet_receive_from_sdk_process_arp(p_pkt_rx);
        }

        /* support vrrp modified by liwh for bug 45215, 2017-09-17 
           copy vrrp packet to CPU */
        if ((CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_VRRP) == p_pkt_rx->rx_info.reason)
        {
            sal_memset(attr_list, 0, sizeof(attr_list));    
            attr_list[0].id = SAI_HOSTIF_PACKET_TRAP_ID;
            attr_list[0].value.s32 = ctc_sai_get_reason_trap(p_pkt_rx->rx_info.reason);
    
            attr_list[1].id = SAI_HOSTIF_PACKET_INGRESS_PORT;
            attr_list[1].value.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT, p_pkt_rx->rx_info.src_port);
            count = 2;
    
            attr_list[2].id = SAI_HOSTIF_PACKET_VLAN_ID;
            attr_list[2].value.u16 = _ctc_get_copp_vid(p_pkt_rx);
            count = 3;
    
            tid = ctc_sai_port_get_lag_id(p_pkt_rx->rx_info.src_port);
            if(0 != tid)
            {
                attr_list[3].id = SAI_HOSTIF_PACKET_INGRESS_LAG;
                attr_list[3].value.oid = portid;
                count = 4;
            }

            ctc_sai_get_sys_info()->sai_switch_notification_table.on_packet_event(
                p_pkt_rx->pkt_buf->data + CTC_PKT_HEADER_LEN,
                p_pkt_rx->pkt_buf->len  - CTC_PKT_HEADER_LEN,
                count,
                attr_list);    
            return SAI_STATUS_SUCCESS;
        }
        /* liwh end */

        if (CTC_PKT_CPU_REASON_L3_MTU_FAIL == p_pkt_rx->rx_info.reason)
        {
            /* add the l2 header excluding the vlan tag */
            //ctc_packet_add_l2_header(p_pkt_rx);
            uint8       pkt_buffer[MAX_PKT_BUFFER];

            sal_memset(pkt_buffer, 0, sizeof(pkt_buffer));
            ctc_packet_update_l2_header(p_pkt_rx, pkt_buffer);

#ifdef _GLB_UML_SYSTEM_
#ifdef GREATBELT
            p_pkt_rx->pkt_buf->len = p_pkt_rx->pkt_buf->len - 4;
#endif
#endif
            /* send the packet to linux kernel */
            //ctc_packet_send_to_kernel(pst_hostif->fd, p_pkt_rx->pkt_buf->data + CTC_PKT_HEADER_LEN, p_pkt_rx->pkt_buf->len - CTC_PKT_HEADER_LEN);
            ctc_packet_send_to_kernel(pst_hostif->fd, pkt_buffer + CTC_PKT_HEADER_LEN, p_pkt_rx->pkt_buf->len - CTC_PKT_HEADER_LEN);

            return SAI_STATUS_SUCCESS;
        }
        /*added by yejl to discard the ospf packet when system memory is not enough, bug43529, 2017-03-31*/
        if ((CTC_PKT_CPU_REASON_L3_PDU + CTC_L3PDU_ACTION_INDEX_OSPF) == p_pkt_rx->rx_info.reason)
        {
            if (memory_check_pktdiscard)
            {
                return SAI_STATUS_SUCCESS;
            }
        }
        /* remove vlan in the packet */
        ctc_packet_remove_vlan(p_pkt_rx);

        /* support vrrp modified by liwh for bug 45215, 2017-09-17 
           check whether replace vmac by route mac */
        if ((CTC_PKT_CPU_REASON_L3_COPY_CPU == p_pkt_rx->rx_info.reason)
            && (0 == sal_memcmp((p_pkt_rx->pkt_buf->data + CTC_PKT_HEADER_LEN), vrrp_mac, 5)))
        {
            vrrp_replace_mac_da_for_icmp_request(p_pkt_rx->pkt_buf->data + CTC_PKT_HEADER_LEN, p_pkt_rx->pkt_buf->len - CTC_PKT_HEADER_LEN);    
        }
        /* liwh end */

        /* send the packet to linux kernel */
        ctc_packet_send_to_kernel(pst_hostif->fd, p_pkt_rx->pkt_buf->data + CTC_PKT_HEADER_LEN, p_pkt_rx->pkt_buf->len - CTC_PKT_HEADER_LEN);
    }

    return SAI_STATUS_SUCCESS;
}

#define HOSTIF_SEND_TO_KERNEL_MAX_TIMES     1000
uint32 g_hostif_send_to_kernel_error_count = 0;

int32
ctc_packet_send_to_kernel(int fd, uint8 *buf, uint32 length)
{
    uint8 *head = buf;
    int writenLen = 0;
    int count = 0;
    int resend = 0;

    while (resend <= HOSTIF_SEND_TO_KERNEL_MAX_TIMES)
    {
        writenLen = write(fd, head + count, length);
        resend++;
        if (writenLen == -1)
        {
            if (errno == EAGAIN)
            {
                break;
            }
            else if(errno == ECONNRESET)
            {
                break;
            }
            else if (errno == EINTR)
            {
                continue;
            }
            else
            {

            }
        }

        if (writenLen == 0)
        {
            break;
        }

        count += writenLen;
        if (count == length)
        {
            break;
        }
    }

    if (resend >= HOSTIF_SEND_TO_KERNEL_MAX_TIMES)
    {
        g_hostif_send_to_kernel_error_count++;
    }
    
    return SAI_STATUS_SUCCESS;
}

void
ctc_packet_receive_from_kernel(void *data)
{
    ctc_sai_hostif_t *pst_hostif = NULL;
    struct epoll_event events[2048];
    int sockfd = 0;
    int nfds   = 0;
    int idx    = 0;

    while (TRUE)
    {
        nfds = epoll_wait(g_hostif_info.epoll_sock, events, 2048, 1);
        for (idx = 0; idx < nfds; ++idx)
        {
            if (events[idx].events & EPOLLIN)
            {
                if ( (sockfd = events[idx].data.fd) < 0)
                {
                    continue;
                }

                char *head = g_hostif_info.pkt_buff;
                bool bReadOk = FALSE;
                int recvNum = 0;
                int count = 0;

                while (TRUE)
                {
                    recvNum = read(sockfd, head + count, 9600);
                    if(recvNum < 0)
                    {
                        if (errno == EAGAIN)
                        {
                            bReadOk = true;
                            break;
                        }
                        else if (errno == ECONNRESET)
                        {
                            break;
                         }
                        else if (errno == EINTR)
                        {
                            continue;
                        }
                        else
                        {
                            break;
                        }
                   }
                   else if (recvNum == 0)
                   {
                        break;
                   }

                   count += recvNum;
                   if (recvNum >= 9600)
                   {
                       break;
                   }
                   else
                   {
                       bReadOk = true;
                       break;
                   }
                }

                if (bReadOk == true)
                {
                    g_hostif_info.pkt_buff[count] = '\0';
                    pst_hostif = ctc_sai_hostif_get_by_fd(sockfd);
                    if (NULL == pst_hostif)
                    {
                        continue;
                    }
                    else if (0 == sal_strncmp(pst_hostif->ifname, "loopback", 8))
                    {
                        continue;
                    }

                    /* support vrrp modified by liwh for bug 45215, 2017-09-17 
                       check whether replace src mac by vmac for icmp reply */
                    vrrp_replace_mac_da_for_icmp_reply(g_hostif_info.pkt_buff, count);
                    /* liwh end */
                    
                    ctc_packet_send_to_sdk(pst_hostif, g_hostif_info.pkt_buff, count);
                }
            }
        }
    }
}

/*these 2 trap are inited by SDK to drop */
/*this function reset these 2 trap to up to cpu*/
int32
ctc_sai_init_other_cpu_traffic(void)
{
    int32 ret = 0;
    ctc_qos_queue_cfg_t    qos_queue_cfg;

    sal_memset(&qos_queue_cfg, 0, sizeof(ctc_qos_queue_cfg_t));
    qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_REASON_DEST;
    qos_queue_cfg.value.reason_map.cpu_reason = CTC_PKT_CPU_REASON_L3_IP_OPTION;
    qos_queue_cfg.value.reason_map.queue_id = 0;
    qos_queue_cfg.value.reason_map.reason_group = 0;
    qos_queue_cfg.value.reason_dest.dest_type = CTC_PKT_CPU_REASON_TO_LOCAL_CPU;
    qos_queue_cfg.value.reason_dest.dest_port = CTC_LPORT_CPU;
    ret += ctc_qos_set_queue(&qos_queue_cfg);

    sal_memset(&qos_queue_cfg, 0, sizeof(ctc_qos_queue_cfg_t));
    qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_REASON_DEST;
    qos_queue_cfg.value.reason_map.cpu_reason = CTC_PKT_CPU_REASON_L3_MTU_FAIL;
    qos_queue_cfg.value.reason_map.queue_id = 0;
    qos_queue_cfg.value.reason_map.reason_group = 0;
    qos_queue_cfg.value.reason_dest.dest_type = CTC_PKT_CPU_REASON_TO_LOCAL_CPU;
    qos_queue_cfg.value.reason_dest.dest_port = CTC_LPORT_CPU;
    ret += ctc_qos_set_queue(&qos_queue_cfg);
        
    return ret;
}


#define ________SAI_SAI_DEBUG_FUNC
sai_status_t sai_create_hostif_debug_param(
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    const sai_attribute_t *attr = NULL;
    uint32_t          attr_idx = 0; 

    for (attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = (sai_attribute_t*)attr_list + attr_idx;
        switch (attr->id)
        {
        case SAI_HOSTIF_ATTR_TYPE:
            CTC_SAI_DEBUG("out:SAI_HOSTIF_ATTR_TYPE");
            break;
        case SAI_HOSTIF_ATTR_RIF_OR_PORT_ID:
            CTC_SAI_DEBUG("out:SAI_HOSTIF_ATTR_RIF_OR_PORT_ID 0x%llx", attr->value.oid);
            break;
        case SAI_HOSTIF_ATTR_NAME:
            CTC_SAI_DEBUG("out:SAI_HOSTIF_TRAP_GROUP_ATTR_QUEUE %s", attr->value.chardata);
            break;
         default:
            break;
        }
    }

    return SAI_STATUS_SUCCESS;
}
sai_status_t sai_create_hostif_trap_group_debug_param(
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    const sai_attribute_t *attr = NULL;
    uint32_t          attr_idx = 0; 

    for (attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = (sai_attribute_t*)attr_list + attr_idx;
        switch (attr->id)
        {
        case SAI_HOSTIF_TRAP_GROUP_ATTR_ADMIN_STATE:
            CTC_SAI_DEBUG("out:SAI_HOSTIF_TRAP_GROUP_ATTR_ADMIN_STATE %u", attr->value.booldata);
            break;
        case SAI_HOSTIF_TRAP_GROUP_ATTR_PRIO:
            CTC_SAI_DEBUG("out:SAI_HOSTIF_TRAP_GROUP_ATTR_PRIO");
            break;
        case SAI_HOSTIF_TRAP_GROUP_ATTR_QUEUE:
            CTC_SAI_DEBUG("out:SAI_HOSTIF_TRAP_GROUP_ATTR_QUEUE %u", attr->value.u32);
            break;
        case SAI_HOSTIF_TRAP_GROUP_ATTR_POLICER:
            CTC_SAI_DEBUG("out:SAI_HOSTIF_TRAP_GROUP_ATTR_POLICER 0x%llx", attr->value.oid);
            break;
         default:
            break;
        }
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t ctc_sai_set_trap_group_queue(sai_object_id_t hostif_trap_group_id, int32 queueid)
{
    ctc_sai_hostif_group_t* p_hostif_group = NULL;
    ctc_qos_queue_cfg_t        qos_queue_cfg;
    CTC_SAI_DEBUG_FUNC();

    p_hostif_group = ctc_sai_hostif_group_db_oid(hostif_trap_group_id);
    CTC_SAI_PTR_VALID_CHECK(p_hostif_group);
    p_hostif_group->queue_id = queueid;

    sal_memset(&qos_queue_cfg, 0, sizeof(ctc_qos_queue_cfg_t));
    qos_queue_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_REASON_MAP;
    qos_queue_cfg.value.reason_map.cpu_reason = p_hostif_group->ctc_reason_id + CTC_PKT_CPU_REASON_CUSTOM_BASE*2;
    qos_queue_cfg.value.reason_map.queue_id = queueid;
    qos_queue_cfg.value.reason_map.reason_group = 0;
    ctc_qos_set_queue(&qos_queue_cfg);

    return SAI_STATUS_SUCCESS;
}

sai_status_t ctc_sai_set_trap_group_policer(sai_object_id_t hostif_trap_group_id, sai_object_id_t policer_oid)
{
    ctc_sai_hostif_group_t* p_hostif_group = NULL;
    sai_object_id_t acl_oid[8];
    uint32 i;

    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr;

    CTC_SAI_DEBUG_FUNC();

    sal_memset(acl_oid, 0, sizeof(acl_oid));
    p_hostif_group = ctc_sai_hostif_group_db_oid(hostif_trap_group_id);
    CTC_SAI_PTR_VALID_CHECK(p_hostif_group);
    
    CTC_ERROR_RETURN(sai_api_query(SAI_API_ACL,(void**)&acl_api));

    /*1, apply all acl entry policer for this trap group*/
    for(i=0; i<8; i++)
    {
        CTC_ERROR_RETURN(ctc_sai_copp_get_acl_oid_from_reason(p_hostif_group->ctc_reason_id, acl_oid));
        if(acl_oid[i] != 0)
        {
            sal_memset(&attr, 0, sizeof(sai_attribute_t));
            attr.id = SAI_ACL_ENTRY_ATTR_ACTION_SET_POLICER;
            attr.value.aclaction.enable = TRUE;
            attr.value.aclaction.parameter.oid = policer_oid;
            CTC_ERROR_RETURN(acl_api->set_acl_entry_attribute(acl_oid[i], &attr));
        }
            
    }

    /*2, save acl policeroid*/
    p_hostif_group->police_id = policer_oid;

    return SAI_STATUS_SUCCESS;
}

sai_status_t ctc_sai_set_trap_group_priority(sai_object_id_t hostif_trap_group_id, int32 prio)
{
    ctc_sai_hostif_group_t* p_hostif_group = NULL;
    CTC_SAI_DEBUG_FUNC();

    p_hostif_group = ctc_sai_hostif_group_db_oid(hostif_trap_group_id);
    CTC_SAI_PTR_VALID_CHECK(p_hostif_group);
    p_hostif_group->priority = prio;



    return SAI_STATUS_NOT_SUPPORTED;
}

sai_status_t ctc_sai_get_trap_group_queue(sai_object_id_t hostif_trap_group_id, sai_attribute_t* attr)
{
    ctc_sai_hostif_group_t* p_hostif_group = NULL;
    CTC_SAI_DEBUG_FUNC();

    p_hostif_group = ctc_sai_hostif_group_db_oid(hostif_trap_group_id);
    CTC_SAI_PTR_VALID_CHECK(p_hostif_group);
    attr->value.u32 = p_hostif_group->queue_id;

    return SAI_STATUS_SUCCESS;
}

sai_status_t ctc_sai_get_trap_group_policer(sai_object_id_t hostif_trap_group_id, sai_attribute_t* attr)
{
    ctc_sai_hostif_group_t* p_hostif_group = NULL;
    CTC_SAI_DEBUG_FUNC();

    p_hostif_group = ctc_sai_hostif_group_db_oid(hostif_trap_group_id);
    CTC_SAI_PTR_VALID_CHECK(p_hostif_group);
    attr->value.oid= p_hostif_group->police_id;

    return SAI_STATUS_NOT_SUPPORTED;
}

sai_status_t ctc_sai_get_trap_group_priority(sai_object_id_t hostif_trap_group_id, sai_attribute_t* attr)
{
    ctc_sai_hostif_group_t* p_hostif_group = NULL;
    CTC_SAI_DEBUG_FUNC();

    p_hostif_group = ctc_sai_hostif_group_db_oid(hostif_trap_group_id);
    CTC_SAI_PTR_VALID_CHECK(p_hostif_group);
    attr->value.u32 = p_hostif_group->priority;

    return SAI_STATUS_SUCCESS;
}

sai_status_t ctc_sai_get_trap_group_counter(sai_object_id_t hostif_trap_group_id, sai_attribute_t* attr)
{
    ctc_sai_hostif_group_t* p_hostif_group = NULL;
    sai_object_id_t counter_oid;
    CTC_SAI_DEBUG_FUNC();

    p_hostif_group = ctc_sai_hostif_group_db_oid(hostif_trap_group_id);
    CTC_SAI_PTR_VALID_CHECK(p_hostif_group);
    

    CTC_ERROR_RETURN(ctc_sai_copp_get_counter_oid_from_reason(p_hostif_group->ctc_reason_id, &counter_oid));
    attr->value.oid = counter_oid;

    return SAI_STATUS_NOT_SUPPORTED;
}


sai_status_t ctc_sai_create_hostif_trap(
    _In_ sai_hostif_trap_id_t hostif_trapid,
    _In_ sai_hostif_trap_channel_t trap_channel)
{
    ctc_sai_hostif_trap_t  *hostif_trap   = NULL;
    int32 ret = 0;

    hostif_trap = ctc_sai_hostif_trap_db_trap_id(hostif_trapid);
    if (NULL == hostif_trap)
    {
        hostif_trap = ctc_sai_hostif_trap_db_alloc(hostif_trapid);
        if (NULL == hostif_trap)
        {
            return SAI_STATUS_NO_MEMORY;
        }
    }

    /* will overwrite SAI_HOSTIF_TRAP_ID_OSPF etc. , bypass those trapid */
    if ((SAI_HOSTIF_TRAP_ID_OSPFV6 != hostif_trapid)
     && (SAI_HOSTIF_TRAP_ID_VRRPV6 != hostif_trapid)
     && (SAI_HOSTIF_TRAP_ID_BGPV6 != hostif_trapid))
    {
        hostif_trap->ctc_reason_id = sai_trap_id_to_ctc_reason_id(hostif_trapid);
        ctc_sai_set_reason_trap(hostif_trap->ctc_reason_id, hostif_trapid);
    }

    hostif_trap->channel = trap_channel;
    ctc_sai_set_reason_channel(hostif_trap->ctc_reason_id, hostif_trap->channel);

    hostif_trap->action = SAI_PACKET_ACTION_TRAP;
    
    return ret;
}


sai_status_t ctc_sai_set_trap_attr_group(sai_object_id_t trap_id, sai_object_id_t trap_group_id)
{
    ctc_sai_hostif_trap_t  *hostif_trap   = NULL;
    ctc_sai_hostif_group_t *trap_group  = NULL;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_DEBUG("in:hostif_trapid %u", trap_id);

    /*1, check trap and trap group exist*/

    hostif_trap = ctc_sai_hostif_trap_db_trap_id(trap_id);
    CTC_SAI_PTR_VALID_CHECK(hostif_trap);
    trap_group = ctc_sai_hostif_group_db_oid(trap_group_id); 
    CTC_SAI_PTR_VALID_CHECK(trap_group);

    /*2, set trap_group and set ctc_reason_id to trap_group*/
    /*Note, currently CTC API must need ctc_reason_id to set trap_group queue,
    so, we require user to bind trap to one trap_group first, and then set 
    trap_group attr for queueid*/
    hostif_trap->hostif_group_id = trap_group_id;
    trap_group->ctc_reason_id = hostif_trap->ctc_reason_id;

    return SAI_STATUS_SUCCESS;
}

sai_status_t ctc_sai_get_trap_attr_group(sai_object_id_t trap_id, sai_attribute_t* attr)
{
    ctc_sai_hostif_trap_t  *hostif_trap   = NULL;
    CTC_SAI_DEBUG_FUNC();

    hostif_trap = ctc_sai_hostif_trap_db_trap_id(trap_id);
    CTC_SAI_PTR_VALID_CHECK(hostif_trap);
    attr->value.oid = hostif_trap->hostif_group_id;

    return SAI_STATUS_SUCCESS;
}



#define ________SAI_SAI_API_FUNC

/*
* Routine Description:
*    Create host interface trap group
*
* Arguments:
*  [out] hostif_trap_group_id  - host interface trap group id
*  [in] attr_count - number of attributes
*  [in] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_create_hostif_trap_group(
    _Out_ sai_object_id_t *hostif_trap_group_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    sai_status_t          ret         = SAI_STATUS_SUCCESS;
    sai_attribute_t*      attr        = NULL;
    uint32_t              attr_idx    = 0;
    ctc_sai_hostif_group_t *hostif_group = NULL;

    CTC_SAI_DEBUG_FUNC();
    sai_create_hostif_trap_group_debug_param(attr_count, attr_list);
    CTC_SAI_PTR_VALID_CHECK(hostif_trap_group_id);
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    hostif_group = ctc_sai_hostif_group_db_alloc();
    if (NULL == hostif_group)
    {
        return SAI_STATUS_NO_MEMORY;
    }

    for (attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = (sai_attribute_t*)attr_list + attr_idx;
        switch (attr->id)
        {
        case SAI_HOSTIF_TRAP_GROUP_ATTR_ADMIN_STATE:
            hostif_group->enable = attr->value.booldata;
            break;

        case SAI_HOSTIF_TRAP_GROUP_ATTR_PRIO:
            hostif_group->priority = attr->value.u32;
            break;

        case SAI_HOSTIF_TRAP_GROUP_ATTR_QUEUE:
            hostif_group->queue_id = attr->value.u32;
            break;

        case SAI_HOSTIF_TRAP_GROUP_ATTR_POLICER:
            hostif_group->police_id = attr->value.oid;
            break;

        default:
            break;
        }

        if(ret != SAI_STATUS_SUCCESS)
        {
            break;
        }
    }

    *hostif_trap_group_id = hostif_group->hostif_group_id;
    CTC_SAI_DEBUG("in:hostif_trap_group_id 0x%llx", (*hostif_trap_group_id));
    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*    Remove host interface trap group
*
* Arguments:
*  [in] hostif_trap_group_id - host interface trap group id
*
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_remove_hostif_trap_group(
    _In_ sai_object_id_t hostif_trap_group_id
    )
{
    CTC_SAI_DEBUG_FUNC();
    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*   Set host interface trap group attribute value.
*
* Arguments:
*    [in] hostif_trap_group_id - host interface trap group id
*    [in] attr - attribute
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_set_trap_group_attribute(
    _In_ sai_object_id_t hostif_trap_group_id,
    _In_ const sai_attribute_t *attr
    )
{
    sai_status_t                ret = SAI_STATUS_SUCCESS;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_DEBUG("in:hostif_trap_group_id 0x%llx", hostif_trap_group_id);
    CTC_SAI_PTR_VALID_CHECK(attr);

    switch(attr->id)
    {        
    case SAI_HOSTIF_TRAP_GROUP_ATTR_QUEUE:
        ret = ctc_sai_set_trap_group_queue(hostif_trap_group_id, attr->value.u32);
        break;
        
    case SAI_HOSTIF_TRAP_GROUP_ATTR_POLICER:
        ret = ctc_sai_set_trap_group_policer(hostif_trap_group_id, attr->value.oid);
        break;
        
    case SAI_HOSTIF_TRAP_GROUP_ATTR_PRIO:
        ret = ctc_sai_set_trap_group_priority(hostif_trap_group_id, attr->value.u32);
        break;
        
    default:
        return SAI_STATUS_NOT_SUPPORTED;
    }

    if (0 != ret)
    {
        log_sys(M_MOD_SAI, E_ERROR, "TODO Trap group ID %"PRIu64", attr ID %u ret %d", hostif_trap_group_id, attr->id, ret);
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t sai_get_trap_group_attribute(
    _In_ sai_object_id_t hostif_trap_group_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list
    )
{

    sai_status_t                ret         = SAI_STATUS_SUCCESS;
    sai_attribute_t*            attr        = NULL;
    uint32_t                    attr_idx    = 0;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        switch(attr->id)
        {
        case SAI_HOSTIF_TRAP_GROUP_ATTR_QUEUE:
            ret = ctc_sai_get_trap_group_queue(hostif_trap_group_id, attr);
            break;
            
        case SAI_HOSTIF_TRAP_GROUP_ATTR_POLICER:
            ret = ctc_sai_get_trap_group_policer(hostif_trap_group_id, attr);
            break;
            
        case SAI_HOSTIF_TRAP_GROUP_ATTR_PRIO:
            ret = ctc_sai_get_trap_group_priority(hostif_trap_group_id, attr);
            break;

        case SAI_HOSTIF_TRAP_GROUP_ATTR_COUNTER:
            ret = ctc_sai_get_trap_group_counter(hostif_trap_group_id, attr);
            break;
        }
    }
    return ret;
}


/*
* Routine Description:
*   Set trap attribute value.
*
* Arguments:
*    [in] hostif_trap_id - host interface trap id
*    [in] attr - attribute
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_set_trap_attribute(
    _In_ sai_hostif_trap_id_t hostif_trapid,
    _In_ const sai_attribute_t *attr
    )
{
    ctc_sai_hostif_trap_t  *hostif_trap   = NULL;
    sai_status_t                ret = SAI_STATUS_SUCCESS;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_DEBUG("in:hostif_trapid %u", hostif_trapid);
    CTC_SAI_PTR_VALID_CHECK(attr);
    
    hostif_trap = ctc_sai_hostif_trap_db_trap_id(hostif_trapid);
    if (NULL == hostif_trap)
    {
        hostif_trap = ctc_sai_hostif_trap_db_alloc(hostif_trapid);
        if (NULL == hostif_trap)
        {
            return SAI_STATUS_NO_MEMORY;
        }
    }
    hostif_trap->ctc_reason_id = sai_trap_id_to_ctc_reason_id(hostif_trapid);

    switch(attr->id)
    {        
    case SAI_HOSTIF_TRAP_ATTR_TRAP_GROUP:
        ret = ctc_sai_set_trap_attr_group(hostif_trapid, attr->value.oid);
        break;
        
    default:
        return SAI_STATUS_NOT_SUPPORTED;
    }
    
    return ret;

}

/*
* Routine Description:
*   Get trap attribute value.
*
* Arguments:
*    [in] hostif_trap_id - host interface trap id
*    [in] attr_count - number of attributes
*    [in,out] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_get_trap_attribute(
    _In_ sai_hostif_trap_id_t hostif_trapid,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{

    sai_status_t                ret         = SAI_STATUS_SUCCESS;
    sai_attribute_t*            attr        = NULL;
    uint32_t                    attr_idx    = 0;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        switch(attr->id)
        {
        case SAI_HOSTIF_TRAP_ATTR_TRAP_GROUP:
            ret = ctc_sai_get_trap_attr_group(hostif_trapid, attr);
            break;
        default: 
            return SAI_STATUS_NOT_SUPPORTED;
        }
    }
    return ret;
}


/*
* Routine Description:
*   Set user defined trap attribute value.
*
* Arguments:
*    [in] hostif_user_defined_trap_id - host interface user defined trap id
*    [in] attr - attribute
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_set_user_defined_trap_attribute(
    _In_ sai_hostif_user_defined_trap_id_t hostif_user_defined_trapid,
    _In_ const sai_attribute_t *attr)
{

    CTC_SAI_DEBUG_FUNC();
    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*   Get user defined trap attribute value.
*
* Arguments:
*    [in] hostif_user_defined_trap_id - host interface user defined trap id
*    [in] attr_count - number of attributes
*    [in,out] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_get_user_defined_trap_attribute(
    _In_ sai_hostif_user_defined_trap_id_t hostif_user_defined_trapid,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{
    
    CTC_SAI_DEBUG_FUNC();
    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*    Create host interface
*
* Arguments:
*    [out] hif_id - host interface id
*    [in] attr_count - number of attributes
*    [in] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_create_hostif(
    _Out_ sai_object_id_t *hif_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    ctc_sai_hostif_t    *sai_hostif = NULL;
    sai_attribute_t     *attr       = NULL;
    sai_object_id_t     portid       = 0;
    uint32_t            attr_idx = 0;
    char    ifname[32];
    uint32  vlanid = 0;
    int     fd = -1;

    CTC_SAI_DEBUG_FUNC();
    sai_create_hostif_debug_param(attr_count, attr_list);
    sal_memset(ifname, 0, sizeof(ifname));

    for(attr_idx = 0; attr_idx < attr_count; attr_idx ++)
    {
        attr = (sai_attribute_t*)attr_list + attr_idx;

        switch (attr->id)
        {
        case SAI_HOSTIF_ATTR_TYPE:
            break;

        case SAI_HOSTIF_ATTR_RIF_OR_PORT_ID:
            portid = attr->value.oid;
            break;

        case SAI_HOSTIF_ATTR_NAME:
            sal_strcpy(ifname, attr->value.chardata);
            break;
        }
    }

    /* use ioctl to create tap interface in linux kernel */
    fd = ctc_create_net_device(ifname);    
    if (fd < 0)
    {
        return SAI_STATUS_NO_MEMORY;
    }

    /* get vlan id by vlan interface name */
    if (0 == sal_memcmp(ifname, "vlan", 4))
    {
        sal_sscanf(ifname, "vlan""%u", &vlanid);
        ctc_vlan_set_arp_excp_type(vlanid, CTC_EXCP_FWD_AND_TO_CPU);    
    }

    sai_hostif = ctc_sai_hostif_db_alloc(ifname, fd, portid, vlanid);
    if (NULL == sai_hostif)
    {
        ctc_remove_net_device(fd);
        return SAI_STATUS_NO_MEMORY;
    }

    *hif_id = sai_hostif->hostif_id;

    /* add fd to epoll socket list */
    g_hostif_info.evl.data.fd = fd;
    epoll_ctl(g_hostif_info.epoll_sock, EPOLL_CTL_ADD, fd, &g_hostif_info.evl);
    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*    Remove host interface
*
* Arguments:
*    [in] hif_id - host interface id
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
int32_t sai_remove_hostif(
    _In_ sai_object_id_t hif_id
    )
{
    ctc_sai_hostif_t *sai_hostif = NULL;
    int32 fd = -1;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_DEBUG("in:hif_id 0x%llx", hif_id);
    sai_hostif = ctc_sai_hostif_get_by_hostif_id(hif_id);
    if (NULL == sai_hostif)
    {
        return SAI_STATUS_FAILURE;
    }

    /* vlan interface process */
    if (0 != sai_hostif->vlanid)
    {
        ctc_vlan_set_arp_excp_type(sai_hostif->vlanid, CTC_EXCP_NORMAL_FWD);
    }

    /* remove fd from epoll socket list */
    epoll_ctl(g_hostif_info.epoll_sock, EPOLL_CTL_DEL, sai_hostif->fd, &g_hostif_info.evl);

    /* remove host interface from hash and free the memory */
    fd = sai_hostif->fd;
    ctc_sai_hostif_db_release(sai_hostif);

    /* remove net device from linux kernel */
    ctc_remove_net_device(fd);

    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*    Set host interface attribute
*
* Arguments:
*    [in] hif_id - host interface id
*    [in] attr - attribute
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_set_hostif_attribute(
    _In_ sai_object_id_t hif_id,
    _In_ const sai_attribute_t *attr)
{
    CTC_SAI_DEBUG_FUNC();
    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*    Get host interface attribute
*
* Arguments:
*    [in] hif_id - host interface id
*    [in] attr_count - number of attributes
*    [inout] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_get_hostif_attribute(
    _In_ sai_object_id_t  hif_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{
    CTC_SAI_DEBUG_FUNC();
    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*   hostif receive function
*
* Arguments:
*    [in]  hif_id  - host interface id
*    [out] buffer - packet buffer
*    [in,out] buffer_size - [in] allocated buffer size. [out] actual packet size in bytes
*    [in,out] attr_count - [in] allocated list size. [out] number of attributes
*    [out] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    SAI_STATUS_BUFFER_OVERFLOW if buffer_size is insufficient,
*    and buffer_size will be filled with required size. Or
*    if attr_count is insufficient, and attr_count
*    will be filled with required count.
*    Failure status code on error
*/
sai_status_t sai_recv_hostif_packet(
    _In_ sai_object_id_t  hif_id,
    _Out_ void *buffer,
    _Inout_ sai_size_t *buffer_size,
    _Inout_ uint32_t *attr_count,
    _Out_ sai_attribute_t *attr_list)
{
    CTC_SAI_DEBUG_FUNC();
    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*   hostif send function
*
* Arguments:
*    [in] hif_id  - host interface id. only valid for send through FD channel. Use SAI_NULL_OBJECT_ID for send through CB channel.
*    [In] buffer - packet buffer
*    [in] buffer size - packet size in bytes
*    [in] attr_count - number of attributes
*    [in] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_send_hostif_packet(
    _In_ sai_object_id_t hif_id,
    _In_ void *buffer,
    _In_ sai_size_t buffer_size,
    _In_ uint32_t attr_count,
    _In_ sai_attribute_t *attr_list)
{
    ctc_pkt_tx_t    pkt_tx;
    ctc_pkt_skb_t   *p_skb = NULL;
    uint32_t        attr_idx = 0;
    uint32_t        port_type = 0;
    uint32_t        tid = 0;
    sai_object_id_t portid = 0;
    sai_object_id_t ingress_portid = 0;
    sai_attribute_t *attr = NULL;
    ctc_sai_hostif_t *pst_hostif = NULL;
    int32_t         sdk_rc = 0;
    int32_t         ret = 0;
    sai_object_id_t vlan_id = 0;
    uint32          gport = 0;
    uint32          is_mcast = FALSE;
    uint8           oper_type = CTC_PKT_OPER_NORMAL;
    sai_attribute_t debug_attr[1];

    debug_attr[0].value.u32 = 0;
    
    CTC_SAI_DEBUG_FUNC();
    sal_memset(&pkt_tx, 0, sizeof(ctc_pkt_tx_t));
    p_skb = &(pkt_tx.skb);
    ctc_packet_skb_init(p_skb);

    ctc_packet_skb_put(p_skb, buffer_size);
    sal_memcpy(p_skb->data, buffer, buffer_size);

    for (attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;

        switch (attr->id)
        {
        case SAI_HOSTIF_PACKET_EGRESS_PORT_OR_LAG:
            portid = attr->value.oid;
            break;
            
        case SAI_HOSTIF_PACKET_EGRESS_PORT_VLAN:
            vlan_id = attr->value.oid;
            break;    
            
        case SAI_HOSTIF_PACKET_INGRESS_PORT:
            is_mcast = TRUE;
            ingress_portid = attr->value.oid;
            break;

        case SAI_HOSTIF_PACKET_PTP_METADATA:
            oper_type = CTC_PKT_OPER_PTP;
            break;
    
        case SAI_HOSTIF_PACKET_PDU_TYPE:
            debug_attr[0].value.u32 = attr->value.u32;
            break;
    
        default:
            break;
        }
    }

    if (is_mcast)
    {
        pkt_tx.mode = CTC_PKT_MODE_DMA;
        pkt_tx.lchip = 0;
        pkt_tx.tx_info.oper_type = oper_type;
        pkt_tx.tx_info.is_critical = TRUE;
        pkt_tx.tx_info.src_svid = vlan_id;
        pkt_tx.tx_info.dest_group_id = vlan_id;
        pkt_tx.tx_info.flags |= CTC_PKT_FLAG_HASH_VALID;
        pkt_tx.tx_info.flags |= CTC_PKT_FLAG_MCAST;
        pkt_tx.tx_info.flags |= CTC_PKT_FLAG_SRC_SVID_VALID;

        if (ingress_portid)
        {
            port_type = CTC_SAI_OBJECT_TYPE_GET(ingress_portid);
            if (SAI_OBJECT_TYPE_LAG == port_type)
            {
                tid = CTC_SAI_OBJECT_INDEX_GET(ingress_portid);
                pkt_tx.tx_info.src_port = CTC_MAP_TID_TO_GPORT(tid);
            }
            else if (SAI_OBJECT_TYPE_PORT == port_type)
            {
                pkt_tx.tx_info.src_port = CTC_SAI_OBJECT_INDEX_GET(ingress_portid);
            }
            else 
            {
                return SAI_STATUS_INVALID_PARAMETER;
            }
            pkt_tx.tx_info.flags |= CTC_PKT_FLAG_SRC_PORT_VALID;
            //ret = ctc_fdb_get_gport(p_skb->data, vlan_id, &gport);
        }
        else
        {
            pkt_tx.tx_info.src_port = 0;
            //pkt_tx.tx_info.src_port = CPU_PORT; ?
        }

        sdk_rc = ctc_packet_tx(&pkt_tx);
        if (!sdk_rc) {
            ctc_sai_get_sys_info()->sai_switch_notification_table.on_cpu_packet_debug(p_skb->data, p_skb->tail - p_skb->data + 1, 1, debug_attr);
        }
        return ctc_sai_get_error_from_sdk_error(sdk_rc);
    }
    else
    {
        if (vlan_id)
        {
            /* vlan interface */
            ctc_packet_skb_put(p_skb, buffer_size);
            sal_memcpy(p_skb->data, buffer, buffer_size);
            pkt_tx.tx_info.flags |= CTC_PKT_FLAG_SRC_SVID_VALID;

            /* first get port from static fdb */
            ret = ctc_fdb_get_gport(p_skb->data, vlan_id, &gport);
            /* not found static fdb get port from arp fdb */
            if (SAI_STATUS_SUCCESS != ret)
            {
                ret = ctc_arp_fdb_get_gport(p_skb->data, vlan_id, &gport);
            }

            pst_hostif = ctc_sai_hostif_get_by_vlan(vlan_id);
            if (NULL == pst_hostif)
            {
                return SAI_STATUS_FAILURE;
            }

            /* flooding in vlan */
            if (SAI_STATUS_SUCCESS != ret)
            {
                pkt_tx.tx_info.flags |= CTC_PKT_FLAG_MCAST;
                pkt_tx.tx_info.flags |= CTC_PKT_FLAG_SRC_SVID_VALID;
                pkt_tx.tx_info.src_svid = pst_hostif->vlanid;
                pkt_tx.tx_info.dest_group_id = pst_hostif->vlanid;
            }
            /* unicat to port */
            else
            {
                pkt_tx.tx_info.flags |= CTC_PKT_FLAG_NH_OFFSET_VALID;
                pkt_tx.tx_info.flags |= CTC_PKT_FLAG_SRC_SVID_VALID;
                pkt_tx.tx_info.src_svid = pst_hostif->vlanid;
                pkt_tx.tx_info.nh_offset = pst_hostif->nexthop_ptr;
                pkt_tx.tx_info.dest_gport = gport;
            }

            pkt_tx.mode = CTC_PKT_MODE_DMA;
            pkt_tx.lchip = 0;
            pkt_tx.tx_info.oper_type = oper_type;
            pkt_tx.tx_info.is_critical = TRUE;

            sdk_rc = ctc_packet_tx(&pkt_tx);
            if (!sdk_rc) {
                ctc_sai_get_sys_info()->sai_switch_notification_table.on_cpu_packet_debug(p_skb->data, p_skb->tail - p_skb->data + 1, 1, debug_attr);
            }
            return ctc_sai_get_error_from_sdk_error(sdk_rc);
        }

        if (portid)
        {
            port_type = CTC_SAI_OBJECT_TYPE_GET(portid);
            if (SAI_OBJECT_TYPE_LAG == port_type)
            {
                tid = CTC_SAI_OBJECT_INDEX_GET(portid);
                pkt_tx.tx_info.dest_gport = CTC_MAP_TID_TO_GPORT(tid);
            }
            else if (SAI_OBJECT_TYPE_PORT == port_type)
            {
                pkt_tx.tx_info.dest_gport = CTC_SAI_OBJECT_INDEX_GET(portid);
            }
            else 
            {
                return SAI_STATUS_INVALID_PARAMETER;
            }
        }
        else
        {
            pkt_tx.tx_info.dest_gport = CTC_SAI_OBJECT_INDEX_GET(hif_id);
        }

        pkt_tx.mode = CTC_PKT_MODE_DMA;
        pkt_tx.lchip = 0;
        pkt_tx.tx_info.oper_type = oper_type;
        pkt_tx.tx_info.is_critical = TRUE;
        /* Added by kcao for bug 43952, only ucast packet need set bypass */
        if (!CTC_FLAG_ISSET(pkt_tx.tx_info.flags, CTC_PKT_FLAG_MCAST))
        {
            pkt_tx.tx_info.flags |= CTC_PKT_FLAG_NH_OFFSET_BYPASS;
        }

        sdk_rc = ctc_packet_tx(&pkt_tx);
        if (!sdk_rc) {
            ctc_sai_get_sys_info()->sai_switch_notification_table.on_cpu_packet_debug(p_skb->data, p_skb->tail - p_skb->data + 1, 1, debug_attr);
        }
        return ctc_sai_get_error_from_sdk_error(sdk_rc);
    }
}

sai_status_t
ctc_sai_hostif_db_dhcp_sys_syn(uint32 enable)
{
    uint32_t trap_id = SAI_HOSTIF_TRAP_ID_DHCP;

    if (enable)
    {
        ctc_sai_create_hostif_trap(trap_id, SAI_HOSTIF_TRAP_CHANNEL_NETDEV);
    }
    else
    {
        ctc_sai_create_hostif_trap(trap_id, SAI_HOSTIF_TRAP_CHANNEL_NOPROCESS);
    }
    
    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_hostif_db_init()
{
    uint32_t reason_id = 0;
    uint32_t trap_id = 0;

    sal_memset(&g_hostif_info, 0, sizeof(g_hostif_info));
    g_hostif_info.max_count = 256;

    if (0 != ctc_opf_init(CTC_OPF_SAI_HOSTIF_GROUP_ID,1))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    g_hostif_info.opf.pool_type = CTC_OPF_SAI_HOSTIF_GROUP_ID;
    g_hostif_info.opf.pool_index = 0;

    if (0 != ctc_opf_init_offset(&g_hostif_info.opf, 0, g_hostif_info.max_count))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    if (0 != ctc_opf_init(CTC_OPF_SAI_HOSTIF_ID,1))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    g_hostif_info.hosif_id_opf.pool_type = CTC_OPF_SAI_HOSTIF_ID;
    g_hostif_info.hosif_id_opf.pool_index = 0;

    if (0 != ctc_opf_init_offset(&g_hostif_info.hosif_id_opf, 0, 2048))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    g_hostif_info.hostif_group_list = ctc_list_new();
    g_hostif_info.hostif_trap_list  = ctc_list_new();
    g_hostif_info.hostif_port_list  = ctc_list_new();

    g_hostif_info.hostif_hash  = ctc_hash_create(64, 32, _hostif_hash_make, _hostif_hash_cmp);
    g_hostif_info.hostif_fd_hash  = ctc_hash_create(64, 32, _hostif_fd_hash_make, _hostif_fd_hash_cmp);
    g_hostif_info.hostif_port_hash  = ctc_hash_create(64, 32, _hostif_port_hash_make, _hostif_port_hash_cmp);
    g_hostif_info.hostif_vlan_hash  = ctc_hash_create(64, 32, _hostif_vlan_hash_make, _hostif_vlan_hash_cmp);
    g_hostif_info.hostif_arp_fdb_hash  = ctc_hash_create(128, 256, _hostif_arp_fdb_hash_make, _hostif_arp_fdb_hash_cmp);

    sal_mutex_create(&g_hostif_info.arp_fdb_mutex);

    sal_task_create(&g_hostif_info.arp_fdb_aging_task, "arpfdbaging",
        SAL_DEF_TASK_STACK_SIZE, 0, ctc_arp_fdb_aging, NULL);

    for (reason_id = 0; reason_id < 256; reason_id++)
    {
        g_hostif_info.ctc_reason[reason_id].channel = SAI_HOSTIF_TRAP_CHANNEL_NETDEV;
    }

    /* init all trap id */
    for (trap_id = SAI_HOSTIF_TRAP_ID_STP; trap_id <= SAI_HOSTIF_TRAP_ID_SCL_MATCH; trap_id++)
    {
        ctc_sai_create_hostif_trap(trap_id, SAI_HOSTIF_TRAP_CHANNEL_CB);
    }

    for (trap_id = SAI_HOSTIF_TRAP_ID_ARP_REQUEST; trap_id <= SAI_HOSTIF_TRAP_ID_MLD_V2_REPORT; trap_id++)
    {
        ctc_sai_create_hostif_trap(trap_id, SAI_HOSTIF_TRAP_CHANNEL_NETDEV);
    }
    
    for (trap_id = SAI_HOSTIF_TRAP_ID_L2_PORT_MAC_LIMIT; trap_id <= SAI_HOSTIF_TRAP_ID_L2_PORT_MAC_MISMATCH; trap_id++)
    {
        ctc_sai_create_hostif_trap(trap_id, SAI_HOSTIF_TRAP_CHANNEL_CB);
    }

    for (trap_id = SAI_HOSTIF_TRAP_ID_L3_MTU_ERROR; trap_id <= SAI_HOSTIF_TRAP_ID_TTL_ERROR; trap_id++)
    {
        ctc_sai_create_hostif_trap(trap_id, SAI_HOSTIF_TRAP_CHANNEL_NETDEV);
    }
    /*added openflow trap*/
    ctc_sai_create_hostif_trap(SAI_HOSTIF_TRAP_ID_CUSTOM_EXCEPTION_OPENFLOW_TO_CONTROLLER, SAI_HOSTIF_TRAP_CHANNEL_CB);

    /*modified by yejl to change SAI_HOSTIF_TRAP_CHANNEL_CB to SAI_HOSTIF_TRAP_CHANNEL_NETDEV*/
    trap_id = SAI_HOSTIF_TRAP_ID_CUSTOM_EXCEPTION_L3_COPY_CPU;
    ctc_sai_create_hostif_trap(trap_id, SAI_HOSTIF_TRAP_CHANNEL_NETDEV);

    trap_id = SAI_HOSTIF_TRAP_ID_DHCP;
    ctc_sai_create_hostif_trap(trap_id, SAI_HOSTIF_TRAP_CHANNEL_NETDEV);
    return SAI_STATUS_SUCCESS;
}

static sai_status_t __init_mode(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    sai_status_t ret = SAI_STATUS_SUCCESS;

    ctc_sai_hostif_db_init();

    /* create socket to kernal */
    ctc_lib_netlink_socket();

    ctc_packet_epool_init();

    ctc_sai_cpu_traffic_init();
    ctc_sai_init_other_cpu_traffic();
    
    system("mkdir /dev/net > /dev/null 2>&1");
    system("mknod /dev/net/tun c 10 200 > /dev/null 2>&1");
    system("chmod 777 /dev/net/tun > /dev/null 2>&1");
    preg->init_status = INITIALIZED;

    sal_task_create(&g_hostif_info.recv_task, "saiRecvThread", SAL_DEF_TASK_STACK_SIZE, 0,
        ctc_packet_receive_from_kernel, NULL);
    return ret;
}

static sai_status_t __exit_mode(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}

/*
* hostif methods table retrieved with sai_api_query()
*/
 static sai_hostif_api_t g_sai_api_func = {
    .create_hostif                       = sai_create_hostif,
    .remove_hostif                       = sai_remove_hostif,
    .set_hostif_attribute                = sai_set_hostif_attribute,
    .get_hostif_attribute                = sai_get_hostif_attribute,
    .create_hostif_trap_group            = sai_create_hostif_trap_group,
    .remove_hostif_trap_group            = sai_remove_hostif_trap_group,
    .set_trap_group_attribute            = sai_set_trap_group_attribute,
    .get_trap_group_attribute            = sai_get_trap_group_attribute,
    .set_trap_attribute                  = sai_set_trap_attribute,
    .get_trap_attribute                  = sai_get_trap_attribute,
    .set_user_defined_trap_attribute     = sai_set_user_defined_trap_attribute,
    .get_user_defined_trap_attribute     = sai_get_user_defined_trap_attribute,
    .recv_packet                         = sai_recv_hostif_packet,
    .send_packet                         = sai_send_hostif_packet,
};


static ctc_sai_api_reg_info_t g_api_reg_info = {
    .id               = SAI_API_HOST_INTERFACE,
    .init_func        = __init_mode,
    .exit_func        = __exit_mode,
    .api_method_table = &g_sai_api_func,
    .private_data     = NULL,
};

#define ________SAI_OUTER_FUNC
sai_status_t ctc_sai_hostinterface_init()
{
    api_reg_register_fn(&g_api_reg_info);
    return SAI_STATUS_SUCCESS;
}


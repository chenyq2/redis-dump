#if !defined (__SAI_HOSTINTERFACE_H_)
#define __SAI_HOSTINTERFACE_H_
#include <sys/epoll.h>
#include <linux/socket.h>
#include <linux/version.h>
#include <linux/types.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <linux/if_tun.h>
#include "ctc_const.h"

/**
 *  @brief FDB event type
 */
typedef enum sai_arp_fdb_event_t
{
    /** New FDB entry learned */
    SAI_ARP_FDB_EVENT_LEARNED,

    /** FDB entry aged */
    SAI_ARP_FDB_EVENT_AGED,

    /** FDB entry flushd */
    SAI_ARP_FDB_EVENT_FLUSHED,

} sai_arp_fdb_event_t;

typedef struct ctc_sai_hostif_trap_s
{
    sai_uint32_t                hostif_trap_id;
    bool                        enable;
    sai_hostif_trap_channel_t   channel;
    sai_object_id_t             fd;
    sai_packet_action_t         action;
    sai_object_id_t             hostif_group_id;
    sai_object_id_t             acl_entry_oid;
    uint32_t                    ctc_reason_id;    
} ctc_sai_hostif_trap_t;

typedef struct ctc_sai_hostif_group_s
{
    sai_object_id_t             hostif_group_id;
    bool                        enable;
    sai_uint32_t                ctc_reason_id; /*currently, one trap group alloc one reason_id, 
                                            if user need many reason to one group, it need new reason for them*/
    sai_uint32_t                queue_id;
    sai_uint32_t                priority; /*not used currently*/
    sai_object_id_t             police_id;
} ctc_sai_hostif_group_t;

typedef struct ctc_sai_ctc_reason_s
{
    uint32                      reason_id;
    sai_hostif_trap_channel_t   channel;
    sai_int32_t                 hostif_trap_id;
} ctc_sai_ctc_reason_t;

typedef struct ctc_sai_hostif_s
{
    char ifname[32];
    sai_object_id_t             hostif_id;
    sai_object_id_t             port;
    uint32                      vlanid;
    int32                       fd;

    /* vlan interface sending packet */
    uint32                      nexthop_ptr;
} ctc_sai_hostif_t;

typedef struct ctc_sai_arp_fdb_s
{
    mac_addr_t                  mac_address;
    uint32                      vlanid;
    uint32                      resv;
    sai_object_id_t             port;
    int32                       live_time; /* unit is miniute */
} ctc_sai_arp_fdb_t;

typedef struct ctc_sai_hostif_info_s
{
    ctc_linklist_t *hostif_group_list;
    ctc_linklist_t *hostif_trap_list;
    ctc_hash_t *hostif_hash;
    ctc_hash_t *hostif_fd_hash;
    ctc_hash_t *hostif_port_hash;
    ctc_linklist_t *hostif_port_list;
    ctc_hash_t *hostif_vlan_hash;
    ctc_hash_t *hostif_arp_fdb_hash;
    ctc_sai_ctc_reason_t ctc_reason[1024];  /* CTC_PKT_CPU_REASON_MAX_COUNT */
    ctc_opf_t       opf;
    ctc_opf_t       hosif_id_opf;
    sai_uint32_t    max_count;

    sal_task_t *recv_task;
    sal_task_t *arp_fdb_aging_task;
    sal_mutex_t *arp_fdb_mutex;
    int32 epoll_sock;
    struct epoll_event evl;
    char pkt_buff[9600];

    int32 sock;
    int32 seq;
    struct sockaddr_nl snl;
    char name[20];
}ctc_sai_hostif_info_t;

enum ctc_sai_l2pdu_key_index_by_mac_da_e
{
    SAI_L2PDU_KEY_INDEX_ERPS_COMMON         = 0,
    SAI_L2PDU_KEY_INDEX_ERPS_FLUSH          = 1
 };
typedef enum ctc_sai_l2pdu_key_index_by_mac_da_e ctc_sai_l2pdu_key_index_by_mac_da_t;

enum ctc_sai_l2pdu_key_index_by_mac_da_hw_e
{
    SAI_L2PDU_KEY_INDEX_ERPS_HW_ADDR1       = 0,
    SAI_L2PDU_KEY_INDEX_ERPS_HW_ADDR2       = 1,
    SAI_L2PDU_KEY_INDEX_ERPS_HW_ADDR3       = 2,
    SAI_L2PDU_KEY_INDEX_ERPS_HW_ADDR4       = 3
 };
typedef enum ctc_sai_l2pdu_key_index_by_mac_da_hw_e ctc_sai_l2pdu_key_index_by_mac_da_hw_t;

#define CTC_SAI_CPU_TRAFFIC_SET_MAC(mac, byte0, byte1, byte2, byte3, byte4, byte5)         \
do{                                                                                     \
    mac[0] = byte0;                                                                     \
    mac[1] = byte1;                                                                     \
    mac[2] = byte2;                                                                     \
    mac[3] = byte3;                                                                     \
    mac[4] = byte4;                                                                     \
    mac[5] = byte5;                                                                     \
}while(0)

sai_status_t ctc_sai_hostinterface_init();

sai_status_t ctc_sai_hostif_db_dhcp_sys_syn(uint32 enable);

int32
ctc_packet_send_to_sdk(ctc_sai_hostif_t *pst_hostif, char *buffer, int buffer_size);

int32
ctc_packet_send_to_kernel(int fd, uint8 *buf, uint32 length);

int32 ctc_fdb_get_gport(uint8 *mac_address, uint32 vlanid, uint32 *gport);

int32 ctc_fdb_get_portid(uint8 *mac_address, uint32 vlanid, sai_object_id_t *portid);

uint32_t sai_trap_action_to_ctc_action(sai_hostif_trap_id_t trapid, sai_packet_action_t action);

uint32_t sai_trap_id_to_ctc_reason_id(sai_hostif_trap_id_t trapid);

inline void ctc_sai_set_reason_channel(const uint32_t reason_id, const sai_hostif_trap_channel_t channel);

inline void ctc_sai_set_reason_trap(const uint32_t reason_id, const sai_int32_t hostif_trap_id);

inline sai_hostif_trap_channel_t ctc_sai_get_reason_channel(const uint32_t reason_id);

inline sai_int32_t ctc_sai_get_reason_trap(const uint32_t reason_id);
#endif


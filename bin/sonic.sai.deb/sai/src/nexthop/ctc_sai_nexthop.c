#include <sai.h>
#include <sal.h>
#include "ctc_api.h"
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_notifier_call.h>
#include <ctc_sai_sai.h>
#include <ctc_sai_port.h>
#include <ctc_sai_routerintf.h>
#include <ctc_sai_nexthop.h>
#include <ctc_sai_neighbor.h>
#include <ctc_sai_debug.h>

#define CTC_SAI_NEXTHOP_BLOCK_SIZE	64

static ctc_sai_nexthop_info_t  g_sai_nh_info;

static ctc_sai_attr_entry_info_t g_sai_attr_entries[] = {
    {
        .id     = SAI_NEXT_HOP_ATTR_TYPE,
        .type   = SAI_ATTR_FALG_READ | SAI_ATTR_FALG_WRITE,
    },
    {
        .id     = SAI_NEXT_HOP_ATTR_IP,
        .type   = SAI_ATTR_FALG_CREATE | SAI_ATTR_FALG_READ,
    },
	{
        .id     = SAI_NEXT_HOP_ATTR_ROUTER_INTERFACE_ID,
        .type   = SAI_ATTR_FALG_CREATE | SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_ATTR_ID_END,
        .type   = 0,
    },
};

int32
ctc_sai_nexthop_id_opf_alloc(uint32* p_index)
{
    return ctc_opf_alloc_offset(&g_sai_nh_info.opf, 0, p_index);
}

int32
ctc_sai_nexthop_id_opf_release(uint32 index)
{
    return ctc_opf_free_offset(&g_sai_nh_info.opf, 0, index);
}

ctc_sai_nexthop_entry_t*
ctc_nexthop_get_by_key(
    _In_  const ctc_sai_nexthop_entry_t* pkey)
{
    return ctc_hash_lookup(g_sai_nh_info.phash, (void*)pkey);
}

static uint32_t
__nexthop_hash_make(
	_In_  void* data)
{
    ctc_sai_nexthop_entry_t* pnb_key = (ctc_sai_nexthop_entry_t*)data;

    return ctc_hash_caculate(sizeof(_sai_nexthop_key_t), &pnb_key->nh_key);
}

static bool
__nexthop_hash_cmp(
	_In_  ctc_sai_nexthop_entry_t* pnb_key,
	_In_  ctc_sai_nexthop_entry_t* pnb_key1)
{
    if (0 != sal_memcmp(&pnb_key->nh_key, &pnb_key1->nh_key, sizeof(pnb_key1->nh_key)))
    {
        return FALSE;
    }

    return TRUE;
}

sai_status_t
ctc_sai_nexthop_alloc_offset(uint32_t *popf_index)
{
    sai_status_t    ret         = SAI_STATUS_SUCCESS;
    uint32          opf_index   = 0;
    
    CTC_SAI_ERROR_GOTO_MAPSDKERR2SAI(
        ctc_opf_alloc_offset(&g_sai_nh_info.opf, 0, &opf_index),ret,out);

    *popf_index = opf_index;
    
out:
    return ret;
}

sai_status_t
ctc_sai_nexthop_free_offset(uint32_t opf_index)
{
    sai_status_t    ret         = SAI_STATUS_SUCCESS;
    
    CTC_SAI_ERROR_GOTO_MAPSDKERR2SAI(
        ctc_opf_free_offset(&g_sai_nh_info.opf, 0, opf_index),ret,out);
    
out:
    return ret;
}

sai_status_t
ctc_nexthop_alloc(
	_In_  ctc_sai_nexthop_entry_t** pp_nh_entry)
{
	sai_status_t                ret          = SAI_STATUS_SUCCESS;
    ctc_sai_nexthop_entry_t 	*pst_nexthop = NULL;
    uint32_t                    index        = 0;

    if (g_sai_nh_info.pvector->used_cnt >= g_sai_nh_info.max_count)
    {
        ret = SAI_STATUS_TABLE_FULL;
        goto out;
    }

    pst_nexthop = mem_malloc(MEM_APP_NEXTHOP_MODULE,sizeof(ctc_sai_nexthop_entry_t));
    if (NULL == pst_nexthop)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }

    sal_memset(pst_nexthop,0,sizeof(ctc_sai_nexthop_entry_t));

    CTC_SAI_ERROR_GOTO(ctc_opf_alloc_offset(&g_sai_nh_info.opf, 0, &index),ret,out1);
    pst_nexthop->nh_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP, index);

    *pp_nh_entry = pst_nexthop;

out:
    return ret;

out1:
    if(pst_nexthop)
    {
        mem_free(pst_nexthop);
        pst_nexthop = NULL;
    }
    goto out;
}

void
ctc_nexthop_release(
	_In_  ctc_sai_nexthop_entry_t *pst_nexthop)
{
    if(NULL == pst_nexthop)
    {
        return;
    }

    ctc_opf_free_offset(&g_sai_nh_info.opf, 0, CTC_SAI_OBJECT_INDEX_GET(pst_nexthop->nh_id));
    mem_free(pst_nexthop);
}

ctc_sai_nexthop_entry_t*
ctc_nexthop_get_by_oid_no_ref(
	_In_  const sai_object_id_t nh_id)
{
    ctc_sai_nexthop_entry_t  *pst_nexthop = NULL;

    pst_nexthop = ctc_vector_get(g_sai_nh_info.pvector,
                                CTC_SAI_OBJECT_INDEX_GET(nh_id));
    return pst_nexthop;
}

ctc_sai_nexthop_entry_t*
ctc_nexthop_get_by_oid(
	_In_  const sai_object_id_t nh_id)
{
    return ctc_nexthop_get_by_oid_no_ref(nh_id);
}

sai_status_t
ctc_nexthop_add_entry(
    _In_  ctc_sai_nexthop_entry_t *nexthop)
{
    ctc_ip_nh_param_t ipuc_nexthop;

    sal_memset(&ipuc_nexthop, 0, sizeof(ipuc_nexthop));
    ipuc_nexthop.dsnh_offset  = 0;
    ipuc_nexthop.oif.oif_type = CTC_NH_OIF_TYPE_ROUTED_PORT;
    ipuc_nexthop.oif.gport = CTC_LPORT_CPU;
    return ctc_nh_add_ipuc(CTC_SAI_OBJECT_INDEX_GET(nexthop->nh_id), &ipuc_nexthop);
}

sai_status_t
ctc_nexthop_add_entry_new(
    _In_  ctc_sai_nexthop_entry_t *nexthop,
    _In_ ctc_sai_routerintf_entry_t* p_rif)
{
    ctc_ip_nh_param_t ipuc_nexthop;

    sal_memset(&ipuc_nexthop, 0, sizeof(ipuc_nexthop));
    ipuc_nexthop.dsnh_offset  = 0;
    ipuc_nexthop.oif.gport = 65535;

    SAI_SET_FLAG(ipuc_nexthop.flag, CTC_IP_NH_FLAG_UNROV);

    if (SAI_ROUTER_INTERFACE_TYPE_VLAN == p_rif->type)
    {
        ipuc_nexthop.oif.vid = p_rif->vlan_id;
        ipuc_nexthop.oif.oif_type = CTC_NH_OIF_TYPE_VLAN_PORT;
    }
    else
    {
        ipuc_nexthop.oif.oif_type = CTC_NH_OIF_TYPE_ROUTED_PORT;
        ctc_sai_port_objectid_to_gport(p_rif->port_oid, &ipuc_nexthop.oif.gport);
    }

    return ctc_nh_add_ipuc(CTC_SAI_OBJECT_INDEX_GET(nexthop->nh_id), &ipuc_nexthop);
}

sai_status_t
ctc_nexthop_remove_entry(
	_In_  ctc_sai_nexthop_entry_t *nexthop)
{
    return ctc_nh_remove_ipuc(CTC_SAI_OBJECT_INDEX_GET(nexthop->nh_id));
}

sai_status_t
ctc_nexthop_get_type(
	_In_  ctc_sai_nexthop_entry_t 	*nexthop,
	_Inout_ sai_attribute_t			*attr)
{
    attr->value.s32 = nexthop->nh_type;
    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_nexthop_get_ip(
	_In_  ctc_sai_nexthop_entry_t 	*nexthop,
	_Inout_  sai_attribute_t		*attr)
{
    sal_memcpy(&attr->value.ipaddr, &nexthop->nh_key.ip_address, sizeof(sai_ip_address_t));
    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_nexthop_get_ifid(
	_In_  ctc_sai_nexthop_entry_t 	*nexthop,
	_Inout_  sai_attribute_t		*attr)
{
    attr->value.oid = nexthop->nh_key.rif_id;
    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_nexthop_db_init()
{
	sai_status_t                 ret = SAI_STATUS_SUCCESS;

    g_sai_nh_info.max_count = CTC_SAI_NEXTHOP_MAX_ENTRY;
    g_sai_nh_info.pvector   =
			ctc_vector_init(CTC_VEC_BLOCK_NUM(g_sai_nh_info.max_count,
				CTC_SAI_NEXTHOP_BLOCK_SIZE),
			CTC_SAI_NEXTHOP_BLOCK_SIZE);

    if(NULL == g_sai_nh_info.pvector)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }

    g_sai_nh_info.phash =
    ctc_hash_create(512, 32,
        (hash_key_fn)__nexthop_hash_make,
        (hash_cmp_fn)__nexthop_hash_cmp);

    CTC_SAI_ERROR_GOTO(ctc_opf_init(CTC_OPF_SAI_NEXTHOP_ID,1),ret,out1);
    g_sai_nh_info.opf.pool_type = CTC_OPF_SAI_NEXTHOP_ID;
    g_sai_nh_info.opf.pool_index= 0;
    /*modified by wangl for  openflow GLB_OPENFLOW_NH_MAX_NUM*/
    CTC_SAI_ERROR_GOTO(ctc_opf_init_offset(&g_sai_nh_info.opf, 3000, g_sai_nh_info.max_count),
		ret,out1);

out:
    return ret;

out1:
	if(g_sai_nh_info.pvector)
	{
		g_sai_nh_info.pvector = NULL;
	}
	goto out;
}

#define ________SAI_SAI_DEBUG_FUNC
sai_status_t
ctc_sai_create_next_hop_debug_param(
    _Out_ sai_object_id_t* next_hop_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    CTC_SAI_DEBUG("in:attr_count %u", attr_count);
    CTC_SAI_DEBUG("out:next_hop_id 0x%llx", (*next_hop_id));

    return SAI_STATUS_SUCCESS;
}
sai_status_t
ctc_sai_remove_next_hop_debug_param(
    _In_ sai_object_id_t next_hop_id)
{
    CTC_SAI_DEBUG("in:next_hop_id %u", next_hop_id);

    return SAI_STATUS_SUCCESS;
}
sai_status_t
ctc_sai_get_next_hop_attribute_debug_param(
    _In_ sai_object_id_t next_hop_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{
    sai_status_t     ret         = SAI_STATUS_SUCCESS;
    uint32_t         attr_idx    = 0;
    sai_attribute_t* attr        = NULL;

    CTC_SAI_DEBUG("in:next_hop_id 0x%llx attr_count %u", next_hop_id, attr_count);
    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        ret = ctc_sai_attr_check_read_attr(g_sai_attr_entries,attr);

        if(ret != SAI_STATUS_SUCCESS)
        {
            return ret + attr_idx;
        }

        switch(attr->id)
        {
        case SAI_NEXT_HOP_ATTR_TYPE:
            CTC_SAI_DEBUG("out:SAI_NEXT_HOP_ATTR_TYPE %d", attr->value.s32);
            break;
        case SAI_NEXT_HOP_ATTR_IP:
            CTC_SAI_DEBUG("out:SAI_NEXT_HOP_ATTR_IP");
            break;
        case SAI_NEXT_HOP_ATTR_ROUTER_INTERFACE_ID:
            CTC_SAI_DEBUG("out:SAI_NEXT_HOP_ATTR_ROUTER_INTERFACE_ID 0x%llx", attr->value.oid);
            break;
        }

        if(ret != SAI_STATUS_SUCCESS)
        {
            break;
        }
    }

    return SAI_STATUS_SUCCESS;
}
#define ________SAI_SAI_API_FUNC
/*
* Routine Description:
*    Create next hop
*
* Arguments:
*    [out] next_hop_id - next hop id
*    [in] attr_count - number of attributes
*    [in] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*
* Note: IP address expected in Network Byte Order.
*/
sai_status_t
ctc_sai_create_next_hop(
    _Out_ sai_object_id_t* next_hop_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    sai_status_t                ret = SAI_STATUS_SUCCESS;
    ctc_sai_attr_entry_list_t   *pattr_entry_list   = NULL;
    ctc_sai_nexthop_entry_t     *pst_nexthop        = NULL;
    ctc_sai_neighbor_entry_t    *pst_neighbor       = NULL;
    ctc_sai_routerintf_entry_t  *p_rif              = NULL;
    sai_neighbor_entry_t        neighbor_entry;

    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_PTR_VALID_CHECK(next_hop_id);
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    CTC_SAI_ERROR_GOTO(ctc_sai_attr_alloc_attr_entry_list(g_sai_attr_entries,
                            attr_list,
                            attr_count,
                            &pattr_entry_list), ret, out);

    CTC_SAI_ERROR_GOTO(ctc_sai_attr_check_attr_entry_list(g_sai_attr_entries,
                            pattr_entry_list), ret, out);

    /* 1. alloc nexthop */
    CTC_SAI_ERROR_GOTO(ctc_nexthop_alloc(&pst_nexthop), ret, out);

    /* 2. update nexthop para */
    if(pattr_entry_list[SAI_NEXT_HOP_ATTR_TYPE].valid)
    {
        pst_nexthop->nh_type = pattr_entry_list[SAI_NEXT_HOP_ATTR_TYPE].value.s32;
    }
    sal_memcpy(&pst_nexthop->nh_key.ip_address,
        &pattr_entry_list[SAI_NEXT_HOP_ATTR_IP].value.ipaddr,sizeof(sai_ip_address_t));
    pst_nexthop->nh_key.rif_id = pattr_entry_list[SAI_NEXT_HOP_ATTR_ROUTER_INTERFACE_ID].value.oid;

    p_rif = ctc_routerintf_get_by_oid_no_ref(pst_nexthop->nh_key.rif_id);

    /* 3. update nexthop para */
    if (NULL == p_rif)
    {
        ret = SAI_STATUS_ITEM_NOT_FOUND;
        goto out1;
    }
    else
    {
        CTC_SAI_ERROR_GOTO(ctc_nexthop_add_entry_new(pst_nexthop, p_rif), ret, out1);
    }

    /* Modified by wangjj for update of the nexthop, 2016-08-04 */
    //CTC_SAI_ERROR_GOTO(ctc_nexthop_add_entry(pst_nexthop), ret, out1);

    ctc_hash_insert(g_sai_nh_info.phash, pst_nexthop);
    ctc_vector_add(g_sai_nh_info.pvector, CTC_SAI_OBJECT_INDEX_GET(pst_nexthop->nh_id), pst_nexthop);

    /* 4. return nexthop id*/
    *next_hop_id = pst_nexthop->nh_id;

    sal_memset(&neighbor_entry, 0, sizeof(neighbor_entry));
    sal_memcpy(&neighbor_entry.ip_address, &pst_nexthop->nh_key.ip_address, sizeof(pst_nexthop->nh_key.ip_address));
    neighbor_entry.rif_id = pst_nexthop->nh_key.rif_id;
    pst_neighbor = ctc_neighbor_get_by_key(&neighbor_entry);
    if(NULL != pst_neighbor)
    {
        pst_neighbor->nhid = pst_nexthop->nh_id;
        ctc_neighbor_update_entry(pst_neighbor);
    }

    ctc_sai_create_next_hop_debug_param(next_hop_id, attr_count, attr_list);

out:
    if (NULL != pattr_entry_list)
    {
        ctc_sai_attr_free_attr_entry_list(pattr_entry_list);
    }
    return ret;

out1:

    if (NULL != pst_nexthop)
    {
        ctc_hash_remove(g_sai_nh_info.phash, pst_nexthop);
        ctc_vector_del(g_sai_nh_info.pvector, CTC_SAI_OBJECT_INDEX_GET(pst_nexthop->nh_id));        
        ctc_nexthop_release(pst_nexthop);
    }
    goto out;
}

/*
* Routine Description:
*    Remove next hop
*
* Arguments:
*    [in] next_hop_id - next hop id
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_remove_next_hop(
    _In_ sai_object_id_t next_hop_id)
{
    sai_status_t             ret = SAI_STATUS_SUCCESS;
    ctc_sai_nexthop_entry_t *pst_nexthop = NULL;

    CTC_SAI_DEBUG_FUNC();
    ctc_sai_remove_next_hop_debug_param(next_hop_id);

    pst_nexthop = ctc_nexthop_get_by_oid_no_ref(next_hop_id);
    if(NULL == pst_nexthop)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    ret = ctc_nexthop_remove_entry(pst_nexthop);
    ctc_hash_remove(g_sai_nh_info.phash, pst_nexthop);
    ctc_vector_del(g_sai_nh_info.pvector, CTC_SAI_OBJECT_INDEX_GET(pst_nexthop->nh_id));
    ctc_nexthop_release(pst_nexthop);
    return ret;
}

/*
* Routine Description:
*    Set Next Hop attribute
*
* Arguments:
*    [in] next_hop_id - next hop id
*    [in] attr - attribute
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_set_next_hop_attribute(
    _In_ sai_object_id_t next_hop_id,
    _In_ const sai_attribute_t *attr)
{
    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_PTR_VALID_CHECK(attr);

	return SAI_STATUS_INVALID_ATTRIBUTE_0;
}

/*
* Routine Description:
*    Get Next Hop attribute
*
* Arguments:
*    [in] next_hop_id - next hop id
*    [in] attr_count - number of attributes
*    [inout] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_get_next_hop_attribute(
    _In_ sai_object_id_t next_hop_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{
    sai_status_t                ret         = SAI_STATUS_SUCCESS;
    sai_attribute_t*            attr        = NULL;
    uint32_t                    attr_idx    = 0;
    ctc_sai_nexthop_entry_t     *pnh_entry = NULL;

    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_PTR_VALID_CHECK(attr_list);

    pnh_entry = ctc_nexthop_get_by_oid_no_ref(next_hop_id);
    if(NULL == pnh_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        ret = ctc_sai_attr_check_read_attr(g_sai_attr_entries,attr);

        if(ret != SAI_STATUS_SUCCESS)
        {
            return ret + attr_idx;
        }

        switch(attr->id)
        {
        case SAI_NEXT_HOP_ATTR_TYPE:
            ret = ctc_nexthop_get_type(pnh_entry,attr);
            break;
        case SAI_NEXT_HOP_ATTR_IP:
            ret = ctc_nexthop_get_ip(pnh_entry,attr);
            break;
        case SAI_NEXT_HOP_ATTR_ROUTER_INTERFACE_ID:
            ret = ctc_nexthop_get_ifid(pnh_entry,attr);
            break;
        }

        if(ret != SAI_STATUS_SUCCESS)
        {
            break;
        }
    }
    ctc_sai_get_next_hop_attribute_debug_param(next_hop_id, attr_count, attr_list);
    return ret;
}

#define ________SAI_SAI_INNER_API_FUNC
static sai_status_t
__init_mode_fn(
    _In_  ctc_sai_api_reg_info_t    *preg,
    _In_  void                      *private_data)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    CTC_SAI_ERROR_GOTO(ctc_nexthop_db_init(),ret,out);

    preg->init_status =  INITIALIZED;

out:
    return ret;
}

static sai_status_t
__exit_mode_fn(
    _In_  ctc_sai_api_reg_info_t    *preg,
    _In_  void                      *private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}

#define ________SAI_SAI_API_FUNC

static sai_next_hop_api_t      g_sai_api_func = {
        .create_next_hop            = ctc_sai_create_next_hop,
        .remove_next_hop            = ctc_sai_remove_next_hop,
        .set_next_hop_attribute     = ctc_sai_set_next_hop_attribute,
        .get_next_hop_attribute     = ctc_sai_get_next_hop_attribute,
};

static ctc_sai_api_reg_info_t g_api_reg_info = {
        .id  = SAI_API_NEXT_HOP,
        .init_func = __init_mode_fn,
        .exit_func = __exit_mode_fn,
        .api_method_table = &g_sai_api_func,
        .private_data     = NULL,
};

#define ________SAI_OUTER_FUNC
sai_status_t
ctc_sai_nexthop_init()
{
    api_reg_register_fn(&g_api_reg_info);

    return SAI_STATUS_SUCCESS;
}

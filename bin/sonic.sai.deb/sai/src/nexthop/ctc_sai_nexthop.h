#if !defined (__SAI_NEXTHOP_H_)
#define __SAI_NEXTHOP_H_

#include <sainexthop.h>
#include <ctc_vector.h>
#include <ctc_opf.h>

#define CTC_SAI_NEXTHOP_MAX_ENTRY  16384

typedef enum
{
    CTC_SAI_NEXTHOP_UPDATE_EVENT,
}ctc_sai_nexthop_event_t;

struct ctc_sai_routerintf_entry_s;

typedef struct _sai_nexthop_key_s
{
    sai_object_id_t rif_id; 
    sai_ip_address_t ip_address;
} _sai_nexthop_key_t;

typedef struct ctc_sai_nexthop_entry_s
{
    sai_object_id_t         nh_id;
    uint32_t                nh_type;
    _sai_nexthop_key_t      nh_key;
}ctc_sai_nexthop_entry_t;

typedef struct ctc_sai_nexthop_info_s
{
    ctc_hash_t*     phash;              
    ctc_vector_t*   pvector;
    uint32_t        max_count;
    ctc_opf_t       opf;
}ctc_sai_nexthop_info_t;

ctc_sai_nexthop_entry_t*
ctc_nexthop_get_by_oid(
    _In_  const sai_object_id_t);

void
ctc_nexthop_release(
    _In_  ctc_sai_nexthop_entry_t *);

ctc_sai_nexthop_entry_t*
ctc_nexthop_get_by_key(
    _In_  const ctc_sai_nexthop_entry_t* pkey);

sai_status_t
ctc_sai_nexthop_init();

ctc_sai_nexthop_entry_t*
ctc_nexthop_get_by_oid_no_ref(
	_In_  const sai_object_id_t nh_id);

sai_status_t
ctc_nexthop_alloc(
  _In_  ctc_sai_nexthop_entry_t** pp_nh_entry);

sai_status_t
ctc_sai_nexthop_alloc_offset(uint32_t *popf_index);

sai_status_t
ctc_sai_nexthop_free_offset(uint32_t opf_index);

#endif


#include <sal.h>
#include "ctc_api.h"
#include <sai.h>
#include <saitypes.h>
#include <saistatus.h>
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_sai.h>
#include <ctc_sai_nexthop_group.h>
#include <ctc_sai_port.h>
#include <ctc_sai_debug.h>
#include <ctc_sai_mirror.h>
#include <ctc_sai_lag.h>
#include <ctc_sai_tap_group.h>
#include <ctc_sai_acl.h>
#include <ctc_sai_copp.h>

enum{
        L4_PROTOCOL_TCP = 6,
        L4_PROTOCOL_UDP = 17,
        L4_PROTOCOL_GRE = 47,
    };

enum{
        L4_PROTOCOL_GRE_DEST_PORT = 4789,
    };

#define 	CTC_SAI_SCL_TUNNEL_RES				4096
#define 	CTC_SAI_SCL_TUNNEL_BLOCK_SIZE		32

typedef struct fields_mapping_res_s{
#define acl u.ctc_acl_entry
#define scl u.ctc_scl_entry

#define acl_key u.ctc_acl_entry.key.u.ipv4_key
#define scl_key u.ctc_scl_entry.key.u.tcam_ipv4_key
    enum {
        FIELD_ACL_ENTRY_TYPE,
        FIELD_SCL_ENTRY_TYPE,
    } mapping_type;
    union {
        ctc_acl_entry_t        ctc_acl_entry;
        ctc_scl_entry_t        ctc_scl_entry;
    }u;    
}fields_mapping_res_t;


extern sai_status_t ctc_sai_policer_acl_set_policer(uint32_t policer_id, uint32_t entry_id, bool enable);
static int32_t 
__check_tunnel_header_valid_and_config(
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res);

extern void 
__mapping_sai_acl_entry_to_ctc_acl_entry(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res);

extern ctc_sai_port_info_t g_sai_port_info;

extern ctc_sai_lag_info_t g_ctc_sai_lag_info;

static ctc_sai_attr_entry_info_t g_acl_count_attr_entries[] = {
    {
        .id     = SAI_ACL_COUNTER_ATTR_TABLE_ID,
        .type   = SAI_ATTR_FALG_CREATE | SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_ACL_COUNTER_ATTR_ENABLE_PACKET_COUNT,
        .type   = SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_ACL_COUNTER_ATTR_ENABLE_BYTE_COUNT,
        .type   = SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_ACL_COUNTER_ATTR_PACKETS,
        .type   = SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_ACL_COUNTER_ATTR_BYTES,
        .type   = SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_ATTR_ID_END,
        .type   = 0,
    },
};

extern ctc_sai_attr_entry_info_t    g_sai_acl_attr_entries[];
extern ctc_sai_attr_entry_info_t    g_sai_acl_attr_tables[];
ctc_sai_acl_info_t  g_sai_acl_info;

ctc_sai_mirror_entry_t*
ctc_sai_mirror_entry_get(sai_object_id_t session_oid);

#define ________SAI_ACL_SAI_INNER_API_FUNC

void ctc_sai_acl_alloc_entry_id(uint32* p_index)
{
    ctc_opf_alloc_offset(&g_sai_acl_info.opf[2], 0, p_index);
}

void ctc_sai_acl_release_entry_id(uint32 index)
{
    ctc_opf_free_offset(&g_sai_acl_info.opf[2], 0, index);
}

static uint32_t
__tunnel_decap_res_hash_make(
    _In_  void* data)
{
    ctc_sai_acl_tunnel_decap_info_t* p_hash = (ctc_sai_acl_tunnel_decap_info_t*)data;

    return ctc_hash_caculate(sizeof(ctc_sai_acl_tunnel_decap_info_key_t), &p_hash->key);
}

static bool
__tunnel_decap_res_hash_cmp(
    _In_ void *data,
    _In_ void *data1)
{
    ctc_sai_acl_tunnel_decap_info_t* phash = data;
    ctc_sai_acl_tunnel_decap_info_t* phash1 = data1;

    if (0 == sal_memcmp(&phash->key, &phash1->key, sizeof(ctc_sai_acl_tunnel_decap_info_key_t)))
    {
        return TRUE;
    }
    return FALSE;
}

static ctc_sai_acl_tunnel_decap_info_t*
__tunnel_decap_alloc (  ctc_sai_acl_tunnel_decap_info_key_t *key, 
                        ctc_sai_acl_entry_t  *psai_acl_entry)
{
    ctc_sai_acl_tunnel_decap_info_t   tunnel_decap; 
    ctc_sai_acl_tunnel_decap_info_t   *ptunnel_decap = NULL;
    fields_mapping_res_t    sclentry = {FIELD_SCL_ENTRY_TYPE};
    sai_uint32_t            index = 0;
    uint32_t                group_id = 0;
    uint32                  gport = 0;
    
    sai_status_t            ret = SAI_STATUS_SUCCESS;
    
    sal_memset(&tunnel_decap, 0, sizeof(ctc_sai_acl_tunnel_decap_info_t));
    sal_memcpy(&tunnel_decap.key,key, sizeof(ctc_sai_acl_tunnel_decap_info_key_t));

    sal_memset(&sclentry, 0, sizeof(fields_mapping_res_t));
    sclentry.mapping_type = FIELD_SCL_ENTRY_TYPE;

    ptunnel_decap = ctc_hash_lookup(g_sai_acl_info.tunnel_res_hash, &tunnel_decap);

    if(NULL == ptunnel_decap){
        ptunnel_decap = mem_malloc(MEM_APP_TAP_MODULE,sizeof(ctc_sai_acl_tunnel_decap_info_t));
        if(NULL == ptunnel_decap){
            return NULL;
        }

        sal_memset(ptunnel_decap, 0, sizeof(ctc_sai_acl_tunnel_decap_info_t));
        sal_memcpy(&ptunnel_decap->key,key, sizeof(ctc_sai_acl_tunnel_decap_info_key_t));
    }

    /* if exist then ref count */
    if(ptunnel_decap->count > 0){
        ptunnel_decap->count++;

        CTC_SAI_DEBUG("%s%d: get tunnel decap res inc count:count = %d\n",
            __FUNCTION__,__LINE__,ptunnel_decap->count);
        
        return ptunnel_decap;
    }

    /* create res */
    ctc_opf_alloc_offset(&g_sai_acl_info.tunnel_opf, 0, &index);
    ptunnel_decap->entry_id = index;

    __mapping_sai_acl_entry_to_ctc_acl_entry(
                &psai_acl_entry->outer_fileds, 
                psai_acl_entry, 
                &sclentry);


    ctc_sai_port_objectid_to_gport(key->port_oid, &gport);
    group_id = ctc_sai_port_make_acl_group_id(CTC_INGRESS, gport);

    sclentry.scl.entry_id = ptunnel_decap->entry_id;
    sclentry.scl.key.type = CTC_SCL_KEY_TCAM_IPV4;
    sclentry.scl.key.u.tcam_ipv4_key.key_size = CTC_SCL_KEY_SIZE_DOUBLE;
    sclentry.scl.priority_valid = TRUE;
    sclentry.scl.priority = psai_acl_entry->priority;

    CTC_SET_FLAG(sclentry.scl.action.type, CTC_SCL_ACTION_FLOW);
    CTC_SET_FLAG(sclentry.scl.action.u.flow_action.flag, CTC_SCL_FLOW_ACTION_FLAG_DENY_BRIDGE);
    CTC_SET_FLAG(sclentry.scl.action.u.flow_action.flag, CTC_SCL_FLOW_ACTION_FLAG_DENY_LEARNING);
    CTC_SET_FLAG(sclentry.scl.action.u.flow_action.flag, CTC_SCL_FLOW_ACTION_FLAG_DENY_ROUTE);
    //CTC_SET_FLAG(sclentry.scl.action.u.flow_action.flag, CTC_SCL_FLOW_ACTION_FLAG_INNERLOOKUP);
    CTC_SET_FLAG(sclentry.scl.action.u.flow_action.flag, CTC_SCL_FLOW_ACTION_FLAG_METADATA);
    sclentry.scl.action.u.flow_action.metadata = ptunnel_decap->entry_id;

    __check_tunnel_header_valid_and_config(psai_acl_entry, &sclentry);
#if 0
    CTC_SET_FLAG(sclentry.scl.action.u.flow_action.flag, CTC_SCL_FLOW_ACTION_FLAG_STRIP_PACKET);
    sclentry.scl.action.u.flow_action.strip_packet.start_packet_strip = 3;
    sclentry.scl.action.u.flow_action.strip_packet.strip_extra_len    = 8;
    sclentry.scl.action.u.flow_action.strip_packet.packet_type        = 0;
#endif
    ret = ctc_scl_add_entry(group_id, &sclentry.scl);
    ret = ctc_scl_install_entry(sclentry.scl.entry_id);

//    ctc_sai_port_alloc_metadata(key->port_oid);

    ptunnel_decap->count++;

    ctc_hash_insert(g_sai_acl_info.tunnel_res_hash, ptunnel_decap);

    (void)ret;
    return ptunnel_decap;
}

void
__tunnel_decap_free (ctc_sai_acl_tunnel_decap_info_t *ptunnel_decap)
{
    uint32                  gport = 0;
    
//    sal_assert(ptunnel_decap != NULL);

    ptunnel_decap->count--;

    CTC_SAI_DEBUG("%s%d:dec tunnel count count = %d\n",
            __FUNCTION__,__LINE__,ptunnel_decap->count);
    
    if(ptunnel_decap->count <= 0 ){
        CTC_SAI_DEBUG("%s%d:free nexthop entry_id = %d\n",
            __FUNCTION__,__LINE__,ptunnel_decap->entry_id);
        
        ctc_scl_uninstall_entry(ptunnel_decap->entry_id);
        ctc_scl_remove_entry(ptunnel_decap->entry_id);
        ctc_opf_free_offset(&g_sai_acl_info.tunnel_opf, 0, ptunnel_decap->entry_id);

        ctc_sai_port_objectid_to_gport(ptunnel_decap->key.port_oid, &gport);

        ctc_hash_remove(g_sai_acl_info.tunnel_res_hash, ptunnel_decap);

        mem_free(ptunnel_decap);
    }
}


sai_status_t
ctc_sai_acl_db_alloc_table(ctc_sai_acl_table_t** ppacl_table)
{
    ctc_sai_acl_table_t *pacl_table = NULL;
    uint32_t            index       = 0;

    if (g_sai_acl_info.pvector[0]->used_cnt >= g_sai_acl_info.max_count[0])
    {
        return SAI_STATUS_TABLE_FULL;
    }

    pacl_table = mem_malloc(MEM_APP_ACL_MODULE,sizeof(ctc_sai_acl_table_t));
    if (NULL != pacl_table)
    {
        sal_memset(pacl_table, 0, sizeof(ctc_sai_acl_table_t));
        ctc_opf_alloc_offset(&g_sai_acl_info.opf[0],0, &index);
        pacl_table->table_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_TABLE, index);
    }

    *ppacl_table = pacl_table;
    return SAI_STATUS_SUCCESS;
}

void
ctc_sai_acl_db_release_table(ctc_sai_acl_table_t *pacl_table)
{
    if (NULL == pacl_table)
    {
        return ;
    }

    ctc_opf_free_offset(&g_sai_acl_info.opf[0], 0, CTC_SAI_OBJECT_INDEX_GET(pacl_table->table_id));
    mem_free(pacl_table);
}


ctc_sai_acl_table_t*
ctc_sai_acl_db_get_table_by_oid(const sai_object_id_t table_id)
{
    ctc_sai_acl_table_t  *pacl_table = NULL;
    pacl_table = ctc_vector_get(g_sai_acl_info.pvector[0], CTC_SAI_OBJECT_INDEX_GET(table_id));
    return pacl_table;
}

ctc_sai_acl_table_t*
ctc_sai_acl_db_get_table_by_oid_no_ref(const sai_object_id_t table_id)
{
    ctc_sai_acl_table_t  *pacl_table = NULL;

    pacl_table = ctc_vector_get(g_sai_acl_info.pvector[0], CTC_SAI_OBJECT_INDEX_GET(table_id));
    return pacl_table;
}

sai_status_t
ctc_sai_acl_db_alloc_entry(ctc_sai_acl_entry_t** ppacl_entry)
{
    ctc_sai_acl_entry_t *pacl_entry = NULL;
    uint32_t index = 0;

    if (g_sai_acl_info.pvector[1]->used_cnt >= g_sai_acl_info.max_count[1])
    {
        return SAI_STATUS_TABLE_FULL;
    }

    pacl_entry = mem_malloc(MEM_APP_ACL_MODULE,sizeof(ctc_sai_acl_entry_t));
    if (NULL != pacl_entry)
    {
        sal_memset(pacl_entry, 0, sizeof(ctc_sai_acl_entry_t));
        ctc_opf_alloc_offset(&g_sai_acl_info.opf[1], 0, &index);
        pacl_entry->entry_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_ENTRY, index);
    }

    *ppacl_entry = pacl_entry;
    return SAI_STATUS_SUCCESS;
}

void
ctc_sai_acl_db_release_entry(ctc_sai_acl_entry_t *pacl_entry)
{
    if (NULL == pacl_entry)
    {
        return ;
    }

    ctc_opf_free_offset(&g_sai_acl_info.opf[1], 0, CTC_SAI_OBJECT_INDEX_GET(pacl_entry->entry_id));
    mem_free(pacl_entry);
}

ctc_sai_acl_entry_t*
ctc_sai_acl_db_get_entry_by_oid(const sai_object_id_t entry_id)
{
    ctc_sai_acl_entry_t  *pacl_entry = NULL;
    pacl_entry = ctc_vector_get(g_sai_acl_info.pvector[1], CTC_SAI_OBJECT_INDEX_GET(entry_id));

    return pacl_entry;
}

#ifdef GREATBELT

ctc_sai_acl_port_en_t*
ctc_sai_acl_get_port_en_by_oid(const sai_object_id_t acl_port_oid)
{
    ctc_sai_acl_port_en_t *acl_port_en_info = NULL;
    struct ctc_listnode* node = NULL;

    for (node = g_sai_acl_info.acl_port_oid_en_list->head; node; CTC_NEXTNODE(node))
    {
        acl_port_en_info = CTC_GETDATA(node);
        if (acl_port_en_info && acl_port_en_info->acl_port_oid == acl_port_oid)
        {
            return acl_port_en_info;
        }
    }
    return NULL;
}

ctc_sai_acl_port_en_t*
ctc_sai_acl_port_en_db_alloc(sai_object_id_t acl_port_oid, ctc_direction_t dir, sai_object_id_t acl_lag_oid)
{
    ctc_sai_acl_port_en_t *acl_port_en_info = NULL;
    uint32 gport = 0;
    uint16 class_id = 0;
    ctc_sai_acl_port_en_t *acl_port_en_info_db = NULL;

    if (acl_port_oid == acl_lag_oid)
    {
        ctc_sai_port_objectid_to_classid(acl_port_oid, &class_id);
    }
    else
    {
        ctc_sai_port_objectid_to_classid(acl_lag_oid, &class_id);
    }

    
    ctc_sai_port_objectid_to_gport(acl_port_oid, &gport);
    acl_port_en_info_db = ctc_sai_acl_get_port_en_by_oid(acl_port_oid);

    if (acl_port_en_info_db)
    {
        if (CTC_INGRESS == dir)
        {
            acl_port_en_info_db->ingress_en_cnt++;
            if (1 == acl_port_en_info_db->ingress_en_cnt)
            {
                ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_EN, CTC_INGRESS, 0x1);
                ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_CLASSID, dir, class_id);
            }   
        }
        else if (CTC_EGRESS == dir)
        {
            acl_port_en_info_db->egress_en_cnt++;
            if (1 == acl_port_en_info_db->egress_en_cnt)
            {
                ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_EN, CTC_EGRESS, 0x1);
                ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_CLASSID, dir, class_id);
            }
        }
        else if (CTC_BOTH_DIRECTION == dir)
        {
            acl_port_en_info_db->ingress_en_cnt++;
            acl_port_en_info_db->egress_en_cnt++;
            if (1 == acl_port_en_info_db->ingress_en_cnt)
            {
                ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_EN, CTC_INGRESS, 0x1);
                ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_CLASSID, dir, class_id);
            }
            if (1 == acl_port_en_info_db->egress_en_cnt)
            {
                ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_EN, CTC_EGRESS, 0x1);
                ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_CLASSID, dir, class_id);
            }
        }
        return acl_port_en_info_db;
    }

    acl_port_en_info = mem_malloc(MEM_APP_ACL_MODULE,sizeof(ctc_sai_acl_port_en_t));
    if (NULL == acl_port_en_info)
    {
        return NULL;
    }

    sal_memset(acl_port_en_info, 0, sizeof(ctc_sai_acl_port_en_t));

    acl_port_en_info->acl_port_oid = acl_port_oid;
    ctc_sai_port_objectid_to_gport(acl_port_oid, &gport);
    if (CTC_INGRESS == dir)
    {
        acl_port_en_info->ingress_en_cnt++;
        ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_EN, CTC_INGRESS, 0x1);
        ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_CLASSID, dir, class_id);
    }
    else if (CTC_EGRESS == dir)
    {
        acl_port_en_info->egress_en_cnt++;
        ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_EN, CTC_EGRESS, 0x1);
        ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_CLASSID, dir, class_id);
    }
    else if (CTC_BOTH_DIRECTION == dir)
    {
        acl_port_en_info->ingress_en_cnt++;
        acl_port_en_info->egress_en_cnt++;
        ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_EN, CTC_INGRESS, 0x1);
        ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_EN, CTC_EGRESS, 0x1);
        ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_CLASSID, dir, class_id);
    }
    
    ctc_listnode_add(g_sai_acl_info.acl_port_oid_en_list, acl_port_en_info);
    return acl_port_en_info;
}

void
ctc_sai_acl_port_en_db_release(ctc_sai_acl_port_en_t *acl_port_en_info, ctc_direction_t dir)
{
    ctc_sai_acl_port_en_t *acl_port_en_info_db = NULL;
    uint32 gport = 0;
    
    if(NULL == acl_port_en_info)
    {
        return;
    }

    ctc_sai_port_objectid_to_gport(acl_port_en_info->acl_port_oid, &gport);

    acl_port_en_info_db = ctc_sai_acl_get_port_en_by_oid(acl_port_en_info->acl_port_oid);
    if (NULL == acl_port_en_info_db)
    {
        return;
    }

    if (CTC_INGRESS == dir && acl_port_en_info_db->ingress_en_cnt > 0)
    {
        acl_port_en_info_db->ingress_en_cnt--;
    }
    else if (CTC_EGRESS == dir && acl_port_en_info_db->egress_en_cnt > 0)
    {
        acl_port_en_info_db->egress_en_cnt--;
    }
    else if (CTC_BOTH_DIRECTION == dir && acl_port_en_info_db->egress_en_cnt > 0 
        && acl_port_en_info_db->ingress_en_cnt > 0)
    {
        acl_port_en_info_db->ingress_en_cnt--;
        acl_port_en_info_db->egress_en_cnt--;
    }
    
    if (0 == acl_port_en_info_db->ingress_en_cnt)
    {
        ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_EN, CTC_INGRESS, 0x0);
    }

    if (0 == acl_port_en_info_db->egress_en_cnt)
    {
        ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_EN, CTC_EGRESS, 0x0);
    }

    if (0 == acl_port_en_info_db->ingress_en_cnt && 0 == acl_port_en_info_db->egress_en_cnt)
    {
        ctc_listnode_delete(g_sai_acl_info.acl_port_oid_en_list, acl_port_en_info_db);
        mem_free(acl_port_en_info_db);
    }
    return;
}

int32_t
_ctc_sai_acl_update_port_en_db(
_In_  void	*array_data,
_In_  void	*use_data)
{
    ctc_sai_port_entry_t *pst_port_entry = array_data;
    ctc_sai_acl_en_port_node_t *acl_port_en_node = use_data;
    sai_object_id_t acl_lag_oid;

    if ((NULL == pst_port_entry) || (NULL == acl_port_en_node))
    {
        return 0;
    }

    if (0 != pst_port_entry->lag_id)
    {
        acl_lag_oid = pst_port_entry->lag_id;
    }
    else
    {
        acl_lag_oid = pst_port_entry->port_oid;
    }
    
    ctc_sai_acl_port_en_db_alloc(pst_port_entry->port_oid, acl_port_en_node->dir, acl_lag_oid);

    return SAI_STATUS_SUCCESS;
}

int32_t
_ctc_sai_acl_dis_port_en_db(
_In_  void	*array_data,
_In_  void	*use_data)
{
    ctc_sai_port_entry_t *pst_port_entry = array_data;
    ctc_sai_acl_port_en_t *acl_port_en_info = NULL;
    ctc_sai_acl_en_port_node_t *acl_port_en_node = use_data;

    if ((NULL == pst_port_entry) || (NULL == acl_port_en_node))
    {
        return 0;
    }
    acl_port_en_info = ctc_sai_acl_get_port_en_by_oid(pst_port_entry->port_oid);

    ctc_sai_acl_port_en_db_release(acl_port_en_info, acl_port_en_node->dir);
    return SAI_STATUS_SUCCESS;
}


int32_t
_ctc_sai_acl_set_lag_en_db(
_In_  void	*array_data,
_In_  void	*use_data)
{
    ctc_sai_port_entry_t *pst_port_entry = array_data;
    ctc_sai_acl_en_port_node_t *acl_port_en_node = use_data;

    if ((NULL == pst_port_entry) || (NULL == acl_port_en_node))
    {
        return 0;
    }

    if (acl_port_en_node->port_oid == pst_port_entry->lag_id)
    {
        ctc_sai_acl_port_en_db_alloc(pst_port_entry->port_oid, acl_port_en_node->dir, pst_port_entry->lag_id);
    }

    return SAI_STATUS_SUCCESS;
}

int32_t
_ctc_sai_acl_unset_lag_en_db(
_In_  void	*array_data,
_In_  void	*use_data)
{
    ctc_sai_port_entry_t *pst_port_entry = array_data;
    ctc_sai_acl_en_port_node_t *acl_port_en_node = use_data;
    ctc_sai_acl_port_en_t *acl_port_en_info = NULL;

    if ((NULL == pst_port_entry) || (NULL == acl_port_en_node))
    {
        return 0;
    }

    if (acl_port_en_node->port_oid == pst_port_entry->lag_id)
    {
        acl_port_en_info = ctc_sai_acl_get_port_en_by_oid(pst_port_entry->port_oid);
        ctc_sai_acl_port_en_db_release(acl_port_en_info, acl_port_en_node->dir);
    }

    return SAI_STATUS_SUCCESS;
}


int32_t
ctc_sai_acl_en_lag_port(sai_object_id_t lag_oid, ctc_direction_t dirction)
{
    ctc_sai_acl_en_port_node_t acl_port_en_node;

    acl_port_en_node.port_oid = lag_oid;
    acl_port_en_node.dir = dirction;

    ctc_hash_traverse(g_sai_port_info.port_entry, _ctc_sai_acl_set_lag_en_db, &acl_port_en_node);
    return SAI_STATUS_SUCCESS;
}

int32_t
ctc_sai_acl_dis_lag_port(sai_object_id_t lag_oid, ctc_direction_t dirction)
{
    ctc_sai_acl_en_port_node_t acl_port_en_node;

    acl_port_en_node.port_oid = lag_oid;
    acl_port_en_node.dir = dirction;

    ctc_hash_traverse(g_sai_port_info.port_entry, _ctc_sai_acl_unset_lag_en_db, &acl_port_en_node);
    return SAI_STATUS_SUCCESS;
}


int32_t
ctc_sai_acl_enable_global_port()
{
    ctc_sai_acl_en_port_node_t acl_port_en_node;
    acl_port_en_node.dir = CTC_INGRESS;

    ctc_hash_traverse(g_sai_port_info.port_entry, _ctc_sai_acl_update_port_en_db, &acl_port_en_node);

    return SAI_STATUS_SUCCESS;
}

int32_t
ctc_sai_acl_disable_global_port()
{
    ctc_sai_acl_en_port_node_t acl_port_en_node;
    acl_port_en_node.dir = CTC_INGRESS;

    ctc_hash_traverse(g_sai_port_info.port_entry, _ctc_sai_acl_dis_port_en_db, &acl_port_en_node);

    return SAI_STATUS_SUCCESS;
}

int32_t
_ctc_sai_acl_get_entry_lag_dir(
_In_  void	*array_data,
_In_  void	*use_data)
{
    ctc_sai_acl_entry_t *pst_acl_entry = array_data;
    ctc_sai_acl_en_port_node_t *acl_port_en_node = use_data;

    if ((NULL == pst_acl_entry) || (NULL == acl_port_en_node))
    {
        return 0;
    }

    if (pst_acl_entry->port_oid_list[0] == acl_port_en_node->port_oid
        && pst_acl_entry->dirction == acl_port_en_node->dir)
    {
        acl_port_en_node->entries_cnt++;
        return 1;
    }
    return 0;
}

int32_t
ctc_sai_acl_get_entry_by_oid_dir(sai_object_id_t acl_port_oid, ctc_direction_t dirction)
{
    ctc_sai_acl_en_port_node_t acl_port_en;
    acl_port_en.port_oid = acl_port_oid;
    acl_port_en.dir = dirction;
    acl_port_en.entries_cnt = 0;
    
    ctc_vector_traverse(g_sai_acl_info.pvector[1], _ctc_sai_acl_get_entry_lag_dir, &acl_port_en);

    return acl_port_en.entries_cnt;
}

#endif

int
ctc_sai_acl_worm_filter_init()
{
    ctc_acl_group_info_t acl_group;
    sai_uint32_t group_id = SAI_ACL_WORM_FILTER_GROUP;

    sal_memset(&acl_group, 0, sizeof(acl_group));
    acl_group.type     = CTC_ACL_GROUP_TYPE_GLOBAL;
    acl_group.dir      = CTC_INGRESS;

    ctc_acl_create_group(group_id, &acl_group);
    ctc_acl_install_group(group_id, &acl_group);
    return SAI_STATUS_SUCCESS;

}


int
ctc_sai_acl_copp_group_init()
{
#ifndef DUET2    
    ctc_acl_group_info_t acl_group;
    sai_uint32_t group_id = 0;
    sai_uint32_t port_bitmap = 0; 
#endif
#ifdef DUET2
/*TODO by yejl*/
#endif

#ifdef GOLDENGATE 
    sal_memset(&acl_group, 0, sizeof(acl_group));
    group_id = SAI_ACL_COPP_REASON_GROUP;
    acl_group.type     = CTC_ACL_GROUP_TYPE_PORT_BITMAP;
    acl_group.dir      = CTC_INGRESS;
    acl_group.priority = 2;   /* tcam3, low priority than tcam0 */
    port_bitmap = (1 << SAI_COPP_REASON_PORT_ID);
    acl_group.un.port_bitmap[0] = port_bitmap;

    ctc_acl_create_group(group_id, &acl_group);
    ctc_acl_install_group(group_id, &acl_group);

    sal_memset(&acl_group, 0, sizeof(acl_group));
    group_id = SAI_ACL_COPP_FWD2CPU_GROUP;
    acl_group.type     = CTC_ACL_GROUP_TYPE_PORT_BITMAP;
    acl_group.dir      = CTC_INGRESS;
    acl_group.priority = 2;   /* tcam3, low priority than tcam0 */
    port_bitmap = (1 << SAI_COPP_FWD_PORT_ID);
    acl_group.un.port_bitmap[0] = port_bitmap;

    ctc_acl_create_group(group_id, &acl_group);
    ctc_acl_install_group(group_id, &acl_group);

    sal_memset(&acl_group, 0, sizeof(acl_group));
    group_id = SAI_ACL_COPP_OPENFLOW_TO_CONTROLLER_GROUP;
    acl_group.type     = CTC_ACL_GROUP_TYPE_PORT_BITMAP;
    acl_group.dir      = CTC_INGRESS;
    acl_group.priority = 2;   /* tcam3, low priority than tcam0 */
    port_bitmap = (1 << SAI_COPP_HYBIRD_PORT_ID);
    acl_group.un.port_bitmap[0] = port_bitmap;

    ctc_acl_create_group(group_id, &acl_group);
    ctc_acl_install_group(group_id, &acl_group);

    sal_memset(&acl_group, 0, sizeof(acl_group));
    group_id = SAI_ACL_COPP_ACL_GROUP;
    acl_group.type     = CTC_ACL_GROUP_TYPE_PORT_BITMAP;
    acl_group.dir      = CTC_INGRESS;
    acl_group.priority = 0;   /* tcam0, high priority than tcam2 */
    port_bitmap = (1 << SAI_COPP_REASON_PORT_ID) | (1 << SAI_COPP_FWD_PORT_ID) | (1 << SAI_COPP_HYBIRD_PORT_ID);
    acl_group.un.port_bitmap[0] = port_bitmap;

    ctc_acl_create_group(group_id, &acl_group);
    ctc_acl_install_group(group_id, &acl_group);
    
#elif GREATBELT

    sal_memset(&acl_group, 0, sizeof(acl_group));
    group_id = SAI_ACL_COPP_REASON_GROUP;
    acl_group.type     = CTC_ACL_GROUP_TYPE_PORT_BITMAP;
    acl_group.dir      = CTC_INGRESS;
    acl_group.priority = 1;   /* tcam3, low priority than tcam0 */
    port_bitmap = (1 << SAI_COPP_REASON_PORT_ID);
    acl_group.un.port_bitmap[0] = port_bitmap;

    ctc_acl_create_group(group_id, &acl_group);
    ctc_acl_install_group(group_id, &acl_group);
    
    sal_memset(&acl_group, 0, sizeof(acl_group));
    group_id = SAI_ACL_COPP_FWD2CPU_GROUP;
    acl_group.type     = CTC_ACL_GROUP_TYPE_PORT_BITMAP;
    acl_group.dir      = CTC_INGRESS;
    acl_group.priority = 1;   /* tcam1, low priority than tcam0 */
    port_bitmap = (1 << SAI_COPP_FWD_PORT_ID);
    acl_group.un.port_bitmap[0] = port_bitmap;

    ctc_acl_create_group(group_id, &acl_group);
    ctc_acl_install_group(group_id, &acl_group);

    sal_memset(&acl_group, 0, sizeof(acl_group));
    group_id = SAI_ACL_COPP_OPENFLOW_TO_CONTROLLER_GROUP;
    acl_group.type     = CTC_ACL_GROUP_TYPE_PORT_BITMAP;
    acl_group.dir      = CTC_INGRESS;
    acl_group.priority = 1;   /* tcam1, low priority than tcam0 */
    port_bitmap = (1 << SAI_COPP_HYBIRD_PORT_ID);
    acl_group.un.port_bitmap[0] = port_bitmap;

    ctc_acl_create_group(group_id, &acl_group);
    ctc_acl_install_group(group_id, &acl_group);

    sal_memset(&acl_group, 0, sizeof(acl_group));
    group_id = SAI_ACL_COPP_ACL_GROUP;
    acl_group.type     = CTC_ACL_GROUP_TYPE_PORT_BITMAP;
    acl_group.dir      = CTC_INGRESS;
    acl_group.priority = 0;   /* tcam0, high priority than tcam2 */
    port_bitmap = (1 << SAI_COPP_FWD_PORT_ID);
    acl_group.un.port_bitmap[0] = port_bitmap;

    ctc_acl_create_group(group_id, &acl_group);
    ctc_acl_install_group(group_id, &acl_group);

    ctc_acl_entry_t  acl_entry;

    sal_memset(&acl_entry, 0x0, sizeof(ctc_acl_entry_t));
    acl_entry.key.type = CTC_ACL_KEY_IPV4;
    acl_entry.priority_valid = 1;
    acl_entry.priority = SAI_ACL_COPP_DEFAULT_ACL_PRIORITY;
    acl_entry.entry_id = SAI_ACL_COPP_DEFAULT_ACL_ENTRY_ID;
    ctc_acl_add_entry(group_id, &acl_entry);
    ctc_acl_install_entry(SAI_ACL_COPP_DEFAULT_ACL_ENTRY_ID);
#endif
    return SAI_STATUS_SUCCESS;

}



int
ctc_sai_acl_global_egress_dealut_init()
{
    ctc_acl_group_info_t acl_group;
    ctc_acl_entry_t acl_entry;
    ctc_sai_acl_entry_t *pst_acl_entry = NULL;
    sai_status_t ret = SAI_STATUS_SUCCESS;
    sai_uint32_t ret_ctc = 0;
    sai_uint32_t group_id = 0;
    sai_uint32_t index = 0;

    /*egress default entry*/
    sal_memset(&acl_group, 0, sizeof(acl_group));
    sal_memset(&acl_entry, 0, sizeof(acl_entry));
    acl_group.type     = CTC_ACL_GROUP_TYPE_GLOBAL;
    acl_group.dir      = CTC_EGRESS;
    group_id           = SAI_ACL_GLOBAL_EGRESS_GROUP;

    ctc_acl_create_group(group_id, &acl_group);
    ctc_acl_install_group(group_id, &acl_group);

    ret = ctc_sai_acl_db_alloc_entry(&pst_acl_entry);
    if (NULL == pst_acl_entry)
    {
        return SAI_STATUS_NO_MEMORY;
    }

    /*if the attr changed, this init block_size should be changed too*/
    pst_acl_entry->acl_action_vector = ctc_vector_init(1,SAI_ACL_ENTRY_ATTR_ACTION_END - SAI_ACL_ENTRY_ATTR_ACTION_START + 1);
    if(NULL == pst_acl_entry->acl_action_vector)
    {
        ret = SAI_STATUS_NO_MEMORY;
        return ret;
    }

    CTC_SET_FLAG(acl_entry.action.flag, CTC_ACL_ACTION_FLAG_DISCARD);

    acl_entry.key.type = CTC_ACL_KEY_IPV4;
    acl_entry.key.u.ipv4_key.key_size = CTC_ACL_KEY_SIZE_DOUBLE;
    
    ctc_opf_alloc_offset(&g_sai_acl_info.opf[2], 0, &index);
    pst_acl_entry->ctc_entry_id_list[0] = index;
    pst_acl_entry->ctc_entry_id_cnt = 1;
    pst_acl_entry->dirction = CTC_EGRESS;
    pst_acl_entry->port_oid_list[0] = 0;
    pst_acl_entry->port_oid_cnt = 1;

    acl_entry.entry_id = pst_acl_entry->ctc_entry_id_list[0];
    acl_entry.priority = index;
    acl_entry.priority_valid = TRUE;
    ret_ctc = ctc_acl_add_entry(SAI_ACL_GLOBAL_EGRESS_GROUP, &acl_entry);

    if (CTC_E_NONE != ret_ctc)
    {        
        ret = SAI_STATUS_FAILURE;
    }

    ret_ctc = ctc_acl_install_entry(acl_entry.entry_id);
    if (CTC_E_NONE != ret_ctc)
    {
        ctc_acl_remove_entry(acl_entry.entry_id);          
        ret = SAI_STATUS_FAILURE;
    }

    pst_acl_entry->enable = TRUE;
    ctc_vector_add(g_sai_acl_info.pvector[1], pst_acl_entry->entry_id, pst_acl_entry);
    
    return ret;

}

int
ctc_sai_acl_port_enable(ctc_direction_t dir, sai_object_id_t port)
{
    ctc_acl_group_info_t acl_group;
    ctc_scl_group_info_t scl_group;
    uint32 group_id = 0;
    uint32 gport    = 0;
    uint16 class_id = 0;

    ctc_port_scl_property_t port_scl_property;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_DEBUG("dir = %d, port = 0x%llx", dir, port);
    
    ctc_sai_port_objectid_to_gport(port, &gport);

    group_id = ctc_sai_port_make_acl_group_id(dir, gport);
    ctc_sai_port_objectid_to_classid(port, &class_id);
    
#ifdef GOLDENGATE
#ifndef OFPRODUCT
    if (CTC_INGRESS == dir)
    {
        ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_EN, dir, 0x1);
        /*must config CTC_ACL_TCAM_LKUP_TYPE_L2, acl key is all ipv4 double key*/
        ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_TCAM_LKUP_TYPE_0, dir, CTC_ACL_TCAM_LKUP_TYPE_L2);
    }
    else
    {
#ifndef TAPPRODUCT
        ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_EN, dir, 0x1);
#endif 
    }
#endif    
    ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_CLASSID, dir, class_id);
#endif

    ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_CLASSID, dir, class_id);
    ctc_port_set_direction_property(gport, CTC_PORT_DIR_PROP_ACL_USE_CLASSID, dir, 1);
    

    sal_memset(&acl_group, 0, sizeof(acl_group));
    acl_group.un.port_class_id = class_id;
    acl_group.type     = CTC_ACL_GROUP_TYPE_PORT_CLASS;
    acl_group.lchip    = 0;
    acl_group.priority = 0;
    acl_group.dir      = dir;

    ctc_acl_create_group(group_id, &acl_group);
    ctc_acl_install_group(group_id, &acl_group);

    sal_memset(&port_scl_property, 0, sizeof(port_scl_property));
    port_scl_property.scl_id = 0;
    port_scl_property.direction = CTC_INGRESS;
    port_scl_property.class_id  = class_id;
    port_scl_property.class_id_en = TRUE;
    port_scl_property.tcam_type   = CTC_PORT_IGS_SCL_TCAM_TYPE_IP;
    port_scl_property.hash_type   = CTC_PORT_IGS_SCL_HASH_TYPE_DISABLE;
    port_scl_property.action_type = CTC_PORT_SCL_ACTION_TYPE_FLOW;
    ctc_port_set_scl_property(gport, &port_scl_property);

    sal_memset(&scl_group, 0, sizeof(scl_group));
    scl_group.un.port_class_id = class_id;
    scl_group.type     = CTC_SCL_GROUP_TYPE_PORT_CLASS;
    scl_group.lchip    = 0;
    scl_group.priority = 0;

    ctc_scl_create_group(group_id, &scl_group);
    ctc_scl_install_group(group_id, &scl_group);
    
    return SAI_STATUS_SUCCESS;
}



int
ctc_sai_acl_lag_install(ctc_direction_t dir, sai_object_id_t lag_id)
{
    ctc_acl_group_info_t acl_group;
    ctc_scl_group_info_t scl_group;
    uint32 group_id = 0;
    uint32 gport    = 0;
    uint16 class_id = 0;

    ctc_port_scl_property_t port_scl_property;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_DEBUG("dir = %d, port = 0x%llx", dir, lag_id);

    ctc_sai_port_objectid_to_gport(lag_id, &gport);
    
    group_id = ctc_sai_port_make_acl_group_id(dir, gport);
    ctc_sai_port_objectid_to_classid(lag_id, &class_id);
    
    sal_memset(&acl_group, 0, sizeof(acl_group));
    acl_group.un.port_class_id = class_id;
    acl_group.type     = CTC_ACL_GROUP_TYPE_PORT_CLASS;
    acl_group.lchip    = 0;
    acl_group.priority = 0;
    acl_group.dir      = dir;

    ctc_acl_create_group(group_id, &acl_group);
    ctc_acl_install_group(group_id, &acl_group);

    sal_memset(&port_scl_property, 0, sizeof(port_scl_property));
    port_scl_property.scl_id = 0;
    port_scl_property.direction = CTC_INGRESS;
    port_scl_property.class_id  = class_id;
    port_scl_property.class_id_en = TRUE;
    port_scl_property.tcam_type   = CTC_PORT_IGS_SCL_TCAM_TYPE_IP;
    port_scl_property.hash_type   = CTC_PORT_IGS_SCL_HASH_TYPE_DISABLE;
    port_scl_property.action_type = CTC_PORT_SCL_ACTION_TYPE_FLOW;
    ctc_port_set_scl_property(gport, &port_scl_property);

    sal_memset(&scl_group, 0, sizeof(scl_group));
    scl_group.un.port_class_id = class_id;
    scl_group.type     = CTC_SCL_GROUP_TYPE_PORT_CLASS;
    scl_group.lchip    = 0;
    scl_group.priority = 0;

    ctc_scl_create_group(group_id, &scl_group);
    ctc_scl_install_group(group_id, &scl_group);
    
    return SAI_STATUS_SUCCESS;
}

int
ctc_sai_acl_lag_member_enable(sai_object_id_t lag_id, sai_object_id_t lag_member_port_id)
{
    uint32 lag_member_gport = 0;
    uint16 class_id  = 0;
    uint32 lag_gport = 0;
#ifdef GREATBELT
    uint32 entres_cnt = 0;
    uint32 i = 0;
#endif
    ctc_port_scl_property_t port_scl_property;

    ctc_sai_port_objectid_to_gport(lag_id, &lag_gport);
    ctc_sai_port_objectid_to_gport(lag_member_port_id, &lag_member_gport);

    ctc_sai_port_objectid_to_classid(lag_id, &class_id);

#ifdef GREATBELT
    entres_cnt = ctc_sai_acl_get_entry_by_oid_dir(lag_id, CTC_INGRESS);
    for (i = 0; i < entres_cnt ; i++)
    {
        ctc_sai_acl_port_en_db_alloc(lag_member_port_id, CTC_INGRESS, lag_id);
    }
    entres_cnt = ctc_sai_acl_get_entry_by_oid_dir(lag_id, CTC_EGRESS);
    for (i = 0; i < entres_cnt ; i++)
    {
        ctc_sai_acl_port_en_db_alloc(lag_member_port_id, CTC_EGRESS, lag_id);
    }
#endif
    
    ctc_port_set_direction_property(lag_member_gport, CTC_PORT_DIR_PROP_ACL_CLASSID, CTC_INGRESS, class_id);

    ctc_port_set_direction_property(lag_member_gport, CTC_PORT_DIR_PROP_ACL_CLASSID, CTC_EGRESS, class_id);

    sal_memset(&port_scl_property, 0, sizeof(port_scl_property));
    port_scl_property.scl_id = 0;
    port_scl_property.direction = CTC_INGRESS;
    ctc_port_get_scl_property(lag_member_gport, &port_scl_property);

    port_scl_property.class_id = class_id;
    ctc_port_set_scl_property(lag_member_gport, &port_scl_property);


    return SAI_STATUS_SUCCESS;
}

int
ctc_sai_acl_lag_member_disable(sai_object_id_t lag_member_port_id, sai_object_id_t lag_id)
{
    uint32 lag_member_gport = 0;
    uint16 class_id  = 0;
    
#ifdef GREATBELT
    ctc_sai_acl_port_en_t lag_acl_en_node;
    uint32 entres_cnt = 0;
    uint32 i = 0;
#endif
    ctc_port_scl_property_t port_scl_property;

    ctc_sai_port_objectid_to_gport(lag_member_port_id, &lag_member_gport);

    ctc_sai_port_objectid_to_classid(lag_member_port_id, &class_id);
    ctc_port_set_direction_property(lag_member_gport, CTC_PORT_DIR_PROP_ACL_CLASSID, CTC_INGRESS, class_id);

    ctc_port_set_direction_property(lag_member_gport, CTC_PORT_DIR_PROP_ACL_CLASSID, CTC_EGRESS, class_id);

    sal_memset(&port_scl_property, 0, sizeof(port_scl_property));
    port_scl_property.scl_id = 0;
    port_scl_property.direction = CTC_INGRESS;
    ctc_port_get_scl_property(lag_member_gport, &port_scl_property);

    port_scl_property.class_id = class_id;
    ctc_port_set_scl_property(lag_member_gport, &port_scl_property);

#ifdef GREATBELT    
    lag_acl_en_node.acl_port_oid = lag_member_port_id;
    entres_cnt = ctc_sai_acl_get_entry_by_oid_dir(lag_id, CTC_INGRESS);
    for (i = 0; i < entres_cnt ; i++)
    {
        ctc_sai_acl_port_en_db_release(&lag_acl_en_node, CTC_INGRESS);
    }
    entres_cnt = ctc_sai_acl_get_entry_by_oid_dir(lag_id, CTC_EGRESS);
    for (i = 0; i < entres_cnt ; i++)
    {
        ctc_sai_acl_port_en_db_release(&lag_acl_en_node, CTC_EGRESS);
    }
    
#endif

    return SAI_STATUS_SUCCESS;
}




#define ________SAI_ACL_SAI_DEBUG_FUNC
sai_status_t
sai_create_acl_entry_debug_param(
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    const sai_attribute_t *pattr_entry = NULL;
    uint32 i = 0;
    sai_object_id_t     table_id = 0;
    ctc_sai_acl_table_t *pst_acl_table = NULL;

    for (i = 0; i < attr_count; i++)
    {
        pattr_entry = &attr_list[i];
        switch (pattr_entry->id)
        {
        case SAI_ACL_ENTRY_ATTR_TABLE_ID:
            table_id = pattr_entry->value.oid;
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_TABLE_ID 0x%llx", pattr_entry->value.oid);
            break;
        case SAI_ACL_ENTRY_ATTR_PRIORITY:
            pst_acl_table = ctc_sai_acl_db_get_table_by_oid(table_id);
            if (NULL == pst_acl_table)
            {
                CTC_SAI_DEBUG("in:sai_create_acl_entry_debug_param invalid table_id");
            }
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_PRIORITY %"PRIu64, ((pattr_entry->value.u32) & 0xffff) + (((pst_acl_table->priority) & 0xffff) << 16));
            break;
        case SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT:
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT 0x%llx", pattr_entry->value.aclfield.data.oid);
            break;

        case SAI_ACL_ENTRY_ATTR_FIELD_OUT_PORT:
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_OUT_PORT 0x%llx", pattr_entry->value.aclfield.data.oid);
            break;

        case SAI_ACL_ENTRY_ATTR_FIELD_SRC_MAC:
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_SRC_MAC %x:%x:%x:%x:%x:%x", 
                pattr_entry->value.aclfield.data.mac[5], pattr_entry->value.aclfield.data.mac[4], pattr_entry->value.aclfield.data.mac[3],
                pattr_entry->value.aclfield.data.mac[2], pattr_entry->value.aclfield.data.mac[1], pattr_entry->value.aclfield.data.mac[0]);
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_SRC_MAC_MASK %x:%x:%x:%x:%x:%x", 
                pattr_entry->value.aclfield.mask.mac[5], pattr_entry->value.aclfield.mask.mac[4], pattr_entry->value.aclfield.mask.mac[3],
                pattr_entry->value.aclfield.mask.mac[2], pattr_entry->value.aclfield.mask.mac[1], pattr_entry->value.aclfield.mask.mac[0]);
            break;

        case SAI_ACL_ENTRY_ATTR_FIELD_DST_MAC:
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_DST_MAC %x:%x:%x:%x:%x:%x", 
                pattr_entry->value.aclfield.data.mac[5], pattr_entry->value.aclfield.data.mac[4], pattr_entry->value.aclfield.data.mac[3],
                pattr_entry->value.aclfield.data.mac[2], pattr_entry->value.aclfield.data.mac[1], pattr_entry->value.aclfield.data.mac[0]);
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_DST_MAC_MASK %x:%x:%x:%x:%x:%x", 
                pattr_entry->value.aclfield.mask.mac[5], pattr_entry->value.aclfield.mask.mac[4], pattr_entry->value.aclfield.mask.mac[3],
                pattr_entry->value.aclfield.mask.mac[2], pattr_entry->value.aclfield.mask.mac[1], pattr_entry->value.aclfield.mask.mac[0]);
            break;
        case SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_ID:
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_ID %u", pattr_entry->value.aclfield.data.u16);
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_ID_MAK %u", pattr_entry->value.aclfield.mask.u16);
            break;

        case SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_PRI:
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_PRI %u", pattr_entry->value.aclfield.data.u8);
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_PRI_MASK %u", pattr_entry->value.aclfield.mask.u8);
            break;

        case SAI_ACL_ENTRY_ATTR_FIELD_INNER_VLAN_ID:
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_INNER_VLAN_ID %u", pattr_entry->value.aclfield.data.u16);
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_INNER_VLAN_ID_MASK %u", pattr_entry->value.aclfield.mask.u16);
            break;

        case SAI_ACL_ENTRY_ATTR_FIELD_INNER_VLAN_PRI:
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_INNER_VLAN_PRI %u", pattr_entry->value.aclfield.data.u8);
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_INNER_VLAN_PRI_MASK %u", pattr_entry->value.aclfield.mask.u8);
            break;

        case SAI_ACL_ENTRY_ATTR_FIELD_ETHER_TYPE:
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_ETHER_TYPE %u", pattr_entry->value.aclfield.data.u16);
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_ETHER_TYPE_MASK %u", pattr_entry->value.aclfield.mask.u16);
            break;

        case SAI_ACL_ENTRY_ATTR_FIELD_SRC_IP:
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_SRC_IP %u", pattr_entry->value.aclfield.data.ip4);
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_SRC_IP_MASK %u", pattr_entry->value.aclfield.mask.ip4);
            break;

        case SAI_ACL_ENTRY_ATTR_FIELD_DST_IP:
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_DST_IP %u", pattr_entry->value.aclfield.data.ip4);
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_DST_IP_MASK %u", pattr_entry->value.aclfield.mask.ip4);
            break;

        case SAI_ACL_ENTRY_ATTR_FIELD_IP_PROTOCOL:
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_IP_PROTOCOL %u", pattr_entry->value.aclfield.data.u8);
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_IP_PROTOCOL_MASK %u", pattr_entry->value.aclfield.mask.u8);
            break;

        case SAI_ACL_ENTRY_ATTR_FIELD_L4_SRC_PORT:
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_L4_SRC_PORT %u", pattr_entry->value.aclfield.data.u16);
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_L4_SRC_PORT_MASK %u", pattr_entry->value.aclfield.mask.u16);
            break;

        case SAI_ACL_ENTRY_ATTR_FIELD_L4_DST_PORT:
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_L4_DST_PORT %u", pattr_entry->value.aclfield.data.u16);
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_L4_DST_PORT_MASK %u", pattr_entry->value.aclfield.mask.u16);
            break;

        case SAI_ACL_ENTRY_ATTR_FIELD_UDF_MATCH:
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_UDF %u", pattr_entry->value.aclfield.data.u32);
            CTC_SAI_DEBUG("in:SAI_ACL_ENTRY_ATTR_FIELD_UDF_MASK %u", pattr_entry->value.aclfield.mask.u32);
            break;

        case SAI_ACL_ENTRY_ATTR_FIELD_IN_PORTS:
        case SAI_ACL_ENTRY_ATTR_FIELD_OUT_PORTS:
            /*unsupport*/
            break;

        case SAI_ACL_ENTRY_ATTR_PACKET_ACTION:
            if (pattr_entry->value.aclaction.enable)
            {
                switch(pattr_entry->value.aclaction.parameter.s32)
                {
                    case SAI_PACKET_ACTION_DROP:
                        CTC_SAI_DEBUG("in:SAI_PACKET_ACTION_DROP");
                        break;

                    case SAI_PACKET_ACTION_FORWARD:
                        CTC_SAI_DEBUG("in:SAI_PACKET_ACTION_FORWARD");
                        break;

                    case SAI_PACKET_ACTION_TRAP:
                        CTC_SAI_DEBUG("in:SAI_PACKET_ACTION_TRAP");
                        break;

                    case SAI_PACKET_ACTION_LOG:
                        CTC_SAI_DEBUG("in:SAI_PACKET_ACTION_DROP");
                        break;

                    default:
                        break;            
                }
            }
            break;

        case SAI_ACL_ENTRY_ATTR_ACTION_COUNTER:
            if (pattr_entry->value.aclaction.enable)
            {
                CTC_SAI_DEBUG("in:CTC_ACL_ACTION_FLAG_STATS");
            }
            break;

        case SAI_ACL_ENTRY_ATTR_ACTION_SET_TC:
            if (pattr_entry->value.aclaction.enable)
            {
                CTC_SAI_DEBUG("in:CTC_ACL_ACTION_FLAG_PRIORITY");
            }
            break;
         default:
            break;
        }
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t  sai_get_acl_entry_attribute_debug_param (
    _In_ uint32_t attr_count,
    _Out_ sai_attribute_t *attr_list)
{
    uint32_t                    attr_idx = 0;
    const sai_attribute_t *pattr_entry = NULL;

    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        pattr_entry = &attr_list[attr_idx];

        switch (pattr_entry->id)
        {
        case SAI_ACL_ENTRY_ATTR_ADMIN_STATE:
            CTC_SAI_DEBUG("out:SAI_ACL_ENTRY_ATTR_ADMIN_STATE %u", pattr_entry->value.booldata);
            break;
        case SAI_ACL_ENTRY_ATTR_PRIORITY:
            CTC_SAI_DEBUG("out:SAI_ACL_ENTRY_ATTR_PRIORITY %u", pattr_entry->value.u32);
            break;
         default:
            break;
        }
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_get_acl_counter_attribute_debug_param(
    _In_ sai_object_id_t acl_counter_id,
    _In_ uint32_t attr_count,
    _Out_ sai_attribute_t *attr_list)
{
    uint32_t                    attr_idx = 0;
    const sai_attribute_t *pattr_entry = NULL;

    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        pattr_entry = &attr_list[attr_idx];

        switch (pattr_entry->id)
        {

        case SAI_ACL_COUNTER_ATTR_TABLE_ID:
        case SAI_ACL_COUNTER_ATTR_ENABLE_PACKET_COUNT:
        case SAI_ACL_COUNTER_ATTR_ENABLE_BYTE_COUNT:
            break;

        case SAI_ACL_COUNTER_ATTR_PACKETS:
            CTC_SAI_DEBUG("out:SAI_ACL_COUNTER_ATTR_PACKETS %"PRIu64, pattr_entry->value.u64);
            break;
        case SAI_ACL_COUNTER_ATTR_BYTES:
            CTC_SAI_DEBUG("out:SAI_ACL_COUNTER_ATTR_BYTES %"PRIu64, pattr_entry->value.u64);
            break;
         default:
            break;
        }
    }

    return SAI_STATUS_SUCCESS;
}
#define ________SAI_ACL_SAI_API_FUNC
/*
* Routine Description:
*   Create an ACL table
*
* Arguments:
 *  [out] acl_table_id - the the acl table id
 *  [in] attr_count - number of attributes
 *  [in] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_create_acl_table(
    _Out_ sai_object_id_t* acl_table_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_attribute_t const *pattr_entry = NULL;
    ctc_sai_acl_table_t         *pacl_table = NULL;
    uint32_t index = 0;

    CTC_SAI_DEBUG_FUNC();
    
    CTC_SAI_PTR_VALID_CHECK(acl_table_id);
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    ret = ctc_sai_acl_db_alloc_table(&pacl_table);
    if(NULL == pacl_table)
    {
        return SAI_STATUS_NO_MEMORY;
    }

    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_ACL_TABLE_ATTR_STAGE, attr_list, attr_count, &index);
    if (NULL != pattr_entry)
    {
        pacl_table->stage = pattr_entry->value.s32;
    }


    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_ACL_TABLE_ATTR_PRIORITY, attr_list, attr_count, &index);
    if (pattr_entry)
    {
        pacl_table->priority = pattr_entry->value.u32;
    }


    for (index = 0; index < attr_count; index++)
    {
        if ((SAI_ACL_TABLE_ATTR_FIELD_START <= attr_list[index].id) && (SAI_ACL_TABLE_ATTR_FIELD_END >= attr_list[index].id))
        {
            if (
                (SAI_ACL_TABLE_ATTR_FIELD_TTL == attr_list[index].id) ||
                (SAI_ACL_TABLE_ATTR_FIELD_TOS == attr_list[index].id) ||
                (SAI_ACL_TABLE_ATTR_FIELD_IP_FLAGS == attr_list[index].id) ||
                (SAI_ACL_TABLE_ATTR_FIELD_OUTER_VLAN_PRI == attr_list[index].id) ||
                (SAI_ACL_TABLE_ATTR_FIELD_INNER_VLAN_PRI == attr_list[index].id))
            {
                ctc_sai_acl_db_release_table(pacl_table);
                return SAI_STATUS_NOT_SUPPORTED;
            }

            if (attr_list[index].value.booldata)
            {
                pacl_table->field_bitmap |= (1 << (attr_list[index].id - SAI_ACL_TABLE_ATTR_FIELD_START));
            }
        }
    }

    /* pass at least one field */
    if (0 == pacl_table->field_bitmap)
    {
        ctc_sai_acl_db_release_table(pacl_table);
        return SAI_STATUS_INVALID_PARAMETER;
    }

    if(FALSE == ctc_vector_add(g_sai_acl_info.pvector[0],
                CTC_SAI_OBJECT_INDEX_GET(pacl_table->table_id),
                pacl_table))
    {
        ctc_sai_acl_db_release_table(pacl_table);
        return SAI_STATUS_FAILURE;
    }

    *acl_table_id = pacl_table->table_id;

    return ret;

}

/*
* Routine Description:
*   Delete an ACL table
*
* Arguments:
*   [in] acl_table_id - the acl table id
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_delete_acl_table(
    _In_ sai_object_id_t acl_table_id)
{
    sai_status_t                ret = SAI_STATUS_SUCCESS;
    ctc_sai_acl_table_t         *pacl_table = NULL;

    CTC_SAI_DEBUG_FUNC();

    pacl_table = ctc_sai_acl_db_get_table_by_oid_no_ref(acl_table_id);
    if(NULL == pacl_table)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    ctc_vector_del(g_sai_acl_info.pvector[0],
                CTC_SAI_OBJECT_INDEX_GET(pacl_table->table_id));

    ctc_sai_acl_db_release_table(pacl_table);

    return ret;
}

/*
* Routine Description:
*   Set ACL table attribute
*
* Arguments:
*    [in] acl_table_id - the acl table id
*    [in] attr - attribute
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t  sai_set_acl_table_attribute(
    _In_ sai_object_id_t acl_table_id,
    _In_ const sai_attribute_t *attr)
{

    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_PTR_VALID_CHECK(attr);

    return SAI_STATUS_INVALID_ATTRIBUTE_0;
}

/*
* Routine Description:
*   Get ACL table attribute
*
* Arguments:
*    [in] acl_table_id - acl table id
*    [in] attr_count - number of attributes
*    [Out] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_get_acl_table_attribute(
    _In_ sai_object_id_t acl_table_id,
    _In_ uint32_t attr_count,
    _Out_ sai_attribute_t *attr_list)
{
    sai_status_t     ret         = SAI_STATUS_SUCCESS;
    sai_attribute_t *attr        = NULL;
    uint32_t         attr_idx    = 0;
    ctc_sai_acl_table_t         *pacl_table = NULL;

    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_PTR_VALID_CHECK(attr_list);

    pacl_table = ctc_sai_acl_db_get_table_by_oid(acl_table_id);
    if(NULL == pacl_table)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
    /*
        ret = ctc_sai_attr_check_read_attr(g_sai_acl_attr_tables,attr);

        if(ret != SAI_STATUS_SUCCESS)
        {
            return ret + attr_idx;
        }
    */
        if (SAI_ACL_TABLE_ATTR_STAGE == attr->id)
        {
            attr->value.s32 = pacl_table->stage;
        }
        else if (SAI_ACL_TABLE_ATTR_PRIORITY == attr->id)
        {
            attr->value.u32 = pacl_table->priority;
        }
        else if ((SAI_ACL_TABLE_ATTR_FIELD_START <= attr->id) && (SAI_ACL_TABLE_ATTR_FIELD_END >= attr->id))
        {
            attr->value.booldata = CTC_IS_BIT_SET(pacl_table->field_bitmap, attr->id - SAI_ACL_TABLE_ATTR_FIELD_START);
        }
    }

    return ret;
}

static int32_t
__config_strip_header(
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    enum{
        PACKET_UNKONW = 0,
        PACKET_VXLAN,
        PACKET_IPV4_GRE,
        PACKET_MAX,
    };

    int32_t packet_type = PACKET_UNKONW;
    uint8_t l4_protocol = 0;
    uint16_t l4_dst_port = 0;
#if 0    
    uint32_t vni_mask = 0;
    uint32_t gre_mask = 0;
#endif

#if 0
    if(pst_acl_entry->strip_header == 0 &&
       pst_acl_entry->l4_vxlan_vni_en == 0){
        return 0;
    }
#endif
    l4_protocol = 
        psai_acl_entry->outer_fileds.ipv4_ip_protocol.data.u8 & 
        ~(psai_acl_entry->outer_fileds.ipv4_ip_protocol.mask.u8);

    /* dst_port eq mode, list dst-port eq 4789,so data == mask == 4789 */
    l4_dst_port = 
        psai_acl_entry->outer_fileds.ipv4_dst_port.data.u16 & 
        psai_acl_entry->outer_fileds.ipv4_dst_port.mask.u16;

    /* check parameters */
    if(L4_PROTOCOL_UDP == l4_protocol && L4_PROTOCOL_GRE_DEST_PORT == l4_dst_port)
    {
#ifdef GOLDENGATE     
        packet_type = PACKET_VXLAN;
#endif
    }else if(L4_PROTOCOL_GRE == l4_protocol){
#ifdef GOLDENGATE      
        packet_type = PACKET_IPV4_GRE;
#endif
    }

    /* set strip-header */
    switch(packet_type){
    case PACKET_VXLAN:
        if(res->mapping_type == FIELD_ACL_ENTRY_TYPE){
            if(psai_acl_entry->strip_header){
                res->u.ctc_acl_entry.action.packet_strip.start_packet_strip  = CTC_ACL_STRIP_START_TO_L4;
                res->u.ctc_acl_entry.action.packet_strip.packet_type         = PKT_TYPE_ETH;
                res->u.ctc_acl_entry.action.packet_strip.strip_extra_len     = 16;

                /* TODO DIY strip offset */
                if(psai_acl_entry->action.strip_header_pos.enable){
                    switch(psai_acl_entry->action.strip_header_pos.parameter.u32){
                    case SAI_ACL_STRIP_HEADER_POS_L2:
                        res->u.ctc_acl_entry.action.packet_strip.start_packet_strip  = CTC_ACL_STRIP_START_TO_L2;
                        break;
                    case SAI_ACL_STRIP_HEADER_POS_L3:
                        res->u.ctc_acl_entry.action.packet_strip.start_packet_strip  = CTC_ACL_STRIP_START_TO_L3;
                        break;
                    default:
                        break;
                    }
                }

                if(psai_acl_entry->action.strip_header_offset.enable){
                    res->u.ctc_acl_entry.action.packet_strip.strip_extra_len  = 
                        psai_acl_entry->action.strip_header_offset.parameter.u32;
                }
            }
        }
        break;

    case PACKET_IPV4_GRE:
        if(res->mapping_type == FIELD_ACL_ENTRY_TYPE){
            if(psai_acl_entry->strip_header){
                res->u.ctc_acl_entry.action.packet_strip.start_packet_strip  = CTC_ACL_STRIP_START_TO_L4;
                res->u.ctc_acl_entry.action.packet_strip.packet_type         = PKT_TYPE_ETH;

                res->u.ctc_acl_entry.action.packet_strip.strip_extra_len     = 4;

                if(SAI_ACL_GRE_NVGRE == 
                    psai_acl_entry->outer_fileds.gre_type.data.u32){
                    /* nvgre allows has gre-key */
                    res->u.ctc_acl_entry.action.packet_strip.strip_extra_len += 4;      
                }else{
                    /* if gre has gre-key */
                    if(psai_acl_entry->outer_fileds.gre_key.enable){
                        res->u.ctc_acl_entry.action.packet_strip.strip_extra_len  += 4;
                    }
                }
                /* TODO DIY strip offset */
                if(psai_acl_entry->action.strip_header_pos.enable){
                    switch(psai_acl_entry->action.strip_header_pos.parameter.u32){
                    case SAI_ACL_STRIP_HEADER_POS_L2:
                        res->u.ctc_acl_entry.action.packet_strip.start_packet_strip  = CTC_ACL_STRIP_START_TO_L2;
                        break;
                    case SAI_ACL_STRIP_HEADER_POS_L3:
                        res->u.ctc_acl_entry.action.packet_strip.start_packet_strip  = CTC_ACL_STRIP_START_TO_L3;
                        break;
                    default:
                        break;
                    }
                }

                if(psai_acl_entry->action.strip_header_offset.enable){
                    res->u.ctc_acl_entry.action.packet_strip.strip_extra_len  = 
                        psai_acl_entry->action.strip_header_offset.parameter.u32;
                }
            } 
        }
    default:
        goto out;
        break;
    }

    return 0;

out:
    return 0;
}

static int32_t 
__check_tunnel_header_valid_and_config(
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    enum{
        PACKET_UNKONW = 0,
        PACKET_VXLAN,
        PACKET_IPV4_GRE,
        PACKET_MAX,
    };

    int32_t packet_type = PACKET_UNKONW;
    uint8_t l4_protocol = 0;
    uint16_t l4_dst_port = 0;
    uint32_t vni_mask = 0;
    uint32_t gre_mask = 0;
#if 0    
    if(pst_acl_entry->strip_header == 0 &&
       pst_acl_entry->l4_vxlan_vni_en == 0){
        return 0;
    }
#endif
    l4_protocol = 
        psai_acl_entry->outer_fileds.ipv4_ip_protocol.data.u8 & 
        ~(psai_acl_entry->outer_fileds.ipv4_ip_protocol.mask.u8);

    /* dst_port eq mode, list dst-port eq 4789,so data == mask == 4789 */
    l4_dst_port = 
        psai_acl_entry->outer_fileds.ipv4_dst_port.data.u16 & 
        psai_acl_entry->outer_fileds.ipv4_dst_port.mask.u16;

    /* check parameters */
    if(L4_PROTOCOL_UDP == l4_protocol && L4_PROTOCOL_GRE_DEST_PORT == l4_dst_port)
    {
#ifdef GOLDENGATE     
        packet_type = PACKET_VXLAN;
#endif
    }else if(L4_PROTOCOL_GRE == l4_protocol){
#ifdef GOLDENGATE      
        packet_type = PACKET_IPV4_GRE;
#endif
    }

    /* set strip-header */
    switch(packet_type){
    case PACKET_VXLAN:
        if(res->mapping_type == FIELD_ACL_ENTRY_TYPE){
#if 0            
            if(psai_acl_entry->strip_header){
                res->u.ctc_acl_entry.action.packet_strip.start_packet_strip  = CTC_ACL_STRIP_START_TO_L4;
                res->u.ctc_acl_entry.action.packet_strip.packet_type         = PKT_TYPE_ETH;
                res->u.ctc_acl_entry.action.packet_strip.strip_extra_len     = 16;

                /* TODO DIY strip offset */
                if(psai_acl_entry->action.strip_header_pos.enable){
                    switch(psai_acl_entry->action.strip_header_pos.parameter.u32){
                    case SAI_ACL_STRIP_HEADER_POS_L2:
                        res->u.ctc_acl_entry.action.packet_strip.start_packet_strip  = CTC_ACL_STRIP_START_TO_L2;
                        break;
                    case SAI_ACL_STRIP_HEADER_POS_L3:
                        res->u.ctc_acl_entry.action.packet_strip.start_packet_strip  = CTC_ACL_STRIP_START_TO_L3;
                        break;
                    default:
                        break;
                    }
                }

                if(psai_acl_entry->action.strip_header_offset.enable){
                    res->u.ctc_acl_entry.action.packet_strip.strip_extra_len  = 
                        psai_acl_entry->action.strip_header_offset.parameter.u32;
                }
            }
#endif            
            res->acl_key.sub_flag &= ~(CTC_ACL_IPV4_KEY_SUB_FLAG_L4_SRC_PORT);
            res->acl_key.sub_flag &= ~(CTC_ACL_IPV4_KEY_SUB_FLAG_L4_DST_PORT);

            res->acl_key.sub_flag |= CTC_ACL_IPV4_KEY_SUB_FLAG_VNI;

            if(psai_acl_entry->l4_vxlan_vni_en){
                vni_mask = (~psai_acl_entry->l4_vxlan_vni_mask) & 0xFFFFFF;      /* 24-bit */
                
                res->acl_key.vni      = psai_acl_entry->l4_vxlan_vni;
                res->acl_key.vni_mask = vni_mask;
            }else{
                res->acl_key.vni      = 0;
                res->acl_key.vni_mask = 0;
            } 
        }else{
            /* TODO DIY strip offset */
#if 0            
            CTC_SET_FLAG(res->scl.action.u.flow_action.flag, CTC_SCL_FLOW_ACTION_FLAG_STRIP_PACKET);
            res->scl.action.u.flow_action.strip_packet.start_packet_strip = CTC_SCL_STRIP_START_TO_L4;
            res->scl.action.u.flow_action.strip_packet.strip_extra_len    = 16 >> 1;    /* IpeSclFlowCtl.removeByteShift = 1 */
            res->scl.action.u.flow_action.strip_packet.packet_type        = PKT_TYPE_ETH;

            /* TODO DIY strip offset */
            if(psai_acl_entry->action.strip_header_pos.enable){
                switch(psai_acl_entry->action.strip_header_pos.parameter.u32){
                case SAI_ACL_STRIP_HEADER_POS_L2:
                    res->scl.action.u.flow_action.strip_packet.start_packet_strip  = CTC_SCL_STRIP_START_TO_L2;
                    break;
                case SAI_ACL_STRIP_HEADER_POS_L3:
                    res->scl.action.u.flow_action.strip_packet.start_packet_strip  = CTC_SCL_STRIP_START_TO_L3;
                    break;
                default:
                    break;
                }
            }

            if(psai_acl_entry->action.strip_header_offset.enable){
                res->scl.action.u.flow_action.strip_packet.strip_extra_len  = 
                    psai_acl_entry->action.strip_header_offset.parameter.u32 >> 1;
            }
#endif
            CTC_SET_FLAG(res->scl.action.u.flow_action.flag, CTC_SCL_FLOW_ACTION_FLAG_ACLQOS_USE_OUTER_LOOKUP);
            res->scl.action.u.flow_action.aclqos_outer_lookup = 0;

            res->scl.key.u.tcam_ipv4_key.sub_flag &= ~(CTC_SCL_TCAM_IPV4_KEY_SUB_FLAG_L4_SRC_PORT);
            res->scl.key.u.tcam_ipv4_key.sub_flag &= ~(CTC_SCL_TCAM_IPV4_KEY_SUB_FLAG_L4_DST_PORT);

            res->scl.key.u.tcam_ipv4_key.sub_flag |= CTC_SCL_TCAM_IPV4_KEY_SUB_FLAG_VNI;

            if(psai_acl_entry->l4_vxlan_vni_en){
                vni_mask = (~psai_acl_entry->l4_vxlan_vni_mask) & 0xFFFFFF;      /* 24-bit */
                
                res->scl.key.u.tcam_ipv4_key.vni      = psai_acl_entry->l4_vxlan_vni;
                res->scl.key.u.tcam_ipv4_key.vni_mask = vni_mask;
            }else{
                res->scl.key.u.tcam_ipv4_key.vni      = 0;
                res->scl.key.u.tcam_ipv4_key.vni_mask = 0;
            } 
        }
        break;

    case PACKET_IPV4_GRE:
        if(res->mapping_type == FIELD_ACL_ENTRY_TYPE){
#if 0            
            if(psai_acl_entry->strip_header){
                res->u.ctc_acl_entry.action.packet_strip.start_packet_strip  = CTC_ACL_STRIP_START_TO_L4;
                res->u.ctc_acl_entry.action.packet_strip.packet_type         = PKT_TYPE_ETH;

                res->u.ctc_acl_entry.action.packet_strip.strip_extra_len     = 4;

                if(SAI_ACL_GRE_NVGRE == 
                    psai_acl_entry->outer_fileds.gre_type.data.u32){
                    /* nvgre allows has gre-key */
                    res->u.ctc_acl_entry.action.packet_strip.strip_extra_len += 4;      
                }else{
                    /* if gre has gre-key */
                    if(psai_acl_entry->outer_fileds.gre_key.enable){
                        res->u.ctc_acl_entry.action.packet_strip.strip_extra_len  += 4;
                    }
                }
                /* TODO DIY strip offset */
                if(psai_acl_entry->action.strip_header_pos.enable){
                    switch(psai_acl_entry->action.strip_header_pos.parameter.u32){
                    case SAI_ACL_STRIP_HEADER_POS_L2:
                        res->u.ctc_acl_entry.action.packet_strip.start_packet_strip  = CTC_ACL_STRIP_START_TO_L2;
                        break;
                    case SAI_ACL_STRIP_HEADER_POS_L3:
                        res->u.ctc_acl_entry.action.packet_strip.start_packet_strip  = CTC_ACL_STRIP_START_TO_L3;
                        break;
                    default:
                        break;
                    }
                }

                if(psai_acl_entry->action.strip_header_offset.enable){
                    res->u.ctc_acl_entry.action.packet_strip.strip_extra_len  = 
                        psai_acl_entry->action.strip_header_offset.parameter.u32;
                }
            }
#endif
            res->acl_key.flag |= CTC_ACL_IPV4_KEY_FLAG_L4_PROTOCOL;

            if(SAI_ACL_GRE_NVGRE == psai_acl_entry->outer_fileds.gre_type.data.u32){
                res->acl_key.sub_flag |= CTC_ACL_IPV4_KEY_SUB_FLAG_NVGRE_KEY;
            }else{
                res->acl_key.sub_flag |= CTC_ACL_IPV4_KEY_SUB_FLAG_GRE_KEY;
            }

            if(psai_acl_entry->outer_fileds.gre_key.enable){               
                gre_mask = (~(psai_acl_entry->outer_fileds.gre_key.mask.u32)) & 0xFFFFFFFF;
                res->acl_key.gre_key = psai_acl_entry->outer_fileds.gre_key.data.u32;
                res->acl_key.gre_key_mask = gre_mask;
            }
        }else{
            /* TODO DIY strip offset */
#if 0
            CTC_SET_FLAG(res->scl.action.u.flow_action.flag, CTC_SCL_FLOW_ACTION_FLAG_STRIP_PACKET);
            res->scl.action.u.flow_action.strip_packet.start_packet_strip = CTC_ACL_STRIP_START_TO_L4;
            res->scl.action.u.flow_action.strip_packet.packet_type        = PKT_TYPE_ETH;

            res->scl.action.u.flow_action.strip_packet.strip_extra_len     = 4;

            if(SAI_ACL_GRE_NVGRE == 
                psai_acl_entry->outer_fileds.gre_type.data.u32){
                /* nvgre allows has gre-key */
                res->scl.action.u.flow_action.strip_packet.strip_extra_len += 4;      
            }else{
                /* if gre has gre-key */
                if(psai_acl_entry->outer_fileds.gre_key.enable){
                    res->scl.action.u.flow_action.strip_packet.strip_extra_len  += 4;
                }
            }
           
            /* TODO DIY strip offset */
            if(psai_acl_entry->action.strip_header_pos.enable){
                switch(psai_acl_entry->action.strip_header_pos.parameter.u32){
                case SAI_ACL_STRIP_HEADER_POS_L2:
                    res->scl.action.u.flow_action.strip_packet.start_packet_strip  = CTC_SCL_STRIP_START_TO_L2;
                    break;
                case SAI_ACL_STRIP_HEADER_POS_L3:
                    res->scl.action.u.flow_action.strip_packet.start_packet_strip  = CTC_SCL_STRIP_START_TO_L3;
                    break;
                default:
                    break;
                }
            }

            if(psai_acl_entry->action.strip_header_offset.enable){
                res->scl.action.u.flow_action.strip_packet.strip_extra_len  = 
                    psai_acl_entry->action.strip_header_offset.parameter.u32;
            }


            res->scl.action.u.flow_action.strip_packet.strip_extra_len >>= 1;    /* IpeSclFlowCtl.removeByteShift = 1 */
#endif 
            CTC_SET_FLAG(res->scl.action.u.flow_action.flag, CTC_SCL_FLOW_ACTION_FLAG_ACLQOS_USE_OUTER_LOOKUP);
            res->scl.action.u.flow_action.aclqos_outer_lookup = 0;

            res->scl.key.u.tcam_ipv4_key.flag |= CTC_SCL_TCAM_IPV4_KEY_FLAG_L4_PROTOCOL;
            if(SAI_ACL_GRE_NVGRE == psai_acl_entry->outer_fileds.gre_type.data.u32){
                res->scl.key.u.tcam_ipv4_key.sub_flag |= CTC_SCL_TCAM_IPV4_KEY_SUB_FLAG_NVGRE_KEY;
            }else{
                res->scl.key.u.tcam_ipv4_key.sub_flag |= CTC_SCL_TCAM_IPV4_KEY_SUB_FLAG_GRE_KEY;
            }

            if(psai_acl_entry->outer_fileds.gre_key.enable){               
                gre_mask = (~(psai_acl_entry->outer_fileds.gre_key.mask.u32)) & 0xFFFFFFFF;
                res->scl.key.u.tcam_ipv4_key.gre_key = psai_acl_entry->outer_fileds.gre_key.data.u32;
                res->scl.key.u.tcam_ipv4_key.gre_key_mask = gre_mask;
            }
        }
    default:
        goto out;
        break;
    }

    return 0;

out:
    return 0;
}

void
__connect_acl2scl(ctc_sai_acl_tunnel_decap_info_t   *ptunnel_decap,
                  ctc_sai_acl_entry_t               *pst_acl_entry,
                  sai_object_id_t                   in_port_oid,
                  fields_mapping_res_t              *res)
{
    if(NULL == ptunnel_decap)
    {
        if(SAI_OBJECT_TYPE_PORT == CTC_SAI_OBJECT_TYPE_GET(in_port_oid))
        {
            if(ctc_sai_port_get_metadata(in_port_oid)){
                CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_METADATA);
                res->acl_key.metadata        = 0;
                res->acl_key.metadata_mask   = 0xFFFFFFFF;
            }
        }
    }else{
 //       sal_assert(FIELD_ACL_ENTRY_TYPE == res->mapping_type);

        CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_METADATA);
        res->acl_key.metadata        = ptunnel_decap->entry_id;
        res->acl_key.metadata_mask   = 0xFFFFFFFF;
    }

    __config_strip_header(pst_acl_entry, res);
}

void 
__convert_attr_list_to_sai_acl_entry(
        _In_ uint32_t               attr_count,
        _In_ const sai_attribute_t  *attr_list,
             ctc_sai_acl_entry_t    *psai_acl_entry)
{
#define __ACL_GET_FILED_ATTR(attr_id, member)                       \
    {                                                               \
        attr_stage = ctc_sai_attr_get_attr_by_id(attr_id,           \
                                                attr_list,          \
                                                attr_count,         \
                                                NULL);              \
                                                                    \
        if(attr_stage){                                             \
            if( attr_id < SAI_ACL_ENTRY_ATTR_FIELD_INNER_END &&     \
                attr_id > SAI_ACL_ENTRY_ATTR_FIELD_INNER_START ){   \
                psai_acl_entry->apply_inner_lookup = true;          \
                sal_memcpy(                                         \
                    &psai_acl_entry->inner_fileds.member,           \
                    &attr_stage->value.aclfield,                    \
                    sizeof(sai_acl_field_data_t));                  \
            } else if( attr_id >= SAI_ACL_ENTRY_ATTR_FIELD_START && \
                       attr_id <= SAI_ACL_ENTRY_ATTR_FIELD_END ){   \
                sal_memcpy(                                         \
                    &psai_acl_entry->outer_fileds.member,           \
                    &attr_stage->value.aclfield,                    \
                    sizeof(sai_acl_field_data_t));                  \
            }                                                       \
        }                                                           \
    }

#define __ACL_GET_FILED_ATTR_ACTION(attr_id, member)                \
    {                                                               \
        attr_stage = ctc_sai_attr_get_attr_by_id(attr_id,           \
                                                attr_list,          \
                                                attr_count,         \
                                                NULL);              \
                                                                    \
        if(attr_stage){                                             \
            if( attr_id >= SAI_ACL_ENTRY_ATTR_ACTION_START &&       \
                attr_id <= SAI_ACL_ENTRY_ATTR_ACTION_END ){         \
                sal_memcpy(                                         \
                    &psai_acl_entry->action.member,                 \
                    &attr_stage->value.aclaction,                   \
                    sizeof(sai_acl_action_data_t));                 \
            }                                                       \
        }                                                           \
    }

#define __ACL_GET_ATTR(attr_id, member)                             \
    {                                                               \
        attr_stage = ctc_sai_attr_get_attr_by_id(attr_id,           \
                                                attr_list,          \
                                                attr_count,         \
                                                NULL);              \
                                                                    \
        if(attr_stage){                                             \
                sal_memcpy(                                         \
                    &psai_acl_entry->member,                        \
                    &attr_stage->value.aclfield,                    \
                    sizeof(sai_acl_field_data_t));                  \
        }                                                           \
    }

    const sai_attribute_t         *attr_stage         = NULL;

    __ACL_GET_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT,        in_port);

    /* outer filed */
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_SRC_MAC,                  ether_macsa);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_DST_MAC,                  ether_macda);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_SRC_IP,                   ipv4_ipsa);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_DST_IP,                   ipv4_ipda);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_ID,            ether_svlan);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_VLAN_ID,            ether_cvlan);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_PRI,           ether_svlan_pri);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_CFI,           ether_svlan_cfi);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_VLAN_PRI,           ether_cvlan_pri);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_VLAN_CFI,           ether_cvlan_cfi);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_L4_SRC_PORT,              ipv4_src_port);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_L4_DST_PORT,              ipv4_dst_port);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_ETHER_TYPE,               ether_type);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_IP_PROTOCOL,              ipv4_ip_protocol);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_IP_PRECEDENCE,            ipv4_ip_precedence);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_DSCP,                     ipv4_dscp);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_IP_FLAGS,                 ipv4_ip_frag);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_TCP_FLAGS,                ipv4_tcp_flag);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_IP_FRAG,                  ipv4_ip_frag);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_ICMP_TYPE,                ipv4_icmp_type);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_ICMP_CODE,                ipv4_icmp_code);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_IGMP_TYPE,                ipv4_igmp_type);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_IP_OPTIONS,               ipv4_ip_options);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_ROUTED_PKT,               ipv4_routed_packet);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_VXLAN_VNI,                ipv4_vxlan_vni);

    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_GRE_TYPE,                 gre_type);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_GRE_KEY,                  gre_key);

    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_UDF_TYPE,                 udf_type);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_UDF_MATCH,                udf_match_data);

    /* inner filed */
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_SRC_MAC,            ether_macsa);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_DST_MAC,            ether_macda);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_SRC_IP,             ipv4_ipsa);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_DST_IP,             ipv4_ipda);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_OUTER_VLAN_ID,      ether_svlan);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_INNER_VLAN_ID,      ether_cvlan);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_OUTER_VLAN_PRI,     ether_svlan_pri);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_OUTER_VLAN_CFI,     ether_svlan_cfi);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_INNER_VLAN_PRI,     ether_cvlan_pri);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_INNER_VLAN_CFI,     ether_cvlan_cfi);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_L4_SRC_PORT,        ipv4_src_port);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_L4_DST_PORT,        ipv4_dst_port);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_ETHER_TYPE,         ether_type);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_IP_PROTOCOL,        ipv4_ip_protocol);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_IP_PRECEDENCE,      ipv4_ip_precedence);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_DSCP,               ipv4_dscp);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_IP_FLAGS,           ipv4_ip_frag);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_TCP_FLAGS,          ipv4_tcp_flag);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_IP_FRAG,            ipv4_ip_frag);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_ICMP_TYPE,          ipv4_icmp_type);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_ICMP_CODE,          ipv4_icmp_code);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_IGMP_TYPE,          ipv4_igmp_type);
    __ACL_GET_FILED_ATTR(SAI_ACL_ENTRY_ATTR_FIELD_INNER_IP_OPTIONS,         ipv4_ip_options);


    /* action */
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_PACKET_ACTION,                  action);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_COUNTER,                 counter);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_MIRROR_INGRESS,          mirror_ingress);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_MIRROR_EGRESS,           mirror_egress);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_SET_COLOR,               set_color);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_SET_POLICER,             set_policer);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT,                redirect);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_SET_REDIRECT_VLAN_ID,    redirect_vlan_id);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_SET_REDIRECT_UNTAG,      redirect_vlan_untag);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_SET_TRUNCATION,          trunction);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_SET_SRC_MAC,             src_mac);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_SET_DST_MAC,             dst_mac);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_SET_SRC_IP,              src_ip);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_SET_DST_IP,              dst_ip);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_SET_STRIP_HEADER,        strip_header);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_SET_STRIP_HEADER_POS,    strip_header_pos);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_SET_STRIP_HEADER_OFFSET, strip_header_offset);
    __ACL_GET_FILED_ATTR_ACTION(SAI_ACL_ENTRY_ATTR_ACTION_SET_OUTER_VLAN_ID,       outer_vlan);
}

void  
__mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer_ovlan(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ether_svlan.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_SVLAN);
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_STAG_VALID);
            res->acl_key.stag_valid = TRUE;
            res->acl_key.svlan      = field_list->ether_svlan.data.u16;
            res->acl_key.svlan_mask = field_list->ether_svlan.mask.u16;
            SAI_ACL_VLAN_WILDCARD_MASK(res->acl_key.svlan_mask);
        }else {
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_SVLAN);
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_STAG_VALID);
            res->scl_key.stag_valid = TRUE;
            res->scl_key.svlan      = field_list->ether_svlan.data.u16;
            res->scl_key.svlan_mask = field_list->ether_svlan.mask.u16;
            SAI_ACL_VLAN_WILDCARD_MASK(res->scl_key.svlan_mask);
        }
    }
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer_ovlan_cos(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ether_svlan_pri.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_STAG_COS);
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_STAG_VALID);
            res->acl_key.stag_valid = TRUE;
            res->acl_key.stag_cos      = field_list->ether_svlan_pri.data.u8;
            res->acl_key.stag_cos_mask = field_list->ether_svlan_pri.mask.u8;
            SAI_ACL_COS_WILDCARD_MASK(res->acl_key.stag_cos_mask);
        }else {
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_STAG_COS);
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_STAG_VALID);
            res->scl_key.stag_valid = TRUE;
            res->scl_key.stag_cos      = field_list->ether_svlan_pri.data.u8;
            res->scl_key.stag_cos_mask = field_list->ether_svlan_pri.mask.u8;
            SAI_ACL_COS_WILDCARD_MASK(res->scl_key.stag_cos_mask);
        }
    }
}

void
__mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer_ivlan(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ether_cvlan.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_CVLAN);
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_CTAG_VALID);
            res->acl_key.ctag_valid = TRUE;
            res->acl_key.cvlan        = field_list->ether_cvlan.data.u16;
            res->acl_key.cvlan_mask   = field_list->ether_cvlan.mask.u16;
            SAI_ACL_VLAN_WILDCARD_MASK(res->acl_key.cvlan_mask);
        }else {
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_CVLAN);
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_CTAG_VALID);
            res->scl_key.ctag_valid = TRUE;
            res->scl_key.cvlan        = field_list->ether_cvlan.data.u16;
            res->scl_key.cvlan_mask   = field_list->ether_cvlan.mask.u16;
            SAI_ACL_VLAN_WILDCARD_MASK(res->scl_key.cvlan_mask);
        }
    }
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer_ivlan_cos(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ether_cvlan_pri.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_CTAG_COS);
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_CTAG_VALID);
            res->acl_key.ctag_valid = TRUE;
            res->acl_key.ctag_cos      = field_list->ether_cvlan_pri.data.u8;
            res->acl_key.ctag_cos_mask = field_list->ether_cvlan_pri.mask.u8;
            SAI_ACL_COS_WILDCARD_MASK(res->acl_key.ctag_cos_mask);
        }else {
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_CTAG_COS);
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_CTAG_VALID);
            res->scl_key.ctag_valid = TRUE;
            res->scl_key.ctag_cos      = field_list->ether_cvlan_pri.data.u8;
            res->scl_key.ctag_cos_mask = field_list->ether_cvlan_pri.mask.u8;
            SAI_ACL_COS_WILDCARD_MASK(res->scl_key.ctag_cos_mask);
        }
    }

}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer_ether_macsa(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ether_macsa.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_MAC_SA);
            sal_memcpy(res->acl_key.mac_sa,       field_list->ether_macsa.data.mac, sizeof(sai_mac_t));
            sal_memcpy(res->acl_key.mac_sa_mask,  field_list->ether_macsa.mask.mac, sizeof(sai_mac_t));
            SAI_ACL_MAC_WILDCARD_MASK(res->acl_key.mac_sa_mask);
        }else {
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_MAC_SA);
            sal_memcpy(res->scl_key.mac_sa,       field_list->ether_macsa.data.mac, sizeof(sai_mac_t));
            sal_memcpy(res->scl_key.mac_sa_mask,  field_list->ether_macsa.mask.mac, sizeof(sai_mac_t));
            SAI_ACL_MAC_WILDCARD_MASK(res->scl_key.mac_sa_mask);
        }
    }
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer_ether_macda(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ether_macda.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_MAC_DA);
            sal_memcpy(res->acl_key.mac_da,       field_list->ether_macda.data.mac, sizeof(sai_mac_t));
            sal_memcpy(res->acl_key.mac_da_mask,  field_list->ether_macda.mask.mac, sizeof(sai_mac_t));
            SAI_ACL_MAC_WILDCARD_MASK(res->acl_key.mac_da_mask);
        }else {
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_MAC_DA);
            sal_memcpy(res->scl_key.mac_da,       field_list->ether_macda.data.mac, sizeof(sai_mac_t));
            sal_memcpy(res->scl_key.mac_da_mask,  field_list->ether_macda.mask.mac, sizeof(sai_mac_t));
            SAI_ACL_MAC_WILDCARD_MASK(res->scl_key.mac_da_mask);
        }
    }
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer_ether_type(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
#ifdef GOLDENGATE
    struct eth_type_map{
        uint16_t    type;
        uint8_t     l3_type;
    } type2map[] = {
        {0x0800,CTC_PARSER_L3_TYPE_IPV4},
        {0x0806,CTC_PARSER_L3_TYPE_ARP},
        {0x86DD,CTC_PARSER_L3_TYPE_IPV6},
        {0x8847,CTC_PARSER_L3_TYPE_MPLS},
        {0x8848,CTC_PARSER_L3_TYPE_MPLS_MCAST},
        {0x8906,CTC_PARSER_L3_TYPE_FCOE},
        {0x22F3,CTC_PARSER_L3_TYPE_TRILL},
        {0x8902,CTC_PARSER_L3_TYPE_ETHER_OAM},
        {0x88E7,CTC_PARSER_L3_TYPE_CMAC},
        {0x8809,CTC_PARSER_L3_TYPE_SLOW_PROTO},
        {0x88F7,CTC_PARSER_L3_TYPE_PTP},
    };
    uint32_t    idx = 0;
#endif
    uint32_t    hit_l3_type = 0;

    CTC_SAI_DEBUG_FUNC();
    if (field_list->ether_type.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
#ifdef GOLDENGATE
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);

            for(idx = 0; idx < sizeof(type2map)/sizeof(type2map[0]); idx++)
            {
                if (type2map[idx].type == field_list->ether_type.data.u16 && 
                    0 == field_list->ether_type.mask.u16)
                {
                    res->acl_key.l3_type = type2map[idx].l3_type;
                    res->acl_key.l3_type_mask = 0xf;

                    hit_l3_type = 1;
                    break;
                }
            }
#else
            if (0x0800 == field_list->ether_type.data.u16 
                && 0 == field_list->ether_type.mask.u16)
            {
                CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_IPV4_PACKET);
                res->acl_key.ipv4_packet = 1;
                
                hit_l3_type = 1;
            }
            else if (0x0806 == field_list->ether_type.data.u16 
                && 0 == field_list->ether_type.mask.u16)
            {
                CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_ARP_PACKET);
                res->acl_key.arp_packet = 1;

                hit_l3_type = 1;
            }
#endif
            if(!hit_l3_type){
                res->acl_key.l3_type      = CTC_PARSER_L3_TYPE_NONE;
                res->acl_key.l3_type_mask = 0xf;
                CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_ETH_TYPE);
            }
            res->acl_key.eth_type      = field_list->ether_type.data.u16;
            res->acl_key.eth_type_mask = field_list->ether_type.mask.u16;
            SAI_ACL_WILDCARD_MASK(res->acl_key.eth_type_mask);
        }else {
#ifdef GOLDENGATE
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_L3_TYPE);

            for(idx = 0; idx < sizeof(type2map)/sizeof(type2map[0]); idx++)
            {
                if (type2map[idx].type == field_list->ether_type.data.u16 && 
                    0 == field_list->ether_type.mask.u16)
                {
                    res->scl_key.l3_type = type2map[idx].l3_type;
                    res->scl_key.l3_type_mask = 0xf;

                    hit_l3_type = 1;
                    break;
                }
            }
#else
            /* not support GB */
#endif
            if(!hit_l3_type){
                res->scl_key.l3_type      = CTC_PARSER_L3_TYPE_NONE;
                res->scl_key.l3_type_mask = 0xf;
                CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_ETH_TYPE);
            }
            res->scl_key.eth_type      = field_list->ether_type.data.u16;
            res->scl_key.eth_type_mask = field_list->ether_type.mask.u16;
            SAI_ACL_WILDCARD_MASK(res->scl_key.eth_type_mask);
        }
    }
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    /* L2 layer */
    __mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer_ether_macsa(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer_ether_macda(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer_ovlan(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer_ovlan_cos(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer_ivlan(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer_ivlan_cos(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer_ether_type(field_list, psai_acl_entry, res);
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ipda(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
        
    if (field_list->ipv4_ipda.enable)
    {
        if(IS_EQ_WILDCARD_MASK_32(field_list->ipv4_ipda.mask.ip4)){
            return ;
        }

        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
#ifdef GOLDENGATE
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
            res->acl_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
            res->acl_key.l3_type_mask = 0xf;
            
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_IP_DA);
            res->acl_key.ip_da        = field_list->ipv4_ipda.data.ip4;
            res->acl_key.ip_da_mask   = field_list->ipv4_ipda.mask.ip4;
            SAI_ACL_WILDCARD_MASK(res->acl_key.ip_da_mask);
        }else{        
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_L3_TYPE);
            res->scl_key.l3_type        = CTC_PARSER_L3_TYPE_IPV4;
            res->scl_key.l3_type_mask   = 0xF;

            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_IP_DA);
            res->scl_key.ip_da        = field_list->ipv4_ipda.data.ip4;
            res->scl_key.ip_da_mask   = field_list->ipv4_ipda.mask.ip4;
            SAI_ACL_WILDCARD_MASK(res->scl_key.ip_da_mask);
        }
    }
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ipsa(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
        
    if (field_list->ipv4_ipsa.enable)
    {
        if(IS_EQ_WILDCARD_MASK_32(field_list->ipv4_ipsa.mask.ip4)){
            return ;
        }

        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
#ifdef GOLDENGATE
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
            res->acl_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
            res->acl_key.l3_type_mask = 0xf;
            
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_IP_SA);
            res->acl_key.ip_sa        = field_list->ipv4_ipsa.data.ip4;
            res->acl_key.ip_sa_mask   = field_list->ipv4_ipsa.mask.ip4;
            SAI_ACL_WILDCARD_MASK(res->acl_key.ip_sa_mask);
        }else{       
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_L3_TYPE);
            res->scl_key.l3_type        = CTC_PARSER_L3_TYPE_IPV4;
            res->scl_key.l3_type_mask   = 0xF;

            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_IP_SA);
            res->scl_key.ip_sa        = field_list->ipv4_ipsa.data.ip4;
            res->scl_key.ip_sa_mask   = field_list->ipv4_ipsa.mask.ip4;
            SAI_ACL_WILDCARD_MASK(res->scl_key.ip_sa_mask);
        }
    }
}

void
__mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ip_protocol(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ipv4_ip_protocol.enable)
    {
        if(IS_EQ_WILDCARD_MASK_8(field_list->ipv4_ip_protocol.mask.u8)){
            return ;
        }
        
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
#ifdef GOLDENGATE
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
            /* SDK bug, if l4_protocol == 0 && l4_protocol_mask == 255 then ,not set flag l4_protocol */
            if(field_list->ipv4_ip_protocol.mask.u8 != 0xFF ||
               res->acl_key.l4_protocol != 0)
            {
                res->acl_key.l3_type      = CTC_PARSER_L3_TYPE_IPV4;
                res->acl_key.l3_type_mask = 0xf;
                CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_L4_PROTOCOL);
                
                res->acl_key.l4_protocol      = field_list->ipv4_ip_protocol.data.u8;
                res->acl_key.l4_protocol_mask = field_list->ipv4_ip_protocol.mask.u8;
                SAI_ACL_WILDCARD_MASK(res->acl_key.l4_protocol_mask);
            }
        }else {
#ifdef GOLDENGATE
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_L4_PROTOCOL);
#endif
            /* SDK bug, if l4_protocol == 0 && l4_protocol_mask == 255 then ,not set flag l4_protocol */
            if(field_list->ipv4_ip_protocol.mask.u8 != 0xFF ||
               res->scl_key.l4_protocol != 0)
            {
                res->scl_key.l3_type      = CTC_PARSER_L3_TYPE_IPV4;
                res->scl_key.l3_type_mask = 0xf;
                CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_L4_PROTOCOL);
                
                res->scl_key.l4_protocol      = field_list->ipv4_ip_protocol.data.u8;
                res->scl_key.l4_protocol_mask = field_list->ipv4_ip_protocol.mask.u8;
                SAI_ACL_WILDCARD_MASK(res->scl_key.l4_protocol_mask);
            }
        }
    }
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ip_dscp(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ipv4_dscp.enable)
    {
        if(IS_EQ_WILDCARD_MASK_8(field_list->ipv4_dscp.mask.u8)){
            return ;
        }

        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
#ifdef GOLDENGATE
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
            res->acl_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
            res->acl_key.l3_type_mask = 0xf;
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_DSCP);
            res->acl_key.dscp = field_list->ipv4_dscp.data.u8;
            res->acl_key.dscp_mask = field_list->ipv4_dscp.mask.u8;
            SAI_ACL_DSCP_WILDCARD_MASK(res->acl_key.dscp_mask);
        }else {
#ifdef GOLDENGATE
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_L3_TYPE);
#endif
            res->scl_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
            res->scl_key.l3_type_mask = 0xf;
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_DSCP);
            res->scl_key.dscp = field_list->ipv4_dscp.data.u8;
            res->scl_key.dscp_mask = field_list->ipv4_dscp.mask.u8;
            SAI_ACL_DSCP_WILDCARD_MASK(res->scl_key.dscp_mask);
        }
    }
}


void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ip_precedence(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ipv4_ip_precedence.enable)
    {
        if(IS_EQ_WILDCARD_MASK_8(field_list->ipv4_ip_precedence.mask.u8)){
            return ;
        }
        
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
#ifdef GOLDENGATE
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
            res->acl_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
            res->acl_key.l3_type_mask = 0xf;
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_PRECEDENCE);
            res->acl_key.dscp = field_list->ipv4_ip_precedence.data.u8;
            res->acl_key.dscp_mask = field_list->ipv4_ip_precedence.mask.u8;
            SAI_ACL_COS_WILDCARD_MASK(res->acl_key.dscp_mask);
        }else {
#ifdef GOLDENGATE
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_L3_TYPE);
#endif
            res->scl_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
            res->scl_key.l3_type_mask = 0xf;
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_PRECEDENCE);
            res->scl_key.dscp = field_list->ipv4_ip_precedence.data.u8;
            res->scl_key.dscp_mask = field_list->ipv4_ip_precedence.mask.u8;
            SAI_ACL_COS_WILDCARD_MASK(res->scl_key.dscp_mask);
        }
    }
}


void
__mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ip_frag(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    ctc_parser_global_cfg_t cfg;

    sal_memset(&cfg,0,sizeof(ctc_parser_global_cfg_t));
    if (field_list->ipv4_ip_frag.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
#ifdef GOLDENGATE
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
            res->acl_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
            res->acl_key.l3_type_mask = 0xf;
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_IP_FRAG);
            res->acl_key.ip_frag = field_list->ipv4_ip_frag.data.u8;
            if (res->acl_key.ip_frag == CTC_IP_FRAG_SMALL)
            {
                cfg.small_frag_offset = 3;
                ctc_parser_set_global_cfg(&cfg);
            }
        }else {
#ifdef GOLDENGATE
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_L3_TYPE);
#endif
            res->scl_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
            res->scl_key.l3_type_mask = 0xf;
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_IP_FRAG);
            res->scl_key.ip_frag = field_list->ipv4_ip_frag.data.u8;
            if (res->scl_key.ip_frag == CTC_IP_FRAG_SMALL)
            {
                cfg.small_frag_offset = 3;
                ctc_parser_set_global_cfg(&cfg);
            }
        }
    }
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_igmp_type(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ipv4_igmp_type.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
            CTC_SET_FLAG(res->acl_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_IGMP_TYPE);
            res->acl_key.igmp_type = field_list->ipv4_igmp_type.data.u8;
            res->acl_key.igmp_type_mask = 0xff;
        }else {
            CTC_SET_FLAG(res->scl_key.sub_flag, CTC_SCL_TCAM_IPV4_KEY_SUB_FLAG_IGMP_TYPE);
            res->scl_key.igmp_type = field_list->ipv4_igmp_type.data.u8;
            res->scl_key.igmp_type_mask = 0xff;
        }
    }
}

void
__mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_icmp_type(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ipv4_icmp_type.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
            CTC_SET_FLAG(res->acl_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_ICMP_TYPE);
            res->acl_key.icmp_type = field_list->ipv4_icmp_type.data.u8;
            res->acl_key.icmp_type_mask = 0xff;
        }else {
            CTC_SET_FLAG(res->scl_key.sub_flag, CTC_SCL_TCAM_IPV4_KEY_SUB_FLAG_ICMP_TYPE);
            res->scl_key.icmp_type = field_list->ipv4_icmp_type.data.u8;
            res->scl_key.icmp_type_mask = 0xff;
        }
    }
}

void
__mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_icmp_code(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ipv4_icmp_code.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
            CTC_SET_FLAG(res->acl_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_ICMP_CODE);
            res->acl_key.icmp_code = field_list->ipv4_icmp_code.data.u8;
            res->acl_key.icmp_code_mask = 0xff;
        }else {
            CTC_SET_FLAG(res->scl_key.sub_flag, CTC_SCL_TCAM_IPV4_KEY_SUB_FLAG_ICMP_CODE);
            res->scl_key.icmp_code = field_list->ipv4_icmp_code.data.u8;
            res->scl_key.icmp_code_mask = 0xff;
        }
    }
}



void
__mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ip_options(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ipv4_ip_options.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
#ifdef GOLDENGATE
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
            res->acl_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
            res->acl_key.l3_type_mask = 0xf;
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_IP_OPTION);
            res->acl_key.ip_option = field_list->ipv4_ip_options.data.u8;
        }else {
#ifdef GOLDENGATE
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_L3_TYPE);
#endif
            res->scl_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
            res->scl_key.l3_type_mask = 0xf;
            CTC_SET_FLAG(res->scl_key.flag, CTC_SCL_TCAM_IPV4_KEY_FLAG_IP_OPTION);
            res->scl_key.ip_option = field_list->ipv4_ip_options.data.u8;
        }
    }
}

void
__mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ip_routed_packet(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ipv4_routed_packet.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
#ifdef GOLDENGATE
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
            res->acl_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
            res->acl_key.l3_type_mask = 0xf;
            CTC_SET_FLAG(res->acl_key.flag, CTC_ACL_IPV4_KEY_FLAG_ROUTED_PACKET);
            res->acl_key.routed_packet = field_list->ipv4_routed_packet.data.u8;
        }else {
        /* not support. routed packet is after scl */
        }
    }
}


void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    /* L3 layer */
    __mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ipsa(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ipda(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ip_protocol(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ip_dscp(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ip_precedence(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ip_frag(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_igmp_type(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_icmp_type(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_icmp_code(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ip_options(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer_ip_routed_packet(field_list, psai_acl_entry, res);
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l4_layer_src_port(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ipv4_src_port.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
            CTC_SET_FLAG(res->acl_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_L4_SRC_PORT);
#ifdef SAI_DEFINE_STANDAND_ACL_CTC
            if (field_list->ipv4_src_port.data.u16 == field_list->ipv4_src_port.mask.u16)
            {
                res->acl_key.l4_src_port_use_mask = 1;
                res->acl_key.l4_src_port_0 = field_list->ipv4_src_port.data.u16;
                res->acl_key.l4_src_port_1 = 0xffff;
            }
            else
            {
                res->acl_key.l4_src_port_use_mask = 0;
                res->acl_key.l4_src_port_0 = field_list->ipv4_src_port.data.u16;
                res->acl_key.l4_src_port_1 = field_list->ipv4_src_port.mask.u16;
            }
#else 
            res->acl_key.l4_src_port_use_mask = 1;
            res->acl_key.l4_src_port_0 = field_list->ipv4_src_port.data.u16;
            res->acl_key.l4_src_port_1 = field_list->ipv4_src_port.mask.u16;
            SAI_ACL_WILDCARD_MASK(res->acl_key.l4_src_port_1);
#endif
        }else {
            CTC_SET_FLAG(res->scl_key.sub_flag, CTC_SCL_TCAM_IPV4_KEY_SUB_FLAG_L4_SRC_PORT);
            res->scl_key.l4_src_port = field_list->ipv4_src_port.data.u16;
            res->scl_key.l4_src_port = field_list->ipv4_src_port.mask.u16;
            /* src_port eq data == mask */
        }
    }
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l4_layer_dst_port(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ipv4_dst_port.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
            CTC_SET_FLAG(res->acl_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_L4_DST_PORT);
#ifdef SAI_DEFINE_STANDAND_ACL_CTC
            if (field_list->ipv4_dst_port.data.u16 == field_list->ipv4_dst_port.mask.u16)
            {
                res->acl_key.l4_dst_port_use_mask = 1;
                res->acl_key.l4_dst_port_0 = field_list->ipv4_dst_port.data.u16;
                res->acl_key.l4_dst_port_1 = 0xffff;
            }
            else
            {
                res->acl_key.l4_dst_port_use_mask = 0;
                res->acl_key.l4_dst_port_0 = field_list->ipv4_dst_port.data.u16;
                res->acl_key.l4_dst_port_1 = field_list->ipv4_dst_port.mask.u16;
            }
#else 
            res->acl_key.l4_dst_port_use_mask = 1;
            res->acl_key.l4_dst_port_0 = field_list->ipv4_dst_port.data.u16;
            res->acl_key.l4_dst_port_1 = field_list->ipv4_dst_port.mask.u16;
            SAI_ACL_WILDCARD_MASK(res->acl_key.l4_dst_port_1);
#endif
        }else {
            CTC_SET_FLAG(res->scl_key.sub_flag, CTC_SCL_TCAM_IPV4_KEY_SUB_FLAG_L4_DST_PORT);
            res->scl_key.l4_dst_port = field_list->ipv4_dst_port.data.u16;
            res->scl_key.l4_dst_port = field_list->ipv4_dst_port.mask.u16;

            /* dst_port eq data == mask */
        }
    }
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l4_vxlan_vni(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    /* only outer field */
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ipv4_vxlan_vni.enable)
    {
        psai_acl_entry->l4_vxlan_vni       = field_list->ipv4_vxlan_vni.data.u32;
        psai_acl_entry->l4_vxlan_vni_mask  = field_list->ipv4_vxlan_vni.mask.u32;
        psai_acl_entry->l4_vxlan_vni_en    = TRUE;
    }
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l4_tcp_flags(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();
    if (field_list->ipv4_tcp_flag.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
            CTC_SET_FLAG(res->acl_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_TCP_FLAGS);
            res->acl_key.tcp_flags_match_any   = field_list->ipv4_tcp_flag.data.u8;
            res->acl_key.tcp_flags             = field_list->ipv4_tcp_flag.mask.u8;
        }else {
            /* SDK not support */
        }
    }
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_l4_layer(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    /* L3 layer */
    __mapping_sai_acl_entry_to_ctc_acl_entry_l4_layer_src_port(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l4_layer_dst_port(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l4_vxlan_vni(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_l4_tcp_flags(field_list, psai_acl_entry, res);
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_udf_type(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    CTC_SAI_DEBUG_FUNC();

    if (field_list->udf_type.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
            res->acl.key.u.ipv4_key.udf_type = 
                (field_list->udf_type.data.u8 - 1) ? 
                    CTC_PARSER_UDF_TYPE_L4_UDF: CTC_PARSER_UDF_TYPE_L3_UDF;
        }else {
            /* scl not support udf */
        }
    }
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry_udf_match(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    sai_uint8_t i = 0;
    sai_uint32_t udf_value;
    sai_uint32_t udf_mask;
    
    CTC_SAI_DEBUG_FUNC();

    if (field_list->udf_match_data.enable)
    {
        if(FIELD_ACL_ENTRY_TYPE == res->mapping_type){
            CTC_SET_FLAG(res->acl.key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_UDF);
            udf_value = field_list->udf_match_data.data.u32;
            udf_mask = ~field_list->udf_match_data.mask.u32;
            for (i = 0; i < CTC_ACL_UDF_BYTE_NUM; i++)
            {
                res->acl.key.u.ipv4_key.udf[CTC_ACL_UDF_BYTE_NUM - i -1] = (udf_value >> (8 * i)) & 0xff;
                res->acl.key.u.ipv4_key.udf_mask[CTC_ACL_UDF_BYTE_NUM - i -1] = (udf_mask >> (8 * i)) & 0xff;
            }
        }else {
            /* scl not support udf */
        }
    }
}

void 
__mapping_sai_acl_entry_to_ctc_acl_entry(
            ctc_sai_acl_entry_field_list_t *field_list,
            ctc_sai_acl_entry_t     *psai_acl_entry,
            fields_mapping_res_t    *res)
{
    /* convert field */
    /* L2 layer */
    __mapping_sai_acl_entry_to_ctc_acl_entry_l2_layer(field_list, psai_acl_entry, res);

    /* L3 layer */
    __mapping_sai_acl_entry_to_ctc_acl_entry_l3_layer(field_list, psai_acl_entry, res);

    /* L4 layer */
    __mapping_sai_acl_entry_to_ctc_acl_entry_l4_layer(field_list, psai_acl_entry, res);
    /* convert action */

    __mapping_sai_acl_entry_to_ctc_acl_entry_udf_type(field_list, psai_acl_entry, res);
    __mapping_sai_acl_entry_to_ctc_acl_entry_udf_match(field_list, psai_acl_entry, res);
}
  
/*
* Routine Description:
*   Create an ACL entry
*
* Arguments:
*   [out] acl_entry_id - the acl entry id
*   [in] attr_count - number of attributes
*   [in] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_create_acl_entry(
    _Out_ sai_object_id_t* acl_entry_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    ctc_sai_acl_entry_t *pst_acl_entry = NULL;
    ctc_sai_acl_table_t *pst_acl_table = NULL;
    sai_attribute_t const *pattr_entry = NULL;
    sai_object_id_t port_id = 0;
    uint32 gport = 0;
    sai_status_t ret = SAI_STATUS_SUCCESS;
    sai_uint32_t group_id = 0;
    sai_uint32_t index = 0;
    sai_attribute_t *attr_list_db = NULL;
    sai_uint32_t dir = 0;
    sai_uint32_t i = 0;
    ctc_sai_mirror_entry_t* p_session = NULL;
    ctc_mirror_dest_t mirror_dest;
    bool is_worm_filter = FALSE;
    uint8 tid = 0;
#ifdef TAPPRODUCT
    ctc_sai_tap_group_edit_group_key    key;
#endif
	ctc_sai_acl_tunnel_decap_info_key_t tunnel_decap_key;
    fields_mapping_res_t    aclentry = {FIELD_ACL_ENTRY_TYPE};

    CTC_SAI_PTR_VALID_CHECK(acl_entry_id);
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    CTC_SAI_DEBUG_FUNC();
    sai_create_acl_entry_debug_param(attr_count, attr_list);

    sal_memset(&aclentry, 0, sizeof(fields_mapping_res_t));

    aclentry.mapping_type = FIELD_ACL_ENTRY_TYPE;

    ret = ctc_sai_acl_db_alloc_entry(&pst_acl_entry);
    if (NULL == pst_acl_entry)
    {
        return SAI_STATUS_NO_MEMORY;
    }

    pst_acl_entry->l3type = CTC_PARSER_L3_TYPE_NONE;

    /*if the attr changed, this init block_size should be changed too*/
    pst_acl_entry->acl_action_vector = ctc_vector_init(1,SAI_ACL_ENTRY_ATTR_ACTION_END - SAI_ACL_ENTRY_ATTR_ACTION_START + 1);
    if(NULL == pst_acl_entry->acl_action_vector)
    {
        ret = SAI_STATUS_NO_MEMORY;
        return ret;
    }

    /* 1. get table */
    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_ACL_ENTRY_ATTR_TABLE_ID, attr_list, attr_count, &index);
    if (NULL != pattr_entry)
    {
        pst_acl_entry->table_id = pattr_entry->value.oid;
    }
    else
    {
        ret = SAI_STATUS_MANDATORY_ATTRIBUTE_MISSING;
        goto out;
    }

    pst_acl_table = ctc_sai_acl_db_get_table_by_oid(pst_acl_entry->table_id);
    if (NULL == pst_acl_table)
    {
        ret = SAI_STATUS_ITEM_NOT_FOUND;
        goto out;
    }

    /* 2. get priority */
    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_ACL_ENTRY_ATTR_PRIORITY, attr_list, attr_count, &index);
    if (NULL != pattr_entry)
    {
        pst_acl_entry->priority = pattr_entry->value.u32;
    }
    else
    {
        ret = SAI_STATUS_MANDATORY_ATTRIBUTE_MISSING;
        goto out;
    }

    /* 4. get port and stage*/
    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT, attr_list, attr_count, &index);
    if (NULL != pattr_entry)
    {
        port_id = pattr_entry->value.aclfield.data.oid;
        dir = CTC_INGRESS;
    }
    else
    {
        pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_ACL_ENTRY_ATTR_FIELD_OUT_PORT, attr_list, attr_count, &index);
        if (NULL != pattr_entry)
        {
            port_id = pattr_entry->value.aclfield.data.oid;
            dir = CTC_EGRESS;
        }
        else
        {
            pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_ACL_ENTRY_ATTR_FIELD_IN_PORTS, attr_list, attr_count, &index);
            if (NULL != pattr_entry)
            {
                dir = CTC_INGRESS;
            }
            else
            {
                pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_ACL_ENTRY_ATTR_FIELD_OUT_PORTS, attr_list, attr_count, &index);
                if (NULL != pattr_entry)
                {
                    dir = CTC_EGRESS;
                }
            }
        }
    }

    /* 3. mapping parameter */

    __convert_attr_list_to_sai_acl_entry(attr_count, attr_list, pst_acl_entry);
    if(pst_acl_entry->apply_inner_lookup)
    {
        __mapping_sai_acl_entry_to_ctc_acl_entry(
                &pst_acl_entry->inner_fileds, 
                pst_acl_entry, 
                &aclentry);

        /* TODO */
        sal_memcpy(&tunnel_decap_key.fields, &pst_acl_entry->outer_fileds, 
                    sizeof(ctc_sai_acl_tunnel_decap_info_key_t));
        tunnel_decap_key.port_oid = port_id;
        pst_acl_entry->ptunnel_info = __tunnel_decap_alloc(&tunnel_decap_key, pst_acl_entry);
        
 //       sal_assert(pst_acl_entry->ptunnel_info != NULL);
    }else{
        __mapping_sai_acl_entry_to_ctc_acl_entry(
                &pst_acl_entry->outer_fileds, 
                pst_acl_entry, 
                &aclentry);
    }

    for (index = 0; index < attr_count; index++)
    {
        if ((SAI_ACL_ENTRY_ATTR_ACTION_START <= attr_list[index].id) && (SAI_ACL_ENTRY_ATTR_ACTION_END >= attr_list[index].id))
        {
            if(NULL == g_sai_acl_info.g_acl_action[attr_list[index].id-SAI_ACL_ENTRY_ATTR_ACTION_START]){
                continue;
            }
            
            ret = g_sai_acl_info.g_acl_action[attr_list[index].id-SAI_ACL_ENTRY_ATTR_ACTION_START]
                (&aclentry.acl, &attr_list[index],pst_acl_entry);
            if (ret)
            {
                goto out;
            }
            /* save entry info in db */
            attr_list_db = mem_malloc(MEM_APP_ACL_MODULE,sizeof(sai_attribute_t));
            sal_memcpy(attr_list_db, &attr_list[index], sizeof(sai_attribute_t));

            if(FALSE == ctc_vector_add(pst_acl_entry->acl_action_vector, attr_list[index].id - SAI_ACL_ENTRY_ATTR_ACTION_START, attr_list_db))
            {
                ret = SAI_STATUS_FAILURE;
                return ret;
            }
        }
    }
    
    /* 3.1 check strip-header */
    /* if inner lookup is invaild, then use acl to strip-packet */
    if(!pst_acl_entry->apply_inner_lookup)
    {
        if(0 != __check_tunnel_header_valid_and_config(pst_acl_entry, &aclentry)){
            ret = SAI_STATUS_FAILURE;
            goto out;
        }
    }

    __connect_acl2scl(pst_acl_entry->ptunnel_info,pst_acl_entry, port_id, &aclentry);

#ifndef GOLDENGATE
    /*for gb ingress deny learning*/
    if(CTC_FLAG_ISSET(aclentry.acl.action.flag,CTC_ACL_ACTION_FLAG_DISCARD) && CTC_INGRESS == dir)
    {
        CTC_SET_FLAG(aclentry.acl.action.flag, CTC_ACL_ACTION_FLAG_DENY_LEARNING);
    }
#endif

    /*creat acl mirror session*/
    if(CTC_FLAG_ISSET(aclentry.acl.action.flag,CTC_ACL_ACTION_FLAG_RANDOM_LOG))
    {
        p_session = ctc_sai_mirror_entry_get(CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_MIRROR,aclentry.acl.action.log_session_id));
        if(!p_session)
        {
            return SAI_STATUS_ITEM_NOT_FOUND;
        }
        sal_memset(&mirror_dest, 0, sizeof(mirror_dest));
        mirror_dest.session_id = CTC_SAI_OBJECT_INDEX_GET(p_session->sid);
        mirror_dest.dir = dir;
        mirror_dest.type = CTC_MIRROR_ACLLOG_SESSION;
        if (p_session->monitor_type == SAI_MIRROR_TYPE_LOCAL)
        {
            if (p_session->is_multi_dest_mirror)
            {
                mirror_dest.rspan.nh_id = CTC_SAI_OBJECT_INDEX_GET(p_session->nhid);
                mirror_dest.is_rspan = TRUE;
                mirror_dest.vlan_valid = FALSE; 
            }
            else
            {
                /* port */
                if (SAI_OBJECT_TYPE_PORT == CTC_SAI_OBJECT_TYPE_GET(p_session->monitor_port[0]))
                {
                    mirror_dest.dest_gport = CTC_SAI_OBJECT_INDEX_GET(p_session->monitor_port[0]);
                }
                /* agg */
                else if (SAI_OBJECT_TYPE_LAG == CTC_SAI_OBJECT_TYPE_GET(p_session->monitor_port[0]))
                {
                    tid = CTC_SAI_OBJECT_INDEX_GET(p_session->monitor_port[0]);
                    mirror_dest.dest_gport = CTC_MAP_TID_TO_GPORT(tid);
                }
                else
                {
                    return SAI_STATUS_NOT_SUPPORTED;
                }
            }
        }
        else if (p_session->monitor_type == SAI_MIRROR_TYPE_REMOTE)
        {            
            mirror_dest.dest_gport = CTC_SAI_OBJECT_INDEX_GET(p_session->monitor_port[0]);
            mirror_dest.rspan.nh_id = CTC_SAI_OBJECT_INDEX_GET(p_session->nhid);
            mirror_dest.is_rspan = TRUE;
            mirror_dest.vlan_valid = FALSE;
        }
        else
        {
            return SAI_STATUS_NOT_SUPPORTED;
        }
        ret = ctc_mirror_add_session(&mirror_dest);
        if(ret)
        {
            return ret;
        }
        pst_acl_entry->mirror_session_id = p_session->sid;
    }
#ifdef TAPPRODUCT
    if (pst_acl_entry->ptap_info)
    {
        uint32_t    session_id = 0;
        uint32_t    nexthop_id = 0;
        
        CTC_SAI_DEBUG("%s%d:tap_info: g_tap_truncation = %d\n",
            __FUNCTION__,__LINE__,pst_acl_entry->trunction_en);
            
        if(pst_acl_entry->trunction_en){ 
            ctc_sai_tap_group_get_session_id(pst_acl_entry->tap_group_id,&session_id);

            aclentry.acl.action.flag |= CTC_ACL_ACTION_FLAG_RANDOM_LOG;
            aclentry.acl.action.log_session_id = session_id;
            aclentry.acl.action.log_percent = CTC_LOG_PERCENT_POWER_NEGATIVE_0;

            pst_acl_entry->trunction_en = TRUE;
        }else{
            if(pst_acl_entry->ipda_en || pst_acl_entry->ipsa_en || 
                pst_acl_entry->macda_en || pst_acl_entry->macsa_en ||
                pst_acl_entry->action.outer_vlan.enable){
                sal_memset(&key, 0, sizeof(ctc_sai_tap_group_edit_group_key));

                if( pst_acl_entry->strip_header &&
                    (pst_acl_entry->outer_fileds.gre_type.enable && 
                    SAI_ACL_GRE_GRE == pst_acl_entry->outer_fileds.gre_type.data.u32))
                {
                    SAI_SET_BIT(key.edit_flag,CTC_SAI_TAP_GROUP_EDIT_TYPE_CUSTOM_GRE_L2_HDR);
                }else{
                    SAI_SET_BIT(key.edit_flag,CTC_SAI_TAP_GROUP_EDIT_TYPE_CUSTOM);
                }
                
                
                if(pst_acl_entry->ipda_en){
                    SAI_SET_BIT(key.edit_flag,CTC_SAI_TAP_GROUP_EDIT_DIP);
                    key.ipv4_dip = pst_acl_entry->ipda;
                }
                if(pst_acl_entry->ipsa_en){
                    SAI_SET_BIT(key.edit_flag,CTC_SAI_TAP_GROUP_EDIT_SIP);
                    key.ipv4_sip = pst_acl_entry->ipsa;
                }
                if(pst_acl_entry->macda_en){
                    SAI_SET_BIT(key.edit_flag,CTC_SAI_TAP_GROUP_EDIT_DMAC);
                    sal_memcpy(key.mac_dest, pst_acl_entry->macda, sizeof(sai_mac_t));
                }
                if(pst_acl_entry->macsa_en){
                    SAI_SET_BIT(key.edit_flag,CTC_SAI_TAP_GROUP_EDIT_SMAC);
                    sal_memcpy(key.mac_src, pst_acl_entry->macsa, sizeof(sai_mac_t));
                }
                if(pst_acl_entry->action.outer_vlan.enable){
                    SAI_SET_BIT(key.edit_flag,CTC_SAI_TAP_GROUP_EDIT_VLAN);
                    key.vlan = pst_acl_entry->action.outer_vlan.parameter.u16;
                }
                pst_acl_entry->edit_group 
                    = ctc_sai_tap_group_get_edit_group(key, pst_acl_entry->ptap_info);
                
                if(NULL == pst_acl_entry->edit_group){
                    return SAI_STATUS_FAILURE;
                }
                nexthop_id = pst_acl_entry->edit_group->nexthop_id;
            }else{
                ctc_sai_tap_group_get_nexthop_id(pst_acl_entry->tap_group_id,&nexthop_id);
            }
            aclentry.acl.action.flag |= CTC_ACL_ACTION_FLAG_REDIRECT;
            aclentry.acl.action.nh_id = nexthop_id;
        }
    }
#endif
    if (port_id && dir == CTC_INGRESS)
    {
        if (SAI_OBJECT_TYPE_NULL == CTC_SAI_OBJECT_TYPE_GET(port_id)
            && (0 == (port_id & 0xffff)))
        {
            is_worm_filter = TRUE;
        }
    }

    if (is_worm_filter)
    {
        aclentry.acl.key.type = CTC_ACL_KEY_IPV4;
        aclentry.acl.key.u.ipv4_key.key_size = CTC_ACL_KEY_SIZE_DOUBLE;
        
        ctc_opf_alloc_offset(&g_sai_acl_info.opf[2], 0, &index);
        pst_acl_entry->ctc_entry_id_list[0] = index;
        pst_acl_entry->ctc_entry_id_cnt = 1;
        pst_acl_entry->dirction = CTC_BOTH_DIRECTION;
        pst_acl_entry->port_oid_list[0] = 0;
        pst_acl_entry->port_oid_cnt = 1;
#ifdef GREATBELT
        /*enable all ports&agg acl enable ingress*/
        ctc_sai_acl_enable_global_port();
#endif
        aclentry.acl.entry_id = pst_acl_entry->ctc_entry_id_list[0];
        aclentry.acl.priority = index + SAI_ACL_WORM_FILTER_PRIORITY_BASE;
        aclentry.acl.priority_valid = TRUE;
        ret = ctc_acl_add_entry(SAI_ACL_WORM_FILTER_GROUP, &aclentry.acl);

        if (CTC_E_NONE != ret)
        {
#ifdef TAPPRODUCT        
            if(pst_acl_entry->trunction_en){
                ctc_sai_tap_group_put_session_id(pst_acl_entry->tap_group_id);
                pst_acl_entry->trunction_en = FALSE;
            }
#endif            
             return ret;
        }
    
        ret = ctc_acl_install_entry(aclentry.acl.entry_id);
        if (CTC_E_NONE != ret)
        {
            ctc_acl_remove_entry(aclentry.acl.entry_id);
#ifdef TAPPRODUCT            
            if(pst_acl_entry->trunction_en){
                ctc_sai_tap_group_put_session_id(pst_acl_entry->tap_group_id);
                pst_acl_entry->trunction_en = FALSE;
            }
#endif            
            goto out;
        }
    
        pst_acl_entry->enable = TRUE;
        ctc_vector_add(g_sai_acl_info.pvector[1], pst_acl_entry->entry_id, pst_acl_entry);
    
        *acl_entry_id = pst_acl_entry->entry_id;
        return ret;
    }
    
    if(port_id && !is_worm_filter)
    {
        /* add to asic */
        aclentry.acl.key.type = CTC_ACL_KEY_IPV4;
        aclentry.acl.key.u.ipv4_key.key_size = CTC_ACL_KEY_SIZE_DOUBLE;

        ctc_opf_alloc_offset(&g_sai_acl_info.opf[2], 0, &index);
        pst_acl_entry->ctc_entry_id_list[0] = index;
        pst_acl_entry->ctc_entry_id_cnt = 1;
        pst_acl_entry->port_oid_list[0] = port_id;
        pst_acl_entry->port_oid_cnt = 1;
        pst_acl_entry->dirction = dir;

        ctc_sai_port_objectid_to_gport(port_id, &gport);
        group_id = ctc_sai_port_make_acl_group_id(dir, gport);
        aclentry.acl.entry_id = pst_acl_entry->ctc_entry_id_list[0];
        aclentry.acl.priority = pst_acl_entry->priority;
        aclentry.acl.priority_valid = TRUE;   
        
#ifdef GREATBELT
        if (SAI_OBJECT_TYPE_LAG == CTC_SAI_OBJECT_TYPE_GET(port_id))
        {
            ctc_sai_acl_en_lag_port(port_id, dir);
        }
        else if (SAI_OBJECT_TYPE_PORT == CTC_SAI_OBJECT_TYPE_GET(port_id))
        {
            ctc_sai_acl_port_en_db_alloc(port_id, dir, port_id);
        }
#endif

        if (SAI_OBJECT_TYPE_COPP == CTC_SAI_OBJECT_TYPE_GET(port_id))
        {
            ctc_sai_port_objectid_to_gport(port_id, &gport);
            if (SAI_COPP_REASON_PORT_ID == gport)
            {
                group_id = SAI_ACL_COPP_REASON_GROUP;
            }
            else if (SAI_COPP_FWD_PORT_ID == gport)
            {
                group_id = SAI_ACL_COPP_FWD2CPU_GROUP;
            }
            else if (SAI_COPP_PORT_ID == gport)
            {
                group_id = SAI_ACL_COPP_ACL_GROUP;
            }
            else if(SAI_COPP_HYBIRD_PORT_ID == gport)
            {
                group_id = SAI_ACL_COPP_OPENFLOW_TO_CONTROLLER_GROUP;
            }
        }

        ret = ctc_acl_add_entry(group_id, &aclentry.acl);

        if (CTC_E_NONE != ret)
        {
#ifdef TAPPRODUCT        
            if(pst_acl_entry->trunction_en){
                ctc_sai_tap_group_put_session_id(pst_acl_entry->tap_group_id);
                pst_acl_entry->trunction_en = FALSE;
            }
#endif            
             return ret;
        }
    
        ret = ctc_acl_install_entry(aclentry.acl.entry_id);
        if (CTC_E_NONE != ret)
        {
            ctc_acl_remove_entry(aclentry.acl.entry_id);
#ifdef TAPPRODUCT             
            if(pst_acl_entry->trunction_en){
                ctc_sai_tap_group_put_session_id(pst_acl_entry->tap_group_id);
                pst_acl_entry->trunction_en = FALSE;
            }
#endif
            goto out;
        }
    
        pst_acl_entry->enable = TRUE;
        ctc_vector_add(g_sai_acl_info.pvector[1], pst_acl_entry->entry_id, pst_acl_entry);
    
        *acl_entry_id = pst_acl_entry->entry_id;
        return ret;
    }

    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_ACL_ENTRY_ATTR_FIELD_IN_PORTS, attr_list, attr_count, &index);
    if (NULL != pattr_entry)
    {

        dir = CTC_INGRESS;
    }
    else
    {
        pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_ACL_ENTRY_ATTR_FIELD_OUT_PORTS, attr_list, attr_count, &index);
        if (NULL != pattr_entry)
        {
            dir = CTC_EGRESS;
        }
    }
    
    if(NULL != pattr_entry)
    {
        for(i=0; i<pattr_entry->value.aclfield.data.objlist.count; i++)
        {
            /* add to asic */
            aclentry.acl.key.type = CTC_ACL_KEY_IPV4;
            aclentry.acl.key.u.ipv4_key.key_size = CTC_ACL_KEY_SIZE_DOUBLE;
    
            ctc_opf_alloc_offset(&g_sai_acl_info.opf[2], 0, &index);
            pst_acl_entry->ctc_entry_id_list[i] = index;
            pst_acl_entry->ctc_entry_id_cnt ++;
            pst_acl_entry->port_oid_list[i] = port_id;
            pst_acl_entry->port_oid_cnt ++;
            pst_acl_entry->dirction = dir;
           
            ctc_sai_port_objectid_to_gport(pattr_entry->value.aclfield.data.objlist.list[i], &gport);
            group_id = ctc_sai_port_make_acl_group_id(dir, gport);
            aclentry.acl.entry_id = pst_acl_entry->ctc_entry_id_list[i];
            aclentry.acl.priority = pst_acl_entry->priority;
            aclentry.acl.priority_valid = TRUE;

            if (SAI_OBJECT_TYPE_COPP == CTC_SAI_OBJECT_TYPE_GET(port_id))
            {
                ctc_sai_port_objectid_to_gport(port_id, &gport);
                if (SAI_COPP_REASON_PORT_ID == gport)
                {
                    group_id = SAI_ACL_COPP_REASON_GROUP;
                }
                else if (SAI_COPP_FWD_PORT_ID == gport)
                {
                    group_id = SAI_ACL_COPP_FWD2CPU_GROUP;
                }
                else if (SAI_COPP_PORT_ID == gport)
                {
                    group_id = SAI_ACL_COPP_ACL_GROUP;
                }
                else if(SAI_COPP_HYBIRD_PORT_ID == gport)
                {
                    group_id = SAI_ACL_COPP_OPENFLOW_TO_CONTROLLER_GROUP;
                }
            }
            ret = ctc_acl_add_entry(group_id, &aclentry.acl);

            if (CTC_E_NONE != ret)
            {
#ifdef TAPPRODUCT            
                if(pst_acl_entry->trunction_en){
                    ctc_sai_tap_group_put_session_id(pst_acl_entry->tap_group_id);
                    pst_acl_entry->trunction_en = FALSE;
                }
#endif                
                goto out;
            }
        
            ret = ctc_acl_install_entry(aclentry.acl.entry_id);
            if (CTC_E_NONE != ret)
            {
                ctc_acl_remove_entry(aclentry.acl.entry_id);
#ifdef TAPPRODUCT                
                if(pst_acl_entry->trunction_en){
                    ctc_sai_tap_group_put_session_id(pst_acl_entry->tap_group_id);
                    pst_acl_entry->trunction_en = FALSE;
                }
#endif                
                goto out;
            }
        
            pst_acl_entry->enable = TRUE;            
        }
        ctc_vector_add(g_sai_acl_info.pvector[1], pst_acl_entry->entry_id, pst_acl_entry);
        *acl_entry_id = pst_acl_entry->entry_id;
    }


out:
    if(pst_acl_entry->acl_action_vector){
        ctc_vector_release(pst_acl_entry->acl_action_vector);
        pst_acl_entry->acl_action_vector = NULL;
    }

    ctc_sai_acl_db_release_entry(pst_acl_entry);
    return ret;
}

/*
* Routine Description:
*   Delete an ACL entry
*
* Arguments:
 *  [in] acl_entry_id - the acl entry id
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_delete_acl_entry(_In_ sai_object_id_t acl_entry_id)
{
    sai_status_t                ret = SAI_STATUS_SUCCESS;
    ctc_sai_acl_entry_t         *pacl_entry = NULL;
    ctc_sai_acl_table_t         *pacl_table = NULL;
    sai_uint32_t i = 0;
    ctc_mirror_dest_t mirror_dest;
    sai_uint32_t action_id =0;
    sai_attribute_t   *attr_value = NULL;
#ifdef GREATBELT
    ctc_sai_acl_port_en_t *acl_port_en_info = NULL;
#endif

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_DEBUG("acl_entry_id = 0x%llx", acl_entry_id);

    pacl_entry = ctc_sai_acl_db_get_entry_by_oid(acl_entry_id);
    if(NULL == pacl_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }
#ifdef TAPPRODUCT
    if(pacl_entry->trunction_en){
        ctc_sai_tap_group_put_session_id(pacl_entry->tap_group_id);
        pacl_entry->trunction_en = FALSE;
    }
    if(pacl_entry->edit_group){
        ctc_sai_tap_group_release_edit_group(pacl_entry->edit_group, pacl_entry->ptap_info);
        pacl_entry->edit_group = NULL;
    }

    if(pacl_entry->ptunnel_info){
        __tunnel_decap_free(pacl_entry->ptunnel_info);
        pacl_entry->ptunnel_info = NULL;
    }
#endif
    pacl_table = ctc_sai_acl_db_get_table_by_oid_no_ref(pacl_entry->table_id);
    if(NULL == pacl_table)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }
    for(i=0; i<pacl_entry->ctc_entry_id_cnt; i++)
    {
        ret = ctc_acl_uninstall_entry(pacl_entry->ctc_entry_id_list[i]);
        if (CTC_E_NONE != ret)
        {
            return ret;
        }
    
        ret = ctc_acl_remove_entry(pacl_entry->ctc_entry_id_list[i]);
        if (CTC_E_NONE != ret)
        {
            return ret;
        }
        ctc_opf_free_offset(&g_sai_acl_info.opf[2], 0, pacl_entry->ctc_entry_id_list[i]);
        
    }

#ifdef GREATBELT
    for (i = 0; i < pacl_entry->port_oid_cnt; i++)
    {
        if (CTC_BOTH_DIRECTION == pacl_entry->dirction && 0 == pacl_entry->port_oid_list[0])
        {
            ctc_sai_acl_disable_global_port();
        }
        else
        {
            if (SAI_OBJECT_TYPE_LAG == CTC_SAI_OBJECT_TYPE_GET(pacl_entry->port_oid_list[i]))
            {
                ctc_sai_acl_dis_lag_port(pacl_entry->port_oid_list[i], pacl_entry->dirction);
            }
            else
            {
                acl_port_en_info = ctc_sai_acl_get_port_en_by_oid(pacl_entry->port_oid_list[i]);
                ctc_sai_acl_port_en_db_release(acl_port_en_info, pacl_entry->dirction); 
            }
        }
    }
#endif

    if(pacl_entry->mirror_session_id)
    {
        mirror_dest.session_id = CTC_SAI_OBJECT_INDEX_GET(pacl_entry->mirror_session_id);
        ctc_mirror_remove_session(&mirror_dest);
    }

    for(action_id = SAI_ACL_ENTRY_ATTR_ACTION_START; action_id <= SAI_ACL_ENTRY_ATTR_ACTION_END; action_id ++)
    {
        attr_value = ctc_vector_get(pacl_entry->acl_action_vector, action_id - SAI_ACL_ENTRY_ATTR_ACTION_START);

        if(NULL != attr_value)
        {
            /* free mirror memory */
            if(attr_value->id == SAI_ACL_ENTRY_ATTR_ACTION_MIRROR_INGRESS || attr_value->id == SAI_ACL_ENTRY_ATTR_ACTION_MIRROR_EGRESS)
            {
                if(NULL != attr_value->value.aclaction.parameter.objlist.list)
                {
                    mem_free(attr_value->value.aclaction.parameter.objlist.list);    
                }
            }

            mem_free(attr_value);
        }
    }
    ctc_vector_release(pacl_entry->acl_action_vector);
    pacl_entry->acl_action_vector = NULL;
    ctc_vector_del(g_sai_acl_info.pvector[1], CTC_SAI_OBJECT_INDEX_GET(pacl_entry->entry_id));

    ctc_sai_acl_db_release_entry(pacl_entry);
    return ret;
}

sai_status_t
ctc_sai_acl_action_map_db_attribute_set_mirror_value(sai_attribute_t *attr_value, const sai_attribute_t *attr, sai_object_id_t *p_list)
{
    sai_object_id_t *p       = NULL;
    uint32_t         count   = 1;
    
    if(attr->id != SAI_ACL_ENTRY_ATTR_ACTION_MIRROR_INGRESS && attr->id != SAI_ACL_ENTRY_ATTR_ACTION_MIRROR_EGRESS) return SAI_STATUS_SUCCESS;

    if(NULL == p_list) /* allocate new memory */
    {
        p = mem_malloc(MEM_APP_ACL_MODULE, sizeof(sai_object_id_t) * count);
        if(NULL == p) return SAI_STATUS_FAILURE;

        sal_memcpy(p, attr->value.aclaction.parameter.objlist.list, sizeof(sai_object_id_t) * count);
        attr_value->value.aclaction.parameter.objlist.list = p;
    }
    else 
    {
        if(NULL != attr->value.aclaction.parameter.objlist.list)
        {
            sal_memcpy(p_list, attr->value.aclaction.parameter.objlist.list, sizeof(sai_object_id_t) * count);
        }
        attr_value->value.aclaction.parameter.objlist.list = p_list;
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t 
ctc_sai_acl_action_map_db_attribute(const sai_attribute_t *attr, ctc_sai_acl_entry_t *pacl_entry)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_attribute_t   *attr_value = NULL;
    sai_attribute_t *attr_list_db = NULL;
    sai_object_id_t *p_list = NULL;

    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, attr->id - SAI_ACL_ENTRY_ATTR_ACTION_START);
    if(NULL == attr_value)
    {
        attr_list_db = mem_malloc(MEM_APP_ACL_MODULE,sizeof(sai_attribute_t));
        sal_memcpy(attr_list_db, attr, sizeof(sai_attribute_t));

        if (FALSE == ctc_vector_add(pacl_entry->acl_action_vector, attr->id - SAI_ACL_ENTRY_ATTR_ACTION_START, attr_list_db))
        {
            mem_free(attr_list_db);
            ret = SAI_STATUS_FAILURE;
            return ret;
        }

        ctc_sai_acl_action_map_db_attribute_set_mirror_value(attr_list_db, attr, (sai_object_id_t *)NULL);
    }
    else
    {
        p_list = attr_value->value.aclaction.parameter.objlist.list;
        sal_memcpy(attr_value, attr, sizeof(sai_attribute_t));
        ctc_sai_acl_action_map_db_attribute_set_mirror_value(attr_value, attr, p_list);
    }

    return ret;
}


sai_status_t
ctc_sai_acl_action_map_db_ctc(ctc_sai_acl_entry_t *pacl_entry, ctc_acl_action_t *action)
{
    sai_attribute_t   *attr_value = NULL;
    uint8_t ctc_sai_set_ctc_color[3] = {CTC_QOS_COLOR_GREEN, CTC_QOS_COLOR_YELLOW, CTC_QOS_COLOR_RED};
    ctc_sai_mirror_entry_t* p_session = NULL;
    ctc_mirror_dest_t mirror_dest;
    int32 ret = SAI_STATUS_SUCCESS;
    uint8 tid = CTC_MAX_LINKAGG_GROUP_NUM;
    uint32 redirect_gport = 0;
    
    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT - SAI_ACL_ENTRY_ATTR_ACTION_START);
    if (attr_value)
    {
        if(SAI_OBJECT_TYPE_PORT == CTC_SAI_OBJECT_TYPE_GET(attr_value->value.aclaction.parameter.oid))
        {
            redirect_gport = CTC_SAI_OBJECT_INDEX_GET(attr_value->value.aclaction.parameter.oid);
            ctc_nh_get_l2uc(redirect_gport, CTC_NH_PARAM_BRGUC_SUB_TYPE_BYPASS, &action->nh_id);
            action->flag |= CTC_ACL_ACTION_FLAG_REDIRECT;
        }

        if(SAI_OBJECT_TYPE_LAG == CTC_SAI_OBJECT_TYPE_GET(attr_value->value.aclaction.parameter.oid))
        {
            ctc_sai_port_objectid_to_gport(attr_value->value.aclaction.parameter.oid, &redirect_gport);
            ctc_nh_get_l2uc(redirect_gport, CTC_NH_PARAM_BRGUC_SUB_TYPE_BYPASS, &action->nh_id);
            action->flag |= CTC_ACL_ACTION_FLAG_REDIRECT;
        }
        
        if(CTC_SAI_OBJECT_TYPE_GET(attr_value->value.aclaction.parameter.oid) == SAI_OBJECT_TYPE_NEXT_HOP)
        {
            action->flag |= CTC_ACL_ACTION_FLAG_REDIRECT;
            action->nh_id = CTC_SAI_OBJECT_INDEX_GET(attr_value->value.aclaction.parameter.oid);
        }
    }
    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_PACKET_ACTION - SAI_ACL_ENTRY_ATTR_ACTION_START);
    if(attr_value)
    {
        if (attr_value->value.aclaction.enable)
        {
            switch(attr_value->value.aclaction.parameter.s32)
            {
            case SAI_PACKET_ACTION_DROP:
                CTC_SET_FLAG(action->flag, CTC_ACL_ACTION_FLAG_DISCARD);
                break;

            case SAI_PACKET_ACTION_FORWARD:
                CTC_UNSET_FLAG(action->flag, CTC_ACL_ACTION_FLAG_DISCARD);
                break;

            case SAI_PACKET_ACTION_TRAP:
                CTC_SET_FLAG(action->flag, CTC_ACL_ACTION_FLAG_REDIRECT);
                action->nh_id = CTC_NH_RESERVED_NHID_FOR_TOCPU;
                break;

            case SAI_PACKET_ACTION_LOG:
                CTC_SET_FLAG(action->flag, CTC_ACL_ACTION_FLAG_COPY_TO_CPU);
                break;

            default:
                break;            
            }
        }
    }
    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_ACTION_FLOOD - SAI_ACL_ENTRY_ATTR_ACTION_START);
    if(attr_value)
    {
    
    }
    
    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_ACTION_COUNTER - SAI_ACL_ENTRY_ATTR_ACTION_START);
    if(attr_value)
    {
        if (attr_value->value.aclaction.enable)
        {
            action->flag |= CTC_ACL_ACTION_FLAG_STATS;
            action->stats_id = CTC_SAI_OBJECT_INDEX_GET(attr_value->value.aclaction.parameter.oid);
        }
    }
    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_ACTION_MIRROR_INGRESS - SAI_ACL_ENTRY_ATTR_ACTION_START);
    if(attr_value)
    {
        if (attr_value->value.aclaction.enable)
        {
            p_session = ctc_sai_mirror_entry_get(attr_value->value.aclaction.parameter.objlist.list[0]);
            if(p_session)
            {
                /*if p_session->sid == 0, the mirror session is not exist*/
                if(0 != p_session->sid)
                {
                    sal_memset(&mirror_dest, 0, sizeof(mirror_dest));
                    mirror_dest.session_id = CTC_SAI_OBJECT_INDEX_GET(p_session->sid);
                    mirror_dest.dir = CTC_INGRESS;
                    mirror_dest.type = CTC_MIRROR_ACLLOG_SESSION;
                    if (p_session->monitor_type == SAI_MIRROR_TYPE_LOCAL)
                    {
                        if (p_session->is_multi_dest_mirror)
                        {
                            mirror_dest.rspan.nh_id = CTC_SAI_OBJECT_INDEX_GET(p_session->nhid);
                            mirror_dest.is_rspan = TRUE;
                            mirror_dest.vlan_valid = FALSE; 
                        }
                        else
                        {
                            /* port */
                            if (SAI_OBJECT_TYPE_PORT == CTC_SAI_OBJECT_TYPE_GET(p_session->monitor_port[0]))
                            {
                                mirror_dest.dest_gport = CTC_SAI_OBJECT_INDEX_GET(p_session->monitor_port[0]);
                            }
                            /* agg */
                            else if (SAI_OBJECT_TYPE_LAG == CTC_SAI_OBJECT_TYPE_GET(p_session->monitor_port[0]))
                            {
                                tid = CTC_SAI_OBJECT_INDEX_GET(p_session->monitor_port[0]);
                                mirror_dest.dest_gport = CTC_MAP_TID_TO_GPORT(tid);
                            }
                            else
                            {
                                return SAI_STATUS_NOT_SUPPORTED;
                            }
                        }
                    }
                    else if (p_session->monitor_type == SAI_MIRROR_TYPE_REMOTE)
                    {            
                        mirror_dest.dest_gport = CTC_SAI_OBJECT_INDEX_GET(p_session->monitor_port[0]);
                        mirror_dest.rspan.nh_id = CTC_SAI_OBJECT_INDEX_GET(p_session->nhid);
                        mirror_dest.is_rspan = TRUE;
                        mirror_dest.vlan_valid = FALSE;
                    }
                    else
                    {
                        return SAI_STATUS_NOT_SUPPORTED;
                    }
                    ret = ctc_mirror_add_session(&mirror_dest);
                    if(ret)
                    {
                        return ret;
                    }
                    action->flag |= CTC_ACL_ACTION_FLAG_RANDOM_LOG;
                    action->log_percent = CTC_LOG_PERCENT_POWER_NEGATIVE_0;
                    action->log_session_id = CTC_SAI_OBJECT_INDEX_GET(attr_value->value.aclaction.parameter.objlist.list[0]);
                }
            }
        }
    }
    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_ACTION_MIRROR_EGRESS - SAI_ACL_ENTRY_ATTR_ACTION_START);
    if(attr_value)
    {
        if (attr_value->value.aclaction.enable)
        {
            p_session = ctc_sai_mirror_entry_get(attr_value->value.aclaction.parameter.objlist.list[0]);
            if(p_session)
            {
                if(0 != p_session->sid)
                {
                    sal_memset(&mirror_dest, 0, sizeof(mirror_dest));
                    mirror_dest.session_id = CTC_SAI_OBJECT_INDEX_GET(p_session->sid);
                    mirror_dest.dir = CTC_EGRESS;
                    mirror_dest.type = CTC_MIRROR_ACLLOG_SESSION;
                    if (p_session->monitor_type == SAI_MIRROR_TYPE_LOCAL)
                    {
                        if (p_session->is_multi_dest_mirror)
                        {
                            mirror_dest.rspan.nh_id = CTC_SAI_OBJECT_INDEX_GET(p_session->nhid);
                            mirror_dest.is_rspan = TRUE;
                            mirror_dest.vlan_valid = FALSE; 
                        }
                        else
                        {
                            /* port */
                            if (SAI_OBJECT_TYPE_PORT == CTC_SAI_OBJECT_TYPE_GET(p_session->monitor_port[0]))
                            {
                                mirror_dest.dest_gport = CTC_SAI_OBJECT_INDEX_GET(p_session->monitor_port[0]);
                            }
                            /* agg */
                            else if (SAI_OBJECT_TYPE_LAG == CTC_SAI_OBJECT_TYPE_GET(p_session->monitor_port[0]))
                            {
                                tid = CTC_SAI_OBJECT_INDEX_GET(p_session->monitor_port[0]);
                                mirror_dest.dest_gport = CTC_MAP_TID_TO_GPORT(tid);
                            }
                            else
                            {
                                return SAI_STATUS_NOT_SUPPORTED;
                            }
                        }
                    }
                    else if (p_session->monitor_type == SAI_MIRROR_TYPE_REMOTE)
                    {            
                        mirror_dest.dest_gport = CTC_SAI_OBJECT_INDEX_GET(p_session->monitor_port[0]);
                        mirror_dest.rspan.nh_id = CTC_SAI_OBJECT_INDEX_GET(p_session->nhid);
                        mirror_dest.is_rspan = TRUE;
                        mirror_dest.vlan_valid = FALSE;
                    }
                    else
                    {
                        return SAI_STATUS_NOT_SUPPORTED;
                    }
                    ret = ctc_mirror_add_session(&mirror_dest);
                    if(ret)
                    {
                        return ret;
                    }
                    action->flag |= CTC_ACL_ACTION_FLAG_RANDOM_LOG;
                    action->log_percent = CTC_LOG_PERCENT_POWER_NEGATIVE_0;
                    action->log_session_id = CTC_SAI_OBJECT_INDEX_GET(attr_value->value.aclaction.parameter.objlist.list[0]);
                }
            }
        }
    }
    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_ACTION_SET_POLICER - SAI_ACL_ENTRY_ATTR_ACTION_START);
    if(attr_value)
    {
        if (attr_value->value.aclaction.enable)
        {
            action->flag |= CTC_ACL_ACTION_FLAG_MICRO_FLOW_POLICER;
            action->micro_policer_id = CTC_SAI_OBJECT_INDEX_GET(attr_value->value.aclaction.parameter.oid);
        }
    }
    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_ACTION_DECREMENT_TTL - SAI_ACL_ENTRY_ATTR_ACTION_START);
    if(attr_value)
    {
    
    }
    /* SYSTEM MODIFIED BEGIN: fix gb tc+color bug add by wangqj at 2016/8/11 */
//    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_ACTION_SET_TC - SAI_ACL_ENTRY_ATTR_ACTION_START);
//    if(attr_value)
//    {
//        if(attr_value->value.aclaction.enable)
//        {
//            action->flag |= CTC_ACL_ACTION_FLAG_PRIORITY;
//            action->priority = (attr_value->value.aclaction.parameter.u8) * 8;
//        }
//    }
//    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_ACTION_SET_COLOR - SAI_ACL_ENTRY_ATTR_ACTION_START);
//    if(attr_value)
//    {
//        if(attr_value->value.aclaction.enable)
//        {
//            action->flag |= CTC_ACL_ACTION_FLAG_COLOR;
//            action->color = ctc_sai_set_ctc_color[attr_value->value.aclaction.parameter.s32];
//        }
//    }
    /* END: fix gb tc+color bug add by wangqj at 2016/8/11 */
    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_ACTION_SET_INNER_VLAN_ID - SAI_ACL_ENTRY_ATTR_ACTION_START);
    if(attr_value)
    {
        if(attr_value->value.aclaction.enable)
        {
            action->flag |= CTC_ACL_ACTION_FLAG_VLAN_EDIT;
#ifdef GREATBELT
            action->vlan_edit.ctag_op = CTC_ACL_VLAN_TAG_OP_REP;
#else
            action->vlan_edit.ctag_op = CTC_ACL_VLAN_TAG_OP_REP_OR_ADD;
#endif
            action->vlan_edit.cvid_sl = CTC_ACL_VLAN_TAG_SL_NEW;
            action->vlan_edit.cvid_new = attr_value->value.aclaction.parameter.u16;
        }
    }
    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_ACTION_SET_INNER_VLAN_PRI - SAI_ACL_ENTRY_ATTR_ACTION_START);
    if(attr_value)
    {
        if(attr_value->value.aclaction.enable)
        {
            action->flag |= CTC_ACL_ACTION_FLAG_VLAN_EDIT;
#ifdef GREATBELT
            action->vlan_edit.ctag_op = CTC_ACL_VLAN_TAG_OP_REP;
#else
            action->vlan_edit.ctag_op = CTC_ACL_VLAN_TAG_OP_REP_OR_ADD;
#endif
            action->vlan_edit.ccos_sl = CTC_ACL_VLAN_TAG_SL_NEW;
            action->vlan_edit.ccos_new= attr_value->value.aclaction.parameter.u8;
        }
    }
    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_ACTION_SET_OUTER_VLAN_ID - SAI_ACL_ENTRY_ATTR_ACTION_START);
    if(attr_value)
    {
        if(attr_value->value.aclaction.enable)
        {
            action->flag |= CTC_ACL_ACTION_FLAG_VLAN_EDIT;
#ifdef GREATBELT
            action->vlan_edit.stag_op = CTC_ACL_VLAN_TAG_OP_REP;
#else
            action->vlan_edit.stag_op = CTC_ACL_VLAN_TAG_OP_REP_OR_ADD;
#endif
            action->vlan_edit.svid_sl = CTC_ACL_VLAN_TAG_SL_NEW;
            action->vlan_edit.svid_new = attr_value->value.aclaction.parameter.u16;
        }
    }
    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_ACTION_SET_OUTER_VLAN_PRI - SAI_ACL_ENTRY_ATTR_ACTION_START);
    if(attr_value)
    {
        if(attr_value->value.aclaction.enable)
        {
            action->flag |= CTC_ACL_ACTION_FLAG_VLAN_EDIT;
#ifdef GREATBELT
            action->vlan_edit.stag_op = CTC_ACL_VLAN_TAG_OP_REP;
#else
            action->vlan_edit.stag_op = CTC_ACL_VLAN_TAG_OP_REP_OR_ADD;
#endif
            action->vlan_edit.scos_sl = CTC_ACL_VLAN_TAG_SL_NEW;
            action->vlan_edit.scos_new= attr_value->value.aclaction.parameter.u8;
        }
    }
    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_ACTION_SET_DSCP - SAI_ACL_ENTRY_ATTR_ACTION_START);
    if(attr_value)
    {
        if(attr_value->value.aclaction.enable)
        {
            action->flag |= CTC_ACL_ACTION_FLAG_DSCP;
            action->dscp = attr_value->value.aclaction.parameter.u8;
        }
    }
    /* SYSTEM MODIFIED BEGIN: fix gb tc+color bug add by wangqj at 2016/8/11 */
    attr_value = ctc_vector_get(pacl_entry->acl_action_vector, SAI_ACL_ENTRY_ATTR_ACTION_SET_TC_AND_COLOR - SAI_ACL_ENTRY_ATTR_ACTION_START);
    if(attr_value)
    {
        if(attr_value->value.aclaction.enable)
        {
            action->flag |= CTC_ACL_ACTION_FLAG_PRIORITY_AND_COLOR;

            action->priority = (attr_value->value.aclaction.parameter.tcandcolor.tc) * 8;
            action->color = ctc_sai_set_ctc_color[attr_value->value.aclaction.parameter.tcandcolor.color];
        }
    }
    /* END: fix gb tc+color bug add by wangqj at 2016/8/11 */
    return SAI_STATUS_SUCCESS;
    
}

/*
* Routine Description:
*   Set ACL entry attribute
*
* Arguments:
*    [in] acl_entry_id - the acl entry id
*    [in] attr - attribute
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t sai_set_acl_entry_attribute(
    _In_ sai_object_id_t acl_entry_id,
    _In_ const sai_attribute_t *attr)
{
    CTC_SAI_DEBUG_FUNC();
    ctc_sai_acl_entry_t         *pacl_entry = NULL;
    sai_status_t                ret = SAI_STATUS_SUCCESS;
    ctc_acl_action_t action;
    uint32 i = 0;
    pacl_entry = ctc_sai_acl_db_get_entry_by_oid(acl_entry_id);
    if(NULL == pacl_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }
    if(SAI_ACL_ENTRY_ATTR_PRIORITY == attr->id)
    {
        for(i =0; i < pacl_entry->ctc_entry_id_cnt; i ++)
        {
            ret += ctc_acl_set_entry_priority(CTC_SAI_OBJECT_INDEX_GET(pacl_entry->ctc_entry_id_list[i]), attr->value.u32);
        }
        pacl_entry->priority = attr->value.u32;

        return ret;
    }
    if(SAI_ACL_ENTRY_ATTR_ACTION_SET_POLICER == attr->id)
    {
        if (attr->value.aclaction.enable)
        {
            ctc_sai_policer_acl_set_policer(CTC_SAI_OBJECT_INDEX_GET(attr->value.aclaction.parameter.oid), CTC_SAI_OBJECT_INDEX_GET(acl_entry_id), TRUE);
        }
        else
        {
            ctc_sai_policer_acl_set_policer(CTC_SAI_OBJECT_INDEX_GET(attr->value.aclaction.parameter.oid), CTC_SAI_OBJECT_INDEX_GET(acl_entry_id), FALSE);
        }
    }
    sal_memset(&action, 0x0, sizeof(ctc_acl_action_t));
    ctc_sai_acl_action_map_db_attribute(attr, pacl_entry);
    ctc_sai_acl_action_map_db_ctc(pacl_entry, &action);

    for(i =0; i < pacl_entry->ctc_entry_id_cnt; i ++)
    {
        ret += ctc_acl_update_action(CTC_SAI_OBJECT_INDEX_GET(pacl_entry->ctc_entry_id_list[i]), &action);
    }
    return ret;
}

/*
* Routine Description:
*   Get ACL table attribute
*
* Arguments:
*    [in] acl_table_id - acl table id
*    [in] attr_count - number of attributes
*    [Out] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/

sai_status_t  sai_get_acl_entry_attribute (
    _In_ sai_object_id_t acl_entry_id,
    _In_ uint32_t attr_count,
    _Out_ sai_attribute_t *attr_list)
{
    sai_status_t                ret = SAI_STATUS_SUCCESS;
    sai_attribute_t             *attr = NULL;
    uint32_t                    attr_idx = 0;
    ctc_sai_acl_entry_t         *pacl_entry = NULL;

    CTC_SAI_DEBUG_FUNC();
    sai_get_acl_entry_attribute_debug_param(attr_count, attr_list);

    pacl_entry = ctc_sai_acl_db_get_entry_by_oid(acl_entry_id);
    if(NULL == pacl_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        
        if (SAI_ACL_ENTRY_ATTR_ADMIN_STATE == attr->id)
        {
            attr->value.booldata = pacl_entry->enable;
        }
        else if (SAI_ACL_ENTRY_ATTR_PRIORITY == attr->id)
        {
            attr->value.u32 = pacl_entry->priority;
        }

    }

    return ret;
}

sai_status_t
ctc_acl_counter_add_entry(sai_acl_stage_t acl_stage, sai_uint32_t acl_priority, uint32 *counter_id)
{
    ctc_stats_statsid_t stats;
    int32_t             sdk_ret  = 0;

    sal_memset(&stats,0,sizeof(stats));
    stats.statsid.acl_priority = acl_priority & 0xFF;
    stats.type                 = CTC_STATS_STATSID_TYPE_ACL;
    if (SAI_ACL_STAGE_INGRESS == acl_stage)
    {
        stats.dir = CTC_INGRESS;
    }
    else
    {
        stats.dir = CTC_EGRESS;
    }

    CTC_SAI_ERROR_GOTO(ctc_stats_create_statsid(&stats), sdk_ret, out);
    if(SAI_STATUS_SUCCESS == sdk_ret)
    {
        *counter_id = stats.stats_id;
        ctc_stats_clear_stats(stats.stats_id);
    }

out:
    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

/*
* Routine Description:
*   Create an ACL counter
*
* Arguments:
*   [out] acl_counter_id - the acl counter id
*   [in] attr_count - number of attributes
*   [in] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_create_acl_counter(
    _Out_ sai_object_id_t *acl_counter_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    ctc_sai_acl_table_t *table_entry = NULL;
    sai_status_t ret = SAI_STATUS_SUCCESS;
    uint32 counter_id = 0;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_DEBUG("in:attr_count %u", attr_count);

    CTC_SAI_PTR_VALID_CHECK(acl_counter_id);
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    /* 1. get stage */
    table_entry = ctc_sai_acl_db_get_table_by_oid(
        attr_list[SAI_ACL_COUNTER_ATTR_TABLE_ID].value.oid);
    if (NULL == table_entry)
    {
        return SAI_STATUS_INVALID_OBJECT_ID;
    }

    /* 2. get stage */
    ret = ctc_acl_counter_add_entry(table_entry->stage, table_entry->priority, &counter_id);
    if (ret)
    {
        return ret;
    }

    *acl_counter_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ACL_COUNTER, counter_id);
    CTC_SAI_DEBUG("out:acl_counter_id 0x%llx", (*acl_counter_id));
    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*   Delete an ACL counter
*
* Arguments:
 *  [in] acl_counter_id - the acl counter id
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_delete_acl_counter(
    _In_ sai_object_id_t acl_counter_id)
{
    CTC_SAI_DEBUG_FUNC();
    
    return ctc_stats_destroy_statsid(CTC_SAI_OBJECT_INDEX_GET(acl_counter_id));
}

/*
* Routine Description:
*   Set ACL counter attribute
*
* Arguments:
*    [in] acl_counter_id - the acl counter id
*    [in] attr - attribute
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_set_acl_counter_attribute(
    _In_ sai_object_id_t acl_counter_id,
    _In_ const sai_attribute_t *attr)
{
    sai_status_t      ret      = SAI_STATUS_SUCCESS;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_DEBUG("in:acl_counter_id 0x%llx, attribute_id %u", acl_counter_id, attr->id);

    switch(attr->id)
    {
    case SAI_ACL_COUNTER_ATTR_TABLE_ID:
    case SAI_ACL_COUNTER_ATTR_ENABLE_PACKET_COUNT:
    case SAI_ACL_COUNTER_ATTR_ENABLE_BYTE_COUNT:
        return SAI_STATUS_NOT_SUPPORTED;
        break;

    case SAI_ACL_COUNTER_ATTR_PACKETS:
    case SAI_ACL_COUNTER_ATTR_BYTES:
        ret = ctc_stats_clear_stats(CTC_SAI_OBJECT_INDEX_GET(acl_counter_id));
        break;
    }

    return ret;
}

/*
* Routine Description:
*   Get ACL counter attribute
*
* Arguments:
*    [in] acl_counter_id - acl counter id
*    [in] attr_count - number of attributes
*    [Out] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_get_acl_counter_attribute(
    _In_ sai_object_id_t acl_counter_id,
    _In_ uint32_t attr_count,
    _Out_ sai_attribute_t *attr_list)
{
    sai_attribute_t*  attr     = NULL;
    uint32_t          attr_idx = 0;
    sai_status_t      ret      = SAI_STATUS_SUCCESS;
    ctc_stats_basic_t stats_count;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    for (attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        ret = ctc_sai_attr_check_read_attr(g_acl_count_attr_entries,attr);
        if(ret != SAI_STATUS_SUCCESS)
        {
            return ret + attr_idx;
        }

        switch(attr->id)
        {
        case SAI_ACL_COUNTER_ATTR_TABLE_ID:
            break;

        case SAI_ACL_COUNTER_ATTR_ENABLE_PACKET_COUNT:
            break;

        case SAI_ACL_COUNTER_ATTR_ENABLE_BYTE_COUNT:
            break;

        case SAI_ACL_COUNTER_ATTR_PACKETS:
            sal_memset(&stats_count, 0, sizeof(stats_count));
            ret = ctc_stats_get_stats(CTC_SAI_OBJECT_INDEX_GET(acl_counter_id), &stats_count);
            attr->value.u64 = stats_count.packet_count;
            break;

        case SAI_ACL_COUNTER_ATTR_BYTES:
            sal_memset(&stats_count, 0, sizeof(stats_count));
            ret = ctc_stats_get_stats(CTC_SAI_OBJECT_INDEX_GET(acl_counter_id), &stats_count);
            attr->value.u64 = stats_count.byte_count;
            break;
        }

        if (ret != SAI_STATUS_SUCCESS)
        {
            break;
        }
    }

    ctc_sai_get_acl_counter_attribute_debug_param(acl_counter_id, attr_count, attr_list);
    return ret;
}

#define ________SAI_ACL_MAPPING_FUNC
#if 0
inline sai_status_t 
_acl_mapping_mac_da(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_MAC_DA);
        sal_memcpy(acl_entry->key.u.ipv4_key.mac_da, attr_value->value.aclfield.data.mac, sizeof(sai_mac_t));
        sal_memcpy(acl_entry->key.u.ipv4_key.mac_da_mask, attr_value->value.aclfield.mask.mac, sizeof(sai_mac_t));
        SAI_ACL_MAC_WILDCARD_MASK(acl_entry->key.u.ipv4_key.mac_da_mask);
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_MAC_DA);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_mac_sa(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_MAC_SA);
        sal_memcpy(acl_entry->key.u.ipv4_key.mac_sa, attr_value->value.aclfield.data.mac, sizeof(sai_mac_t));
        sal_memcpy(acl_entry->key.u.ipv4_key.mac_sa_mask, attr_value->value.aclfield.mask.mac, sizeof(sai_mac_t));
        SAI_ACL_MAC_WILDCARD_MASK(acl_entry->key.u.ipv4_key.mac_sa_mask);
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_MAC_SA);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_ip_sa(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        if(IS_EQ_WILDCARD_MASK_32(attr_value->value.aclfield.mask.ip4)){
            return SAI_STATUS_SUCCESS;
        }
#ifdef GOLDENGATE
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
        acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_IP_SA);
        acl_entry->key.u.ipv4_key.ip_sa = attr_value->value.aclfield.data.ip4;
        acl_entry->key.u.ipv4_key.ip_sa_mask = attr_value->value.aclfield.mask.ip4;
        SAI_ACL_WILDCARD_MASK(acl_entry->key.u.ipv4_key.ip_sa_mask);
    }
    else
    {
#ifdef GOLDENGATE
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_IP_SA);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_ip_da(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        if(IS_EQ_WILDCARD_MASK_32(attr_value->value.aclfield.mask.ip4)){
            return SAI_STATUS_SUCCESS;
        }
#ifdef GOLDENGATE
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
        acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_IP_DA);
        acl_entry->key.u.ipv4_key.ip_da = attr_value->value.aclfield.data.ip4;
        acl_entry->key.u.ipv4_key.ip_da_mask = attr_value->value.aclfield.mask.ip4;
        SAI_ACL_WILDCARD_MASK(acl_entry->key.u.ipv4_key.ip_da_mask);
    }
    else
    {
#ifdef GOLDENGATE
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_IP_DA);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_ovlan(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_SVLAN);
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_STAG_VALID);
        acl_entry->key.u.ipv4_key.stag_valid = TRUE;
        acl_entry->key.u.ipv4_key.svlan = attr_value->value.aclfield.data.u16;
        acl_entry->key.u.ipv4_key.svlan_mask = attr_value->value.aclfield.mask.u16;
        SAI_ACL_VLAN_WILDCARD_MASK(acl_entry->key.u.ipv4_key.svlan_mask);
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_SVLAN);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_ovlan_cos(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_STAG_COS);
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_STAG_VALID);
        acl_entry->key.u.ipv4_key.stag_valid = TRUE;
        acl_entry->key.u.ipv4_key.stag_cos = attr_value->value.aclfield.data.u8;
        acl_entry->key.u.ipv4_key.stag_cos_mask = attr_value->value.aclfield.mask.u8;
        SAI_ACL_COS_WILDCARD_MASK(acl_entry->key.u.ipv4_key.stag_cos_mask);
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_STAG_COS);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_ivlan(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_CVLAN);
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_CTAG_VALID);
        acl_entry->key.u.ipv4_key.ctag_valid = TRUE;
        acl_entry->key.u.ipv4_key.cvlan = attr_value->value.aclfield.data.u16;
        acl_entry->key.u.ipv4_key.cvlan_mask = attr_value->value.aclfield.mask.u16;
        SAI_ACL_VLAN_WILDCARD_MASK(acl_entry->key.u.ipv4_key.cvlan_mask);
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_CVLAN);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_ivlan_cos(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_CTAG_COS);
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_CTAG_VALID);
        acl_entry->key.u.ipv4_key.ctag_valid = TRUE;
        acl_entry->key.u.ipv4_key.ctag_cos = attr_value->value.aclfield.data.u8;
        acl_entry->key.u.ipv4_key.ctag_cos_mask = attr_value->value.aclfield.mask.u8;
        SAI_ACL_COS_WILDCARD_MASK(acl_entry->key.u.ipv4_key.ctag_cos_mask);
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_CTAG_COS);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_ether_type(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
#ifdef GOLDENGATE
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        if (0x0800 == attr_value->value.aclfield.data.u16 
            && 0 == attr_value->value.aclfield.mask.u16)
        {
#ifdef GOLDENGATE
            acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
            acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
#else
            CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_IPV4_PACKET);
            acl_entry->key.u.ipv4_key.ipv4_packet = 1;
#endif
        }
        else if (0x0806 == attr_value->value.aclfield.data.u16 
            && 0 == attr_value->value.aclfield.mask.u16)
        {
#ifdef GOLDENGATE
            acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_ARP;
            acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
#else
            CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_ARP_PACKET);
            acl_entry->key.u.ipv4_key.arp_packet = 1;
#endif
        }
#ifdef GOLDENGATE
        else if (0x86DD == attr_value->value.aclfield.data.u16 
            && 0 == attr_value->value.aclfield.mask.u16)
        {
            acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_IPV6;
            acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        }
        else if (0x8847 == attr_value->value.aclfield.data.u16 
            && 0 == attr_value->value.aclfield.mask.u16)
        {
            acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_MPLS;
            acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        }
        else if (0x8848 == attr_value->value.aclfield.data.u16 
            && 0 == attr_value->value.aclfield.mask.u16)
        {
            acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_MPLS_MCAST;
            acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        }
        else if (0x8906 == attr_value->value.aclfield.data.u16 
            && 0 == attr_value->value.aclfield.mask.u16)
        {
            acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_FCOE;
            acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        }
        else if (0x22F3 == attr_value->value.aclfield.data.u16 
            && 0 == attr_value->value.aclfield.mask.u16)
        {
            acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_TRILL;
            acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        }
        else if (0x8902 == attr_value->value.aclfield.data.u16 
            && 0 == attr_value->value.aclfield.mask.u16)
        {
            acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_ETHER_OAM;
            acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        }
        else if (0x88E7 == attr_value->value.aclfield.data.u16 
            && 0 == attr_value->value.aclfield.mask.u16)
        {
            acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_CMAC;
            acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        }
        else if (0x8809 == attr_value->value.aclfield.data.u16 
            && 0 == attr_value->value.aclfield.mask.u16)
        {
            acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_SLOW_PROTO;
            acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        }
        else if (0x88F7 == attr_value->value.aclfield.data.u16 
            && 0 == attr_value->value.aclfield.mask.u16)
        {
            acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_PTP;
            acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        }
#endif
        else
        {
            acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_NONE;
            acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
            CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_ETH_TYPE);
        }
        acl_entry->key.u.ipv4_key.eth_type = attr_value->value.aclfield.data.u16;
        acl_entry->key.u.ipv4_key.eth_type_mask = attr_value->value.aclfield.mask.u16;
        SAI_ACL_WILDCARD_MASK(acl_entry->key.u.ipv4_key.eth_type_mask);
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_ETH_TYPE);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_l4_srcport(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_L4_SRC_PORT);
#ifdef SAI_DEFINE_STANDAND_ACL_CTC
        if (attr_value->value.aclfield.data.u16 == attr_value->value.aclfield.mask.u16)
        {
            acl_entry->key.u.ipv4_key.l4_src_port_use_mask = 1;
            acl_entry->key.u.ipv4_key.l4_src_port_0 = attr_value->value.aclfield.data.u16;
            acl_entry->key.u.ipv4_key.l4_src_port_1 = 0xffff;
        }
        else
        {
            acl_entry->key.u.ipv4_key.l4_src_port_use_mask = 0;
            acl_entry->key.u.ipv4_key.l4_src_port_0 = attr_value->value.aclfield.data.u16;
            acl_entry->key.u.ipv4_key.l4_src_port_1 = attr_value->value.aclfield.mask.u16;
        }
#else 
        acl_entry->key.u.ipv4_key.l4_src_port_use_mask = 1;
        acl_entry->key.u.ipv4_key.l4_src_port_0 = attr_value->value.aclfield.data.u16;
        acl_entry->key.u.ipv4_key.l4_src_port_1 = attr_value->value.aclfield.mask.u16;
        SAI_ACL_WILDCARD_MASK(acl_entry->key.u.ipv4_key.l4_src_port_1);
#endif
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_L4_SRC_PORT);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_l4_dstport(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_L4_DST_PORT);
#ifdef SAI_DEFINE_STANDAND_ACL_CTC
        if (attr_value->value.aclfield.data.u16 == attr_value->value.aclfield.mask.u16)
        {
            acl_entry->key.u.ipv4_key.l4_dst_port_use_mask = 1;
            acl_entry->key.u.ipv4_key.l4_dst_port_0 = attr_value->value.aclfield.data.u16;
            acl_entry->key.u.ipv4_key.l4_dst_port_1 = 0xffff;
            
            pacl_db->l4_dst_port = attr_value->value.aclfield.data.u16;
            pacl_db->l4_dst_port_mask = 0xffff;
        }
        else
        {
            acl_entry->key.u.ipv4_key.l4_dst_port_use_mask = 0;
            acl_entry->key.u.ipv4_key.l4_dst_port_0 = attr_value->value.aclfield.data.u16;
            acl_entry->key.u.ipv4_key.l4_dst_port_1 = attr_value->value.aclfield.mask.u16;
        }
#else 
        acl_entry->key.u.ipv4_key.l4_dst_port_use_mask = 1;
        acl_entry->key.u.ipv4_key.l4_dst_port_0 = attr_value->value.aclfield.data.u16;
        acl_entry->key.u.ipv4_key.l4_dst_port_1 = attr_value->value.aclfield.mask.u16;
        SAI_ACL_WILDCARD_MASK(acl_entry->key.u.ipv4_key.l4_dst_port_1);
#endif
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_L4_DST_PORT);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_ip_protocol(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        if(IS_EQ_WILDCARD_MASK_8(attr_value->value.aclfield.mask.u8)){
            return SAI_STATUS_SUCCESS;
        }
        
#ifdef GOLDENGATE
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        /* SDK bug, if l4_protocol == 0 && l4_protocol_mask == 255 then ,not set flag l4_protocol */
        if(attr_value->value.aclfield.mask.u8 != 0xFF ||
           acl_entry->key.u.ipv4_key.l4_protocol != 0)
       {
            acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
            acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
            CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L4_PROTOCOL);
            acl_entry->key.u.ipv4_key.l4_protocol = attr_value->value.aclfield.data.u8;
            acl_entry->key.u.ipv4_key.l4_protocol_mask = attr_value->value.aclfield.mask.u8;
            SAI_ACL_WILDCARD_MASK(acl_entry->key.u.ipv4_key.l4_protocol_mask);

            pacl_db->l4_protocol = acl_entry->key.u.ipv4_key.l4_protocol;
            pacl_db->l4_protocol_mask = acl_entry->key.u.ipv4_key.l4_protocol_mask;
        }
    }
    else
    {
#ifdef GOLDENGATE
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L4_PROTOCOL);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_ip_dscp(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        if(IS_EQ_WILDCARD_MASK_8(attr_value->value.aclfield.mask.u8)){
            return SAI_STATUS_SUCCESS;
        }
#ifdef GOLDENGATE
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
        acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_DSCP);
        acl_entry->key.u.ipv4_key.dscp = attr_value->value.aclfield.data.u8;
        acl_entry->key.u.ipv4_key.dscp_mask = attr_value->value.aclfield.mask.u8;
        SAI_ACL_DSCP_WILDCARD_MASK(acl_entry->key.u.ipv4_key.dscp_mask);
    }
    else
    {
#ifdef GOLDENGATE
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_DSCP);
    }

    return SAI_STATUS_SUCCESS;
}


inline sai_status_t 
_acl_mapping_ip_precedence(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        if(IS_EQ_WILDCARD_MASK_8(attr_value->value.aclfield.mask.u8)){
            return SAI_STATUS_SUCCESS;
        }
#ifdef GOLDENGATE
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
        acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_PRECEDENCE);
        acl_entry->key.u.ipv4_key.dscp = attr_value->value.aclfield.data.u8;
        acl_entry->key.u.ipv4_key.dscp_mask = attr_value->value.aclfield.mask.u8;
        SAI_ACL_COS_WILDCARD_MASK(acl_entry->key.u.ipv4_key.dscp_mask);
    }
    else
    {
#ifdef GOLDENGATE
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_PRECEDENCE);
    }

    return SAI_STATUS_SUCCESS;
}


inline sai_status_t 
_acl_mapping_ip_frag(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    ctc_parser_global_cfg_t cfg;

    sal_memset(&cfg,0,sizeof(ctc_parser_global_cfg_t));
    if (attr_value->value.aclfield.enable)
    {
#ifdef GOLDENGATE
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
        acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_IP_FRAG);
        acl_entry->key.u.ipv4_key.ip_frag = attr_value->value.aclfield.data.u8;
        if (acl_entry->key.u.ipv4_key.ip_frag == CTC_IP_FRAG_SMALL)
        {
            cfg.small_frag_offset = 3;
            ctc_parser_set_global_cfg(&cfg);
        }
    }
    else
    {
#ifdef GOLDENGATE
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_IP_FRAG);
        cfg.small_frag_offset = 0;
        ctc_parser_set_global_cfg(&cfg);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_igmp_type(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_IGMP_TYPE);
        acl_entry->key.u.ipv4_key.igmp_type = attr_value->value.aclfield.data.u8;
        acl_entry->key.u.ipv4_key.igmp_type_mask = 0xff;
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_SUB_FLAG_IGMP_TYPE);
    }
 
    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_icmp_type(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_ICMP_TYPE);
        acl_entry->key.u.ipv4_key.icmp_type = attr_value->value.aclfield.data.u8;
        acl_entry->key.u.ipv4_key.icmp_type_mask = 0xff;
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_ICMP_TYPE);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_icmp_code(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_ICMP_CODE);
        acl_entry->key.u.ipv4_key.icmp_code = attr_value->value.aclfield.data.u8;
        acl_entry->key.u.ipv4_key.icmp_code_mask = 0xff;
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_ICMP_CODE);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_tcp_flags(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_TCP_FLAGS);
        acl_entry->key.u.ipv4_key.tcp_flags_match_any = attr_value->value.aclfield.data.u8;
        acl_entry->key.u.ipv4_key.tcp_flags = attr_value->value.aclfield.mask.u8;;
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.sub_flag, CTC_ACL_IPV4_KEY_SUB_FLAG_TCP_FLAGS);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_ip_options(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
#ifdef GOLDENGATE
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
        acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_IP_OPTION);
        acl_entry->key.u.ipv4_key.ip_option = attr_value->value.aclfield.data.u8;
    }
    else
    {
#ifdef GOLDENGATE
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_IP_OPTION);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_ip_routed_packet(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
#ifdef GOLDENGATE
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        acl_entry->key.u.ipv4_key.l3_type = CTC_PARSER_L3_TYPE_IPV4;
        acl_entry->key.u.ipv4_key.l3_type_mask = 0xf;
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_ROUTED_PACKET);
        acl_entry->key.u.ipv4_key.routed_packet = attr_value->value.aclfield.data.u8;
    }
    else
    {
#ifdef GOLDENGATE
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_L3_TYPE);
#endif
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_ROUTED_PACKET);
    }

    return SAI_STATUS_SUCCESS;
}

inline  sai_status_t 
_acl_mapping_udf_match(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    sai_uint8_t i = 0;
    sai_uint32_t udf_value;
    sai_uint32_t udf_mask;
    
    if (attr_value->value.aclfield.enable)
    {
        CTC_SET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_UDF);
        udf_value = attr_value->value.aclfield.data.u32;
        udf_mask = ~attr_value->value.aclfield.mask.u32;
        for (i = 0; i < CTC_ACL_UDF_BYTE_NUM; i++)
        {
            acl_entry->key.u.ipv4_key.udf[i] = (udf_value >> (8*(CTC_ACL_UDF_BYTE_NUM-1-i)))&0xf;
            acl_entry->key.u.ipv4_key.udf_mask[i] = (udf_mask >> (8*(CTC_ACL_UDF_BYTE_NUM-1-i)))&0xf;
        }
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->key.u.ipv4_key.flag, CTC_ACL_IPV4_KEY_FLAG_UDF);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_udf_type(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        acl_entry->key.u.ipv4_key.udf_type = (attr_value->value.aclfield.data.u8 - 1) ? CTC_PARSER_UDF_TYPE_L4_UDF: CTC_PARSER_UDF_TYPE_L3_UDF;
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_l4_vxlan_vni(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclfield.enable)
    {
        pacl_db->l4_vxlan_vni       = attr_value->value.aclfield.data.u32;
        pacl_db->l4_vxlan_vni_mask  = attr_value->value.aclfield.mask.u32;
        pacl_db->l4_vxlan_vni_en    = TRUE;
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_none(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_mapping_unsupport(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value)
{
    return SAI_STATUS_NOT_SUPPORTED;
}
#endif
#define ________SAI_ACL_ACTION_FUNC
inline sai_status_t 
_acl_action_packet_action(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclaction.enable)
    {
        switch(attr_value->value.aclaction.parameter.s32)
        {
        case SAI_PACKET_ACTION_DROP:
            CTC_SET_FLAG(acl_entry->action.flag, CTC_ACL_ACTION_FLAG_DISCARD);
            break;

        case SAI_PACKET_ACTION_LOG:
            CTC_SET_FLAG(acl_entry->action.flag, CTC_ACL_ACTION_FLAG_RANDOM_LOG);
            break;

        case SAI_PACKET_ACTION_FORWARD:
            CTC_UNSET_FLAG(acl_entry->action.flag, CTC_ACL_ACTION_FLAG_DISCARD);
            break;

        case SAI_PACKET_ACTION_TRAP:
            CTC_SET_FLAG(acl_entry->action.flag, CTC_ACL_ACTION_FLAG_REDIRECT);
            acl_entry->action.nh_id = CTC_NH_RESERVED_NHID_FOR_TOCPU;
            break;

        case SAI_PACKET_ACTION_COPY:
            CTC_SET_FLAG(acl_entry->action.flag, CTC_ACL_ACTION_FLAG_COPY_TO_CPU);
            break;

        default:
            break;            
        }
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_action_mirror(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{  
    CTC_SAI_DEBUG_FUNC();

    if (attr_value->value.aclaction.enable)
    {
        if(attr_value->value.aclaction.parameter.objlist.count > 1)
        {
            return SAI_STATUS_FAILURE;
        }
        acl_entry->action.flag |= CTC_ACL_ACTION_FLAG_RANDOM_LOG;
        acl_entry->action.log_percent = CTC_LOG_PERCENT_POWER_NEGATIVE_0;
        acl_entry->action.log_session_id = CTC_SAI_OBJECT_INDEX_GET(attr_value->value.aclaction.parameter.objlist.list[0]);
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->action.flag, CTC_ACL_ACTION_FLAG_RANDOM_LOG);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_action_counter(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclaction.enable)
    {
        acl_entry->action.flag |= CTC_ACL_ACTION_FLAG_STATS;
        acl_entry->action.stats_id = CTC_SAI_OBJECT_INDEX_GET(attr_value->value.aclaction.parameter.oid);
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->action.flag, CTC_ACL_ACTION_FLAG_STATS);
    }

    return SAI_STATUS_SUCCESS;
}


inline sai_status_t 
_acl_action_settc(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclaction.enable)
    {
        acl_entry->action.flag |= CTC_ACL_ACTION_FLAG_PRIORITY;
        acl_entry->action.priority = (attr_value->value.aclaction.parameter.u32)*8 - 1;
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->action.flag, CTC_ACL_ACTION_FLAG_PRIORITY);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_action_setcolor(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    CTC_SAI_DEBUG_FUNC();
    if (attr_value->value.aclaction.enable)
    {
        acl_entry->action.flag |= CTC_ACL_ACTION_FLAG_COLOR;
        acl_entry->action.color = (attr_value->value.aclaction.parameter.u32)*8 - 1;
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->action.flag, CTC_ACL_ACTION_FLAG_COLOR);
    }

    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_action_set_policer(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    if (attr_value->value.aclaction.enable)
    {
        acl_entry->action.flag |= CTC_ACL_ACTION_FLAG_MICRO_FLOW_POLICER;
        acl_entry->action.micro_policer_id = CTC_SAI_OBJECT_INDEX_GET(attr_value->value.aclaction.parameter.oid);
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->action.flag, CTC_ACL_ACTION_FLAG_MICRO_FLOW_POLICER);
    }
    return SAI_STATUS_SUCCESS;
}


inline sai_status_t 
_acl_action_set_redirect_action(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
#ifdef TAPPRODUCT
    ctc_sai_tap_info_t* tap_info = NULL;
#endif
    if (attr_value->value.aclaction.enable)
    { 
#ifdef TAPPRODUCT    
        if(sai_object_type_query(attr_value->value.aclaction.parameter.oid) == SAI_OBJECT_TYPE_TAP_GROUP){
            tap_info = ctc_sai_tap_get_by_oid(attr_value->value.aclaction.parameter.oid);
            if (!tap_info)
            {
                return SAI_STATUS_FAILURE;
            }
            pacl_db->ptap_info = tap_info;
            pacl_db->tap_group_id = attr_value->value.aclaction.parameter.oid;
        }else{
#endif        
            acl_entry->action.flag |= CTC_ACL_ACTION_FLAG_REDIRECT;
            if(CTC_SAI_OBJECT_TYPE_GET(attr_value->value.aclaction.parameter.oid) == SAI_OBJECT_TYPE_NEXT_HOP)
            {
                acl_entry->action.nh_id = CTC_SAI_OBJECT_INDEX_GET(attr_value->value.aclaction.parameter.oid);
            }
#ifdef TAPPRODUCT
        }
#endif        
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->action.flag, CTC_ACL_ACTION_FLAG_REDIRECT);
    }
    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_action_set_redirect_truncation(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
#ifdef TAPPRODUCT
    if (attr_value->value.aclaction.enable)
    {
        pacl_db->trunction_en = TRUE;
    }
    else
    {
        pacl_db->trunction_en = FALSE;
    }
#endif
    return SAI_STATUS_SUCCESS;
}


inline sai_status_t 
_acl_action_set_redirect_vlan(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    if (attr_value->value.aclaction.enable)
    {
        acl_entry->action.flag |= CTC_ACL_ACTION_FLAG_VLAN_EDIT;
        acl_entry->action.vlan_edit.stag_op = CTC_ACL_VLAN_TAG_OP_ADD;
        acl_entry->action.vlan_edit.svid_sl = CTC_ACL_VLAN_TAG_SL_NEW;
        acl_entry->action.vlan_edit.svid_new = attr_value->value.aclaction.parameter.u16;
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->action.flag, CTC_ACL_ACTION_FLAG_MICRO_FLOW_POLICER);
    }
    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_action_set_redirect_untag(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    if (attr_value->value.aclaction.enable)
    {
        acl_entry->action.flag |= CTC_ACL_ACTION_FLAG_VLAN_EDIT;
        acl_entry->action.vlan_edit.stag_op = CTC_ACL_VLAN_TAG_OP_DEL;
        acl_entry->action.vlan_edit.svid_sl = CTC_ACL_VLAN_TAG_SL_NONE;
    }
    else
    {
        CTC_UNSET_FLAG(acl_entry->action.flag, CTC_ACL_ACTION_FLAG_MICRO_FLOW_POLICER);
    }
    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_action_set_src_mac_action(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    if (attr_value->value.aclaction.enable)
    {
        pacl_db->macsa_en = TRUE;
        sal_memcpy(pacl_db->macsa, attr_value->value.aclaction.parameter.mac, sizeof(sai_mac_t));
    }
    else
    {
        pacl_db->macsa_en = FALSE;
    }
    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_action_set_dst_mac_action(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    if (attr_value->value.aclaction.enable)
    {
        pacl_db->macda_en = TRUE;
        sal_memcpy(pacl_db->macda, attr_value->value.aclaction.parameter.mac, sizeof(sai_mac_t));
    }
    else
    {
        pacl_db->macda_en = FALSE;
    }
    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_action_set_src_ip_action(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    if (attr_value->value.aclaction.enable)
    {
        pacl_db->ipsa_en = TRUE;
        sal_memcpy(&pacl_db->ipsa, &attr_value->value.aclaction.parameter.ip4, sizeof(sai_ip4_t));
    }
    else
    {
        pacl_db->ipsa_en = FALSE;
    }
    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_action_set_dst_ip_action(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    if (attr_value->value.aclaction.enable)
    {
        pacl_db->ipda_en = TRUE;
        sal_memcpy(&pacl_db->ipda, &attr_value->value.aclaction.parameter.ip4, sizeof(sai_ip4_t));
    }
    else
    {
        pacl_db->ipda_en = FALSE;
    }
    return SAI_STATUS_SUCCESS;
}

inline sai_status_t 
_acl_action_set_strip_header_action(ctc_acl_entry_t* acl_entry, const sai_attribute_t *attr_value, ctc_sai_acl_entry_t *pacl_db)
{
    if (attr_value->value.aclaction.enable)
    {
        pacl_db->strip_header = attr_value->value.aclaction.parameter.u32;
    }
    else
    {
        pacl_db->strip_header = 0;
    }
    return SAI_STATUS_SUCCESS;
}


sai_status_t
ctc_sai_acl_db_init()
{
    CTC_SAI_DEBUG_FUNC();
    sal_memset(&g_sai_acl_info, 0, sizeof(g_sai_acl_info));

    g_sai_acl_info.max_count[0] = 128;
    g_sai_acl_info.pvector[0] = ctc_vector_init(100, 100);

    if (NULL == g_sai_acl_info.pvector[0])
    {
        return SAI_STATUS_NO_MEMORY;
    }

    if (0 != ctc_opf_init(CTC_OPF_ACL_TABLE_ID, 1))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    g_sai_acl_info.opf[0].pool_type = CTC_OPF_ACL_TABLE_ID;
    g_sai_acl_info.opf[0].pool_index = 0;

    if (0 != ctc_opf_init_offset(&g_sai_acl_info.opf[0], 0, g_sai_acl_info.max_count[0]))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    g_sai_acl_info.max_count[1] = 10000;
    g_sai_acl_info.pvector[1] = ctc_vector_init(100, 100);
    if (0 != ctc_opf_init(CTC_OPF_SAI_ACL_ENTRY_ID, 1))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    g_sai_acl_info.opf[1].pool_type = CTC_OPF_SAI_ACL_ENTRY_ID;
    g_sai_acl_info.opf[1].pool_index = 0;


    if (0 != ctc_opf_init_offset(&g_sai_acl_info.opf[1], 0, g_sai_acl_info.max_count[1]))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    if (0 != ctc_opf_init(CTC_OPF_CTC_SCL_ENTRY_ID, 1))
    {
        return SAI_STATUS_NO_MEMORY;
    }
    
    g_sai_acl_info.tunnel_max_count = 4096;
    g_sai_acl_info.tunnel_opf.pool_type = CTC_OPF_CTC_SCL_ENTRY_ID;
    g_sai_acl_info.tunnel_opf.pool_index= 0;
    if (0 != ctc_opf_init_offset(&g_sai_acl_info.tunnel_opf, 1, g_sai_acl_info.tunnel_max_count))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    g_sai_acl_info.max_count[2] = 100000;
    g_sai_acl_info.pvector[2] = ctc_vector_init(100, 100);
    if (0 != ctc_opf_init(CTC_OPF_ACL_ENTRY_ID, 1))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    g_sai_acl_info.opf[2].pool_type = CTC_OPF_ACL_ENTRY_ID;
    g_sai_acl_info.opf[2].pool_index = 0;

    g_sai_acl_info.max_count[3] = 100000;
    g_sai_acl_info.pvector[3] = ctc_vector_init(100, 100);

    if (0 != ctc_opf_init_offset(&g_sai_acl_info.opf[2], 0, g_sai_acl_info.max_count[2]))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    g_sai_acl_info.acl_port_oid_en_list = ctc_list_new();
#if 0    
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_SRC_MAC - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_mac_sa;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_DST_MAC - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_mac_da;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_ID - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_ovlan;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_OUTER_VLAN_PRI - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_ovlan_cos;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_INNER_VLAN_ID - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_ivlan;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_INNER_VLAN_PRI - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_ivlan_cos;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_ETHER_TYPE - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_ether_type;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_SRC_IP - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_ip_sa;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_DST_IP - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_ip_da;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_IP_PROTOCOL - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_ip_protocol;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_L4_SRC_PORT - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_l4_srcport;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_L4_DST_PORT - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_l4_dstport;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_DSCP - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_ip_dscp;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_IP_PRECEDENCE- SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_ip_precedence;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_IP_FRAG - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_ip_frag;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_ICMP_TYPE - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_icmp_type;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_ICMP_CODE - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_icmp_code;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_IGMP_TYPE - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_igmp_type;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_TCP_FLAGS - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_tcp_flags;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_IP_OPTIONS - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_ip_options;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_ROUTED_PKT - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_ip_routed_packet;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_UDF_MATCH - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_udf_match;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_UDF_TYPE - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_udf_type;

    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_IN_PORTS - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_none;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_OUT_PORTS - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_none;

    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_none;
    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_OUT_PORT - SAI_ACL_ENTRY_ATTR_FIELD_START] = _acl_mapping_none;

    g_sai_acl_info.g_acl_mapping[SAI_ACL_ENTRY_ATTR_FIELD_VXLAN_VNI - SAI_ACL_ENTRY_ATTR_FIELD_START] 
        = _acl_mapping_l4_vxlan_vni;
#endif

    g_sai_acl_info.g_acl_action[SAI_ACL_ENTRY_ATTR_PACKET_ACTION - SAI_ACL_ENTRY_ATTR_ACTION_START] = _acl_action_packet_action;
    g_sai_acl_info.g_acl_action[SAI_ACL_ENTRY_ATTR_ACTION_COUNTER - SAI_ACL_ENTRY_ATTR_ACTION_START] = _acl_action_counter;
    g_sai_acl_info.g_acl_action[SAI_ACL_ENTRY_ATTR_ACTION_MIRROR_INGRESS - SAI_ACL_ENTRY_ATTR_ACTION_START] = _acl_action_mirror;
    g_sai_acl_info.g_acl_action[SAI_ACL_ENTRY_ATTR_ACTION_MIRROR_EGRESS - SAI_ACL_ENTRY_ATTR_ACTION_START] = _acl_action_mirror;
    g_sai_acl_info.g_acl_action[SAI_ACL_ENTRY_ATTR_ACTION_SET_COLOR - SAI_ACL_ENTRY_ATTR_ACTION_START] = _acl_action_setcolor;
    g_sai_acl_info.g_acl_action[SAI_ACL_ENTRY_ATTR_ACTION_SET_POLICER - SAI_ACL_ENTRY_ATTR_ACTION_START] = _acl_action_set_policer;

    g_sai_acl_info.g_acl_action[SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT - SAI_ACL_ENTRY_ATTR_ACTION_START] = _acl_action_set_redirect_action;
    g_sai_acl_info.g_acl_action[SAI_ACL_ENTRY_ATTR_ACTION_SET_REDIRECT_VLAN_ID - SAI_ACL_ENTRY_ATTR_ACTION_START] = _acl_action_set_redirect_vlan;
    g_sai_acl_info.g_acl_action[SAI_ACL_ENTRY_ATTR_ACTION_SET_REDIRECT_UNTAG - SAI_ACL_ENTRY_ATTR_ACTION_START] = _acl_action_set_redirect_untag;
    g_sai_acl_info.g_acl_action[SAI_ACL_ENTRY_ATTR_ACTION_SET_TRUNCATION - SAI_ACL_ENTRY_ATTR_ACTION_START] = _acl_action_set_redirect_truncation;

    g_sai_acl_info.g_acl_action[SAI_ACL_ENTRY_ATTR_ACTION_SET_SRC_MAC - SAI_ACL_ENTRY_ATTR_ACTION_START] 
        = _acl_action_set_src_mac_action;

    g_sai_acl_info.g_acl_action[SAI_ACL_ENTRY_ATTR_ACTION_SET_DST_MAC - SAI_ACL_ENTRY_ATTR_ACTION_START] 
        = _acl_action_set_dst_mac_action;

    g_sai_acl_info.g_acl_action[SAI_ACL_ENTRY_ATTR_ACTION_SET_SRC_IP - SAI_ACL_ENTRY_ATTR_ACTION_START] 
        = _acl_action_set_src_ip_action;

    g_sai_acl_info.g_acl_action[SAI_ACL_ENTRY_ATTR_ACTION_SET_DST_IP - SAI_ACL_ENTRY_ATTR_ACTION_START] 
        = _acl_action_set_dst_ip_action;

    g_sai_acl_info.g_acl_action[SAI_ACL_ENTRY_ATTR_ACTION_SET_STRIP_HEADER - SAI_ACL_ENTRY_ATTR_ACTION_START] 
        = _acl_action_set_strip_header_action;

    ctc_sai_acl_worm_filter_init();

    g_sai_acl_info.tunnel_res_hash = 
        ctc_hash_create(CTC_SAI_SCL_TUNNEL_RES, 
                        CTC_SAI_SCL_TUNNEL_BLOCK_SIZE, 
                        __tunnel_decap_res_hash_make, 
                        __tunnel_decap_res_hash_cmp);

#ifdef TAPPRODUCT
    ctc_sai_acl_global_egress_dealut_init();
#endif


    return SAI_STATUS_SUCCESS;
}

#define ________SAI_ACL_INNER_FUNC
sai_status_t __acl_init_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
#ifdef TAPPRODUCT
    uint32 value    = 0;
    value = 1;
#endif
    ret = ctc_sai_acl_db_init();

    if(SAI_STATUS_SUCCESS != ret)
    {
        goto out;
    }

#ifdef TAPPRODUCT
    ctc_global_ctl_set(CTC_GLOBAL_CHIP_STRIP_PACKET_SCLFLOW_BYTE_SHIFT, &value);
    ctc_global_ctl_set(CTC_GLOBAL_CHIP_GRE_AUTO_RECOGNITION, &value);
#endif    

    //ctc_sai_acl_init_lag_group();

    preg->init_status =  INITIALIZED;

out:
    return ret;
}

sai_status_t __acl_exit_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}

/* define sai 0.9.2 */
static sai_acl_api_t      g_sai_acl_api_func = {
    .create_acl_table           = sai_create_acl_table,
    .delete_acl_table           = sai_delete_acl_table,
    .set_acl_table_attribute    = sai_set_acl_table_attribute,
    .get_acl_table_attribute    = sai_get_acl_table_attribute,
    .create_acl_entry           = sai_create_acl_entry,
    .delete_acl_entry           = sai_delete_acl_entry,
    .set_acl_entry_attribute    = sai_set_acl_entry_attribute,
    .get_acl_entry_attribute    = sai_get_acl_entry_attribute,
    .create_acl_counter         = ctc_sai_create_acl_counter,
    .delete_acl_counter         = ctc_sai_delete_acl_counter,
    .set_acl_counter_attribute  = ctc_sai_set_acl_counter_attribute,
    .get_acl_counter_attribute  = ctc_sai_get_acl_counter_attribute
};

static ctc_sai_api_reg_info_t g_acl_api_reg_info = {
        .id  = SAI_API_ACL,
        .init_func = __acl_init_mode_fn,
        .exit_func = __acl_exit_mode_fn,
        .api_method_table = &g_sai_acl_api_func,
        .private_data     = NULL,
};

#define ________SAI_ACL_OUTER_FUNC
sai_status_t ctc_sai_acl_init()
{
    api_reg_register_fn(&g_acl_api_reg_info);

    return SAI_STATUS_SUCCESS;
}




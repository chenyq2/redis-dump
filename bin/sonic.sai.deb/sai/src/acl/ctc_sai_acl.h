#if !defined (__SAI_ACL_H_)
#define __SAI_ACL_H_

#include <saiacl.h>
#include <ctc_sai_common.h>
#include <saitypes.h>
#include <saistatus.h>
#include <ctc_vector.h>
#include <ctc_opf.h>
#include <ctc_acl.h>

#define SAI_DEFINE_STANDAND_ACL_CTC  1

#define SAI_ATTR_ACL_TABLE_MINIMUM_PRIORITY 0
#define SAI_ATTR_ACL_TABLE_MAXIMUM_PRIORITY 0xffff

#define SAI_ATTR_ACL_ENTRY_MINIMUM_PRIORITY 0
#define SAI_ATTR_ACL_ENTRY_MAXIMUM_PRIORITY 0xffff

#define SAI_ACL_GROUP_BASE                  36

#define SAI_ACL_WORM_FILTER_GROUP           (1022)
#define SAI_ACL_GLOBAL_INGRESS_GROUP        (1023)
#define SAI_ACL_GLOBAL_EGRESS_GROUP         (1024)
#define SAI_ACL_COPP_REASON_GROUP           (1025)
#define SAI_ACL_COPP_FWD2CPU_GROUP          (1026)
#define SAI_ACL_COPP_ACL_GROUP              (1027)
#define SAI_ACL_COPP_OPENFLOW_TO_CONTROLLER_GROUP (1028)
#define SAI_ACL_WORM_FILTER_PRIORITY_BASE    10

#define SAI_ACL_COPP_DEFAULT_ACL_PRIORITY 0x1ffff
#define SAI_ACL_COPP_DEFAULT_ACL_ENTRY_ID 0x1ffff

#define SAI_ACL_MAC_WILDCARD_MASK(mac_addr) \
    mac_addr[0]=(~mac_addr[0]); \
    mac_addr[1]=(~mac_addr[1]); \
    mac_addr[2]=(~mac_addr[2]); \
    mac_addr[3]=(~mac_addr[3]); \
    mac_addr[4]=(~mac_addr[4]); \
    mac_addr[5]=(~mac_addr[5]);

#define SAI_ACL_VLAN_WILDCARD_MASK(vlanid) \
    (vlanid=((~vlanid)&0xfff));

#define SAI_ACL_COS_WILDCARD_MASK(cosid) \
    (cosid=((~cosid)&0x7));

#define SAI_ACL_DSCP_WILDCARD_MASK(dscp) \
    (dscp=((~dscp)&0x3F));

#define SAI_ACL_WILDCARD_MASK(value) (value=(~value));

#define IS_EQ_WILDCARD_MASK_8(value) (value==0xFF)
#define IS_EQ_WILDCARD_MASK_16(value) (value==0xFFFF)
#define IS_EQ_WILDCARD_MASK_32(value) (value==0xFFFFFFFF)


typedef struct ctc_sai_acl_table_s
{
    sai_object_id_t     table_id;
    sai_uint32_t        priority;
    sai_acl_stage_t     stage;
    sai_uint32_t        field_bitmap;
}ctc_sai_acl_table_t;

typedef struct ctc_sai_acl_entry_field_list_s
{
    sai_acl_field_data_t    ether_macsa;
    sai_acl_field_data_t    ether_macda;

    sai_acl_field_data_t    ether_svlan;
    sai_acl_field_data_t    ether_svlan_pri;
    sai_acl_field_data_t    ether_svlan_cfi;
    sai_acl_field_data_t    ether_cvlan;
    sai_acl_field_data_t    ether_cvlan_pri;
    sai_acl_field_data_t    ether_cvlan_cfi;

    sai_acl_field_data_t    ether_type;
    
    sai_acl_field_data_t    ipv4_ipsa;
    sai_acl_field_data_t    ipv4_ipda;
    sai_acl_field_data_t    ipv4_src_port;
    sai_acl_field_data_t    ipv4_dst_port;
    sai_acl_field_data_t    ipv4_ip_protocol;
    sai_acl_field_data_t    ipv4_dscp;
    sai_acl_field_data_t    ipv4_ip_frag;
    sai_acl_field_data_t    ipv4_ip_precedence;
    sai_acl_field_data_t    ipv4_icmp_type;
    sai_acl_field_data_t    ipv4_icmp_code;
    sai_acl_field_data_t    ipv4_igmp_type;
    sai_acl_field_data_t    ipv4_tcp_flag;
    sai_acl_field_data_t    ipv4_ip_options;
    sai_acl_field_data_t    ipv4_routed_packet;
    sai_acl_field_data_t    ipv4_vxlan_vni;

    sai_acl_field_data_t    gre_type;
    sai_acl_field_data_t    gre_key;
    sai_acl_field_data_t    nvgre_vni;

    sai_acl_field_data_t    udf_type;
    sai_acl_field_data_t    udf_match_data;
}ctc_sai_acl_entry_field_list_t;

typedef struct ctc_sai_acl_entry_field_action_list_s
{
    sai_acl_action_data_t    action;
    sai_acl_action_data_t    counter;
    sai_acl_action_data_t    mirror_ingress;
    sai_acl_action_data_t    mirror_egress;
    sai_acl_action_data_t    set_color;
    sai_acl_action_data_t    set_policer;
    sai_acl_action_data_t    redirect;
    sai_acl_action_data_t    redirect_vlan_id;
    sai_acl_action_data_t    redirect_vlan_untag;
    sai_acl_action_data_t    trunction;
    sai_acl_action_data_t    src_mac;
    sai_acl_action_data_t    dst_mac;
    sai_acl_action_data_t    src_ip;
    sai_acl_action_data_t    dst_ip;
    sai_acl_action_data_t    strip_header;
    sai_acl_action_data_t    strip_header_pos;
    sai_acl_action_data_t    strip_header_offset;
    sai_acl_action_data_t    outer_vlan;
}ctc_sai_acl_entry_field_action_list_t;

typedef struct ctc_sai_acl_tunnel_decap_info_key_s{
    ctc_sai_acl_entry_field_list_t   fields;
    sai_object_id_t                  port_oid;
}ctc_sai_acl_tunnel_decap_info_key_t;

typedef struct ctc_sai_acl_tunnel_decap_info_s{
    ctc_sai_acl_tunnel_decap_info_key_t   key;
    int32_t     count;
    uint32_t    entry_id;
}ctc_sai_acl_tunnel_decap_info_t;

typedef struct ctc_sai_acl_entry_s
{
    sai_object_id_t     entry_id;
    sai_object_id_t     table_id;
    sai_object_id_t     mirror_session_id;
    sai_uint32_t        priority;
    sai_uint32_t        ctc_entry_id_list[64];
    sai_uint32_t        ctc_entry_id_cnt;
    sai_uint32_t        dirction;
    sai_uint64_t        port_oid_list[64];
    sai_uint32_t        port_oid_cnt;
    bool                enable;
    ctc_vector_t*       acl_action_vector;

    bool                apply_inner_lookup;

    sai_acl_field_data_t    in_port;
    
    ctc_sai_acl_entry_field_list_t          outer_fileds;
    ctc_sai_acl_entry_field_list_t          inner_fileds;
    ctc_sai_acl_entry_field_action_list_t   action;
    ctc_sai_acl_tunnel_decap_info_t         *ptunnel_info;

/* action */
    bool                ipda_en;
    sai_ip4_t           ipda;
    bool                ipsa_en;
    sai_ip4_t           ipsa;
    bool                macda_en;
    sai_mac_t           macda;
    bool                macsa_en;
    sai_mac_t           macsa;

    bool                l4_vxlan_vni_en;
    uint32              l4_vxlan_vni;
    uint32              l4_vxlan_vni_mask;

    uint32_t            strip_header;
#ifdef TAPPRODUCT    
    bool                tap_enable;         /* acl in tap mode */ 
    struct ctc_sai_tap_info_s *ptap_info;
    uint32_t            trunction_en;
    sai_object_id_t     tap_group_id;
    struct  __ctc_sai_tap_group_edit_group    *edit_group;
#endif    
    uint32_t            l3type;             /* set acl_entry l3type */
}ctc_sai_acl_entry_t;

typedef sai_status_t (*sai_acl_attr_mapping_cb)(
    _Out_ ctc_acl_entry_t *acl_entry,
    _In_ const sai_attribute_t *attr,
    ctc_sai_acl_entry_t *pacl_db
    );

typedef struct ctc_sai_acl_port_en_s
{
    sai_object_id_t             acl_port_oid;
    sai_uint32_t                ingress_en_cnt;
    sai_uint32_t                egress_en_cnt;
} ctc_sai_acl_port_en_t;


typedef struct ctc_sai_ctc_copp_reason_s
{
    uint32                      reason_id;
    //sai_hostif_trap_channel_t   channel;
    sai_int32_t                 nexthop_id;
} ctc_sai_ctc_copp_reason_t;

typedef struct ctc_sai_acl_info_s
{
    ctc_vector_t*   pvector[4]; /* 0 is for acl table, 1 is for sai acl entry, 2 is for ctc acl entry , 3 is for acl action*/
    uint32_t        max_count[4]; /* 0 is for acl table, 1 is for sai acl entry, 2 id for ctc acl entry , 3 is for acl action*/
    ctc_opf_t       opf[3]; /* 0 is for sai acl table, 1 is for sai acl entry, 2 is for ctc acl entry  */
    uint32_t        counter_max;
    ctc_linklist_t *acl_port_oid_en_list; /*for acl port enable database*/
    
    ctc_sai_ctc_copp_reason_t ctc_reason[1024];  /* CTC_PKT_CPU_REASON_MAX_COUNT */

    sai_acl_attr_mapping_cb g_acl_mapping[64];
    sai_acl_attr_mapping_cb g_acl_action[64];

    ctc_hash_t     *tunnel_res_hash;
    ctc_opf_t       tunnel_opf;
    uint32_t        tunnel_max_count;
}ctc_sai_acl_info_t;

sai_status_t 
ctc_sai_acl_init();

int 
ctc_sai_acl_port_enable(ctc_direction_t dir, sai_object_id_t port);

int
ctc_sai_acl_lag_member_enable(sai_object_id_t lag_id, sai_object_id_t lag_member_port_id);

int
ctc_sai_acl_lag_member_disable(sai_object_id_t lag_member_port_id, sai_object_id_t lag_id);

int
ctc_sai_acl_port_enable(ctc_direction_t dir, sai_object_id_t port);

int
ctc_sai_acl_lag_install(ctc_direction_t dir, sai_object_id_t lag_id);

int
ctc_sai_acl_copp_group_init();

#endif


#include <sai.h>
#include <sal.h>
#include "ctc_api.h"
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_sai.h>
#include "ctc_sai_router.h"
#include "ctc_sai_port.h"
#include <ctc_sai_routerintf.h>
#include <ctc_sai_debug.h>

#define CTC_SAI_ROUTER_INTERFACE_BLOCK_SIZE   16

typedef struct routerintf_result_s
{
    sai_vlan_id_t               vlan_id;
    sai_object_id_t             port_id;
    ctc_sai_routerintf_entry_t* prtf_entry;
}routerintf_result_t;

static ctc_sai_check_object_type_range_t   g_vr_obj =
{
    .min = SAI_OBJECT_TYPE_VIRTUAL_ROUTER,
    .max = SAI_OBJECT_TYPE_VIRTUAL_ROUTER,
};

static ctc_sai_check_u32_range_t g_intf_attr_type =
{
    .min = SAI_ROUTER_INTERFACE_TYPE_PORT,
    .max = SAI_ROUTER_INTERFACE_TYPE_VLAN,
};

static ctc_sai_attr_entry_info_t g_sai_attr_entries[] = {
    {
        .id     = SAI_ROUTER_INTERFACE_ATTR_VIRTUAL_ROUTER_ID,
        .type   = SAI_ATTR_FALG_CREATE | SAI_ATTR_FALG_READ,
        .check_fn = {
            .func_fn = ctc_sai_check_object_type_range_fn,
            .func_parameter = &g_vr_obj,
        }
    },
    {
        .id     = SAI_ROUTER_INTERFACE_ATTR_TYPE,
        .type   = SAI_ATTR_FALG_CREATE | SAI_ATTR_FALG_READ,
        .check_fn = {
            .func_fn = ctc_sai_check_i32_range_fn,
            .func_parameter = &g_intf_attr_type,
        }
    },
    {
        .id     = SAI_ROUTER_INTERFACE_ATTR_PORT_ID,
        .type   = SAI_ATTR_FLAG_UNKONW | SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_ROUTER_INTERFACE_ATTR_VLAN_ID,
        .type   = SAI_ATTR_FLAG_UNKONW | SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_ROUTER_INTERFACE_ATTR_SRC_MAC_ADDRESS,
        .type   = SAI_ATTR_FALG_WRITE| SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_ROUTER_INTERFACE_ATTR_ADMIN_V4_STATE,
        .type   = SAI_ATTR_FALG_WRITE| SAI_ATTR_FALG_READ | SAI_ATTR_FLAG_DEFAULT,
        .default_value.booldata = true,
    },
    {
        .id     = SAI_ROUTER_INTERFACE_ATTR_ADMIN_V6_STATE,
        .type   = SAI_ATTR_FALG_WRITE| SAI_ATTR_FALG_READ | SAI_ATTR_FLAG_DEFAULT,
        .default_value.booldata = true,
    },
    {
        .id     = SAI_ROUTER_INTERFACE_ATTR_MTU,
        .type   = SAI_ATTR_FALG_WRITE| SAI_ATTR_FALG_READ | SAI_ATTR_FLAG_DEFAULT,
        .default_value.u32 = 1514,
    },
    {
        .id     = SAI_ROUTER_INTERFACE_ATTR_VMAC_ADDRESS,
        .type   = SAI_ATTR_FALG_WRITE| SAI_ATTR_FALG_READ,
    },    
    {
        .id     = SAI_ATTR_ID_END,
        .type   = 0,
    },
};

static ctc_sai_routerintf_info_t  g_sai_routerintf_info;

#define ________SAI_SAI_INNER_API_FUNC
sai_status_t
ctc_routerintf_init()
{
    //ctc_l3if_t router_if;
    sai_status_t ret        = SAI_STATUS_SUCCESS;

    /*modified by wangl for hybrid*/
#ifdef OFPRODUCT
    g_sai_routerintf_info.max_count = MAX_CTC_L3IF_ID - 2; /*1022 is reserved for mpls en, 1021 is reserved for ipuc with l2 port*/
#else
    g_sai_routerintf_info.max_count = MAX_CTC_L3IF_ID;
#endif
    g_sai_routerintf_info.pvector 	=
        ctc_vector_init(CTC_VEC_BLOCK_NUM(g_sai_routerintf_info.max_count,
           CTC_SAI_ROUTER_INTERFACE_BLOCK_SIZE),
                CTC_SAI_ROUTER_INTERFACE_BLOCK_SIZE);

    if(NULL == g_sai_routerintf_info.pvector)
    {
        return SAI_STATUS_NO_MEMORY;
    }

    CTC_SAI_ERROR_GOTO(ctc_opf_init(CTC_OPF_SAI_ROUTER_INTF_ID,1), ret, out);

    g_sai_routerintf_info.opf.pool_type = CTC_OPF_SAI_ROUTER_INTF_ID;
    g_sai_routerintf_info.opf.pool_index= 0;

    CTC_SAI_ERROR_GOTO(
        ctc_opf_init_offset(&g_sai_routerintf_info.opf, 2, g_sai_routerintf_info.max_count),
        ret,out);

    //sal_memset(&router_if, 0, sizeof(router_if));
    //router_if.l3if_type = CTC_L3IF_TYPE_PHY_IF;
    //router_if.gport = CTC_LPORT_CPU;
    //ctc_l3if_create(MAX_CTC_L3IF_ID, &router_if);
out:
    return ret;
}

int32
ctc_routerintf_alloc_l3if_id(uint32_t *l3if_id)
{
    return ctc_opf_alloc_offset(&g_sai_routerintf_info.opf, 0, l3if_id);
}

int32
ctc_routerintf_release_l3if_id(uint32_t l3if_id)
{
    return ctc_opf_free_offset(&g_sai_routerintf_info.opf, 0, l3if_id);
}

sai_status_t
ctc_routerintf_alloc(
    _Out_ ctc_sai_routerintf_entry_t** prouterintf_entry)
{
    sai_status_t                ret         = SAI_STATUS_SUCCESS;
    uint32_t                    index       = 0;
    ctc_sai_routerintf_entry_t  *prouterintf_entry_tmp = NULL;

    if (g_sai_routerintf_info.pvector->used_cnt >= g_sai_routerintf_info.max_count)
    {
        ret = SAI_STATUS_TABLE_FULL;
        goto out;
    }

    prouterintf_entry_tmp = mem_malloc(MEM_APP_ROUTER_IF_MODULE,sizeof(ctc_sai_routerintf_entry_t));

    if (prouterintf_entry_tmp)
    {
        sal_memset(prouterintf_entry_tmp,0,sizeof(ctc_sai_routerintf_entry_t));
        ctc_routerintf_alloc_l3if_id(&index);
        prouterintf_entry_tmp->rif_id =
            CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_ROUTER_INTERFACE,index);
    }

    *prouterintf_entry = prouterintf_entry_tmp;

out:
    return ret;
}

void
ctc_routerintf_release(
    _In_  ctc_sai_routerintf_entry_t *prouterintf_entry)
{
    if(NULL == prouterintf_entry)
    {
        return ;
    }

    ctc_routerintf_release_l3if_id(CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id));
    mem_free(prouterintf_entry);
}

ctc_sai_routerintf_entry_t*
ctc_routerintf_get_by_oid_no_ref(
	_In_  const sai_object_id_t rif_id)
{
    ctc_sai_routerintf_entry_t  *prouterintf_entry = NULL;

    prouterintf_entry =
        ctc_vector_get(g_sai_routerintf_info.pvector,
            CTC_SAI_OBJECT_INDEX_GET(rif_id));

    return prouterintf_entry;
}

ctc_sai_routerintf_entry_t*
ctc_routerintf_get_by_oid(
	_In_  const sai_object_id_t rif_id)
{
    return ctc_routerintf_get_by_oid_no_ref(rif_id);
}

static int32_t
__ctc_vec_traversal_by_vlan(
	void* array_data,
	void* user_data)
{
    ctc_sai_routerintf_entry_t* prouterintf_entry 	= NULL;
    routerintf_result_t*        prouterintf_result 	= NULL;

    if(!array_data)
    {
        return 0;
    }

    prouterintf_entry = array_data;
    prouterintf_result= user_data;

    if(SAI_ROUTER_INTERFACE_TYPE_VLAN == prouterintf_entry->type)
    {
        if(prouterintf_result->vlan_id == prouterintf_entry->vlan_id)
        {
            prouterintf_result->prtf_entry = prouterintf_entry;
        }
    }

    return 0;
}

static int32_t
__ctc_vec_traversal_by_port_oid(
	void* array_data,
	void* user_data)
{
    ctc_sai_routerintf_entry_t* prouterintf_entry 	= NULL;
    routerintf_result_t*        prouterintf_result 	= NULL;

    if(!array_data)
    {
        return 0;
    }

    prouterintf_entry = array_data;
    prouterintf_result= user_data;

    if(SAI_ROUTER_INTERFACE_TYPE_PORT == prouterintf_entry->type)
    {
        if(prouterintf_result->port_id == prouterintf_entry->port_oid)
        {
            prouterintf_result->prtf_entry = prouterintf_entry;
        }
    }

    return 0;
}

ctc_sai_routerintf_entry_t*
ctc_routerintf_get_by_vlan(
	_In_  const sai_vlan_id_t vlan_id)
{
    ctc_sai_routerintf_entry_t  *prouterintf_entry 	= NULL;
    routerintf_result_t         router_result 		= {};

    sal_memset(&router_result,0,sizeof(routerintf_result_t));

    router_result.vlan_id = vlan_id;

    ctc_vector_traverse(g_sai_routerintf_info.pvector,
        __ctc_vec_traversal_by_vlan, &router_result);

    prouterintf_entry = router_result.prtf_entry;
    return prouterintf_entry;
}

ctc_sai_routerintf_entry_t*
ctc_routerintf_get_by_port_oid(
	_In_  const sai_object_id_t port_oid)
{
    ctc_sai_routerintf_entry_t  *prouterintf_entry 	= NULL;
    routerintf_result_t         router_result 		= {};

    sal_memset(&router_result,0,sizeof(routerintf_result_t));

    router_result.port_id = port_oid;

    ctc_vector_traverse(g_sai_routerintf_info.pvector,
        __ctc_vec_traversal_by_port_oid, &router_result);

    prouterintf_entry = router_result.prtf_entry;
    return prouterintf_entry;
}


sai_status_t
__ctc_routerintf_create_l3if(
	_In_  ctc_sai_routerintf_entry_t *prouterintf_entry)
{
    int32_t     sdk_ret = 0;
    ctc_l3if_t  l3if;
    int32_t  i = 0;
#ifdef DUET2
    uint32 gport[64] = {0};
#else
    uint16 gport[64] = {0};
#endif
    uint8 cnt = 0;
    uint8 tid  = 0;

    sal_memset(&l3if,0,sizeof(ctc_l3if_t));

    if(SAI_ROUTER_INTERFACE_TYPE_PORT == prouterintf_entry->type)
    {
        l3if.l3if_type = CTC_L3IF_TYPE_PHY_IF;
        ctc_sai_port_objectid_to_gport(prouterintf_entry->port_oid, &l3if.gport);
    }
    else if(SAI_ROUTER_INTERFACE_TYPE_VLAN == prouterintf_entry->type)
    {
        l3if.l3if_type = CTC_L3IF_TYPE_VLAN_IF;
        l3if.vlan_id = prouterintf_entry->vlan_id;
    }
    else
    {
        return sdk_ret;
    }

    sdk_ret = ctc_l3if_create(
        (uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id),
                &l3if);

    if(SAI_ROUTER_INTERFACE_TYPE_PORT == prouterintf_entry->type)
    {
        ctc_port_set_phy_if_en(l3if.gport,TRUE);

        /*modified by hansf, default trust cos 2017/09/13*/
        //ctc_port_set_property(l3if.gport, CTC_PORT_PROP_QOS_POLICY, CTC_QOS_TRUST_DSCP);
#if 0 /* SYSTEM MODIFIED: fix qos bug 40267 add by wangqj */
        ctc_port_set_property(l3if.gport, CTC_PORT_PROP_REPLACE_DSCP_EN, 0);
        ctc_port_set_property(l3if.gport, CTC_PORT_PROP_REPLACE_STAG_COS, 0);
#endif
        if (CTC_IS_LINKAGG_PORT(l3if.gport))
        {
            tid = CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->port_oid);
            ctc_linkagg_get_member_ports(tid,gport, &cnt);
            for(i=0; i<cnt; i++)
            {
                ctc_port_set_phy_if_en(gport[i],TRUE);
                ctc_port_set_property(gport[i], CTC_PORT_PROP_BRIDGE_EN, 1);

                /*modified by hansf, default trust cos 2017/09/13*/
                //ctc_port_set_property(gport[i], CTC_PORT_PROP_QOS_POLICY, CTC_QOS_TRUST_DSCP);
#if 0 /* SYSTEM MODIFIED: fix qos bug 40267 add by wangqj */
                ctc_port_set_property(gport[i], CTC_PORT_PROP_REPLACE_DSCP_EN, 0);
                ctc_port_set_property(gport[i], CTC_PORT_PROP_REPLACE_STAG_COS, 0);
#endif
                ctc_sai_port_set_port_flag(CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,gport[i]),SAI_PORT_FLAG_ROUTED_EN, TRUE);
            }
            
            goto out;
        }
        else
        {
            ctc_port_set_property(l3if.gport, CTC_PORT_PROP_BRIDGE_EN, 1);
        }

        ctc_stp_clear_all_inst_state(l3if.gport);
    }
    else if(SAI_ROUTER_INTERFACE_TYPE_VLAN == prouterintf_entry->type)
    {
#if 0
        /* Delete for should set based on IGMP Snooping enable config */
        ctc_l3if_set_property((uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id), CTC_L3IF_PROP_IGMP_SNOOPING_EN, TRUE);    
#endif
    }

out:
    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}


sai_status_t
ctc_routerintf_add_entry(
	_In_  ctc_sai_routerintf_entry_t *prouterintf_entry)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    CTC_SAI_ERROR_GOTO(__ctc_routerintf_create_l3if(prouterintf_entry),ret,out);

    ctc_vector_add(g_sai_routerintf_info.pvector,
                CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id),
                prouterintf_entry);

    CTC_SAI_ERROR_GOTO(
        ctc_vr_add_router_intf(prouterintf_entry->pvr,prouterintf_entry),
        ret,out);

out:
    return ret;
}

sai_status_t
__ctc_routerintf_destory_l3if(
	_In_  ctc_sai_routerintf_entry_t *prouterintf_entry)
{
    int32_t     sdk_ret = 0;
    ctc_l3if_t  l3if;
    int32_t  i = 0;
#ifdef DUET2    
    uint32 gport[64] = {0};
#else
    uint16 gport[64] = {0};
#endif
    uint8 cnt = 0;
    uint8 tid = 0;

    sal_memset(&l3if,0,sizeof(ctc_l3if_t));

    if(SAI_ROUTER_INTERFACE_TYPE_PORT == prouterintf_entry->type)
    {
        l3if.l3if_type = CTC_L3IF_TYPE_PHY_IF;
        /* modified by wangjj for fix lag type gport differ from creating, 2016-04-06 */
        ctc_sai_port_objectid_to_gport(prouterintf_entry->port_oid, &l3if.gport);
        #if 0 
        if (SAI_OBJECT_TYPE_LAG == CTC_SAI_OBJECT_TYPE_GET(prouterintf_entry->port_oid))
        {
            l3if.gport = CTC_LINKAGGID_MASK | (CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->port_oid));
        }
        else
        {
            l3if.gport = CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->port_oid);
        }
        #endif
    }
    else if(SAI_ROUTER_INTERFACE_TYPE_VLAN == prouterintf_entry->type)
    {
        l3if.l3if_type = CTC_L3IF_TYPE_VLAN_IF;
        l3if.vlan_id = prouterintf_entry->vlan_id;
    }
    else
    {
        return sdk_ret;
    }

    if(SAI_ROUTER_INTERFACE_TYPE_VLAN == prouterintf_entry->type)
    {
#if 0
        /* Delete for should set based on IGMP Snooping enable config */
        ctc_l3if_set_property((uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id), CTC_L3IF_PROP_IGMP_SNOOPING_EN, FALSE);
#endif
    }
    
    sdk_ret = ctc_l3if_destory(
        (uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id),
                &l3if);

    if(SAI_ROUTER_INTERFACE_TYPE_PORT == prouterintf_entry->type)
    {
        ctc_port_set_phy_if_en(l3if.gport,FALSE);
        ctc_port_set_property(l3if.gport, CTC_PORT_PROP_QOS_POLICY, CTC_QOS_TRUST_STAG_COS);
#if 0 /* SYSTEM MODIFIED: fix qos bug 40267 add by wangqj */
        ctc_port_set_property(l3if.gport, CTC_PORT_PROP_REPLACE_STAG_COS, 0);
        ctc_port_set_property(l3if.gport, CTC_PORT_PROP_REPLACE_DSCP_EN, 0);
#endif
        if (CTC_IS_LINKAGG_PORT(l3if.gport))
        {
            tid = CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->port_oid);
            ctc_linkagg_get_member_ports(tid,gport, &cnt);
            for(i=0; i<cnt; i++)
            {
                ctc_port_set_phy_if_en(gport[i],FALSE);
                ctc_port_set_property(gport[i], CTC_PORT_PROP_QOS_POLICY, CTC_QOS_TRUST_STAG_COS);
#if 0 /* SYSTEM MODIFIED: fix qos bug 40267 add by wangqj */
                ctc_port_set_property(gport[i], CTC_PORT_PROP_REPLACE_STAG_COS, 0);
                ctc_port_set_property(gport[i], CTC_PORT_PROP_REPLACE_DSCP_EN, 0);
#endif
                ctc_sai_port_set_port_flag(CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,gport[i]),SAI_PORT_FLAG_ROUTED_EN, FALSE);
            }
            
        }
    }
    
    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}


sai_status_t
ctc_routerintf_remove_entry(
	_In_  ctc_sai_routerintf_entry_t *prouterintf_entry)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    CTC_SAI_ERROR_GOTO(__ctc_routerintf_destory_l3if(prouterintf_entry),ret,out);

    ctc_vr_remove_router_intf(prouterintf_entry->pvr,prouterintf_entry);

    ctc_vector_del(g_sai_routerintf_info.pvector,
                CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id));

out:
    return ret;
}

sai_status_t
ctc_routerintf_update_src_mac(
	_In_  const ctc_sai_routerintf_entry_t 	*prouterintf_entry,
	_In_  const uint8_t 					*pmac)
{
    int32_t     sdk_ret = 0;
    ctc_l3if_router_mac_t   smac;

    sal_memset(&smac,0,sizeof(ctc_l3if_router_mac_t));

    sal_memcpy(smac.mac[0],pmac,sizeof(sai_mac_t));
    smac.num = 1;

    sdk_ret = ctc_l3if_set_interface_router_mac((uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id),
                smac);

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_routerintf_set_src_mac(
	ctc_sai_routerintf_entry_t 	*prouterintf_entry,
	const sai_attribute_t 		*attr)
{
    int32_t     sdk_ret = 0;

    sdk_ret = ctc_routerintf_update_src_mac(prouterintf_entry,
            (uint8_t*)attr->value.mac);

    sal_memcpy(&prouterintf_entry->smac,&attr->value.mac,sizeof(sai_mac_t));

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}
sai_status_t
ctc_routerintf_set_vmac(
    ctc_sai_routerintf_entry_t  *prouterintf_entry,
    const sai_attribute_t    *attr)
{
    int32_t                 sdk_ret = 0;
    ctc_l3if_router_mac_t   smac;
    sai_object_id_t         vr_id = 0;
    ctc_sai_vr_entry_t      *pvr_entry = NULL;
#ifdef GREATBELT
    ctc_l3if_vmac_t         l3if_vmac;
    uint32_t                index = 0;
#endif   

    sal_memset(&smac,0,sizeof(ctc_l3if_router_mac_t));
#ifdef GREATBELT
    sal_memset(&l3if_vmac, 0, sizeof(ctc_l3if_vmac_t));    
#endif   

    sal_memcpy(&smac, &attr->value.vrrp, sizeof(ctc_l3if_router_mac_t));

#ifdef GREATBELT
    /* remove all vmac */
    for (index = 0; index < 3; index++)
    {
        l3if_vmac.low_8bits_mac_index = index;
        l3if_vmac.prefix_type = CTC_L3IF_ROUTE_MAC_PFEFIX_TYPE0;
    
        ctc_l3if_remove_vmac_low_8bit((uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id), &l3if_vmac);
    }
    
    l3if_vmac.low_8bits_mac_index = 3;
    l3if_vmac.prefix_type = CTC_L3IF_ROUTE_MAC_PFEFIX_TYPE_RSV_ROUTER_MAC;
    
    ctc_l3if_remove_vmac_low_8bit((uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id), &l3if_vmac);

    /* if there is vmac, should add router mac */
    if (smac.num > 1)
    {
        l3if_vmac.low_8bits_mac_index = 3;
        l3if_vmac.prefix_type = CTC_L3IF_ROUTE_MAC_PFEFIX_TYPE_RSV_ROUTER_MAC;
        l3if_vmac.low_8bits_mac = smac.mac[0][5];;

        sdk_ret = ctc_l3if_add_vmac_low_8bit((uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id), &l3if_vmac);

        if (sdk_ret)
        {
            return ctc_sai_get_error_from_sdk_error(sdk_ret);
        }
    }
    
    /* add all vmac, smac.mac[1] - smac.mac[3] are vmac */
    for (index = 1; index < smac.num; index++)
    {
        l3if_vmac.low_8bits_mac = smac.mac[index][5];
        l3if_vmac.low_8bits_mac_index = index - 1;
        l3if_vmac.prefix_type = CTC_L3IF_ROUTE_MAC_PFEFIX_TYPE0;
    
        sdk_ret = ctc_l3if_add_vmac_low_8bit((uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id), &l3if_vmac);

        if (sdk_ret)
        {
            return ctc_sai_get_error_from_sdk_error(sdk_ret);
        }
    }
#else
    sdk_ret = ctc_l3if_set_interface_router_mac((uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id),
                smac);
#endif

    pvr_entry = ctc_vr_get_by_oid(vr_id);
    if (!pvr_entry)
    {
        return ctc_sai_get_error_from_sdk_error(sdk_ret);    
    }

    sal_memcpy(pvr_entry->smac, prouterintf_entry->smac, 6);

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_routerintf_set_v4_admin(
	_In_  ctc_sai_routerintf_entry_t 	*prouterintf_entry,
	_In_  const sai_attribute_t 		*attr)
{
    int32_t    	sdk_ret = 0;

    bool        admin_state = attr->value.booldata;

    CTC_SAI_ERROR_GOTO(
        ctc_l3if_set_property(
            (uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id),
                CTC_L3IF_PROP_IPV4_UCAST,admin_state),sdk_ret,out);
    /* Deleted by kcao for case igsp_func_36_forward_with_no_group.tcl, CNOS not support IPMC, enable it will result in IPMC packet do routing process */
#if 0
    CTC_SAI_ERROR_GOTO(
        ctc_l3if_set_property(
            (uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id),
                CTC_L3IF_PROP_IPV4_MCAST,admin_state),sdk_ret,out);
#endif
    prouterintf_entry->v4_admin = attr->value.booldata;

out:
    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_routerintf_set_v6_admin(
_In_  ctc_sai_routerintf_entry_t 	*prouterintf_entry,
_In_  const sai_attribute_t 		*attr)
{
    int32_t    	sdk_ret = 0;

    bool        admin_state = attr->value.booldata;

    CTC_SAI_ERROR_GOTO(
        ctc_l3if_set_property(
            (uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id),
                CTC_L3IF_PROP_IPV6_UCAST,admin_state),sdk_ret,out);
    /* Deleted by kcao for case igsp_func_36_forward_with_no_group.tcl, CNOS not support IPMC, enable it will result in IPMC packet do routing process */
#if 0
    CTC_SAI_ERROR_GOTO(
        ctc_l3if_set_property(
            (uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id),
                CTC_L3IF_PROP_IPV6_MCAST,admin_state),sdk_ret,out);
#endif
    prouterintf_entry->v4_admin = attr->value.booldata;

out:
    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_routerintf_set_mtu(
	_In_  ctc_sai_routerintf_entry_t 	*prouterintf_entry,
	_In_  const sai_attribute_t 		*attr)
{
    int32_t    sdk_ret = 0;

    CTC_SAI_ERROR_GOTO(
        ctc_l3if_set_property(
            (uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id),
                CTC_L3IF_PROP_MTU_SIZE,attr->value.u32),sdk_ret,out);

    if (!ctc_sai_get_cut_through_en()) {
        CTC_SAI_ERROR_GOTO(
            ctc_l3if_set_property(
                (uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id),
                    CTC_L3IF_PROP_MTU_EN,true),sdk_ret,out);
    }

    CTC_SAI_ERROR_GOTO(
        ctc_l3if_set_property(
            (uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id),
                CTC_L3IF_PROP_MTU_EXCEPTION_EN,true),sdk_ret,out);

    prouterintf_entry->mtu = attr->value.u32;

out:
    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_routerintf_set_urpf(
    _In_  ctc_sai_routerintf_entry_t    *prouterintf_entry,
    _In_  const sai_attribute_t         *attr)
{
    int32_t    sdk_ret = 0;
    uint32     value = CTC_L3IF_IPSA_LKUP_TYPE_NONE;

    /*get ucast sa type*/
    if (attr->value.u32)
        value = CTC_L3IF_IPSA_LKUP_TYPE_RPF;
    else
        value = CTC_L3IF_IPSA_LKUP_TYPE_NONE;

    CTC_SAI_ERROR_GOTO(
        ctc_l3if_set_property(
            (uint16_t)CTC_SAI_OBJECT_INDEX_GET(prouterintf_entry->rif_id),
                CTC_L3IF_PROP_IPV4_SA_TYPE, value), sdk_ret, out);

    prouterintf_entry->urpf = attr->value.u32;

out:
    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_routerintf_get_src_mac(
    _In_  ctc_sai_routerintf_entry_t    *prouterintf_entry,
    _Inout_  sai_attribute_t            *attr)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    sal_memcpy(&attr->value.mac,&prouterintf_entry->smac,sizeof(sai_mac_t));

    return ret;
}

sai_status_t
ctc_routerintf_get_v4_admin(
    _In_  ctc_sai_routerintf_entry_t    *prouterintf_entry,
    _Inout_  sai_attribute_t            *attr)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    if(prouterintf_entry->v4_admin)
    {
        attr->value.booldata = true;
    }
    else
    {
        attr->value.booldata = false;
    }

    return ret;
}

sai_status_t
ctc_routerintf_get_v6_admin(
	_In_  ctc_sai_routerintf_entry_t 	*prouterintf_entry,
	_Inout_  sai_attribute_t 			*attr)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    if(prouterintf_entry->v4_admin)
    {
        attr->value.booldata = true;
    }
    else
    {
        attr->value.booldata = false;
    }

    return ret;
}

sai_status_t
ctc_routerintf_get_mtu(
	_In_  ctc_sai_routerintf_entry_t 	*prouterintf_entry,
	_Inout_  sai_attribute_t 			*attr)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    attr->value.u32 = prouterintf_entry->mtu;

    return ret;
}

sai_status_t
ctc_routerintf_get_urpf(
	_In_  ctc_sai_routerintf_entry_t 	*prouterintf_entry,
	_Inout_  sai_attribute_t 			*attr)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    attr->value.u32 = prouterintf_entry->urpf;

    return ret;
}

#define ________SAI_SAI_DEBUG_FUNC
sai_status_t
ctc_sai_set_router_interface_attribute_debug_param(
    _In_ sai_object_id_t rif_id,
    _In_ const sai_attribute_t *attr)
{
    CTC_SAI_DEBUG("in:rif_id %u", rif_id);
    switch(attr->id)
    {
    case SAI_ROUTER_INTERFACE_ATTR_SRC_MAC_ADDRESS:
        CTC_SAI_DEBUG("in:SAI_ROUTER_INTERFACE_ATTR_SRC_MAC_ADDRESS");
        break;
    case SAI_ROUTER_INTERFACE_ATTR_ADMIN_V4_STATE:
        CTC_SAI_DEBUG("in:SAI_ROUTER_INTERFACE_ATTR_ADMIN_V4_STATE %u", attr->value.booldata);
        break;
    case SAI_ROUTER_INTERFACE_ATTR_ADMIN_V6_STATE:
        CTC_SAI_DEBUG("in:SAI_ROUTER_INTERFACE_ATTR_ADMIN_V6_STATE %u", attr->value.booldata);
        break;
    case SAI_ROUTER_INTERFACE_ATTR_MTU:
        CTC_SAI_DEBUG("in:SAI_ROUTER_INTERFACE_ATTR_MTU %u", attr->value.u32);
        break;
     case SAI_ROUTER_INTERFACE_ATTR_VMAC_ADDRESS:
        CTC_SAI_DEBUG("in:SAI_ROUTER_INTERFACE_ATTR_VMAC_ADDRESS");
        break;
    }
    return SAI_STATUS_SUCCESS;
}
sai_status_t
ctc_sai_get_router_interface_attribute_debug_param(
    _In_ sai_object_id_t rif_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{
    uint32_t                    attr_idx    = 0;
    const sai_attribute_t *attr = NULL;

    CTC_SAI_DEBUG("in:rif_id %"PRIu64" attr_count %u", rif_id, attr_count);
    for (attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        switch (attr->id)
        {
        case SAI_ROUTER_INTERFACE_ATTR_SRC_MAC_ADDRESS:
            CTC_SAI_DEBUG("in:SAI_ROUTER_INTERFACE_ATTR_SRC_MAC_ADDRESS");
            break;
        case SAI_ROUTER_INTERFACE_ATTR_ADMIN_V4_STATE:
            CTC_SAI_DEBUG("in:SAI_ROUTER_INTERFACE_ATTR_ADMIN_V4_STATE %u", attr->value.booldata);
            break;
        case SAI_ROUTER_INTERFACE_ATTR_ADMIN_V6_STATE:
            CTC_SAI_DEBUG("in:SAI_ROUTER_INTERFACE_ATTR_ADMIN_V4_STATE %u", attr->value.booldata);
            break;
        case SAI_ROUTER_INTERFACE_ATTR_MTU:
            CTC_SAI_DEBUG("in:SAI_ROUTER_INTERFACE_ATTR_MTU %u", attr->value.u32);
            break;
        }
    }

    return SAI_STATUS_SUCCESS;
}
#define ________SAI_SAI_API_FUNC

/*
* Routine Description:
*    Create router interface.
*
* Arguments:
*    [out] rif_id - router interface id
*    [in] attr_count - number of attributes
*    [in] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_create_router_interface(
    _Out_ sai_object_id_t* rif_id,
    _In_ uint32_t attr_count,
    _In_ sai_attribute_t *attr_list)
{
    sai_status_t                 ret 				= SAI_STATUS_SUCCESS;
    ctc_sai_attr_entry_list_t    *pattr_entry_list 	= NULL;
    ctc_sai_routerintf_entry_t   *prouter_intf_entry = NULL;
    sai_attribute_t              attr;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_PTR_VALID_CHECK(rif_id);
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    sal_memset(&attr,0,sizeof(sai_attribute_t));

    CTC_SAI_ERROR_GOTO(ctc_sai_attr_alloc_attr_entry_list(g_sai_attr_entries,
                            attr_list,
                            attr_count,
                            &pattr_entry_list),ret,out);

    CTC_SAI_ERROR_GOTO(ctc_sai_attr_check_attr_entry_list(g_sai_attr_entries,
                            pattr_entry_list),ret,out);

    if(pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_TYPE].value.s32 == SAI_ROUTER_INTERFACE_TYPE_PORT)
    {
        if(!pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_PORT_ID].valid)
        {
            ret = SAI_STATUS_MANDATORY_ATTRIBUTE_MISSING;
            goto out;
        }
    }

    if(pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_TYPE].value.s32 == SAI_ROUTER_INTERFACE_TYPE_VLAN)
    {
        if(!pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_VLAN_ID].valid)
        {
            ret = SAI_STATUS_MANDATORY_ATTRIBUTE_MISSING;
            goto out;
        }
    }

    CTC_SAI_ERROR_GOTO(ctc_routerintf_alloc(&prouter_intf_entry),ret,out);

    prouter_intf_entry->pvr =
        ctc_vr_get_by_oid(
            pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_VIRTUAL_ROUTER_ID].value.oid);
    if(NULL == prouter_intf_entry->pvr)
    {
        goto out1;
    }

    prouter_intf_entry->type =
        pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_TYPE].value.s32;

    if(SAI_ROUTER_INTERFACE_TYPE_PORT == prouter_intf_entry->type)
    {
        prouter_intf_entry->port_oid=
            pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_PORT_ID].value.oid;
    }
    else if(SAI_ROUTER_INTERFACE_TYPE_VLAN == prouter_intf_entry->type)
    {
        prouter_intf_entry->vlan_id=
            pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_VLAN_ID].value.u16;
    }

    CTC_SAI_ERROR_GOTO(ctc_routerintf_add_entry(prouter_intf_entry),ret,out1);

    *rif_id = prouter_intf_entry->rif_id;

    if(pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_SRC_MAC_ADDRESS].valid)
    {
        attr.id = SAI_ROUTER_INTERFACE_ATTR_SRC_MAC_ADDRESS;
        attr.value = pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_SRC_MAC_ADDRESS].value;
        ctc_sai_set_router_interface_attribute(prouter_intf_entry->rif_id,
                        &attr);
    }else{
        if(is_valid_ether_addr((uint8_t*)&prouter_intf_entry->pvr->smac))
        {
            ctc_routerintf_update_src_mac(prouter_intf_entry,
                (uint8_t*)&prouter_intf_entry->pvr->smac);
        }
    }

    if(pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_ADMIN_V4_STATE].valid)
    {
        attr.id = SAI_ROUTER_INTERFACE_ATTR_ADMIN_V4_STATE;
        attr.value = pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_ADMIN_V4_STATE].value;
        ctc_sai_set_router_interface_attribute(prouter_intf_entry->rif_id,
                        &attr);
    }

    if(pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_ADMIN_V6_STATE].valid)
    {
        attr.id = SAI_ROUTER_INTERFACE_ATTR_ADMIN_V6_STATE;
        attr.value = pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_ADMIN_V6_STATE].value;
        ctc_sai_set_router_interface_attribute(prouter_intf_entry->rif_id,
                        &attr);
    }

    if(pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_MTU].valid)
    {
        attr.id = SAI_ROUTER_INTERFACE_ATTR_MTU;
        attr.value.u32 = pattr_entry_list[SAI_ROUTER_INTERFACE_ATTR_MTU].value.u32;
        ctc_sai_set_router_interface_attribute(prouter_intf_entry->rif_id,
                        &attr);
    }

out:
    if(pattr_entry_list)
    {
        ctc_sai_attr_free_attr_entry_list(pattr_entry_list);
    }

    return ret;
out1:
    if(prouter_intf_entry->pvr)
    {
        ctc_vr_release(prouter_intf_entry->pvr);
    }

    if(prouter_intf_entry)
    {
        ctc_routerintf_release(prouter_intf_entry);
    }
    goto out;
}

/*
* Routine Description:
*    Remove router interface
*
* Arguments:
*    [in] rif_id - router interface id
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_remove_router_interface(
    _In_ sai_object_id_t rif_id)
{
    sai_status_t                 ret = SAI_STATUS_SUCCESS;
    ctc_sai_routerintf_entry_t   *prouter_intf_entry = NULL;

    CTC_SAI_DEBUG_FUNC();

    prouter_intf_entry = ctc_routerintf_get_by_oid_no_ref(rif_id);
    if(NULL == prouter_intf_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    CTC_SAI_ERROR_GOTO(ctc_routerintf_remove_entry(prouter_intf_entry),ret,out);

    ctc_vr_release(prouter_intf_entry->pvr);
    ctc_routerintf_release(prouter_intf_entry);
out:
    return ret;
}

/*
* Routine Description:
*    Set router interface attribute
*
* Arguments:
*    [in] rif_id - router interface id
*    [in] attr - attribute
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_set_router_interface_attribute(
    _In_ sai_object_id_t rif_id,
    _In_ const sai_attribute_t *attr)
{
    sai_status_t                ret = SAI_STATUS_SUCCESS;
    ctc_sai_routerintf_entry_t  *prouter_intf_entry = NULL;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_PTR_VALID_CHECK(attr);

    CTC_SAI_ERROR_GOTO(ctc_sai_attr_check_write_attr(g_sai_attr_entries,attr),ret,out);

    prouter_intf_entry = ctc_routerintf_get_by_oid_no_ref(rif_id);
    if(NULL == prouter_intf_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    ctc_sai_set_router_interface_attribute_debug_param(rif_id, attr);
    switch(attr->id)
    {
    case SAI_ROUTER_INTERFACE_ATTR_SRC_MAC_ADDRESS:
        ret = ctc_routerintf_set_src_mac(prouter_intf_entry, attr);
        break;
    case SAI_ROUTER_INTERFACE_ATTR_ADMIN_V4_STATE:
        ret = ctc_routerintf_set_v4_admin(prouter_intf_entry, attr);
        break;
    case SAI_ROUTER_INTERFACE_ATTR_ADMIN_V6_STATE:
        ret = ctc_routerintf_set_v6_admin(prouter_intf_entry, attr);
        break;
    case SAI_ROUTER_INTERFACE_ATTR_MTU:
        ret = ctc_routerintf_set_mtu(prouter_intf_entry, attr);
        break;
    case SAI_ROUTER_INTERFACE_ATTR_URPF:
        ret = ctc_routerintf_set_urpf(prouter_intf_entry, attr);
        break;
    case SAI_ROUTER_INTERFACE_ATTR_VMAC_ADDRESS:
        ret = ctc_routerintf_set_vmac(prouter_intf_entry, attr);
        break;
    }

out:
    return ret;
}


/*
* Routine Description:
*    Get router interface attribute
*
* Arguments:
*    [in] rif_id - router interface id
*    [in] attr_count - number of attributes
*    [inout] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_get_router_interface_attribute(
    _In_ sai_object_id_t rif_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{
    sai_status_t                ret         = SAI_STATUS_SUCCESS;
    sai_attribute_t*            attr        = NULL;
    uint32_t                    attr_idx    = 0;
    ctc_sai_routerintf_entry_t  *prouter_intf_entry = NULL;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    prouter_intf_entry = ctc_routerintf_get_by_oid_no_ref(rif_id);
    if(NULL == prouter_intf_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        ret = ctc_sai_attr_check_read_attr(g_sai_attr_entries,attr);

        if(ret != SAI_STATUS_SUCCESS)
        {
            return ret + attr_idx;
        }

        switch(attr->id)
        {
        case SAI_ROUTER_INTERFACE_ATTR_SRC_MAC_ADDRESS:
            ret = ctc_routerintf_get_src_mac(prouter_intf_entry,attr);
            break;
        case SAI_ROUTER_INTERFACE_ATTR_ADMIN_V4_STATE:
            ret = ctc_routerintf_get_v4_admin(prouter_intf_entry,attr);
            break;
        case SAI_ROUTER_INTERFACE_ATTR_ADMIN_V6_STATE:
            ret = ctc_routerintf_get_v6_admin(prouter_intf_entry,attr);
            break;
        case SAI_ROUTER_INTERFACE_ATTR_MTU:
            ret = ctc_routerintf_get_mtu(prouter_intf_entry,attr);
            break;
        case SAI_ROUTER_INTERFACE_ATTR_URPF:
            ret = ctc_routerintf_get_urpf(prouter_intf_entry, attr);
            break;
        }

        if(ret != SAI_STATUS_SUCCESS)
        {
            break;
        }
    }

    ctc_sai_get_router_interface_attribute_debug_param(rif_id, attr_count, attr_list);
    return ret;
}

#define ________SAI_INNER_FUNC
static sai_status_t
__init_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    CTC_SAI_ERROR_GOTO(ctc_routerintf_init(),ret,out);

    preg->init_status =  INITIALIZED;

out:
    return ret;
}

static sai_status_t
__exit_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}


static sai_router_interface_api_t      g_sai_api_func = {
    .create_router_interface      		= ctc_sai_create_router_interface,
    .remove_router_interface      		= ctc_sai_remove_router_interface,
    .set_router_interface_attribute     = ctc_sai_set_router_interface_attribute,
    .get_router_interface_attribute     = ctc_sai_get_router_interface_attribute,
};

static ctc_sai_api_reg_info_t g_api_reg_info = {
        .id  		= SAI_API_ROUTER_INTERFACE,
        .init_func 	= __init_mode_fn,
        .exit_func 	= __exit_mode_fn,
        .api_method_table = &g_sai_api_func,
        .private_data     = NULL,
};

#define ________SAI_OUTER_FUNC
sai_status_t
ctc_sai_routerintf_init()
{
    api_reg_register_fn(&g_api_reg_info);

    return SAI_STATUS_SUCCESS;
}


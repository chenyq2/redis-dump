#if !defined (__SAI_ROUTERINTF_H_)
#define __SAI_ROUTERINTF_H_

#include <sairouterintf.h>
#include <ctc_vector.h>
#include <ctc_opf.h>

struct ctc_sai_vr_entry_s;
typedef struct ctc_sai_routerintf_entry_s
{
    int32_t                 type;                       /* sai_router_interface_type_t */
    sai_object_id_t         port_oid;
    sai_vlan_id_t           vlan_id;
    sai_ip_address_t        ip;
    sai_object_id_t         rif_id;
    sai_mac_t               smac;
    uint32_t                mtu;
    uint32_t                urpf;
    bool                    v4_admin;
    bool                    v6_admin;
    struct ctc_sai_vr_entry_s      *pvr;               	/* -> ctc_sai_vr_entry_t */
}ctc_sai_routerintf_entry_t;

typedef struct ctc_sai_routerintf_info_s
{
    ctc_vector_t*   pvector;
    uint32_t        max_count;
    ctc_opf_t       opf;
}ctc_sai_routerintf_info_t;

ctc_sai_routerintf_entry_t*
ctc_routerintf_get_by_vlan(
	_In_  const sai_vlan_id_t);

ctc_sai_routerintf_entry_t*
ctc_routerintf_get_by_port_oid(
	_In_  const sai_object_id_t port_oid);

void
ctc_routerintf_release(
	_In_  ctc_sai_routerintf_entry_t *);

ctc_sai_routerintf_entry_t*
ctc_routerintf_get_by_oid(
	_In_  const sai_object_id_t rif_id);

ctc_sai_routerintf_entry_t*
ctc_routerintf_get_by_oid_no_ref(
	_In_  const sai_object_id_t rif_id);

sai_status_t
ctc_routerintf_update_src_mac(
	_In_  const ctc_sai_routerintf_entry_t *,
	_In_  const uint8_t *);

sai_status_t
ctc_routerintf_set_v4_admin(
	_In_  ctc_sai_routerintf_entry_t *,
	_In_  const sai_attribute_t *);

sai_status_t
ctc_routerintf_set_v6_admin(
	_In_  ctc_sai_routerintf_entry_t *,
	_In_  const sai_attribute_t *);

sai_status_t
ctc_sai_set_router_interface_attribute(
    _In_ sai_object_id_t ,
    _In_ const sai_attribute_t *);

sai_status_t
ctc_sai_routerintf_init(void);

sai_status_t
ctc_routerintf_alloc(
    _Out_ ctc_sai_routerintf_entry_t** prouterintf_entry);

sai_status_t
ctc_routerintf_add_entry(
	_In_  ctc_sai_routerintf_entry_t *prouterintf_entry);

sai_status_t
ctc_routerintf_remove_entry(
	_In_  ctc_sai_routerintf_entry_t *prouterintf_entry);

int32
ctc_routerintf_alloc_l3if_id(uint32_t *l3if_id);

int32
ctc_routerintf_release_l3if_id(uint32_t l3if_id);

#endif


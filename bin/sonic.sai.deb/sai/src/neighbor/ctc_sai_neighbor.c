#include <sai.h>
#include <sal.h>
#include "ctc_api.h"
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_notifier_call.h>
#include <ctc_sai_sai.h>
#include <ctc_sai_fdb.h>
#include <ctc_sai_neighbor.h>
#include <ctc_sai_routerintf.h>
#include <ctc_sai_hostif.h>
#include <ctc_sai_nexthop.h>
#include <ctc_sai_port.h>
#include <ctc_sai_debug.h>

#define NEIGHBOR_HASH_BLOCK_SIZE    64
#define ROUTED_FDB_AGE_ARP_NOTIFY   1

SAI_NEI_CB g_hsrv_neighbor_fdb_cb = NULL;

static ctc_sai_neighbor_info_t 	g_sai_neighbor_info;

static sai_status_t
__ctc_sai_check_action_fn(
	_In_  ctc_sai_attr_entry_list_t *pattr,
	_In_  void 						*data);

static ctc_sai_attr_entry_info_t g_sai_attr_entries[] = {
    {
        .id     = SAI_NEIGHBOR_ATTR_DST_MAC_ADDRESS,
        .type   = SAI_ATTR_FALG_CREATE | SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_NEIGHBOR_ATTR_PACKET_ACTION,
        .type   = SAI_ATTR_FLAG_DEFAULT | SAI_ATTR_FALG_READ | SAI_ATTR_FALG_WRITE | SAI_ATTR_FALG_CREATE,
        .default_value.s32 = SAI_PACKET_ACTION_FORWARD,
        .check_fn = {
            .func_fn = __ctc_sai_check_action_fn,
            .func_parameter = NULL,
        }
    },
    {
        .id     = SAI_ATTR_ID_END,
        .type   = 0,
    },
};

#define ________SAI_SAI_INNER_API_FUNC
static uint32_t
__neighbor_hash_make(
	_In_  void* data)
{
    sai_neighbor_entry_t* pnb_key = (sai_neighbor_entry_t*)data;

    return ctc_hash_caculate(sizeof(sai_neighbor_entry_t), pnb_key);
}


static bool
__neighbor_hash_cmp(
	_In_  sai_neighbor_entry_t* pnb_key,
	_In_  sai_neighbor_entry_t* pnb_key1)
{
    if (sal_memcmp(&pnb_key->ip_address,&pnb_key1->ip_address,sizeof(sai_ip_address_t)))
    {
        return FALSE;
    }

    if (pnb_key->rif_id != pnb_key1->rif_id)
    {
        return FALSE;
    }

    return TRUE;
}

int32
sai_nei_register_fdb(SAI_NEI_CB fn)
{
    g_hsrv_neighbor_fdb_cb = fn;
    return SAI_STATUS_SUCCESS;
}


sai_status_t
neighbor_update_nexthop_bk(
    _In_  ctc_sai_neighbor_entry_t  *pst_neighbor,
    _In_  sai_object_id_t           portid,
    _In_  uint32_t                  update_type)
{
    ctc_sai_routerintf_entry_t  *pst_routerintf = NULL;
    ctc_ip_nh_param_t            nh_param;
    ctc_ipuc_param_t             ipuc_info;
    uint32                       nh_id    = 0;
    int32                        sdk_ret  = 0;

    sal_memset(&nh_param, 0, sizeof(nh_param));

    if (CTC_LPORT_CPU == portid)
    {
        nh_param.oif.oif_type   = CTC_NH_OIF_TYPE_ROUTED_PORT;
    }
    else
    {
        /* 1. get router interface information */
        pst_routerintf = ctc_routerintf_get_by_oid(pst_neighbor->rif);
        if (NULL != pst_routerintf)
        {
            if (SAI_ROUTER_INTERFACE_TYPE_VLAN == pst_routerintf->type)
            {
                nh_param.oif.vid        = pst_routerintf->vlan_id;
                nh_param.oif.oif_type   = CTC_NH_OIF_TYPE_VLAN_PORT;
            }
            else
            {
                nh_param.oif.oif_type   = CTC_NH_OIF_TYPE_ROUTED_PORT;
            }
        }
        /* remove neighbor, maybe router interface has been removed */
        else
        {
            nh_param.oif.oif_type   = CTC_NH_OIF_TYPE_ROUTED_PORT;
        }
    }

    /* 2. set port id */
    pst_neighbor->port = portid;

    /* 3. set parameter */
    nh_id = CTC_SAI_OBJECT_INDEX_GET(pst_neighbor->nhid);

    nh_param.dsnh_offset 	= 0;
    nh_param.upd_type 		= CTC_NH_UPD_FWD_ATTR;
    sal_memcpy(nh_param.mac, pst_neighbor->mac, sizeof(sai_mac_t));
    ctc_sai_port_objectid_to_gport(pst_neighbor->port, &nh_param.oif.gport);

    /* 4. create neigbor ,one router should be created */
    if(SAI_NEIGHBOR_CREATE == update_type)
    {
        sdk_ret = ctc_nh_update_ipuc(nh_id, &nh_param);
        if (0 == sdk_ret)
        {
            sal_memset(&ipuc_info,0,sizeof(ctc_ipuc_param_t));

            if(SAI_IP_ADDR_FAMILY_IPV4 == pst_neighbor->key.ip_address.addr_family)
            {
                ipuc_info.ip.ipv4 = pst_neighbor->key.ip_address.addr.ip4;
                ipuc_info.masklen = 32;
                ipuc_info.ip_ver  = CTC_IP_VER_4;
            }
            else
            {
                sal_memcpy(ipuc_info.ip.ipv6, pst_neighbor->key.ip_address.addr.ip6, sizeof(sai_ip6_t));
                ipuc_info.masklen = 128;
                ipuc_info.ip_ver  = CTC_IP_VER_6;
            }

            ipuc_info.nh_id = nh_id;
            ipuc_info.route_flag = CTC_IPUC_FLAG_NEIGHBOR;
            CTC_SET_FLAG(ipuc_info.route_flag, CTC_IPUC_FLAG_TTL_CHECK);
            sdk_ret = ctc_ipuc_add(&ipuc_info);
        }
    }
    /* 5. remove neigbor ,one router should be removed */
    else if(SAI_NEIGHBOR_REMOVE == update_type)
    {
        //ctc_nh_update_ipuc(nh_id, &nh_param);
        sal_memset(&ipuc_info,0,sizeof(ctc_ipuc_param_t));

        if(SAI_IP_ADDR_FAMILY_IPV4 == pst_neighbor->key.ip_address.addr_family)
        {
            ipuc_info.ip.ipv4 = pst_neighbor->key.ip_address.addr.ip4;
            ipuc_info.masklen = 32;
            ipuc_info.ip_ver  = CTC_IP_VER_4;
        }
        else
        {
            sal_memcpy(ipuc_info.ip.ipv6,pst_neighbor->key.ip_address.addr.ip6,sizeof(sai_ip6_t));
            ipuc_info.masklen = 128;
            ipuc_info.ip_ver  = CTC_IP_VER_6;
        }

        ipuc_info.nh_id = nh_id;
        ipuc_info.route_flag = CTC_IPUC_FLAG_NEIGHBOR;
        sdk_ret = ctc_ipuc_remove(&ipuc_info);

        sdk_ret = ctc_nh_update_ipuc(nh_id, &nh_param);
    }
    else if(SAI_NEIGHBOR_UPDATE_PORT == update_type)
    {
        sdk_ret = ctc_nh_update_ipuc(nh_id, &nh_param);
    }
    else if(SAI_NEIGHBOR_UPDATE_ACTION == update_type)
    {
        sdk_ret = ctc_nh_update_ipuc(nh_id, &nh_param);
    }

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
neighbor_update_nexthop(
    _In_  ctc_sai_neighbor_entry_t  *pst_neighbor,
    _In_  sai_object_id_t           portid,
    _In_  uint32_t                  update_type)
{
    ctc_sai_routerintf_entry_t  *pst_routerintf = NULL;
    ctc_ip_nh_param_t            nh_param;
    ctc_ipuc_param_t             ipuc_info;
    uint32                       nh_id    = 0;
    int32                        sdk_ret  = 0;
    uint32                      update_act = 0;
    sal_memset(&nh_param, 0, sizeof(nh_param));

    update_act = update_type;
    if (SAI_NEIGHBOR_UPDATE_PORT == update_type || SAI_NEIGHBOR_UPDATE_PORT == update_type)
    {
        if (portid == CTC_LPORT_CPU)
        {
            update_act = SAI_NEIGHBOR_REMOVE;
        }
        else
        {
            update_act = SAI_NEIGHBOR_CREATE;
        }
    }

    ctc_sai_port_objectid_to_gport(portid, &nh_param.oif.gport);

    /* 1. get router interface information */
    pst_routerintf = ctc_routerintf_get_by_oid(pst_neighbor->rif);
    if (NULL != pst_routerintf)
    {
        if (SAI_ROUTER_INTERFACE_TYPE_VLAN == pst_routerintf->type)
        {
            nh_param.oif.vid        = pst_routerintf->vlan_id;
            nh_param.oif.oif_type   = CTC_NH_OIF_TYPE_VLAN_PORT;
            if (portid == CTC_LPORT_CPU && SAI_NEIGHBOR_CREATE == update_type)
            {
                return 0;
            }
        }
        else
        {
            nh_param.oif.oif_type   = CTC_NH_OIF_TYPE_ROUTED_PORT;
            ctc_sai_port_objectid_to_gport(pst_routerintf->port_oid, &nh_param.oif.gport);
        }
    }
    /* remove neighbor, maybe router interface has been removed */
    else
    {
        nh_param.oif.oif_type   = CTC_NH_OIF_TYPE_ROUTED_PORT;
    }

    /* 2. set port id */
    pst_neighbor->port = portid;

    /* 3. set parameter */
    nh_id = CTC_SAI_OBJECT_INDEX_GET(pst_neighbor->nhid);

    nh_param.dsnh_offset    = 0;
    //nh_param.upd_type       = CTC_NH_UPD_FWD_ATTR;
    sal_memcpy(nh_param.mac, pst_neighbor->mac, sizeof(sai_mac_t));

    /* 4. create neigbor ,one router should be created */
    if(SAI_NEIGHBOR_CREATE == update_act)
    {
        nh_param.upd_type       = CTC_NH_UPD_UNRSV_TO_FWD;
        sdk_ret = ctc_nh_update_ipuc(nh_id, &nh_param);
        if (0 == sdk_ret)
        {
            sal_memset(&ipuc_info,0,sizeof(ctc_ipuc_param_t));

            if(SAI_IP_ADDR_FAMILY_IPV4 == pst_neighbor->key.ip_address.addr_family)
            {
                ipuc_info.ip.ipv4 = pst_neighbor->key.ip_address.addr.ip4;
                ipuc_info.masklen = 32;
                ipuc_info.ip_ver  = CTC_IP_VER_4;
            }
            else
            {
                sal_memcpy(ipuc_info.ip.ipv6, pst_neighbor->key.ip_address.addr.ip6, sizeof(sai_ip6_t));
                ipuc_info.masklen = 128;
                ipuc_info.ip_ver  = CTC_IP_VER_6;
            }

            ipuc_info.nh_id = nh_id;
            ipuc_info.route_flag = CTC_IPUC_FLAG_NEIGHBOR;
            CTC_SET_FLAG(ipuc_info.route_flag, CTC_IPUC_FLAG_TTL_CHECK);
            CTC_SET_FLAG(ipuc_info.route_flag, CTC_IPUC_FLAG_ICMP_CHECK);
            sdk_ret = ctc_ipuc_add(&ipuc_info);
        }
    }
    /* 5. remove neigbor ,one router should be removed */
    else if(SAI_NEIGHBOR_REMOVE == update_act)
    {
        nh_param.upd_type       = CTC_NH_UPD_FWD_TO_UNRSV;
        sal_memset(&ipuc_info,0,sizeof(ctc_ipuc_param_t));

        if(SAI_IP_ADDR_FAMILY_IPV4 == pst_neighbor->key.ip_address.addr_family)
        {
            ipuc_info.ip.ipv4 = pst_neighbor->key.ip_address.addr.ip4;
            ipuc_info.masklen = 32;
            ipuc_info.ip_ver  = CTC_IP_VER_4;
        }
        else
        {
            sal_memcpy(ipuc_info.ip.ipv6,pst_neighbor->key.ip_address.addr.ip6,sizeof(sai_ip6_t));
            ipuc_info.masklen = 128;
            ipuc_info.ip_ver  = CTC_IP_VER_6;
        }

        ipuc_info.nh_id = nh_id;
        ipuc_info.route_flag = CTC_IPUC_FLAG_NEIGHBOR;
        sdk_ret = ctc_ipuc_remove(&ipuc_info);

        sdk_ret = ctc_nh_update_ipuc(nh_id, &nh_param);
    }
    else if(SAI_NEIGHBOR_UPDATE_PORT == update_act)
    {
        sdk_ret = ctc_nh_update_ipuc(nh_id, &nh_param);
    }
    else if(SAI_NEIGHBOR_UPDATE_ACTION == update_act)
    {
        sdk_ret = ctc_nh_update_ipuc(nh_id, &nh_param);
    }

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_neighbor_alloc(
	_In_  ctc_sai_neighbor_entry_t** ppnb_entry)
{
    sai_status_t                	ret 		= SAI_STATUS_SUCCESS;
    ctc_sai_neighbor_entry_t    	*pnb_entry 	= NULL;

    if (g_sai_neighbor_info.phash->count >= g_sai_neighbor_info.max_count)
    {
        ret = SAI_STATUS_TABLE_FULL;
        goto out;
    }

    pnb_entry = mem_malloc(MEM_APP_NEIGHBOR_MODULE,sizeof(ctc_sai_neighbor_entry_t));
    if (NULL == pnb_entry)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }
    sal_memset(pnb_entry, 0, sizeof(ctc_sai_neighbor_entry_t));

    *ppnb_entry = pnb_entry;

out:
    return ret;
}

void
ctc_neighbor_release(
	_In_  ctc_sai_neighbor_entry_t *pnb_entry)
{
    if(NULL == pnb_entry)
    {
        return ;
    }

    mem_free(pnb_entry);
}

ctc_sai_neighbor_entry_t*
ctc_neighbor_get_by_key(
    _In_  const sai_neighbor_entry_t* pkey)
{
    ctc_sai_neighbor_entry_t  *pnb_entry = NULL;

    pnb_entry = ctc_hash_lookup(g_sai_neighbor_info.phash,(void*)pkey);

    return pnb_entry;
}

sai_status_t
ctc_neighbor_add_entry(
    _In_  ctc_sai_neighbor_entry_t *neighbor_entry)
{
    sai_status_t        ret     = SAI_STATUS_SUCCESS;
    sai_fdb_entry_t     key;
    ctc_sai_routerintf_entry_t *pst_routerintf = NULL;
    ctc_sai_fdb_entry_t fdb_entry;
    sai_object_id_t port_id = 0;

    sal_memset(&fdb_entry,0,sizeof(ctc_sai_fdb_entry_t));
    sal_memset(&key,0,sizeof(sai_fdb_entry_t));

    pst_routerintf = ctc_routerintf_get_by_oid(neighbor_entry->rif);
    if (NULL == pst_routerintf)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }

    if(SAI_ROUTER_INTERFACE_TYPE_VLAN == pst_routerintf->type)
    {
        if (SAI_STATUS_SUCCESS != ctc_fdb_get_portid(neighbor_entry->mac, pst_routerintf->vlan_id, &port_id))
        {
            port_id = CTC_LPORT_CPU;
            if (0 && SAI_STATUS_SUCCESS != ctc_arp_fdb_get_portid(neighbor_entry->mac, pst_routerintf->vlan_id, &port_id))
            {
                port_id = CTC_LPORT_CPU;
            }
        }
    }
    else
    {
        port_id = pst_routerintf->port_oid;
    }

    ctc_hash_insert(g_sai_neighbor_info.phash, &neighbor_entry->key);

    CTC_SAI_ERROR_GOTO(
        neighbor_update_nexthop(neighbor_entry, port_id, SAI_NEIGHBOR_CREATE),
        ret,out);

out:
    return ret;
}


sai_status_t
ctc_neighbor_update_entry(
    _In_  ctc_sai_neighbor_entry_t *neighbor_entry)
{
    sai_status_t        ret     = SAI_STATUS_SUCCESS;
    sai_fdb_entry_t     key;
    ctc_sai_routerintf_entry_t *pst_routerintf = NULL;
    ctc_sai_fdb_entry_t fdb_entry;
    sai_object_id_t port_id = 0;

    sal_memset(&fdb_entry,0,sizeof(ctc_sai_fdb_entry_t));
    sal_memset(&key,0,sizeof(sai_fdb_entry_t));

    pst_routerintf = ctc_routerintf_get_by_oid(neighbor_entry->rif);
    if (NULL == pst_routerintf)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }

    if(SAI_ROUTER_INTERFACE_TYPE_VLAN == pst_routerintf->type)
    {
        if (SAI_STATUS_SUCCESS != ctc_fdb_get_portid(neighbor_entry->mac, pst_routerintf->vlan_id, &port_id))
        {
            port_id = CTC_LPORT_CPU;
            if (0 && SAI_STATUS_SUCCESS != ctc_arp_fdb_get_portid(neighbor_entry->mac, pst_routerintf->vlan_id, &port_id))
            {
                port_id = CTC_LPORT_CPU;
            }
        }
    }
    else
    {
        port_id = pst_routerintf->port_oid;
    }

    CTC_SAI_ERROR_GOTO(
        neighbor_update_nexthop(neighbor_entry, port_id, SAI_NEIGHBOR_CREATE),
        ret,out);

out:
    return ret;
}


sai_status_t
ctc_neighbor_remove_entry(
	_In_  ctc_sai_neighbor_entry_t *pnb_entry)
{
    sai_object_id_t dma_port = CTC_LPORT_CPU;
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    ctc_hash_remove(g_sai_neighbor_info.phash,&pnb_entry->key);

    CTC_SAI_ERROR_GOTO(
        neighbor_update_nexthop(pnb_entry, dma_port, SAI_NEIGHBOR_REMOVE),
        ret,out);
out:
    return ret;
}

static int32_t
__hash_traversal_remove_nb(
	_In_  void	*array_data,
	_In_  void	*user_data)
{
    ctc_sai_neighbor_entry_t *pnb_entry  = NULL;

    pnb_entry = array_data;

    if(!ctc_neighbor_remove_entry(pnb_entry))
    {
        ctc_neighbor_release(pnb_entry);
    }

    return 0;
}

sai_status_t
ctc_neighbor_remove_all()
{
    return ctc_hash_traverse(g_sai_neighbor_info.phash,__hash_traversal_remove_nb,NULL);
}

sai_status_t
ctc_neighbor_set_mac(
	_In_  ctc_sai_neighbor_entry_t 	*pnb_entry,
	_In_  const sai_attribute_t 	*attr)
{
    sai_status_t    ret = SAI_STATUS_NOT_SUPPORTED;

    if(SAI_STATUS_SUCCESS == ret)
    {
        sal_memcpy(&pnb_entry->mac,&attr->value.mac,sizeof(sai_mac_t));
    }

    return ret;
}

sai_status_t
ctc_neighbor_get_mac(
	_In_  ctc_sai_neighbor_entry_t 	*pnb_entry,
	_Inout_ sai_attribute_t 		*attr)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    sal_memcpy(&attr->value.mac,&pnb_entry->mac,sizeof(sai_mac_t));

    return ret;
}

sai_status_t
ctc_neighbor_set_action(
	_In_  ctc_sai_neighbor_entry_t 	*pnb_entry,
	_In_  const sai_attribute_t 	*attr)
{
    sai_object_id_t port_id = CTC_LPORT_CPU;
    sai_status_t ret = SAI_STATUS_SUCCESS;
    uint32_t        old_action 	= 0;

    old_action = (uint32_t)pnb_entry->action;

    pnb_entry->action = attr->value.s32;

    ret = neighbor_update_nexthop(pnb_entry, port_id, SAI_NEIGHBOR_UPDATE_ACTION);
    if(SAI_STATUS_SUCCESS != ret)
    {
        pnb_entry->action = old_action;
        goto out;
    }

out:
    return ret;
}

sai_status_t
ctc_neighbor_get_action(
	_In_  ctc_sai_neighbor_entry_t 	*pnb_entry,
	_Inout_ sai_attribute_t 		*attr)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    attr->value.s32 = pnb_entry->action;

    return ret;
}

typedef struct
{
    ctc_sai_arp_fdb_t *pst_arp_fdb;
    uint32 action;
} arp_fdb_update_argv_t;

static int32_t
ctc_arp_fdb_update_neighbor(
	_In_  void	*array_data,
	_In_  void	*user_data)
{
    ctc_sai_neighbor_entry_t    *pst_neighbor      = array_data;
    arp_fdb_update_argv_t       *arp_fdb_argv      = user_data;
    ctc_sai_arp_fdb_t           *pst_arp_fdb       = NULL;
    ctc_sai_routerintf_entry_t  *prouterintf_entry = NULL;
    sai_object_id_t              port_id = 0;
    uint32                       action = 0;

    if ((NULL == pst_neighbor) || (NULL == arp_fdb_argv))
    {
        return 0;
    }

    pst_arp_fdb = arp_fdb_argv->pst_arp_fdb;
    action = arp_fdb_argv->action;

    prouterintf_entry = ctc_routerintf_get_by_oid(pst_neighbor->rif);
    if ((NULL == prouterintf_entry)
        || (SAI_ROUTER_INTERFACE_TYPE_VLAN != prouterintf_entry->type)
        || (prouterintf_entry->vlan_id != pst_arp_fdb->vlanid)
        || (0 != sal_memcmp(pst_neighbor->mac, pst_arp_fdb->mac_address, sizeof(sai_mac_t))))
    {
        return 0;
    }

    switch(action)
    {
    case SAI_ARP_FDB_EVENT_LEARNED:
        port_id = pst_arp_fdb->port;
        break;

    case SAI_ARP_FDB_EVENT_AGED:
    case SAI_ARP_FDB_EVENT_FLUSHED:
        port_id = CTC_LPORT_CPU;
        if (NULL != g_hsrv_neighbor_fdb_cb)
        {
            (*g_hsrv_neighbor_fdb_cb)(&pst_neighbor->key);
        }
        break;
    }

    if (pst_neighbor->port != port_id)
    {
        neighbor_update_nexthop(pst_neighbor, port_id, SAI_NEIGHBOR_UPDATE_PORT);
    }

    return 0;
}

int32_t
ctc_arp_fdb_update_nexthop(void *arp_fdb, uint32 action)
{
    ctc_sai_routerintf_entry_t* pst_rif_entry = NULL;
    ctc_sai_arp_fdb_t           *pst_arp_fdb = arp_fdb;
    sai_object_id_t             fdb_portid = 0;
    arp_fdb_update_argv_t       arp_fdb_argv;
    int                         ret = 0;

    if (NULL == pst_arp_fdb)
    {
        return SAI_STATUS_SUCCESS;
    }

    ret = ctc_fdb_get_portid(pst_arp_fdb->mac_address, pst_arp_fdb->vlanid, &fdb_portid);
    if (SAI_STATUS_SUCCESS == ret)
    {
        return SAI_STATUS_SUCCESS;
    }

    pst_rif_entry = ctc_routerintf_get_by_vlan(pst_arp_fdb->vlanid);
    if(NULL == pst_rif_entry)
    {
        return SAI_STATUS_SUCCESS;
    }

    arp_fdb_argv.pst_arp_fdb = pst_arp_fdb;
    arp_fdb_argv.action = action;
    ctc_hash_traverse(g_sai_neighbor_info.phash, ctc_arp_fdb_update_neighbor, &arp_fdb_argv);
    return SAI_STATUS_SUCCESS;
}

typedef struct
{
    ctc_sai_fdb_entry_t *pst_fdb;
    uint32 action;
} fdb_update_argv_t;

static int32_t
ctc_fdb_update_neighbor(
	_In_  void	*array_data,
	_In_  void	*user_data)
{
    ctc_sai_neighbor_entry_t    *pst_neighbor = array_data;
    fdb_update_argv_t           *fdb_argv = user_data;
    ctc_sai_fdb_entry_t         *pst_fdb = NULL;
    ctc_sai_routerintf_entry_t  *prouterintf_entry = NULL;
    sai_object_id_t              port_id = 0;
    uint32 action = 0;
    int ret       = 0;

    if ((NULL == pst_neighbor) || (NULL == fdb_argv))
    {
        return 0;
    }

    pst_fdb = fdb_argv->pst_fdb;
    action  = fdb_argv->action;

    prouterintf_entry = ctc_routerintf_get_by_oid(pst_neighbor->rif);
    if ((NULL == prouterintf_entry)
        || (SAI_ROUTER_INTERFACE_TYPE_VLAN != prouterintf_entry->type)
        || (prouterintf_entry->vlan_id != pst_fdb->fdb_key.vlan_id)
        || (0 != sal_memcmp(pst_neighbor->mac, pst_fdb->fdb_key.mac_address, sizeof(sai_mac_t))))
    {
        return 0;
    }

    switch(action)
    {
    case SAI_FDB_EVENT_LEARNED:
        port_id = pst_fdb->port;
        break;

    case SAI_FDB_EVENT_AGED:
    case SAI_FDB_EVENT_FLUSHED:
        ret = ctc_fdb_get_portid(pst_fdb->fdb_key.mac_address, pst_fdb->fdb_key.vlan_id, &port_id);
        if (SAI_STATUS_SUCCESS != ret)
        {
            port_id = CTC_LPORT_CPU;
        }

        port_id = CTC_LPORT_CPU;
        if (NULL != g_hsrv_neighbor_fdb_cb)
        {
            (*g_hsrv_neighbor_fdb_cb)(&pst_neighbor->key);
        }

        break;
    }

    if (pst_neighbor->port != port_id)
    {
        neighbor_update_nexthop(pst_neighbor, port_id, SAI_NEIGHBOR_UPDATE_PORT);
    }
    return 0;
}

int32_t
ctc_fdb_notifier_callback(
    _In_  struct ctc_sai_notifier_block *nb,
    _In_  uint32_t action,
    _In_  void *data)
{
    ctc_sai_fdb_entry_t*        pst_fdb = data;
    ctc_sai_routerintf_entry_t* prouterintf_entry = NULL;
    ctc_sai_neighbor_entry_t    pkey;
    fdb_update_argv_t           fdb_argv;

    sal_memset(&pkey,0,sizeof(ctc_sai_neighbor_entry_t));
    sal_memcpy(pkey.mac, pst_fdb->fdb_key.mac_address,sizeof(sai_mac_t));
    prouterintf_entry = ctc_routerintf_get_by_vlan(pst_fdb->fdb_key.vlan_id);
    if(NULL == prouterintf_entry)
    {
        return CTC_SAI_NOTIFY_OK;
    }

    fdb_argv.pst_fdb = pst_fdb;
    fdb_argv.action = action;
    ctc_hash_traverse(g_sai_neighbor_info.phash, ctc_fdb_update_neighbor, &fdb_argv);
    return CTC_SAI_NOTIFY_OK;
}

static struct ctc_sai_notifier_block nb_fdb_notifier_cb = {
    .notifier_call = ctc_fdb_notifier_callback,
};

sai_status_t
ctc_neighbor_init()
{
    sai_status_t ret        = SAI_STATUS_SUCCESS;

    g_sai_neighbor_info.max_count = CTC_SAI_NEIGHBOR_MAX;
    g_sai_neighbor_info.phash   =
        ctc_hash_create(CTC_VEC_BLOCK_NUM(g_sai_neighbor_info.max_count,NEIGHBOR_HASH_BLOCK_SIZE),
            NEIGHBOR_HASH_BLOCK_SIZE,
            (hash_key_fn)__neighbor_hash_make,
            (hash_cmp_fn)__neighbor_hash_cmp);

    if(NULL == g_sai_neighbor_info.phash)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }

    ctc_sai_fdbevnet_notifier_register(&nb_fdb_notifier_cb);
    return CTC_SAI_NOTIFY_DONE;

out:
    if(g_sai_neighbor_info.phash)
    {
        ctc_hash_free(g_sai_neighbor_info.phash);
    }
    return ret;
}

#define ________SAI_SAI_DEBUG_FUNC
sai_status_t
ctc_sai_set_neighbor_attribute_debug_param(
    _In_ const sai_neighbor_entry_t* neighbor_entry,
    _In_ const sai_attribute_t *attr)
{
    switch(attr->id)
    {
    case SAI_NEIGHBOR_ATTR_DST_MAC_ADDRESS:
        CTC_SAI_DEBUG("in:SAI_NEIGHBOR_ATTR_DST_MAC_ADDRESS %x:%x:%x:%x:%x:%x",
            attr->value.mac[5], attr->value.mac[4], attr->value.mac[3],
            attr->value.mac[2], attr->value.mac[1], attr->value.mac[0]);
        break;

    case SAI_NEIGHBOR_ATTR_PACKET_ACTION:
        CTC_SAI_DEBUG("in:SAI_NEIGHBOR_ATTR_PACKET_ACTION %d", attr->value.s32);
        break;
    }

    return SAI_STATUS_SUCCESS;
}
sai_status_t
ctc_sai_get_neighbor_attribute_debug_param(
    _In_ const sai_neighbor_entry_t* neighbor_entry,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{
    sai_status_t     ret         = SAI_STATUS_SUCCESS;
    uint32_t         attr_idx    = 0;
    sai_attribute_t* attr        = NULL;

    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        ret = ctc_sai_attr_check_read_attr(g_sai_attr_entries,attr);

        if(ret != SAI_STATUS_SUCCESS)
        {
            return ret + attr_idx;
        }

        switch (attr->id)
        {
            case SAI_NEXT_HOP_ATTR_TYPE:
                CTC_SAI_DEBUG("out:SAI_NEXT_HOP_ATTR_TYPE %d", attr->value.s32);
                break;
            case SAI_NEXT_HOP_ATTR_IP:
                CTC_SAI_DEBUG("out:SAI_NEXT_HOP_ATTR_IP");
                break;
            case SAI_NEXT_HOP_ATTR_ROUTER_INTERFACE_ID:
                CTC_SAI_DEBUG("out:SAI_NEXT_HOP_ATTR_ROUTER_INTERFACE_ID 0x%llx", attr->value.oid);
                break;
            default:
                continue;
        }
    }

    return SAI_STATUS_SUCCESS;
}
#define ________SAI_SAI_API_FUNC
/*
* Routine Description:
*    Create neighbor entry
*
* Arguments:
*    [in] neighbor_entry - neighbor entry
*    [in] attr_count - number of attributes
*    [in] attrs - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*
* Note: IP address expected in Network Byte Order.
*/
sai_status_t
ctc_sai_create_neighbor_entry(
    _In_ const sai_neighbor_entry_t* neighbor_entry,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    ctc_sai_attr_entry_list_t   *pattr_entry_list   = NULL;
    ctc_sai_neighbor_entry_t    *pst_neighbor       = NULL;
    ctc_sai_routerintf_entry_t  *pst_routerintf     = NULL;
    ctc_sai_nexthop_entry_t     *pst_nexthop        = NULL;
    ctc_sai_nexthop_entry_t     nexthop_key;
    sai_status_t ret = SAI_STATUS_SUCCESS;

    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_PTR_VALID_CHECK(neighbor_entry);
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    CTC_SAI_ERROR_GOTO(ctc_sai_attr_alloc_attr_entry_list(g_sai_attr_entries,
                            attr_list,
                            attr_count,
                            &pattr_entry_list),ret,out);

    CTC_SAI_ERROR_GOTO(ctc_sai_attr_check_attr_entry_list(g_sai_attr_entries,
                            pattr_entry_list),ret,out);

    /* 1. check neighor exist */
    pst_neighbor = ctc_neighbor_get_by_key(neighbor_entry);
    if (NULL != pst_neighbor)
    {
        ret = SAI_STATUS_ITEM_ALREADY_EXISTS;
        goto out;
    }

    /* 2. alloc neighor */
    ret = ctc_neighbor_alloc(&pst_neighbor);
    if(SAI_STATUS_SUCCESS != ret)
    {
        goto out;
    }

    /* 3. set neigbor parameter */
    sal_memcpy(&pst_neighbor->key, neighbor_entry, sizeof(sai_neighbor_entry_t));

    pst_routerintf = ctc_routerintf_get_by_oid(neighbor_entry->rif_id);
    if(NULL == pst_routerintf)
    {
        ret = SAI_STATUS_INVALID_OBJECT_ID;
        goto out1;
    }

    pst_neighbor->rif = neighbor_entry->rif_id;

    sal_memcpy(pst_neighbor->mac,
        pattr_entry_list[SAI_NEIGHBOR_ATTR_DST_MAC_ADDRESS].value.mac,
        sizeof(sai_mac_t));

    pst_neighbor->action = pattr_entry_list[SAI_NEIGHBOR_ATTR_PACKET_ACTION].value.s32;


    sal_memset(&nexthop_key, 0, sizeof(nexthop_key));
    nexthop_key.nh_key.rif_id = pst_neighbor->rif;
    sal_memcpy(&nexthop_key.nh_key.ip_address, &pst_neighbor->key.ip_address, sizeof(sai_ip_address_t));
    pst_nexthop = ctc_nexthop_get_by_key(&nexthop_key);
    if (NULL == pst_nexthop)
    {
        pst_neighbor->nhid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP,CTC_NH_RESERVED_NHID_FOR_DROP);
    }
    else
    {
        pst_neighbor->nhid = pst_nexthop->nh_id;
    }

    //ctc_hash_insert(g_sai_neighbor_info.phash, &pst_neighbor->key);
    ctc_hash_insert(g_sai_neighbor_info.phash, pst_neighbor);

    /* 4. add neigbor */
    if(NULL != pst_nexthop)
    {
        ctc_neighbor_update_entry(pst_neighbor);
        if(SAI_STATUS_SUCCESS != ret)
        {
            ret = SAI_STATUS_FAILURE;
            goto out1;
        }
    }

out:
    if(pattr_entry_list)
    {
        ctc_sai_attr_free_attr_entry_list(pattr_entry_list);
    }

    return ret;

out1:
    if(pst_neighbor)
    {
        ctc_neighbor_release(pst_neighbor);
    }
    goto out;
}

/*
* Routine Description:
*    Remove neighbor entry
*
* Arguments:
*    [in] neighbor_entry - neighbor entry
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*
* Note: IP address expected in Network Byte Order.
*/
sai_status_t
ctc_sai_remove_neighbor_entry(
    _In_ const sai_neighbor_entry_t* neighbor_entry)
{
    ctc_sai_neighbor_entry_t *pst_neighbor_entry = NULL;

    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_PTR_VALID_CHECK(neighbor_entry);

    pst_neighbor_entry = ctc_neighbor_get_by_key(neighbor_entry);
    if (NULL == pst_neighbor_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    ctc_neighbor_remove_entry(pst_neighbor_entry);
    ctc_neighbor_release(pst_neighbor_entry);
    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*    Set neighbor attribute value
*
* Arguments:
*    [in] neighbor_entry - neighbor entry
*    [in] attr - attribute
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_set_neighbor_attribute(
    _In_ const sai_neighbor_entry_t* neighbor_entry,
    _In_ const sai_attribute_t *attr)
{
    sai_status_t                ret         = SAI_STATUS_SUCCESS;
    ctc_sai_neighbor_entry_t    *pnb_entry  = NULL;

    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_PTR_VALID_CHECK(neighbor_entry);
    CTC_SAI_PTR_VALID_CHECK(attr);

    ret = ctc_sai_attr_check_write_attr(g_sai_attr_entries,attr);

    if(ret != SAI_STATUS_SUCCESS)
    {
        return ret;
    }

    pnb_entry = ctc_neighbor_get_by_key(neighbor_entry);
    if(pnb_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    ctc_sai_set_neighbor_attribute_debug_param(neighbor_entry, attr);
    switch(attr->id)
    {
    case SAI_NEIGHBOR_ATTR_DST_MAC_ADDRESS:
        ret = ctc_neighbor_set_mac(pnb_entry,attr);
        break;

    case SAI_NEIGHBOR_ATTR_PACKET_ACTION:
        ret = ctc_neighbor_set_action(pnb_entry,attr);
        break;
    }

    return ret;
}


/*
* Routine Description:
*    Get neighbor attribute value
*
* Arguments:
*    [in] neighbor_entry - neighbor entry
*    [in] attr_count - number of attributes
*    [inout] attrs - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_get_neighbor_attribute(
    _In_ const sai_neighbor_entry_t* neighbor_entry,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{
    sai_status_t                ret         = SAI_STATUS_SUCCESS;
    sai_attribute_t*            attr        = NULL;
    uint32_t                    attr_idx    = 0;
    ctc_sai_neighbor_entry_t    *pnb_entry  = NULL;

    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_PTR_VALID_CHECK(neighbor_entry);
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    ret = ctc_sai_attr_check_write_attr(g_sai_attr_entries,attr_list);

    if(ret != SAI_STATUS_SUCCESS)
    {
        return ret;
    }

    pnb_entry = ctc_neighbor_get_by_key(neighbor_entry);
    if (NULL == pnb_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        ret = ctc_sai_attr_check_read_attr(g_sai_attr_entries,attr);

        if(ret != SAI_STATUS_SUCCESS)
        {
            return ret + attr_idx;
        }

        switch(attr_list->id)
        {
        case SAI_NEIGHBOR_ATTR_DST_MAC_ADDRESS:
            sal_memcpy(attr_list->value.mac, pnb_entry->mac, sizeof(sai_mac_t));
            break;
        case SAI_NEIGHBOR_ATTR_PACKET_ACTION:
            attr_list->value.s32 = pnb_entry->action;
            break;
        }

        if(ret != SAI_STATUS_SUCCESS)
        {
            break;
        }
    }
    ctc_sai_get_neighbor_attribute_debug_param(neighbor_entry, attr_count, attr_list);
    return ret;
}

/*
* Routine Description:
*    Remove all neighbor entries
*
* Arguments:
*    None
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_remove_all_neighbor_entries(void)
{
    CTC_SAI_DEBUG_FUNC();

    ctc_neighbor_remove_all();
    return SAI_STATUS_SUCCESS;
}

#define ________SAI_INNER_FUNC
static sai_status_t
__ctc_sai_check_action_fn(
    _In_  ctc_sai_attr_entry_list_t *pattr,
    _In_  void                      *data)
{
    if (SAI_PACKET_ACTION_DROP == pattr->value.s32
        || SAI_PACKET_ACTION_FORWARD  == pattr->value.s32)
    {
        return SAI_STATUS_SUCCESS;
    }

    return SAI_STATUS_ATTR_NOT_SUPPORTED_0 + pattr->attr_index;
}

static sai_status_t
__init_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    CTC_SAI_ERROR_GOTO(ctc_neighbor_init(),ret,out);

    preg->init_status =  INITIALIZED;

out:
    return ret;
}

static sai_status_t
__exit_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}

/* define sai 0.9.2 */
static sai_neighbor_api_t      g_sai_api_func = {
    .create_neighbor_entry      = ctc_sai_create_neighbor_entry,
    .remove_neighbor_entry      = ctc_sai_remove_neighbor_entry,
    .set_neighbor_attribute     = ctc_sai_set_neighbor_attribute,
    .get_neighbor_attribute     = ctc_sai_get_neighbor_attribute,
    .remove_all_neighbor_entries= ctc_sai_remove_all_neighbor_entries,
};

static ctc_sai_api_reg_info_t g_api_reg_info = {
        .id         = SAI_API_NEIGHBOR,
        .init_func  = __init_mode_fn,
        .exit_func  = __exit_mode_fn,
        .api_method_table = &g_sai_api_func,
        .private_data     = NULL,
};

#define ________SAI_OUTER_FUNC
sai_status_t
ctc_sai_neighbor_init()
{
    api_reg_register_fn(&g_api_reg_info);

    return SAI_STATUS_SUCCESS;
}


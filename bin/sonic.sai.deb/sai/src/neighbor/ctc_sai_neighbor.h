#if !defined (__SAI_NEIGHBOR_H_)
#define __SAI_NEIGHBOR_H_

#include <saineighbor.h>
#include <saiswitch.h>

#define CTC_SAI_NEIGHBOR_MAX  16384

typedef int32 (*SAI_NEI_CB)(sai_neighbor_entry_t* p_neighbor_entry);

typedef enum
{
    SAI_NEIGHBOR_CREATE,
    SAI_NEIGHBOR_REMOVE,
    SAI_NEIGHBOR_UPDATE_PORT,
    SAI_NEIGHBOR_UPDATE_ACTION,
}ctc_sai_neighbor_update_type_t;

struct ctc_sai_routerintf_entry_s;
typedef struct ctc_sai_neighbor_entry_s
{
    sai_neighbor_entry_t   key;
    sai_mac_t              mac;
    sai_packet_action_t    action;
    sai_object_id_t        rif;
    sai_object_id_t        port;
    sai_object_id_t        nhid;
}ctc_sai_neighbor_entry_t;

typedef struct ctc_sai_neighbor_info_s
{
    ctc_hash_t*     phash;              /* -> ctc_sai_neighbor_entry_t */
    uint32_t       	max_count;
}ctc_sai_neighbor_info_t;

ctc_sai_neighbor_entry_t*
ctc_neighbor_get_by_key(
    _In_  const sai_neighbor_entry_t* );

int32 ctc_arp_fdb_get_portid(uint8 *mac_address, uint32 vlanid, sai_object_id_t *portid);

int32 ctc_arp_fdb_get_gport(uint8 *mac_address, uint32 vlanid, uint32 *gport);

int32_t ctc_arp_fdb_update_nexthop(void *arp_fdb, uint32 action);

extern sai_status_t
neighbor_update_nexthop(
    _In_  ctc_sai_neighbor_entry_t  *pnb_entry,
    _In_  sai_object_id_t           port_id,
    _In_  uint32_t                  update_type);

sai_status_t
ctc_sai_neighbor_init(void);

sai_status_t
ctc_neighbor_update_entry(
    _In_  ctc_sai_neighbor_entry_t *neighbor_entry);


#endif


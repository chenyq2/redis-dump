#include <sal.h>
#include "ctc_api.h"
#include "sal_error.h"
#include <sai.h>
#include <saitypes.h>
#include <saistatus.h>
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_sai.h>
#include <ctc_sai_vlan.h>
#include <ctc_sai_stp.h>
#include <ctc_sai_lag.h>
#include <ctc_sai_port.h>
#include <ctc_sai_debug.h>

#define CTC_SAI_VLAN_BLOCK_SIZE 32
#define CTC_SAI_VLAN_PORT_LIST_MAX 4096

typedef struct ctc_sai_vlan_info_s
{
    ctc_vector_t*       pvector;            /* ->ctc_sai_stp_entry_t* */
    sai_object_id_t     default_stp_id;
    ctc_hash_t*         p_hash;
    ctc_vector_t*       p_vlan_list_vector;
    
}ctc_sai_vlan_info_t;

/*

typedef struct ctc_sai_vlan_list_s
{
    ctc_hash_t *vlan_id;

}ctc_sai_vlan_list_t;

*/

typedef struct ctc_sai_vlan_attr_s
{
    ctc_vector_t*       pvector;            /* ->ctc_sai_stp_entry_t* */
    bool                default_learn_disable;
}ctc_sai_vlan_attr_t;

sai_status_t
ctc_sai_vlan_set_stp_instance(
    _In_ sai_vlan_id_t,
    _In_ const sai_attribute_t*);

static ctc_sai_vlan_info_t  g_sai_vlan_info;

static ctc_sai_vlan_attr_t  g_sai_vlan_attr;

static sai_vlan_id_t        g_vlan_id[CTC_SAI_VLAN_PORT_LIST_MAX];
    
static ctc_sai_check_u32_range_t g_range_0_vlan_address_limit =
{
    .min = 0,
    .max = 255,
};

static ctc_sai_check_object_type_range_t g_range_objtype_stp =
{
    .min = SAI_OBJECT_TYPE_STP_INSTANCE,
    .max = SAI_OBJECT_TYPE_STP_INSTANCE,
};

static ctc_sai_attr_entry_info_t g_sai_vlan_attr_entries[] = {
    {
        .id     = SAI_VLAN_ATTR_PORT_LIST,
        .type   = SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_VLAN_ATTR_MAX_LEARNED_ADDRESSES,
        .type   = SAI_ATTR_FALG_WRITE | SAI_ATTR_FALG_READ,
        .check_fn = {
            .func_fn = ctc_sai_check_u32_range_fn,
            .func_parameter = &g_range_0_vlan_address_limit,
        }
    },
    {
        .id     = SAI_VLAN_ATTR_STP_INSTANCE,
        .type   = SAI_ATTR_FALG_WRITE | SAI_ATTR_FALG_READ,
        .check_fn = {
            .func_fn = ctc_sai_check_object_type_range_fn,
            .func_parameter = &g_range_objtype_stp,
        }
    },
    {
        .id     = SAI_VLAN_ATTR_LEARN_DISABLE,
        .type   = SAI_ATTR_FALG_READ | SAI_ATTR_FALG_WRITE,
    },
    {
        .id     = SAI_VLAN_ATTR_META_DATA,
        .type   = SAI_ATTR_FALG_READ | SAI_ATTR_FALG_WRITE,
    },
    {
        .id     = SAI_VLAN_ATTR_IGMP_SNOOPING_EN,
        .type   = SAI_ATTR_FALG_READ | SAI_ATTR_FALG_WRITE,
    },
    {
        .id     = SAI_VLAN_ATTR_IGMP_SNOOPING_DISCARD_UNKNOWN,
        .type   = SAI_ATTR_FALG_READ | SAI_ATTR_FALG_WRITE,
    },
    {
        .id     = SAI_VLAN_ATTR_DHCPSNOOPING,
        .type   = SAI_ATTR_FALG_READ | SAI_ATTR_FALG_WRITE,
    },
    {
        .id     = SAI_VLAN_ATTR_INGRESS_MIRROR_SESSION,
        .type   = SAI_ATTR_FALG_READ | SAI_ATTR_FALG_WRITE,
    },
    {
        .id     = SAI_VLAN_ATTR_EGRESS_MIRROR_SESSION,
        .type   = SAI_ATTR_FALG_READ | SAI_ATTR_FALG_WRITE,
    },
    {
        .id     = SAI_ATTR_ID_END,
        .type   = 0,
    },
};

#define ________SAI_SAI_INNER_API_FUNC
sai_status_t
ctc_sai_vlan_create_vlan(
    _In_  sai_vlan_id_t vlan_id)
{
#ifdef GOLDENGATE
    int32_t             sdk_ret = CTC_E_NONE;
    ctc_vlan_uservlan_t user_vlan;

    sal_memset(&user_vlan, 0, sizeof(ctc_vlan_uservlan_t));

    user_vlan.vlan_id   = vlan_id;
    user_vlan.fid       = vlan_id;
    user_vlan.user_vlanptr = vlan_id;
    /* SYSTEM MODIFIED by wangjj for fix bug 42563, 2017-01-17 */
    user_vlan.flag = CTC_L2_DFT_VLAN_FLAG_PROTOCOL_EXCP_TOCPU;

    sdk_ret = ctc_vlan_create_uservlan(&user_vlan);

    if(sdk_ret == CTC_E_NONE)
    {
        //sdk_ret = ctc_vlan_set_learning_en(vlan_id, TRUE);
        sdk_ret = ctc_vlan_set_bridge_en(vlan_id, TRUE);
    }

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
#else
    uint16 vid = vlan_id;
    uint16 fid = vlan_id;
    uint16 learning_en = 1;
    uint16 bridge_en = 1;
    uint32 groupId = vlan_id;
    ctc_l2dflt_addr_t l2dflt;
    int32_t             sdk_ret = CTC_E_NONE;  
    
    sdk_ret = ctc_vlan_create_vlan(vid);
    sdk_ret = ctc_vlan_set_fid(vid, fid);

    sal_memset(&l2dflt, 0, sizeof(ctc_l2dflt_addr_t));
    l2dflt.fid = fid;
    l2dflt.l2mc_grp_id = groupId;
    l2dflt.flag = CTC_L2_DFT_VLAN_FLAG_PROTOCOL_EXCP_TOCPU;
    ctc_l2_add_default_entry(&l2dflt);

    ctc_vlan_set_learning_en(vid, learning_en);
    ctc_vlan_set_bridge_en(vid, bridge_en);
    
    /*l2 vlan should not send arp packet to cpu*/
    ctc_vlan_set_arp_excp_type(vid, CTC_EXCP_NORMAL_FWD);
    ctc_vlan_set_dhcp_excp_type(vid, CTC_EXCP_NORMAL_FWD);

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
#endif
}

sai_status_t
ctc_sai_vlan_remove_vlan(
    _In_  sai_vlan_id_t vlan_id)
{
#ifdef GOLDENGATE
    int32_t                     sdk_ret         = CTC_E_NONE;
    ctc_sai_stp_entry_t         *pstp_entry  	= NULL;
#else
    int32_t                     sdk_ret         = CTC_E_NONE;
    ctc_sai_stp_entry_t         *pstp_entry  	= NULL;
    uint16 vid = vlan_id;
    ctc_l2dflt_addr_t l2dflt_addr;
#endif

#ifdef GOLDENGATE
    sdk_ret = ctc_vlan_destroy_vlan(vlan_id);
#else
    sdk_ret = ctc_vlan_destroy_vlan(vlan_id);
    ctc_vlan_set_transmit_en(vid, FALSE);
    ctc_vlan_set_receive_en(vid, FALSE);
    
    sal_memset(&l2dflt_addr, 0, sizeof(ctc_l2dflt_addr_t));
    l2dflt_addr.fid = vlan_id;
    ctc_l2_remove_default_entry(&l2dflt_addr);
#endif
    if(CTC_E_NONE == sdk_ret)
    {
        pstp_entry = ctc_vector_get(g_sai_vlan_info.pvector, vlan_id);
        if(pstp_entry)
        {
            ctc_sai_stp_remove_vlan(pstp_entry,vlan_id);
            ctc_vector_del(g_sai_vlan_info.pvector, vlan_id);
        }
    }

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_vlan_id_t*
ctc_sai_vlan_get_vlan_id_global()
{
    return g_vlan_id;
}

static uint32_t
_vlan_vlan_hash_make(
    _In_  void* data)
{
    ctc_sai_vlan_list_t* p_vlan_key = (ctc_sai_vlan_list_t*)data;
    uint32 vlanid = 0;
    vlanid = CTC_SAI_OBJECT_INDEX_GET(p_vlan_key->vlan_id);
    return ctc_hash_caculate(sizeof(uint32), &vlanid);
}

static bool
_vlan_vlan_hash_cmp(
    _In_ void *data,
    _In_ void *data1)
{
    ctc_sai_vlan_list_t* p_vlan_key = data;
    ctc_sai_vlan_list_t* p_vlan_key1 = data1;

    if ((p_vlan_key->vlan_id & 0xffffffff) == (p_vlan_key1->vlan_id & 0xffffffff))
    {
        return TRUE;
    }

    return FALSE;
}

ctc_sai_vlan_list_t*
ctc_sai_vlan_db_get_by_vlan_id(sai_vlan_id_t vlan_id)
{
    ctc_sai_vlan_list_t  *pvlan_list =  NULL;

    pvlan_list = ctc_vector_get(g_sai_vlan_info.p_vlan_list_vector, vlan_id);

    return pvlan_list;
}

sai_status_t
ctc_sai_vlan_db_add_vlan_list(sai_vlan_id_t vlan_id, ctc_sai_vlan_list_t *pvlan_list)
{
    ctc_sai_vlan_list_t  *pst_vlan_list = NULL;

    pst_vlan_list = ctc_vector_get(g_sai_vlan_info.p_vlan_list_vector, vlan_id);
    if (NULL != pst_vlan_list)
    {
        ctc_vector_del(g_sai_vlan_info.p_vlan_list_vector, vlan_id);
    }

    ctc_vector_add(g_sai_vlan_info.p_vlan_list_vector, vlan_id, pvlan_list);

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_vlan_db_remove_vlan_list(sai_vlan_id_t vlan_id, ctc_sai_vlan_list_t* p_vlan_list)
{
    ctc_vector_del(g_sai_vlan_info.p_vlan_list_vector, vlan_id);
    
    mem_free(p_vlan_list->vlan_port_list.list);
    mem_free(p_vlan_list);
    
    return SAI_STATUS_SUCCESS;
}


sai_status_t
ctc_sai_vlan_db_alloc(sai_vlan_id_t vlan_id)
{
    ctc_sai_vlan_list_t *pst_vlan_list      = NULL;
    sai_vlan_port_t     *p_vlan_port        = NULL;
    uint32 max_count = CTC_MAX_LPORT;
    
    pst_vlan_list = mem_malloc(MEM_VLAN_MODULE, sizeof(ctc_sai_vlan_list_t));

    p_vlan_port = mem_malloc(MEM_VLAN_MODULE, sizeof(sai_vlan_port_t) * max_count);
    
    if (NULL == pst_vlan_list || NULL == p_vlan_port)
    {
        CTC_SAI_DEBUG("Memory alloc not successed!");
        return SAI_STATUS_FAILURE;
    }

    sal_memset(pst_vlan_list, 0, sizeof(ctc_sai_vlan_list_t));
    sal_memset(p_vlan_port, 0, sizeof(p_vlan_port)* max_count);
    
    pst_vlan_list->vlan_id = vlan_id;
    pst_vlan_list->vlan_port_list.list = p_vlan_port;

    ctc_sai_vlan_db_add_vlan_list(vlan_id, pst_vlan_list);

    return SAI_STATUS_SUCCESS;
}

void
ctc_sai_vlan_db_release(ctc_sai_vlan_list_t *p_vlan_list)
{
    if(NULL == p_vlan_list)
    {
        return;
    }

    if (0 != p_vlan_list->vlan_id)
    {
        ctc_hash_remove(g_sai_vlan_info.p_hash, p_vlan_list);
    }

    mem_free(p_vlan_list);
}


sai_status_t
ctc_sai_vlan_port_list_check_and_process_add(
    _In_  const sai_vlan_id_t   vlan_id,
    _In_  const uint32_t        port_count,    
    _In_  const sai_vlan_port_t *port_list)
{
    ctc_sai_vlan_list_t* pst_vlan_list_info = NULL;
    uint32 portid2  = 0;    
    uint32 i        = 0;
    uint32 ck_cnt   = 0;  

    ctc_sai_vlan_list_t vlan_list_info;

    sal_memset(&vlan_list_info, 0, sizeof(vlan_list_info));
    pst_vlan_list_info = ctc_sai_vlan_db_get_by_vlan_id(vlan_id);
    if (NULL != pst_vlan_list_info)
    {
        for(i = 0; i < port_count; i++)
        {
            portid2 = CTC_SAI_PORT_GET_LPORT(port_list[i].port_id);
            if (port_list[i].port_id == pst_vlan_list_info->vlan_port_list.list[portid2].port_id)
            {
                ck_cnt++;
            }
            else
            {
                sal_memcpy(&pst_vlan_list_info->vlan_port_list.list[portid2], &port_list[i],
                            sizeof(sai_vlan_port_t));
            }
        }

        if (ck_cnt == port_count)
        {
            return SAI_STATUS_SUCCESS;
        }
        else
        {
            pst_vlan_list_info->vlan_port_list.count += (port_count - ck_cnt);
        }

        pst_vlan_list_info->vlan_id = vlan_id;
        ctc_sai_vlan_db_add_vlan_list(vlan_id, pst_vlan_list_info);        

    }
    else
    {
        portid2 = port_list[i].port_id;
        vlan_list_info.vlan_id = vlan_id;
        vlan_list_info.vlan_port_list.count = port_count;

        for(i = 0; i < port_count; i++)
        {

            sal_memcpy(&vlan_list_info.vlan_port_list.list[portid2], &port_list[i],
                        sizeof(sai_vlan_port_t));
        }
        ctc_sai_vlan_db_add_vlan_list(vlan_id, &vlan_list_info);       
    }
    
    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_vlan_port_list_check_and_process_del(
    _In_  const sai_vlan_id_t   vlan_id,
    _In_  const uint32_t        port_count,    
    _In_  const sai_vlan_port_t *port_list)
{
    ctc_sai_vlan_list_t* pst_vlan_list_info = NULL;
    uint32 portid2  = 0;
    uint32 i        = 0;
    uint32 ck_cnt   = 0;
    
    pst_vlan_list_info = ctc_sai_vlan_db_get_by_vlan_id(vlan_id);
    if (NULL == pst_vlan_list_info)
    {
        return SAI_STATUS_FAILURE;
    }
    
    for(i = 0; i < port_count; i++)
    {
        portid2 = CTC_SAI_PORT_GET_LPORT(port_list[i].port_id);
        if (port_list[i].port_id == pst_vlan_list_info->vlan_port_list.list[portid2].port_id)
        {
            sal_memset(&pst_vlan_list_info->vlan_port_list.list[portid2], 0, sizeof(sai_vlan_port_t));
            ck_cnt++;
        }
        
    }

    pst_vlan_list_info->vlan_port_list.count -= ck_cnt;

    ctc_sai_vlan_db_add_vlan_list(vlan_id, pst_vlan_list_info);

    return SAI_STATUS_SUCCESS;
}


sai_status_t
ctc_sai_vlan_update_vlan_list(sai_vlan_id_t vlan_id, uint32 is_add)
{
    sai_vlan_id_t       *p_vlan_id = NULL;
    
    p_vlan_id = ctc_sai_vlan_get_vlan_id_global();
    
    if (1 == is_add)
    {
        p_vlan_id[vlan_id] = 1;
    }
    else if (0 == is_add)
    {
        p_vlan_id[vlan_id] = 0;
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_vlan_get_vlan_port_list(
    _In_ sai_vlan_id_t      vlan_id,
    _Out_ sai_attribute_t   *pattr)
{
    ctc_sai_vlan_list_t     *pst_vlan_port_list = NULL;
    sai_object_id_t         *p_vlan_port        = NULL;
    uint8_t                 *p_mode_list        = NULL;
    uint32 i        = 0;
    uint32 count2   = 0;
    uint32 count    = 0;
    uint32 max_count = CTC_MAX_LPORT;
    
    p_vlan_port = mem_malloc(MEM_VLAN_MODULE, sizeof(sai_object_id_t) * max_count);
    p_mode_list = mem_malloc(MEM_VLAN_MODULE, sizeof(uint8_t) * max_count);

    pst_vlan_port_list = ctc_sai_vlan_db_get_by_vlan_id(vlan_id);

    if (NULL == p_vlan_port || p_mode_list == NULL)
    {
        return SAI_STATUS_FAILURE;
    }

    sal_memset(p_vlan_port, 0, sizeof(sai_object_id_t) * max_count);
    sal_memset(p_mode_list, 0, sizeof(uint8_t) * max_count);
    
    pattr[0].value.objlist.list = p_vlan_port;
    pattr[1].value.u8list.list = p_mode_list;
    
    if (NULL == pst_vlan_port_list)
    {
        return SAI_STATUS_FAILURE;
    }
    
    if (SAI_VLAN_ATTR_PORT_LIST != pattr[0].id)
    {
        return SAI_STATUS_FAILURE;
    }
    
    for (i = 0; i < max_count; i++)
    {
        if (pst_vlan_port_list->vlan_port_list.list[i].port_id)
        {
            count = pattr[0].value.objlist.count;
            pattr[0].value.objlist.list[count] = pst_vlan_port_list->vlan_port_list.list[i].port_id;
            pattr[0].value.objlist.count ++;

            count2 = pattr[1].value.u8list.count;
            pattr[1].value.u8list.list[count2] = pst_vlan_port_list->vlan_port_list.list[i].tagging_mode;
            pattr[1].value.u8list.count ++;
        }
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_vlan_set_max_learned_address(
    _In_  const sai_vlan_id_t   vlan_id,
    _In_  const sai_attribute_t *pattr)
{
    int32_t                     sdk_ret = CTC_E_NONE;
    ctc_security_learn_limit_t  learn_limit;

    sal_memset(&learn_limit,0,sizeof(learn_limit));

    learn_limit.limit_type = CTC_SECURITY_LEARN_LIMIT_TYPE_VLAN;
    learn_limit.vlan       = vlan_id;
    learn_limit.limit_num  = pattr->value.u32;
    learn_limit.limit_action = CTC_MACLIMIT_ACTION_DISCARD;

    sdk_ret = ctc_mac_security_set_learn_limit(&learn_limit);

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_sai_vlan_get_max_learned_address(
    _In_  const sai_vlan_id_t   vlan_id,
    _Inout_  sai_attribute_t    *pattr)
{
    int32_t                     sdk_ret = CTC_E_NONE;
    ctc_security_learn_limit_t  learn_limit;

    sal_memset(&learn_limit,0,sizeof(learn_limit));

    learn_limit.limit_type = CTC_SECURITY_LEARN_LIMIT_TYPE_VLAN;
    learn_limit.vlan       = vlan_id;

    sdk_ret = ctc_mac_security_get_learn_limit(&learn_limit);

    if(sdk_ret != CTC_E_NONE)
    {
        goto out;
    }

    pattr->value.u32 = learn_limit.limit_num;

out:
    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
__ctc_sai_vlan_add_ports_to_vlan(
    _In_  const sai_vlan_id_t   vlan_id,
    _In_  const uint32_t        port_count,
    _In_  const sai_vlan_port_t *port_list)
{
    uint32_t    port_id     = 0;
    int32_t     sdk_ret     = CTC_E_NONE;
    int32_t     taged       = 0;

    for(port_id = 0; port_id < port_count; port_id++)
    {
        CTC_SAI_ERROR_GOTO(ctc_vlan_add_port(vlan_id,
                        CTC_SAI_OBJECT_INDEX_GET(port_list[port_id].port_id)),
                        sdk_ret,out);

        switch(port_list[port_id].tagging_mode)
        {
        case SAI_VLAN_PORT_UNTAGGED:
            taged = 0;
            break;
        case SAI_VLAN_PORT_TAGGED:
            taged = 1;
            break;
        case SAI_VLAN_PORT_PRIORITY_TAGGED:

            break;
        }

        CTC_SAI_ERROR_GOTO(ctc_vlan_set_tagged_port(vlan_id,
                        CTC_SAI_OBJECT_INDEX_GET(port_list[port_id].port_id),
                        taged),
                        sdk_ret,out);
    }

out:
    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
__convert_lag_port_to_ports(
    _In_  const sai_vlan_port_t *plag_port,
    _In_        sai_vlan_port_t *pport_arry,
    _In_  const uint32_t        port_max,
    _Out_       uint32_t        *lag_mumber_count)
{
    sai_status_t    ret           = SAI_STATUS_SUCCESS;
    uint32_t        port_count    = 0;
    sai_object_id_t *parr_port_id = NULL;
    sai_attribute_t lag_ports;

    parr_port_id = mem_malloc(MEM_APP_VLAN_MODULE,sizeof(sai_object_id_t) * port_max);

    if(NULL == parr_port_id)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }

    sal_memset(parr_port_id, 0, sizeof(sizeof(sai_object_id_t) * port_max));

    lag_ports.value.objlist.list = parr_port_id;
    lag_ports.value.objlist.count= port_max;
    CTC_SAI_ERROR_GOTO(ctc_sai_lag_get_ports(plag_port->port_id,&lag_ports),ret,out);

    for(port_count = 0; port_count < lag_ports.value.objlist.count; port_count++)
    {
        pport_arry[port_count].port_id = lag_ports.value.objlist.list[port_count];
        pport_arry[port_count].tagging_mode = plag_port->tagging_mode;
    }

    *lag_mumber_count = lag_ports.value.objlist.count;

out:
    if(parr_port_id)
    {
        mem_free(parr_port_id);
        parr_port_id = NULL;
    }
    return ret;
}

sai_status_t
ctc_sai_vlan_add_ports_to_vlan(
    _In_  const sai_vlan_id_t   vlan_id,
    _In_  const uint32_t    port_count,
    _In_  const sai_vlan_port_t *port_list)
{

    sai_status_t    ret           = SAI_STATUS_SUCCESS;
    uint32_t        port_id = 0;
    uint32_t        port_current_idx = 0;
    uint32_t        lag_port_member_count = 0;
    sai_vlan_port_t vlan_port_arry[CTC_MAX_LPORT];
    sai_vlan_port_t *pvlan_port_arry = NULL;

    ctc_sai_port_entry_t *psaiport_entry = NULL;
#ifndef GOLDENGATE
    ctc_l2dflt_addr_t l2dflt_addr;
    uint32 gport = 0;
    uint32 i = 0;
#endif
    pvlan_port_arry = &vlan_port_arry[0];

    if(NULL == pvlan_port_arry)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }

    sal_memset(pvlan_port_arry, 0, sizeof(vlan_port_arry));

    for(port_id = 0; port_id < port_count; port_id++)
    {
            
        psaiport_entry = ctc_sai_port_get_port(port_list[port_id].port_id);
        if(NULL == psaiport_entry)
        {
            continue;
        }
        else
        {
            CTC_BMP_SET(psaiport_entry->vlanbmp, vlan_id);
        }

        if(SAI_OBJECT_TYPE_PORT == CTC_SAI_OBJECT_TYPE_GET(port_list[port_id].port_id))
        {
            pvlan_port_arry[port_current_idx].port_id = port_list[port_id].port_id;
            pvlan_port_arry[port_current_idx].tagging_mode = port_list[port_id].tagging_mode;
            port_current_idx++;
            continue;
        }

        if(SAI_OBJECT_TYPE_LAG == CTC_SAI_OBJECT_TYPE_GET(port_list[port_id].port_id))
        {
            CTC_SAI_ERROR_GOTO(
                __convert_lag_port_to_ports(&port_list[port_id],
                pvlan_port_arry + port_current_idx,
                CTC_MAX_LPORT - port_current_idx,
                &lag_port_member_count),
                ret,
                out);
            port_current_idx += lag_port_member_count;
            continue;

        }

        ret = SAI_STATUS_INVALID_PARAMETER;
        goto out;
    }

    ctc_sai_vlan_port_list_check_and_process_add(vlan_id, port_current_idx, pvlan_port_arry);

    ret = __ctc_sai_vlan_add_ports_to_vlan(vlan_id, port_current_idx, pvlan_port_arry);
#ifndef GOLDENGATE
    sal_memset(&l2dflt_addr, 0, sizeof(l2dflt_addr));
    l2dflt_addr.fid = vlan_id;
    l2dflt_addr.l2mc_grp_id = vlan_id;
    
    for(port_id = 0; port_id < port_count; port_id++)
    {
        if(SAI_OBJECT_TYPE_PORT == CTC_SAI_OBJECT_TYPE_GET(port_list[port_id].port_id))
        {
            
            ctc_sai_port_objectid_to_gport(port_list[port_id].port_id, &gport);
            if(ctc_sai_port_get_lag_id(gport))
            {
                /*if interface is AGG interface, it should load agg if to vlan default entry for GB*/
                continue;
            }
            l2dflt_addr.member.mem_port = gport;
            ctc_l2_add_port_to_default_entry(&l2dflt_addr);
        }
        else if(SAI_OBJECT_TYPE_LAG == CTC_SAI_OBJECT_TYPE_GET(port_list[port_id].port_id))
        {
            ctc_sai_port_objectid_to_gport(port_list[port_id].port_id, &gport);
            l2dflt_addr.member.mem_port = gport;
            ctc_l2_add_port_to_default_entry(&l2dflt_addr);

            /*this logic is used for gb, gb need delete all agg member ports from default vlan entry*/
            port_current_idx = 0;
            lag_port_member_count= 0;

                __convert_lag_port_to_ports(&port_list[port_id],
                pvlan_port_arry + port_current_idx,
                CTC_MAX_LPORT - port_current_idx,
                &lag_port_member_count);

            
            for(i=0; i<lag_port_member_count; i++)
            {
                ctc_sai_port_objectid_to_gport(pvlan_port_arry[i].port_id, &gport);
                l2dflt_addr.member.mem_port = gport;
                ctc_l2_remove_port_from_default_entry(&l2dflt_addr);
            }
                

        }
    }
    
#endif

out:
    if(pvlan_port_arry)
    {
        pvlan_port_arry = NULL;
    }
    return ret;
}

sai_status_t
ctc_sai_vlan_remove_ports_to_vlan(
    _In_  const sai_vlan_id_t   vlan_id,
    _In_  const uint32_t        port_count,
    _In_  const sai_vlan_port_t *port_list)
{
    uint32_t        port_id                 = 0;
    sai_status_t    ret                     = SAI_STATUS_SUCCESS;
    uint32_t        lag_port_member_count   = 0;
    uint32_t        port_current_idx        = 0;
    sai_vlan_port_t *pvlan_port_arry        = NULL;
    sai_vlan_port_t vlan_port_arry[CTC_MAX_LPORT];

    ctc_sai_port_entry_t *psaiport_entry = NULL;
#ifndef GOLDENGATE
    ctc_l2dflt_addr_t l2dflt_addr;
    uint32 gport = 0;
#endif

    sal_memset(vlan_port_arry, 0, sizeof(vlan_port_arry));
    pvlan_port_arry = vlan_port_arry;

    if(NULL == pvlan_port_arry)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }

    for(port_id = 0; port_id < port_count; port_id++)
    {

        psaiport_entry = ctc_sai_port_get_port(port_list[port_id].port_id);
        if(NULL == psaiport_entry)
        {
            continue;
        }
        else
        {
            CTC_BMP_UNSET(psaiport_entry->vlanbmp, vlan_id);
        }

        if(SAI_OBJECT_TYPE_LAG == CTC_SAI_OBJECT_TYPE_GET(port_list[port_id].port_id))
        {
            CTC_SAI_ERROR_GOTO(
                __convert_lag_port_to_ports(&port_list[port_id],
                pvlan_port_arry + port_current_idx,
                CTC_MAX_LPORT - port_current_idx,
                &lag_port_member_count),
                ret,
                out);

            for(port_current_idx = 0; port_current_idx < lag_port_member_count; port_current_idx++)
            {
                 ctc_vlan_remove_port(vlan_id,CTC_SAI_OBJECT_INDEX_GET(pvlan_port_arry[port_id].port_id));
            }
        }
        else
        {
             ctc_vlan_remove_port(vlan_id,CTC_SAI_OBJECT_INDEX_GET(port_list[port_id].port_id));
        }        
    }

    ctc_sai_vlan_port_list_check_and_process_del(vlan_id, port_current_idx, pvlan_port_arry);


#ifndef GOLDENGATE
    sal_memset(&l2dflt_addr, 0, sizeof(l2dflt_addr));
    l2dflt_addr.fid = vlan_id;
    l2dflt_addr.l2mc_grp_id = vlan_id;
    
    for(port_id = 0; port_id < port_count; port_id++)
    {

        if(SAI_OBJECT_TYPE_PORT == CTC_SAI_OBJECT_TYPE_GET(port_list[port_id].port_id))
        {
            
            ctc_sai_port_objectid_to_gport(port_list[port_id].port_id, &gport);
            if(ctc_sai_port_get_lag_id(gport))
            {
                /*if interface is AGG interface, it should load agg if to vlan default entry for GB*/
                continue;
            }
            l2dflt_addr.member.mem_port = gport;
            ctc_l2_remove_port_from_default_entry(&l2dflt_addr);
        }
        else if(SAI_OBJECT_TYPE_LAG == CTC_SAI_OBJECT_TYPE_GET(port_list[port_id].port_id))
        {
            ctc_sai_port_objectid_to_gport(port_list[port_id].port_id, &gport);
            l2dflt_addr.member.mem_port = gport;
            ctc_l2_remove_port_from_default_entry(&l2dflt_addr);
        }
    }
    
#endif
    

out:
    if(pvlan_port_arry)
    {
        pvlan_port_arry = NULL;
    }
    return ret;
}


sai_status_t
__ctc_sai_vlan_remove_ports_to_vlan(
    _In_  const sai_vlan_id_t   vlan_id,
    _In_  const uint32_t        port_count,
    _In_  const sai_vlan_port_t *port_list)
{
    uint32_t    port_id = 0;

    for(port_id = 0; port_id < port_count; port_id++)
    {
        if(SAI_OBJECT_TYPE_PORT == CTC_SAI_OBJECT_TYPE_GET(port_list[port_id].port_id))
        {
            continue;
        }

        if(SAI_OBJECT_TYPE_LAG == CTC_SAI_OBJECT_TYPE_GET(port_list[port_id].port_id))
        {
            continue;
        }

        return SAI_STATUS_INVALID_PARAMETER;
    }

    return __ctc_sai_vlan_remove_ports_to_vlan(vlan_id,port_count,port_list);
}

sai_status_t
ctc_sai_vlan_set_igmp_snooping_en(
    _In_ sai_vlan_id_t          vlan_id,
    _In_ const sai_attribute_t  *pattr)
{
    int32_t    sdk_ret = 0;
    uint32 enable = 0;

    enable = pattr->value.booldata;

    sdk_ret = ctc_vlan_set_igmp_snoop_en(vlan_id, enable);

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_sai_vlan_set_igmp_snooping_discard_unknown(
    _In_ sai_vlan_id_t          vlan_id,
    _In_ const sai_attribute_t  *pattr)
{
    int32_t    sdk_ret = 0;
    uint32 discard = 0;

    discard = pattr->value.booldata;

    sdk_ret = ctc_vlan_set_property(vlan_id, CTC_VLAN_PROP_DROP_UNKNOWN_MCAST_EN, discard);

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_sai_vlan_set_stp_instance(
    _In_ sai_vlan_id_t          vlan_id,
    _In_ const sai_attribute_t  *pattr)
{
    ctc_sai_stp_entry_t*    pstp_entry = NULL;

    pstp_entry = ctc_vector_get(g_sai_vlan_info.pvector, vlan_id);
    if(pstp_entry)
    {
        if(pstp_entry->stp_id == pattr->value.oid)
        {
            return SAI_STATUS_SUCCESS;
        }

        ctc_sai_stp_remove_vlan(pstp_entry,vlan_id);
    }

    pstp_entry = ctc_sai_stp_get_by_oid(pattr->value.oid);
    if(!pstp_entry)
    {
        return SAI_STATUS_INVALID_OBJECT_ID;
    }

    ctc_sai_stp_add_vlan(pstp_entry,vlan_id);
    ctc_vector_add(g_sai_vlan_info.pvector, vlan_id,pstp_entry);
    refcnt_inc(pstp_entry);

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_vlan_set_attr_dhcpnooping(
    _In_ sai_vlan_id_t          vlan_id,
    _In_ const sai_attribute_t  *pattr)
{
    uint32 type = 0;

    if (NULL != pattr && SAI_VLAN_ATTR_DHCPSNOOPING == pattr->id)
    {
        type = pattr->value.u32;
    }
    else
    {
        return SAI_STATUS_FAILURE;
    }
    
    ctc_vlan_set_dhcp_excp_type(vlan_id, type);
    
    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_vlan_get_stp_instance(
    _In_ sai_vlan_id_t      vlan_id,
    _Out_ sai_attribute_t   *pattr)
{
    ctc_sai_stp_entry_t*    pstp_entry = NULL;

    pstp_entry = ctc_vector_get(g_sai_vlan_info.pvector, vlan_id);
    if(!pstp_entry)
    {
        return SAI_STATUS_FAILURE;
    }
    else
    {
        pattr->value.oid = pstp_entry->stp_id;
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_vlan_set_learn_disable(
    _In_ sai_vlan_id_t          vlan_id,
    _In_ bool                   learn_disable)
{
    ctc_sai_vlan_attr_entry_t*    p_attr_entry = NULL;
    ctc_sai_vlan_attr_entry_t     attr_entry;
    ctc_sai_vlan_attr_entry_t*    pst_attr_entry = NULL;
    uint32  rc = SAI_STATUS_SUCCESS;

    pst_attr_entry = mem_malloc(MEM_VLAN_MODULE, sizeof(ctc_sai_vlan_attr_entry_t));

    sal_memset(pst_attr_entry, 0, sizeof(*pst_attr_entry));
    sal_memset(&attr_entry, 0 , sizeof(attr_entry));
    p_attr_entry = ctc_vector_get(g_sai_vlan_attr.pvector, vlan_id);
    if (NULL != p_attr_entry)
    {
        ctc_vector_del(g_sai_vlan_attr.pvector, vlan_id);
    }
 
    pst_attr_entry->learn_disable = learn_disable;
    ctc_vector_add(g_sai_vlan_attr.pvector, vlan_id, pst_attr_entry);
       
    rc = ctc_vlan_set_learning_en(vlan_id, (!learn_disable));

    return rc;
}

sai_status_t
ctc_sai_vlan_set_attr_learn_disable(
    _In_ sai_vlan_id_t          vlan_id,
    _In_ const sai_attribute_t  *pattr)
{
    ctc_sai_vlan_attr_entry_t*    p_attr_entry = NULL;
    ctc_sai_vlan_attr_entry_t     attr_entry;
    uint32  rc = 0;
    bool    learn_disable;  

    ctc_sai_vlan_attr_entry_t*    pst_attr_entry = NULL;

    pst_attr_entry = mem_malloc(MEM_VLAN_MODULE, sizeof(ctc_sai_vlan_attr_entry_t));

    sal_memset(pst_attr_entry, 0, sizeof(*pst_attr_entry));
    sal_memset(&attr_entry, 0 , sizeof(attr_entry));
    learn_disable = pattr->value.booldata;
    
    p_attr_entry = ctc_vector_get(g_sai_vlan_attr.pvector, vlan_id);
    if (NULL != p_attr_entry)
    {
        ctc_vector_del(g_sai_vlan_attr.pvector, vlan_id);
    }
 
    pst_attr_entry->learn_disable = learn_disable;
    ctc_vector_add(g_sai_vlan_attr.pvector, vlan_id, pst_attr_entry);

    rc = ctc_vlan_set_learning_en(vlan_id, (!learn_disable));
    
    return rc;
}

sai_status_t
ctc_sai_vlan_set_learn_disable_vlan_remove(
    _In_ sai_vlan_id_t          vlan_id)
{
    ctc_sai_vlan_attr_entry_t*    p_attr_entry = NULL;

    p_attr_entry = ctc_vector_get(g_sai_vlan_attr.pvector, vlan_id);
    if (NULL != p_attr_entry)
    {
        ctc_vector_del(g_sai_vlan_attr.pvector, vlan_id);
        mem_free(p_attr_entry);
    }


    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_vlan_db_get_vlan_stats(
    _In_    sai_vlan_id_t                   vlan_id,
    _In_    const sai_vlan_stat_counter_t   *counter_ids,
    _In_    uint32_t                        number_of_counters,
    _Out_   uint64_t                        *counters)
{
    return SAI_STATUS_SUCCESS;
}

void
ctc_sai_vlan_set_default_learn_disable(bool learn_disable)
{
    g_sai_vlan_attr.default_learn_disable = learn_disable;
}

sai_status_t
ctc_sai_vlan_get_learn_disable(
    _In_    sai_vlan_id_t                   vlan_id,
    _Out_   sai_attribute_t                 *p_attr)
{

    ctc_sai_vlan_attr_entry_t*    p_vlan_attr_entry = NULL;

    p_vlan_attr_entry = ctc_vector_get(g_sai_vlan_attr.pvector, vlan_id);

    if (NULL == p_vlan_attr_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    if (SAI_VLAN_ATTR_LEARN_DISABLE == p_attr->id)
    {
        p_attr->value.booldata = p_vlan_attr_entry->learn_disable;
    }
    
    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_vlan_set_ingress_mirror_session(
    _In_ sai_vlan_id_t          vlan_id,
    _In_ const sai_attribute_t  *attr)
{
    uint32   session_id = 0;
    uint8    sdk_session_id = 0;
    int32_t  sdk_ret = 0;
    bool     enable;
    
    if (0 == attr->value.objlist.count)
    {
        ctc_mirror_get_vlan_info(vlan_id, CTC_INGRESS, &enable, &sdk_session_id);
        sdk_ret = ctc_mirror_set_vlan_en(vlan_id, CTC_INGRESS, FALSE, sdk_session_id);
        if (sdk_ret != CTC_E_NONE)
        {
            return ctc_sai_get_error_from_sdk_error(sdk_ret);
        }
    }
    else if (1 == attr->value.objlist.count)
    {
        session_id = CTC_SAI_OBJECT_INDEX_GET(attr->value.objlist.list[0]);
        sdk_session_id = session_id;
        sdk_ret = ctc_mirror_set_vlan_en(vlan_id, CTC_INGRESS, TRUE, sdk_session_id);
        if (sdk_ret != CTC_E_NONE)
        {
            return ctc_sai_get_error_from_sdk_error(sdk_ret);
        }
    }
    else
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }  
    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_sai_vlan_get_ingress_mirror_session(
    _In_    sai_vlan_id_t                   vlan_id,
    _Out_   sai_attribute_t                 *attr)
{
    uint8   sdk_session_id = 0 ;
    int32_t sdk_ret = 0;
    bool    enable = FALSE;
    
    if (0 == attr->value.objlist.count) 
    {   
        return SAI_STATUS_INVALID_PARAMETER;
    }
    else
    {   
        sdk_ret = ctc_mirror_get_vlan_info(vlan_id, CTC_INGRESS, &enable, &sdk_session_id);
        if (sdk_ret != CTC_E_NONE)
        {
            return ctc_sai_get_error_from_sdk_error(sdk_ret);
        }
        if (enable)
        {
            attr->value.objlist.count = 1;
            attr->value.objlist.list[0] = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_MIRROR, sdk_session_id);
        }
        else
        {
            attr->value.objlist.count = 0;
            attr->value.objlist.list = NULL;
        }
    }
    return ctc_sai_get_error_from_sdk_error(sdk_ret);   
}

sai_status_t
ctc_sai_vlan_set_egress_mirror_session(
    _In_ sai_vlan_id_t          vlan_id,
    _In_ const sai_attribute_t  *attr)
{
    uint32   session_id = 0;
    uint8    sdk_session_id = 0;
    int32_t  sdk_ret = 0;
    bool     enable;
    
    if (0 == attr->value.objlist.count)
    {
        ctc_mirror_get_vlan_info(vlan_id, CTC_EGRESS, &enable, &sdk_session_id);
        sdk_ret = ctc_mirror_set_vlan_en(vlan_id, CTC_EGRESS, FALSE, sdk_session_id);
        if (sdk_ret != CTC_E_NONE)
        {
            return ctc_sai_get_error_from_sdk_error(sdk_ret);
        }
       
    }
    else if (1 == attr->value.objlist.count)
    {
        session_id = CTC_SAI_OBJECT_INDEX_GET(attr->value.objlist.list[0]);
        sdk_session_id = session_id;
        sdk_ret = ctc_mirror_set_vlan_en(vlan_id, CTC_EGRESS, TRUE, sdk_session_id);
        if (sdk_ret != CTC_E_NONE)
        {
            return ctc_sai_get_error_from_sdk_error(sdk_ret);
        }
    }
    else
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }
    return ctc_sai_get_error_from_sdk_error(sdk_ret);    
}

sai_status_t
ctc_sai_vlan_set_attr_arpnooping(
    _In_ sai_vlan_id_t          vlan_id,
    _In_ const sai_attribute_t  *attr)
{
    uint32 type = 0;
    int32_t sdk_ret = 0;

    if (NULL != attr && SAI_VLAN_ATTR_ARPSNOOPING == attr->id)
    {
        type = attr->value.u32;
    }
    else
    {
        return SAI_STATUS_FAILURE;
    }
    sdk_ret = ctc_vlan_set_property(vlan_id, CTC_VLAN_PROP_ARP_EXCP_TYPE, type);
    if (sdk_ret < 0)
    {
        return sdk_ret;
    }   
    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_vlan_get_egress_mirror_session(
    _In_    sai_vlan_id_t                   vlan_id,
    _Out_   sai_attribute_t                 *attr)
{
    uint8   sdk_session_id = 0 ;
    int32_t sdk_ret = 0;
    bool    enable = FALSE;
    
    if (0 == attr->value.objlist.count) 
    {   
        return SAI_STATUS_INVALID_PARAMETER;
    }
    else
    {   
        sdk_ret = ctc_mirror_get_vlan_info(vlan_id, CTC_EGRESS, &enable, &sdk_session_id);
        if (sdk_ret != CTC_E_NONE)
        {
            return ctc_sai_get_error_from_sdk_error(sdk_ret);
        }
        if (enable)
        {
            attr->value.objlist.count = 1;
            attr->value.objlist.list[0] = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_MIRROR, sdk_session_id);
        }
        else
        {
            attr->value.objlist.count = 0;
            attr->value.objlist.list = NULL;
        }
    }
    return ctc_sai_get_error_from_sdk_error(sdk_ret);   
}


#define ________SAI_SAI_DEBUG_FUNC
sai_status_t
ctc_sai_set_vlan_attribute_debug_param(
    _In_ sai_vlan_id_t vlan_id,
    _In_ const sai_attribute_t *attr)
{
    CTC_SAI_DEBUG("in:vlan_id %u", vlan_id);
    switch(attr->id)
    {
    case SAI_VLAN_ATTR_MAX_LEARNED_ADDRESSES:
        CTC_SAI_DEBUG("in:SAI_VLAN_ATTR_MAX_LEARNED_ADDRESSES %u", attr->value.u32);
        break;
    case SAI_VLAN_ATTR_STP_INSTANCE:
        CTC_SAI_DEBUG("in:SAI_VLAN_ATTR_STP_INSTANCE 0x%llx", attr->value.oid);
        break;
    case SAI_VLAN_ATTR_LEARN_DISABLE:
        CTC_SAI_DEBUG("in:SAI_VLAN_ATTR_LEARN_DISABLE %u", attr->value.booldata);
        break;  
    default: /*not support other field */
        CTC_SAI_DEBUG("in:NOT SUPPORT");
        break;
    }
    return SAI_STATUS_SUCCESS;
}
sai_status_t
ctc_sai_get_vlan_attribute_debug_param(
    _In_ sai_vlan_id_t vlan_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    const sai_attribute_t *attr = NULL;
    uint32_t          attr_idx = 0; 

    CTC_SAI_DEBUG("in:vlan_id lag_id %u", vlan_id);
    for (attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        ret = ctc_sai_attr_check_read_attr(g_sai_vlan_attr_entries,attr);

        if(ret != SAI_STATUS_SUCCESS)
        {
            return SAI_STATUS_SUCCESS;
        }

        switch(attr->id)
        {
        case SAI_VLAN_ATTR_PORT_LIST:
            CTC_SAI_DEBUG("in:SAI_VLAN_ATTR_PORT_LIST");
            break;
            
        case SAI_VLAN_ATTR_MAX_LEARNED_ADDRESSES:
            CTC_SAI_DEBUG("in:SAI_VLAN_ATTR_MAX_LEARNED_ADDRESSES %u", attr->value.u32);
            break;
        case SAI_VLAN_ATTR_STP_INSTANCE:
            CTC_SAI_DEBUG("in:SAI_VLAN_ATTR_STP_INSTANCE 0x%llx", attr->value.oid);
            break;

        case SAI_VLAN_ATTR_LEARN_DISABLE:
            CTC_SAI_DEBUG("in:SAI_VLAN_ATTR_LEARN_DISABLE %u", attr->value.booldata);
            break;

        case SAI_VLAN_ATTR_META_DATA:
            break;
        }

        if(ret != SAI_STATUS_SUCCESS)
        {
            break;
        }
    }

    return SAI_STATUS_SUCCESS;
}
#define ________SAI_SAI_API_FUNC
/*
* Routine Description:
*    Create a VLAN
*
* Arguments:
*    [in] vlan_id - VLAN id
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_create_vlan(
    _In_ sai_vlan_id_t vlan_id)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_attribute_t attr;
    uint32 is_add = 0;
     
    sal_memset(&attr,0,sizeof(sai_attribute_t));

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_DEBUG("in:vlan_id %u", vlan_id);
    CTC_SAI_ERROR_GOTO(ctc_sai_vlan_create_vlan(vlan_id),ret,out);

    /* set the act to add vlan list, and depend by is_add, value 1 is add */
    is_add = 1;
    ret = ctc_sai_vlan_update_vlan_list(vlan_id, is_add);

    ret = ctc_sai_vlan_db_alloc(vlan_id);

    /* set default vlan attribute */
    ctc_sai_vlan_set_learn_disable(vlan_id, FALSE);

    /* set default */
    attr.id        = SAI_VLAN_ATTR_STP_INSTANCE;
    attr.value.oid = g_sai_vlan_info.default_stp_id;
    CTC_SAI_ERROR_GOTO(ctc_sai_vlan_set_stp_instance(vlan_id,&attr),ret,out1);

    /* set IGMP Snooping enable */
    ctc_vlan_set_igmp_snoop_en(vlan_id, TRUE);

out:
    return ret;

out1:
    ctc_sai_vlan_remove_vlan(vlan_id);
    goto out;
}

/*
* Routine Description:
*    Remove a VLAN
*
* Arguments:
*    [in] vlan_id - VLAN id
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_remove_vlan(
    _In_ sai_vlan_id_t vlan_id)
{
    ctc_sai_vlan_list_t* p_vlan_list = NULL;
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    uint32 is_add = 1;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_DEBUG("in:vlan_id %u", vlan_id);
    CTC_SAI_ERROR_GOTO(ctc_sai_vlan_remove_vlan(vlan_id),ret,out);

    /* set IGMP Snooping disable */
    ctc_vlan_set_igmp_snoop_en(vlan_id, FALSE);

    /* update vlan attribute when remove vlan */
    ctc_sai_vlan_set_learn_disable_vlan_remove(vlan_id);

    /* set the act to add vlan list, and depend by is_add, value 0 is del */
    is_add = 0;
    ret = ctc_sai_vlan_update_vlan_list(vlan_id, is_add);

    p_vlan_list = ctc_sai_vlan_db_get_by_vlan_id(vlan_id);
    if (NULL == p_vlan_list)
    {
        return ret;
    }

    ctc_sai_vlan_db_remove_vlan_list(vlan_id, p_vlan_list);

out:
    return ret;
}

/*
* Routine Description:
*    Set VLAN attribute Value
*
* Arguments:
*    [in] vlan_id - VLAN id
*    [in] attr - attribute
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_set_vlan_attribute(
    _In_ sai_vlan_id_t vlan_id,
    _In_ const sai_attribute_t *attr)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_PTR_VALID_CHECK(attr);

    CTC_SAI_ERROR_GOTO(ctc_sai_attr_check_write_attr(
                            g_sai_vlan_attr_entries,attr),
                       ret,out);
    ctc_sai_set_vlan_attribute_debug_param(vlan_id, attr);
    switch(attr->id)
    {
        case SAI_VLAN_ATTR_MAX_LEARNED_ADDRESSES:
            ret = ctc_sai_vlan_set_max_learned_address(vlan_id, attr);
            break;
            
        case SAI_VLAN_ATTR_STP_INSTANCE:
            ret = ctc_sai_vlan_set_stp_instance(vlan_id, attr);
            break;
            
        case SAI_VLAN_ATTR_LEARN_DISABLE:
            ret = ctc_sai_vlan_set_attr_learn_disable(vlan_id, attr);
            break;

        case SAI_VLAN_ATTR_DHCPSNOOPING:
            ret = ctc_sai_vlan_set_attr_dhcpnooping(vlan_id, attr);
            break;
            
        case SAI_VLAN_ATTR_META_DATA:
            break;

        case SAI_VLAN_ATTR_IGMP_SNOOPING_EN:
            ret = ctc_sai_vlan_set_igmp_snooping_en(vlan_id, attr);
            break;

        case SAI_VLAN_ATTR_IGMP_SNOOPING_DISCARD_UNKNOWN:
            ret = ctc_sai_vlan_set_igmp_snooping_discard_unknown(vlan_id, attr);
            break;
            
        case SAI_VLAN_ATTR_INGRESS_MIRROR_SESSION:
            ret = ctc_sai_vlan_set_ingress_mirror_session(vlan_id, attr);
            break;
            
        case SAI_VLAN_ATTR_EGRESS_MIRROR_SESSION:
            ret = ctc_sai_vlan_set_egress_mirror_session(vlan_id, attr);
            break;

        case SAI_VLAN_ATTR_ARPSNOOPING:
            ret = ctc_sai_vlan_set_attr_arpnooping(vlan_id, attr);
            break;
    }

out:
    return ret;
}

/*
* Routine Description:
*    Get VLAN attribute Value
*
* Arguments:
*    [in] vlan_id - VLAN id
*    [in] attr_count - number of attributes
*    [inout] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_get_vlan_attribute(
    _In_ sai_vlan_id_t vlan_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_attribute_t* attr        = NULL;
    uint32_t        attr_idx    = 0;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        ret = ctc_sai_attr_check_read_attr(g_sai_vlan_attr_entries,attr);

        if(ret != SAI_STATUS_SUCCESS)
        {
            return ret + attr_idx;
        }

        switch(attr->id)
        {
        case SAI_VLAN_ATTR_PORT_LIST:
            ret = ctc_sai_vlan_get_vlan_port_list(vlan_id, attr_list);
            break;
            
        case SAI_VLAN_ATTR_MAX_LEARNED_ADDRESSES:
            ret = ctc_sai_vlan_get_max_learned_address(vlan_id, attr);
            break;
        case SAI_VLAN_ATTR_STP_INSTANCE:
            ret = ctc_sai_vlan_get_stp_instance(vlan_id, attr);
            break;

        case SAI_VLAN_ATTR_LEARN_DISABLE:
            ret = ctc_sai_vlan_get_learn_disable(vlan_id, attr);
            break;
            
        case SAI_VLAN_ATTR_INGRESS_MIRROR_SESSION:
            ret = ctc_sai_vlan_get_ingress_mirror_session(vlan_id, attr);
            break;
            
        case SAI_VLAN_ATTR_EGRESS_MIRROR_SESSION:
            ret = ctc_sai_vlan_get_egress_mirror_session(vlan_id, attr);
            break;  
            
        case SAI_VLAN_ATTR_META_DATA:
            break;
        }

        if(ret != SAI_STATUS_SUCCESS)
        {
            break;
        }
    }

    ctc_sai_get_vlan_attribute_debug_param(vlan_id, attr_count, attr_list);
    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*    Remove VLAN configuration (remove all VLANs).
*
* Arguments:
*    None
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_remove_all_vlans(void)
{
    sai_vlan_id_t vlan_id = 0;

    CTC_SAI_DEBUG_FUNC();

    for(vlan_id = 1; vlan_id < 4096; vlan_id++)
    {
        ctc_sai_remove_vlan(vlan_id);
    }

    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*    Add Port to VLAN
*
* Arguments:
*    [in] vlan_id - VLAN id
*    [in] port_count - number of ports
*    [in] port_list - pointer to membership structures
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_add_ports_to_vlan(
    _In_ sai_vlan_id_t vlan_id,
    _In_ uint32_t port_count,
    _In_ const sai_vlan_port_t* port_list)
{
    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_DEBUG("in:vlan_id %u port_count %u", vlan_id, port_count);
    CTC_SAI_PTR_VALID_CHECK(port_list);

    return ctc_sai_vlan_add_ports_to_vlan(vlan_id,port_count,port_list);
}

/*
* Routine Description:
*    Remove Port from VLAN
*
* Arguments:
*    [in] vlan_id - VLAN id
*    [in] port_count - number of ports
*    [in] port_list - pointer to membership structures
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_remove_ports_from_vlan(
    _In_ sai_vlan_id_t vlan_id,
    _In_ uint32_t port_count,
    _In_ const sai_vlan_port_t* port_list)
{
    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_DEBUG("in:vlan_id %u port_count %u", vlan_id, port_count);
    CTC_SAI_PTR_VALID_CHECK(port_list);

    return ctc_sai_vlan_remove_ports_to_vlan(vlan_id,port_count,port_list);
}

/*
* Routine Description:
*   Get vlan statistics counters.
*
* Arguments:
*    [in] vlan_id - VLAN id
*    [in] counter_ids - specifies the array of counter ids
*    [in] number_of_counters - number of counters in the array
*    [out] counters - array of resulting counter values.
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_get_vlan_stats(
    _In_ sai_vlan_id_t vlan_id,
    _In_ const sai_vlan_stat_counter_t *counter_ids,
    _In_ uint32_t number_of_counters,
    _Out_ uint64_t* counters)
{
    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_DEBUG("in:vlan_id %u port_count %u number_of_counters %u", 
        vlan_id, number_of_counters);
    CTC_SAI_PTR_VALID_CHECK(counter_ids);
    CTC_SAI_PTR_VALID_CHECK(counters);

    return ctc_sai_vlan_db_get_vlan_stats(vlan_id, counter_ids, number_of_counters, counters);
}


#define ________SAI_VLAN_INNER_FUNC
static sai_status_t
__init_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    g_sai_vlan_info.pvector = ctc_vector_init(CTC_VEC_BLOCK_NUM(4096, CTC_SAI_VLAN_BLOCK_SIZE),
                                CTC_SAI_VLAN_BLOCK_SIZE);

    g_sai_vlan_attr.pvector = ctc_vector_init(CTC_VEC_BLOCK_NUM(4096, CTC_SAI_VLAN_BLOCK_SIZE),
                                CTC_SAI_VLAN_BLOCK_SIZE);

    g_sai_vlan_info.p_hash = ctc_hash_create(64, 32, _vlan_vlan_hash_make, _vlan_vlan_hash_cmp);

    g_sai_vlan_info.p_vlan_list_vector = ctc_vector_init(CTC_VEC_BLOCK_NUM(4096, CTC_SAI_VLAN_BLOCK_SIZE),
                                CTC_SAI_VLAN_BLOCK_SIZE);

    /* init the global vlan port list and vlan list */

    sal_memset(g_vlan_id, 0, sizeof(g_vlan_id));        

    if(!g_sai_vlan_info.pvector)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }

    if (!g_sai_vlan_attr.pvector)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }

    if(!g_sai_vlan_info.p_vlan_list_vector)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }

    ctc_sai_vlan_set_default_learn_disable(FALSE);
    
    preg->init_status              = INITIALIZED;

out:
    return ret;

    goto out;
}

static sai_status_t
__exit_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}

/* define sai 0.9.2 */
static sai_vlan_api_t      g_sai_api_func = {
    .create_vlan            = ctc_sai_create_vlan,
    .remove_vlan            = ctc_sai_remove_vlan,
    .set_vlan_attribute     = ctc_sai_set_vlan_attribute,
    .get_vlan_attribute     = ctc_sai_get_vlan_attribute,
    .add_ports_to_vlan      = ctc_sai_add_ports_to_vlan,
    .remove_ports_from_vlan = ctc_sai_remove_ports_from_vlan,
    .remove_all_vlans       = ctc_sai_remove_all_vlans,
    .get_vlan_stats         = ctc_sai_get_vlan_stats,
};

static ctc_sai_api_reg_info_t g_api_reg_info = {
        .id         = SAI_API_VLAN,
        .init_func  = __init_mode_fn,
        .exit_func  = __exit_mode_fn,
        .api_method_table = &g_sai_api_func,
        .private_data     = NULL,
};

#define ________SAI_FDB_OUTER_FUNC
sai_status_t
ctc_sai_vlan_init()
{
    api_reg_register_fn(&g_api_reg_info);

    return SAI_STATUS_SUCCESS;
}


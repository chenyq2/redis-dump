#if !defined (__SAI_VLAN_H_)
#define __SAI_VLAN_H_

#include <saivlan.h>

typedef struct ctc_sai_vlan_attr_entry_s
{
    bool learn_disable;
    
}ctc_sai_vlan_attr_entry_t;


typedef struct ctc_sai_vlan_list_s
{
    sai_vlan_id_t           vlan_id;
    sai_vlan_port_list_t    vlan_port_list;

}ctc_sai_vlan_list_t;


sai_status_t ctc_sai_vlan_init();

sai_vlan_id_t*
ctc_sai_vlan_get_vlan_id_global();


#endif


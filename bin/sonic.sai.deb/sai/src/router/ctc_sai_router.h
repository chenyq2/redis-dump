#if !defined (__SAI_ROUTER_H_)
#define __SAI_ROUTER_H_

#include <sairouter.h>
#include <ctc_vector.h>
#include <ctc_opf.h>
#include <ctc_mix.h>


struct ctc_sai_routerintf_entry_s;

typedef struct ctc_sai_vr_entry_s
{
    int32_t                 ref;
    ctc_linklist_t          *list_routerintf;
    sai_object_id_t         vr_id;
    sai_mac_t               smac;
    bool                    v4_admin;
    bool                    v6_admin;
}ctc_sai_vr_entry_t;

typedef struct ctc_sai_vr_info_s
{
    ctc_vector_t    *pvector;
    uint32_t        max_count;
    ctc_opf_t       opf;
}ctc_sai_vr_info_t;

sai_status_t
ctc_vr_add_router_intf(
    _In_ ctc_sai_vr_entry_t*,
    _In_ struct ctc_sai_routerintf_entry_s *);

sai_status_t
ctc_vr_remove_router_intf(
    _In_ ctc_sai_vr_entry_t* ,
    _In_ struct ctc_sai_routerintf_entry_s *);

void
ctc_vr_release(
    _In_ ctc_sai_vr_entry_t *);

ctc_sai_vr_entry_t*
ctc_vr_get_by_oid(
    _In_ const sai_object_id_t );

sai_status_t
ctc_sai_vr_init();

sai_status_t
ctc_vr_alloc(
	_Out_ ctc_sai_vr_entry_t** pvr_entry);

sai_status_t
ctc_vr_add_entry(
	_In_  ctc_sai_vr_entry_t *pvr_entry);

sai_status_t
ctc_sai_remove_virtual_router(
    _In_ sai_object_id_t vr_id);


#endif


#include <sai.h>
#include "ctc_api.h"
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_notifier_call.h>
#include <ctc_sai_sai.h>
#include <ctc_sai_fdb.h>
#include <ctc_sai_neighbor.h>
#include <ctc_sai_routerintf.h>
#include <ctc_sai_hostif.h>
#include <ctc_sai_nexthop.h>
#include <ctc_sai_port.h>
#include <ctc_sai_debug.h>
#include <ctc_sai_vrrp.h>

static ctc_sai_vrrp_info_t g_sai_vrrp_info;

static ctc_sai_attr_entry_info_t g_sai_attr_entries[] = {
    {
        .id     = SAI_VRRP_ATTR_VMAC_ADDRESS,
        .type   = SAI_ATTR_FALG_CREATE | SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_VRRP_ATTR_IF_MAC_ADDRESS,
        .type   = SAI_ATTR_FALG_CREATE | SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_ATTR_ID_END,
        .type   = 0,
    },
};

ctc_sai_vrrp_vip_entry_t*
ctc_vrrp_vip_get_by_key(
    _In_  const sai_vrrp_vip_entry_t* pkey)
{
    ctc_sai_vrrp_vip_entry_t  *pnb_entry = NULL;

    pnb_entry = ctc_hash_lookup(g_sai_vrrp_info.phash,(void*)pkey);

    return pnb_entry;
}

sai_status_t
ctc_vrrp_vip_alloc(
    _In_  ctc_sai_vrrp_vip_entry_t** ppnb_entry)
{
    sai_status_t                ret = SAI_STATUS_SUCCESS;
    ctc_sai_vrrp_vip_entry_t    *pnb_entry = NULL;

    if (g_sai_vrrp_info.phash->count >= g_sai_vrrp_info.max_count)
    {
        ret = SAI_STATUS_TABLE_FULL;
        goto out;
    }

    pnb_entry = mem_malloc(MEM_APP_VRRP_MODULE,sizeof(ctc_sai_vrrp_vip_entry_t));
    if (NULL == pnb_entry)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }
    sal_memset(pnb_entry, 0, sizeof(ctc_sai_vrrp_vip_entry_t));

    *ppnb_entry = pnb_entry;

out:
    return ret;
}


/*
* Routine Description:
*    Create vrrp vip entry
*
* Arguments:
*    [in] vrrp_vip_entry - vrrp vip entry
*    [in] attr_count - number of attributes
*    [in] attrs - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*
* Note: IP address expected in Network Byte Order.
*/
sai_status_t
ctc_sai_create_vrrp_vip_entry(
    _In_ const sai_vrrp_vip_entry_t* vrrp_vip_entry,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    ctc_sai_attr_entry_list_t   *pattr_entry_list   = NULL;
    ctc_sai_vrrp_vip_entry_t    *pst_vrrp_vip = NULL;
    sai_status_t                ret = SAI_STATUS_SUCCESS;

    CTC_SAI_ERROR_GOTO(ctc_sai_attr_alloc_attr_entry_list(g_sai_attr_entries,
                            attr_list,
                            attr_count,
                            &pattr_entry_list),ret,out);

    CTC_SAI_ERROR_GOTO(ctc_sai_attr_check_attr_entry_list(g_sai_attr_entries,
                            pattr_entry_list),ret,out);

    /* 1. check vip exist */
    pst_vrrp_vip = ctc_vrrp_vip_get_by_key(vrrp_vip_entry);
    if (NULL != pst_vrrp_vip)
    {
        ret = SAI_STATUS_ITEM_ALREADY_EXISTS;
        goto out;
    }

    /* 2. alloc vip */
    ret = ctc_vrrp_vip_alloc(&pst_vrrp_vip);
    if(SAI_STATUS_SUCCESS != ret)
    {
        goto out;
    }

    /* 3. set vip parameter */
    sal_memcpy(&pst_vrrp_vip->key, vrrp_vip_entry, sizeof(sai_vrrp_vip_entry_t));

    sal_memcpy(pst_vrrp_vip->vmac,
        pattr_entry_list[SAI_VRRP_ATTR_VMAC_ADDRESS].value.mac,
        sizeof(sai_mac_t));

    sal_memcpy(pst_vrrp_vip->if_mac,
        pattr_entry_list[SAI_VRRP_ATTR_IF_MAC_ADDRESS].value.mac,
        sizeof(sai_mac_t));

    ctc_hash_insert(g_sai_vrrp_info.phash, pst_vrrp_vip);

out:
    if(pattr_entry_list)
    {
        ctc_sai_attr_free_attr_entry_list(pattr_entry_list);
    }

    return ret;    
}


sai_status_t
ctc_vrrp_vip_remove_entry(
    _In_  ctc_sai_vrrp_vip_entry_t *pnb_entry)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    ctc_hash_remove(g_sai_vrrp_info.phash, &pnb_entry->key);

    return ret;
}

void
ctc_vrrp_vip_release(
    _In_  ctc_sai_vrrp_vip_entry_t *pnb_entry)
{
    if(NULL == pnb_entry)
    {
        return ;
    }

    mem_free(pnb_entry);
}

/*
* Routine Description:
*    Remove vrrp vip entry
*
* Arguments:
*    [in] vrrp_vip_entry - vrrp vip entry
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*
* Note: IP address expected in Network Byte Order.
*/
sai_status_t
ctc_sai_remove_vrrp_vip_entry(
    _In_ const sai_vrrp_vip_entry_t* vrrp_vip_entry)
{
    ctc_sai_vrrp_vip_entry_t *pst_vrrp_vip_entry = NULL;

    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_PTR_VALID_CHECK(vrrp_vip_entry);

    pst_vrrp_vip_entry = ctc_vrrp_vip_get_by_key(vrrp_vip_entry);
    if (NULL == pst_vrrp_vip_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    ctc_vrrp_vip_remove_entry(pst_vrrp_vip_entry);
    ctc_vrrp_vip_release(pst_vrrp_vip_entry);
    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*    Set neighbor attribute value
*
* Arguments:
*    [in] neighbor_entry - neighbor entry
*    [in] attr - attribute
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/


static uint32_t
__vrrp_hash_make(
    _In_  void* data)
{
    sai_vrrp_vip_entry_t* pnb_key = (sai_vrrp_vip_entry_t*)data;

    return ctc_hash_caculate(sizeof(sai_vrrp_vip_entry_t), pnb_key);
}


static bool
__vrrp_hash_cmp(
    _In_  sai_vrrp_vip_entry_t* pnb_key,
    _In_  sai_vrrp_vip_entry_t* pnb_key1)
{
    if (sal_memcmp(&pnb_key->ip_address, &pnb_key1->ip_address, sizeof(sai_ip_address_t)))
    {
        return FALSE;
    }

    return TRUE;
}

sai_status_t
ctc_vrrp_init()
{
    sai_status_t ret        = SAI_STATUS_SUCCESS;

    g_sai_vrrp_info.max_count = CTC_SAI_VRRP_MAX;
    g_sai_vrrp_info.phash   =
        ctc_hash_create(CTC_VEC_BLOCK_NUM(g_sai_vrrp_info.max_count, VRRP_HASH_BLOCK_SIZE),
            VRRP_HASH_BLOCK_SIZE,
            (hash_key_fn)__vrrp_hash_make,
            (hash_cmp_fn)__vrrp_hash_cmp);

    if(NULL == g_sai_vrrp_info.phash)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }

    return CTC_SAI_NOTIFY_DONE;

out:
    if(g_sai_vrrp_info.phash)
    {
        ctc_hash_free(g_sai_vrrp_info.phash);
    }
    return ret;
}

static sai_status_t
__init_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    CTC_SAI_ERROR_GOTO(ctc_vrrp_init(),ret,out);

    preg->init_status =  INITIALIZED;

out:
    return ret;
}

static sai_status_t
__exit_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}

/* define sai 0.9.2 */
static sai_vrrp_api_t      g_sai_api_func = {
    .create_vrrp_vip_entry      = ctc_sai_create_vrrp_vip_entry,
    .remove_vrrp_vip_entry      = ctc_sai_remove_vrrp_vip_entry,
};

static ctc_sai_api_reg_info_t g_api_vrrp_reg_info = {
        .id         = SAI_API_VRRP,
        .init_func  = __init_mode_fn,
        .exit_func  = __exit_mode_fn,
        .api_method_table = &g_sai_api_func,
        .private_data     = NULL,
};

#define ________SAI_OUTER_FUNC
sai_status_t
ctc_sai_vrrp_init()
{
    api_reg_register_fn(&g_api_vrrp_reg_info);

    return SAI_STATUS_SUCCESS;
}


#if !defined (__SAI_NEXTHOP_GROUP_H_)
#define __SAI_NEXTHOP_GROUP_H_

#include <saifdb.h>
#include <ctc_vector.h>
#include <ctc_opf.h>
#include <ctc_mix.h>
#include <ctc_sai_common.h>

#define CTC_SAI_NEXTHOP_GROUP_MAX_ENTRY     16384//1024
#define CTC_SAI_NH_GROUP_OFFSET             12000//8K + 3000
//#define CTC_SAI_DEFAULT_MAX_ECMP_NUM        64

struct ctc_sai_nexthop_entry_s;

typedef struct ctc_sai_nexthop_group_list_node_s
{
    ctc_list_pointer_node_t node;
    struct ctc_sai_nexthop_entry_s*  pnh_entry;

}ctc_sai_nexthop_group_list_node_t;

typedef struct ctc_sai_nexthop_group_entry_s
{
    int32_t                 ref;
    sai_object_id_t         nhg_id;
    uint32_t                nhg_type;
    ctc_list_pointer_t      nh_list_head;
    struct
    {
        uint32_t            nhid;
        uint32_t            drop_count;
    }sdk;

}ctc_sai_nexthop_group_entry_t;

typedef struct ctc_sai_nexthop_group_id_info_s
{
    sai_object_id_t         nhg_id;
    sai_object_id_t         nhid[CTC_SAI_DEFAULT_MAX_ECMP_NUM];
    int32_t                 nh_num;

}ctc_sai_nexthop_group_id_info_t;

typedef struct ctc_sai_nexthop_group_info_s
{
    ctc_vector_t*   pvector;
    uint32_t        max_count;
    ctc_opf_t       opf;

}ctc_sai_nexthop_group_info_t;

void
ctc_nexthop_group_release(
    _In_  ctc_sai_nexthop_group_entry_t *);

ctc_sai_nexthop_group_entry_t*
ctc_nexthop_group_get_by_oid(
    _In_  const sai_object_id_t);

ctc_sai_nexthop_group_entry_t*
ctc_nexthop_group_get_by_oid_no_ref(
    _In_  const sai_object_id_t nhg_id);

ctc_sai_nexthop_group_id_info_t*
ctc_nexthop_group_id_get_global();

uint16_t
ctc_nexthop_group_get_nhg_cnt_global();

sai_status_t
ctc_sai_nexthop_group_init();


#endif


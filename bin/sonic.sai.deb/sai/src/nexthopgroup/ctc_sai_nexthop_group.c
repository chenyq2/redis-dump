#include <sai.h>
#include "sal.h"
#include <ctc_api.h>
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_notifier_call.h>
#include <ctc_sai_sai.h>
#include <ctc_sai_nexthop.h>
#include <ctc_sai_nexthop_group.h>
#include <ctc_sai_debug.h>

#define CTC_SAI_NEXTHOP_GROUP_BLOCK_SIZE    64
#define CTC_SAI_NEXTHOP_GROUP_MAX           239

uint16  nexthop_group_num = 0;

static ctc_sai_nexthop_group_info_t  g_sai_nhg_info;
static ctc_sai_nexthop_group_id_info_t g_sai_nh_group_id_info[CTC_SAI_NEXTHOP_GROUP_MAX_ENTRY - CTC_SAI_NH_GROUP_OFFSET + 1];

static ctc_sai_attr_entry_info_t g_sai_attr_entries[] = {
    {
        .id     = SAI_NEXT_HOP_GROUP_ATTR_NEXT_HOP_COUNT,
        .type   = SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_NEXT_HOP_GROUP_ATTR_TYPE,
        .type   =  SAI_ATTR_FALG_READ | SAI_ATTR_FALG_WRITE,
    },
    {
        .id     = SAI_NEXT_HOP_GROUP_ATTR_NEXT_HOP_LIST,
        .type   = SAI_ATTR_FALG_CREATE | SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_ATTR_ID_END,
        .type   = 0,
    },
};

ctc_sai_nexthop_group_id_info_t*
ctc_nexthop_group_id_get_global()
{
    return g_sai_nh_group_id_info;
}

sai_status_t
ctc_nexthop_group_id_sort_bob(_In_  sai_object_id_t *nhid_sort)
{
    sai_object_id_t     id_compare = 0;
    uint32              i = 0;
    uint32              k = 0;

    for(i = 0; i < CTC_SAI_DEFAULT_MAX_ECMP_NUM; i++)
    {
        for(k = CTC_SAI_DEFAULT_MAX_ECMP_NUM - 1; k > i; k--)
        {
            if (0 == nhid_sort[i] || 0 == nhid_sort[k])
            {
                continue;
            }

            if (nhid_sort[i] > nhid_sort[k])
            {
                id_compare = nhid_sort[k];
                nhid_sort[k] = nhid_sort[i];
                nhid_sort[i] = id_compare;
            }
        }
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_nexthop_group_id_sort(_In_  sai_object_id_t *nhid_sort)
{
    sai_object_id_t         nhid_st[CTC_SAI_DEFAULT_MAX_ECMP_NUM];
    sai_object_id_t         id_compare = 0;
    uint32                  i = 0;
    uint32                  j = 0;
    uint32                  k = 0;

    sal_memset(nhid_st,  0, sizeof(nhid_st));

    for(i = 0; i < CTC_SAI_DEFAULT_MAX_ECMP_NUM; i++)
    {
        if (nhid_sort[i])
        {
            id_compare = nhid_sort[i];
        }
        else
        {
            continue;
        }

        for(k = i; k < CTC_SAI_DEFAULT_MAX_ECMP_NUM; k++)
        {
            if (id_compare > nhid_sort[k] && nhid_sort[k])
            {
                id_compare = nhid_sort[k];
                sal_memset(&nhid_sort[k],  0, sizeof(sai_object_id_t));
            }
        }

        sal_memset(&nhid_sort[i],  0, sizeof(sai_object_id_t));
        j ++;
        nhid_st[j] = id_compare;
    }

    sal_memcpy(nhid_sort, nhid_st,sizeof(nhid_st));

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_nexthop_group_id_insert(
    _In_  const sai_object_id_t nhg_id,
    _In_  const sai_object_id_t *nh_id, int32_t num)
{
    ctc_sai_nexthop_group_id_info_t * p_master = NULL;
    sai_object_id_t         nhid_sort[CTC_SAI_DEFAULT_MAX_ECMP_NUM];
    uint32 i        =0;
    uint32 index    = 0;

    p_master = ctc_nexthop_group_id_get_global();
    if (NULL == p_master)
    {
        return SAI_STATUS_FAILURE;
    }

    sal_memset(nhid_sort, 0 , sizeof(nhid_sort));
    index = nhg_id - CTC_SAI_NH_GROUP_OFFSET;
    p_master[index].nhg_id = nhg_id;
    p_master[index].nh_num = num;
    for(i = 0; i < CTC_SAI_DEFAULT_MAX_ECMP_NUM; i++)
    {
       nhid_sort[i] = nh_id[i];
    }

    ctc_nexthop_group_id_sort_bob(nhid_sort);
    sal_memcpy(p_master[index].nhid, nhid_sort, sizeof(nhid_sort));

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_nexthop_group_id_delete(
    _In_  const sai_object_id_t nhg_id)
{
    ctc_sai_nexthop_group_id_info_t * p_master = NULL;
    uint32 index = 0;

    p_master = ctc_nexthop_group_id_get_global();
    if (NULL == p_master)
    {
        return SAI_STATUS_FAILURE;
    }

    index = nhg_id - CTC_SAI_NH_GROUP_OFFSET;
    sal_memset(&p_master[index], 0, sizeof(p_master[index]));

    return SAI_STATUS_SUCCESS;
}

sai_status_t
__nexthop_group_create_ecmp_group(
    _In_  ctc_sai_nexthop_group_entry_t* pnhg_entry)
{
    struct ctc_sai_nexthop_entry_s      *pnh_entry      = NULL;
    ctc_list_pointer_node_t             *pnode          = NULL;
    ctc_sai_nexthop_group_list_node_t   *pnhgn_entry    = NULL;
    ctc_nh_ecmp_nh_param_t              nh_param;
    sai_object_id_t     nh_id_arr[CTC_SAI_DEFAULT_MAX_ECMP_NUM];
    int32_t                             idx_node        = 0;
    int32_t                             sdk_ret         = 0;
    int32_t                             ret             = 0;

    sal_memset(&nh_param, 0, sizeof(nh_param));
    sal_memset(nh_id_arr, 0, sizeof(nh_id_arr));

    CTC_LIST_POINTER_LOOP(pnode, &pnhg_entry->nh_list_head)
    {
        pnhgn_entry     = _ctc_container_of(pnode, ctc_sai_nexthop_group_list_node_t, node);
        pnh_entry       = pnhgn_entry->pnh_entry;
        nh_param.nhid[idx_node] = pnh_entry->nh_id;
        nh_id_arr[idx_node] = pnh_entry->nh_id;

        if(nh_param.nhid[idx_node] == NEIGHBOR_ACTION_DROP_NHID)
        {
            pnhg_entry->sdk.drop_count++;
        }

        idx_node++;
    }

    nh_param.nh_num = idx_node;

    ret = ctc_nexthop_group_id_insert(pnhg_entry->nhg_id, nh_id_arr, idx_node);

    sdk_ret = ctc_nh_add_ecmp(pnhg_entry->sdk.nhid, &nh_param);

    (void)ret;
    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
__nexthop_group_remove_ecmp_group(
    _In_  ctc_sai_nexthop_group_entry_t *pnhg_entry)
{
    int32_t                             sdk_ret = 0;
    int32_t                             ret     = 0;

    sdk_ret = ctc_nh_remove_ecmp(pnhg_entry->sdk.nhid);
    ret = ctc_nexthop_group_id_delete(pnhg_entry->nhg_id);

    (void)ret;
    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_nexthop_group_add_member(
    _In_  ctc_sai_nexthop_group_entry_t *pnhg_entry,
    _In_  ctc_sai_nexthop_entry_t       *pnh_entry)
{
    ctc_nh_ecmp_nh_param_t              nh_param;
    int32_t                             sdk_ret = 0;

    sal_memset(&nh_param, 0, sizeof(nh_param));

    if(pnh_entry->nh_id == NEIGHBOR_ACTION_DROP_NHID)
    {
        if(pnhg_entry->sdk.drop_count)
        {
            pnhg_entry->sdk.drop_count++;
            return SAI_STATUS_SUCCESS;
        }
    }

    nh_param.nhid[0] = pnh_entry->nh_id;
    nh_param.nh_num  = 1;
    nh_param.upd_type= CTC_NH_ECMP_ADD_MEMBER;

    sdk_ret = ctc_nh_update_ecmp(pnhg_entry->sdk.nhid, &nh_param);

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_nexthop_group_remove_member(
    _In_  ctc_sai_nexthop_group_entry_t *pnhg_entry,
    _In_  ctc_sai_nexthop_entry_t       *pnh_entry)
{
    ctc_nh_ecmp_nh_param_t              nh_param;
    int32_t                             sdk_ret = 0;

    sal_memset(&nh_param, 0, sizeof(nh_param));

    if(pnh_entry->nh_id == NEIGHBOR_ACTION_DROP_NHID)
    {
        pnhg_entry->sdk.drop_count--;
        if(pnhg_entry->sdk.drop_count)
        {
            return SAI_STATUS_SUCCESS;
        }
    }

    nh_param.nhid[0] = pnh_entry->nh_id;
    nh_param.nh_num  = 1;
    nh_param.upd_type= CTC_NH_ECMP_REMOVE_MEMBER;

    sdk_ret = ctc_nh_update_ecmp(pnhg_entry->sdk.nhid, &nh_param);

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_nexthop_group_alloc(
    _In_  ctc_sai_nexthop_group_entry_t** ppnhg_entry)
{
    sai_status_t                    ret         = SAI_STATUS_SUCCESS;
    ctc_sai_nexthop_group_entry_t   *pnhg_entry = NULL;
    uint32_t                        index     = 0;

    if(g_sai_nhg_info.pvector->used_cnt >= g_sai_nhg_info.max_count)
    {
        return SAI_STATUS_TABLE_FULL;
    }

    pnhg_entry = mem_malloc(MEM_APP_NEXTHOP_GRP_MODULE, sizeof(ctc_sai_nexthop_group_entry_t));

    if(!pnhg_entry)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }

    sal_memset(pnhg_entry, 0, sizeof(ctc_sai_nexthop_group_entry_t));
    ctc_list_pointer_init(&pnhg_entry->nh_list_head);

    CTC_SAI_ERROR_GOTO(ctc_opf_alloc_offset(&g_sai_nhg_info.opf, 0, &index), ret, out1);

    pnhg_entry->nhg_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP_GROUP, index);

    refcnt_inc(pnhg_entry);

    pnhg_entry->sdk.nhid = index;

    *ppnhg_entry = pnhg_entry;

out:
    return ret;
out1:
    if(pnhg_entry)
    {
        mem_free(pnhg_entry);
        pnhg_entry = NULL;
    }

    //ctc_opf_free_offset(&g_sai_nhg_info.opf, 0,CTC_SAI_OBJECT_INDEX_GET(pnhg_entry->nhg_id));
    goto out;
}

void
ctc_nexthop_group_release(
    _In_  ctc_sai_nexthop_group_entry_t *pnhg_entry)
{
    if(NULL == pnhg_entry)
    {
        return ;
    }

    ctc_opf_free_offset(&g_sai_nhg_info.opf,0,CTC_SAI_OBJECT_INDEX_GET(pnhg_entry->nhg_id));
    mem_free(pnhg_entry);

}

ctc_sai_nexthop_group_entry_t*
ctc_nexthop_group_get_by_oid_no_ref(
    _In_  const sai_object_id_t nhg_id)
{
    ctc_sai_nexthop_group_entry_t  *pnhg_entry = NULL;

    pnhg_entry = ctc_vector_get(g_sai_nhg_info.pvector,
                                CTC_SAI_OBJECT_INDEX_GET(nhg_id));

    return pnhg_entry;
}

ctc_sai_nexthop_group_entry_t*
ctc_nexthop_group_get_by_oid(
    _In_  const sai_object_id_t nhg_id)
{
    ctc_sai_nexthop_group_entry_t  *pnhg_entry = NULL;

    pnhg_entry = ctc_nexthop_group_get_by_oid_no_ref(nhg_id);

    if(pnhg_entry)
    {
        refcnt_inc(pnhg_entry);
    }

    return pnhg_entry;
}

uint16_t
ctc_nexthop_group_get_nhg_cnt_global()
{
    return nexthop_group_num;
}

void
ctc_nexthop_group_nhg_cnt_inc()
{
    nexthop_group_num ++;
}

void
ctc_nexthop_group_nhg_cnt_dec()
{
    nexthop_group_num --;
}

void
__nexthop_group_remove_nexthoplist(
    _In_  ctc_sai_nexthop_group_entry_t *pnhg_entry)
{
    ctc_list_pointer_node_t             *pnode          = NULL;
    ctc_list_pointer_node_t             *pnext_node     = NULL;
    ctc_sai_nexthop_group_list_node_t   *pnhgn_entry    = NULL;

    CTC_LIST_POINTER_LOOP_DEL(pnode, pnext_node, &pnhg_entry->nh_list_head)
    {
        pnhgn_entry = _ctc_container_of(pnode, ctc_sai_nexthop_group_list_node_t, node);
        pnhgn_entry->pnh_entry = NULL;
        ctc_list_pointer_delete(&pnhg_entry->nh_list_head, pnode);
        mem_free(pnhgn_entry);
    }
}

sai_status_t
__nexthop_group_create_nexthoplist(
    _In_  ctc_sai_nexthop_group_entry_t *pnhg_entry,
    _In_  const sai_object_list_t       *objlist)
{
    ctc_sai_nexthop_entry_t             *pnh_entry   = NULL;
    ctc_sai_nexthop_group_list_node_t   *pnhgn_entry = NULL;
    sai_status_t    ret         = SAI_STATUS_SUCCESS;
    uint32_t        i           = 0;

    for(i = 0; i < objlist->count; i++)
    {
        pnh_entry = ctc_nexthop_get_by_oid_no_ref(objlist->list[i]);
        if(NULL == pnh_entry)
        {
            ret = SAI_STATUS_ITEM_NOT_FOUND;
            goto out;
        }
        pnhgn_entry = mem_malloc(MEM_APP_NEXTHOP_GRP_MODULE,sizeof(ctc_sai_nexthop_group_list_node_t));
        if(!pnhgn_entry)
        {
            ret = SAI_STATUS_NO_MEMORY;
            goto out;
        }

        pnhgn_entry->pnh_entry = pnh_entry;

        ctc_list_pointer_insert_head(&pnhg_entry->nh_list_head, &pnhgn_entry->node);
    }

    if(!pnhg_entry->nh_list_head.count)
    {
        ret = SAI_STATUS_INVALID_PARAMETER;
    }

    return ret;

out:
    __nexthop_group_remove_nexthoplist(pnhg_entry);
    return ret;
}


sai_status_t
__nexthop_group_exist_check_nexthoplist(_In_  const sai_object_list_t  *objlist, sai_object_id_t *nhg_id_ret)
{
    ctc_sai_nexthop_group_id_info_t * p_master = NULL;
    ctc_sai_nexthop_entry_t         *pnh_entry  = NULL;
    sai_object_id_t                 nhid_st[CTC_SAI_DEFAULT_MAX_ECMP_NUM];
    ctc_sai_nexthop_group_id_info_t id_info;
    sai_status_t    ret     = SAI_STATUS_SUCCESS;
    uint32          i       = 0;

    sal_memset(nhid_st, 0, sizeof(nhid_st));
    sal_memset(&id_info, 0 ,sizeof(id_info));
    p_master = ctc_nexthop_group_id_get_global();
    if (NULL == p_master)
    {
        return SAI_STATUS_FAILURE;
    }

    for(i = 0; i < objlist->count; i++)
    {
        pnh_entry = ctc_nexthop_get_by_oid_no_ref(objlist->list[i]);
        if(NULL == pnh_entry)
        {
            ret = SAI_STATUS_ITEM_NOT_FOUND;
            goto out;
        }

        nhid_st[i] = pnh_entry->nh_id;
    }

    ctc_nexthop_group_id_sort_bob(nhid_st);

    for(i = 0; i < (CTC_SAI_NEXTHOP_GROUP_MAX_ENTRY - CTC_SAI_NH_GROUP_OFFSET); i++)
    {
        if (((CTC_SAI_NEXTHOP_GROUP_MAX_ENTRY - CTC_SAI_NH_GROUP_OFFSET) - 1) == i)
        {
            goto out;
        }
        if (0 == sal_memcmp(&p_master[i], &id_info, sizeof(id_info)))
        {
            continue;
        }
        if (0 != sal_memcmp(p_master[i].nhid, nhid_st, sizeof(nhid_st)))
        {
            continue;
        }
        else
        {
            *nhg_id_ret = p_master[i].nhg_id;
            goto out1;
        }
    }

out1:
    return SAI_STATUS_ITEM_ALREADY_EXISTS;

out:
    return ret;
}

sai_status_t
ctc_nexthop_group_add_entry(
    _In_  ctc_sai_nexthop_group_entry_t **ppnhg_entry,
    _In_  const sai_object_list_t       *objlist)
{
    sai_status_t                ret = SAI_STATUS_SUCCESS;
    uint32                      rc = 0;
    sai_object_id_t             nhg_id_exist    = 0;
    ctc_sai_nexthop_group_entry_t *pst_nhg      = NULL;

    rc = __nexthop_group_exist_check_nexthoplist(objlist, &nhg_id_exist);
    if (SAI_STATUS_ITEM_ALREADY_EXISTS == rc)
    {
        if (nhg_id_exist)
        {
            pst_nhg = ctc_nexthop_group_get_by_oid_no_ref(nhg_id_exist);
            if (NULL != pst_nhg)
            {
                refcnt_inc(pst_nhg);
                ctc_nexthop_group_release(*ppnhg_entry);

                ctc_vector_del(g_sai_nhg_info.pvector,
                            CTC_SAI_OBJECT_INDEX_GET(pst_nhg->nhg_id));

                ctc_vector_add(g_sai_nhg_info.pvector,
                            CTC_SAI_OBJECT_INDEX_GET(pst_nhg->nhg_id),
                            pst_nhg);

                *ppnhg_entry = pst_nhg;
                goto out;
            }
        }
    }

    CTC_SAI_ERROR_GOTO(__nexthop_group_create_nexthoplist(*ppnhg_entry,objlist),ret,out);

    CTC_SAI_ERROR_GOTO(__nexthop_group_create_ecmp_group(*ppnhg_entry),ret,out1);

    ctc_nexthop_group_nhg_cnt_inc();
    ctc_vector_add(g_sai_nhg_info.pvector,
                CTC_SAI_OBJECT_INDEX_GET((*ppnhg_entry)->nhg_id),
                (*ppnhg_entry));

out:
    return ret;

out1:
    __nexthop_group_remove_nexthoplist(*ppnhg_entry);
    goto out;
}


sai_status_t
ctc_sai_nexthop_group_db_remove_entry(
    _In_  ctc_sai_nexthop_group_entry_t *pnhg_entry)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    __nexthop_group_remove_nexthoplist(pnhg_entry);

    ret = __nexthop_group_remove_ecmp_group(pnhg_entry);
    if (!ret)
    {
        ctc_nexthop_group_nhg_cnt_dec();
    }

    ctc_vector_del(g_sai_nhg_info.pvector,
                CTC_SAI_OBJECT_INDEX_GET(pnhg_entry->nhg_id));

    return ret;
}

ctc_sai_nexthop_group_list_node_t*
__lookup_nexthopnode(
    _In_  ctc_sai_nexthop_group_entry_t *pnhg_entry,
    _In_  sai_object_id_t               nhobj)
{
    ctc_list_pointer_node_t     *pnode      = NULL;
    ctc_list_pointer_node_t     *pnext_node = NULL;
    ctc_sai_nexthop_group_list_node_t*  pnhgn_entry = NULL;

    CTC_LIST_POINTER_LOOP_DEL(pnode, pnext_node, &pnhg_entry->nh_list_head)
    {
        pnhgn_entry = _ctc_container_of(pnode, ctc_sai_nexthop_group_list_node_t, node);
        if(pnhgn_entry->pnh_entry->nh_id == nhobj)
        {
            return pnhgn_entry;
        }
    }

    return NULL;
}

sai_status_t
ctc_nexthop_group_add_nexthop(
    _In_  ctc_sai_nexthop_group_entry_t *pnhg_entry,
    _In_  uint32_t                      next_hop_count,
    _In_  const sai_object_id_t         * nexthops)
{
    sai_status_t                        ret = SAI_STATUS_SUCCESS;
    ctc_sai_nexthop_entry_t             *pnh_entry      = NULL;
    ctc_sai_nexthop_group_list_node_t   *pnhgn_entry    = NULL;
    uint32_t                            i               = 0;

    for(i = 0; i < next_hop_count; i++)
    {
        if(!__lookup_nexthopnode(pnhg_entry,nexthops[i]))
        {
            pnh_entry = ctc_nexthop_get_by_oid(nexthops[i]);
            if(NULL == pnh_entry)
            {
                ret = SAI_STATUS_ITEM_NOT_FOUND;
                goto out;
            }
            pnhgn_entry = mem_malloc(MEM_APP_NEXTHOP_GRP_MODULE,sizeof(ctc_sai_nexthop_group_list_node_t));
            if(!pnhgn_entry)
            {
                ret = SAI_STATUS_NO_MEMORY;
                goto out;
            }
            pnhgn_entry->pnh_entry = pnh_entry;
            ret = ctc_nexthop_group_add_member(pnhg_entry, pnh_entry);
            ctc_list_pointer_insert_head(&pnhg_entry->nh_list_head,&pnhgn_entry->node);
        }
    }

out:
    return ret;
}

sai_status_t
ctc_nexthop_group_remove_nexthop(
    _In_  ctc_sai_nexthop_group_entry_t *pnhg_entry,
    _In_  uint32_t                      next_hop_count,
    _In_  const sai_object_id_t         *nexthops)
{
    sai_status_t                        ret         = SAI_STATUS_SUCCESS;
    ctc_sai_nexthop_group_list_node_t*  pnhgn_entry = NULL;
    uint32_t                            i           = 0;

    for(i = 0; i < next_hop_count; i++)
    {
        pnhgn_entry = __lookup_nexthopnode(pnhg_entry,nexthops[i]);
        if(pnhgn_entry)
        {
            ret = ctc_nexthop_group_remove_member(pnhg_entry,pnhgn_entry->pnh_entry);
            pnhgn_entry->pnh_entry = NULL;
            ctc_list_pointer_delete(&pnhg_entry->nh_list_head,&pnhgn_entry->node);
            mem_free(pnhgn_entry);
        }
    }

    return ret;
}

static int32_t
__vec_traversal_update_nh(
    _In_  void  *array_data,
    _In_  void  *user_data)
{
    ctc_sai_nexthop_entry_t             *pnh_entry      = NULL;
    ctc_sai_nexthop_group_entry_t       *pnhg_entry     = NULL;
    ctc_sai_nexthop_group_list_node_t   *pnhgn_entry    = NULL;

    pnhg_entry = (ctc_sai_nexthop_group_entry_t*)array_data;
    pnh_entry  = (ctc_sai_nexthop_entry_t*)user_data;

    pnhgn_entry = __lookup_nexthopnode(pnhg_entry,pnh_entry->nh_id);
    if(pnhgn_entry)
    {
        ctc_nexthop_group_remove_member(pnhg_entry,pnh_entry);
        ctc_nexthop_group_add_member(pnhg_entry,pnhgn_entry->pnh_entry);
        return -1;
    }

    return 0;
}


static int32_t
ctc_nexthop_notifier_callback(
    _In_  struct ctc_sai_notifier_block *nb,
    _In_  uint32_t action,
    _In_  void *data)
{

    switch(action)
    {
        case CTC_SAI_NEXTHOP_UPDATE_EVENT:
            ctc_vector_traverse(g_sai_nhg_info.pvector,__vec_traversal_update_nh,data);
            break;
        default :
            return CTC_SAI_NOTIFY_OK;
    }

    return CTC_SAI_NOTIFY_OK;
}

static struct ctc_sai_notifier_block nhg_nexthop_notifier_cb = {
    .notifier_call = ctc_nexthop_notifier_callback,
};

sai_status_t
ctc_nexthop_group_db_init()
{
    sai_status_t    ret         = SAI_STATUS_SUCCESS;
    g_sai_nhg_info.max_count    = CTC_SAI_NEXTHOP_GROUP_MAX_ENTRY;
    g_sai_nhg_info.pvector      =
        ctc_vector_init(CTC_VEC_BLOCK_NUM(g_sai_nhg_info.max_count,
                CTC_SAI_NEXTHOP_GROUP_BLOCK_SIZE),
            CTC_SAI_NEXTHOP_GROUP_BLOCK_SIZE);

    if(NULL == g_sai_nhg_info.pvector)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }

    CTC_SAI_ERROR_GOTO(
        ctc_opf_init(CTC_OPF_SAI_NEXTHOP_GROUP_ID,1), ret, out);

    g_sai_nhg_info.opf.pool_type = CTC_OPF_SAI_NEXTHOP_GROUP_ID;
    g_sai_nhg_info.opf.pool_index = 0;

    CTC_SAI_ERROR_GOTO(
        ctc_opf_init_offset(&g_sai_nhg_info.opf, CTC_SAI_NH_GROUP_OFFSET, g_sai_nhg_info.max_count),
        ret,out);

    sal_memset(g_sai_nh_group_id_info, 0, sizeof(g_sai_nh_group_id_info));
    ctc_sai_nexthop_evnet_notifier_register(&nhg_nexthop_notifier_cb);

out:
    return ret;
}


sai_status_t
ctc_nhg_sai_attr_alloc_attr_entry_list(const ctc_sai_attr_entry_info_t const *attr_info_entries,
                                 const sai_attribute_t *attr_list,
                                 uint32_t attr_count,
                                 _Out_ ctc_sai_attr_entry_list_t **pattr_entry_list)
{
    uint32_t attr_info_count = 0;
    uint32_t attr_idx        = 0;
    ctc_sai_attr_entry_list_t *psai_attr_entry_list = NULL;
    sai_object_id_t* list = NULL;

    CTC_SAI_PTR_VALID_CHECK(attr_info_entries);
    CTC_SAI_PTR_VALID_CHECK(pattr_entry_list);

    while(attr_info_entries[attr_info_count].id != SAI_ATTR_ID_END)
        attr_info_count++;

    if(0 == attr_info_count)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }

    psai_attr_entry_list = mem_malloc(MEM_APP_NEXTHOP_GRP_MODULE,sizeof(ctc_sai_attr_entry_list_t) * attr_info_count);
    *pattr_entry_list = psai_attr_entry_list;

    if(!psai_attr_entry_list )
    {
        return SAI_STATUS_NO_MEMORY;
    }

    sal_memset(psai_attr_entry_list,0,sizeof(ctc_sai_attr_entry_list_t) * attr_info_count);

    for(attr_idx = 0; attr_list && attr_idx < attr_count; attr_idx++)
    {
        if(attr_list[attr_idx].id >= attr_info_count)
        {
            return SAI_STATUS_UNKNOWN_ATTRIBUTE_0 + attr_idx;
        }
        if(attr_list[attr_idx].id == SAI_NEXT_HOP_GROUP_ATTR_NEXT_HOP_LIST)
        {
            list = mem_malloc(MEM_APP_NEXTHOP_GRP_MODULE,sizeof(sai_object_id_t) * CTC_SAI_NHG_ATTR_LIST_MAX);
            sal_memset(list,0,sizeof(sai_object_id_t) * CTC_SAI_NHG_ATTR_LIST_MAX);
            psai_attr_entry_list[attr_list[attr_idx].id].value.objlist.list = list;
            psai_attr_entry_list[attr_list[attr_idx].id].value.objlist.count = attr_list[attr_idx].value.objlist.count;
            sal_memcpy(list, attr_list[attr_idx].value.objlist.list, attr_list[attr_idx].value.objlist.count*(sizeof(sai_object_id_t)));
        }
        else
        {
            psai_attr_entry_list[attr_list[attr_idx].id].value = attr_list[attr_idx].value;
        }
        psai_attr_entry_list[attr_list[attr_idx].id].attr_index = attr_idx;
        psai_attr_entry_list[attr_list[attr_idx].id].valid = true;
    }

    attr_idx = 0;
    while(attr_info_entries[attr_idx].id != SAI_ATTR_ID_END)
    {
        if(SAI_ATTR_FLAG_DEFAULT == (SAI_ATTR_FLAG_DEFAULT &attr_info_entries[attr_idx].type))
        {
            if(false == psai_attr_entry_list[attr_idx].valid)
            {
                psai_attr_entry_list[attr_idx].value =
                    attr_info_entries[attr_idx].default_value;
                psai_attr_entry_list[attr_idx].valid = true;
            }
        }
        attr_idx++;
    }

    *pattr_entry_list = psai_attr_entry_list;

    return SAI_STATUS_SUCCESS;
}


#define ________SAI_SAI_INNER_DEBUG_FUNC
sai_status_t
ctc_sai_create_next_hop_group_debug_param(
    _Out_ sai_object_id_t* next_hop_group_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    CTC_SAI_DEBUG("out:next_hop_group_id 0x%llx", (*next_hop_group_id));
    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_remove_next_hop_group_debug_param(
    _In_ sai_object_id_t next_hop_group_id)
{
    CTC_SAI_DEBUG("in:next_hop_group_id 0x%llx", next_hop_group_id);
    return SAI_STATUS_SUCCESS;
}
sai_status_t
ctc_sai_add_next_hop_to_group_debug_param(
    _In_ sai_object_id_t next_hop_group_id,
    _In_ uint32_t next_hop_count,
    _In_ const sai_object_id_t* nexthops)
{
    CTC_SAI_DEBUG("in:next_hop_group_id 0x%llx next_hop_count %u", next_hop_group_id, next_hop_count);
    return SAI_STATUS_SUCCESS;
}
sai_status_t
ctc_sai_remove_next_hop_from_group_debug_param(
    _In_ sai_object_id_t next_hop_group_id,
    _In_ uint32_t next_hop_count,
    _In_ const sai_object_id_t* nexthops)
{
    CTC_SAI_DEBUG("in:next_hop_group_id 0x%llx next_hop_count %u", next_hop_group_id, next_hop_count);
    return SAI_STATUS_SUCCESS;
}
#define ________SAI_SAI_INNER_API_FUNC

/*
* Routine Description:
*    Create next hop group
*
* Arguments:
*    [out] next_hop_group_id - next hop group id
*    [in] attr_count - number of attributes
*    [in] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_create_next_hop_group(
    _Out_ sai_object_id_t* next_hop_group_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    sai_status_t                    ret               = SAI_STATUS_SUCCESS;
    ctc_sai_attr_entry_list_t       *pattr_entry_list = NULL;
    ctc_sai_nexthop_group_entry_t   *pnhg_entry       = NULL;
    uint32_t attr_idx        = 0;

    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_PTR_VALID_CHECK(next_hop_group_id);
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    CTC_SAI_ERROR_GOTO(ctc_nhg_sai_attr_alloc_attr_entry_list(g_sai_attr_entries,
                            attr_list,
                            attr_count,
                            &pattr_entry_list),ret,out);

    CTC_SAI_ERROR_GOTO(ctc_sai_attr_check_attr_entry_list(g_sai_attr_entries,
                            pattr_entry_list),ret,out);

    CTC_SAI_ERROR_GOTO(ctc_nexthop_group_alloc(&pnhg_entry), ret, out);
    if(pattr_entry_list[SAI_NEXT_HOP_GROUP_ATTR_TYPE].valid)
    {
        pnhg_entry->nhg_type = pattr_entry_list[SAI_NEXT_HOP_GROUP_ATTR_TYPE].value.s32;
    }


    CTC_SAI_ERROR_GOTO(
        ctc_nexthop_group_add_entry(&pnhg_entry,
                &pattr_entry_list[SAI_NEXT_HOP_GROUP_ATTR_NEXT_HOP_LIST].value.objlist),
                ret,out1);

    *next_hop_group_id = pnhg_entry->nhg_id;
    ctc_sai_create_next_hop_group_debug_param(next_hop_group_id, attr_count, attr_list);

out:
    if(pattr_entry_list)
    {
        for(attr_idx = 0; attr_list && attr_idx < attr_count; attr_idx++)
        {
            if(attr_list[attr_idx].id == SAI_NEXT_HOP_GROUP_ATTR_NEXT_HOP_LIST)
            {
                mem_free(pattr_entry_list[attr_list[attr_idx].id].value.objlist.list);
            }
        }

        ctc_sai_attr_free_attr_entry_list(pattr_entry_list);
    }

    return ret;

out1:

    if(pnhg_entry)
    {
        ctc_nexthop_group_release(pnhg_entry);
    }

    goto out;
}

/*
* Routine Description:
*    Remove next hop group
*
* Arguments:
*    [in] next_hop_group_id - next hop group id
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_remove_next_hop_group(
    _In_ sai_object_id_t next_hop_group_id)
{
    sai_status_t                    ret         = SAI_STATUS_SUCCESS;
    ctc_sai_nexthop_group_entry_t   *pnhg_entry = NULL;

    CTC_SAI_DEBUG_FUNC();
    ctc_sai_remove_next_hop_group_debug_param(next_hop_group_id);

    pnhg_entry = ctc_nexthop_group_get_by_oid_no_ref(next_hop_group_id);
    if (NULL == pnhg_entry)
    {
        ret = SAI_STATUS_ITEM_NOT_FOUND;
        goto out;
    }

    if(1 < pnhg_entry->ref)
    {
        refcnt_dec(pnhg_entry);
        goto out;
    }

    CTC_SAI_ERROR_GOTO(ctc_sai_nexthop_group_db_remove_entry(pnhg_entry),ret,out);

    ctc_nexthop_group_release(pnhg_entry);

out:
    return ret;
}

/*
* Routine Description:
*    Set Next Hop Group attribute
*
* Arguments:
*    [in] sai_object_id_t - next_hop_group_id
*    [in] attr - attribute
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_set_next_hop_group_attribute(
    _In_ sai_object_id_t next_hop_group_id,
    _In_ const sai_attribute_t *attr)
{
    CTC_SAI_DEBUG_FUNC();

    return SAI_STATUS_SUCCESS;
}


/*
* Routine Description:
*    Get Next Hop Group attribute
*
* Arguments:
*    [in] sai_object_id_t - next_hop_group_id
*    [in] attr_count - number of attributes
*    [inout] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_get_next_hop_group_attribute(
    _In_ sai_object_id_t next_hop_group_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{
    CTC_SAI_DEBUG_FUNC();

    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*    Add next hop to a group
*
* Arguments:
*    [in] next_hop_group_id - next hop group id
*    [in] next_hop_count - number of next hops
*    [in] nexthops - array of next hops
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_add_next_hop_to_group(
    _In_ sai_object_id_t next_hop_group_id,
    _In_ uint32_t next_hop_count,
    _In_ const sai_object_id_t* nexthops)
{
    sai_status_t                    ret = SAI_STATUS_SUCCESS;
    ctc_sai_nexthop_group_entry_t   *pnhg_entry = NULL;

    CTC_SAI_DEBUG_FUNC();
    ctc_sai_add_next_hop_to_group_debug_param(next_hop_group_id, next_hop_count, nexthops);

    pnhg_entry = ctc_nexthop_group_get_by_oid(next_hop_group_id);
    if(NULL == pnhg_entry)
    {
        ret = SAI_STATUS_ITEM_NOT_FOUND;
        goto out;
    }

    ret = ctc_nexthop_group_add_nexthop(pnhg_entry, next_hop_count, nexthops);

out:
    if(pnhg_entry)
    {
        ctc_nexthop_group_release(pnhg_entry);
    }
    return ret;
}


/*
* Routine Description:
*    Remove next hop from a group
*
* Arguments:
*    [in] next_hop_group_id - next hop group id
*    [in] next_hop_count - number of next hops
*    [in] nexthops - array of next hops
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_remove_next_hop_from_group(
    _In_ sai_object_id_t next_hop_group_id,
    _In_ uint32_t next_hop_count,
    _In_ const sai_object_id_t* nexthops)
{
    sai_status_t                    ret = SAI_STATUS_SUCCESS;
    ctc_sai_nexthop_group_entry_t   *pnhg_entry = NULL;

    CTC_SAI_DEBUG_FUNC();
    ctc_sai_remove_next_hop_from_group_debug_param(next_hop_group_id, next_hop_count, nexthops);

    pnhg_entry = ctc_nexthop_group_get_by_oid_no_ref(next_hop_group_id);
    if(NULL == pnhg_entry)
    {
        ret = SAI_STATUS_ITEM_NOT_FOUND;
        return ret;
    }

    ret = ctc_nexthop_group_remove_nexthop(pnhg_entry,next_hop_count,nexthops);

    return ret;
}


#define ________SAI_SAI_INNER_API_FUNC
static sai_status_t
__init_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    CTC_SAI_ERROR_GOTO(ctc_nexthop_group_db_init(),ret,out);

    preg->init_status =  INITIALIZED;

out:
    return ret;
}

static sai_status_t
__exit_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}

#define ________SAI_SAI_API_FUNC
/* define sai 0.9.2 */
static sai_next_hop_group_api_t      g_sai_api_func = {
    .create_next_hop_group          = ctc_sai_create_next_hop_group,
    .remove_next_hop_group          = ctc_sai_remove_next_hop_group,
    .set_next_hop_group_attribute   = ctc_sai_set_next_hop_group_attribute,
    .get_next_hop_group_attribute   = ctc_sai_get_next_hop_group_attribute,
    .add_next_hop_to_group          = ctc_sai_add_next_hop_to_group,
    .remove_next_hop_from_group     = ctc_sai_remove_next_hop_from_group,
};

static ctc_sai_api_reg_info_t g_api_reg_info = {
        .id             = SAI_API_NEXT_HOP_GROUP,
        .init_func      = __init_mode_fn,
        .exit_func      = __exit_mode_fn,
        .api_method_table = &g_sai_api_func,
        .private_data     = NULL,
};

#define ________SAI_OUTER_FUNC
sai_status_t
ctc_sai_nexthop_group_init()
{
    api_reg_register_fn(&g_api_reg_info);

    return SAI_STATUS_SUCCESS;
}

#if !defined (__CTC_SAI_COPP_H_)
#define __CTC_SAI_COPP_H_

#include <sai.h>

#define SAI_COPP_PORT_ID 1

#define SAI_COPP_REASON_PORT_ID 2
#define SAI_COPP_FWD_PORT_ID 3
#define SAI_COPP_HYBIRD_PORT_ID 4
#define SAI_COPP_PORT_ID_MAX 5
#define SAI_COPP_REASON_MAX_COUNT  1024  //same to CTC_PKT_CPU_REASON_MAX_COUNT

typedef struct ctc_sai_copp_reason_s
{
    uint32   reason_id;
    sai_object_id_t   nexthop_oid;
    sai_object_id_t   counter_oid;
    sai_object_id_t   policer_oid;
    sai_object_id_t   acl_entry_oid[8];
} ctc_sai_copp_reason_t;

typedef struct ctc_sai_copp_port_info_s
{
    uint16   port_id;
    uint32   nexthop_id;

} ctc_sai_copp_port_info_t;

typedef struct ctc_sai_copp_info_s
{
    ctc_sai_copp_reason_t ctc_reason[SAI_COPP_REASON_MAX_COUNT];  
    ctc_sai_copp_port_info_t ctc_copp_port_info[SAI_COPP_PORT_ID_MAX];
    sai_object_id_t   ctc_copp_igs_tbl_oid;

}ctc_sai_copp_info_t;

sai_status_t
ctc_sai_copp_init();
uint32
ctc_sai_copp_get_fwd_port();
int32 
ctc_sai_copp_get_acl_oid_from_reason(uint32 reason_id, sai_object_id_t* acl_oid);
int32 
ctc_sai_copp_get_counter_oid_from_reason(uint32 reason_id, sai_object_id_t* counter_oid);

#endif


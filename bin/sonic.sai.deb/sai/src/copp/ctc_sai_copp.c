#include <sal.h>
#include "ctc_api.h"
#include "sal_error.h"
#include <sai.h>
#include <saitypes.h>
#include <saistatus.h>
#include <saicopp.h>
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_sai.h>
#include <ctc_sai_port.h>
#include <ctc_sai_debug.h>
#include <ctc_sai_copp.h>
#include <ctc_sai_hostif.h>
#include <ctc_sai_nexthop.h>
#include <ctc_sai_scheduler.h>
#include <ctc_sai_acl.h>

ctc_sai_copp_info_t g_sai_copp_master;

uint32
ctc_sai_copp_get_fwd_port()
{
    return g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].port_id;
}

uint32
ctc_sai_copp_get_reason_port()
{
    return g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].port_id;
}

int32
ctc_sai_copp_tbl_init()
{
    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr_list[12];
    sai_object_id_t acl_table_id = 0;

    CTC_SAI_DEBUG_FUNC();
    sai_api_query(SAI_API_ACL,(void**)&acl_api);

    /* ingress copp ACL table created */
    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[0].id = SAI_ACL_TABLE_ATTR_STAGE;
    attr_list[0].value.s32 = SAI_ACL_STAGE_INGRESS;

    attr_list[1].id = SAI_ACL_TABLE_ATTR_PRIORITY;
#ifdef GREATBELT
    attr_list[1].value.u32 = 0x1;
#else
    attr_list[1].value.u32 = 0x2;
#endif
    attr_list[2].id = SAI_ACL_TABLE_ATTR_FIELD_SRC_MAC;
    attr_list[2].value.booldata = TRUE;

    attr_list[3].id = SAI_ACL_TABLE_ATTR_FIELD_DST_MAC;
    attr_list[3].value.booldata = TRUE;

    attr_list[4].id = SAI_ACL_TABLE_ATTR_FIELD_SRC_IP;
    attr_list[4].value.booldata = TRUE;

    attr_list[5].id = SAI_ACL_TABLE_ATTR_FIELD_DST_IP;
    attr_list[5].value.booldata = TRUE;

    attr_list[6].id = SAI_ACL_TABLE_ATTR_FIELD_IN_PORT;
    attr_list[6].value.booldata = TRUE;

    attr_list[7].id = SAI_ACL_TABLE_ATTR_FIELD_OUTER_VLAN_ID;
    attr_list[7].value.booldata = TRUE;

    attr_list[8].id = SAI_ACL_TABLE_ATTR_FIELD_L4_SRC_PORT;
    attr_list[8].value.booldata = TRUE;

    attr_list[9].id = SAI_ACL_TABLE_ATTR_FIELD_L4_DST_PORT;
    attr_list[9].value.booldata = TRUE;

    attr_list[10].id = SAI_ACL_TABLE_ATTR_FIELD_ETHER_TYPE;
    attr_list[10].value.booldata = TRUE;

    attr_list[11].id = SAI_ACL_TABLE_ATTR_FIELD_IP_PROTOCOL;
    attr_list[11].value.booldata = TRUE;
    CTC_ERROR_RETURN(acl_api->create_acl_table(&acl_table_id, 12, attr_list));
    g_sai_copp_master.ctc_copp_igs_tbl_oid = acl_table_id;

    return SAI_STATUS_SUCCESS;

}

/*Note, return acl oids for this reason, user must alloc oid[4]*/
int32 
ctc_sai_copp_get_acl_oid_from_reason(uint32 reason_id, sai_object_id_t* acl_oid)
{

    if(reason_id > CTC_PKT_CPU_REASON_CUSTOM_BASE + 1)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }
    acl_oid[0] = g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[0];
    acl_oid[1] = g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[1];
    acl_oid[2] = g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[2];
    acl_oid[3] = g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[3];

    return SAI_STATUS_SUCCESS;
}

int32 
ctc_sai_copp_get_counter_oid_from_reason(uint32 reason_id, sai_object_id_t* counter_oid)
{

    if(reason_id > CTC_PKT_CPU_REASON_CUSTOM_BASE)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }
    
    *counter_oid  = g_sai_copp_master.ctc_reason[reason_id].counter_oid;
    return SAI_STATUS_SUCCESS;
}

/*Add ACE entry for ARP packet */
/*Key is Ether type = 0x0806*/
int32
ctc_sai_copp_add_acl_entry_for_reason_arp(sai_object_id_t nh_oid,  
                      sai_object_id_t* acl_entry_oid, sai_object_id_t* counter_oid)
{
    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr_list[36];
    uint32 attr_count = 0;
    uint16 ether_type_mask = 0x0;
    uint16 ether_type = 0x0806;
    sai_object_id_t acl_counter_id = 0;
    sai_attribute_t counter_attr;
    sai_object_id_t acl_entry_id = 0;

    CTC_SAI_DEBUG_FUNC();
    sai_api_query(SAI_API_ACL,(void**)&acl_api);

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid; /*COPP_IGS_ACL_TBLID*/;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;


    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_ETHER_TYPE;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.u16 = ether_type;
    attr_list[attr_count].value.aclfield.mask.u16 = ether_type_mask;
    attr_count++;

    /* create counter id */
    counter_attr.id = SAI_ACL_COUNTER_ATTR_TABLE_ID;
    counter_attr.value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid; /*global GLB_IGS_ACL_TBLID defined*/
    acl_api->create_acl_counter(&acl_counter_id, 1, &counter_attr);

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;


    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id, attr_count, attr_list));
    *acl_entry_oid = acl_entry_id;
    *counter_oid = acl_counter_id;

    return SAI_STATUS_SUCCESS;
}

/*Add ACE entry for OSPF packet */
/*Key is IPv4 or IPv6, layer3 protocol = 89*/
int32
ctc_sai_copp_add_acl_entry_for_reason_ospf(sai_object_id_t nh_oid, 
                            sai_object_id_t* acl_entry_oid, sai_object_id_t* counter_oid)
{
    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr_list[36];
    uint32 attr_count = 0;
    uint8 l3_protocol_mask = 0x0;
    uint8 l3_protocol = 89;
    sai_object_id_t acl_counter_id = 0;
    sai_attribute_t counter_attr;
    sai_object_id_t acl_entry_id = 0;

    CTC_SAI_DEBUG_FUNC();
    sai_api_query(SAI_API_ACL,(void**)&acl_api);

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IP_PROTOCOL;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.u8 = l3_protocol;
    attr_list[attr_count].value.aclfield.mask.u8 = l3_protocol_mask;
    attr_count++;

    /* create counter id */
    counter_attr.id = SAI_ACL_COUNTER_ATTR_TABLE_ID;
    counter_attr.value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid; /*global GLB_IGS_ACL_TBLID defined*/
    acl_api->create_acl_counter(&acl_counter_id, 1, &counter_attr);

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id, attr_count, attr_list));
    *acl_entry_oid = acl_entry_id;
    *counter_oid = acl_counter_id;

    return SAI_STATUS_SUCCESS;
}

/*Add ACE entry for PIM packet */
/*Key is IPv4 or IPv6, layer3 protocol = 103*/
int32
ctc_sai_copp_add_acl_entry_for_reason_pim(sai_object_id_t nh_oid,
                      sai_object_id_t* acl_entry_oid, sai_object_id_t* counter_oid)
{
    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr_list[36];
    uint32 attr_count = 0;
    uint8 l3_protocol_mask = 0x0;
    uint8 l3_protocol = 103;
    sai_object_id_t acl_counter_id = 0;
    sai_attribute_t counter_attr;
    sai_object_id_t acl_entry_id = 0;

    CTC_SAI_DEBUG_FUNC();
    sai_api_query(SAI_API_ACL,(void**)&acl_api);

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IP_PROTOCOL;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.u8 = l3_protocol;
    attr_list[attr_count].value.aclfield.mask.u8 = l3_protocol_mask;
    attr_count++;

    /* create counter id */
    counter_attr.id = SAI_ACL_COUNTER_ATTR_TABLE_ID;
    counter_attr.value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid; /*global GLB_IGS_ACL_TBLID defined*/
    acl_api->create_acl_counter(&acl_counter_id, 1, &counter_attr);

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id, attr_count, attr_list));
    *acl_entry_oid = acl_entry_id;
    *counter_oid = acl_counter_id;

    return SAI_STATUS_SUCCESS;
}

/*Add ACE entry for VRRP packet */
/*Key is IPv4 or IPv6, layer3 protocol = 112*/
int32
ctc_sai_copp_add_acl_entry_for_reason_vrrp(sai_object_id_t nh_oid, 
                    sai_object_id_t* acl_entry_oid, sai_object_id_t* counter_oid)
{
    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr_list[36];
    uint32 attr_count = 0;
    uint8 l3_protocol_mask = 0x0;
    uint8 l3_protocol = 112;
    sai_object_id_t acl_counter_id = 0;
    sai_attribute_t counter_attr;
    sai_object_id_t acl_entry_id = 0;

    CTC_SAI_DEBUG_FUNC();
    sai_api_query(SAI_API_ACL,(void**)&acl_api);

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IP_PROTOCOL;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.u8 = l3_protocol;
    attr_list[attr_count].value.aclfield.mask.u8 = l3_protocol_mask;
    attr_count++;

    /* create counter id */
    counter_attr.id = SAI_ACL_COUNTER_ATTR_TABLE_ID;
    counter_attr.value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    acl_api->create_acl_counter(&acl_counter_id, 1, &counter_attr);

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id, attr_count, attr_list));
    *acl_entry_oid = acl_entry_id;
    *counter_oid = acl_counter_id;

    return SAI_STATUS_SUCCESS;
}

/*Add ACE entry for BGP packet */
/*Key is TCP , DestPort = 179*/
int32
ctc_sai_copp_add_acl_entry_for_reason_bgp(sai_object_id_t nh_oid, 
                        sai_object_id_t* acl_entry_oid, sai_object_id_t* counter_oid)
{
    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr_list[36];
    uint32 attr_count = 0;
    uint16 dest_port = 179;
    uint8 ip_protocol = 6;
    uint8 ip_protocol_mask = 0x0;
    sai_object_id_t acl_counter_id = 0;
    sai_attribute_t counter_attr;
    sai_object_id_t acl_entry_id = 0;

    CTC_SAI_DEBUG_FUNC();
    sai_api_query(SAI_API_ACL,(void**)&acl_api);

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IP_PROTOCOL;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.u8 = ip_protocol;
    attr_list[attr_count].value.aclfield.mask.u8 = ip_protocol_mask;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_L4_DST_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.u16 = dest_port;
    attr_list[attr_count].value.aclfield.mask.u16 = dest_port;
    attr_count++;

    /* create counter id */
    counter_attr.id = SAI_ACL_COUNTER_ATTR_TABLE_ID;
    counter_attr.value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    acl_api->create_acl_counter(&acl_counter_id, 1, &counter_attr);

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;
    
    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id, attr_count, attr_list));
    *acl_entry_oid = acl_entry_id;
    *counter_oid = acl_counter_id;
    
    return SAI_STATUS_SUCCESS;
}


/*Add ACE entry for DHCP packet */
/*Key is IPv4 UDP l4DestPort = 67 or 68, IPv6 UDP l4DestPort = 546 or 547*/
int32
ctc_sai_copp_add_acl_entry_for_reason_dhcp(sai_object_id_t nh_oid,
                         sai_object_id_t* acl_entry_oid, sai_object_id_t* counter_oid)
{
    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr_list[36];
    uint32 attr_count = 0;
    uint16 dest_port = 67;
    uint16 dest_port1 = 68;
    uint8 ip_protocol = 17;
    uint8 ip_protocol_mask = 0x0;
    sai_object_id_t acl_counter_id = 0;
    sai_attribute_t counter_attr;
    sai_object_id_t acl_entry_id[2];

    CTC_SAI_DEBUG_FUNC();
    sai_api_query(SAI_API_ACL,(void**)&acl_api);

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;

    /* create counter id */
    counter_attr.id = SAI_ACL_COUNTER_ATTR_TABLE_ID;
    counter_attr.value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    acl_api->create_acl_counter(&acl_counter_id, 1, &counter_attr);

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IP_PROTOCOL;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.u8 = ip_protocol;
    attr_list[attr_count].value.aclfield.mask.u8 = ip_protocol_mask;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_L4_DST_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.u16 = dest_port;
    attr_list[attr_count].value.aclfield.mask.u16 = dest_port;
    attr_count++;

    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id[0], attr_count, attr_list));

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IP_PROTOCOL;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.u8 = ip_protocol;
    attr_list[attr_count].value.aclfield.mask.u8 = ip_protocol_mask;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_L4_DST_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.u16 = dest_port1;
    attr_list[attr_count].value.aclfield.mask.u16 = dest_port1;
    attr_count++;

    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id[1], attr_count, attr_list));
    
    *acl_entry_oid = acl_entry_id[0];
    *(acl_entry_oid+1) = acl_entry_id[1];
    *counter_oid = acl_counter_id;

    return SAI_STATUS_SUCCESS;
}

/*Add ACE entry for IGMP packet , ip protocol = 2*/
/*Key is ip daΪD�ࣺ1110+28λ���⣬��224.0.0.0-239.255.255.255��ΪĿ�ĵ�ַ��ip����*/
/*
SAI_HOSTIF_TRAP_ID_IGMP_TYPE_QUERY
SAI_HOSTIF_TRAP_ID_IGMP_TYPE_LEAVE
SAI_HOSTIF_TRAP_ID_IGMP_TYPE_V1_REPORT
SAI_HOSTIF_TRAP_ID_IGMP_TYPE_V2_REPORT
SAI_HOSTIF_TRAP_ID_IGMP_TYPE_V3_REPORT
*/
/*Noet, this function return 4 acl_entry_oid, user need alloc acl_entry_oid[4]*/
int32
ctc_sai_copp_add_acl_entry_for_reason_igmp(sai_object_id_t nh_oid,
                         sai_object_id_t* acl_entry_oid, sai_object_id_t* counter_oid)
{
    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr_list[36];
    uint32 attr_count = 0;
    uint8 ip_protocol = 2;
    uint8 ip_protocol_mask = 0x0;
    sai_object_id_t acl_counter_id = 0;
    sai_attribute_t counter_attr;
    sai_object_id_t acl_entry_id[2];

    CTC_SAI_DEBUG_FUNC();
    sai_api_query(SAI_API_ACL,(void**)&acl_api);

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;

    /* create counter id */
    counter_attr.id = SAI_ACL_COUNTER_ATTR_TABLE_ID;
    counter_attr.value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    acl_api->create_acl_counter(&acl_counter_id, 1, &counter_attr);

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IP_PROTOCOL;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.u8 = ip_protocol;
    attr_list[attr_count].value.aclfield.mask.u8 = ip_protocol_mask;
    attr_count++;

    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id[0], attr_count, attr_list));
    *acl_entry_oid = acl_entry_id[0];
    *counter_oid = acl_counter_id;

    return SAI_STATUS_SUCCESS;
}


/*Add ACE entry for BPDU packet */
/*Key is Macda = 01:80:c2:00:00:00*/
/*Key is MacdaMask = ff:ff:ff:ff:ff:c0*/
int32
ctc_sai_copp_add_acl_entry_for_reason_bpdu(sai_object_id_t nh_oid,
                        sai_object_id_t* acl_entry_oid, sai_object_id_t* counter_oid)
{
    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr_list[36];
    uint32 attr_count = 0;
    mac_addr_t dmac_mask = {0x0, 0x0, 0x0, 0x0, 0x0, 0x3F};
    mac_addr_t dmac = {0x01, 0x80, 0xC2, 0x00, 0x00, 0x00};
    sai_object_id_t acl_counter_id = 0;
    sai_attribute_t counter_attr;
    sai_object_id_t acl_entry_id = 0;

    CTC_SAI_DEBUG_FUNC();
    sai_api_query(SAI_API_ACL,(void**)&acl_api);

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;


    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_DST_MAC;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    sal_memcpy(attr_list[attr_count].value.aclfield.data.mac, &dmac, sizeof(mac_addr_t));
    sal_memcpy(attr_list[attr_count].value.aclfield.mask.mac, &dmac_mask, sizeof(mac_addr_t));
    attr_count++;

    /* create counter id */
    counter_attr.id = SAI_ACL_COUNTER_ATTR_TABLE_ID;
    counter_attr.value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    acl_api->create_acl_counter(&acl_counter_id, 1, &counter_attr);

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id, attr_count, attr_list));
    *acl_entry_oid = acl_entry_id;
    *counter_oid = acl_counter_id;

    return SAI_STATUS_SUCCESS;
}


/*Add ACE entry for EAPOL packet */
/*Key is Ether type = 0x888E*/
int32
ctc_sai_copp_add_acl_entry_for_reason_eapol(sai_object_id_t nh_oid,
                       sai_object_id_t* acl_entry_oid, sai_object_id_t* counter_oid)
{
    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr_list[36];
    uint32 attr_count = 0;
    uint16 ether_type_mask = 0x0;
    uint16 ether_type = 0x888E;
    sai_object_id_t acl_counter_id = 0;
    sai_attribute_t counter_attr;
    sai_object_id_t acl_entry_id = 0;

    CTC_SAI_DEBUG_FUNC();
    sai_api_query(SAI_API_ACL,(void**)&acl_api);

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;


    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_ETHER_TYPE;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.u16 = ether_type;
    attr_list[attr_count].value.aclfield.mask.u16 = ether_type_mask;
    attr_count++;

    /* create counter id */
    counter_attr.id = SAI_ACL_COUNTER_ATTR_TABLE_ID;
    counter_attr.value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    acl_api->create_acl_counter(&acl_counter_id, 1, &counter_attr);

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id, attr_count, attr_list));
    *acl_entry_oid = acl_entry_id;
    *counter_oid = acl_counter_id;
    
    return SAI_STATUS_SUCCESS;
}

/*Add ACE entry for LLDP packet */
/*Key is Ether type = 0x88CC*/
int32
ctc_sai_copp_add_acl_entry_for_reason_lldp(sai_object_id_t nh_oid,
                      sai_object_id_t* acl_entry_oid, sai_object_id_t* counter_oid)
{
    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr_list[36];
    uint32 attr_count = 0;
    uint16 ether_type_mask = 0x0;
    uint16 ether_type = 0x88CC;
    sai_object_id_t acl_counter_id = 0;
    sai_attribute_t counter_attr;
    sai_object_id_t acl_entry_id = 0;

    CTC_SAI_DEBUG_FUNC();
    sai_api_query(SAI_API_ACL,(void**)&acl_api);

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;


    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_ETHER_TYPE;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.u16 = ether_type;
    attr_list[attr_count].value.aclfield.mask.u16 = ether_type_mask;
    attr_count++;

    /* create counter id */
    counter_attr.id = SAI_ACL_COUNTER_ATTR_TABLE_ID;
    counter_attr.value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    acl_api->create_acl_counter(&acl_counter_id, 1, &counter_attr);

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id, attr_count, attr_list));
    *acl_entry_oid = acl_entry_id;
    *counter_oid = acl_counter_id;
    
    return SAI_STATUS_SUCCESS;
}

/*Add ACE entry for ERPS packet */
/*
mac, 0x01, 0x80, 0x63, 0x07, 0x00, 0x00
mac_mask, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
mac, 0x00, 0x01, 0x7A, 0x4F, 0x48, 0x26
mac_mask, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
h3c:
mac, 0x00, 0x0f, 0xe2, 0x07, 0x82, 0x00
mac_mask, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00
mac, 0x01, 0x80, 0x63, 0x07, 0x00, 0x00
mac_mask, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff
*/
/*Noet, this function return 4 acl_entry_oid, user need alloc acl_entry_oid[4]*/
int32
ctc_sai_copp_add_acl_entry_for_reason_erps(sai_object_id_t nh_oid,
                         sai_object_id_t* acl_entry_oid, sai_object_id_t* counter_oid)
{
    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr_list[36];
    uint32 attr_count = 0;
    mac_addr_t dmac_mask1 = {0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
    mac_addr_t dmac1 = {0x01, 0x80, 0x63, 0x07, 0x00, 0x00};

    mac_addr_t dmac_mask2 = {0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
    mac_addr_t dmac2 = {0x00, 0x01, 0x7A, 0x4F, 0x48, 0x26};

    mac_addr_t dmac_mask3 = {0x0, 0x0, 0x0, 0x0, 0x0, 0xFF};
    mac_addr_t dmac3 = {0x00, 0x0F,0xE2, 0x07, 0x82, 0x00};

    mac_addr_t dmac_mask4 = {0x0, 0x0, 0x0, 0x0, 0x0, 0x0};
    mac_addr_t dmac4 = {0x01, 0x80,0x63, 0x07, 0x00, 0x00};

    sai_object_id_t acl_counter_id = 0;
    sai_attribute_t counter_attr;
    sai_object_id_t acl_entry_id[4];

    CTC_SAI_DEBUG_FUNC();
    sai_api_query(SAI_API_ACL,(void**)&acl_api);

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;

    /* create counter id */
    counter_attr.id = SAI_ACL_COUNTER_ATTR_TABLE_ID;
    counter_attr.value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    acl_api->create_acl_counter(&acl_counter_id, 1, &counter_attr);

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_DST_MAC;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    sal_memcpy(attr_list[attr_count].value.aclfield.data.mac, &dmac1, sizeof(mac_addr_t));
    sal_memcpy(attr_list[attr_count].value.aclfield.mask.mac, &dmac_mask1, sizeof(mac_addr_t));
    attr_count++;
    
    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id[0], attr_count, attr_list));

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_DST_MAC;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    sal_memcpy(attr_list[attr_count].value.aclfield.data.mac, &dmac2, sizeof(mac_addr_t));
    sal_memcpy(attr_list[attr_count].value.aclfield.mask.mac, &dmac_mask2, sizeof(mac_addr_t));
    attr_count++;

    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id[1], attr_count, attr_list));

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_DST_MAC;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    sal_memcpy(attr_list[attr_count].value.aclfield.data.mac, &dmac3, sizeof(mac_addr_t));
    sal_memcpy(attr_list[attr_count].value.aclfield.mask.mac, &dmac_mask3, sizeof(mac_addr_t));
    attr_count++;

    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id[2], attr_count, attr_list));

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_DST_MAC;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    sal_memcpy(attr_list[attr_count].value.aclfield.data.mac, &dmac4, sizeof(mac_addr_t));
    sal_memcpy(attr_list[attr_count].value.aclfield.mask.mac, &dmac_mask4, sizeof(mac_addr_t));
    attr_count++;

    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id[3], attr_count, attr_list));
    
    *counter_oid = acl_counter_id;
    *acl_entry_oid = acl_entry_id[0];
    *(acl_entry_oid+1) = acl_entry_id[1];
    *(acl_entry_oid+2) = acl_entry_id[2];
    *(acl_entry_oid+3) = acl_entry_id[3];
    
    return SAI_STATUS_SUCCESS;
}


/*Add ACE entry for SFLOW packet */
/*Key is Ether type = 0x8809*/
int32
ctc_sai_copp_add_acl_entry_for_reason_slow_protocol(sai_object_id_t nh_oid,
                                     sai_object_id_t* acl_entry_oid, sai_object_id_t* counter_oid)
{
    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr_list[36];
    uint32 attr_count = 0;
    uint16 ether_type_mask = 0x0;
    uint16 ether_type = 0x8809;
    sai_object_id_t acl_counter_id = 0;
    sai_attribute_t counter_attr;
    sai_object_id_t acl_entry_id = 0;

    CTC_SAI_DEBUG_FUNC();
    sai_api_query(SAI_API_ACL,(void**)&acl_api);

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_REASON_PORT_ID);
    attr_count++;


    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_ETHER_TYPE;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.u16 = ether_type;
    attr_list[attr_count].value.aclfield.mask.u16 = ether_type_mask;
    attr_count++;

    /* create counter id */
    counter_attr.id = SAI_ACL_COUNTER_ATTR_TABLE_ID;
    counter_attr.value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid;
    acl_api->create_acl_counter(&acl_counter_id, 1, &counter_attr);

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id, attr_count, attr_list));
    *acl_entry_oid = acl_entry_id;
    *counter_oid = acl_counter_id;
    
    return SAI_STATUS_SUCCESS;
}

int32
ctc_sai_copp_add_acl_entry_for_fwd_to_cpu(sai_object_id_t nh_oid,   
                      sai_object_id_t* acl_entry_oid, sai_object_id_t* counter_oid)
{
    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr_list[36];
    uint32 attr_count = 0;
    sai_object_id_t acl_counter_id = 0;
    sai_attribute_t counter_attr;
    sai_object_id_t acl_entry_id = 0;

    CTC_SAI_DEBUG_FUNC();
    sai_api_query(SAI_API_ACL,(void**)&acl_api);

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid; /*COPP_IGS_ACL_TBLID*/;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_FWD_PORT_ID);
    attr_count++;

    /* create counter id */
    counter_attr.id = SAI_ACL_COUNTER_ATTR_TABLE_ID;
    counter_attr.value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid; /*global GLB_IGS_ACL_TBLID defined*/
    acl_api->create_acl_counter(&acl_counter_id, 1, &counter_attr);

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id, attr_count, attr_list));
    *acl_entry_oid = acl_entry_id;
    *counter_oid = acl_counter_id;

    return SAI_STATUS_SUCCESS;
}

int32
ctc_sai_copp_add_acl_entry_for_fwd_to_controller(sai_object_id_t nh_oid,   
                      sai_object_id_t* acl_entry_oid, sai_object_id_t* counter_oid)
{
    sai_acl_api_t *acl_api = NULL;
    sai_attribute_t attr_list[36];
    uint32 attr_count = 0;
    sai_object_id_t acl_counter_id = 0;
    sai_attribute_t counter_attr;
    sai_object_id_t acl_entry_id = 0;

    CTC_SAI_DEBUG_FUNC();
    sai_api_query(SAI_API_ACL,(void**)&acl_api);

    sal_memset(attr_list, 0, sizeof(attr_list));
    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_TABLE_ID;
    attr_list[attr_count].value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid; /*COPP_IGS_ACL_TBLID*/;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_PRIORITY;
    attr_list[attr_count].value.u32 = 0;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_FIELD_IN_PORT;
    attr_list[attr_count].value.aclfield.enable = TRUE;
    attr_list[attr_count].value.aclfield.data.oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_COPP,SAI_COPP_HYBIRD_PORT_ID);
    attr_count++;

    /* create counter id */
    counter_attr.id = SAI_ACL_COUNTER_ATTR_TABLE_ID;
    counter_attr.value.oid = g_sai_copp_master.ctc_copp_igs_tbl_oid; /*global GLB_IGS_ACL_TBLID defined*/
    acl_api->create_acl_counter(&acl_counter_id, 1, &counter_attr);

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_COUNTER;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = acl_counter_id;
    attr_count++;

    attr_list[attr_count].id = SAI_ACL_ENTRY_ATTR_ACTION_REDIRECT;
    attr_list[attr_count].value.aclaction.enable = TRUE;
    attr_list[attr_count].value.aclaction.parameter.oid = nh_oid;
    attr_count++;

    CTC_ERROR_RETURN(acl_api->create_acl_entry(&acl_entry_id, attr_count, attr_list));
    *acl_entry_oid = acl_entry_id;
    *counter_oid = acl_counter_id;

    return SAI_STATUS_SUCCESS;
}

uint32
ctc_sai_copp_get_nhid_for_controller(void)
{
    return g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].nexthop_id;
}

#ifndef GREATBELT
extern int32
sys_goldengate_internal_port_set_iloop_for_pkt_to_cpu(uint8 lchip, uint32 gport, uint8 enable);
#endif

int
ctc_sai_copp_internal_port_init()
{
    ctc_internal_port_assign_para_t alloc_iloop_port;
    ctc_loopback_nexthop_param_t alloc_iloop_nh;
    sai_uint32_t nexthopid;
#ifdef DUET2
/*TODO by yejl*/
#endif


#ifdef GOLDENGATE
    sal_memset(&alloc_iloop_port, 0, sizeof(alloc_iloop_port));
    alloc_iloop_port.type = CTC_INTERNAL_PORT_TYPE_ILOOP;
    CTC_ERROR_RETURN(ctc_alloc_internal_port(&alloc_iloop_port));
    g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].port_id = alloc_iloop_port.inter_port;
    sys_goldengate_internal_port_set_iloop_for_pkt_to_cpu(0, alloc_iloop_port.inter_port, 1);
    
    sal_memset(&alloc_iloop_nh, 0, sizeof(alloc_iloop_nh));
    CTC_ERROR_RETURN(ctc_sai_nexthop_alloc_offset(&nexthopid));
    alloc_iloop_nh.lpbk_lport = g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].port_id;
    CTC_ERROR_RETURN(ctc_nh_add_iloop(nexthopid, &alloc_iloop_nh));
    g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].nexthop_id = nexthopid;

    ctc_port_set_direction_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].port_id, CTC_PORT_DIR_PROP_ACL_EN, CTC_INGRESS, 0x5); /*tcam0 & tacm2*/
    ctc_port_set_direction_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].port_id, CTC_PORT_DIR_PROP_ACL_PORT_BITMAP_ID, CTC_INGRESS, SAI_COPP_REASON_PORT_ID);
    ctc_port_set_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].port_id, CTC_PORT_PROP_L3PDU_ARP_ACTION, CTC_PORT_ARP_ACTION_TYPE_FW);
    ctc_port_set_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].port_id, CTC_PORT_PROP_L3PDU_DHCP_ACTION, CTC_PORT_DHCP_ACTION_TYPE_FW);

    sal_memset(&alloc_iloop_port, 0, sizeof(alloc_iloop_port));
    alloc_iloop_port.type = CTC_INTERNAL_PORT_TYPE_ILOOP;
    CTC_ERROR_RETURN(ctc_alloc_internal_port(&alloc_iloop_port));
    g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].port_id = alloc_iloop_port.inter_port;
    sys_goldengate_internal_port_set_iloop_for_pkt_to_cpu(0, alloc_iloop_port.inter_port, 1);

    sal_memset(&alloc_iloop_nh, 0, sizeof(alloc_iloop_nh));
    CTC_ERROR_RETURN(ctc_sai_nexthop_alloc_offset(&nexthopid));
    alloc_iloop_nh.lpbk_lport = g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].port_id;
    CTC_ERROR_RETURN(ctc_nh_add_iloop(nexthopid, &alloc_iloop_nh));
    g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].nexthop_id = nexthopid;

    ctc_port_set_direction_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].port_id, CTC_PORT_DIR_PROP_ACL_EN, CTC_INGRESS, 0x5);
    ctc_port_set_direction_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].port_id, CTC_PORT_DIR_PROP_ACL_PORT_BITMAP_ID, CTC_INGRESS, SAI_COPP_FWD_PORT_ID);
    ctc_port_set_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].port_id, CTC_PORT_PROP_L3PDU_ARP_ACTION, CTC_PORT_ARP_ACTION_TYPE_FW);
    ctc_port_set_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].port_id, CTC_PORT_PROP_L3PDU_DHCP_ACTION, CTC_PORT_DHCP_ACTION_TYPE_FW);

    sal_memset(&alloc_iloop_port, 0, sizeof(alloc_iloop_port));
    alloc_iloop_port.type = CTC_INTERNAL_PORT_TYPE_ILOOP;
    CTC_ERROR_RETURN(ctc_alloc_internal_port(&alloc_iloop_port));
    g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].port_id = alloc_iloop_port.inter_port;
    sys_goldengate_internal_port_set_iloop_for_pkt_to_cpu(0, alloc_iloop_port.inter_port, 1);
    
    sal_memset(&alloc_iloop_nh, 0, sizeof(alloc_iloop_nh));
    CTC_ERROR_RETURN(ctc_sai_nexthop_alloc_offset(&nexthopid));
    alloc_iloop_nh.lpbk_lport = g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].port_id;
    CTC_ERROR_RETURN(ctc_nh_add_iloop(nexthopid, &alloc_iloop_nh));
    g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].nexthop_id = nexthopid;

    ctc_port_set_direction_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].port_id, CTC_PORT_DIR_PROP_ACL_EN, CTC_INGRESS, 0x5);
    ctc_port_set_direction_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].port_id, CTC_PORT_DIR_PROP_ACL_PORT_BITMAP_ID, CTC_INGRESS, SAI_COPP_HYBIRD_PORT_ID);
    ctc_port_set_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].port_id, CTC_PORT_PROP_L3PDU_ARP_ACTION, CTC_PORT_ARP_ACTION_TYPE_FW);
    ctc_port_set_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].port_id, CTC_PORT_PROP_L3PDU_DHCP_ACTION, CTC_PORT_DHCP_ACTION_TYPE_FW);
#endif

#ifdef GREATBELT

    sal_memset(&alloc_iloop_port, 0, sizeof(alloc_iloop_port));
    alloc_iloop_port.type = CTC_INTERNAL_PORT_TYPE_ILOOP;
    CTC_ERROR_RETURN(ctc_alloc_internal_port(&alloc_iloop_port));
    g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].port_id = alloc_iloop_port.inter_port;
    CTC_ERROR_RETURN(ctc_port_set_property(alloc_iloop_port.inter_port, CTC_PORT_PROP_CROSS_CONNECT_EN, CTC_NH_RESERVED_NHID_FOR_TOCPU));
    CTC_ERROR_RETURN(ctc_port_set_property(alloc_iloop_port.inter_port, CTC_PORT_PROP_ROUTE_EN, FALSE));
    CTC_ERROR_RETURN(ctc_port_set_bridge_en(alloc_iloop_port.inter_port, FALSE));
    CTC_ERROR_RETURN(ctc_port_set_port_en(alloc_iloop_port.inter_port, TRUE));
    CTC_ERROR_RETURN(ctc_port_set_default_vlan(alloc_iloop_port.inter_port, 0));
    CTC_ERROR_RETURN(ctc_port_set_learning_en(alloc_iloop_port.inter_port, FALSE));
    
    sal_memset(&alloc_iloop_nh, 0, sizeof(alloc_iloop_nh));
    CTC_ERROR_RETURN(ctc_sai_nexthop_alloc_offset(&nexthopid));
    alloc_iloop_nh.lpbk_lport = g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].port_id;
    CTC_ERROR_RETURN(ctc_nh_add_iloop(nexthopid, &alloc_iloop_nh));
    g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].nexthop_id = nexthopid;

    ctc_port_set_direction_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].port_id, CTC_PORT_DIR_PROP_ACL_EN, CTC_INGRESS, 0x3); /*tcam0 & tacm1*/
    ctc_port_set_direction_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].port_id, CTC_PORT_DIR_PROP_ACL_PORT_BITMAP_ID, CTC_INGRESS, SAI_COPP_REASON_PORT_ID);
    ctc_port_set_direction_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].port_id, CTC_PORT_DIR_PROP_ACL_USE_CLASSID, CTC_INGRESS, 0);
    ctc_port_set_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].port_id, CTC_PORT_PROP_L3PDU_ARP_ACTION, CTC_PORT_ARP_ACTION_TYPE_FW);
    ctc_port_set_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_REASON_PORT_ID].port_id, CTC_PORT_PROP_L3PDU_DHCP_ACTION, CTC_PORT_DHCP_ACTION_TYPE_FW);

    sal_memset(&alloc_iloop_port, 0, sizeof(alloc_iloop_port));
    alloc_iloop_port.type = CTC_INTERNAL_PORT_TYPE_ILOOP;
    CTC_ERROR_RETURN(ctc_alloc_internal_port(&alloc_iloop_port));
    g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].port_id = alloc_iloop_port.inter_port;
    CTC_ERROR_RETURN(ctc_port_set_property(alloc_iloop_port.inter_port, CTC_PORT_PROP_CROSS_CONNECT_EN, CTC_NH_RESERVED_NHID_FOR_TOCPU));
    CTC_ERROR_RETURN(ctc_port_set_property(alloc_iloop_port.inter_port, CTC_PORT_PROP_ROUTE_EN, FALSE));
    CTC_ERROR_RETURN(ctc_port_set_bridge_en(alloc_iloop_port.inter_port, FALSE));
    CTC_ERROR_RETURN(ctc_port_set_port_en(alloc_iloop_port.inter_port, TRUE));
    CTC_ERROR_RETURN(ctc_port_set_default_vlan(alloc_iloop_port.inter_port, 0));
    CTC_ERROR_RETURN(ctc_port_set_learning_en(alloc_iloop_port.inter_port, FALSE));

    sal_memset(&alloc_iloop_nh, 0, sizeof(alloc_iloop_nh));
    CTC_ERROR_RETURN(ctc_sai_nexthop_alloc_offset(&nexthopid));
    alloc_iloop_nh.lpbk_lport = g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].port_id;
    CTC_ERROR_RETURN(ctc_nh_add_iloop(nexthopid, &alloc_iloop_nh));
    g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].nexthop_id = nexthopid;

    ctc_port_set_direction_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].port_id, CTC_PORT_DIR_PROP_ACL_EN, CTC_INGRESS, 0x3);
    ctc_port_set_direction_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].port_id, CTC_PORT_DIR_PROP_ACL_PORT_BITMAP_ID, CTC_INGRESS, SAI_COPP_FWD_PORT_ID);
    ctc_port_set_direction_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].port_id, CTC_PORT_DIR_PROP_ACL_USE_CLASSID, CTC_INGRESS, 0);
    ctc_port_set_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].port_id, CTC_PORT_PROP_L3PDU_ARP_ACTION, CTC_PORT_ARP_ACTION_TYPE_FW);
    ctc_port_set_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_FWD_PORT_ID].port_id, CTC_PORT_PROP_L3PDU_DHCP_ACTION, CTC_PORT_DHCP_ACTION_TYPE_FW);

    sal_memset(&alloc_iloop_port, 0, sizeof(alloc_iloop_port));
    alloc_iloop_port.type = CTC_INTERNAL_PORT_TYPE_ILOOP;
    CTC_ERROR_RETURN(ctc_alloc_internal_port(&alloc_iloop_port));
    g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].port_id = alloc_iloop_port.inter_port;
    CTC_ERROR_RETURN(ctc_port_set_property(alloc_iloop_port.inter_port, CTC_PORT_PROP_CROSS_CONNECT_EN, CTC_NH_RESERVED_NHID_FOR_TOCPU));
    CTC_ERROR_RETURN(ctc_port_set_property(alloc_iloop_port.inter_port, CTC_PORT_PROP_ROUTE_EN, FALSE));
    CTC_ERROR_RETURN(ctc_port_set_bridge_en(alloc_iloop_port.inter_port, FALSE));
    CTC_ERROR_RETURN(ctc_port_set_port_en(alloc_iloop_port.inter_port, TRUE));
    CTC_ERROR_RETURN(ctc_port_set_default_vlan(alloc_iloop_port.inter_port, 0));
    CTC_ERROR_RETURN(ctc_port_set_learning_en(alloc_iloop_port.inter_port, FALSE));
    
    sal_memset(&alloc_iloop_nh, 0, sizeof(alloc_iloop_nh));
    CTC_ERROR_RETURN(ctc_sai_nexthop_alloc_offset(&nexthopid));
    alloc_iloop_nh.lpbk_lport = g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].port_id;
    CTC_ERROR_RETURN(ctc_nh_add_iloop(nexthopid, &alloc_iloop_nh));
    g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].nexthop_id = nexthopid;

    ctc_port_set_direction_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].port_id, CTC_PORT_DIR_PROP_ACL_EN, CTC_INGRESS, 0x3);
    ctc_port_set_direction_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].port_id, CTC_PORT_DIR_PROP_ACL_PORT_BITMAP_ID, CTC_INGRESS, SAI_COPP_HYBIRD_PORT_ID);
    ctc_port_set_direction_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].port_id, CTC_PORT_DIR_PROP_ACL_USE_CLASSID, CTC_INGRESS, 0);
    ctc_port_set_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].port_id, CTC_PORT_PROP_L3PDU_ARP_ACTION, CTC_PORT_ARP_ACTION_TYPE_FW);
    ctc_port_set_property(g_sai_copp_master.ctc_copp_port_info[SAI_COPP_HYBIRD_PORT_ID].port_id, CTC_PORT_PROP_L3PDU_DHCP_ACTION, CTC_PORT_DHCP_ACTION_TYPE_FW);
#endif
    return SAI_STATUS_SUCCESS;
}

int
_ctc_sai_copp_set_exception_nexthop(uint16 cpu_reason, uint16 port_type)
{
    ctc_misc_nh_param_t nh_param;
    sai_uint32_t nexthopid;
    sai_status_t ret = SAI_STATUS_SUCCESS;
    ctc_qos_queue_cfg_t que_cfg;

    sal_memset(&que_cfg, 0, sizeof(que_cfg));
    que_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_REASON_DEST;
    que_cfg.value.reason_dest.cpu_reason = cpu_reason;
    que_cfg.value.reason_dest.dest_type = CTC_PKT_CPU_REASON_TO_NHID;
    que_cfg.value.reason_dest.nhid = g_sai_copp_master.ctc_copp_port_info[port_type].nexthop_id;
    ret += ctc_qos_set_queue(&que_cfg);
    CTC_ERROR_RETURN(ctc_sai_nexthop_alloc_offset(&nexthopid));
    sal_memset(&que_cfg, 0, sizeof(que_cfg));
    que_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_REASON_DEST;
    que_cfg.value.reason_dest.cpu_reason = (cpu_reason+CTC_PKT_CPU_REASON_CUSTOM_BASE*2);
    que_cfg.value.reason_dest.dest_type = CTC_PKT_CPU_REASON_TO_LOCAL_CPU;
    ret += ctc_qos_set_queue(&que_cfg);
    sal_memset(&nh_param, 0, sizeof(nh_param));
    nh_param.type = CTC_MISC_NH_TYPE_TO_CPU;
    nh_param.misc_param.cpu_reason.cpu_reason_id = (cpu_reason+CTC_PKT_CPU_REASON_CUSTOM_BASE*2);
    ret += ctc_nh_add_misc(nexthopid, &nh_param);
    g_sai_copp_master.ctc_reason[cpu_reason].nexthop_oid = nexthopid; 

    return ret; 

}

int
_ctc_sai_copp_set_controller_nexthop(uint16 cpu_reason, uint16 port_type)
{
    ctc_misc_nh_param_t nh_param;
    sai_uint32_t nexthopid;
    sai_status_t ret = SAI_STATUS_SUCCESS;
    ctc_qos_queue_cfg_t que_cfg;
    CTC_ERROR_RETURN(ctc_sai_nexthop_alloc_offset(&nexthopid));
    sal_memset(&nh_param, 0, sizeof(nh_param));
    nh_param.type = CTC_MISC_NH_TYPE_TO_CPU;
    nh_param.misc_param.cpu_reason.cpu_reason_id = (cpu_reason+CTC_PKT_CPU_REASON_CUSTOM_BASE*2);
    ret += ctc_nh_add_misc(nexthopid, &nh_param);
    g_sai_copp_master.ctc_reason[cpu_reason].nexthop_oid = nexthopid; 

    sal_memset(&que_cfg, 0, sizeof(que_cfg));
    que_cfg.type = CTC_QOS_QUEUE_CFG_QUEUE_REASON_DEST;
    que_cfg.value.reason_dest.cpu_reason = (cpu_reason+CTC_PKT_CPU_REASON_CUSTOM_BASE*2);
    que_cfg.value.reason_dest.dest_type = CTC_PKT_CPU_REASON_TO_LOCAL_CPU;
    ret += ctc_qos_set_queue(&que_cfg);

    return ret; 

}



int
ctc_sai_copp_exception_nexthop_init()
{
    sai_status_t ret = SAI_STATUS_SUCCESS;

    /*LLDP Reason exception, alloc nexthop for this reason and mapping the reason to CPU*/
    ret +=_ctc_sai_copp_set_exception_nexthop(CTC_PKT_CPU_REASON_L2_PDU+CTC_L2PDU_ACTION_INDEX_LLDP, 
                                                SAI_COPP_REASON_PORT_ID);

    /*BPDU Reason exception, alloc nexthop for this reason and mapping the reason to CPU*/
    ret +=_ctc_sai_copp_set_exception_nexthop(CTC_PKT_CPU_REASON_L2_PDU+CTC_L2PDU_ACTION_INDEX_BPDU, 
                                                SAI_COPP_REASON_PORT_ID);

    /*SLOW PROTOCOL Reason exception, alloc nexthop for this reason and mapping the reason to CPU*/
    ret +=_ctc_sai_copp_set_exception_nexthop(CTC_PKT_CPU_REASON_L2_PDU+CTC_L2PDU_ACTION_INDEX_SLOW_PROTO, 
                                                SAI_COPP_REASON_PORT_ID);

    /*EAPOL Reason exception, alloc nexthop for this reason and mapping the reason to CPU*/
    ret +=_ctc_sai_copp_set_exception_nexthop(CTC_PKT_CPU_REASON_L2_PDU+CTC_L2PDU_ACTION_INDEX_EAPOL, 
                                                SAI_COPP_REASON_PORT_ID);

    /*ERPS Reason exception, alloc nexthop for this reason and mapping the reason to CPU*/
    ret +=_ctc_sai_copp_set_exception_nexthop(CTC_PKT_CPU_REASON_L2_PDU+CTC_L2PDU_ACTION_INDEX_ERPS,
                                                SAI_COPP_REASON_PORT_ID);

    /*OSPF Reason exception, alloc nexthop for this reason and mapping the reason to CPU*/
    ret +=_ctc_sai_copp_set_exception_nexthop(CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_OSPF,
                                                SAI_COPP_REASON_PORT_ID);

    /*BGP Reason exception, alloc nexthop for this reason and mapping the reason to CPU*/
    ret +=_ctc_sai_copp_set_exception_nexthop(CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_BGP,
                                                SAI_COPP_REASON_PORT_ID);
    
    /*VRRP Reason exception, alloc nexthop for this reason and mapping the reason to CPU*/
    ret +=_ctc_sai_copp_set_exception_nexthop(CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_VRRP,
                                                SAI_COPP_REASON_PORT_ID);

    /*IGMP Reason exception, alloc nexthop for this reason and mapping the reason to CPU*/
    ret +=_ctc_sai_copp_set_exception_nexthop(CTC_PKT_CPU_REASON_IGMP_SNOOPING,
                                                SAI_COPP_REASON_PORT_ID);
    
    /*ARP Reason exception, alloc nexthop for this reason and mapping the reason to CPU*/
    ret +=_ctc_sai_copp_set_exception_nexthop(CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_ARP,
                                                SAI_COPP_REASON_PORT_ID);
    
    /*DHCP Reason exception, alloc nexthop for this reason and mapping the reason to CPU*/
    ret +=_ctc_sai_copp_set_exception_nexthop(CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_DHCP,
                                                SAI_COPP_REASON_PORT_ID);

    /*PIM Reason exception, alloc nexthop for this reason and mapping the reason to CPU*/
    ret +=_ctc_sai_copp_set_exception_nexthop(CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_PIM,
                                                SAI_COPP_REASON_PORT_ID);
    
    /*fwd-to-cpu Reason, alloc nexthop for this reason and mapping the reason to CPU*/
    ret +=_ctc_sai_copp_set_exception_nexthop(CTC_PKT_CPU_REASON_L3_COPY_CPU,SAI_COPP_FWD_PORT_ID);

    /*to-controller Reason, alloc nexthop for this reason and mapping the reason to CPU*/
    /*CTC_PKT_CPU_REASON_CUSTOM_BASE + GLB_PKT_CUSTOM_TOCPU_OPENFLOW_MIN*/
    ret +=_ctc_sai_copp_set_controller_nexthop(CTC_PKT_CPU_REASON_CUSTOM_BASE + 1,SAI_COPP_HYBIRD_PORT_ID);
    
    return ret;
}



sai_status_t 
ctc_sai_copp_set_total_rate(const sai_attribute_t *attr)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    ctc_qos_shape_t qos_shape;
    sal_memset(&qos_shape, 0x0, sizeof(ctc_qos_shape_t));

    qos_shape.type = CTC_QOS_SHAPE_PORT;
    qos_shape.shape.port_shape.enable = TRUE;
    qos_shape.shape.port_shape.gport = CTC_LPORT_CPU;
    qos_shape.shape.port_shape.pir = attr->value.u64;
    qos_shape.shape.port_shape.pbs = attr->value.u64*1000*2;
    ret = ctc_qos_set_shape(&qos_shape);
  
    return ret;
}



#define ________SAI_COPP_QUEUE_API_FUNC

sai_status_t sai_set_copp_queue_attribute_debug_param(
    _In_ sai_object_id_t queue_id,
    _In_ const sai_attribute_t *attr
    )
{
    CTC_SAI_DEBUG("in:queue_id 0x%llx", queue_id);
    switch(attr->id)
    {
    case SAI_COPP_QUEUE_ATTR_SCHEDULER_PROFILE_ID:
        CTC_SAI_DEBUG("in:SAI_COPP_QUEUE_ATTR_SCHEDULER_PROFILE_ID %u", attr->value.u32);
        //copp 8 queue
        break;
    }
    return SAI_STATUS_SUCCESS;
}


sai_status_t sai_set_copp_queue_attribute(
    _In_ sai_object_id_t queue_id,
    _In_ const sai_attribute_t *attr
    )
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    CTC_SAI_DEBUG_FUNC();
    sai_set_copp_queue_attribute_debug_param(queue_id, attr);

    CTC_SAI_PTR_VALID_CHECK(attr);

    switch(attr->id)
    {
        case SAI_COPP_QUEUE_ATTR_SCHEDULER_PROFILE_ID:
            ret = ctc_sai_scheduler_copp_set_scheduler(queue_id, attr);
            break;
        case SAI_COPP_QUEUE_ATTR_TOTAL_RATE:
            ret = ctc_sai_copp_set_total_rate(attr);
            break;
        default :
            break;
    }

    return ret;
}


sai_status_t sai_get_copp_queue_attribute(
    _In_ sai_object_id_t queue_id,
    _In_ uint32_t        attr_count,
    _Inout_ sai_attribute_t *attr_list
    )
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_attribute_t* attr;
    int i;

    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_PTR_VALID_CHECK(attr_list);
    for (i=0; i<attr_count; i++)
    {
        attr = attr_list + i;
        switch(attr->id)
        {
            case SAI_COPP_QUEUE_ATTR_SCHEDULER_PROFILE_ID:
                ret = ctc_sai_scheduler_copp_get_scheduler(queue_id, attr);
                break; 

            case SAI_COPP_QUEUE_ATTR_TOTAL_RATE:
                break;

            default :
                break;
        }
    }

    return ret;
}

sai_status_t
ctc_sai_copp_db_init()
{
    sai_object_id_t nh_oid;
    sai_object_id_t acl_entry_oids[8];
    sai_object_id_t counter_oid;
    uint32 reason_id;
    
    sal_memset(&g_sai_copp_master,0,sizeof(g_sai_copp_master));
    
    /*inisiall port*/
    CTC_ERROR_RETURN(ctc_sai_copp_internal_port_init());

    CTC_ERROR_RETURN(ctc_sai_copp_tbl_init());

    /*inisiall port acl group*/
    CTC_ERROR_RETURN(ctc_sai_acl_copp_group_init());

    /*creat nexthop for each exception*/
    CTC_ERROR_RETURN(ctc_sai_copp_exception_nexthop_init());

    /*creat acl entry for lldp exception for Godengate iloop solution*/
    reason_id = CTC_PKT_CPU_REASON_L2_PDU+CTC_L2PDU_ACTION_INDEX_LLDP;
    nh_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP, g_sai_copp_master.ctc_reason[reason_id].nexthop_oid);
    ctc_sai_copp_add_acl_entry_for_reason_lldp(nh_oid, &acl_entry_oids[0], &counter_oid);
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[0] = acl_entry_oids[0];
    g_sai_copp_master.ctc_reason[reason_id].nexthop_oid = nh_oid;

    /*creat acl entry for slow protocol exception for Godengate iloop solution*/
    reason_id = CTC_PKT_CPU_REASON_L2_PDU+CTC_L2PDU_ACTION_INDEX_SLOW_PROTO;
    nh_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP, g_sai_copp_master.ctc_reason[reason_id].nexthop_oid);
    ctc_sai_copp_add_acl_entry_for_reason_slow_protocol(nh_oid, &acl_entry_oids[0], &counter_oid);
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[0] = acl_entry_oids[0];
    g_sai_copp_master.ctc_reason[reason_id].nexthop_oid = nh_oid;

    /*creat acl entry for eapol exception for Godengate iloop solution*/
    reason_id = CTC_PKT_CPU_REASON_L2_PDU+CTC_L2PDU_ACTION_INDEX_EAPOL;
    nh_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP, g_sai_copp_master.ctc_reason[reason_id].nexthop_oid);
    ctc_sai_copp_add_acl_entry_for_reason_eapol(nh_oid, &acl_entry_oids[0], &counter_oid);
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[0] = acl_entry_oids[0];
    g_sai_copp_master.ctc_reason[reason_id].nexthop_oid = nh_oid;

    /*creat acl entry for arp exception for Godengate iloop solution*/
    reason_id = CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_ARP;
    nh_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP, g_sai_copp_master.ctc_reason[reason_id].nexthop_oid);
    ctc_sai_copp_add_acl_entry_for_reason_arp(nh_oid, &acl_entry_oids[0], &counter_oid); 
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[0] = acl_entry_oids[0];
    g_sai_copp_master.ctc_reason[reason_id].nexthop_oid = nh_oid;

    /*creat acl entry for ospf exception for Godengate iloop solution*/
    reason_id = CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_OSPF;
    nh_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP, g_sai_copp_master.ctc_reason[reason_id].nexthop_oid);
    ctc_sai_copp_add_acl_entry_for_reason_ospf(nh_oid, &acl_entry_oids[0], &counter_oid); 
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[0] = acl_entry_oids[0];
    g_sai_copp_master.ctc_reason[reason_id].nexthop_oid = nh_oid;

    /*creat acl entry for pim exception for Godengate iloop solution*/
    reason_id = CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_PIM;
    nh_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP, g_sai_copp_master.ctc_reason[reason_id].nexthop_oid);
    ctc_sai_copp_add_acl_entry_for_reason_pim(nh_oid, &acl_entry_oids[0], &counter_oid); 
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[0] = acl_entry_oids[0];
    g_sai_copp_master.ctc_reason[reason_id].nexthop_oid = nh_oid;

    /*creat acl entry for vrrp exception for Godengate iloop solution*/
    reason_id = CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_VRRP;
    nh_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP, g_sai_copp_master.ctc_reason[reason_id].nexthop_oid);
    ctc_sai_copp_add_acl_entry_for_reason_vrrp(nh_oid, &acl_entry_oids[0], &counter_oid); 
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[0] = acl_entry_oids[0];
    g_sai_copp_master.ctc_reason[reason_id].nexthop_oid = nh_oid;
    
    /*creat acl entry for bgp exception for Godengate iloop solution*/
    reason_id = CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_BGP;
    nh_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP, g_sai_copp_master.ctc_reason[reason_id].nexthop_oid);
    ctc_sai_copp_add_acl_entry_for_reason_bgp(nh_oid, &acl_entry_oids[0], &counter_oid); 
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[0] = acl_entry_oids[0];
    g_sai_copp_master.ctc_reason[reason_id].nexthop_oid = nh_oid;

    /*creat acl entry for dhcp exception for Godengate iloop solution*/
    reason_id = CTC_PKT_CPU_REASON_L3_PDU+CTC_L3PDU_ACTION_INDEX_DHCP;
    nh_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP, g_sai_copp_master.ctc_reason[reason_id].nexthop_oid);
    ctc_sai_copp_add_acl_entry_for_reason_dhcp(nh_oid, acl_entry_oids, &counter_oid); 
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[0] = acl_entry_oids[0];
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[1] = acl_entry_oids[1];
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[2] = acl_entry_oids[2];
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[3] = acl_entry_oids[3];
    g_sai_copp_master.ctc_reason[reason_id].nexthop_oid = nh_oid;

    /*creat acl entry for igmp exception for Godengate iloop solution*/
    reason_id = CTC_PKT_CPU_REASON_IGMP_SNOOPING;
    nh_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP, g_sai_copp_master.ctc_reason[reason_id].nexthop_oid);
    ctc_sai_copp_add_acl_entry_for_reason_igmp(nh_oid, acl_entry_oids, &counter_oid); 
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[0] = acl_entry_oids[0];
    g_sai_copp_master.ctc_reason[reason_id].nexthop_oid = nh_oid;

    /*creat acl entry for erps exception for Godengate iloop solution*/
    reason_id = CTC_PKT_CPU_REASON_L2_PDU+CTC_L2PDU_ACTION_INDEX_ERPS;
    nh_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP, g_sai_copp_master.ctc_reason[reason_id].nexthop_oid);
    ctc_sai_copp_add_acl_entry_for_reason_erps(nh_oid, acl_entry_oids, &counter_oid);
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[0] = acl_entry_oids[0];
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[1] = acl_entry_oids[1];
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[2] = acl_entry_oids[2];
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[3] = acl_entry_oids[3];
    g_sai_copp_master.ctc_reason[reason_id].nexthop_oid = nh_oid;

    /*creat acl entry for bpdu exception for Godengate iloop solution*/
    reason_id = CTC_PKT_CPU_REASON_L2_PDU+CTC_L2PDU_ACTION_INDEX_BPDU;
    nh_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP, g_sai_copp_master.ctc_reason[reason_id].nexthop_oid);
    ctc_sai_copp_add_acl_entry_for_reason_bpdu(nh_oid, &acl_entry_oids[0], &counter_oid);
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[0] = acl_entry_oids[0];
    g_sai_copp_master.ctc_reason[reason_id].nexthop_oid = nh_oid;

    /*creat acl entry for fwd2cpu for Godengate iloop solution*/
    reason_id = CTC_PKT_CPU_REASON_L3_COPY_CPU;
    nh_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP, g_sai_copp_master.ctc_reason[reason_id].nexthop_oid);
    ctc_sai_copp_add_acl_entry_for_fwd_to_cpu(nh_oid, &acl_entry_oids[0], &counter_oid);
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[0] = acl_entry_oids[0];
    g_sai_copp_master.ctc_reason[reason_id].nexthop_oid = nh_oid;

    /*to-controller Reason, alloc nexthop for this reason and mapping the reason to CPU*/
    /*CTC_PKT_CPU_REASON_CUSTOM_BASE + GLB_PKT_CUSTOM_TOCPU_OPENFLOW_MIN*/
    reason_id = CTC_PKT_CPU_REASON_CUSTOM_BASE + 1;
    nh_oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_NEXT_HOP, g_sai_copp_master.ctc_reason[reason_id].nexthop_oid);
    ctc_sai_copp_add_acl_entry_for_fwd_to_controller(nh_oid, &acl_entry_oids[0], &counter_oid);
    g_sai_copp_master.ctc_reason[reason_id].acl_entry_oid[0] = acl_entry_oids[0];
    g_sai_copp_master.ctc_reason[reason_id].nexthop_oid = nh_oid;

    return SAI_STATUS_SUCCESS;
}


#define ________SAI_COPP_INNER_FUNC

static sai_status_t
__init_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    #ifndef DUET2
    ret = ctc_sai_copp_db_init();
    #else
//    ret = ctc_sai_copp_db_init();
    #endif

    if(SAI_STATUS_SUCCESS != ret)
    {
        goto out;
    }
    
    preg->init_status =  INITIALIZED;

out:
    return ret;
}

static sai_status_t
__exit_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}

static sai_copp_api_t g_copp_sai_api_func = {
        .set_copp_queue_attribute               = sai_set_copp_queue_attribute,
        .get_copp_queue_attribute               = sai_get_copp_queue_attribute,
};

static ctc_sai_api_reg_info_t g_copp_api_reg_info = {
        .id         = SAI_API_COPP,
        .init_func  = __init_mode_fn,
        .exit_func  = __exit_mode_fn,
        .api_method_table = &g_copp_sai_api_func,
        .private_data     = NULL,
};

#define ________SAI_COPP_OUTER_FUNC



sai_status_t
ctc_sai_copp_init()
{
    api_reg_register_fn(&g_copp_api_reg_info);
    
    return SAI_STATUS_SUCCESS;
}



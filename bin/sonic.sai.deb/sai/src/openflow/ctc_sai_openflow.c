#include <sal.h>
#include <sai.h>
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_sai.h>
#include <ctc_sai_openflow.h>
#include <ctc_sai_routerintf.h>
#include <ctc_sai_debug.h>
#include <ctc_api.h>


typedef struct
{
    sai_object_id_t            port_id;
    uint32                     l3if_id;
    uint32                     nh_id;
} ctc_sai_of_port_t;

ctc_hash_t *sai_of_port_hash;

static uint32_t
_of_port_entry_hash_make(
    _In_  void* data)
{
    ctc_sai_of_port_t* p_of_port = (ctc_sai_of_port_t*)data;

    return ctc_hash_caculate(sizeof(sai_object_id_t), &p_of_port->port_id);
}

static bool
_of_port_entry_hash_cmp(
    _In_ void *data,
    _In_ void *data1)
{
    ctc_sai_of_port_t* p_of_port = (ctc_sai_of_port_t*)data;
    ctc_sai_of_port_t* p_of_port1 = (ctc_sai_of_port_t*)data1;
    
    if (p_of_port->port_id == p_of_port1->port_id)
    {
        return TRUE;
    }
    return FALSE;
}

static int32
_ctc_sai_openflow_port_set_pdu_action(uint32 gport)
{
    /* Set well-known l2pdu action to normal forward to comply to OpenFlow standard.
       NOTE: 
       1. the action index for these l2pdu is set by hagt_cpu_traffic_init. 
       2. Until we support hybrid mode, we do not to set action for l3pdu. */
       
    ctc_l2pdu_set_port_action(gport, CTC_L2PDU_ACTION_INDEX_BPDU, 
                               CTC_PDU_L2PDU_ACTION_TYPE_FWD);               
    ctc_l2pdu_set_port_action(gport, CTC_L2PDU_ACTION_INDEX_LLDP, 
                               CTC_PDU_L2PDU_ACTION_TYPE_FWD); 
    ctc_l2pdu_set_port_action(gport, CTC_L2PDU_ACTION_INDEX_SLOW_PROTO, 
                                CTC_PDU_L2PDU_ACTION_TYPE_COPY_TO_CPU); 

    /* Ensure arp/dhcp packet is forwarded by openflow rules. */
    ctc_port_set_property(gport, CTC_PORT_PROP_L3PDU_DHCP_ACTION, CTC_EXCP_NORMAL_FWD);
    ctc_port_set_property(gport, CTC_PORT_PROP_L3PDU_ARP_ACTION, CTC_EXCP_NORMAL_FWD);

    return SAI_STATUS_SUCCESS;
}

static int32
_ctc_sai_openflow_port_unset_pdu_action(uint32 gport)
{
    /* Restore well-known l2pdu action. */
    ctc_l2pdu_set_port_action(gport, CTC_L2PDU_ACTION_INDEX_BPDU, 
                                CTC_PDU_L2PDU_ACTION_TYPE_REDIRECT_TO_CPU);                
    ctc_l2pdu_set_port_action(gport, CTC_L2PDU_ACTION_INDEX_LLDP, 
                                CTC_PDU_L2PDU_ACTION_TYPE_REDIRECT_TO_CPU);  


    // TODO:  hybrid will not be support, l3pdu state is not needed to be restored.
    
    return SAI_STATUS_SUCCESS;
}

/* refer to V580 hagt_openflow_port_enable() */
int32
_ctc_sai_openflow_set_port_enable(sai_object_id_t port_id, uint32 enable, uint32 l3if_id)
{
    uint32 gport = 0;
    ctc_acl_group_info_t group_info;
    ctc_direction_t dir;
    ctc_l3if_t l3if;
    ctc_l3if_router_mac_t router_mac;
    
    sal_memset(&group_info, 0, sizeof(ctc_acl_group_info_t));
    group_info.dir = dir = CTC_INGRESS;
    sal_memset(&router_mac, 0, sizeof(router_mac));

    gport = CTC_SAI_OBJECT_INDEX_GET(port_id);

#if 0
    uint i = 0;
    hagt_openflow_port_mac_t p_openflow_port_mac_param;
    
    for (i = 0; i < req ->portMac.size; i++)
    {
        router_mac.mac[0][i] = req ->portMac.buf[i];
        p_openflow_port_mac_param.mac[i] = req ->portMac.buf[i];
    }
    p_openflow_port_mac_param.gport = req->gport;
    openflow_port_mac_add_hash(&p_openflow_port_mac_param);
#endif

    router_mac.num = 1;
    if (enable)
    {
#if 0
        ctc_port_set_direction_property(req->gport, CTC_PORT_DIR_PROP_ACL_EN, dir, CTC_ACL_EN_0);
        ctc_port_set_direction_property(req->gport, CTC_PORT_DIR_PROP_ACL_CLASSID, dir, req->label);
        if (GLB_STM_MODE_OF_IPV6 == g_pst_hagt_master->stm_mode)
        {
            ctc_port_set_direction_property(req->gport, CTC_PORT_DIR_PROP_ACL_TCAM_LKUP_TYPE_0, dir, CTC_ACL_TCAM_LKUP_TYPE_L2_L3);
        }
        else
        {
            ctc_port_set_direction_property(req->gport, CTC_PORT_DIR_PROP_ACL_TCAM_LKUP_TYPE_0, dir, CTC_ACL_TCAM_LKUP_TYPE_L2);
        }
#endif
        ctc_port_set_property(gport, CTC_PORT_PROP_ADD_DEFAULT_VLAN_DIS, TRUE);
        /* Added by weizj for tunnel */
        ctc_port_set_property(gport, CTC_PORT_PROP_METADATA_OVERWRITE_UDF, TRUE);
        _ctc_sai_openflow_port_set_pdu_action(gport);
        l3if.l3if_type = CTC_L3IF_TYPE_PHY_IF;
        l3if.gport = gport;
        ctc_l3if_create(l3if_id, &l3if);
        ctc_port_set_phy_if_en(gport, TRUE);
        ctc_l3if_set_property(l3if_id, CTC_L3IF_PROP_ROUTE_ALL_PKT, TRUE);
        /* Added by weizj for tunnel bug: 33368, default is CTC_DOT1Q_TYPE_BOTH */
        ctc_port_set_property(gport, CTC_PORT_PROP_DOT1Q_TYPE, CTC_DOT1Q_TYPE_BOTH);

        /* modified by yaom for openflow MPLS L2VPN 20160214 */
        ctc_l3if_set_property(l3if_id, CTC_L3IF_PROP_MPLS_EN, TRUE);
        ctc_l3if_set_property(l3if_id, CTC_L3IF_PROP_CONTEXT_LABEL_EXIST, TRUE);
        /* XXX_V350: SDK will disable DsSrcPort_BridgeEn_f and DsDestPort_BridgeEn_f
         * after we call ctc_port_set_phy_if_en, this will make layer 2 edit on epe
         * fail to work, so we enable this too property explicitly.
         * Note, we have to modify SDK code to allow set the property because SDK
         * check phy_if_en collision. */
        ctc_port_set_bridge_en(gport, TRUE);

        /* Enable reflective bridge, we will control using met entry. */
        ctc_port_set_reflective_bridge_en(gport, TRUE);
        ctc_l3if_set_interface_router_mac(l3if_id, router_mac);
    }
    else
    {
#if 0
        HAGT_IF_ERROR_RETURN(ctc_port_set_direction_property(req->gport, CTC_PORT_DIR_PROP_ACL_EN, dir, 0));
        if (hagt_ipuc_get_ipv6_enabled())
        {
            HAGT_IF_ERROR_RETURN(ctc_port_set_direction_property(req->gport, 
                CTC_PORT_DIR_PROP_ACL_EN, dir, GLB_QOS_ACL_BLOCK_ENABLE_LOOKUP));
        }
#endif
        ctc_port_set_property(gport, CTC_PORT_PROP_ADD_DEFAULT_VLAN_DIS, 0);
        /* Added by weizj for tunnel */
        ctc_port_set_property(gport, CTC_PORT_PROP_METADATA_OVERWRITE_UDF, FALSE);
        _ctc_sai_openflow_port_unset_pdu_action(gport);

        l3if.l3if_type = CTC_L3IF_TYPE_PHY_IF;
        l3if.gport = gport;
        ctc_l3if_destory(l3if_id, &l3if);
        ctc_port_set_phy_if_en(gport, FALSE);
        /* modified by yaom for openflow MPLS L2VPN 20160214 */
        ctc_l3if_set_property(l3if_id, CTC_L3IF_PROP_MPLS_EN, FALSE);
        ctc_l3if_set_property(l3if_id, CTC_L3IF_PROP_CONTEXT_LABEL_EXIST, FALSE );
        ctc_l3if_set_property(l3if_id, CTC_L3IF_PROP_ROUTE_ALL_PKT, FALSE);
        /* Added by weizj for tunnel bug: 33360 */
        ctc_port_set_property(gport, CTC_PORT_PROP_ADD_DEFAULT_VLAN_DIS, TRUE);

        /* Enable reflective bridge, we will control using met entry. */
        ctc_port_set_reflective_bridge_en(gport, FALSE);
    }
    
    return SAI_STATUS_SUCCESS;
}


sai_status_t 
ctc_sai_create_openflow_port(
        _In_  sai_object_id_t port_id,
        _In_  uint32_t attr_count,
        _In_  const sai_attribute_t *attr_list)
{
    ctc_sai_of_port_t of_port;
    ctc_sai_of_port_t *p_of_port = NULL;
    ctc_sai_of_port_t *p_db_of_port = NULL;
    void *p_ret = NULL;
    uint32 l3if_id = 0;
    sai_status_t ret = SAI_STATUS_SUCCESS;
    
    /* 1. check dupliate config */
    of_port.port_id = port_id;
    p_db_of_port = ctc_hash_lookup(sai_of_port_hash, &of_port);
    if (p_db_of_port)
    {
        return SAI_STATUS_ITEM_ALREADY_EXISTS;
    }

    /* 2. call SDK APIs, refer to V580's hsrv_openflow_port_enable() */
    p_of_port = mem_malloc(MEM_APP_OPENFLOW_MODULE, sizeof(ctc_sai_of_port_t));
    if (NULL == p_of_port)
    {
        return SAI_STATUS_INSUFFICIENT_RESOURCES;
    }

#if 0
    TODO
    /* 2.1 use l3if is for MPLS processing */
    ctc_routerintf_alloc_l3if_id(&l3if_id);

    /* 2.2 CNOS uses ctc_sai_port_entry_t group_id_igs/group_id_egs/port_class_id */
#ifdef GREATBELT
    ctc_sai_acl_port_enable(CTC_INGRESS, port_id);
#else
    /* GG is ACL enabled by default */
#endif
    _ctc_sai_openflow_set_port_enable(port_id, TRUE, l3if_id);

    /* 2.3 create port flex_nh, refer to hsrv_openflow_nexthop_alloc_port_flex_nh() */
    hsrv_openflow_nexthop_alloc_port_flex_nh(gport, &p_port_data->nh_info);
    
    /* 2.4 Added by weizj for udf, refer to hsrv_openflow_port_udf_enable() */
    (hsrv_openflow_port_udf_enable(ifindex, gport));

#endif

    /* 3. store DB */
    p_of_port->port_id = port_id;
    p_of_port->l3if_id = l3if_id;
    p_ret = ctc_hash_insert(sai_of_port_hash, p_of_port);
    if (NULL == p_ret)
    {
        ret = SAI_STATUS_INSUFFICIENT_RESOURCES;
        goto error;
    }

    return SAI_STATUS_SUCCESS;
    
error:
    if (p_of_port)
    {
        mem_free(p_of_port);
        p_of_port = NULL;
    }

    return ret;
}

/**
 * @brief Remove openflow port.
 *
 * @param[in] port_id  Port id
 * @return SAI_STATUS_SUCCESS if operation is successful otherwise a different
 *  error code is returned.
 */
sai_status_t ctc_sai_remove_openflow_port(
        _In_ sai_object_id_t port_id)
{
    ctc_sai_of_port_t of_port;
    ctc_sai_of_port_t *p_db_of_port = NULL;
    
    /* 1. check dupliate config */
    of_port.port_id = port_id;
    p_db_of_port = ctc_hash_lookup(sai_of_port_hash, &of_port);
    if (NULL == p_db_of_port)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }
    
    /* 2. call SDK APIs */

    /* 3. store DB */
    ctc_hash_remove(sai_of_port_hash, p_db_of_port);
    mem_free(p_db_of_port);

    return SAI_STATUS_SUCCESS;
}

static sai_openflow_api_t g_sai_openflow_api_func = {
    .create_openflow_port = ctc_sai_create_openflow_port,
    .remove_openflow_port = ctc_sai_remove_openflow_port,    
};

sai_status_t
__openflow_init_mode_fn(
    _In_  ctc_sai_api_reg_info_t *preg,
    _In_  void *private_data)
{
    preg->init_status = INITIALIZED;

    sai_of_port_hash = ctc_hash_create(64, 32, _of_port_entry_hash_make, _of_port_entry_hash_cmp);
    
    return SAI_STATUS_SUCCESS;
}

sai_status_t
__openflow_exit_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}

static ctc_sai_api_reg_info_t g_openflow_api_reg_info = {
        .id         = SAI_API_OPENFLOW,
        .init_func  = __openflow_init_mode_fn,
        .exit_func  = __openflow_exit_mode_fn,
        .api_method_table = &g_sai_openflow_api_func,
        .private_data     = NULL,
};

sai_status_t
ctc_sai_openflow_init()
{
    api_reg_register_fn(&g_openflow_api_reg_info);

    return SAI_STATUS_SUCCESS;
}


#if !defined (__CTC_SAI_OPENFLOW_H_)
#define __CTC_SAI_OPENFLOW_H_

#include <sai.h>
#include <ctc_opf.h>

sai_status_t
ctc_sai_openflow_init(void);

#endif /* !__CTC_SAI_OPENFLOW_H_ */


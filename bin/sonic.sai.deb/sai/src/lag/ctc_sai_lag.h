#if !defined (__CTC_SAI_LAG_H_)
#define __CTC_SAI_LAG_H_

#include <sai.h>
#include <ctc_opf.h>
#include "ctc_sai_opb.h"
#include "ctc_sai_port.h"

#define CTC_SAI_MAX_LINKAGG_RR_GROUP_NUM    16
#if defined GOLDENGATE
#define CTC_SAI_MAX_LINKAGG_GROUP_NUM       55
#elif defined DUET2
#define CTC_SAI_MAX_LINKAGG_GROUP_NUM       55
#else
#define CTC_SAI_MAX_LINKAGG_GROUP_NUM       31
#endif

typedef struct ctc_sai_lag_info_s
{
    uint32_t        max_count;
    ctc_opf_t       opf;
    ctc_sai_opb_t   opb;
    ctc_hash_t*     ctc_sai_lag_port_info_hash;
    ctc_sai_port_entry_t agg_entries[CTC_MAX_LINKAGG_GROUP_NUM];
}ctc_sai_lag_info_t;

typedef struct ctc_sai_lag_port_info_hash_s
{
    sai_object_id_t                    lag_member_id;
    sai_object_id_t                    portid;
    uint32_t                           gport; 
    uint8                              tid;
}ctc_sai_lag_port_info_hash_t;

enum{
    CTC_SAI_LAG_NF_NEW_LAG = 0,
    CTC_SAI_LAG_NF_DEL_LAG,
    CTC_SAI_LAG_NF_NEW_LAG_MEMBER,
    CTC_SAI_LAG_NF_DEL_LAG_MEMBER,
};

typedef struct ctc_sai_lag_notifier
{
    uint32_t                            op;
    sai_object_id_t                     lag_id;
    sai_object_id_t                     lag_member_port_id;      /* member port oid */
}ctc_sai_lag_notifier_t;

sai_status_t
ctc_sai_lag_get_ports(
    _In_    sai_object_id_t      lag_id,
    _Inout_ sai_attribute_t*     attr);

sai_status_t
ctc_sai_lag_init(void);

int32_t
ctc_sai_lag_alloc_timestamp (sai_object_id_t port_id, uint32_t *ptimestamp_nhid);

int32_t
ctc_sai_lag_free_timestamp (sai_object_id_t port_id);

ctc_sai_port_entry_t*
ctc_sai_lag_get_by_lagid(sai_object_id_t lag_id);

#endif


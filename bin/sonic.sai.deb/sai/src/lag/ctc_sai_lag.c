#include <sai.h>
#include <ctc_port.h>
#include <ctc_sai_lag.h>
#include <sal.h>
#include <ctc_sai_sai.h>
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_port.h>
#include <ctc_sai_acl.h>
#include <ctc_api.h>
#include <ctc_sai_debug.h>
#include <ctc_sai_nexthop.h>
#include <ctc_sai_opb.h>

ctc_sai_lag_info_t g_ctc_sai_lag_info;

static ctc_sai_attr_entry_info_t g_sai_attr_entries[] = {
    {
        .id     = SAI_LAG_ATTR_PORT_LIST,
        .type   = SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_ATTR_ID_END,
        .type   = 0,
    },
};
#if 0
static ctc_sai_attr_entry_info_t g_lag_member_attr_entries[] = {
    {
        .id     = SAI_LAG_MEMBER_ATTR_LAG_ID,
        .type   = SAI_ATTR_FALG_CREATE  | SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_LAG_MEMBER_ATTR_PORT_ID,
        .type   = SAI_ATTR_FALG_CREATE  | SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_LAG_MEMBER_ATTR_EGRESS_DISABLE,
        .type   = SAI_ATTR_FALG_CREATE  | SAI_ATTR_FALG_READ,
    },
        {
        .id     = SAI_LAG_MEMBER_ATTR_INGRESS_DISABLE,
        .type   = SAI_ATTR_FALG_CREATE  | SAI_ATTR_FALG_READ,
    },    
    {
        .id     = SAI_ATTR_ID_END,
        .type   = 0,
    },
};
#endif
#define ________SAI_SAI_INNER_API_FUNC

ctc_sai_lag_port_info_hash_t*
ctc_sai_lag_port_info_get_by_gport(uint32 gport)
{
    ctc_sai_lag_port_info_hash_t p_lag_port_info_hash;

    sal_memset(&p_lag_port_info_hash, 0, sizeof(p_lag_port_info_hash));
    p_lag_port_info_hash.gport = gport;
    
    return ctc_hash_lookup(g_ctc_sai_lag_info.ctc_sai_lag_port_info_hash, &p_lag_port_info_hash);
}

ctc_sai_lag_port_info_hash_t*
ctc_sai_lag_port_info_add_hash(uint32 gport)
{
    ctc_sai_lag_port_info_hash_t* p_lag_port_info_hash = NULL;

    p_lag_port_info_hash = mem_malloc(MEM_APP_LINKAGG_MODULE,sizeof(ctc_sai_lag_port_info_hash_t));
    if (NULL == p_lag_port_info_hash)
    {
        return NULL;
    }
    p_lag_port_info_hash->gport = gport;
    
    return ctc_hash_insert(g_ctc_sai_lag_info.ctc_sai_lag_port_info_hash, p_lag_port_info_hash);
}

static uint32_t
_lag_port_info_hash_make(
    _In_  void* data)
{
    ctc_sai_lag_port_info_hash_t* p_lag_port_info_hash = (ctc_sai_lag_port_info_hash_t*)data;

    return ctc_hash_caculate(sizeof(uint32), &p_lag_port_info_hash->gport);
}

static bool
_lag_port_info_hash_cmp(
    _In_ void *data,
    _In_ void *data1)
{
    ctc_sai_lag_port_info_hash_t* p_lag_port_info_hash = data;
    ctc_sai_lag_port_info_hash_t* p_lag_port_info_hash1 = data1;

    if ((p_lag_port_info_hash->gport) == (p_lag_port_info_hash1->gport))
    {
        return TRUE;
    }
    return FALSE;
}

ctc_sai_port_entry_t*
ctc_sai_lag_get_by_lagid(sai_object_id_t lag_id)
{
    uint32 tid = 0;

    if (SAI_OBJECT_TYPE_LAG != CTC_SAI_OBJECT_TYPE_GET(lag_id))
    {
        return NULL;
    }
    
    tid = CTC_SAI_OBJECT_INDEX_GET(lag_id);
    if (tid > CTC_MAX_LINKAGG_GROUP_NUM)
    {
        return NULL;
    }
    
    return &g_ctc_sai_lag_info.agg_entries[tid];
}

sai_status_t
ctc_sai_lag_db_init()
{
    sal_memset(&g_ctc_sai_lag_info, 0, sizeof(g_ctc_sai_lag_info));
    g_ctc_sai_lag_info.max_count = CTC_SAI_MAX_LINKAGG_GROUP_NUM;         /* lag tid */

    if(0 != ctc_opf_init(CTC_OPF_SAI_LAG_ID,1))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    g_ctc_sai_lag_info.opf.pool_type = CTC_OPF_SAI_LAG_ID;
    g_ctc_sai_lag_info.opf.pool_index= 0;

    if(0 != ctc_opf_init_offset(&g_ctc_sai_lag_info.opf, 1, g_ctc_sai_lag_info.max_count))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    ctc_sai_opb_create(&g_ctc_sai_lag_info.opb, 0, g_ctc_sai_lag_info.max_count, "lag");

    g_ctc_sai_lag_info.ctc_sai_lag_port_info_hash = ctc_hash_create(64, 32, _lag_port_info_hash_make, _lag_port_info_hash_cmp);
    
    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_lag_create(
	_Out_ sai_object_id_t* lag_id,
	   _In_ uint32_t attr_count,
        _In_ sai_attribute_t *attr_list)
{
    uint32_t                        opf_index;
    int32_t                         sdk_ret     = 0;
    ctc_linkagg_group_t             linkagg_grp;

    if (attr_count < 1 || attr_list == NULL)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }
    
    sal_memset(&linkagg_grp,0,sizeof(ctc_linkagg_group_t));

    if (SAI_LAG_LOAD_BALANCE_DLB == attr_list->value.u32)
    {
        ctc_sai_opb_alloc_offset(&g_ctc_sai_lag_info.opb, &opf_index);    
        linkagg_grp.linkagg_mode = CTC_LINKAGG_MODE_DLB;
    }
    else if (SAI_LAG_LOAD_BALANCE_RR == attr_list->value.u32)
    {
        ctc_sai_opb_alloc_offset_position_reverse(&g_ctc_sai_lag_info.opb, CTC_SAI_MAX_LINKAGG_RR_GROUP_NUM-1, &opf_index);    
        linkagg_grp.linkagg_mode = CTC_LINKAGG_MODE_RR;
    }
    else if(SAI_LAG_LOAD_BALANCE_STATIC_FAILOVER == attr_list->value.u32)
    {
        ctc_sai_opb_alloc_offset_last_reverse(&g_ctc_sai_lag_info.opb, &opf_index);    
        linkagg_grp.linkagg_mode =CTC_LINKAGG_MODE_STATIC; /* CTC_LINKAGG_MODE_STATIC_FAILOVER; modified by chenyq for bug 42560, chip bug*/
    }
    else
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }
     
    linkagg_grp.tid          = opf_index;
    *lag_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_LAG, opf_index);
    
    ctc_sai_acl_lag_install(CTC_INGRESS, *lag_id);
    ctc_sai_acl_lag_install(CTC_EGRESS, *lag_id);

    sdk_ret = ctc_linkagg_create(&linkagg_grp);
    if(CTC_E_INVALID_TID == sdk_ret)
    {
        return SAI_STATUS_TABLE_FULL;
    }
    g_ctc_sai_lag_info.agg_entries[opf_index].port_oid = *lag_id;

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_sai_lag_remove(
	_In_  sai_object_id_t lag_id)
{
    uint32_t                        opf_index;
    int32_t                         sdk_ret     = 0;
    ctc_linkagg_group_t             linkagg_grp;

    sal_memset(&linkagg_grp,0,sizeof(ctc_linkagg_group_t));

    opf_index = CTC_SAI_OBJECT_INDEX_GET(lag_id);

    ctc_sai_opb_free_offset(&g_ctc_sai_lag_info.opb, opf_index);

    ctc_linkagg_destroy(opf_index);

    ctc_sai_clear_port_all_stats(lag_id);
    g_ctc_sai_lag_info.agg_entries[opf_index].port_oid = 0;

    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

sai_status_t
ctc_sai_lag_creat_lag_member(
    _Out_ sai_object_id_t* lag_member_id,
    _In_ uint32_t attr_count,
    _In_ sai_attribute_t *attr_list)
{
    uint32          attr_idx = 0; 
    uint8           tid  = 0;
    uint32          gport = 0;
    sai_object_id_t lag_id = 0;
    sai_object_id_t port_id = 0;
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_attribute_t*  attr = NULL;
    ctc_sai_lag_port_info_hash_t* p_lag_port_info_hash = NULL;
    bool port_enable = false;
    ctc_sai_port_entry_t *p_sai_port = NULL;
#ifdef GREATBELT
    ctc_sai_port_entry_t *psaiport_entry = NULL;
    uint32 vid;
    ctc_l2dflt_addr_t l2dflt_addr;

    sal_memset(&l2dflt_addr, 0, sizeof(l2dflt_addr));
#endif
    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        switch(attr->id)
        {
        case SAI_LAG_MEMBER_ATTR_LAG_ID:
            lag_id = attr->value.oid;
            tid = CTC_SAI_OBJECT_INDEX_GET(attr->value.oid); 
            break;

        case SAI_LAG_MEMBER_ATTR_PORT_ID:
            port_id = attr->value.oid;
            gport = CTC_SAI_OBJECT_INDEX_GET(attr->value.oid);
            *lag_member_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_LAG_MEMBER, gport);     
            break;

        default: 
            break;
        }
    }

#ifdef GREATBELT
    /*For GB, once port is bind to lag, it should removed from vlan default entry*/
    psaiport_entry = ctc_sai_port_get_port(port_id);
    if(NULL != psaiport_entry)
    {
        CTC_BMP_ITER_BEGIN(psaiport_entry->vlanbmp, vid)
        {
            l2dflt_addr.fid = vid;
            l2dflt_addr.l2mc_grp_id = vid;
            l2dflt_addr.member.mem_port = gport;
            ctc_l2_remove_port_from_default_entry(&l2dflt_addr);
            
        }
        CTC_BMP_ITER_END(psaiport_entry->vlanbmp, vid);
    }
    
#endif
    /* Modified by kcao 2015-03-25 for bug 37743, SAI does not satisfy LAG member operation
     * should uses ctc_sai_port_set_port_flag() flags
     * SAI_PORT_FLAG_AGGREGATED - add member port to LAG, should disable TX/RX
     * SAI_PORT_FLAG_AGG_OPRED  - member port change to operated, should enable TX/RX
     */
#if 0
    ret = ctc_linkagg_add_port(tid, gport);
    ret = ctc_port_get_mac_en(gport, &port_enable);
    if (ret < 0)
    {
         return ctc_sai_get_error_from_sdk_error(ret);
    }
    if (!port_enable)
    {
         ret = ctc_linkagg_remove_port(tid, gport);
         if (ret < 0)
         {
            return ctc_sai_get_error_from_sdk_error(ret);
         }
    }
#else
    (void)tid;
    (void)port_enable;
#endif
    p_lag_port_info_hash = ctc_sai_lag_port_info_get_by_gport(gport);
    if (NULL == p_lag_port_info_hash)
    {
        p_lag_port_info_hash = ctc_sai_lag_port_info_add_hash(gport);
        p_lag_port_info_hash->lag_member_id = 0;
        p_lag_port_info_hash->portid = 0;
        p_lag_port_info_hash->tid = 0;
    }
    p_lag_port_info_hash->lag_member_id = *lag_member_id;
    p_lag_port_info_hash->tid = tid;
    p_lag_port_info_hash->portid = port_id;

    ctc_sai_acl_lag_member_enable(lag_id, port_id);

    ctc_sai_port_bind_lag_id(port_id, lag_id);

    p_sai_port = ctc_sai_port_entry_get_by_portid(port_id);
    if (p_sai_port)
    {
        p_sai_port->lag_id = lag_id;
    }
    
    return ret;
}

sai_status_t
ctc_sai_lag_remove_lag_member(
    _In_ sai_object_id_t  lag_member_id
    )
{
    uint32 gport = 0;
    uint8  tid = 0;
    sai_status_t ret = SAI_STATUS_SUCCESS;
    ctc_sai_lag_port_info_hash_t* p_lag_port_info_hash = NULL;
    sai_object_id_t portid = 0;
    ctc_sai_port_entry_t *p_sai_port = NULL;
    
#ifdef GREATBELT
    ctc_sai_port_entry_t *psaiport_entry = NULL;
    uint32 vid;
    ctc_l2dflt_addr_t l2dflt_addr;
    sai_object_id_t port_id = 0;

    sal_memset(&l2dflt_addr, 0, sizeof(l2dflt_addr));
#endif

    if (SAI_OBJECT_TYPE_LAG_MEMBER != CTC_SAI_OBJECT_TYPE_GET(lag_member_id))
    {
       return SAI_STATUS_INVALID_PARAMETER;
    }
    
    gport = CTC_SAI_OBJECT_INDEX_GET(lag_member_id);
    p_sai_port = ctc_sai_port_entry_get_by_gport(gport);
    if (p_sai_port)
    {
        p_sai_port->lag_id = 0;
    }
    p_lag_port_info_hash = ctc_sai_lag_port_info_get_by_gport(gport);
    if (NULL == p_lag_port_info_hash)
    {
        return SAI_STATUS_NO_MEMORY;
    }
    
    tid = p_lag_port_info_hash->tid;
    portid = p_lag_port_info_hash->portid;

    ctc_sai_acl_lag_member_disable(portid, CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_LAG, tid));
    ctc_sai_port_bind_lag_id(portid, 0);

    p_lag_port_info_hash->lag_member_id = 0;
    p_lag_port_info_hash->tid = 0;
    p_lag_port_info_hash->portid = 0;
    
    /* Modified by kcao 2015-03-25 for bug 37743, SAI does not satisfy LAG member operation
     * should uses ctc_sai_port_set_port_flag() flags
     * SAI_PORT_FLAG_AGGREGATED - add member port to LAG, should disable TX/RX
     * SAI_PORT_FLAG_AGG_OPRED  - member port change to operated, should enable TX/RX
     */
#if 0     
    ret = ctc_linkagg_remove_port(tid, gport);
#endif
#ifdef GREATBELT
    /*For GB, once port is unbind to lag, it should add to vlan default entry*/
    port_id = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT, gport);
    psaiport_entry = ctc_sai_port_get_port(port_id);
    if(NULL != psaiport_entry)
    {
        CTC_BMP_ITER_BEGIN(psaiport_entry->vlanbmp, vid)
        {
            l2dflt_addr.fid = vid;
            l2dflt_addr.l2mc_grp_id = vid;
            l2dflt_addr.member.mem_port = gport;
            ctc_l2_add_port_to_default_entry(&l2dflt_addr);
            
        }
        CTC_BMP_ITER_END(psaiport_entry->vlanbmp, vid);
    }
    
#endif
    if (ret < 0)
    {
        return ctc_sai_get_error_from_sdk_error(ret);
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_lag_get_ports(
    _In_    sai_object_id_t      lag_id,
    _Inout_ sai_attribute_t*     attr)
{
    int32_t     sdk_ret             = 0;
    uint32_t    port_count_index    = 0;
    uint16_t    pport[255];
    uint8_t     port_cnt            = 255;

    CTC_SAI_ERROR_GOTO(ctc_linkagg_get_member_ports(CTC_SAI_OBJECT_INDEX_GET(lag_id),
            pport,&port_cnt),sdk_ret,out);

    for(port_count_index = 0; port_count_index < port_cnt; port_count_index++)
    {
        if(port_count_index >= attr->value.objlist.count)
        {
            break;
        }
        attr->value.objlist.list[port_count_index] =
            CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_PORT,pport[port_count_index]);
    }

    attr->value.objlist.count = port_count_index;

out:
    return ctc_sai_get_error_from_sdk_error(sdk_ret);
}

int32_t
ctc_sai_lag_alloc_timestamp (sai_object_id_t port_id, uint32_t *ptimestamp_nhid)
{
    ctc_sai_port_entry_t    *pport_entry = NULL;
    ctc_misc_nh_param_t     nh_param;
    uint32_t                nexthopid    = 0;
    sai_status_t            ret 		 = SAI_STATUS_SUCCESS;
    
    sal_memset(&nh_param, 0, sizeof(ctc_misc_nh_param_t));

    pport_entry = &g_ctc_sai_lag_info.agg_entries[CTC_SAI_OBJECT_INDEX_GET(port_id)];
    if(!pport_entry)
        return SAI_STATUS_ITEM_NOT_FOUND;

    nh_param.type = CTC_MISC_NH_TYPE_OVER_L2_WITH_TS;
    sal_memcpy(nh_param.misc_param.over_l2edit.mac_da,
        ctc_sai_get_sys_info()->timestamp.dmac, sizeof(sai_mac_t));
    sal_memcpy(nh_param.misc_param.over_l2edit.mac_sa,
        ctc_sai_get_sys_info()->timestamp.smac, sizeof(sai_mac_t));
    nh_param.misc_param.over_l2edit.ether_type = ctc_sai_get_sys_info()->timestamp.type;
    
    if(pport_entry->timestamp_count == 0) {
        nh_param.gport = (0x1f00 | CTC_SAI_OBJECT_INDEX_GET(port_id));
        CTC_SAI_ERROR_GOTO(ctc_sai_nexthop_alloc_offset(&nexthopid),ret,err);
        CTC_SAI_ERROR_GOTO(ctc_nh_add_misc(nexthopid, &nh_param),ret,err1);

        pport_entry->timestamp_nexthopid = nexthopid;

        CTC_SAI_DEBUG("%s%d:port_oid = 0x%llx,timestamp_nhid = %d\n",
            __FUNCTION__,__LINE__,port_id, pport_entry->timestamp_nexthopid);
    }

    pport_entry->timestamp_count++;
    *ptimestamp_nhid = pport_entry->timestamp_nexthopid;

    CTC_SAI_DEBUG("%s%d:port_oid = 0x%llx,timestamp_count = %d\n",
            __FUNCTION__,__LINE__,port_id, pport_entry->timestamp_count);
    
    return SAI_STATUS_SUCCESS;
err1:
    ctc_sai_nexthop_free_offset(nexthopid);
err:
    CTC_SAI_DEBUG("%s%d:port_oid = 0x%llx\n",__FUNCTION__,__LINE__,port_id);
    return ret;
}

int32_t
ctc_sai_lag_free_timestamp (sai_object_id_t port_id)
{
    ctc_sai_port_entry_t    *pport_entry = NULL;

    pport_entry = &g_ctc_sai_lag_info.agg_entries[CTC_SAI_OBJECT_INDEX_GET(port_id)];
    if(!pport_entry)
        return SAI_STATUS_ITEM_NOT_FOUND;

    pport_entry->timestamp_count--;

    CTC_SAI_DEBUG("%s%d:port_oid = 0x%llx,timestamp_count = %d\n",
            __FUNCTION__,__LINE__,port_id, pport_entry->timestamp_count);
    
    if(pport_entry->timestamp_count <= 0 ){
        CTC_SAI_DEBUG("%s%d:port_oid = 0x%llx,timestamp_nexthopid = %d\n",
            __FUNCTION__,__LINE__,port_id, pport_entry->timestamp_nexthopid);
        
        ctc_nh_remove_misc(pport_entry->timestamp_nexthopid);
        ctc_sai_nexthop_free_offset(pport_entry->timestamp_nexthopid);
    }
    
    return SAI_STATUS_SUCCESS;
}


sai_status_t
__copy_lag_number_port_attr_to_port(
    _In_  sai_object_id_t lag_id,
    _In_  const sai_object_list_t *port_list
)
{
    sai_status_t       ret = SAI_STATUS_SUCCESS;
    sai_attribute_t	attr;
    sai_object_list_t 	lag_portlist;
    sai_attribute_t	port_attr;
    uint32_t        	port_attr_idx;
    uint32_t            port_idx = 0;
    uint32_t            max_count = CTC_MAX_LPORT;

    lag_portlist.list = mem_malloc(MEM_APP_LINKAGG_MODULE,sizeof(sai_object_id_t) * max_count);
    if(!lag_portlist.list)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }

    sal_memset(lag_portlist.list,0,sizeof(sai_object_id_t) * max_count);
    lag_portlist.count  = max_count;
    attr.value.objlist  = lag_portlist;

    CTC_SAI_ERROR_GOTO(ctc_sai_lag_get_ports(lag_id,&attr),ret,out);

    for(port_attr_idx = SAI_PORT_ATTR_SPEED;
        port_attr_idx < SAI_PORT_ATTR_EGRESS_SAMPLEPACKET_ENABLE;
        port_attr_idx++)
    {
        port_attr.id = port_attr_idx;
        CTC_SAI_ERROR_GOTO(
            ctc_sai_get_port_attribute(lag_portlist.list[0],1,&port_attr),ret,out);
        for(port_idx = 0; port_idx < port_list->count; port_idx++)
        {
            CTC_SAI_ERROR_GOTO(
                ctc_sai_set_port_attribute(port_list->list[port_idx],&port_attr),ret,out);
        }
    }

out:
    if(lag_portlist.list)
    {
        mem_free(lag_portlist.list);
        lag_portlist.list = NULL;
    }
    return ret;
}

#define ________SAI_SAI_DEBUG_FUNC
sai_status_t
ctc_sai_remove_lag_debug_param(
    _In_ sai_object_id_t  lag_id)
{
    CTC_SAI_DEBUG("in:lag_id 0x%llx", lag_id);
    return SAI_STATUS_SUCCESS;
}
sai_status_t
ctc_sai_get_lag_attribute_debug_param(
    _In_ sai_object_id_t lag_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    const sai_attribute_t *attr = NULL;
    uint32_t          attr_idx = 0; 

    for (attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        ret = ctc_sai_attr_check_read_attr(g_sai_attr_entries,attr);

        if(ret != SAI_STATUS_SUCCESS)
        {
            return SAI_STATUS_SUCCESS;
        }

        switch(attr->id)
        {
            case SAI_LAG_ATTR_PORT_LIST:
                CTC_SAI_DEBUG("in:SAI_LAG_ATTR_PORT_LIST lag_id 0x%llx", lag_id);
                break;
            default: 
                break;
        }

        if(ret != SAI_STATUS_SUCCESS)
        {
            break;
        }
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_create_lag_member_debug_param(
    _Out_ sai_object_id_t* lag_member_id,
    _In_ uint32_t attr_count,
    _In_ sai_attribute_t *attr_list)
{
    const sai_attribute_t *attr = NULL;
    uint32_t          attr_idx = 0; 

    CTC_SAI_DEBUG("out:lag_member_id 0x%llx", (*lag_member_id));
    for (attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        switch (attr->id)
        {
        case SAI_LAG_MEMBER_ATTR_LAG_ID:
            CTC_SAI_DEBUG("out:SAI_LAG_MEMBER_ATTR_LAG_ID 0x%llx", attr->value.oid);
            break;
        case SAI_LAG_MEMBER_ATTR_PORT_ID:
            CTC_SAI_DEBUG("out:SAI_HOSTIF_ATTR_RIF_OR_PORT_ID 0x%llx", attr->value.oid);
            break;
         default:
            break;
        }
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t ctc_sai_get_lag_member_attribute_debug_param(
    _In_ sai_object_id_t lag_member_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list
    )
{
    const sai_attribute_t *attr = NULL;
    uint32_t          attr_idx = 0; 

    CTC_SAI_DEBUG("in:lag_member_id 0x%llx, attr_count", lag_member_id, attr_count);
    for (attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        switch (attr->id)
        {
        case SAI_LAG_MEMBER_ATTR_LAG_ID:
            CTC_SAI_DEBUG("out:SAI_LAG_MEMBER_ATTR_LAG_ID 0x%llx", attr->value.oid);
            break;
        case SAI_LAG_MEMBER_ATTR_PORT_ID:
            CTC_SAI_DEBUG("out:SAI_LAG_MEMBER_ATTR_PORT_ID 0x%llx", attr->value.oid);
            break;
         default:
            break;
        }
    }

    return SAI_STATUS_SUCCESS;
}
#define ________SAI_SAI_API_FUNC

/*
    \brief Create LAG
    \param[out] lag_id LAG id
    \param[in] attr_count number of attributes
    \param[in] attr_list array of attributes
    \return Success: SAI_STATUS_SUCCESS
            Failure: Failure status code on error
*/
sai_status_t
ctc_sai_create_lag(
    _Out_ sai_object_id_t* lag_id,
    _In_ uint32_t attr_count,
    _In_ sai_attribute_t *attr_list)
{
    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_PTR_VALID_CHECK(lag_id);
    return ctc_sai_lag_create(lag_id, attr_count, attr_list);
}

/*
    \brief Remove LAG
    \param[in] lag_id LAG id
    \return Success: SAI_STATUS_SUCCESS
            Failure: Failure status code on error
*/
sai_status_t
ctc_sai_remove_lag(
    _In_ sai_object_id_t  lag_id)
{
    CTC_SAI_DEBUG_FUNC();
    ctc_sai_remove_lag_debug_param(lag_id);

    return ctc_sai_lag_remove(lag_id);
}


/*
    \brief Creat lag member id.
    \param[out] lag member id
    \param[in] attr_count number of attributes
    \param[in] attr_list array of attributes
    \return Success: SAI_STATUS_SUCCESS
            Failure: Failure status code on error
*/
sai_status_t
ctc_sai_create_lag_member(
    _Out_ sai_object_id_t* lag_member_id,
    _In_ uint32_t attr_count,
    _In_ sai_attribute_t *attr_list)
{
    sai_status_t ret = SAI_STATUS_SUCCESS;
    
    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_PTR_VALID_CHECK(attr_list);
    CTC_SAI_PTR_VALID_CHECK(lag_member_id);
       
    ret = ctc_sai_lag_creat_lag_member(lag_member_id, attr_count, attr_list);
    if (SAI_STATUS_SUCCESS != ret)
    {
        return ret;
    }

    ctc_sai_create_lag_member_debug_param(lag_member_id, attr_count, attr_list);
    return ret;
}

/*
    \brief Remove lag member id
    \param[in] lag member id
    \return Success: SAI_STATUS_SUCCESS
            Failure: Failure status code on error          
*/
sai_status_t
ctc_sai_remove_lag_member(
    _In_ sai_object_id_t  lag_member_id
    )
{
    CTC_SAI_DEBUG_FUNC();

     return ctc_sai_lag_remove_lag_member(lag_member_id);
}


/*
    \brief Set LAG Attribute
    \param[in] lag_id LAG id
    \param[in] attr Structure containing ID and value to be set
    \return Success: SAI_STATUS_SUCCESS
            Failure: Failure status code on error
*/
sai_status_t
ctc_sai_set_lag_attribute(
    _In_ sai_object_id_t  lag_id,
    _In_ const sai_attribute_t *attr)
{
    CTC_SAI_DEBUG_FUNC();

    return SAI_STATUS_SUCCESS;
}

/*
    \brief Get LAG Attribute
    \param[in] lag_id LAG id
    \param[in] attr_count Number of attributes to be get
    \param[in,out] attr_list List of structures containing ID and value to be get
    \return Success: SAI_STATUS_SUCCESS
            Failure: Failure status code on error
*/

sai_status_t
ctc_sai_get_lag_attribute(
    _In_ sai_object_id_t lag_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_attribute_t* attr        = NULL;
    uint32_t        attr_idx    = 0;

    CTC_SAI_DEBUG_FUNC();
    ctc_sai_get_lag_attribute_debug_param(lag_id, attr_count, attr_list);
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        ret = ctc_sai_attr_check_read_attr(g_sai_attr_entries,attr);

        if(ret != SAI_STATUS_SUCCESS)
        {
            return ret + attr_idx;
        }

        switch(attr->id)
        {
            case SAI_LAG_ATTR_PORT_LIST:
                ret = ctc_sai_lag_get_ports(lag_id,attr);
                break;
                
            default: 
            break;
        }

        if(ret != SAI_STATUS_SUCCESS)
        {
            break;
        }
    }

    return SAI_STATUS_SUCCESS;
}

/*
    \brief Set LAG Member Attribute
    \param[in] lag_member_id LAG Member id
    \param[in] attr Structure containing ID and value to be set
    \return Success: SAI_STATUS_SUCCESS
            Failure: Failure status code on error
*/
sai_status_t ctc_sai_set_lag_member_attribute(
    _In_ sai_object_id_t  lag_member_id,
    _In_ const sai_attribute_t *attr
    )
{
    CTC_SAI_DEBUG_FUNC();

    return SAI_STATUS_SUCCESS;
}

/*
    \brief Get LAG Member Attribute
    \param[in] lag_member_id LAG Member id
    \param[in] attr_count Number of attributes to be get
    \param[in,out] attr_list List of structures containing ID and value to be get
    \return Success: SAI_STATUS_SUCCESS
            Failure: Failure status code on error
*/

sai_status_t ctc_sai_get_lag_member_attribute(
    _In_ sai_object_id_t lag_member_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list
    )
{
     uint32_t          attr_idx = 0;
     uint32            gport = 0;
     sai_attribute_t*  attr = NULL;
     ctc_sai_lag_port_info_hash_t* p_lag_port_info_hash = NULL;
 
     CTC_SAI_DEBUG_FUNC();

     if (SAI_OBJECT_TYPE_LAG_MEMBER != CTC_SAI_OBJECT_TYPE_GET(lag_member_id))
     {
        return SAI_STATUS_INVALID_PARAMETER;
     }
     gport = CTC_SAI_OBJECT_INDEX_GET(lag_member_id);
     CTC_SAI_PTR_VALID_CHECK(attr_list); 

     p_lag_port_info_hash = ctc_sai_lag_port_info_get_by_gport(gport);
     if(NULL == p_lag_port_info_hash)
     {
         return SAI_STATUS_INVALID_PARAMETER;
     }

     if (0 == p_lag_port_info_hash->lag_member_id)
     {
           return SAI_STATUS_ITEM_NOT_FOUND;
     }
     for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
     {
        attr = attr_list + attr_idx;
        switch(attr->id)
        {
        case SAI_LAG_MEMBER_ATTR_LAG_ID:
            attr->value.oid = p_lag_port_info_hash->lag_member_id;
            break;
            
        case  SAI_LAG_MEMBER_ATTR_PORT_ID:
            attr->value.oid = lag_member_id;
            break;
            
        default: /*not support other field */
            break;
        }
     }
    ctc_sai_get_lag_member_attribute_debug_param(lag_member_id, attr_count, attr_list);
    return SAI_STATUS_SUCCESS;
}

#define ________SAI_INNER_FUNC
static sai_status_t
__init_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    ret = ctc_sai_lag_db_init();
    if(SAI_STATUS_SUCCESS != ret)
    {
        return ret;
    }

    preg->init_status =  INITIALIZED;

    return ret;
}

static sai_status_t
__exit_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}

/* define sai 0.9.2 */
static sai_lag_api_t      g_sai_api_func = {
    .create_lag           = ctc_sai_create_lag,
    .remove_lag           = ctc_sai_remove_lag,
    .set_lag_attribute    = ctc_sai_set_lag_attribute,
    .get_lag_attribute    = ctc_sai_get_lag_attribute,
    .create_lag_member     = ctc_sai_create_lag_member,
    .remove_lag_member     = ctc_sai_remove_lag_member,
    .set_lag_member_attribute  = ctc_sai_set_lag_member_attribute,
    .get_lag_member_attribute  = ctc_sai_get_lag_member_attribute,
};

static ctc_sai_api_reg_info_t g_api_reg_info = {
        .id  		= SAI_API_LAG,
        .init_func 	= __init_mode_fn,
        .exit_func 	= __exit_mode_fn,
        .api_method_table = &g_sai_api_func,
        .private_data     = NULL,
};

#define ________SAI_OUTER_FUNC
sai_status_t
ctc_sai_lag_init()
{
    api_reg_register_fn(&g_api_reg_info);

    return SAI_STATUS_SUCCESS;
}


#if !defined (__CTC_SAI_STP_H_)
#define __CTC_SAI_STP_H_

#include <sai.h>
#include <ctc_opf.h>
#include <ctc_vector.h>

#define CTC_SAI_VLAN_BITMAP_ARRAY       128     /* 4096 div 32 == 128 */

typedef struct ctc_sai_stp_entry_s
{
    int32_t                ref;
    sai_object_id_t     stp_id;
    uint32_t                vlan_bitmap[CTC_SAI_VLAN_BITMAP_ARRAY];
}ctc_sai_stp_entry_t;

typedef struct ctc_sai_stp_info_s
{
    uint32_t        max_count;
    ctc_opf_t       opf;
    ctc_vector_t*   pvector;
}ctc_sai_stp_info_t;

sai_status_t
ctc_sai_create_stp_inst(
    _Out_ sai_object_id_t *,
    _In_  uint32_t,
    _In_  const sai_attribute_t *);

ctc_sai_stp_entry_t*
ctc_sai_stp_get_by_oid(
    _In_  const sai_object_id_t);

sai_status_t
ctc_sai_stp_add_vlan(
    _In_  ctc_sai_stp_entry_t*,
    _In_  const sai_vlan_id_t);

sai_status_t
ctc_sai_stp_remove_vlan(
    _In_  ctc_sai_stp_entry_t*,
    _In_  const sai_vlan_id_t);

void
ctc_sai_stp_release(
    _In_  ctc_sai_stp_entry_t*);

sai_status_t
ctc_sai_stp_init(void);


#endif


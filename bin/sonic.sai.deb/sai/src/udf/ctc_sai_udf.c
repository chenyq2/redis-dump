#include <sal.h>
#include "ctc_api.h"
#include <sai.h>
#include <saitypes.h>
#include <saistatus.h>
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_sai.h>
#include <ctc_sai_debug.h>
#include <ctc_sai_udf.h>

#define 	CTC_SAI_UDF_RES				64
#define 	CTC_SAI_UDF_BLOCK_SIZE		32

static ctc_sai_udf_info_t  g_sai_udf_info;


static sai_status_t
__udf_create(ctc_sai_udf_info_t **ppudf_info_entry)
{
    sai_status_t            ret 		        = SAI_STATUS_SUCCESS;
    ctc_sai_udf_info_t    	*pudf_info_entry 	= NULL;
    uint32_t                opf_index;

    /* 1: check res */
    if (g_sai_udf_info.total_count >= g_sai_udf_info.max_count)
    {
        ret = SAI_STATUS_TABLE_FULL;
        goto out;
    }

    /* 2: alloc index */
    CTC_SAI_ERROR_GOTO_MAPSDKERR2SAI(
        ctc_opf_alloc_offset(&g_sai_udf_info.udf_opf,0,&opf_index),ret,out);

    /* 3: malloc mem */
    pudf_info_entry = mem_malloc(MEM_APP_UDF_MODULE,sizeof(ctc_sai_udf_info_t));
    if (NULL == pudf_info_entry)
    {
        ret = SAI_STATUS_NO_MEMORY;
        ctc_opf_free_offset(&g_sai_udf_info.udf_opf,0,opf_index);
        goto out;
    }
    
    sal_memset(pudf_info_entry, 0, sizeof(ctc_sai_udf_info_t));

    /* 4: set OID */
    *ppudf_info_entry = pudf_info_entry;
    pudf_info_entry->oid = CTC_SAI_OBJECT_TYPE_SET(SAI_OBJECT_TYPE_UDF,opf_index);

    /* 5: save to vector */
    ctc_vector_add(g_sai_udf_info.pudf_vector, opf_index, pudf_info_entry);

    g_sai_udf_info.total_count++;

    CTC_SAI_DEBUG("__udf_create:udf_oid = 0x%llx\n",pudf_info_entry->oid);

out:
    return ret;
}

void
__udf_remove(
    _In_  ctc_sai_udf_info_t* pudf_info_entry)
{
    if(NULL == pudf_info_entry)
    {
        return ;
    }

    CTC_SAI_DEBUG("__udf_remove:udf_oid = 0x%llx\n",pudf_info_entry->oid);

    /* 1: remove vector */
    ctc_vector_del( g_sai_udf_info.pudf_vector, 
                    CTC_SAI_OBJECT_INDEX_GET(pudf_info_entry->oid));

    /* 2: free index */
    ctc_opf_free_offset(&g_sai_udf_info.udf_opf,0,
                            CTC_SAI_OBJECT_INDEX_GET(pudf_info_entry->oid));

    /* 3: free mem */
    mem_free(pudf_info_entry);

    g_sai_udf_info.total_count--;
}

ctc_sai_udf_info_t*
ctc_sai_udf_get_by_oid(sai_object_id_t  udf_oid)
{
    return ctc_vector_get( g_sai_udf_info.pudf_vector, 
                    CTC_SAI_OBJECT_INDEX_GET(udf_oid));
}


static sai_status_t ctc_sai_create_udf(
    _Out_ sai_object_id_t* udf_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list
    )
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_attribute_t const *pattr_entry = NULL;
    ctc_sai_udf_info_t         *pudf_info = NULL;
    uint32_t index = 0;

    CTC_SAI_DEBUG_FUNC();
    
    CTC_SAI_PTR_VALID_CHECK(udf_id);
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    ret = __udf_create(&pudf_info);
    if(SAI_STATUS_SUCCESS != ret)
    {
        return ret;
    }
    
    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_UDF_ATTR_MATCH_ID, attr_list, attr_count, &index);
    if (NULL != pattr_entry)
    {
        pudf_info->u.udf.udf_match_id = pattr_entry->value.oid;
    }

    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_UDF_ATTR_GROUP_ID, attr_list, attr_count, &index);
    if (pattr_entry)
    {
        pudf_info->u.udf.udf_group_id = pattr_entry->value.oid;
    }

    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_UDF_ATTR_BASE, attr_list, attr_count, &index);
    if (pattr_entry)
    {
        pudf_info->u.udf.udf_base_select = pattr_entry->value.s32;
    }

    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_UDF_ATTR_OFFSET, attr_list, attr_count, &index);
    if (pattr_entry)
    {
        pudf_info->u.udf.udf_offset = pattr_entry->value.u16;
    }

    pudf_info->info_type = CTC_SAI_UDF_INFO_TYPE_UDF;
    g_sai_udf_info.udf_cnt++;

    *udf_id = pudf_info->oid;
    
    return SAI_STATUS_SUCCESS;
}


static sai_status_t ctc_sai_remove_udf(
    _In_ sai_object_id_t udf_id
    )
{
    ctc_sai_udf_info_t      *pudf_info_entry    = NULL;

    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_DEBUG("ctc_sai_remove_udf:udf_id = 0x%llx\n",udf_id);

    pudf_info_entry = ctc_sai_udf_get_by_oid(udf_id);
    if(NULL == pudf_info_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }
    __udf_remove(pudf_info_entry);
    g_sai_udf_info.udf_cnt--;

    return SAI_STATUS_SUCCESS;
}


static sai_status_t ctc_sai_set_udf_attribute(
    _In_ sai_object_id_t udf_id,
    _In_ const sai_attribute_t *attr
    )
{
    return SAI_STATUS_SUCCESS;
}

static sai_status_t ctc_sai_get_udf_attribute(
    _In_ sai_object_id_t udf_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list
    )
{
    return SAI_STATUS_SUCCESS;
}

static sai_status_t ctc_sai_create_udf_match(
    _Out_ sai_object_id_t* udf_match_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list
    )
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_attribute_t const *pattr_entry = NULL;
    ctc_sai_udf_info_t         *pudf_info = NULL;
    uint32_t index = 0;

    CTC_SAI_DEBUG_FUNC();
    
    CTC_SAI_PTR_VALID_CHECK(udf_match_id);
    CTC_SAI_PTR_VALID_CHECK(attr_list);

    ret = __udf_create(&pudf_info);
    if(SAI_STATUS_SUCCESS != ret)
    {
        return ret;
    }
    
    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_UDF_MATCH_ATTR_L2_TYPE, attr_list, attr_count, &index);
    if (NULL != pattr_entry)
    {
        pudf_info->u.udf_match.udf_match_l2_type = pattr_entry->value.u16;
    }

    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_UDF_MATCH_ATTR_L3_TYPE, attr_list, attr_count, &index);
    if (pattr_entry)
    {
        pudf_info->u.udf_match.udf_match_l3_type = pattr_entry->value.u8;
    }

    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_UDF_MATCH_ATTR_GRE_TYPE, attr_list, attr_count, &index);
    if (pattr_entry)
    {
        pudf_info->u.udf_match.udf_match_gre_type = pattr_entry->value.u16;
    }

    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_UDF_MATCH_ATTR_PRIORITY, attr_list, attr_count, &index);
    if (pattr_entry)
    {
        pudf_info->u.udf_match.udf_match_priority = pattr_entry->value.u8;
    }

    pudf_info->info_type = CTC_SAI_UDF_INFO_TYPE_MATCH;
    g_sai_udf_info.udf_match_cnt++;

    *udf_match_id = pudf_info->oid;
    
    return SAI_STATUS_SUCCESS;
}

static sai_status_t ctc_sai_remove_udf_match(
    _In_ sai_object_id_t udf_match_id
    )
{
    ctc_sai_udf_info_t      *pudf_info_entry    = NULL;

    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_DEBUG("ctc_sai_remove_udf_match:udf_id = 0x%llx\n",udf_match_id);

    pudf_info_entry = ctc_sai_udf_get_by_oid(udf_match_id);
    if(NULL == pudf_info_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }
    __udf_remove(pudf_info_entry);
    g_sai_udf_info.udf_match_cnt--;
    
    return SAI_STATUS_SUCCESS;
}

static sai_status_t ctc_sai_set_udf_match_attribute(
    _In_ sai_object_id_t udf_match_id,
    _In_ const sai_attribute_t *attr
    )
{
    return SAI_STATUS_SUCCESS;
}

static sai_status_t ctc_sai_get_udf_match_attribute(
    _In_ sai_object_id_t udf_match_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list
    )
{
    return SAI_STATUS_SUCCESS;
}
static sai_status_t ctc_sai_create_udf_group(
    _Out_ sai_object_id_t* udf_group_id,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list
    )
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    sai_attribute_t const *pattr_entry = NULL;
    ctc_sai_udf_info_t *pudf_info = NULL;
    ctc_sai_udf_info_t *search_udf_info_entry = NULL;
    ctc_sai_udf_info_t *search_udf_match_entry = NULL;
    uint32_t index = 0;
    uint32_t i = 0;
    uint32_t j = 0;
    uint32_t udf_index = 0xFFFFFFFF;
    ctc_parser_udf_t udf;

    CTC_SAI_DEBUG_FUNC();
    
    CTC_SAI_PTR_VALID_CHECK(udf_group_id);
    CTC_SAI_PTR_VALID_CHECK(attr_list);
    sal_memset(&udf, 0, sizeof(ctc_parser_udf_t));

    ret = __udf_create(&pudf_info);
    if(SAI_STATUS_SUCCESS != ret)
    {
        return ret;
    }
    
    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_UDF_GROUP_ATTR_UDF_LIST, attr_list, attr_count, &index);
    if (NULL != pattr_entry)
    {
        for (i = 0; i < pattr_entry->value.objlist.count; i++)
        {
            pudf_info->u.udf_group.udf_oid[i] = pattr_entry->value.objlist.list[i];
        }
    }

    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_UDF_GROUP_ATTR_TYPE, attr_list, attr_count, &index);
    if (pattr_entry)
    {
        pudf_info->u.udf_group.udf_group_type = pattr_entry->value.s32;
    }

    pattr_entry = ctc_sai_attr_get_attr_by_id(SAI_UDF_ATTR_LENGTH, attr_list, attr_count, &index);
    if (pattr_entry)
    {
        pudf_info->u.udf_group.udf_length = pattr_entry->value.u16;
        udf.udf_num = pudf_info->u.udf_group.udf_length & 0xFF;
    }
   
    for (i = 0; i < CTC_SAI_UDF_GROUP_UDF_OID_MAX && 0 != pudf_info->u.udf_group.udf_oid[i]; i++)
    {
        search_udf_info_entry = ctc_sai_udf_get_by_oid(pudf_info->u.udf_group.udf_oid[i]);
        if (search_udf_info_entry && search_udf_info_entry->info_type == CTC_SAI_UDF_INFO_TYPE_UDF)
        {
            if (search_udf_info_entry->u.udf.udf_base_select == SAI_UDF_BASE_L3)
            {
                udf.type = CTC_PARSER_UDF_TYPE_L3_UDF;
            }
            else if (search_udf_info_entry->u.udf.udf_base_select == SAI_UDF_BASE_L4)
            {
                udf.type = CTC_PARSER_UDF_TYPE_L4_UDF;
            }
            else
            {
                return SAI_STATUS_NOT_SUPPORTED;
            }

            for (j = 0; j < udf.udf_num && j < CTC_PARSER_UDF_FIELD_NUM; j++)
            {
                udf.udf_offset[j] = (search_udf_info_entry->u.udf.udf_offset & 0xFF) + j;
            }
            
            search_udf_match_entry = ctc_sai_udf_get_by_oid(search_udf_info_entry->u.udf.udf_match_id);
            if (search_udf_match_entry && search_udf_match_entry->info_type == CTC_SAI_UDF_INFO_TYPE_MATCH)
            {
                if (CTC_PARSER_UDF_TYPE_L3_UDF == udf.type)
                {
                    udf.ether_type = search_udf_match_entry->u.udf_match.udf_match_l2_type;
                }
                if (CTC_PARSER_UDF_TYPE_L4_UDF == udf.type)
                {
                    udf.ip_version = CTC_IP_VER_4;
                    udf.l3_header_protocol = search_udf_match_entry->u.udf_match.udf_match_l3_type;
                }

                CTC_SAI_DEBUG("ctc_sai_create_udf_group:udf_l3_header_protocol = %d\n",udf.l3_header_protocol);
                ret = ctc_parser_set_udf(udf_index, &udf);
                if (ret)
                {
                    return ret;
                }
            }
        }
    }

    pudf_info->info_type = CTC_SAI_UDF_INFO_TYPE_GROUP;
    g_sai_udf_info.udf_group_cnt++;

    *udf_group_id = pudf_info->oid;
    
    return SAI_STATUS_SUCCESS;
}

static sai_status_t ctc_sai_remove_udf_group(
    _In_ sai_object_id_t udf_group_id
    )
{
    sai_status_t ret = SAI_STATUS_SUCCESS;
    ctc_sai_udf_info_t *pudf_info = NULL;
    uint32_t i = 0;
    uint32_t udf_index = 0xFFFFFFFF;
    ctc_parser_udf_t udf;
    ctc_sai_udf_info_t *search_udf_info_entry = NULL;
    ctc_sai_udf_info_t *search_udf_match_entry = NULL;

    CTC_SAI_DEBUG_FUNC();

    CTC_SAI_DEBUG("ctc_sai_remove_udf_group:udf_id = 0x%llx\n",udf_group_id);
    sal_memset(&udf, 0, sizeof(ctc_parser_udf_t));
    
    pudf_info = ctc_sai_udf_get_by_oid(udf_group_id);
    if(NULL == pudf_info)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    for (i = 0; i < CTC_SAI_UDF_GROUP_UDF_OID_MAX && 0 != pudf_info->u.udf_group.udf_oid[i]; i++)
    {
        search_udf_info_entry = ctc_sai_udf_get_by_oid(pudf_info->u.udf_group.udf_oid[i]);
        if (search_udf_info_entry && search_udf_info_entry->info_type == CTC_SAI_UDF_INFO_TYPE_UDF)
        {
            if (search_udf_info_entry->u.udf.udf_base_select == SAI_UDF_BASE_L3)
            {
                udf.type = CTC_PARSER_UDF_TYPE_L3_UDF;
            }
            else if (search_udf_info_entry->u.udf.udf_base_select == SAI_UDF_BASE_L4)
            {
                udf.type = CTC_PARSER_UDF_TYPE_L4_UDF;
            }
            else
            {
                return SAI_STATUS_NOT_SUPPORTED;
            }

            search_udf_match_entry = ctc_sai_udf_get_by_oid(search_udf_info_entry->u.udf.udf_match_id);
            if (search_udf_match_entry && search_udf_match_entry->info_type == CTC_SAI_UDF_INFO_TYPE_MATCH)
            {
                if (CTC_PARSER_UDF_TYPE_L3_UDF == udf.type)
                {
                    udf.ether_type = search_udf_match_entry->u.udf_match.udf_match_l2_type;
                }
                if (CTC_PARSER_UDF_TYPE_L4_UDF == udf.type)
                {
                    udf.ip_version = CTC_IP_VER_4;
                    udf.l3_header_protocol = search_udf_match_entry->u.udf_match.udf_match_l3_type;
                }
                ret = ctc_parser_set_udf(udf_index, &udf);
                if (ret)
                {
                    return ret;
                }
            }
        }
    }

    __udf_remove(pudf_info);
    g_sai_udf_info.udf_group_cnt--;

    return SAI_STATUS_SUCCESS;
}

static sai_status_t ctc_sai_set_udf_group_attribute(
    _In_ sai_object_id_t udf_group_id,
    _In_ const sai_attribute_t *attr
    )
{
    return SAI_STATUS_SUCCESS;
}

static sai_status_t ctc_sai_get_udf_group_attribute(
    _In_ sai_object_id_t udf_group_id,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list
    )
{
    return SAI_STATUS_SUCCESS;
}



#define ________SAI_UDF_INNER_FUNC

sai_status_t
ctc_sai_udf_db_init()
{
    CTC_SAI_DEBUG_FUNC();
    sal_memset(&g_sai_udf_info, 0, sizeof(g_sai_udf_info));

    g_sai_udf_info.max_count = CTC_SAI_UDF_RES;
    g_sai_udf_info.pudf_vector = ctc_vector_init(CTC_SAI_UDF_RES, CTC_SAI_UDF_BLOCK_SIZE);

    if (NULL == g_sai_udf_info.pudf_vector)
    {
        return SAI_STATUS_NO_MEMORY;
    }

    if (0 != ctc_opf_init(CTC_OPF_SAI_UDF_ID, 1))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    g_sai_udf_info.udf_opf.pool_type = CTC_OPF_SAI_UDF_ID;
    g_sai_udf_info.udf_opf.pool_index = 0;

    if (0 != ctc_opf_init_offset(&g_sai_udf_info.udf_opf, 1, g_sai_udf_info.max_count))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    return SAI_STATUS_SUCCESS;
}


sai_status_t __udf_init_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;
    ret = ctc_sai_udf_db_init();

    if(SAI_STATUS_SUCCESS != ret)
    {
        goto out;
    }

    preg->init_status =  INITIALIZED;

out:
    return ret;
}

sai_status_t __udf_exit_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}

/* define sai 0.9.2 */
static sai_udf_api_t      g_sai_udf_api_func = {

    .create_udf                 = ctc_sai_create_udf,
    .remove_udf                 = ctc_sai_remove_udf,
    .set_udf_attribute          = ctc_sai_set_udf_attribute,
    .get_udf_attribute          = ctc_sai_get_udf_attribute,
    .create_udf_match           = ctc_sai_create_udf_match,
    .remove_udf_match           = ctc_sai_remove_udf_match,
    .set_udf_match_attribute    = ctc_sai_set_udf_match_attribute,
    .get_udf_match_attribute    = ctc_sai_get_udf_match_attribute,
    .create_udf_group           = ctc_sai_create_udf_group,
    .remove_udf_group           = ctc_sai_remove_udf_group,
    .set_udf_group_attribute    = ctc_sai_set_udf_group_attribute,
    .get_udf_group_attribute    = ctc_sai_get_udf_group_attribute
};


static ctc_sai_api_reg_info_t g_udf_api_reg_info = {
        .id  = SAI_API_UDF,
        .init_func = __udf_init_mode_fn,
        .exit_func = __udf_exit_mode_fn,
        .api_method_table = &g_sai_udf_api_func,
        .private_data     = NULL,
};

#define ________SAI_UDF_OUTER_FUNC
sai_status_t ctc_sai_udf_init()
{
    api_reg_register_fn(&g_udf_api_reg_info);

    return SAI_STATUS_SUCCESS;
}




#include <sai.h>
#include <sal.h>
#include "ctc_api.h"
#include <ctc_sai_fdb.h>
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_notifier_call.h>
#include <ctc_sai_sai.h>
#include <ctc_sai_port.h>
#include <ctc_sai_debug.h>

#undef  __MODULE__
#define __MODULE__ SAI_API_L2MC

typedef struct
{
    sai_l2mc_entry_t    key;
    uint32              group_id;
} sai_l2mc_info_t;

typedef struct ctc_sai_lag_info_s
{
    ctc_opf_t       opf;
    ctc_hash_t      *l2mc_hash;
} ctc_sai_l2mc_info_t;

ctc_sai_l2mc_info_t g_l2mc_info;

static uint32
_sai_l2mc_hash_make(sai_l2mc_info_t *p_l2mc)
{
    uint32 index = 0;
    uint32 key = 0;
    uint8 *pval = NULL;

    pval = (uint8*)&p_l2mc->key;
    for (index = 0; index < sizeof(p_l2mc->key); index++)
    {
        key += pval[index];
    }

    return key;
}

static bool
_sai_l2mc_hash_cmp(void *p_arg1, void *p_arg2)
{
    sai_l2mc_info_t *p_l2mc1 = (sai_l2mc_info_t*)p_arg1;
    sai_l2mc_info_t *p_l2mc2 = (sai_l2mc_info_t*)p_arg2;

    if (0 == sal_memcmp(&p_l2mc1->key, &p_l2mc2->key, sizeof(sai_l2mc_entry_t)))
    {
        return TRUE;
    }

    return FALSE;
}

sai_status_t
ctc_sai_l2mc_alloc_offset(uint32_t *popf_index)
{
    sai_status_t    ret         = SAI_STATUS_SUCCESS;
    uint32          opf_index   = 0;
    
    CTC_SAI_ERROR_GOTO_MAPSDKERR2SAI(
        ctc_opf_alloc_offset(&g_l2mc_info.opf, 0, &opf_index),ret,out);

    *popf_index = opf_index;
    
out:
    return ret;
}

sai_status_t
ctc_sai_l2mc_free_offset(uint32_t opf_index)
{
    sai_status_t    ret         = SAI_STATUS_SUCCESS;
    
    CTC_SAI_ERROR_GOTO_MAPSDKERR2SAI(
        ctc_opf_free_offset(&g_l2mc_info.opf, 0, opf_index),ret,out);
    
out:
    return ret;
}

int32
ctc_sai_mgroup_id_opf_alloc(uint32* p_index)
{
    return ctc_sai_l2mc_alloc_offset(p_index);
}

int32
ctc_sai_mgroup_id_opf_free(uint32 opf_index)
{
    return ctc_sai_l2mc_free_offset(opf_index);
}


sai_l2mc_info_t*
ctc_sai_l2mc_db_get(const sai_l2mc_entry_t* p_l2mc_entry)
{
    return ctc_hash_lookup(g_l2mc_info.l2mc_hash, (void*)p_l2mc_entry);
}

sai_status_t
ctc_sai_l2mc_db_add(const sai_l2mc_entry_t* l2mc_entry, uint32 group_id)
{
    sai_l2mc_info_t *p_l2mc_info = NULL;
    void *p_ret = NULL;

    /* 1. lookup entry exist */
    if (ctc_sai_l2mc_db_get(l2mc_entry))
    {
        return SAI_STATUS_FAILURE;
    }

    /* 2. alloc a new db entry */
    p_l2mc_info = mem_malloc(MEM_APP_L2MC_MODULE, sizeof(sai_l2mc_info_t));
    if (NULL == p_l2mc_info)
    {
        return SAI_STATUS_NO_MEMORY;
    }

    /* 3. evaluate db entry */
    sal_memcpy(&p_l2mc_info->key, l2mc_entry, sizeof(sai_l2mc_entry_t));
    p_l2mc_info->group_id = group_id;

    /* 4. add to db */
    p_ret = ctc_hash_insert(g_l2mc_info.l2mc_hash, p_l2mc_info);
    if (NULL == p_ret)
    {
        return SAI_STATUS_NO_MEMORY;
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_l2mc_db_del(sai_l2mc_info_t *p_db_l2mc_info)
{
    /* 1. delete from db */
    ctc_hash_remove(g_l2mc_info.l2mc_hash, (void*)p_db_l2mc_info);

    /* 2. free db entry */
    mem_free(p_db_l2mc_info);

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_create_l2mc_entry(
    _In_ const sai_l2mc_entry_t* l2mc_entry,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    ctc_l2_mcast_addr_t l2_addr;
    uint32 opf_index = 0;
    int32           sdk_ret = SAI_STATUS_SUCCESS;
    sai_status_t    ret = SAI_STATUS_SUCCESS;
 
    sal_memset(&l2_addr, 0, sizeof(l2_addr));

    sal_memcpy(l2_addr.mac, l2mc_entry->mac_address, sizeof(mac_addr_t));
    l2_addr.fid = l2mc_entry->vlan_id;

    ret = ctc_opf_alloc_offset(&g_l2mc_info.opf, 0, &opf_index);
    if (ret < 0)
    {
        return SAI_STATUS_INSUFFICIENT_RESOURCES;
    }
    l2_addr.l2mc_grp_id = opf_index;

    ret = ctc_sai_l2mc_db_add(l2mc_entry, opf_index);
    if (ret < 0)
    {
        return ret;
    }

    sdk_ret = ctc_l2mcast_add_addr(&l2_addr);
    if (sdk_ret < 0)
    {
        return ctc_sai_get_error_from_sdk_error(sdk_ret);
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_remove_l2mc_entry(
    _In_ const sai_l2mc_entry_t* l2mc_entry)
{
    sai_l2mc_info_t *p_db_l2mc_info = NULL;
    ctc_l2_mcast_addr_t l2_addr;
    int32           sdk_ret = SAI_STATUS_SUCCESS;
    sai_status_t    ret = SAI_STATUS_SUCCESS;
 
    sal_memset(&l2_addr, 0, sizeof(l2_addr));
    sal_memcpy(l2_addr.mac, l2mc_entry->mac_address, sizeof(mac_addr_t));
    l2_addr.fid = l2mc_entry->vlan_id;

    /* 1. lookup entry exist */
    p_db_l2mc_info = ctc_sai_l2mc_db_get(l2mc_entry);
    if (NULL == p_db_l2mc_info)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }
    
    ret = ctc_opf_free_offset(&g_l2mc_info.opf, 0, p_db_l2mc_info->group_id);
    if (ret < 0)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    ctc_sai_l2mc_db_del(p_db_l2mc_info);

    sdk_ret = ctc_l2mcast_remove_addr(&l2_addr);
    if (sdk_ret < 0)
    {
        return ctc_sai_get_error_from_sdk_error(sdk_ret);
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_add_ports_to_l2mc(
    _In_ const sai_l2mc_entry_t* l2mc_entry,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    ctc_l2_mcast_addr_t l2_addr;
    sai_object_id_t port_oid = 0;
    int32           sdk_ret = SAI_STATUS_SUCCESS;
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    if (0 == attr_count || NULL == attr_list)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }
    if (SAI_L2MC_ATTR_PORT_LIST != attr_list[0].id)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }
    if (0 == attr_list[0].value.objlist.count || NULL == attr_list[0].value.objlist.list)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }
    
    sal_memset(&l2_addr, 0, sizeof(l2_addr));

    port_oid = attr_list[0].value.objlist.list[0];
    sal_memcpy(l2_addr.mac, l2mc_entry->mac_address, sizeof(mac_addr_t));
    l2_addr.fid = l2mc_entry->vlan_id;
    ret = ctc_sai_port_objectid_to_gport(port_oid, &l2_addr.member.mem_port);
    if (ret < 0)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }

    sdk_ret = ctc_l2mcast_add_member(&l2_addr);
    if (sdk_ret < 0)
    {
        return ctc_sai_get_error_from_sdk_error(sdk_ret);
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_remove_ports_from_l2mc(
    _In_ const sai_l2mc_entry_t* l2mc_entry,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    ctc_l2_mcast_addr_t l2_addr;
    sai_object_id_t port_oid = 0;
    int32           sdk_ret = SAI_STATUS_SUCCESS;
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    if (0 == attr_count || NULL == attr_list)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }
    if (SAI_L2MC_ATTR_PORT_LIST != attr_list[0].id)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }
    if (0 == attr_list[0].value.objlist.count || NULL == attr_list[0].value.objlist.list)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }
    
    sal_memset(&l2_addr, 0, sizeof(l2_addr));

    port_oid = attr_list[0].value.objlist.list[0];
    sal_memcpy(l2_addr.mac, l2mc_entry->mac_address, sizeof(mac_addr_t));
    l2_addr.fid = l2mc_entry->vlan_id;
    ret = ctc_sai_port_objectid_to_gport(port_oid, &l2_addr.member.mem_port);
    if (ret < 0)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }

    sdk_ret = ctc_l2mcast_remove_member(&l2_addr);
    if (sdk_ret < 0)
    {
        return ctc_sai_get_error_from_sdk_error(sdk_ret);
    }

    return SAI_STATUS_SUCCESS;
}

#define ________SAI_L2MC_INNER_FUNC
static sai_status_t
__init_mode_fn(
    _In_  ctc_sai_api_reg_info_t    *preg,
    _In_  void                      *private_data)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    preg->init_status =  INITIALIZED;
    return ret;
}

static sai_status_t
__exit_mode_fn(
    _In_  ctc_sai_api_reg_info_t    *preg,
    _In_  void                      *private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}

/* define sai 0.9.2 */
static sai_l2mc_api_t      g_l2mc_api_func = {
    .create_l2mc_entry          = ctc_sai_create_l2mc_entry,
    .remove_l2mc_entry          = ctc_sai_remove_l2mc_entry,
    .add_ports_to_l2mc          = ctc_sai_add_ports_to_l2mc,
    .remove_ports_from_l2mc     = ctc_sai_remove_ports_from_l2mc,
    .set_l2mc_entry_attribute   = NULL,
    .get_l2mc_entry_attribute   = NULL,
};

static ctc_sai_api_reg_info_t g_l2mc_api_reg_info = {
        .id         = SAI_API_L2MC,
        .init_func  = __init_mode_fn,
        .exit_func  = __exit_mode_fn,
        .api_method_table = &g_l2mc_api_func,
        .private_data     = NULL,
};

#define ________SAI_L2MC_OUTER_FUNC

sai_status_t
ctc_sai_l2mc_init()
{
    api_reg_register_fn(&g_l2mc_api_reg_info);


    sal_memset(&g_l2mc_info, 0, sizeof(g_l2mc_info));

    if (0 != ctc_opf_init(CTC_OPF_SAI_L2MC_GROUP_ID, 1))
    {
        return SAI_STATUS_NO_MEMORY;
    }

    g_l2mc_info.opf.pool_type = CTC_OPF_SAI_L2MC_GROUP_ID;
    g_l2mc_info.opf.pool_index = 0;
#ifdef OFPRODUCT
    if (0 != ctc_opf_init_offset(&g_l2mc_info.opf, 4096, 4504))
    {
        return SAI_STATUS_NO_MEMORY;
    }
#else
    if (0 != ctc_opf_init_offset(&g_l2mc_info.opf, 4096, 2048))
    {
        return SAI_STATUS_NO_MEMORY;
    }
#endif
    g_l2mc_info.l2mc_hash = ctc_hash_create(64, 32, (hash_key_fn)_sai_l2mc_hash_make, (hash_cmp_fn)_sai_l2mc_hash_cmp);
        
    return SAI_STATUS_SUCCESS;
}


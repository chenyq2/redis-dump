#if !defined (__CTC_ROUTE_H_)
#define __CTC_ROUTE_H_

#include <ctc_sai_router.h>

#define CTC_SAI_ROUTE_MAX_ENTRY  32768

typedef struct ctc_route_entry_s
{
    sai_unicast_route_entry_t               key;
    uint32_t                                action;
    uint32_t                                cur_action;
    uint32_t                                priority;
    struct ctc_sai_vr_entry_s*              pvr_entry;
    sai_object_id_t                         nexthop_id;
    sai_object_id_t                         rif_id;
}ctc_route_entry_t;

typedef struct ctc_route_info_s
{
    ctc_hash_t*     phash;
    uint32_t        max_count;
}ctc_route_info_t;

sai_status_t ctc_sai_route_init();




#endif


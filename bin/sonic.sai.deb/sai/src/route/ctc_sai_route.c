#include <sal.h>
#include <sai.h>
#include <ctc_sai_common.h>
#include <ctc_sai_common_attr.h>
#include <ctc_sai_sai.h>
#include "ctc_sai_route.h"
#include <ctc_sai_nexthop_group.h>
#include <ctc_vector.h>
#include <ctc_sai_nexthop.h>
#include <ctc_sai_nexthop_group.h>
#include <ctc_sai_notifier_call.h>
#include <ctc_api.h>
#include <ctc_sai_debug.h>

#define ROUTE_HASH_B	128

static ctc_sai_attr_entry_info_t g_sai_attr_entries[] = {
    {
        .id     = SAI_ROUTE_ATTR_PACKET_ACTION,
        .type   = SAI_ATTR_FALG_WRITE| SAI_ATTR_FALG_READ | SAI_ATTR_FLAG_DEFAULT,
        .default_value.s32 = SAI_PACKET_ACTION_FORWARD,
    },
    {
        .id     = SAI_ROUTE_ATTR_TRAP_PRIORITY,
        .type   = SAI_ATTR_FALG_WRITE| SAI_ATTR_FALG_READ | SAI_ATTR_FLAG_DEFAULT,
        .default_value.u8 = 0,
    },
    {
        .id     = SAI_ROUTE_ATTR_NEXT_HOP_ID,
        .type   = SAI_ATTR_FALG_WRITE| SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_ROUTE_ATTR_RIF_ID,
        .type   = SAI_ATTR_FALG_WRITE| SAI_ATTR_FALG_READ,
    },
    {
        .id     = SAI_ATTR_ID_END,
        .type   = 0,
    },
};

static struct ctc_route_info_s g_ctc_route_info;

#define ________SAI_SAI_INNER_API_FUNC
static uint32
__ctc_route_hash_make(sai_unicast_route_entry_t* key)
{
    return ctc_hash_caculate(sizeof(sai_unicast_route_entry_t),key);
}

static bool
__ctc_route_hash_cmp(sai_unicast_route_entry_t* key1,
								sai_unicast_route_entry_t* key2)
{
    if(sal_memcmp(key1,key2,sizeof(sai_unicast_route_entry_t)))
	{
		return false;
	}

    return true;
}

static int32
ctc_sai_route_add_default_ipuc_entry()
{
    uint32 nhid;
    ctc_ipuc_param_t ipuc_info;
    int32 ret = SAI_STATUS_SUCCESS;

    nhid = NEIGHBOR_ACTION_TRAP_NHID;

    /*when overlay is enabled, we add vrf = 0 default route to tcam because we are in sdk default route tcam mode*/
    sal_memset(&ipuc_info, 0, sizeof(ctc_ipuc_param_t));
    ipuc_info.ip_ver = CTC_IP_VER_4;
    ipuc_info.vrf_id = 0;
    ipuc_info.nh_id = nhid;     /* modified by ychen in 2014-01-21 for bug 26942 */
    ipuc_info.is_ecmp_nh = 0;
    ipuc_info.route_flag = CTC_IPUC_FLAG_RPF_CHECK;
    ret = ctc_ipuc_add(&ipuc_info);

    return ret;
}

static int32
ctc_sai_route_add_default_route()
{
    uint32 nhid;
    uint32 ipv6_en;
    ctc_ipuc_param_t ipuc_info;
    int32 ret = SAI_STATUS_SUCCESS;

    /*1. get values and dump*/

    /*2.set to SDK*/
    nhid = NEIGHBOR_ACTION_TRAP_NHID;
    ipv6_en = FALSE;
    CTC_SAI_DEBUG("  default route nhid=%d.", nhid);

    /*when overlay is enabled, we add vrf = 0 default route to tcam because we are in sdk default route tcam mode*/
    sal_memset(&ipuc_info, 0, sizeof(ctc_ipuc_param_t));
    ipuc_info.ip_ver = CTC_IP_VER_4;
    ipuc_info.vrf_id = 0;
    ipuc_info.nh_id = nhid;     /* modified by ychen in 2014-01-21 for bug 26942 */
    ipuc_info.is_ecmp_nh = 0;
#ifndef OFPRODUCT
    ipuc_info.route_flag = CTC_IPUC_FLAG_RPF_CHECK;
#endif
    ret = ctc_ipuc_add(&ipuc_info);

    /* Modified by wangjj for init l3 multicast default entry, 2016-08-03 */
    ctc_ipmc_add_default_entry(CTC_IP_VER_4, CTC_IPMC_DEFAULT_ACTION_TO_CPU);

    if (ipv6_en)
    {
        ctc_ipuc_param_t ipuc_info;
        ctc_ipmc_force_route_t mcv6_route;

        sal_memset(&ipuc_info, 0, sizeof(ctc_ipuc_param_t));
        ipuc_info.ip_ver = CTC_IP_VER_6;
        ipuc_info.vrf_id = 0;
        ipuc_info.nh_id = nhid;  /*modified by ychen in 2014-01-21 for bug 26942*/
        ipuc_info.is_ecmp_nh = 0;
        ipuc_info.route_flag = CTC_IPUC_FLAG_RPF_CHECK;
        ret = ctc_ipuc_add(&ipuc_info);

        /*set martion address*/
        sal_memset(&ipuc_info, 0, sizeof(ctc_ipuc_param_t));
        ipuc_info.nh_id = CTC_NH_RESERVED_NHID_FOR_DROP;
        ipuc_info.is_ecmp_nh = 0;

        ipuc_info.ip_ver = CTC_IP_VER_6;
        /*a) drop ::/128*/
        ipuc_info.masklen = 128;
        ret = ctc_ipuc_add(&ipuc_info);

        /*b) drop ::1/128*/
        /*modified by ychen in 2012-05-29 for version 92006 when merge sdk code,
        use SYS_IP_ADDRESS_SORT instead. use ipv6[3] instead of ipv6[0]*/
        ipuc_info.ip.ipv6[3] = 1;
        ipuc_info.masklen = 128;
        ret = ctc_ipuc_add(&ipuc_info);

        /*c). set mcast address in order to send ndp, ospf packet to cpu via force bridge when packet
        is multicast
        #define ALLNODE                            "ff02::1"
        #define ALLROUTER                        "ff02::2"
        #define SOLICITED_PREFIX            "ff02::1:ff00:0"*/
        sal_memset(&mcv6_route, 0, sizeof(ctc_ipmc_force_route_t));
        mcv6_route.ip_version = CTC_IP_VER_6;
        mcv6_route.force_bridge_en = 1;
        //mcv6_route.force_ucast_en = 1;

        mcv6_route.ipaddr0_valid = 1;
        mcv6_route.ip_addr0.ipv6[0] = 0xFF020000;
        mcv6_route.ip_addr0.ipv6[1] = 0x00000000;
        mcv6_route.ip_addr0.ipv6[2] = 0x00000000;
        mcv6_route.ip_addr0.ipv6[3] = 0x00000000;
        mcv6_route.addr0_mask = 120;
        //ret = ctc_ipmc_set_mcast_force_route(&mcv6_route);

        mcv6_route.ipaddr1_valid = 1;
        mcv6_route.ip_addr1.ipv6[0] = 0xFF020000;
        mcv6_route.ip_addr1.ipv6[1] = 0x00000000;
        mcv6_route.ip_addr1.ipv6[2] = 0x00000001;
        mcv6_route.ip_addr1.ipv6[3] = 0xFF000000;
        mcv6_route.addr1_mask = 104;
        ret = ctc_ipmc_set_mcast_force_route(&mcv6_route);
    }

    (void)ret;
    return SAI_STATUS_SUCCESS;
}

static int32
ctc_sai_route_add_ipda_martion()
{
    ctc_ipuc_param_t ipuc_info;
    ctc_ipuc_global_property_t rt_ctl;
    int32 ret = CTC_E_NONE;

    /*1. init*/
    sal_memset(&ipuc_info, 0, sizeof(ctc_ipuc_param_t));
    ipuc_info.nh_id = NEIGHBOR_ACTION_DROP_NHID;
    ipuc_info.is_ecmp_nh = 0;

    ipuc_info.ip_ver = CTC_IP_VER_4;
    /*2. for ipv4 default route*/
    /*a) drop 0.x.x.x/8 */
    ipuc_info.ip.ipv4 = 0;
    ipuc_info.masklen = 8;
    ret = ctc_ipuc_add(&ipuc_info);

    /*b) drop 127.x.x.x/8*/
    ipuc_info.ip.ipv4 = 0x7f000000;
    ipuc_info.masklen = 8;
    ret = ctc_ipuc_add(&ipuc_info);

    /*c) 255.255.255.255/32*/
    ipuc_info.ip.ipv4 = 0xffffffff;
    ipuc_info.masklen = 32;
    ret = ctc_ipuc_add(&ipuc_info);

    /*3. set martion address check enable*/
    sal_memset(&rt_ctl, 0, sizeof(ctc_ipuc_global_property_t));

    SAI_SET_FLAG(rt_ctl.valid_flag, CTC_IP_GLB_PROP_V4_MARTIAN_CHECK_EN);
    rt_ctl.v4_martian_check_en = 1;

    SAI_SET_FLAG(rt_ctl.valid_flag, CTC_IP_GLB_PROP_V6_MARTIAN_CHECK_EN);
    rt_ctl.v6_martian_check_en = 1;

    ret = ctc_ipuc_set_global_property(&rt_ctl);

    (void)ret;
    return SAI_STATUS_SUCCESS;
}

static int32
ctc_sai_route_multicast_pdu_init(void)
{
    ctc_ipmc_force_route_t mcv4_route;
    int32 ret;

    /*for ipv4 pdu packets*/
    sal_memset(&mcv4_route, 0, sizeof(ctc_ipmc_force_route_t));
    mcv4_route.ip_version = CTC_IP_VER_4;
    mcv4_route.force_bridge_en = 1;    
    
   /*modified by jiangz for bug16559, 2011-10-08, for merge sdk*/  
    mcv4_route.ipaddr0_valid = 1;    
    mcv4_route.ip_addr0.ipv4 = 0xE0000000;
    mcv4_route.addr0_mask = 24;
    ret = ctc_ipmc_set_mcast_force_route(&mcv4_route);

   /*modified by jiangz for bug16559, 2011-10-08, for merge sdk, for invalid the second entry*/   
    mcv4_route.ipaddr1_valid = 1;
    mcv4_route.ip_addr1.ipv4 = 0x0;
    mcv4_route.addr1_mask = 32;
    ret = ctc_ipmc_set_mcast_force_route(&mcv4_route);

    (void)ret;
    return SAI_STATUS_SUCCESS;    
}

sai_status_t
ctc_sai_route_db_init()
{
    g_ctc_route_info.max_count = CTC_SAI_ROUTE_MAX_ENTRY;
    g_ctc_route_info.phash   =
        ctc_hash_create(CTC_VEC_BLOCK_NUM(g_ctc_route_info.max_count, ROUTE_HASH_B),
                ROUTE_HASH_B,
                (hash_key_fn)__ctc_route_hash_make,
                (hash_cmp_fn)__ctc_route_hash_cmp);

    /* add default route for ipda martion address */
    ctc_sai_route_add_ipda_martion();
    /* add default route for syn with system before */
    ctc_sai_route_add_default_route();
    /* add ipda range to force multicast pdu packet to cpu*/
    ctc_sai_route_multicast_pdu_init();
    if(NULL == g_ctc_route_info.phash)
    {
        return SAI_STATUS_NO_MEMORY;
    }

    return SAI_STATUS_SUCCESS;
}

ctc_route_entry_t*
ctc_sai_route_db_alloc()
{
    ctc_route_entry_t*	proute_entry = NULL;

    proute_entry = mem_malloc(MEM_APP_ROUTE_MODULE,sizeof(ctc_route_entry_t));

    if(proute_entry)
    {
        sal_memset(proute_entry,0,sizeof(ctc_route_entry_t));
    }

    return proute_entry;
}

void
ctc_sai_route_db_release(ctc_route_entry_t *proute_entry)
{
    if(NULL == proute_entry)
    {
        return ;
    }

    mem_free(proute_entry);
}

ctc_route_entry_t*
ctc_sai_route_db_get_by_key(const sai_unicast_route_entry_t* key)
{
    ctc_route_entry_t  *proute_entry = NULL;

    proute_entry = ctc_hash_lookup(g_ctc_route_info.phash,(void*)key);

    return proute_entry;
}

void
__route_entry_to_ipuc_param(ctc_route_entry_t *proute_entry,ctc_ipuc_param_t* pipuc_info)
{
    uint32_t    mask_len    = 0;
    uint32_t    index    = 0;
    ctc_sai_nexthop_group_id_info_t *pst_nhg = NULL;
    
    switch(proute_entry->action)
    {
    case SAI_PACKET_ACTION_DROP:
        pipuc_info->nh_id = NEIGHBOR_ACTION_DROP_NHID;
        proute_entry->cur_action = SAI_PACKET_ACTION_DROP;
        break;

    case SAI_PACKET_ACTION_FORWARD:
        pipuc_info->nh_id = CTC_SAI_OBJECT_INDEX_GET(proute_entry->nexthop_id);
        proute_entry->cur_action = SAI_PACKET_ACTION_FORWARD;
        CTC_SET_FLAG(pipuc_info->route_flag, CTC_IPUC_FLAG_TTL_CHECK);
        CTC_SET_FLAG(pipuc_info->route_flag, CTC_IPUC_FLAG_ICMP_CHECK);
        CTC_SET_FLAG(pipuc_info->route_flag, CTC_IPUC_FLAG_RPF_CHECK);

        break;

    case SAI_PACKET_ACTION_TRAP:
        pipuc_info->nh_id = NEIGHBOR_ACTION_TRAP_NHID;
        proute_entry->cur_action = SAI_PACKET_ACTION_TRAP;
        pipuc_info->l3_inf = (uint16_t)CTC_SAI_OBJECT_INDEX_GET(proute_entry->rif_id);
        CTC_SET_FLAG(pipuc_info->route_flag, CTC_IPUC_FLAG_TTL_CHECK);
        CTC_SET_FLAG(pipuc_info->route_flag, CTC_IPUC_FLAG_CONNECT);
        CTC_SET_FLAG(pipuc_info->route_flag, CTC_IPUC_FLAG_RPF_CHECK);

        break;

    default:
        break;
    }
    
    if(SAI_IP_ADDR_FAMILY_IPV4 == proute_entry->key.destination.addr_family)
    {
        pipuc_info->ip_ver = CTC_IP_VER_4;
        sal_memcpy(&pipuc_info->ip.ipv4,
            &proute_entry->key.destination.addr.ip4,
            sizeof(sai_ip4_t));

        IPV4_MASK_TO_LEN(proute_entry->key.destination.mask.ip4,mask_len);
        pipuc_info->masklen = mask_len;
        if(SAI_PACKET_ACTION_FORWARD != proute_entry->action && CTC_IPV4_ADDR_LEN_IN_BIT == pipuc_info->masklen)
        {
            SAI_SET_FLAG(pipuc_info->route_flag, CTC_IPUC_FLAG_CPU);
            pipuc_info->nh_id = NEIGHBOR_ACTION_DROP_NHID;
            CTC_UNSET_FLAG(pipuc_info->route_flag, CTC_IPUC_FLAG_CONNECT);
            CTC_UNSET_FLAG(pipuc_info->route_flag, CTC_IPUC_FLAG_RPF_CHECK);
        }
    }
    else
    {
        pipuc_info->ip_ver = CTC_IP_VER_6;
        sal_memcpy(pipuc_info->ip.ipv6,
            proute_entry->key.destination.addr.ip6,
            sizeof(sai_ip6_t));

        IPV6_MASK_TO_LEN(proute_entry->key.destination.mask.ip6,mask_len);
        pipuc_info->masklen = mask_len;
    }

    pipuc_info->vrf_id = CTC_SAI_OBJECT_INDEX_GET(proute_entry->pvr_entry->vr_id);

    pst_nhg = ctc_nexthop_group_id_get_global();
    if (NULL == pst_nhg)
    {
        CTC_SAI_DEBUG("FAIL to get nexthop group global");
        return;
    }
    
    if ((SAI_OBJECT_TYPE_NEXT_HOP_GROUP == CTC_SAI_OBJECT_TYPE_GET(proute_entry->nexthop_id)) 
            && SAI_PACKET_ACTION_FORWARD == proute_entry->action)
    {
        CTC_UNSET_FLAG(pipuc_info->route_flag, CTC_IPUC_FLAG_ICMP_CHECK);
        //index = pipuc_info->nh_id - CTC_SAI_NH_GROUP_OFFSET + 1;
        index = pipuc_info->nh_id - CTC_SAI_NH_GROUP_OFFSET;
        if (CTC_SAI_IP_MAX_RPF_IF < pst_nhg[index].nh_num)
        {
            CTC_UNSET_FLAG(pipuc_info->route_flag, CTC_IPUC_FLAG_RPF_CHECK);
        }
        else if (CTC_SAI_IP_MAX_RPF_IF == pst_nhg[index].nh_num)
        {
            CTC_SAI_DEBUG("URPF will be disabled when nh_cnt > 16");
        }
    }    
}

sai_status_t
__route_update_ipuc_to_sdk(ctc_route_entry_t *proute_entry)
{
    int32_t     ret = 0;
    ctc_ipuc_param_t  ipuc_info;

    sal_memset(&ipuc_info,0,sizeof(ctc_ipuc_param_t));

    __route_entry_to_ipuc_param(proute_entry,&ipuc_info);

    ret = ctc_ipuc_add(&ipuc_info);
    if (CTC_E_IPUC_INVALID_ROUTE_FLAG == ret)
    {
        if (CTC_FLAG_ISSET(ipuc_info.route_flag, CTC_IPUC_FLAG_RPF_CHECK))
        {
            CTC_UNSET_FLAG(ipuc_info.route_flag, CTC_IPUC_FLAG_RPF_CHECK);
            ret = ctc_ipuc_add(&ipuc_info);
        }
        /* check if the entry is same with neighbor */
    }
    /* modified by wangjj for fix bug 43512, when host entry full, 2017-03-28 */
    if (CTC_E_NO_RESOURCE == ret)
    {
        CTC_SAI_DEBUG("Resource full, add route failed");
        ret = CTC_E_NONE;
    }
#ifdef GREATBELT /*Greatbelt sdk 3.3 not support neighbor with ipuc/32, case will cause CTC_E_ENTRY_EXIST, temp solution*/
    if( ret != CTC_E_NONE)
    {
        ret = CTC_E_NONE;
    }
#endif

    return ctc_sai_get_error_from_sdk_error(ret);
}

sai_status_t
__route_remove_ipuc_to_sdk(ctc_route_entry_t *proute_entry)
{
    int32_t     ret = 0;
    ctc_ipuc_param_t  ipuc_info;

    sal_memset(&ipuc_info,0,sizeof(ctc_ipuc_param_t));

    __route_entry_to_ipuc_param(proute_entry,&ipuc_info);

    ret = ctc_ipuc_remove(&ipuc_info);
#ifdef GREATBELT /*Greatbelt sdk 3.3 not support neighbor with ipuc/32, case will cause CTC_E_ENTRY_EXIST, temp solution*/
    if( ret != CTC_E_NONE)
    {
        ret = CTC_E_NONE;
    }
#endif
    return ctc_sai_get_error_from_sdk_error(ret);
}

sai_status_t
_route_check_nexthop_exist(ctc_route_entry_t *proute_entry ,sai_object_id_t nexthop_id)
{
    struct ctc_sai_nexthop_entry_s*         pnh_entry   = NULL;
	struct ctc_sai_nexthop_group_entry_s*   pnhg_entry  = NULL;

    if (SAI_OBJECT_TYPE_NEXT_HOP == CTC_SAI_OBJECT_TYPE_GET(nexthop_id))
    {
        pnh_entry = ctc_nexthop_get_by_oid_no_ref(nexthop_id);
        if(NULL == pnh_entry)
        {
            return SAI_STATUS_ITEM_NOT_FOUND;
        }
    }
    else if (SAI_OBJECT_TYPE_NEXT_HOP_GROUP == CTC_SAI_OBJECT_TYPE_GET(nexthop_id))
    {
        pnhg_entry = ctc_nexthop_group_get_by_oid_no_ref(nexthop_id);
        if(NULL == pnhg_entry)
        {
            return SAI_STATUS_ITEM_NOT_FOUND;
        }
    }

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_route_db_add_entry(ctc_route_entry_t *proute_entry)
{
    sai_status_t ret = SAI_STATUS_SUCCESS;

    ret = __route_update_ipuc_to_sdk(proute_entry);
    if(SAI_STATUS_SUCCESS != ret)
    {        
        return ret;
    } 

    ctc_hash_insert(g_ctc_route_info.phash,&proute_entry->key);

    return SAI_STATUS_SUCCESS;
}

sai_status_t
ctc_sai_route_db_remove_entry(ctc_route_entry_t *proute_entry)
{
    sai_status_t ret = SAI_STATUS_SUCCESS;
    ctc_ipuc_param_t  ipuc_info;
    sai_unicast_route_entry_t default_entry;
    
    sal_memset(&ipuc_info,0,sizeof(ctc_ipuc_param_t));
    sal_memset(&default_entry, 0, sizeof(default_entry));
    default_entry.vr_id = proute_entry->key.vr_id;
    __route_entry_to_ipuc_param(proute_entry,&ipuc_info);

    ret = ctc_ipuc_remove(&ipuc_info);
//#if GREATBELT /*SDK3.3 don't support neighbor&ipuc, this case will cause CTC_E_ENTRY_NOT_EXIST*/
    if(ret != CTC_E_NONE )
    {
        ret = CTC_E_NONE;
    }
//#endif
    if(ret != 0)
    {
        return ctc_sai_get_error_from_sdk_error(ret);
    }

    if (0 == sal_memcmp(&default_entry, &proute_entry->key, sizeof(default_entry)))
    {
        ctc_sai_route_add_default_ipuc_entry();
    }
    
    ctc_hash_remove(g_ctc_route_info.phash,&proute_entry->key);

    if(proute_entry->pvr_entry)
    {
        ctc_vr_release(proute_entry->pvr_entry);
        proute_entry->pvr_entry = NULL;
    }

    return SAI_STATUS_SUCCESS;
}

#define ________SAI_SAI_DEBUG_FUNC
sai_status_t
ctc_sai_set_route_attribute_debug_param(
    _In_ const sai_unicast_route_entry_t* unicast_route_entry,
    _In_ const sai_attribute_t *attr)
{
    CTC_SAI_DEBUG("in:vr_id %u", unicast_route_entry->vr_id);
    switch(attr->id)
    {
    case SAI_ROUTE_ATTR_PACKET_ACTION:
        CTC_SAI_DEBUG("in:SAI_ROUTE_ATTR_PACKET_ACTION %d", attr->value.s32);
        break;

    case SAI_ROUTE_ATTR_NEXT_HOP_ID:
        CTC_SAI_DEBUG("in:SAI_ROUTE_ATTR_NEXT_HOP_ID 0x%llx", attr->value.oid);
        break;
    }
    return SAI_STATUS_SUCCESS;
}
sai_status_t
ctc_sai_get_route_attribute_debug_param(
    _In_ const sai_unicast_route_entry_t* unicast_route_entry,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{
    uint32_t                    attr_idx    = 0;
    const sai_attribute_t *attr = NULL;

    CTC_SAI_DEBUG("in:vr_id 0x%llx attr_count %u", unicast_route_entry->vr_id, attr_count);
    for (attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        switch (attr->id)
        {
        case SAI_ROUTE_ATTR_PACKET_ACTION:
            CTC_SAI_DEBUG("in:SAI_ROUTE_ATTR_PACKET_ACTION %d", attr->value.s32);
            break;
        case SAI_ROUTE_ATTR_TRAP_PRIORITY:
            CTC_SAI_DEBUG("in:SAI_ROUTE_ATTR_PACKET_ACTION %u", attr->value.u8);
            break;
        case SAI_ROUTE_ATTR_NEXT_HOP_ID:
            CTC_SAI_DEBUG("in:SAI_ROUTE_ATTR_PACKET_ACTION 0x%llx", attr->value.oid);
            break;
        }
    }

    return SAI_STATUS_SUCCESS;
}
#define ________SAI_SAI_API_FUNC
/*
* Routine Description:
*    Create Route
*
* Arguments:
*    [in] unicast_route_entry - route entry
*    [in] attr_count - number of attributes
*    [in] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*
* Note: IP prefix/mask expected in Network Byte Order.
*
*/
sai_status_t
ctc_sai_create_route(
    _In_ const sai_unicast_route_entry_t* unicast_route_entry,
    _In_ uint32_t attr_count,
    _In_ const sai_attribute_t *attr_list)
{
    sai_status_t                 ret = SAI_STATUS_SUCCESS;
    ctc_sai_attr_entry_list_t    *pattr_entry_list = NULL;
    ctc_route_entry_t            *proute_entry = NULL;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_PTR_VALID_CHECK(attr_list);
    CTC_SAI_PTR_VALID_CHECK(unicast_route_entry);

    ret = ctc_sai_attr_alloc_attr_entry_list(g_sai_attr_entries,
                                   attr_list,
                                   attr_count,
                                   &pattr_entry_list);

    if(SAI_STATUS_SUCCESS != ret)
    {
        return ret;
    }

    /* 1. check route exist */
    proute_entry = ctc_sai_route_db_get_by_key(unicast_route_entry);
    if(NULL != proute_entry)
    {
        ret = SAI_STATUS_ITEM_ALREADY_EXISTS;
        goto out;
    }

    /* 2. alloc route */
    proute_entry = ctc_sai_route_db_alloc();
    if(NULL == proute_entry)
    {
        ret = SAI_STATUS_NO_MEMORY;
        goto out;
    }

    /* 3. add parameter */
    sal_memcpy(&proute_entry->key, unicast_route_entry, sizeof(sai_unicast_route_entry_t));

    proute_entry->pvr_entry = ctc_vr_get_by_oid(unicast_route_entry->vr_id);
    if(NULL == proute_entry->pvr_entry)
    {
        ret = SAI_STATUS_INVALID_OBJECT_ID;
        goto out1;
    }

    if (pattr_entry_list[SAI_ROUTE_ATTR_NEXT_HOP_ID].valid)
    {
        ret = _route_check_nexthop_exist(proute_entry,
            pattr_entry_list[SAI_ROUTE_ATTR_NEXT_HOP_ID].value.oid);

        if(SAI_STATUS_SUCCESS != ret)
        {
            ret = SAI_STATUS_SUCCESS;
            goto out1;
        }

        proute_entry->nexthop_id = pattr_entry_list[SAI_ROUTE_ATTR_NEXT_HOP_ID].value.oid;
    }

    if(pattr_entry_list[SAI_ROUTE_ATTR_TRAP_PRIORITY].valid)
    {
        proute_entry->priority =
            pattr_entry_list[SAI_ROUTE_ATTR_TRAP_PRIORITY].value.u8;
    }

    if(pattr_entry_list[SAI_ROUTE_ATTR_PACKET_ACTION].valid)
    {
        proute_entry->action =
            pattr_entry_list[SAI_ROUTE_ATTR_PACKET_ACTION].value.s32;
    }
    else
    {
        proute_entry->action = SAI_PACKET_ACTION_FORWARD;
    }

    if (pattr_entry_list[SAI_ROUTE_ATTR_RIF_ID].valid)
    {
        proute_entry->rif_id = pattr_entry_list[SAI_ROUTE_ATTR_RIF_ID].value.oid;
    }

    /* 4. add route */
    ret = ctc_sai_route_db_add_entry(proute_entry);
    if(SAI_STATUS_SUCCESS != ret)
    {
        goto out1;
    }
    else
    {
        //return ret;
    }

out:
    if(pattr_entry_list)
    {
        ctc_sai_attr_free_attr_entry_list(pattr_entry_list);
    }

    return ret;

out1:
    if(proute_entry)
    {
        ctc_sai_route_db_release(proute_entry);
    }

    goto out;
}

/*
* Routine Description:
*    Remove Route
*
* Arguments:
*    [in] unicast_route_entry - route entry
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*
* Note: IP prefix/mask expected in Network Byte Order.
*/
sai_status_t
ctc_sai_remove_route(
    _In_ const sai_unicast_route_entry_t* unicast_route_entry)
{
    ctc_route_entry_t            *proute_entry = NULL;
    sai_status_t                 ret = SAI_STATUS_SUCCESS;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_PTR_VALID_CHECK(unicast_route_entry);

    /* 1. check route exist */
    proute_entry = ctc_sai_route_db_get_by_key(unicast_route_entry);
    if(NULL == proute_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    /* 2. remove route */
    ret = ctc_sai_route_db_remove_entry(proute_entry);
    if(SAI_STATUS_SUCCESS != ret)
    {
        return ret;
    }

    /* 3. release route */
    ctc_sai_route_db_release(proute_entry);
    return SAI_STATUS_SUCCESS;
}

/*
* Routine Description:
*    Set route attribute value
*
* Arguments:
*    [in] unicast_route_entry - route entry
*    [in] attr - attribute
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_set_route_attribute(
    _In_ const sai_unicast_route_entry_t* unicast_route_entry,
    _In_ const sai_attribute_t *attr)
{
    sai_status_t                ret             = SAI_STATUS_SUCCESS;
    ctc_route_entry_t           *proute_entry   = NULL;
    //ctc_route_entry_t           route_entry;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_PTR_VALID_CHECK(attr);
    CTC_SAI_PTR_VALID_CHECK(unicast_route_entry);

    ret = ctc_sai_attr_check_write_attr(g_sai_attr_entries,attr);

    if(ret != SAI_STATUS_SUCCESS)
    {
        return ret;
    }

    proute_entry = ctc_sai_route_db_get_by_key(unicast_route_entry);
    if(NULL == proute_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    ret = __route_remove_ipuc_to_sdk(proute_entry);
    #if 0
    sal_memset(&route_entry, 0, sizeof(route_entry));
    sal_memcpy(&route_entry, proute_entry, sizeof(route_entry));
    ret = ctc_sai_route_db_remove_entry(proute_entry);
    #endif
    ctc_sai_set_route_attribute_debug_param(unicast_route_entry, attr);
    switch(attr->id)
    {
    case SAI_ROUTE_ATTR_PACKET_ACTION:
        if(proute_entry->action != attr->value.s32)
        {
            proute_entry->action = attr->value.s32;
        }

    case SAI_ROUTE_ATTR_NEXT_HOP_ID:
        if(proute_entry->nexthop_id != attr->value.oid)
        {
            proute_entry->nexthop_id = attr->value.oid;
            //ret = ctc_sai_route_db_add_entry(&route_entry);
        }

        break;
    }

    ret = __route_update_ipuc_to_sdk(proute_entry);

    return ret;
}

/*
* Routine Description:
*    Get route attribute value
*
* Arguments:
*    [in] unicast_route_entry - route entry
*    [in] attr_count - number of attributes
*    [inout] attr_list - array of attributes
*
* Return Values:
*    SAI_STATUS_SUCCESS on success
*    Failure status code on error
*/
sai_status_t
ctc_sai_get_route_attribute(
    _In_ const sai_unicast_route_entry_t* unicast_route_entry,
    _In_ uint32_t attr_count,
    _Inout_ sai_attribute_t *attr_list)
{
    sai_status_t                ret         = SAI_STATUS_SUCCESS;
    sai_attribute_t*            attr        = NULL;
    uint32_t                    attr_idx    = 0;
    ctc_route_entry_t           *proute_entry = NULL;

    CTC_SAI_DEBUG_FUNC();
    CTC_SAI_PTR_VALID_CHECK(attr_list);
    CTC_SAI_PTR_VALID_CHECK(unicast_route_entry);

    proute_entry = ctc_sai_route_db_get_by_key(unicast_route_entry);
    if(NULL == proute_entry)
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }


    for(attr_idx = 0; attr_idx < attr_count; attr_idx++)
    {
        attr = attr_list + attr_idx;
        ret = ctc_sai_attr_check_read_attr(g_sai_attr_entries,attr);

        if(ret != SAI_STATUS_SUCCESS)
        {
            return ret + attr_idx;
        }

        switch(attr->id)
        {
        case SAI_ROUTE_ATTR_PACKET_ACTION:
            attr->value.s32 = proute_entry->action;
            break;
        case SAI_ROUTE_ATTR_TRAP_PRIORITY:
            attr->value.u8 = proute_entry->priority;
            break;
        case SAI_ROUTE_ATTR_NEXT_HOP_ID:
            attr->value.oid = proute_entry->nexthop_id;
            break;
        }

        if(ret != SAI_STATUS_SUCCESS)
        {
            break;
        }
    }
    ctc_sai_get_route_attribute_debug_param(unicast_route_entry, attr_count, attr_list);
    return ret;
}

#define ________SAI_INNER_FUNC
static int32_t
__hash_traversal_update_nh(void* array_data, void* user_data)
{
    ctc_sai_nexthop_entry_t*        pnh_entry  = NULL;
    ctc_route_entry_t           *proute_entry = NULL;

    proute_entry = (ctc_route_entry_t*)array_data;
    pnh_entry    = (ctc_sai_nexthop_entry_t*)user_data;

    if(proute_entry->nexthop_id == pnh_entry->nh_id)
    {
        __route_update_ipuc_to_sdk(proute_entry);
    }

    return 0;
}

static int32_t
ctc_nexthop_notifier_callback(struct ctc_sai_notifier_block *nb,
			uint32_t action, void *data)
{

    switch(action)
    {
        case CTC_SAI_NEXTHOP_UPDATE_EVENT:
            ctc_hash_traverse(g_ctc_route_info.phash,__hash_traversal_update_nh,data);
            break;
        default :
            return CTC_SAI_NOTIFY_OK;
    }

    return CTC_SAI_NOTIFY_OK;
}

static struct ctc_sai_notifier_block route_nexthop_notifier_cb = {
    .notifier_call = ctc_nexthop_notifier_callback,
};

static sai_status_t __init_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    sai_status_t    ret = SAI_STATUS_SUCCESS;

    ret = ctc_sai_route_db_init();
    if(SAI_STATUS_SUCCESS != ret)
    {
        return ret;
    }

    ctc_sai_nexthop_evnet_notifier_register(&route_nexthop_notifier_cb);

    preg->init_status =  INITIALIZED;

    return ret;
}

static sai_status_t __exit_mode_fn(ctc_sai_api_reg_info_t* preg, void* private_data)
{
    preg->init_status = UNINITIALIZED;
    return SAI_STATUS_SUCCESS;
}


static sai_route_api_t      g_sai_api_func = {
    .create_route           = ctc_sai_create_route,
    .remove_route           = ctc_sai_remove_route,
    .set_route_attribute    = ctc_sai_set_route_attribute,
    .get_route_attribute    = ctc_sai_get_route_attribute,
};

static ctc_sai_api_reg_info_t g_api_reg_info = {
        .id  = SAI_API_ROUTE,
        .init_func = __init_mode_fn,
        .exit_func = __exit_mode_fn,
        .api_method_table = &g_sai_api_func,
        .private_data     = NULL,
};

#define ________SAI_OUTER_FUNC
sai_status_t ctc_sai_route_init()
{
    api_reg_register_fn(&g_api_reg_info);

    return SAI_STATUS_SUCCESS;
}


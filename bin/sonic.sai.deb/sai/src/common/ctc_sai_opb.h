#if !defined (__CTC_SAI_OPB_H_)
#define __CTC_SAI_OPB_H_

#include <saitypes.h>
#include <sal.h>

#define CTC_SAI_MAX_OPB 32

typedef struct
{
    uint32 *data;           /**< bitmap of allocator */
    uint32 words;           /**< number fo 32 bit words in allocator */
    uint32 start_offset;
    uint32 max_size;
    char   *desc;           /**< descption of allocator */    
} ctc_sai_opb_t;

typedef struct
{
    ctc_sai_opb_t *opb_array[CTC_SAI_MAX_OPB];
    uint32         index;
    uint32         inited;
} ctc_sai_opb_master_t;

int32
ctc_sai_opb_create(ctc_sai_opb_t* p_opb, uint32 start_offset, uint32 max_size, char *desc);

uint32
ctc_sai_opb_offset_is_alloced(ctc_sai_opb_t* p_opb, uint32 offset);

int32
ctc_sai_opb_alloc_designated_offset(ctc_sai_opb_t* p_opb, uint32 offset);

int32
ctc_sai_opb_alloc_offset(ctc_sai_opb_t* p_opb, uint32* offset);

int32
ctc_sai_opb_alloc_offset_position_reverse(ctc_sai_opb_t* p_opb, uint32 position, uint32* offset);

int32
ctc_sai_opb_alloc_offset_last_reverse(ctc_sai_opb_t* p_opb, uint32* offset);

int32
ctc_sai_opb_free_offset(ctc_sai_opb_t* p_opb, uint32 offset);

int32
ctc_sai_opb_dump(FILE *fp);

int32
ctc_sai_opb_init();

#endif /* !__CTC_SAI_OPB_H_ */


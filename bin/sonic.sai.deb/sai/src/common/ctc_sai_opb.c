
#include <saistatus.h>
#include <saitypes.h>
#include <sal.h>
#include <ctc_const.h>
#include <ctc_macro.h>
#include <ctc_sai_opb.h>

static ctc_sai_opb_master_t g_ctc_sai_opb_master;

int32
ctc_sai_opb_create(ctc_sai_opb_t* p_opb, uint32 start_offset, uint32 max_size, char *desc)
{
    if (g_ctc_sai_opb_master.index >= CTC_SAI_MAX_OPB)
    {
        return SAI_STATUS_INSUFFICIENT_RESOURCES;
    }
    
    g_ctc_sai_opb_master.opb_array[g_ctc_sai_opb_master.index] = p_opb;
    g_ctc_sai_opb_master.index++;
    
    p_opb->start_offset = start_offset;
    p_opb->max_size     = max_size;
    p_opb->desc         = strdup(desc);
    p_opb->words = (start_offset + max_size + CTC_UINT32_BITS) / CTC_UINT32_BITS;
    p_opb->data = mem_malloc(MEM_APP_COMMON_MODULE, sizeof(uint32) * p_opb->words);

    return SAI_STATUS_SUCCESS;
}

uint32
ctc_sai_opb_offset_is_alloced(ctc_sai_opb_t* p_opb, uint32 offset)
{
    if (offset >= p_opb->start_offset + p_opb->max_size)
    {
        return FALSE;
    }
    
    if (CTC_BMP_ISSET(p_opb->data, offset))
    {
        return TRUE;
    }

    return FALSE;
}

int32
ctc_sai_opb_alloc_designated_offset(ctc_sai_opb_t* p_opb, uint32 offset)
{
    if (offset >= p_opb->start_offset + p_opb->max_size)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }
    
    if (CTC_BMP_ISSET(p_opb->data, offset))
    {
        return SAI_STATUS_ITEM_ALREADY_EXISTS;
    }

    CTC_BMP_SET(p_opb->data, offset);

    return SAI_STATUS_SUCCESS;
}

int32
ctc_sai_opb_alloc_offset(ctc_sai_opb_t* p_opb, uint32* offset)
{
    int32 i = 0;
    int32 pos = 0;    
    
    for (i = 0, pos = p_opb->start_offset; i < p_opb->max_size; i++, pos++)
    {
        if (CTC_BMP_ISSET(p_opb->data, pos))
        {
            continue;
        }

        CTC_BMP_SET(p_opb->data, pos);
        *offset = pos;
        return SAI_STATUS_SUCCESS;
    }
    
    return SAI_STATUS_INSUFFICIENT_RESOURCES;
}

int32
ctc_sai_opb_alloc_offset_position_reverse(ctc_sai_opb_t* p_opb, uint32 position, uint32* offset)
{
    int32 pos = 0;    

    for (pos = position; pos >= p_opb->start_offset; pos--)
    {
        if (CTC_BMP_ISSET(p_opb->data, pos))
        {
            continue;
        }

        CTC_BMP_SET(p_opb->data, pos);
        *offset = pos;
        return SAI_STATUS_SUCCESS;
    }
    
    return SAI_STATUS_INSUFFICIENT_RESOURCES;
}

int32
ctc_sai_opb_alloc_offset_last_reverse(ctc_sai_opb_t* p_opb, uint32* offset)
{
    int32 i = 0;
    int32 pos = 0;    
    
    for (i = 0, pos = p_opb->start_offset+p_opb->max_size-1; i < p_opb->max_size; i++, pos--)
    {
        if (CTC_BMP_ISSET(p_opb->data, pos))
        {
            continue;
        }

        CTC_BMP_SET(p_opb->data, pos);
        *offset = pos;
        return SAI_STATUS_SUCCESS;
    }
    
    return SAI_STATUS_INSUFFICIENT_RESOURCES;
}

int32
ctc_sai_opb_free_offset(ctc_sai_opb_t* p_opb, uint32 offset)
{
    if (offset >= p_opb->start_offset + p_opb->max_size)
    {
        return SAI_STATUS_INVALID_PARAMETER;
    }
    
    if (!CTC_BMP_ISSET(p_opb->data, offset))
    {
        return SAI_STATUS_ITEM_NOT_FOUND;
    }

    CTC_BMP_UNSET(p_opb->data, offset);
    
    return SAI_STATUS_SUCCESS;
}

int32
ctc_sai_bitmap_val2str(FILE *fp, const uint32 *bmp, const uint32 bmp_len)
{
#define CTC_SAI_LINE_WIDTH  80

    uint32 offset = 0;
    uint32 start_value = 0;
    uint32 stop_value = 0;
    char str[CTC_SAI_LINE_WIDTH];
    char tmp[32];
    uint32 used = 0;
    uint32 tmp_len = 0;

    str[0] = 0;
    for (offset = 0; offset < CTC_UINT32_BITS * bmp_len; offset++)
    {
        if (CTC_BMP_ISSET(bmp, offset))
        {
            start_value = offset;
            stop_value = start_value;
            do 
            {
                stop_value++;
            } while (CTC_BMP_ISSET(bmp, stop_value));
            stop_value--;
            offset = stop_value;
            if (start_value == stop_value)
            {
                sal_sprintf(tmp, "%d,", start_value);
                tmp_len = sal_strlen(tmp);
                if (used + tmp_len >= CTC_SAI_LINE_WIDTH)
                {
                    sal_fprintf(fp, "%s\n", str);
                    sal_memset(str, 0, sizeof(str));
                    continue;
                }
                used += sal_strlen(tmp);
                sal_strncat(str, tmp, 5);
            }
            else
            {
                if (stop_value == start_value + 1)
                    sal_sprintf(tmp, "%d,%d,", start_value, stop_value);
                else
                    sal_sprintf(tmp, "%d-%d,", start_value, stop_value);
                tmp_len = sal_strlen(tmp);
                if (used + tmp_len >= CTC_SAI_LINE_WIDTH)
                {
                    sal_fprintf(fp, "%s\n", str);
                    sal_memset(str, 0, sizeof(str));
                    continue;
                }                
                used += sal_strlen(tmp);
                sal_strncat(str, tmp, 10);   
            }            
        }
    }

    /* strip ',' */
    if ((used > 0) && (str[used-1] == ','))
    {
        str[used-1] = 0;
    }

    if (sal_strlen(str))
    {
        sal_fprintf(fp, "%s\n", str);
        sal_memset(str, 0, sizeof(str));
    }
    
    return SAI_STATUS_SUCCESS;
}

int32
ctc_sai_opb_dump_one(FILE *fp, uint32 i, ctc_sai_opb_t *opb)
{
    sal_fprintf(fp, "### Index %u, desc %s, range [%u, %u], number %u, words %u ###\n", 
        i, opb->desc, opb->start_offset, (opb->start_offset+opb->max_size-1), opb->max_size, opb->words);
    sal_fprintf(fp, "alloced:\n");
    ctc_sai_bitmap_val2str(fp, opb->data, opb->words);
    sal_fprintf(fp, "\n");
    
    return SAI_STATUS_SUCCESS;    
}

int32
ctc_sai_opb_dump(FILE *fp)
{
    uint32 i = 0;
    
    for (i = 0; i < g_ctc_sai_opb_master.index; i++)
    {
        ctc_sai_opb_dump_one(fp, i, g_ctc_sai_opb_master.opb_array[i]);
    }
    
    return SAI_STATUS_SUCCESS;    
}

int32
ctc_sai_opb_init()
{
    sal_memset(&g_ctc_sai_opb_master, 0, sizeof(g_ctc_sai_opb_master));
    g_ctc_sai_opb_master.inited = TRUE;

    return SAI_STATUS_SUCCESS;
}

